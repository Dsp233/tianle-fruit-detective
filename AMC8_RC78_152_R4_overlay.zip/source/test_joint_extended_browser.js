'use strict';
// Real locator clicks replay an independently checked event plan. VM planning
// is never counted as native execution; no DOM handlers are called through evaluate.
const assert=require('assert'),path=require('path'),{boot}=require('./test_support'),T=require('./test_joint_extended'),N=require('./native_browser_support');
const root=process.env.AMC8_RC70_CANDIDATE||path.resolve(__dirname,'..'),out=process.env.AMC8_RC70_EVIDENCE||path.join(root,'tmp/rc78/joint-browser');
const shard=Number(process.env.AMC8_RC70_SHARD||0),shards=Number(process.env.AMC8_RC70_SHARDS||1),all=require('./joint_families.json').families.filter(f=>f.protocol==='FIVE_ROLE_APPLICATION_152'),families=all.filter((_,i)=>i%shards===shard);
function record(b,fn){const commands=[],click=b.click.bind(b),input=b.inputJoint.bind(b);b.click=(action,data={})=>{commands.push({type:'click',action,data});return click(action,data)};b.inputJoint=(field,value)=>{commands.push({type:'input',field,value:String(value)});return input(field,value)};try{return {commands,result:fn()};}finally{b.click=click;b.inputJoint=input;}}
function selector(c){return '[data-action='+JSON.stringify(c.action)+']'+Object.entries(c.data).map(([k,v])=>'[data-'+k.replace(/[A-Z]/g,c=>'-'+c.toLowerCase())+'='+JSON.stringify(String(v))+']').join('');}
async function replay(page,commands){for(const c of commands){
 if(c.type==='input')await page.locator('[data-joint-field='+JSON.stringify(c.field)+']').fill(c.value);
 else{
  // Folded SVG back faces can be occluded by front faces. The interface also
  // provides explicit face buttons; use those real visible controls when present.
  const buttons=page.locator('button'+selector(c));
  await (await buttons.count()?buttons.first():page.locator(selector(c)).first()).click();
 }
}}
async function run(){
 const expected=families.flatMap(f=>f.instances.map(i=>i.id)),rows=[];const env=await N.start(root,out);
 if(!env){N.write(out,'joint-native-'+shard+'.json',{result:'BLOCKED',expectedTaskIds:expected,executed:0,reason:'BROWSER_UNAVAILABLE',nativeBrowser:'NOT_RUN'});process.exitCode=2;return;}
 try{for(const f of families){
  const clock={now:2000000000000},model=boot({},clock),context=await env.browser.newContext({locale:'zh-CN',viewport:{width:1180,height:900}});
  await context.addInitScript(()=>{window.__jointClock=2000000000000;Date.now=()=>window.__jointClock;});const page=await context.newPage();page.setDefaultTimeout(12000);const errors=[];page.on('pageerror',e=>errors.push(e.message));
  try{
   await page.goto(env.base+'/index.html',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>progressStore.getStatus()==='ready');
   await page.locator('details.topic-parent > summary').click();await page.locator('[data-action="knowledge"]').first().click();await page.locator('[data-action="network"][data-code='+JSON.stringify(f.regionId)+']').first().click();await page.locator('[data-action="networkSkill"][data-code='+JSON.stringify(f.primarySkillId)+']').click();
   for(const role of ['G','I1','I2','C','D']){
    const id=f.id+'-'+role;
    if(role==='D'){
     await page.locator('[data-action="joint"][data-code='+JSON.stringify(id)+']').click();assert.equal(await page.evaluate(()=>taskNow()),null);await page.locator('[data-action="network"]').first().click();
     clock.now+=86400000;await page.evaluate(now=>window.__jointClock=now,clock.now);
    }
    model.click('joint',{code:id});const plan=record(model,()=>T.complete(model));
    await page.locator('[data-action="joint"][data-code='+JSON.stringify(id)+']').click();assert.equal(await page.evaluate(()=>taskNow().id),id);
    // Exercise a native correct-operation/wrong-invoice path once per family,
    // without using that modified role as a clean independence claim.
    if(role==='G'){
     await replay(page,plan.commands.slice(0,-1));await page.locator('[data-joint-field="cost"]').fill(String(plan.result.expected.cost+1));await page.locator('[data-action="check"]').first().click();
     const wrong=await page.evaluate(()=>saved.attempts.at(-1));assert.equal(wrong.gradingResult,'incorrect');assert(wrong.jointFacts.nativeAnchorPassed&&!wrong.jointFacts.supportAnchorPassed);
     await page.locator('[data-joint-field="cost"]').fill(String(plan.result.expected.cost));await page.locator('[data-action="check"]').first().click();assert.equal(await page.evaluate(()=>saved.attempts.at(-1).firstSubmissionCorrect),false);
    }else await replay(page,plan.commands);
    const actual=await page.evaluate(()=>saved.attempts.at(-1));assert.equal(actual.gradingResult,'correct');assert.equal(actual.taskInstanceId,id);assert.equal(actual.formalEligible,['I1','I2','D'].includes(role));assert.equal(actual.independent,role!=='G'&&role!=='C');assert(Math.abs(actual.jointFacts.extendedObserved.quantity-plan.result.q)<1e-8);assert.equal(await page.evaluate(()=>Object.keys(saved.skillStage).length),0);
    rows.push({taskId:id,kind:role,status:'PASS',realLocatorEvents:plan.commands.length,quantity:plan.result.q});await page.locator('[data-action="next"]').first().click();
   }
   await page.reload({waitUntil:'domcontentloaded'});await page.waitForFunction(()=>progressStore.getStatus()==='ready');assert(await page.evaluate(fid=>jointEvidence(fid).delayed,f.id));assert.deepEqual(errors,[]);
  }catch(e){rows.push({familyId:f.id,status:'FAIL',error:e.stack});await page.screenshot({path:path.join(out,f.id+'-failure.png'),fullPage:true});}
  finally{await context.close();}
 }}finally{await env.close();}
 const passed=rows.filter(r=>r.status==='PASS').map(r=>r.taskId),ok=passed.length===expected.length&&new Set(passed).size===expected.length&&expected.every(id=>passed.includes(id))&&!rows.some(r=>r.status==='FAIL');
 N.write(out,'joint-native-'+shard+'.json',{result:ok?'PASS':'FAIL',shard,shards,expectedTaskIds:expected,rows,scope:'Actual native DOM clicks and fills; plan arithmetic independently checked in test_joint_extended.js; not child usability or independent editorial acceptance.',clock:'Controlled 24-hour application clock, not elapsed real device time',audioOutput:'NOT_TESTED',physicalDevice:'NOT_TESTED'});if(!ok){console.error(JSON.stringify({failedRows:rows.filter(r=>r.status==='FAIL')}));process.exitCode=1;}
}
run().catch(e=>{N.write(out,'joint-native-error.json',{result:'FAIL',error:e.stack});console.error(e);process.exitCode=1});
