'use strict';
// Verification helpers, excluded from shipped assessment pages.
const assert=require('assert');
const {solveFoundation}=require('./test_foundation_solver');
const microLatest=b=>b.last||JSON.parse(b.storage.tianle_amc8_question_design_v1).attempts.at(-1);
function solvePrediction(b,t){
 if(!['测','巩固'].includes(t.phase))return;
 let expected=null;
 if(t.mode==='integerLab'&&['square','root','power'].includes(t.kind))expected=[t.kind==='root'?t.side*(t.unitSize??1):t.target];
 if(t.mode==='patternLab'&&['arithmetic','geometric','explicit','twoPrev'].includes(t.kind)){
  const values=[...t.initial];const count=t.kind==='twoPrev'?t.count:2;
  for(let i=0;i<count;i++)values.push(t.kind==='arithmetic'?values.at(-1)+t.step:t.kind==='geometric'?values.at(-1)*t.factor:t.kind==='explicit'?(t.operationOrder==='addThenMultiply'?(values.at(-1)+t.add)*t.multiplier:values.at(-1)*t.multiplier+t.add):values.at(-1)+values.at(-2));expected=values.slice(t.initial.length);
 }
 if(t.mode==='measureLab'&&t.kind!=='rearrange'){const per=measureOuterOracle(t.cells||[]).length*t.unitSize,area=(t.cells||[]).length*t.unitSize**2;expected=t.kind==='length'?[(t.end-t.start)*t.unitSize]:t.kind==='perimeter'?[per]:t.kind==='area'?[area]:[per,area]}
 if(t.mode==='angleLab'&&['triangle','conditions'].includes(t.kind))expected=[180-t.angles.filter((_,i)=>i!==t.unknown).reduce((a,b)=>a+b,0)];
 if(['percentLab','scaleLab'].includes(t.mode)){if(t.kind==='whole')expected=[t.part*t.copies];if(t.kind==='change')expected=[t.start+t.add-t.remove];if(t.kind==='estimate'&&t.bounds)expected=['lower','upper'].map(k=>t.bounds[k][0]*t.bounds[k][1])}
 if(t.mode==='ratioLab'){
  if(t.kind==='unit')expected=[t.groups];
  if(t.kind==='partition')expected=t.knownUnit?[t.copies]:[t.unitRed,t.unitBlue];
  if(t.kind==='scale')expected=[t.red*(t.targetCopies?.red||t.copies),t.blue*(t.targetCopies?.blue||t.copies)];
 }
 if(t.mode==='rateLab'){
  if(t.kind==='divide')expected=[t.per];if(t.kind==='compose')expected=[t.total];
  if(t.kind==='compare')expected=[t.a.total/t.a.units,t.b.total/t.b.units];
  if(t.kind==='convert')expected=[t.direction==='forward'?t.count*t.factor:t.count];
 }
 if(t.mode==='journeyLab'){
  const walked=t.segments?.reduce((a,b)=>a+b,0);
  expected=t.kind==='inverse'?[t.count*(t.elapsedPer||1)]:t.kind==='remaining'?[t.unknownWhole?t.whole:t.whole-walked]:t.kind==='joint'?[['a','b'].reduce((n,s)=>n+t[s]*Math.max(0,t.count-(t.starts?.[s]||0)),0)]:[t.kind==='segment'?walked:t.count*t.per];
 }
 if(t.mode==='scaleLab'){
  if(t.kind==='pair')expected=[t.red*(t.targetFactors?.red||t.factor),t.blue*(t.targetFactors?.blue||t.factor)];
  if(t.kind==='length')expected=['short','long'].map(s=>t.direction==='shrink'?t[s]/t.factor:t[s]*t.factor);
  if(t.kind==='area')expected=[t.rows*t.cols*(t.axisFactors?.rows||t.factor)*(t.axisFactors?.cols||t.factor)];
  if(t.kind==='map')expected=[t.count*t.per];
 }
if(t.mode==='equationLab'){
  if(t.kind==='equal')expected=[Number(t.left.reduce((a,n)=>a+n,0)===t.right.reduce((a,n)=>a+n,0))];
  if(['unknown','bilateral'].includes(t.kind))expected=[t.total-t.known];
  if(t.kind==='inverse')expected=[t.unknownInitial?t.remain+t.removedGiven:t.initial-t.remain];
  if(t.kind==='substitute')expected=[Number(t.bag+t.known===t.total)];
 }
 if(t.mode==='constraintLab'){
  if(t.kind==='reverse')expected=[t.bag];
  if(t.kind==='verify')expected=[Number(t.groups*t.bag+(t.extraOutside?t.extra:t.groups*t.extra)===(t.givenTotal??t.groups*(t.bag+t.extra)))];
  if(t.kind==='parity')expected=[Number(t.total%t.divisor===0)];
  if(['stock','optimal'].includes(t.kind))expected=[Math.floor(t.stock/t.per)];
 }
 if(t.mode==='coordinateLab'){
  if(t.kind==='machine')expected=[t.reverseIndex===2?t.inputs[2]:t.inputs[2]*t.multiplier+t.add];
  if(t.kind==='dynamic')expected=[t.startValue+t.step*t.duration];
 }
 if(t.mode==='groupingLab'&&t.kind==='digitRules')expected=t.cases.map(c=>c.number%c.divisor);
 else if(t.mode==='groupingLab'&&t.kind!=='digits')expected=t.kind==='reconstruct'?[t.knownGroups*t.divisor+t.remainder]:(t.kind==='digitSum'?t.numbers.map(n=>String(n).split('').reduce((a,b)=>a+Number(b),0)):t.totals||[t.total]).map(n=>n%t.divisor);
 if(t.mode==='cycleLab'){
  if(t.kind==='power'){let digit=1;for(let i=0;i<t.target;i++)digit=digit*t.factor%10;expected=[digit]}else{
   const n=t.base.length,pos=(((t.kind==='weekday'?t.start:t.indexBase===0?0:-1)+(t.direction||1)*t.target)%n+n)%n;
   expected=[t.kind==='weekday'||t.indexBase===0?pos:pos+1];
  }
 }
 if(!expected)return;
 if((t.mode==='equationLab'&&['equal','substitute'].includes(t.kind))||(t.mode==='constraintLab'&&['verify','parity'].includes(t.kind))||(t.mode==='cycleLab'&&t.kind==='weekday')){b.click('predictionPick',{value:String(expected[0])});b.click('predictionLock');return}
 expected.forEach((n,index)=>{if(n===0)b.click('predictionAmount',{index:String(index),delta:'0'});else{const sign=Math.sign(n);n=Math.abs(n);for(const d of [50,10,5,1])while(n>=d){b.click('predictionAmount',{index:String(index),delta:String(sign*d)});n-=d}}});b.click('predictionLock');
}
function solveInteger(b,t){
 solvePrediction(b,t);
 if(['position','walk'].includes(t.kind))for(let n=t.start;n!==t.target;n+=Math.sign(t.target-n))b.click('integerStep',{delta:String(Math.sign(t.target-n))});
 if(t.kind==='compare'){b.click('integerMark',{value:String(t.left)});b.click('integerMark',{value:String(t.right)});b.click('integerChoice',{value:t.target===t.left?'left':'right'})}
 if(t.kind==='square')for(let i=0;i<t.side;i++)b.click('integerRow',{delta:'1'});
 if(t.kind==='root')for(let i=0;i<t.side;i++)b.click('integerGrow',{delta:'1'});
 if(t.unitSize&&!['测','巩固'].includes(t.phase)){let n=t.kind==='root'?t.side*t.unitSize:t.target;for(const d of [10,5,1])while(n>=d){b.click('integerAmount',{delta:String(d)});n-=d}}
 if(t.kind==='power')for(let i=0;i<t.exponent;i++)b.click('integerMultiply');
}
function solveRatio(b,t){
 solvePrediction(b,t);
 if(t.kind==='unit')for(let i=0;i<t.groups;i++)b.click('ratioGroup',{delta:'1'});
 if(['order','whole'].includes(t.kind)){for(let i=0;i<t.red;i++)b.click('ratioAdd',{side:'red',delta:'1'});for(let i=0;i<t.blue;i++)b.click('ratioAdd',{side:'blue',delta:'1'});let choice;if(t.kind==='order')choice=t.order==='blueFirst'?`${t.blue}:${t.red}`:`${t.red}:${t.blue}`;else{const n=t.focusSide==='blue'?t.blue:t.red,gcd=(a,b)=>b?gcd(b,a%b):a,g=gcd(n,t.red+t.blue);choice=`${n/g}/${(t.red+t.blue)/g}`}b.click('ratioChoice',{value:choice})}
 if(t.kind==='scale'){const target=t.targetCopies||{red:t.copies,blue:t.copies};for(const side of ['red','blue'])for(let i=1;i<target[side];i++)b.click('ratioCopy',{side});if(t.targetCopies)b.click('ratioChoice',{value:target.red===target.blue?'same':'changed'})}
 if(t.kind==='partition'){if(!t.knownUnit){for(let i=0;i<t.unitRed;i++)b.click('ratioPer',{side:'red',delta:'1'});for(let i=0;i<t.unitBlue;i++)b.click('ratioPer',{side:'blue',delta:'1'})}for(let i=0;i<t.copies;i++)b.click('ratioBag')}
}
function solveRate(b,t){
 solvePrediction(b,t);
 const fill=(side,units,per)=>{for(let n=0;n<per;n++)for(let i=0;i<units;i++)b.click('rateMove',{side,index:String(i)})};
 if(['divide','compose'].includes(t.kind))fill('main',t.units,t.per);
 if(t.kind==='compare'){fill('a',t.a.units,t.a.per);fill('b',t.b.units,t.b.per);b.click('rateChoice',{value:t.a.per<t.b.per?'a':t.a.per>t.b.per?'b':'equal'})}
 if(t.kind==='convert')for(let i=0;i<t.count;i++)b.click('rateCard',{delta:'1'});
}
function solveJourney(b,t){
 solvePrediction(b,t);
 if(t.kind==='joint'){for(let i=0;i<t.count;i++)for(const side of ['b','a'])if(i>=(t.starts?.[side]||0))b.click('journeyWorker',{side})}
 else for(let i=0;i<(['segment','remaining'].includes(t.kind)?t.segments.length:t.count);i++)b.click('journeyStep');
 if(t.kind==='remaining'&&!t.unknownWhole)b.click('journeyChoice',{value:String(t.whole-t.segments.reduce((a,c)=>a+c,0))});
 for(const [action,value] of [...(t.unknownWhole?[['journeyWhole',t.whole]]:[]),...(t.elapsedPer?[['journeyElapsed',t.count*t.elapsedPer]]:[])]){let n=value;for(const d of [10,5,1])while(n>=d){b.click(action,{delta:String(d)});n-=d}}
}
function solveScale(b,t){
 solvePrediction(b,t);
 if(t.kind==='pair'){const target=t.targetFactors||{red:t.factor,blue:t.factor};for(const side of ['red','blue'])for(let i=1;i<target[side];i++)b.click('scaleCopy',{side});if(t.targetFactors)b.click('scaleChoice',{value:target.red===target.blue?'same':'changed'})}
 if(t.kind==='length')for(let i=1;i<t.factor;i++)b.click('scaleBoth');
 if(t.kind==='area'){const target=t.axisFactors||{rows:t.factor,cols:t.factor};for(const side of ['rows','cols'])for(let i=1;i<target[side];i++)b.click('scaleAxis',{side});if(t.axisFactors)b.click('scaleChoice',{value:target.rows===target.cols?'same':'changed'})}
 if(t.kind==='map')for(let i=0;i<t.count;i++)b.click('scaleCard',{delta:'1'});
 if(t.kind==='change')solvePercent(b,t);
}
function solvePercent(b,t){
 solvePrediction(b,t);
 if(t.kind==='shade'){if(t.requireWholeSelection)b.click('percentReference',{value:'frame'});for(const index of (t.wholeIndices||Array.from({length:t.total},(_,i)=>i)).slice(0,t.target))b.click('percentCell',{index:String(index)})}
 if(t.kind==='whole'){
  if(t.knownShares)for(let i=0;i<t.knownShares;i++)for(let n=0;n<t.part;n++)b.click('percentSplit',{index:String(i)});
  for(let i=t.knownShares||0;i<t.copies;i++)b.click('percentCopy');
 }
 if(t.kind==='change'){const reverse=t.changeOrder==='removeFirst';for(let i=0;i<(reverse?t.remove:t.add);i++)b.click(reverse?'percentRemove':'percentAdd');b.click('percentPhase');for(let i=0;i<(reverse?t.add:t.remove);i++)b.click(reverse?'percentAdd':'percentRemove')}
 if(t.kind==='estimate'){
  const set=pair=>['a','b'].forEach((side,i)=>{let n=pair[i]-(side==='a'?t.a:t.b);while(n){b.click('percentAdjust',{side,delta:String(Math.sign(n))});n-=Math.sign(n)}});
  if(t.bounds){set(t.bounds.lower);b.click('percentBoundRecord');set(t.bounds.upper);b.click('percentBoundRecord')}else set([t.targetA,t.targetB]);
 }
 b.click('percentChoice',{value:t.correctChoice});
}
function solveEquation(b,t){
 solvePrediction(b,t);
 if(t.kind==='equal'){for(const side of ['left','right'])for(let i=0;i<t[side].length;i++)b.click('equationTerm',{side,index:String(i)});if(t.equalAnswer===false)b.click('equationVerdict',{value:'unequal'})}
 if(t.kind==='unknown'){b.click('equationTake');for(let i=0;i<t.total-t.known;i++)b.click('equationBag')}
 if(t.kind==='bilateral'){if(t.addBoth!==undefined){for(let i=0;i<t.addBoth;i++){b.click('equationLeftAdd');b.click('equationRightAdd')}}else for(let i=0;i<t.known;i++){b.click('equationLeftTake');b.click('equationRightTake')}for(let i=0;i<t.total-t.known;i++)b.click('equationBag')}
 if(t.kind==='inverse'){if(t.unknownInitial){for(let i=0;i<t.removedGiven;i++)b.click('equationReturn');for(let i=0;i<t.initial;i++)b.click('equationWhole',{delta:'1'})}else for(let i=0;i<t.initial-t.remain;i++)b.click('equationRemove')}
 if(t.kind==='substitute'){for(let i=0;i<t.bag;i++)b.click('equationBag');for(let i=0;i<t.known;i++)b.click('equationKnown');if(t.correctVerdict)b.click('equationVerdict',{value:t.bag+t.known===t.total?'accept':'reject'})}
}
function solveConstraint(b,t){
 solvePrediction(b,t);
 if(t.kind==='reverse'){if(!t.extraOutside)b.click('constraintDivide');for(let i=0;i<t.extra;i++)b.click('constraintPeel');if(t.extraOutside)b.click('constraintDivide')}
 if(t.kind==='verify'){for(let i=0;i<t.bag;i++)b.click('constraintFill');for(let i=0;i<t.extra;i++)b.click('constraintExtra');if(t.correctVerdict)b.click('constraintChoose',{value:t.groups*t.bag+(t.extraOutside?t.extra:t.groups*t.extra)===(t.givenTotal??t.groups*(t.bag+t.extra))?'accept':'reject'})}
 if(t.kind==='parity'){for(let i=0;i<Math.floor(t.total/t.divisor);i++)b.click('constraintPair');b.click('constraintChoose',{value:t.total%t.divisor===0?'possible':'impossible'})}
 if(t.kind==='stock'){for(let i=0;i<Math.floor(t.stock/t.per);i++)b.click('constraintPack');b.click('constraintProbe')}
 if(t.kind==='optimal'){const max=Math.floor(t.stock/t.per);for(let i=1;i<=max+1;i++)b.click('constraintTrial',{value:String(i)});b.click('constraintChoose',{value:String(max)})}
}
function solvePattern(b,t){
 solvePrediction(b,t);
 if(t.kind==='period'){b.click('patternLength',{value:String(Array.from({length:t.base.length},(_,i)=>i+1).find(n=>[...t.base,...t.base,...t.base].every((v,i)=>v===t.base[i%n])))});b.click('patternCopy')}
 if(t.kind==='arithmetic'){for(let i=0;i<Math.abs(t.step);i++)b.click('patternAdjust',{delta:String(Math.sign(t.step))});b.click('patternAppend');b.click('patternAppend')}
 if(t.kind==='geometric'){for(let i=1;i<t.factor;i++)b.click('patternAdjust',{delta:'1'});b.click('patternAppend');b.click('patternAppend')}
 if(t.kind==='explicit')for(let i=0;i<2;i++){for(const action of t.operationOrder==='addThenMultiply'?['patternAdd','patternMultiply']:['patternMultiply','patternAdd'])b.click(action);b.click('patternCommit')}
 if(t.kind==='twoPrev')for(let i=0;i<t.count;i++){b.click('patternPick',{index:String(i)});b.click('patternPick',{index:String(i+1)});b.click('patternSum')}
 if(t.kind==='grid')for(let r=t.tile?.length||1;r<t.rows;r++)for(let c=0;c<t.cols;c++){const color=t.tile?t.tile[r%t.tile.length][c%t.tile[0].length]:(r+c)%2===0?t.start:t.start==='red'?'blue':'red';b.click('patternCell',{row:String(r),col:String(c)});if(color==='blue')b.click('patternCell',{row:String(r),col:String(c)})}
}
function solveCoordinate(b,t){
 solvePrediction(b,t);
 const locate=(i,p)=>{b.click('coordActive',{index:String(i)});b.click('coordAxis',{axis:'x',value:String(p[0])});b.click('coordAxis',{axis:'y',value:String(p[1])});b.click(t.givenPoint||t.direction==='read'?'coordRecord':'coordPoint',{x:String(p[0]),y:String(p[1])})};
 if(t.kind==='machine'){
  for(let i=1;i<t.multiplier;i++)b.click('coordAdjust',{key:'multiplier',delta:'1'});
  for(let i=0;i<t.add;i++)b.click('coordAdjust',{key:'add',delta:'1'});
  if(t.reverseIndex!==undefined)for(let i=0;i<t.inputs[t.reverseIndex];i++)b.click('coordInput',{index:String(t.reverseIndex),delta:'1'});
  for(let i=0;i<t.inputs.length;i++){b.click('coordMultiply',{index:String(i)});b.click('coordAdd',{index:String(i)})}
 }
 if(t.kind==='pair')locate(0,t.target);
 if(t.kind==='order')t.targets.forEach((p,i)=>locate(i,p));
 if(t.kind==='table')t.pairs.forEach((p,i)=>locate(i,p));
 if(t.kind==='move'){for(let i=0;i<Math.abs(t.dx);i++)b.click('coordMove',{dx:String(Math.sign(t.dx)),dy:'0'});for(let i=0;i<Math.abs(t.dy);i++)b.click('coordMove',{dx:'0',dy:String(Math.sign(t.dy))})}
 if(t.kind==='dynamic'){for(let i=0;i<Math.abs(t.step);i++)b.click('coordDelta',{delta:String(Math.sign(t.step))});for(let i=0;i<t.duration;i++)b.click('coordTick')}
}
const groupingDigitFixtures={'O-N01-04-1':['30','34','37'],'T-N01-04-1':['12','42'],'T-N01-04-2':['20','25','28'],'T-N01-04-3':['40','41'],'T-N01-04-4':['23']};
function solveGrouping(b,t){
 solvePrediction(b,t);
 if(t.kind==='digitRules'){require('./test_digit_rules_solver').solveDigitRules(b,t);return}
 if(t.kind==='reconstruct'){for(let i=0;i<t.knownGroups;i++)b.click('groupUnwrap',{index:String(i)});for(let n=0;n<t.knownGroups*t.divisor+t.remainder;n++)b.click('groupWhole',{delta:'1'});return}
 if(t.kind==='digits')for(const value of t.pools[0].flatMap(a=>t.pools[1].filter(c=>a!==0&&(t.rule.tens===undefined||a===t.rule.tens)&&(t.rule.ones===undefined||c===t.rule.ones)&&(!t.rule.different||a!==c)).map(c=>String(a)+String(c)))){b.click('groupDigit',{place:'tens',value:value[0]});b.click('groupDigit',{place:'ones',value:value[1]});b.click('groupRecord')}
 else{
  const totals=t.kind==='digitSum'?t.numbers.map(n=>String(n).split('').reduce((sum,v)=>sum+Number(v),0)):t.totals||[t.total];
  totals.forEach((total,i)=>{
   if(t.kind==='digitSum')for(let j=0;j<String(t.numbers[i]).length;j++)b.click('groupSumDigit',{card:String(i),index:String(j)});
   for(let start=0;start+t.divisor<=total;start+=t.divisor){for(let j=0;j<t.divisor;j++)b.click('groupPick',{card:String(i),index:String(start+j)});b.click('groupWrap',{card:String(i)})}
   b.click('groupProbe',{card:String(i)});const rem=total%t.divisor,value=t.kind==='remainder'?String(rem):t.kind==='parity'?rem===0?'even':'odd':rem===0?'complete':'remain';b.click('groupChoice',{card:String(i),value});
  });
 }
}
const factorFixtures={1:[[1,1]],2:[[1,2]],3:[[1,3]],4:[[1,4],[2,2]],5:[[1,5]],7:[[1,7]],8:[[1,8],[2,4]],9:[[1,9],[3,3]],10:[[1,10],[2,5]],11:[[1,11]],12:[[1,12],[2,6],[3,4]],15:[[1,15],[3,5]],16:[[1,16],[2,8],[4,4]],18:[[1,18],[2,9],[3,6]],20:[[1,20],[2,10],[4,5]],24:[[1,24],[2,12],[3,8],[4,6]],25:[[1,25],[5,5]],30:[[1,30],[2,15],[3,10],[5,6]],36:[[1,36],[2,18],[3,12],[4,9],[6,6]]};
function solveFactor(b,t){
 t.numbers.forEach((n,i)=>{
  b.click('factorActive',{index:String(i)});const allPairs=Array.from({length:Math.floor(Math.sqrt(n))},(_,i)=>i+1).filter(d=>n%d===0).map(d=>[d,n/d]),pairs=t.kind==='pairs'?allPairs.filter(p=>p[0]>=(t.minimumSide||1)).slice(0,t.requiredPairs):allPairs;
  for(const p of pairs){b.click('factorPalette');b.click('factorWidth',{value:String(p[1])});b.click('factorFill');b.click('factorRecord');if(t.kind!=='pairs')for(const v of p)b.click('factorCollect',{value:String(v)});b.click('factorClear')}
  const count=new Set(pairs.flat()).size;
  if(['unit','square','count'].includes(t.kind))for(let j=0;j<count;j++)b.click('factorCount',{delta:'1'});
  if(t.classifySquare)b.click('factorChoice',{value:Number.isInteger(Math.sqrt(n))?'square':'nonsquare'});
  if(['prime','unit'].includes(t.kind))b.click('factorChoice',{value:n===1?'neither':count===2?'prime':'composite'});
 });
}
const commonTimeFixtures={'4,6':12,'3,5':15,'2,3':6,'3,4':12,'2,5':10,'4,8':8};
const commonDivisorFixtures={'12,18':[1,2,3,6],'8,12':[1,2,4],'9,12':[1,3],'10,15':[1,5],'6,9':[1,3]};
const commonCutFixtures={'12,18':6,'8,12':4,'9,12':3,'10,15':5,'6,9':3,'4,6':2,'6,8':2,'4,10':2};
function solveCommon(b,t){
 const timing=params=>{const all=t.kind==='multiples',lists=params.periods.map((p,i)=>Array.from({length:Math.floor((params.horizon-(params.starts?.[i]??0))/p)+1},(_,j)=>(params.starts?.[i]??0)+j*p)),overlap=lists[0].filter(x=>x>0&&x>(params.after??0)&&lists[1].includes(x)),chosen=all?overlap:overlap.slice(0,1),end=all?params.horizon:chosen[0];if(!chosen.length)throw Error('No timing overlap');lists.forEach((list,i)=>{for(const x of list.slice(1))if(x<=end)b.click('commonTick',{index:String(i)})});chosen.forEach(time=>b.click('commonTime',{value:String(time)}))};
 const cutting=params=>{const best=Array.from({length:Math.min(...params.dims)},(_,i)=>i+1).filter(n=>params.dims.every(v=>v%n===0)).at(-1);b.click('commonCutSize',{value:String(best)});b.click('commonTile');b.click('commonBest');if(params.unitSize)for(let n=0;n<best*params.unitSize;n++)b.click('commonCutAmount',{delta:'1'});for(let size=best+1;size<=Math.min(...params.dims);size++){b.click('commonCutSize',{value:String(size)});b.click('commonTile')}};
 if(['multiples','least'].includes(t.kind))timing(t);
 if(t.kind==='divisors')for(const size of Array.from({length:Math.min(...t.numbers)},(_,i)=>i+1).filter(n=>t.numbers.every(v=>v%n===0))){b.click('commonGroupSize',{value:String(size)});b.click('commonSplit');b.click('commonCollect')}
 if(t.kind==='greatest')cutting(t);
 if(t.kind==='contexts'){timing(t.bells);b.click('commonSection',{index:'1'});cutting(t.paper);b.click('commonGoal',{index:'0',value:'least'});b.click('commonGoal',{index:'1',value:'greatest'})}
}
function solveCycle(b,t){
 solvePrediction(b,t);
 if(t.mode==='groupingLab'){solveGrouping(b,t);return}
 if(t.mode==='patternLab'){solvePattern(b,t);return}
 if(t.kind==='power'&&t.target===0){b.click('cycleZeroConfirm');b.click('cycleZeroChoice',{value:'1'});return}
 let length=t.base?.length;
 if(t.kind==='power'){for(let i=0;i<t.period+1;i++){b.click('cycleMultiply');b.click('cycleUnits');b.click('cycleCommit')}b.click('cyclePeriod',{value:String(t.period)});b.click('cycleMake');length=t.period}
 for(let i=0;i<Math.floor(t.target/length);i++)b.click('cycleRound');for(let i=0;i<t.target%length;i++)b.click('cycleAdvance');
 b.click('cycleChoice',{value:String(t.kind==='weekday'?((t.start+(t.direction||1)*t.target)%length+length)%length:t.indexBase===0?t.target%length:(t.target-1)%length+1)});
}
const measureRearrangeFixtures={'O-G01-05-1':[[0,0],[0,1],[0,2],[0,3],[1,0],[1,1],[1,2],[1,3],[2,0],[2,1],[3,0],[3,1]],'T-G01-05-1':[[0,0],[0,1],[0,2],[0,3],[1,0],[1,1],[1,2],[1,3]],'T-G01-05-2':[[0,0],[0,1],[0,2],[0,3],[1,0],[1,1]],'T-G01-05-3':[[0,0],[0,1],[0,2],[1,0],[2,0],[3,0],[3,1],[3,2]],'T-G01-05-4':[[0,0],[0,1],[0,2],[0,3],[1,0],[1,1],[1,2],[1,3],[2,2],[2,3],[3,2],[3,3]]};
function measureOuterOracle(cells){const set=new Set(cells.map(p=>p.join(','))),edges=[];for(const [r,c] of cells){if(!set.has((r-1)+','+c))edges.push('h,'+r+','+c);if(!set.has((r+1)+','+c))edges.push('h,'+(r+1)+','+c);if(!set.has(r+','+(c-1)))edges.push('v,'+r+','+c);if(!set.has(r+','+(c+1)))edges.push('v,'+r+','+(c+1))}return edges}
function rearrangedCells(t){
 const referencePerimeter=measureOuterOracle(t.reference).length;let found=null;
 function rows(lengths,left){if(found)return;if(left===0){const cells=lengths.flatMap((n,r)=>Array.from({length:n},(_,c)=>[r,c]));const per=measureOuterOracle(cells).length;if(t.goal==='samePerimeterDifferentArea'?per===referencePerimeter:per!==referencePerimeter)found=cells;return}if(lengths.length>=t.rows)return;for(let n=1;n<=Math.min(t.cols,left,lengths.at(-1)||t.cols);n++)rows([...lengths,n],left-n)}
 rows([],t.total);if(!found)throw Error('No independently searched connected hole-free arrangement '+t.id);return found;
}
function solveMeasure(b,t){
 solvePrediction(b,t);const formal=['测','巩固'].includes(t.phase);
 const cells=t.kind==='length'?[]:t.kind==='rearrange'?rearrangedCells(t):t.cells;
 if(t.kind==='length')for(let i=t.start;i<t.end;i++)b.click('measureSegment',{index:String(i)});
 if(['area','units','rearrange'].includes(t.kind))for(const [r,c] of cells)b.click('measureCell',{row:String(r),col:String(c)});
 if(t.kind==='rearrange')b.click('measureTrace');
 if(['perimeter','units','rearrange'].includes(t.kind))for(const edge of measureOuterOracle(cells))b.click('measureEdge',{value:edge});
 if(t.kind==='units'){b.click('measureUnit',{key:'lengthUnit',value:t.unit});b.click('measureUnit',{key:'areaUnit',value:t.unit+'2'})}
 if(!formal||t.kind==='rearrange'){const values={length:t.kind==='length'?(t.end-t.start)*t.unitSize:measureOuterOracle(cells).length*t.unitSize,area:cells.length*t.unitSize**2};const keys=t.kind==='length'||t.kind==='perimeter'?['length']:t.kind==='area'?['area']:['length','area'];for(const key of keys){let n=values[key];if(n===0)b.click('measureAmount',{key,delta:'0'});for(const d of [10,5,1])while(n>=d){b.click('measureAmount',{key,delta:String(d)});n-=d}}}
}
function solveAngle(b,t){
 solvePrediction(b,t);
 if(t.kind==='arms'){for(let a=0;a<t.target;a+=15)b.click('angleRotate',{delta:'15'});b.click('angleArm',{value:'AB'});b.click('angleArm',{value:'AC'});if(t.mustResize)b.click('angleResize')}
 if(t.kind==='turn')t.targets.forEach((angle,i)=>{for(let a=0;a<angle;a+=30)b.click('angleTurn',{index:String(i)})});
 if(['triangle','conditions'].includes(t.kind)){if(t.kind==='conditions')for(let i=0;i<3;i++)if(i!==t.unknown)b.click('angleCondition',{value:String(i)});for(let i=0;i<3;i++)b.click('anglePiece',{index:String(i)});if(!['测','巩固'].includes(t.phase))for(let a=0;a<t.angles[t.unknown];a+=5)b.click('angleAnswer',{delta:'5'})}
 if(t.kind==='polygon'){for(let i=0;i<t.sides;i++)if(i!==t.anchor&&i!==(t.anchor+1)%t.sides&&i!==(t.anchor+t.sides-1)%t.sides){b.click('angleVertex',{index:String(t.anchor)});b.click('angleVertex',{index:String(i)});b.click('angleConnect')}for(let i=0;i<t.sides-2;i++){b.click('angleTriangles',{delta:'1'});b.click('angleTotal',{delta:'180'})}}
}
const compositePlacements={'O-G03-01-1':[[2,0]],'T-G03-01-1':[[2,0],[0,1]],'T-G03-01-2':[[2,0]],'T-G03-01-3':[[0,1]],'T-G03-01-4':[[1,0]]};
function unionPlacement(p){
 const fixed=new Set(p.fixed.map(p=>p.join(',')));
 for(let r=0;r<p.rows;r++)for(let c=0;c<p.cols;c++){
  const piece=p.piece.map(([y,x])=>[r+y,c+x]);if(piece.some(([y,x])=>y<0||x<0||y>=p.rows||x>=p.cols||fixed.has(`${y},${x}`))||(r===p.start[0]&&c===p.start[1]))continue;
  const cells=[...p.fixed,...piece],set=new Set(cells.map(p=>p.join(','))),seen=new Set([cells[0].join(',')]),queue=[cells[0]];
  while(queue.length){const [y,x]=queue.shift();for(const [dy,dx] of [[1,0],[-1,0],[0,1],[0,-1]]){const key=`${y+dy},${x+dx}`;if(set.has(key)&&!seen.has(key)){seen.add(key);queue.push([y+dy,x+dx])}}}
  if(!p.allowSeparated&&seen.size!==cells.length)continue;
  if(p.target&&(p.target.length!==cells.length||p.target.some(q=>!set.has(q.join(',')))))continue;
  if(p.requirePerimeterChange&&measureOuterOracle(cells).length===measureOuterOracle([...p.fixed,...p.piece.map(([y,x])=>[y+p.start[0],x+p.start[1]])]).length)continue;
  return [r,c];
 }throw Error('No searched union placement '+JSON.stringify(p));
}
function solveComposite(b,t){
 const answer=(value,index)=>{for(let n=0;n<value;n++)b.click('compositeAnswer',{...(index===undefined?{}:{index:String(index)}),delta:'1'})};
 if(['union','move'].includes(t.kind)){
  (t.puzzles||[t]).forEach((p,i)=>{const [r,c]=t.kind==='union'?unionPlacement(p):p.destination;for(let row=p.start[0];row!==r;row+=Math.sign(r-p.start[0]))b.click('compositeMove',{index:String(i),dr:String(Math.sign(r-p.start[0])),dc:'0'});for(let col=p.start[1];col!==c;col+=Math.sign(c-p.start[1]))b.click('compositeMove',{index:String(i),dr:'0',dc:String(Math.sign(c-p.start[1]))});answer(p.fixed.length+p.piece.length,i)});
  if(t.kind==='move')b.click('compositeInvariant',{value:'area'});
 }
 if(t.kind==='cut'){for(const [r,c] of t.remove)b.click('compositeCut',{row:String(r),col:String(c)});answer(t.rows*t.cols-t.remove.length)}
 if(t.kind==='squares'){for(const size of t.sizes){b.click('compositeSize',{value:String(size)});for(let r=0;r<=t.rows-size;r++)for(let c=0;c<=t.cols-size;c++){b.click('compositePreview',{row:String(r),col:String(c)});b.click('compositeRecord')}}answer(t.sizes.reduce((n,size)=>n+(t.rows-size+1)*(t.cols-size+1),0))}
}
function solveCircle(b,t){
 const amount=(value,group,key,index)=>{for(let n=0;n<Math.floor(value);n++)b.click('circleAmount',{group,key,...(index===undefined?{}:{index:String(index)}),delta:'1'});for(let n=Math.floor(value);n<value;n+=.25)b.click('circleAmount',{group,key,...(index===undefined?{}:{index:String(index)}),delta:'0.25'})};
 const unit=(value,group,index)=>b.click('circleUnit',{group,value,...(index===undefined?{}:{index:String(index)})});
 if(t.kind==='center'){b.click('circleOrigin',{value:t.centerName||'O'});for(let i=0;i<t.points.length;i++)b.click('circleRay',{index:String(i)})}
 if(t.kind==='radii'){for(const end of ['A','B']){b.click('circleVertex',{value:'O'});b.click('circleVertex',{value:end});b.click('circleConnect')}b.click('circleJoin');amount(t.answerTarget==='radius'?t.radius:t.radius*2,'main','answer');unit('cm','main')}
 if(t.kind==='walk')(t.routes||[t]).forEach((r,i)=>{for(let n=0;n<r.targetSteps;n++)b.click('circleWalk',{index:String(i)});if(r.includeDiameter)b.click('circleDiameter',{index:String(i)});amount(2*r.radius*r.targetSteps/r.parts,'routes','coeff',i);if(r.includeDiameter)amount(2*r.radius,'routes','constant',i);unit('cm','routes',i)});
 if(t.kind==='area'){t.radii.forEach((r,i)=>{for(let part=0;part<t.parts;part++)b.click('circlePiece',{index:String(i),part:String(part)});amount(r*r,'areas','coeff',i);unit('cm2','areas',i)});if(t.compare)for(let n=0;n<t.radii[1]**2/t.radii[0]**2;n++)b.click('circleRatio',{delta:'1'})}
 if(t.kind==='arc'){for(let i=0;i<t.count;i++)b.click('circleArc',{group:'main',index:'0',part:String((t.start+i)%t.parts)});for(let n=0;n<t.count;n++)b.click('circleFraction',{key:'numerator',delta:'1'});for(let n=1;n<t.parts;n++)b.click('circleFraction',{key:'denominator',delta:'1'});amount(t.totalCirc*t.count/t.parts,'main','answer');unit('cm','main')}
 if(t.kind==='objects'){for(let i=0;i<t.count;i++){const part=String((t.start+i)%t.parts);b.click('circleArc',{group:'objects',index:'0',part});b.click('circleSector',{index:'1',part})}amount(2*t.radius*t.count/t.parts,'objects','coeff',0);unit('cm','objects',0);amount(t.radius**2*t.count/t.parts,'objects','coeff',1);unit('cm2','objects',1)}
}
function solveSimilar(b,t){
 const answer=value=>{for(let n=0;n<Math.floor(value);n++)b.click('similarAnswer',{delta:'1'});for(let n=Math.floor(value);n<value;n+=.25)b.click('similarAnswer',{delta:'0.25'})};
 if(t.kind==='correspond'){
  for(let i=0;i<t.points.length;i++){for(const side of ['source','target'])b.click('similarPoint',{side,index:String(i)});b.click('similarLink')}
  for(const side of ['source','target'])for(const [kind,index] of [['Edge',t.edgeIndex],['Angle',t.angleIndex]])b.click('similarMark',{side,kind,index:String(index)});
  return;
 }
 const x=t.kind==='inverse'?t.newWidth/t.width:t.goalX,y=t.kind==='inverse'?x:t.goalY;
 for(const [axis,target] of (x===y?[['both',x]]:[['x',x],['y',y]]))for(let k=1;k!==target;k+=.5*Math.sign(target-1))b.click('similarScale',{axis,delta:String(.5*Math.sign(target-1))});
 if(t.kind==='resize')b.click('similarChoice',{value:x===y?'similar':'different'});
 if(t.kind==='perimeter'){for(const [side,count] of [['source',2*(t.width+t.height)],['target',2*(t.width*x+t.height*y)]])for(let i=0;i<count;i++)b.click('similarTrace',{side});answer(x)}
 if(t.kind==='area'){for(const [side,width,height] of [['source',t.width,t.height],['target',t.width*x,t.height*y]])for(let r=0;r<height;r++)for(let c=0;c<width;c++)if(side==='source'||!(t.remove||[]).some(p=>p[0]===r&&p[1]===c))b.click('similarCell',{side,row:String(r),col:String(c)});answer((t.width*x*t.height*y-(t.remove||[]).length)/(t.width*t.height))}
 if(t.kind==='inverse')answer(x);
}
function solveRight(b,t,cornerChoice){
 const amount=(key,value)=>{for(let n=0;n<Math.floor(value);n++)b.click('rightAmount',{key,delta:'1'});for(let n=Math.floor(value);n<value;n+=.25)b.click('rightAmount',{key,delta:'0.25'})};
 if(t.kind==='condition'){
  t.cards.forEach((card,i)=>{b.click('rightPick',{card:String(i),index:String(card.corner)});for(const index of [card.corner,(card.corner+2)%3])b.click('rightEdge',{card:String(i),index:String(index)});b.click('rightChoice',{card:String(i),value:card.givenAngle===90?'yes':'no'})});return;
 }
 if(['squares','solve'].includes(t.kind)){b.click('rightPick',{card:'0',index:'0'});for(const index of [0,2])b.click('rightEdge',{card:'0',index:String(index)})}
 if(['axis','diagonal'].includes(t.kind))for(const role of ['A','B']){b.click('rightActive',{value:role});b.click('rightPoint',{x:String(t[role][0]),y:String(t[role][1])})}
 if(t.kind==='axis'){const dx=Math.sign(t.B[0]-t.A[0]),dy=Math.sign(t.B[1]-t.A[1]),n=Math.abs(t.B[0]-t.A[0])+Math.abs(t.B[1]-t.A[1]);for(let i=0;i<n;i++)b.click('rightStep',{dx:String(dx),dy:String(dy)});amount('answer',n);return}
 if(t.kind==='diagonal'){const C=cornerChoice||[t.B[0],t.A[1]];b.click('rightActive',{value:'C'});b.click('rightPoint',{x:String(C[0]),y:String(C[1])});b.click('rightJoin');for(const [index,p,q] of [[0,t.A,C],[1,C,t.B]])for(let n=0;n<Math.abs(p[0]-q[0])+Math.abs(p[1]-q[1]);n++)b.click('rightMeasure',{index:String(index)})}
 const unknown=t.kind==='squares'?'c':t.unknown,target=t[unknown]/t.unit;
 if(t.kind!=='squares')for(let n=1;n<target;n++)b.click('rightSize',{delta:'1'});
 const material=(t.unknown&&t.unknown!=='c'?['c']:['a','b']).flatMap(key=>{const n=t[key]/t.unit;return Array.from({length:n},(_,r)=>Array.from({length:n},(_,c)=>`${key}-${r}-${c}`)).flat()}),deduct=t.unknown&&t.unknown!=='c'?t[t.unknown==='a'?'b':'a']/t.unit:0;
 let at=0;for(const [zone,n] of [['deduct',deduct],['target',target]])for(let r=0;r<n;r++)for(let c=0;c<n;c++){b.click('rightTile',{id:material[at++]});b.click('rightSlot',{zone,row:String(r),col:String(c)})}
 if(t.kind==='squares')for(const key of ['a','b','c'])amount(key,t[key]**2);else amount('answer',t[unknown]);
}
function solveSolid(b,t){
 const geom=require('./solid_geometry'),views=()=>{for(let i=0;i<8;i++)b.click('solidTurn',{delta:'1'});b.click('solidFlip');for(let i=0;i<8;i++)b.click('solidTurn',{delta:'1'})},amount=(index,value)=>{for(let n=0;n<Math.floor(value);n++)b.click('solidAmount',{index:String(index),delta:'1'});for(let n=Math.floor(value);n<value;n+=.125)b.click('solidAmount',{index:String(index),delta:'0.125'})};
 if(t.nets){
  t.nets.forEach((net,index)=>{for(const node of geom.solidNetTree(net).nodes.slice(1))for(let k=0;k<3;k++)b.click('solidFold',{index:String(index),id:node.id,delta:'30'})});views();
  t.nets.forEach((net,index)=>{const a=geom.solidAnalysis(net,geom.solidFullAngles(net)),data={index:String(index)};
   if(t.kind==='valid')b.click('solidValidity',{...data,value:a.valid?'valid':'invalid'});
   if(t.kind==='counts'){for(const id of Object.keys(a.frames))b.click('solidFace',{...data,side:'solid',id});for(const key of ['edges','vertices'])for(const id of Object.keys(a[key]))b.click('solidObject',{...data,key,id});for(const [key,count] of [['faces',6],['edges',12],['vertices',8]])for(let n=0;n<count;n++)b.click('solidCount',{...data,key,delta:'1'})}
   if(t.kind==='match')for(const id of Object.keys(a.frames)){b.click('solidFace',{...data,side:'net',id});b.click('solidFace',{...data,side:'solid',id})}
   if(t.kind==='opposite')for(const id of t.asked){b.click('solidFace',{...data,side:'solid',id});b.click('solidFace',{...data,side:'solid',id:Object.keys(a.frames).find(other=>geom.solidDot(a.frames[id].n,a.frames[other].n)<-.999)})}
  });return;
 }
 t.solids.forEach((model,index)=>{for(const z of [...new Set(model.cells.map(p=>p[2]))]){b.click('solidSlice',{index:String(index),value:String(z)});for(const [x,y,k] of model.cells.filter(p=>p[2]===z))b.click('solidCell',{index:String(index),x:String(x),y:String(y),z:String(k)})}});views();
 t.solids.forEach((model,index)=>{const faces=geom.solidSurface(model.cells);if(t.kind==='surface'){b.click('solidMode',{index:String(index),value:'inspect'});for(const cell of model.cells){const id=cell.join(',');b.click('solidInspect',{index:String(index),id});for(const face of faces.filter(f=>f.cell.join(',')===id))b.click('solidSurface',{index:String(index),side:face.side})}}amount(index,t.kind==='volume'?model.cells.length*t.unit**3:faces.length*t.unit**2);b.click('solidUnit',{index:String(index),value:t.kind==='volume'?'volume':'area'})});
 if(t.compare){const values=t.solids.map(model=>t.kind==='volume'?model.cells.length:geom.solidSurface(model.cells).length);b.click('solidCompare',{value:values.every(v=>v===values[0])?'equal':'different'})}
}
function solveSets(b,t){
 const belongs=(p,key)=>key==='U'||key===p.group||key==='A'&&['R','O'].includes(p.group)||key==='B'&&['Y','O'].includes(p.group)||key==='I'&&p.group!=='N'||key==='exact1'&&['R','Y'].includes(p.group)||key==='notA'&&['Y','N'].includes(p.group)||key==='notB'&&['R','N'].includes(p.group),amount=(key,value,row)=>{for(let n=0;n<value;n++)b.click('setsAmount',{key,...(row===undefined?{}:{row:String(row)}),delta:'1'})},apply=(row,key,sign=1)=>b.click('setsApply',{row:String(row),key,sign:String(sign)});
 for(const p of t.people)for(const flag of (p.group==='N'?['N']:p.group==='O'?['A','B']:p.group==='R'?['A']:['B']))b.click('setsRegister',{id:p.id,flag});
 for(const p of t.people){b.click('setsActor',{id:p.id});b.click('setsPlace',{zone:p.group})}
 for(const key of t.queries||[]){b.click('setsQuery',{key});const members=t.people.filter(p=>belongs(p,key));if(members.length)for(const p of members)b.click('setsActor',{id:p.id});else b.click('setsEmpty')}
 const target=t.target||'U',expected=t.people.filter(p=>belongs(p,target)).length;
 if(['identity','universe','partition'].includes(t.kind))amount('answer',expected);
 if(t.kind==='partition')for(const key of t.countKeys)amount(key,t.people.filter(p=>p.group===key).length);
 if(t.kind==='formula'){for(const key of ['R','O','Y'])apply(0,key);for(const key of ['A','Y'])apply(1,key);for(const row of [0,1])amount('answer',expected,row)}
 if(t.kind==='complement'){apply(0,'U');if(target==='notA')apply(0,'A',-1);else if(target==='notB')apply(0,'B',-1);else{apply(0,'O');apply(0,'A',-1);apply(0,'B',-1)}amount('answer',expected,0)}
 if(t.kind==='twoWays'){if(target==='I'){apply(0,'A');apply(0,'B');apply(0,'O',-1);apply(1,'U');apply(1,'N',-1)}else if(target==='N'){apply(0,'N');apply(1,'U');apply(1,'O');apply(1,'A',-1);apply(1,'B',-1)}else{for(const key of [target==='notA'?'Y':'R','N'])apply(0,key);apply(1,'U');apply(1,target==='notA'?'A':'B',-1)}for(const row of [0,1])amount('answer',expected,row)}
 if(t.kind==='dedup'){for(const key of ['A','B'])b.click('setsAddList',{key});for(const p of t.people.filter(p=>p.group==='O'))b.click('setsTrim',{id:p.id});amount('answer',expected)}
}
function solveCombin(b,t){const {combinAll,combinRule}=require('./combin_ui');t.models.forEach((m,index)=>{const data={index:String(index)};for(let i=0;i<(m.seed||[]).length;i++)b.click('combinDelete',{...data,id:'R'+(i+1)});for(const tuple of combinAll(m)){b.click('combinBin',{...data,id:tuple[0]});tuple.forEach((id,slot)=>{b.click('combinSlot',{...data,slot:String(slot)});b.click('combinCard',{...data,id,...(m.type==='pair'?{list:String(slot)}:{})})});b.click('combinRecord',data)}for(let n=0;n<combinAll(m).length;n++)b.click('combinAmount',{...data,delta:'1'});if(t.kind==='orderMeaning')b.click('combinOrder',{...data,value:m.ordered?'yes':'no'})});if(t.kind==='rule')b.click('combinRule',{value:combinRule(t)})}

function solveChart(b,t){const {chartIntervals,chartQualifies,chartDuration}=require('./chart_ui');const amount=(index,n)=>{if(n===0)b.click('chartAmount',{index:String(index),delta:'0'});for(const d of [100,10,5,1])while(n>=d){b.click('chartAmount',{index:String(index),delta:String(d)});n-=d}};if(t.kind==='legend')for(let r=0;r<t.icons.length;r++)for(let i=0;i<Math.ceil(t.icons[r]);i++){const id=r+':'+i;b.click('chartIcon',{id});for(let k=0;k<t.legend*Math.min(1,t.icons[r]-i);k++){b.click('chartDot',{id:id+':'+k});b.click('chartPlace',{row:String(r)})}}if(t.kind==='ticks')for(let i=1;i<t.ticks.length-1;i++){b.click('chartTick',{index:String(i)});b.click('chartScale',{value:String(t.ticks[i])})}else if(t.kind==='interval'){const ids=chartIntervals(t).filter(p=>chartQualifies(t,p)).map(p=>p.id);if(ids.length)for(const id of ids)b.click('chartInterval',{id});else b.click('chartEmpty');let n=chartDuration(t,ids);while(n>=1){b.click('chartTime',{delta:'1'});n--}if(n)b.click('chartTime',{delta:'0.5'})}else if(t.kind==='legend'){t.values.forEach((v,i)=>amount(i,v))}else{t.values.forEach((v,i)=>{b.click('chartCategory',{index:String(i)});if(t.kind==='read'||t.kind==='convert'&&t.direction==='read')b.click('chartMark',{index:String((v-t.ticks[0])/t.gap)});if(t.kind==='build'||t.kind==='convert'&&t.direction==='build'){for(let k=0;k<(v-t.ticks[0])/t.gap;k++)b.click('chartBlock',{delta:'1'});if(v===t.ticks[0])b.click('chartZero')}amount(i,v)})}if(t.kind!=='ticks')b.click('chartUnit',{value:t.unit})}

function solveStats(b,t){const {statsObservations,statsSummary,statsUnits}=require('./stats_ui'),obs=statsObservations(t),sum=statsSummary(t),amount=(key,n)=>{for(const d of [10,5,1,0.5])while(n>=d){b.click('statsAmount',{key,delta:String(d)});n-=d}};if(['balance','mean','weighted'].includes(t.kind)){if(t.kind==='weighted')t.rows.forEach((r,row)=>b.click('statsExpand',{row:String(row)}));const units=obs.flatMap(p=>statsUnits(t,p)),per=sum.mean/t.quantum;units.forEach((id,i)=>{b.click('statsDot',{id});b.click('statsPlace',{row:String(Math.floor(i/per))})});amount('total',sum.total);amount('denominator',sum.n);amount('answer',sum.mean)}else if(t.kind==='modeRange'){for(const p of obs){b.click('statsCard',{id:p.id});b.click('statsGroup',{value:String(p.value)})}for(const value of sum.modes)b.click('statsModeValue',{value:String(value)});if(!sum.modes.length)b.click('statsNoMode');for(const value of sum.ends)b.click('statsEnd',{value:String(value)});amount('range',sum.range)}else{const sorted=[...obs].sort((a,c)=>t.direction==='desc'?c.value-a.value:a.value-c.value);sorted.forEach((p,slot)=>{b.click('statsCard',{id:p.id});b.click('statsSlot',{slot:String(slot)})});if(t.kind==='median'){b.click('statsWorkMode',{value:'middle'});for(const p of sum.n%2?[sorted[(sum.n-1)/2]]:[sorted[sum.n/2-1],sorted[sum.n/2]])b.click('statsCard',{id:p.id});amount('answer',sum.median)}}}

function solveChance(b,t){const {chanceOutcomes,chanceFavorable,chanceCertainty,chanceLabelEqual,chanceCompare}=require('./chance_ui');t.models.forEach((m,index)=>{const data={index:String(index)},all=chanceOutcomes(m);all.forEach((tuple,i)=>{tuple.forEach((id,slot)=>b.click('chanceAtom',{...data,slot:String(slot),id}));b.click('chanceRecord',data);if(['certainty','favorable','two','weighted'].includes(t.kind)&&chanceFavorable(m,tuple))b.click('chanceFavor',{...data,id:'R'+(i+1)})});const favorable=all.filter(p=>chanceFavorable(m,p)).length;if(['certainty','favorable','two','weighted'].includes(t.kind)&&!favorable)b.click('chanceEmpty',data);if(['favorable','two','weighted'].includes(t.kind))for(const [key,n] of [['numerator',favorable],['denominator',all.length]])for(let k=0;k<n;k++)b.click('chanceAmount',{...data,key,delta:'1'});if(t.kind==='certainty')b.click('chanceChoice',{...data,key:'certainty',value:chanceCertainty(m)});if(t.kind==='equal'){b.click('chanceChoice',{...data,key:'basic',value:'yes'});b.click('chanceChoice',{...data,key:'labels',value:chanceLabelEqual(m)?'yes':'no'})}if(t.kind==='weighted')b.click('chanceChoice',{...data,key:'compare',value:chanceCompare(m)})})}

function solveMotion(b,t){const {motionFinal,motionPaperExpected,motionArea}=require('./motion_ui');if(t.kind==='fold'){for(const id of motionPaperExpected(t))b.click('motionHole',{id});b.click('motionLock');for(const f of t.folds)b.click('motionFold',{axis:f.axis,from:f.from});for(const [x,y] of t.cuts)b.click('motionCut',{x:String(x),y:String(y)});for(const f of t.folds)b.click('motionUnfold');return}for(const p of motionFinal(t)){b.click('motionSelect',{id:p.id});b.click('motionPlace',{x:String(p.x),y:String(p.y)})}b.click('motionLock');let axisValue=0,dx=0,dy=0;for(const step of t.steps){if(step.type==='reflect'){b.click('motionAxis',{value:step.axis});while(axisValue!==step.value){const delta=Math.sign(step.value-axisValue);b.click('motionAdjust',{key:'axisValue',delta:String(delta)});axisValue+=delta}}else if(step.type==='rotate'){b.click('motionGridMode',{value:'centre'});b.click('motionPlace',{x:String(step.cx),y:String(step.cy)});b.click('motionDirection',{value:step.direction});b.click('motionAngle',{value:String(step.angle)})}else{for(const [key,target] of [['dx',step.dx],['dy',step.dy]]){let value=key==='dx'?dx:dy;while(value!==target){const delta=Math.sign(target-value);b.click('motionAdjust',{key,delta:String(delta)});value+=delta}if(key==='dx')dx=value;else dy=value}}b.click('motionApply',{type:step.type})}if(t.kind!=='axis')b.click('motionOrientation',{value:motionArea(t.points)*motionArea(motionFinal(t))>0?'same':'changed'})}

function solveInvariant(b,t){const lib=require('./invariant_ui');if(t.kind==='filter'){for(const tuple of lib.invariantAll(t.items)){tuple.forEach((id,slot)=>{b.click('invariantCard',{id});b.click('invariantSlot',{slot:String(slot)})});const failed=t.conditions.filter(c=>!lib.invariantCondition(c,tuple)).map(c=>c.id);b.click('invariantClass',{value:failed.length?'reject':'keep'});for(const id of failed)b.click('invariantFailed',{id});b.click('invariantRecord')}return}let state=lib.invariantInitial(t),states=[state];const run=ids=>{for(const id of ids)b.click('invariantCoin',{id});b.click('invariantRun');state=lib.invariantStep(t.rule,state,ids);states.push(state)};if(t.kind==='legal'){for(const ids of t.attempts){for(const id of ids)b.click('invariantCoin',{id});b.click('invariantPredictLegal',{value:lib.invariantLegal(t.rule,state,ids)?'legal':'illegal'});b.click('invariantRun');state=lib.invariantStep(t.rule,state,ids)}return}let reachable=false;if(t.kind==='proof'){const node=lib.invariantReachable(t).get(t.goal.join(','));reachable=!!node;if(reachable)for(const ids of node.path)run(ids)}if(t.kind!=='proof'||!reachable)for(let i=0;i<t.minOps;i++)run(lib.invariantChoices(t.rule,state)[0]);if(t.kind==='parity'){for(const [side,s] of [['initial',states[0]],['current',state]]){b.click('invariantPairSide',{value:side});const red=lib.invariantRed(s);for(let i=0;i+1<red.length;i+=2){for(const id of red.slice(i,i+2))b.click('invariantPairCoin',{id});b.click('invariantBindPair')}if(red.length%2){b.click('invariantPairCoin',{id:red.at(-1)});b.click('invariantSingle')}else b.click('invariantNoSingle');b.click('invariantParity',{value:red.length%2?'odd':'even'})}return}for(const [row,s] of states.entries()){for(const [key,n] of [['total',s.order.length],['red',lib.invariantRed(s).length]])for(let i=0;i<n;i++)b.click('invariantLedger',{row:String(row),key,delta:'1'});b.click('invariantLedgerParity',{row:String(row),value:lib.invariantRed(s).length%2?'odd':'even'})}if(t.kind==='proof'){b.click('invariantVerdict',{value:reachable?'reachable':'unreachable'});b.click('invariantProof',{value:reachable?'path':t.rule==='swapAdjacent'?'count':'parity'})}if(t.kind==='invariant'||!reachable){lib.invariantProbes(t.rule).forEach((p,row)=>{for(const id of p.before.order)b.click('invariantProbeCoin',{row:String(row),id});b.click('invariantProbeRun',{row:String(row)});const after=lib.invariantStep(t.rule,p.before,p.before.order);b.click('invariantProbeDelta',{row:String(row),value:String(lib.invariantRed(after).length-lib.invariantRed(p.before).length)})});for(const value of lib.invariantQuantities(t.rule))b.click('invariantQuantity',{value})}}

function prepareStage(b,t){
 if(['counterBuild','compareBuild','reverseExchange','forwardExchange','placeCompose','tenFill','counterRemove','counterChange','inverseMove','equalGroups','orderGroups'].includes(t.mode))solveFoundation(b,t);
 else if(t.mode==='objectSort')for(const index of t.answer)b.click('sortObject',{index:String(index)});
 else if(t.mode==='fractionLab'){
  const tap=(side,n)=>{for(let i=0;i<n;i++)b.click('fractionCell',{side,index:String(i)})};
  if(['shade','decimal'].includes(t.kind))tap('left',t.target);
  if(['compare','equal'].includes(t.kind)){tap('left',t.targetLeft);tap('right',t.targetRight);b.click('fractionChoice',{value:t.correctChoice|| (t.kind==='equal'?'equal':'left')})}
  if(t.kind==='decimal')b.click('fractionChoice',{value:String(t.target/t.denom)});
  if(t.kind==='line')b.click('fractionMark',{index:String(t.target)});
  if(t.kind==='remainder'){if(t.requireBasisSelection)b.click('fractionReference',{value:t.answerBasis||'original'});for(let i=0;i<t.first;i++)b.click('fractionPiece',{index:String(i)});b.click('fractionPhase');for(let i=t.first;i<t.first+t.second;i++)b.click('fractionPiece',{index:String(i)});if(t.correctChoice)b.click('fractionChoice',{value:t.correctChoice})}
 }
 else if(t.mode==='integerLab')solveInteger(b,t);
 else if(t.mode==='ratioLab')solveRatio(b,t);
 else if(t.mode==='rateLab')solveRate(b,t);
 else if(t.mode==='journeyLab')solveJourney(b,t);
 else if(t.mode==='scaleLab')solveScale(b,t);
 else if(t.mode==='equationLab')solveEquation(b,t);
 else if(t.mode==='constraintLab')solveConstraint(b,t);
 else if(t.mode==='patternLab')solvePattern(b,t);
 else if(t.mode==='coordinateLab')solveCoordinate(b,t);
 else if(t.mode==='groupingLab')solveGrouping(b,t);
 else if(t.mode==='factorLab')solveFactor(b,t);
 else if(t.mode==='commonLab')solveCommon(b,t);
 else if(t.mode==='cycleLab')solveCycle(b,t);
 else if(t.mode==='measureLab')solveMeasure(b,t);
 else if(t.mode==='angleLab')solveAngle(b,t);
 else if(t.mode==='compositeLab')solveComposite(b,t);
 else if(t.mode==='circleLab')solveCircle(b,t);
 else if(t.mode==='similarLab')solveSimilar(b,t);
 else if(t.mode==='rightLab')solveRight(b,t);
 else if(t.mode==='solidLab')solveSolid(b,t);
 else if(t.mode==='combinLab')solveCombin(b,t);
 else if(t.mode==='chartLab')solveChart(b,t);
 else if(t.mode==='statsLab')solveStats(b,t);
 else if(t.mode==='chanceLab')solveChance(b,t);
 else if(t.mode==='motionLab')solveMotion(b,t);
 else if(t.mode==='invariantLab')solveInvariant(b,t);
 else if(t.mode==='setsLab')solveSets(b,t);
 else solvePercent(b,t);
}
function solveStage(b,t){prepareStage(b,t);b.click('check');assert.equal(microLatest(b).gradingResult,'correct',t.id+' authored answer '+JSON.stringify(microLatest(b).operationSummary))}
module.exports={solveGrouping,solveFactor,solveCommon,solveCycle,solveEquation,solveConstraint,solvePattern,solveCoordinate,solveRatio,solveRate,solveJourney,solveScale,solveSets,solveCombin,solvePercent,solveStage,prepareStage,solveMotion,solveFoundation,solveMeasure,solveAngle,solveComposite,rearrangedCells,unionPlacement};
