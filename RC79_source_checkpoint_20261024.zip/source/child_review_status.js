'use strict';
// One projection serves delivery, parent counts and exported audit tables.
const ChildReviewStatus=(()=>{
 const routeKeys=['routeId','examId','routeRevision','requiredKnowledge','requiredSkills','policyGaps','judgmentIds','integrationTaskIds','counterexampleTaskIds'];
 const bindingKeys=['bindingId','examId','judgmentId','taskRef','role','matchLevel','policyGaps','evidenceScope'];
 const canonical=x=>x===null||typeof x!=='object'?JSON.stringify(x):Array.isArray(x)?'['+x.map(canonical).join(',')+']':'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}';
 const fields=(x,keys)=>Object.fromEntries(keys.filter(k=>k in x).map(k=>[k,x[k]]));
 const clone=x=>JSON.parse(JSON.stringify(x));
 function label(checked){
  if(checked?.status==='REVIEWED')return '题目形式已审通过';
  if(checked?.status==='REVIEWED_RESTRICTED')return '题目形式已审受限'+(checked.record?.restrictionReason?'：'+checked.record.restrictionReason:'');
  if(checked?.status==='STALE')return '题目形式变更需复审';
  if(checked?.status==='UNMAPPED')return '映射待核验';
  return '题目形式待审';
 }
 function recipePresentationSnapshot(p){
  try{
   const C=typeof module!=='undefined'?require('./competition_reviewed'):null,D=typeof module!=='undefined'?require('./competition_content_contracts'):CompetitionContentContracts;
   const t=C?C.competitionCreate(p.recipe):competitionCreate(p.recipe),d=D.resolve(t);
   return clone({recipe:t.competition.recipe,math:t.competition.math,presentation:d,diagram:t.competition.diagram||null});
  }catch{return {invalidRecipe:true}}
 }
 function create(data,reviews,options={}){
  let taskIndex=null,taskCount=-1;
  let reviewSnapshot=null;
  // Cache within this synchronous read only. The next operation revalidates
  // source content, approvals, routes, bindings and available assets.
  function withReviewSnapshot(read){if(reviewSnapshot)return read();reviewSnapshot=new Map();try{return read()}finally{reviewSnapshot=null}}
  function taskIds(eid){const count=Object.keys(data.tasks).length;if(taskCount!==count){taskIndex={};for(const t of Object.values(data.tasks))(taskIndex[t.originProblemGroupId]??=[]).push(t.taskId);taskCount=count}return (taskIndex[eid]||[]).slice().sort()}
  function problemSnapshot(p){return {examId:p.examId,mathFacts:p.mathFacts||p.facts||null,answerContract:p.answerContract,presentation:p.presentation||null,recipe:p.recipe||null,...(p.sourceCorrection?{sourceCorrection:p.sourceCorrection}:{}),...(p.recipe?{recipePresentation:recipePresentationSnapshot(p)}:{}),load:p.load||null,routeIds:p.routeIds,routes:p.routeIds.map(id=>fields(data.routes[id],routeKeys)),bindings:p.trainingBindingIds.map(id=>fields(data.bindings[id],bindingKeys))}}
  function taskSnapshot(t){return fields(t,['taskId','contentRevision','prompt','answerContract','mathFacts','requiredKnowledge','role','load','options','hints','givenText','givenFigures','givenTable'])}
  function definition(candidate,row){const result=clone(candidate.definition);for(const key of ['prompt','givenText','givenFigures','givenTable','options','hints','renderingMode'])if(row[key]!==undefined)result[key]=clone(row[key]);return result}
  function assetReady(f){
   if(options.assetReady)return options.assetReady(f);
   if(typeof window!=='undefined')return !!window.__AMC8_SOURCE_FIGURES?.[f.sha256];
   if(options.checkFiles){try{const fs=require('fs'),path=require('path'),crypto=require('crypto'),root=path.resolve(__dirname,'..'),target=path.resolve(root,f.path);return target.startsWith(root+'/source/content/')&&crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex')===f.sha256}catch{return false}}
   return true;
  }
  function evaluate(p){
   if(!p)return {eligible:false,status:'UNMAPPED',reasonCodes:['MAPPING_REVIEW_PENDING']};
   const r=reviews.problems[p.examId];
   if(!r||!['REVIEWED','REVIEWED_RESTRICTED'].includes(r.status))return {eligible:false,status:'PENDING',reasonCodes:['CHILD_FORM_REVIEW_PENDING']};
   if(canonical(problemSnapshot(p))!==canonical(r.problemSnapshot))return {eligible:false,status:'STALE',reasonCodes:['CHILD_FORM_REVIEW_STALE']};
   if(canonical(taskIds(p.examId))!==canonical(Object.keys(r.tasks||{}).sort()))return {eligible:false,status:'STALE',reasonCodes:['CHILD_TASK_SET_CHANGED']};
   for(const [id,row] of Object.entries(r.tasks))if(!data.tasks[id]||canonical(taskSnapshot(data.tasks[id]))!==canonical(row.taskSnapshot))return {eligible:false,status:'STALE',reasonCodes:['CHILD_TASK_REVIEW_STALE']};
   if(r.status==='REVIEWED_RESTRICTED')return {eligible:false,status:'REVIEWED_RESTRICTED',reasonCodes:['CHILD_FORM_REVIEW_RESTRICTED'],record:r};
   for(const row of [{...p.presentation,...r},...Object.values(r.tasks)])if((row.givenFigures||[]).some(f=>!assetReady(f)))return {eligible:false,status:'STALE',reasonCodes:['CHILD_FORM_ASSET_MISSING_OR_CHANGED']};
   return {eligible:true,status:'REVIEWED',reasonCodes:[],record:r};
  }
  function review(p){if(reviewSnapshot?.has(p))return reviewSnapshot.get(p);const checked=evaluate(p);if(reviewSnapshot)reviewSnapshot.set(p,checked);return checked}
  function projection(){return Object.keys(data.registeredProblems).sort().map(eid=>{const registered=data.registeredProblems[eid],checked=review(data.problems[eid]);return {examId:eid,mappingVerification:registered.status.verificationStatus,mappingRuntimeStatus:registered.status.runtimeStatus,childFormStatus:checked.status,automaticPoolCandidate:checked.eligible&&registered.status.runtimeStatus==='eligible',reasonCode:checked.reasonCodes.join(';')||'REVIEWED',restrictionReason:checked.record?.restrictionReason||''}})}
  function coverage(){const rows=projection(),count=status=>rows.filter(r=>r.childFormStatus===status).length;return {registered:rows.length,unmapped:count('UNMAPPED'),mapped:Object.keys(data.problems).length,reviewed:count('REVIEWED'),restricted:count('REVIEWED_RESTRICTED'),stale:count('STALE'),pending:count('PENDING'),assessed:count('REVIEWED')+count('REVIEWED_RESTRICTED')}}
  return {problemSnapshot,taskSnapshot,definition,review,projection,coverage,withReviewSnapshot};
 }
 const value=typeof module!=='undefined'?create(require('./exam_runtime_index.json'),require('./child_form_reviews.json'),{checkFiles:true}):create(window.__AMC8_EXAM_MAPPING,window.__AMC8_CHILD_FORMS);
 return {...value,create,recipePresentationSnapshot,label};
})();
if(typeof module!=='undefined')module.exports=ChildReviewStatus;
