'use strict';
const ReasoningGraph=((sourceCatalog,math,extra,linear,final)=>{
 const numeric=v=>String(v).replace(/−/g,'-').split('/').map(Number).reduce((a,b)=>a/b),canon=v=>String(v).replace(/\s/g,'').replace(/×/g,'*').replace(/[÷]/g,'/').replace(/−/g,'-').replace(/甲组/g,'甲').replace(/乙组/g,'乙').replace(/丙组/g,'丙');
 const choose=(n,k)=>{let x=1;for(let i=1;i<=k;i++)x=x*(n-i+1)/i;return x};
 const N=(id,prompt,answer,unit='',extra={})=>({id,prompt,answer:String(answer),unit,prerequisiteIds:[],inputIds:[],outputId:id,rule:'explicit-family-relation',acceptedExpressions:[String(answer)],hints:[prompt+' 想想题干中哪条条件能帮助你。','把涉及同一量的条件放在一起；先只核对当前目标。'],errorCheck:'这个数代表哪个量？把它代回当前使用的条件，再核对单位。',sceneIncrement:{id,unit},disclosure:'current-node-only',...extra});
 function sequence(nodes){return nodes.map((n,i)=>({...n,prerequisiteIds:n.dependsOn??(i?[nodes[i-1].id]:[]),inputIds:n.dependsOn??(n.id==='target'?nodes.slice(0,i).map(x=>x.outputId):(i?[nodes[i-1].outputId]:[])),rule:{kind:'family-quantity-relation',statement:n.prompt},hintApplicability:{nodeId:n.id,prerequisiteIds:n.dependsOn??(i?[nodes[i-1].id]:[])}}))}
 function create(c,routeId){
  if(c.authoredGraph){const g=JSON.parse(JSON.stringify(c.authoredGraph));if(validate(g).length)throw Error('Invalid authored dependency contract');return g}
  const m=c.math,id=c.problemState.familyId||c.family,base={schemaVersion:1,graphRevision:2,familyId:id,configurationId:c.configurationId||'default',goal:c.problemState.goal,coverageStatus:'authored',routes:[]};
  const R=(id,name,nodes,requiredSkills=[])=>({id,name,requiredSkills,nodes:sequence(nodes)});
  if(id==='threeGroupBalance'){
   const extra=m.direction*m.d*(m.ref==='A'?m.k+1:1),parts=m.k+2,net=m.T-extra,ref=m.ref==='A'?'甲':'乙',d=m.direction*m.d;
   const relA=`乙${d>=0?'+':'-'}${Math.abs(d)}`,relC=`${m.k}*${ref}`,total=`${parts}*乙${extra>=0?'+':'-'}${Math.abs(extra)}=${m.T}`;
   const relations=[N('model-A','把甲组与乙组的关系画出来或写出来。',relA,'',{acceptedExpressions:[relA,'甲='+relA],choices:[relA,`${m.d}*乙`,`乙${d>=0?'-':'+'}${Math.abs(d)}`],hints:['“多一些”和“是几倍”有什么区别？','把乙作为一段，再思考甲组多出或少了哪一部分。','可以先放一段乙；额外部分由你选择。','可以请求甲的关系示范；丙仍由你搭。'],errorCheck:`“${m.direction===1?'多':'少'}${m.d}人”是改变人数，还是改变份数？`}),N('model-C','把丙组与参照组的关系画出来或写出来。',relC,'',{acceptedExpressions:[relC,'丙='+relC],choices:[relC,`${ref}+${m.k}`,`${m.k}*${ref==='甲'?'乙':'甲'}`],hints:['丙的倍数关系指向哪一组？','每一份必须是同一参照量；按题目倍数建立。']}),N('total-model','将三个小组连接到总人数。写出等份与额外量的关系。',total,'',{acceptedExpressions:[total,total.replace('*',''),`${m.T}=${total.split('=')[0]}`],hints:['三组都包含了吗？哪些份是同样大小？','甲组的差额也被丙的倍数带入了吗？检查倍数参照。'],errorCheck:'逐组核对甲、乙、丙；不要漏组，也不要把额外人数算成一份。'}),N('net','暂时去掉模型中的额外量，相同份对应的总人数是多少？',net,'人',{acceptedExpressions:[String(net),`${m.T}-(${extra})`],hints:['暂时拿开额外部分，总量应增加还是减少？','差额的符号由“多/少”和倍数参照共同决定。'],errorCheck:'先拿开额外部分，总量应该增加还是减少？'}),N('unit-B','同样的一份，也就是乙组，有多少人？',m.B,'人',{acceptedExpressions:[String(m.B),`${net}/${parts}`]}),N('target','回到题目问的那一组，给出人数。',m[m.goal],'人',{acceptedExpressions:[String(m[m.goal])],errorCheck:'当前得到的数代表哪一组？最后问的是哪一组？'}),N('verify','把结论代回，三组人数合计是多少？',m.T,'人',{acceptedExpressions:[String(m.T),`${m.A}+${m.B}+${m.C}`],verification:'all-three-relations'})];
   base.routes.push(R('reference-B','以乙为一份',relations));
   if(m.k===2&&m.ref==='B'&&m.goal==='C'){const q=`2*丙${d>=0?'+':'-'}${Math.abs(d)}=${m.T}`;base.routes.push(R('direct-C','直接表示丙',[N('pair-relation','甲与乙放在一起，相当于怎样的丙组？',`丙${d>=0?'+':'-'}${Math.abs(d)}`,'',{choices:[`丙${d>=0?'+':'-'}${Math.abs(d)}`,`丙${d>=0?'-':'+'}${Math.abs(d)}`,'2*丙']}),N('total-model','用丙表示三组总人数。',q,'',{acceptedExpressions:[q,q.replace('*','')]}),N('net','暂时去掉额外量，两个丙组共多少人？',m.T-d,'人'),N('target','直接求丙组人数。',m.C,'人'),N('verify','代回原条件后，甲乙丙总和是多少？',m.T,'人',{verification:'all-three-relations'})]))}
   base.routes.push(R('ordered-trial','有序试探',[N('trial-B','尝试一个乙组人数，同时核对三组总量。',m.B,'人',{errorCheck:'用你选的乙计算甲与丙，再和总人数比较；按同一方向继续试。'}),N('trial-growth','乙每增加1人，三组合计增加多少人？',parts,'人',{errorCheck:'甲增加多少？丙增加多少？再合计。'}),N('target','给出所求小组人数。',m[m.goal],'人'),N('verify','核对三组总人数。',m.T,'人',{verification:'all-three-relations'})],['C02.03']));
  }else if(id==='overlapAverages'){
   const a=m.values,k=(a.length+1)/2,sum=x=>x.reduce((s,v)=>s+v,0),front=sum(a.slice(0,k)),back=sum(a.slice(k-1)),all=sum(a);
   base.routes=[R('sum-overlap','把平均还原成总和',[N('target-position','要找的是第几个位置？',k),N('front-total','前面那段所有数的总和是多少？',front),N('back-total','后面那段所有数的总和是多少？',back),N('all-total','全部数的总和是多少？',all),N('multiplicity','前后两段相加，目标位置被数了几次？',2),N('target','如何留下恰好一次目标数？算出它。',a[k-1])]),R('remove-nonoverlap','先移除不重叠部分',[N('all-total','先得到全部数的总和。',all),N('back-total','后段总和是多少？',back),N('nonoverlap','从全部移除后段，留下的前段不重叠总和是多少？',all-back),N('front-total','完整前段总和是多少？',front),N('target','从前段移除不重叠部分，目标数是多少？',a[k-1])])];
  }else if(id==='signedProduct'){
   const cards=m.cards||[-4*m.k,-3*m.k,-m.k,0,2*m.k,5*m.k],neg=cards.filter(x=>x<0).sort((a,b)=>a-b),pos=cards.filter(x=>x>0).sort((a,b)=>a-b),one=neg[0]*pos.at(-1)*pos.at(-2),three=neg.slice(0,3).reduce((a,b)=>a*b,1);
   base.routes=[R('sign-categories','分类比较负乘积',[N('signs','三张乘积为负，负卡数量可能是多少？','1,3','',{acceptedExpressions:['1,3','3,1','1、3']}),N('one-negative','一负两正这一类，最小候选乘积是多少？',one),N('three-negative','三个负数这一类，最小候选乘积是多少？',three),N('target','比较完整类别，哪个乘积最小？',Math.min(one,three,0))])];
   const enumeration=[];for(let i=0;i<cards.length;i++)for(let j=i+1;j<cards.length;j++)for(let k=j+1;k<cards.length;k++)enumeration.push(N('triple-'+i+'-'+j+'-'+k,`按位置次序列全：${cards[i]}、${cards[j]}、${cards[k]} 的乘积是多少？`,cards[i]*cards[j]*cards[k]));enumeration.push(N('target','全部组合没有重复也没有遗漏，最小乘积是多少？',Math.min(...enumeration.map(n=>Number(n.answer)))));base.routes.push(R('complete-enumeration','按卡片位置列全后比较',enumeration));
  }else if(id==='digitDivisor'&&m.lo!==undefined){
   base.routes=[R('units-groups','按非零个位分组',[N('exclude-zero','个位为0时，可以把它当除数吗？','不可以','',{choices:['可以','不可以']}),...Array.from({length:9},(_,i)=>{const u=i+1,values=[];for(let n=m.lo+1;n<m.hi;n++)if(n%10===u&&n%u===0)values.push(n);return N('units-'+u,`个位为 ${u} 的合法数有几个？`,values.length,'个',{errorCheck:`只列个位为${u}的数，逐个检查严格区间与除法余数。`})}),N('target','各组互不重叠，合计多少个合法数？',m.valid.length,'个')])];
   const tens=[];for(let t=Math.floor((m.lo+1)/10);t<=Math.floor((m.hi-1)/10);t++){let count=0;for(let n=Math.max(m.lo+1,t*10);n<Math.min(m.hi,(t+1)*10);n++)if(n%10!==0&&n%(n%10)===0)count++;tens.push(N('tens-'+t,`十位为 ${t} 的合法数有几个？检查严格边界和非零个位。`,count,'个'))}tens.push(N('target','各十位组互不重叠，合计多少个合法数？',m.valid.length,'个'));base.routes.push(R('tens-groups','按十位列全',tens));
  }else if(id==='lShapeArea'&&m.inner!==undefined){const region=m.inner+m.border;
   base.routes=[R('complete-remove','先找边，再补形',[N('outer-side','沿外边连接已知短边，大正方形的边是多少？',m.inner+2*m.border),N('region-side','阴影所在外框方块的边是多少？',region),N('outer-area','外框方块面积是多少？',region**2),N('inner-area','需要移除的中央方块面积是多少？',m.inner**2),N('target','阴影面积是多少？',region**2-m.inner**2)]),R('disjoint-strips','分为不重叠的两条',[N('region-side','较长一条的长度是多少？',region),N('first-strip','较长一条面积是多少？',m.border*region),N('second-strip','另一条扣除转角后面积是多少？',m.border*m.inner),N('target','两条合并后的面积是多少？',region**2-m.inner**2)])];
  }else if(id==='recurrenceBackwards'){
   const a=[m.first,m.second];while(a.length<m.n)a.push(a.at(-1)+a.at(-2));const nodes=[];for(let i=a.length-3;i>=0;i--)nodes.push(N('term-'+(i+1),`利用紧邻的已知项，求第 ${i+1} 项。`,a[i],'',{hints:['递推向前是相加，向后需要什么逆运算？','用后面那项减去它前面已知的一项。'],sceneIncrement:{termIndex:i+1}}));base.routes=[R('reverse-recursion','从相邻末项倒推',nodes)];
  }else if(id==='fixedPerimeter'){const half=m.half,w=Math.floor(half/2);base.routes=[R('pairs','完整列出合法配对',[N('half-perimeter','一条长加一条宽等于多少？',half),...Array.from({length:w},(_,i)=>N('pair-'+(i+1),`短边取 ${i+1} 时，长方形面积是多少？`,(i+1)*(half-i-1))),N('target','完整比较这些合法面积，最大是多少？',w*(half-w))]),R('move-one','把一格从长边移到短边',[N('half-perimeter','保持周长时，长宽和是多少？',half),N('nearest-gap','正整数边尽量靠近时，两边之差最小是多少？',half%2),N('short-side','这个合法形状的短边是多少？',w),N('target','计算面积并检验周长。',w*(half-w))])];
  }else if(id==='boundaryNotch')base.routes=[R('replacement','追踪轮廓替换',[N('old-boundary','原来的长方形周长是多少？',2*(m.w+m.h)),N('removed','缺口替换掉的原边长度是多少？',m.a),N('bottom','凹口新加的底边长度是多少？',m.a),N('extra','哪些边没有被抵消？它们共长多少？',2*m.depth),N('target','新轮廓的周长是多少？',2*(m.w+m.h+m.depth))])];
  else if(id==='exactlyOneSet')base.routes=[R('disjoint','分为只在一个组的两部分',[N('only-A','只在甲组的人数是多少？',m.a-m.both,'人'),N('only-B','只在乙组的人数是多少？',m.b-m.both,'人'),N('target','这两部分互不重叠，合计是多少？',m.a+m.b-2*m.both,'人')])];
  else if(id==='gridDetour')base.routes=[R('subtract-through','完整路线减经过限制点',[N('all-routes','先不考虑P，最短路线共有多少条？',choose(m.w+m.h,m.w),'条'),N('to-P','从A到P有多少条最短路线？',choose(m.x+m.y,m.x),'条'),N('from-P','从P到B有多少条最短路线？',choose(m.w+m.h-m.x-m.y,m.w-m.x),'条'),N('through-P','怎样配对前后段？经过P的完整路线共有多少条？',choose(m.x+m.y,m.x)*choose(m.w+m.h-m.x-m.y,m.w-m.x),'条'),N('target','避开P的路线有多少条？',choose(m.w+m.h,m.w)-choose(m.x+m.y,m.x)*choose(m.w+m.h-m.x-m.y,m.w-m.x),'条')])];
  else if(id==='natural-catch')base.routes=[R('lead-gap','领先距离与差速',[N('lead','先出发的人领先多少米？',m.slow*m.delay,'米'),N('gap-speed','后出发后，每分钟把差距缩小多少米？',m.fast-m.slow,'米/分钟'),N('target','从后者出发起，要多久追上？',m.slow*m.delay/(m.fast-m.slow),'分钟')])];
  else if(id==='rule-packs-enough'){const p=m.params,plans=[];for(let n=0;n<=Math.ceil(p.count/p.size);n++)plans.push({n,single:Math.max(0,p.count-n*p.size),cost:n*p.pack+Math.max(0,p.count-n*p.size)*p.single});base.routes=[R('purchase-candidates','把合法购买方案列完整',[N('upper-pack','多少整包已经能单独买够？',Math.ceil(p.count/p.size),'包'),...plans.map(x=>N('cost-'+x.n,`买 ${x.n} 包，余下按需要单买，总费用是多少？`,x.cost,'元')),N('target','比较合法方案，最低费用是多少？',Math.min(...plans.map(x=>x.cost)),'元')])];}
  else {base.routes=extra.make(c,N,R)||[];base.coverageStatus=base.routes.length?'authored':'unadapted'}
  const finalRoutes=final.review(c,base.routes,N,R);if(finalRoutes){base.routes=finalRoutes;base.graphRevision=3;}
  base.routes.push(...extra.reviewedRoutes(c,N,R));
  if(id==='transferBetweenBoxes')for(const r of base.routes)for(const n of r.nodes)if(n.id==='gap-count'){
   n.unit='块';n.scaffoldKind='two-sided-transfer';
   n.hints=['先分别判断：甲得到积木，乙拿出积木。两边各怎样变化？','比较“乙给甲”与“外面只给甲”：哪一种情况下，乙也会减少？','把甲增加和乙减少对同一个差额的影响合起来。由你求原来的差，再对应份数差。'];
   n.errorCheck='甲增加时两盒的差会怎样变？乙同时减少时，这个差还会怎样变？分别跟踪两边，再合成原差；单位是块。';
  }
  if(c.skillContractKey&&['squareBorder','paintedCube','cubeProbability','chartScale','missingAverage','natural-weighted','natural-fractionWeighted','telescopingDifferences','reverseDigits','natural-digitCount','natural-distinctDigitCount','machineOrder','digitDivisor','boundaryNotch','polygonTurn','lShapeArea','crossArea','oppositeScale','similarAreaPerimeter','scaleAreaReverse','natural-offers','shadowSimilarity'].includes(id))base.graphRevision=3;
  // Family-authored dependencies permit sibling quantities in either order.
  const dependencies={
   threeGroupBalance:{'reference-B':{'model-A':[],'model-C':[],'total-model':['model-A','model-C']},'direct-C':{},'ordered-trial':{}},
   overlapAverages:{'sum-overlap':{'target-position':[],'front-total':['target-position'],'back-total':['target-position'],'all-total':['target-position'],'multiplicity':['front-total','back-total'],'target':['front-total','back-total','all-total','multiplicity']},'remove-nonoverlap':{'all-total':[],'back-total':[],'nonoverlap':['all-total','back-total'],'front-total':[],'target':['nonoverlap','front-total']}},
   exactlyOneSet:{disjoint:{'only-A':[],'only-B':[],target:['only-A','only-B']}},
   gridDetour:{'subtract-through':{'all-routes':[],'to-P':[],'from-P':[],'through-P':['to-P','from-P'],target:['all-routes','through-P']}},
   'natural-weighted':{'family-quantities':{'people-parts':[],'red-total':[],'blue-total':[],target:['people-parts','red-total','blue-total']}},
   'natural-fractionWeighted':{'family-quantities':{'people-parts':[],'red-total':[],'blue-total':[],target:['people-parts','red-total','blue-total']}},
   'natural-catch':{'lead-gap':{lead:[],'gap-speed':[],target:['lead','gap-speed']}},
   'natural-tiles':{'family-quantities':{'largest-side':[],'along-width':['largest-side'],'along-height':['largest-side'],target:['along-width','along-height']}},
   'natural-pairChance':{'family-quantities':{'all-pairs':[],'red-pairs':[],target:['all-pairs','red-pairs']}},
   'natural-offers':{'family-quantities':{'shop-A':[],'shop-B':[],target:['shop-A','shop-B']}},
   'natural-coordinateDistance':{'family-quantities':{'x-gap':[],'y-gap':[],'decision-1':[],target:['x-gap','y-gap','decision-1']}},
   routeProbability:{'family-quantities':{'decision-1':[],'all-routes':['decision-1'],'allowed-routes':['decision-1'],target:['all-routes','allowed-routes']}},
   cubeProbability:{'family-quantities':{'decision-1':[],'one-edge':['decision-1'],'all-edges':[],'two-painted':['one-edge','all-edges'],target:['two-painted']}},
   overlapProbability:{'family-quantities':{'overlap-width':[],'overlap-height':[],intersection:['overlap-width','overlap-height'],union:['intersection'],target:['intersection','union']}},
   ratioUnion:{'family-quantities':{attendance:[],parts:[],'part-value':['attendance','parts'],'B-total':['part-value'],target:['B-total']}},
   chartAverage:{'family-quantities':{count:[],'score-total':[],target:['count','score-total']}},
   recurrenceRemainders:{'family-quantities':{'decision-1':[],'pair-period':c.skillContractKey?['returned-pair']:['decision-1'],'whole-cycles':['pair-period'],'tail-size':['pair-period'],target:c.skillContractKey?['whole-cycles','cycle-sum','tail-sum']:['whole-cycles','tail-size']}},
   remainderProbability:{'family-quantities':{'whole-cycles':[],tail:[],'tail-good':['tail'],good:['whole-cycles','tail-good'],target:['good']}},
   stepwiseRoute:{'family-quantities':{'decision-1':[],'route-count':['decision-1'],'decision-2':['decision-1'],target:['decision-1','decision-2']}},
   'rule-weighted-mean':{'family-quantities':{'count-parts':[],'A-score':[],'B-score':[],target:['count-parts','A-score','B-score']}},
   'rule-weighted-score':{'family-quantities':{'total-score':[],'B-score':[],'A-total':['total-score','B-score'],target:['A-total']}},
   'rule-ratio-length':{'family-quantities':{half:[],parts:[],one:['half','parts'],target:['one']}}
  };
  for(const family of ['natural-digitCount','natural-distinctDigitCount']){
   const groups=base.routes[0]?.nodes.filter(n=>n.id.startsWith('first-')).map(n=>n.id)||[];
   if(id===family)dependencies[family]={'family-quantities':Object.fromEntries([['decision-1',[]],...groups.map(node=>[node,['decision-1']]),['target',groups]])};
  }
  for(const r of base.routes)for(const n of r.nodes){const deps=dependencies[id]?.[r.id]?.[n.id];if(deps){n.prerequisiteIds=deps;n.inputIds=[...deps];n.hintApplicability.prerequisiteIds=[...deps]}}
  if(id==='threeGroupBalance')for(const r of base.routes)for(const n of r.nodes){
   if(n.id==='model-A')n.linearContract={expected:[relExpression(m,'A'),'甲='+relExpression(m,'A')]};
   if(n.id==='model-C')n.linearContract={expected:[String(m.k)+'*'+(m.ref==='A'?'甲':'乙'),'丙='+String(m.k)+'*'+(m.ref==='A'?'甲':'乙')]};
   if(n.id==='pair-relation')n.linearContract={expected:[n.answer]};
   if(n.id==='total-model'){const d=m.direction*m.d;const aliases=r.id==='direct-C'?{'甲':'丙/2'+(d>=0?'+':'')+d,'乙':'丙/2'}:{'甲':'乙'+(d>=0?'+':'')+d,'丙':String(m.k)+'*乙'+(m.ref==='A'?(m.k*d>=0?'+':'')+m.k*d:'')};n.linearContract={expected:[n.answer],aliases}}
  }
  const source=sourceCatalog.definitionFor(id,c.configurationId);
  if(['amc2000-23-full','amc2000-06-full'].includes(c.configurationId)){
   base.graphRevision=4;
   const sufficient=id==='overlapAverages'?{'sum-overlap':['front-total','back-total','all-total','multiplicity','target'],'remove-nonoverlap':['all-total','back-total','nonoverlap','front-total','target']}:{'complete-remove':['region-side','outer-area','inner-area','target'],'disjoint-strips':['region-side','first-strip','second-strip','target']};
   for(const r of base.routes){
    if(sufficient[r.id])r.goalContracts={sufficientNodeSets:[sufficient[r.id]],evidenceScope:'guided_scaffold',numericFinalAloneIsSufficient:false};
    for(const n of r.nodes){let deps;
     if(id==='overlapAverages'&&['front-total','back-total','all-total'].includes(n.id))deps=[];
     if(id==='lShapeArea'&&r.id==='complete-remove')deps=({ 'outer-side':[],'region-side':[],'outer-area':['region-side'],'inner-area':[],target:['outer-area','inner-area']})[n.id];
     if(deps){n.prerequisiteIds=deps;n.inputIds=[...deps];n.hintApplicability.prerequisiteIds=[...deps]}
    }
   }
  }
  for(const r of base.routes){const reviewed=sourceCatalog.reviewedRoute(c,r),mapped=reviewed||source?.routes.find(x=>x.id===r.id);if(mapped){r.requiredSkills=mapped.requiredSkills;if(reviewed){r.skillContractRevision=reviewed.contractRevision;r.skillContractStatus=reviewed.contractStatus}}}
  return base;
 }
 function relExpression(m){const d=m.direction*m.d;return '乙'+(d>=0?'+':'')+d}
 function validate(graph){const failures=[];for(const r of graph.routes){const seen=new Set();for(const n of r.nodes){if(seen.has(n.id)||n.prerequisiteIds.some(id=>!seen.has(id)))failures.push(r.id+'/'+n.id+' dependency');if(!n.prompt||!n.hints.length||!n.outputId||!n.errorCheck)failures.push(r.id+'/'+n.id+' incomplete');seen.add(n.id)}if(r.goalContracts&&(!Array.isArray(r.goalContracts.sufficientNodeSets)||!r.goalContracts.sufficientNodeSets.length||r.goalContracts.sufficientNodeSets.some(ids=>!Array.isArray(ids)||!ids.length||ids.some(id=>!seen.has(id)))))failures.push(r.id+' invalid goal contract')}return failures}
 function accepts(node,input){const s=canon(input);return node.acceptedExpressions.some(a=>canon(a)===s)||math.equal(s,node.answer)||linear.accepts(node,s)}
 function recognizes(node,input){return node.recognizedExpressions?.some(x=>canon(x)===canon(input))||linear.recognizes(node,canon(input))}
 return {create,validate,accepts,recognizes,canon};
})(typeof module!=='undefined'?require('./source_catalog'):SourceCatalog,typeof module!=='undefined'?require('./problem_state'):ProblemState,typeof module!=='undefined'?require('./reasoning_graph_extra'):ReasoningGraphExtra,typeof module!=='undefined'?require('./relation_expression'):RelationExpression,typeof module!=='undefined'?require('./reasoning_graph_final'):ReasoningGraphFinal);
if(typeof module!=='undefined')module.exports=ReasoningGraph;
