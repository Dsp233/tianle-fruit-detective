'use strict';
const SourceCatalog=((data,registry,teaching)=>{
 const skills=new Map(data.skills.map(s=>[s.id,s]));
 function closure(ids){const out=new Set();function add(id){if(out.has(id))return;if(!skills.has(id))throw Error('Unknown required skill '+id);out.add(id);skills.get(id).prerequisiteIds.forEach(add)}ids.forEach(add);return [...out].sort()}
 function knowledgeGaps(c){const id=typeof c==='string'?c:c.problemState?.familyId||c.recipe?.familyId||c.family;return id==='signedProduct'?[{id:'negative-integer-products',reason:'The current A05 lessons do not teach the sign rules for multiplying negative integers',message:'这道题需要负数乘法的规则，当前学习范围还未覆盖。'}]:[]}
 const route=(id,direct,familyId)=>({id,directSkills:direct,requiredSkills:closure(direct),unverifiedKnowledge:knowledgeGaps(familyId||'')});
 const groupBase=['A02.01','A02.03','A02.04','A02.05','R01.01','L01.01'];
 const definitions=Object.fromEntries(registry.anchors.map(a=>[a.familyId,{examId:a.examId,configId:a.configurationId,sourceId:a.sourceId,routes:a.routes.map(r=>route(r.id,r.directSkills,a.familyId))}]));
 definitions.threeGroupBalance={configId:'main',routes:[route('reference-B',groupBase),route('direct-C',groupBase),route('ordered-trial',[...groupBase,'C02.03'])]};
 function definitionFor(id,config){const a=registry.anchors.find(a=>a.familyId===id&&a.configurationId===config);return a?{examId:a.examId,configId:a.configurationId,sourceId:a.sourceId,routes:a.routes.map(r=>route(r.id,r.directSkills,a.familyId))}:definitions[id]}
 function knownTopics(topicIds,excluded=[]){const set=new Set(topicIds),removed=new Set(excluded);return data.skills.filter(s=>set.has(s.unitId)&&!removed.has(s.id)).map(s=>s.id)}
 function profile(settings={}){
  if(!settings||typeof settings!=='object')settings={};
  const selected=new Set(Array.isArray(settings.topicIds)?settings.topicIds:[]),excluded=new Set(Array.isArray(settings.excludedSkillIds)?settings.excludedSkillIds:[]);
  const topicIds=data.units.filter(u=>selected.has(u.id)).map(u=>u.id),excludedSkillIds=data.skills.filter(s=>excluded.has(s.id)).map(s=>s.id);
  return {profileVersion:1,knowledgeStatus:'user-declared',topicIds,excludedSkillIds,declaredSkillIds:knownTopics(topicIds,excludedSkillIds),
   sourceIds:Array.isArray(settings.sourceIds)?[...new Set(settings.sourceIds.filter(id=>registry.banks.some(b=>b.id===id)))]:['AMC8'],
   examIds:Array.isArray(settings.examIds)?[...new Set(settings.examIds.filter(id=>/^AMC8-\d{4}-\d{2}$/.test(id)))]:[],
   maxCalculationLoad:[1,2].includes(settings.maxCalculationLoad)?settings.maxCalculationLoad:null,
   maxReadingLoad:[1,2].includes(settings.maxReadingLoad)?settings.maxReadingLoad:null};
 }
 function allowedRoutes(routes,mastered){const set=new Set(mastered);return routes.filter(r=>!r.unverifiedKnowledge?.length&&r.requiredSkills.every(id=>set.has(id)))}
 function taskRoutes(task){
  if(task.competition.integrated)return task.competition.routes.map(r=>({...r,directSkills:r.requiredSkills,requiredSkills:closure(r.requiredSkills),unverifiedKnowledge:[]}));
  const reviewed=teaching.get(task.competition);
  if(reviewed)return task.competition.routes.map(r=>{const x=reviewedRoute(task.competition,r),gaps=knowledgeGaps(task.competition);return {...x,unverifiedKnowledge:gaps.length?gaps:x.unverifiedKnowledge}});
  const c=task.competition,base=closure(data.skills.filter(s=>(c.topicIds||[]).includes(s.unitId)).map(s=>s.id));
  const common=[c.prompt,c.extension.prompt,c.answer,c.extension.answer].join(' ');
  const extras=text=>{
   const ids=[];if(/[-−]?\d+\s*\/\s*\d+/.test(text))ids.push('A03.02','A03.04');
   ids.push(...teaching.textUses(text).map(x=>x.skillId));
   return ids;
  };
  return (c.routes||[]).map(r=>{const text=common+' '+r.nodes.map(n=>n.answer+' '+n.hints.join(' ')).join(' ');return {id:r.id,unverifiedKnowledge:[...knowledgeGaps(c),...teaching.textKnowledgeGaps(text)],requiredSkills:closure([...(c.sourceProvenance?.matchType==='full_structure'||c.family==='threeGroupBalance'?r.requiredSkills:[...base,...r.requiredSkills]),...extras(text)])}});
 }
 function reviewedRoute(c,r){const contract=teaching.annotate(c,r);return contract?{...contract,requiredSkills:closure(contract.directSkills)}:null}
 function teachingScope(task,settings){
  const c=task.competition,contract=teaching.get(c);if(!contract)return null;
  const methodDefinitions=contract.revision===1?contract.methodExtras.map(extras=>({routeId:contract.routeId,extras})):contract.methods;
  if(methodDefinitions.length!==c.methods.length)throw Error('Unreviewed solution method '+c.family);
  const declared=new Set(profile(settings).declaredSkillIds),routes=taskRoutes(task);
  const methods=methodDefinitions.map((m,index)=>{const main=routes.find(r=>r.id===m.routeId);if(!main)throw Error('Unknown method route '+c.family+'/'+m.routeId);const text=c.methods[index].steps.join(' '),uses=[...m.extras,...(contract.revision===2?teaching.textUses(text):[])];return {index,routeId:m.routeId,useRouteFrames:m.useRouteFrames===true,requiredSkills:closure([...main.directSkills,...uses.map(x=>x.skillId)]),skillUses:uses,unverifiedKnowledge:[...(m.unverifiedKnowledge||[]),...teaching.textKnowledgeGaps(text)].map(x=>({...x}))}});
  const definitions=c.extension.key==='remove-high-to-target-v2'?[{id:c.extension.key,uses:[...contract.variations[0].uses,{skillId:'C02.03',reason:'Enumerate the bounded remaining population'},{skillId:'N01.02',reason:'Members removed must be integer'}]}]:contract.revision===1?[{id:'original-variation',uses:contract.variation}]:contract.variations;
  const variations=definitions.map(v=>{const uses=[...v.uses,...(contract.revision===2?[...teaching.textUses(c.extension.prompt),...teaching.valueUses(c.extension.answer)]:[])],requiredSkills=closure(uses.map(x=>x.skillId)),unverifiedKnowledge=[...(v.unverifiedKnowledge||[]),...teaching.textKnowledgeGaps(c.extension.prompt)].map(x=>({...x}));return {id:v.id,requiredSkills,skillUses:uses,unverifiedKnowledge,allowed:!unverifiedKnowledge.length&&requiredSkills.every(id=>declared.has(id)),missingSkillIds:requiredSkills.filter(id=>!declared.has(id)),solution:v.solution?.(c)}});
  const selected=variations.find(v=>v.allowed)||[...variations].sort((a,b)=>a.missingSkillIds.length-b.missingSkillIds.length)[0];
  return {contractRevision:contract.revision,methods,allowedMethodIndexes:methods.filter(m=>!m.unverifiedKnowledge.length&&m.requiredSkills.every(id=>declared.has(id))).map(m=>m.index),variation:{...selected,routes:variations}};
 }
 function presentationValue(task,value,settings){const contract=teaching.get(task.competition),declared=profile(settings).declaredSkillIds,places=teaching.decimalPlaces(value),skill=places===1?'A03.06':places===2?'A04.02':null;return contract?.revision===2&&(places>2||(skill&&!declared.includes(skill))||(!places&&!declared.includes('A03.06')))?teaching.exactFraction(value):String(value)}
 function taskAllowed(task,settings){return allowedRoutes(taskRoutes(task),profile(settings).declaredSkillIds)}
 function loadsAllowed(task,settings){const c=task.competition;return (!settings.maxCalculationLoad||c.calculationLoad.level<=settings.maxCalculationLoad)&&(!settings.maxReadingLoad||c.readingLoad.level<=settings.maxReadingLoad)}
 function taskEligibility(task,settings){
  const current=profile(settings),routes=taskAllowed(task,current),provenance=task.competition.sourceProvenance||{},sourceId=provenance.sourceId||'original',reasonCodes=[];
  if(!current.sourceIds.includes(sourceId))reasonCodes.push('SOURCE_NOT_SELECTED');
  if(current.examIds.length&&!current.examIds.includes(provenance.examId))reasonCodes.push('EXAM_NOT_SELECTED');
  if(!routes.length)reasonCodes.push('NO_COMPLETE_KNOWLEDGE_ROUTE');
  if(!loadsAllowed(task,current))reasonCodes.push('LOAD_LIMIT');
  return {eligible:reasonCodes.length===0,reasonCodes,allowedRouteIds:routes.map(r=>r.id),profile:current};
 }
 const previewTasks=new Map();
 function preview(item,seed){
  const recipe={engine:3,familyId:item.id,seed,generatorRevision:item.generatorRevision||3,...(item.configurationId?{configurationId:item.configurationId}:{})},key=JSON.stringify(recipe);
  if(!previewTasks.has(key))previewTasks.set(key,(typeof module!=='undefined'?require('./competition_reviewed').competitionCreate:competitionCreate)(recipe));
  return previewTasks.get(key);
 }
 function eligible(families,settings){
  settings=profile(settings);
  const mastered=knownTopics(settings.topicIds,settings.excludedSkillIds),scope=new Set(settings.topicIds),sources=settings.sourceIds||['AMC8'],ids=new Set(settings.examIds||[]),result=[];
  for(const f of families){if(f.integrated){if(sources.includes('original')&&!ids.size)for(const configurationId of f.configurations)result.push({...f,configurationId,generatorRevision:5,sourceId:'original'});continue}const def=definitions[f.id];
   for(const a of registry.anchors.filter(a=>a.familyId===f.id)){
    if(!sources.includes(a.sourceId)||!registry.banks.some(b=>b.id===a.sourceId&&b.enabled)||!['structure_verified_local','runtime_verified','accepted'].includes(a.supplyStatus)||ids.size&&!ids.has(a.examId))continue;
    const routes=allowedRoutes(a.routes.map(r=>route(r.id,r.directSkills,a.familyId)),mastered);if(routes.length)result.push({...f,configurationId:a.configurationId,generatorRevision:a.generatorRevision,sourceId:a.sourceId,sourceExamId:a.examId,allowedRouteIds:routes.map(r=>r.id),requiredSkillsByRoute:routes});
   }
   const hasReviewed=!!teaching.catalog[f.id];
   if(sources.includes('original')&&!ids.size&&(hasReviewed||f.topicIds.every(x=>scope.has(x)))){
    // Original route scopes are conservative until per-route contracts are reviewed.
    const routes=def&&!def.examId?def.routes:[route('legacy-topic-scope',data.skills.filter(s=>f.topicIds.includes(s.unitId)).map(s=>s.id))],allowed=allowedRoutes(routes,mastered);
    const configurations=[f.id==='threeGroupBalance'?'main':undefined,...((typeof module!=='undefined'?require('./structured_recipes'):StructuredRecipes).extraConfigs[f.id]||[])];
    if(allowed.length||hasReviewed)for(const configurationId of configurations)result.push({...f,configurationId,generatorRevision:configurationId?4:f.id==='natural-weighted'?5:f.generatorRevision||3,sourceId:'original',allowedRouteIds:allowed.map(r=>r.id),requiredSkillsByRoute:allowed})
   }
  }return result.map(item=>{let task;for(const seed of [1,2,3,129,2147483647]){const t=preview(item,seed);if(taskAllowed(t,settings).length&&loadsAllowed(t,settings)){task=t;break}}return task?{...item,allowedRouteIds:taskAllowed(task,settings).map(r=>r.id),requiredSkillsByRoute:taskAllowed(task,settings)}:null}).filter(Boolean);
 }
 function explain(families,settings){
  settings=profile(settings);
  const topics=settings.topicIds||[],sourceIds=settings.sourceIds||['AMC8'],pool=eligible(families,settings),result={available:pool.length>0,count:pool.length,code:'available',message:'当前范围可开始挑战。',missingSkillIds:[]};if(pool.length)return result;
  if(!topics.length)return {...result,code:'no_topics',message:'先选你已经掌握的知识。'};
  if(!sourceIds.length)return {...result,code:'no_sources',message:'还没有选择参考来源，请勾选一种。'};
  const active=sourceIds.filter(id=>registry.banks.some(b=>b.id===id&&b.enabled));if(!active.length)return {...result,code:'source_material_missing',message:'所选来源的原始资料还未核验，暂时不能供题。'};
  if((settings.examIds||[]).length){const matching=registry.anchors.filter(a=>settings.examIds.includes(a.examId)&&sourceIds.includes(a.sourceId));if(matching.length&&matching.every(a=>knowledgeGaps(a.familyId).length))return {...result,code:'unverified_knowledge',unverifiedKnowledge:matching.flatMap(a=>knowledgeGaps(a.familyId)),message:knowledgeGaps(matching[0].familyId)[0].message+'原作答与草稿可以保留。'};return {...result,code:'exam_scope',message:'指定真题与当前知识范围没有匹配，请调整题号或已掌握范围。'};}
  if(eligible(families,{...settings,maxCalculationLoad:null,maxReadingLoad:null}).length)return {...result,code:'load_limit',message:'计算量或阅读量限制挡住了可用题，可调整这两项。'};
  const mastered=new Set(knownTopics(topics,settings.excludedSkillIds)),scope=new Set(topics),candidates=[];
  for(const f of families){const d=definitions[f.id];if(active.includes('AMC8')&&d?.examId&&f.topicIds.some(id=>scope.has(id)))candidates.push(...d.routes);if(active.includes('original')){
   if(teaching.catalog[f.id])candidates.push(...taskRoutes(preview({...f,generatorRevision:3},1)));
   else if(f.topicIds.every(id=>scope.has(id)))candidates.push(...(d&&!d.examId?d.routes:[route('legacy-topic-scope',data.skills.filter(x=>f.topicIds.includes(x.unitId)).map(x=>x.id))]));
  }}
  const missing=candidates.map(r=>r.requiredSkills.filter(id=>!mastered.has(id))).filter(x=>x.length).sort((a,b)=>a.length-b.length)[0];
  if(missing)return {...result,code:'missing_prerequisites',missingSkillIds:missing,message:'当前可用结构还需要：'+missing.slice(0,4).map(id=>skills.get(id).title).join('、')+(missing.length>4?'等知识':'')+'。只有确实已掌握时才调整范围。'};
  return {...result,code:'source_coverage_gap',message:'已核验的来源结构暂未覆盖当前选择。可以查看来源情况，或自行调整已掌握范围。'};
 }
 function provenance(id,config){const a=registry.anchors.find(a=>a.familyId===id&&a.configurationId===config);return a?{sourceId:a.sourceId,examId:a.examId,matchType:'full_structure',configurationId:config,reference:a.reference,sourceStatus:a.supplyStatus,acceptanceEvidence:[...(a.acceptanceEvidence||[])],releaseAcceptance:'pending'}:{sourceId:'original',matchType:'original',configurationId:config||'legacy-default'}}
 return {definitions,definitionFor,closure,knownTopics,profile,allowedRoutes,taskRoutes,taskAllowed,taskEligibility,teachingScope,reviewedRoute,presentationValue,skillContractKey:teaching.key,knowledgeGaps,loadsAllowed,eligible,provenance,explain,banks:registry.banks};
})(typeof module!=='undefined'?require('./skills.json'):window.__AMC8_SKILLS,typeof module!=='undefined'?require('./source_registry.json'):window.__AMC8_SOURCE_REGISTRY,typeof module!=='undefined'?require('./teaching_skill_contracts'):TeachingSkillContracts);
if(typeof module!=='undefined')module.exports=SourceCatalog;
