"""Freeze byte identities and registry for RC70. Never changes a deployed site."""
import argparse, hashlib, json, pathlib, re, shutil, subprocess
from artifact_inventory import source_inventory

ROOT = pathlib.Path(__file__).resolve().parent.parent
SEEDS = [1, 2, 129, 2147483646, 2147483647]
ENTRIES = ['index.html', 'source/index.html', 'amc8/index.html', 'academy/index.html', 'qa/index.html', 'qa/normal/index.html', 'qa/history/index.html']

def fixture_file(p):
    relative=p.relative_to(ROOT).as_posix()
    allowed=p.suffix in {'.js','.json','.html','.csv','.py','.css'} or relative.startswith('source/content/imported_assets/') and p.suffix in {'.png','.svg'}
    return p.is_file() and allowed and not any(part.startswith('.') for part in p.relative_to(ROOT).parts)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def canonical(data):
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()

def registry():
    code = """const M=require('./source/competition_reviewed'),S=require('./source/source_catalog'),K=require('./source/skills.json');
const configs=require('./docs/rc69-execution-manifest.json').configurations.map(c=>({familyId:c.familyId,configurationId:c.configurationId,recipe:{...c.rc68Recipe,...(c.familyId==='natural-weighted'?{generatorRevision:5}:{})}}));
for(const f of M.COMPETITION_REVIEWED.filter(f=>f.integrated))for(const configurationId of f.configurations)configs.push({familyId:f.id,configurationId,recipe:{engine:3,familyId:f.id,configurationId,generatorRevision:5,seed:1}});
const routes=[];for(const c of configs){const seen=new Set();for(const seed of [1,2,129,2147483646,2147483647]){const t=M.competitionCreate({...c.recipe,seed});for(const r of S.taskRoutes(t)){if(seen.has(r.id))continue;seen.add(r.id);routes.push({familyId:c.familyId,configurationId:c.configurationId,routeId:r.id,requiredSkills:r.requiredSkills,policyBlocked:!!r.unverifiedKnowledge?.length})}}}
const mapping=require('./source/exam_mapping'),profile={declaredSkillIds:K.skills.map(s=>s.id),sourceIds:['AMC8'],examIds:[]},originalIds=Object.values(mapping.data.problems).filter(p=>mapping.check(p,profile).eligible).map(p=>p.examId),trainingIds=Object.values(mapping.data.tasks).filter(t=>mapping.taskAllowed(t,profile).eligible).map(t=>t.taskId);
console.log(JSON.stringify({families:M.COMPETITION_REVIEWED.map(f=>f.id),configurations:configs,routes,rtm1:{mappingBuildId:mapping.data.mappingBuildId,nativeCaseIds:[...originalIds,...trainingIds,...require('./source/rtm_case_manifest.json').scenarioIds],originalIds,trainingIds,coverage:mapping.data.coverage}}));"""
    return json.loads(subprocess.check_output(['node', '-e', code], cwd=ROOT, text=True))

def freeze(out):
    changes=subprocess.check_output(['git','status','--porcelain','--untracked-files=all','--','source'],cwd=ROOT,text=True)
    if any(pathlib.Path(line[3:]).suffix in {'.js','.json','.py','.css','.html','.svg','.png','.csv'} and line[3:]!='source/index.html' for line in changes.splitlines()):
        raise RuntimeError('Commit source changes before freezing a candidate')
    for cmd in [['python3','source/build.py','--check'],['python3','source/build_qa.py','--check']]:
        subprocess.run(cmd,cwd=ROOT,check=True)
    scope = registry()
    assert len(scope['families']) == 143 and len(scope['configurations']) == 153
    assert len({(c['familyId'],c['configurationId']) for c in scope['configurations']}) == 153
    release = json.loads((ROOT/'source/version.json').read_text())
    entries=ENTRIES+(['muse/rc'+re.search(r'rc\.(\d+)',release['siteVersion']).group(1)+'/maintenance.html'] if int(re.search(r'rc\.(\d+)',release['siteVersion']).group(1))>=73 else [])
    assert all((ROOT/name).is_file() for name in entries),'Missing release entry'
    files = {name:digest((ROOT/name).read_bytes()) for name in entries}
    source_files = sorted(p for p in (ROOT/'source').iterdir() if p.suffix in {'.js','.json','.py','.css','.html'} and p.name!='index.html')
    source_hash = digest('\n'.join(p.name+':'+digest(p.read_bytes()) for p in source_files).encode())
    recursive_sources=source_inventory(ROOT)
    release = json.loads((ROOT/'source/version.json').read_text())
    fixture_paths=[]
    # --check in build_knowledge_graph.js compares every committed output,
    # including these two CSVs. They are acceptance inputs, not optional reports.
    for name in ['prerequisite-review-rc50.csv','knowledge-relations.csv']:
        fixture=ROOT/'docs'/name
        if not fixture.is_file():
            raise RuntimeError('Missing required knowledge graph fixture: '+name)
        fixture_paths.append(fixture)
    workflow=ROOT/'.github/workflows/rc78-acceptance.yml'
    if workflow.is_file():fixture_paths.append(workflow)
    fixture_paths.extend(p for p in (ROOT/'docs/rc78').rglob('*') if p.is_file() and p.suffix in {'.md','.json'} and not any(part.startswith('.') for part in p.relative_to(ROOT).parts))
    fixture_paths.extend(p for p in (ROOT/'docs/rc79').rglob('*') if p.is_file() and p.suffix in {'.md','.json'} and not any(part.startswith('.') for part in p.relative_to(ROOT).parts))
    for name in ['rc68-execution-manifest.json','rc69-execution-manifest.json','rc68-muse-closure-matrix.json','exam-review-ledger.csv','rtm1/child_form_disposition_500.json','rtm1/child_form_disposition_500.csv']:
        if (ROOT/'docs'/name).exists():fixture_paths.append(ROOT/'docs'/name)
    for name in ['rtm1/child_form_disposition.json','rtm1/child_form_disposition.csv',
                 'rtm1/child_form_disposition_650.json','rtm1/child_form_disposition_650.csv',
                 'rtm1/exam_disposition.csv','rtm1/exam_disposition_500.csv','rtm1/exam_disposition_650.csv',
                 'rtm1/supplemental-mapping-138-manifest.json',
                 'rtm1/skill_coverage_179.json','rtm1/training_reuse_review_95.json','rtm1/joint_application_gap_84.json']:
        if (ROOT/'docs'/name).exists():fixture_paths.append(ROOT/'docs'/name)
    for folder in ['evidence/rc68/baseline','evidence/rc68/holdout','evidence/2026-10-08-rc67-full/baseline','evidence/rc73/baseline','evidence/rc74/baseline']:
        fixture_paths.extend(p for p in (ROOT/'docs'/folder).rglob('*') if fixture_file(p))
    for name in ['rc68-main.html','cab77e6-qa.html']:
        if (ROOT/'docs/evidence/rc69/baseline'/name).exists():fixture_paths.append(ROOT/'docs/evidence/rc69/baseline'/name)
    fixtures={p.relative_to(ROOT).as_posix():digest(p.read_bytes()) for p in sorted(fixture_paths)}
    payload = {'schema':2,'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
               'sourceTreeHash':source_hash,'buildSha256':files['index.html'],'release':release,'files':files,
               'recursiveSourceHash':digest(canonical(recursive_sources)),'sourceFiles':recursive_sources,
               'mappingBuildId':json.loads((ROOT/'source/exam_runtime_index.json').read_text())['mappingBuildId'],
               'registrySha256':digest(canonical(scope)),'fixtures':fixtures,'seeds':SEEDS,
               'scope':{'families':143,'configurations':153,'answerable':151,'policyBlocked':2,'answerableInstances':755,'policyInstances':10,
                        'routes':len(scope['routes']),'enabledRoutes':sum(not r['policyBlocked'] for r in scope['routes'])},
               'independentAcceptance':'INDEPENDENT_PENDING','developmentAcceptance':'NOT_RUN'}
    payload['buildId'] = digest(canonical(payload))
    if out.exists():
        old = out/'release-contract.json'
        if old.exists() and json.loads(old.read_text()) == payload:return payload
        raise RuntimeError('Candidate directory exists with another identity; choose a new directory')
    out.mkdir(parents=True)
    for name in recursive_sources:
        dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,dest)
    shutil.copytree(ROOT/'qa',out/'qa',ignore=shutil.ignore_patterns('.*','__pycache__','*.pyc'))
    # Copy precisely the registered public fixtures, never transient output files.
    for name in fixtures:
        p=ROOT/name;dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    for name in files:
        p=out/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,p)
    (out/'scope.json').write_text(json.dumps(scope,ensure_ascii=False,indent=2)+'\n')
    (out/'release-contract.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    (out/'frozen-identity.json').write_text(json.dumps({k:payload[k] for k in ['sourceCommit','sourceTreeHash','buildSha256']},indent=2)+'\n')
    return payload

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--dry-run',action='store_true');a=p.parse_args()
    if a.dry_run:print(json.dumps({'out':str(a.out),'registry':registry()},ensure_ascii=False))
    else:print(json.dumps(freeze(a.out.resolve()),ensure_ascii=False,indent=2))
