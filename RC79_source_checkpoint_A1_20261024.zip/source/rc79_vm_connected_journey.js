'use strict';
// Expected responses come from independent Python fractions/enumeration/cell-set
// verifiers, never from the task's production expected-answer property.
const {assert,boot}=require('./rc79_test_support'),A=require('../docs/rc79/fixtures/independent-mapping-answers.json');
function active(a){return a.value('saved.rtm1?.sessions?.active')}
function response(a,{wrong=false,equivalent=false}={}){const t=active(a),expected=(t.kind==='training'?A.training:A.originals)[t.id];assert(expected!==undefined,'Independent answer missing: '+t.id);let input=expected;
 if(t.definition.answerContract.kind==='choice'){if(wrong)input=t.definition.options.find(o=>String(o.id??o.value)!==String(expected))?.id??'wrong_reference';a.click('rtmChoice',{value:String(input)})}else{input=wrong?'999999999':Array.isArray(expected)?expected.join(','):String(expected);if(equivalent&&!Array.isArray(expected)&&/^[\d./-]+$/.test(input))input='('+input+')+0';a.inputRtm(input)}a.click('rtmSubmit');assert.equal(active(a).feedback.outcome,wrong?'INCORRECT':'VERIFIED');return {id:t.id,kind:t.kind,input,mathKey:t.mathKey};
}
function journey(a,{profile='calculation',html=null,loads=null}={}){const trail=[],events=[],seen=new Set();for(let slot=1;slot<=10;slot++){
 const t=active(a);assert(t&&t.connectedGroupId);assert(!seen.has(t.mathKey));seen.add(t.mathKey);if(loads){const load=t.definition.load||{};if(loads.calculation&&load.calculation)assert(load.calculation<=loads.calculation);if(loads.reading&&load.reading)assert(load.reading<=loads.reading)}
 if(profile==='local-relations'){response(a,{wrong:true});a.click('rtmHint');events.push({slot,actions:['wrong-first','help']})}
 if(profile==='alternative-route'){a.click('rtmHint');events.push({slot,actions:['task-local-help','equivalent-response']})}
 if(profile==='refresh-skip'){a.click('rtmHint');const id=t.attemptId;const first=a.value('Object.keys(saved.rtm1.eventsById).length');a=boot(a.storage,2000000001000+slot,html);a.click('rtmConnectedResume');assert.equal(active(a).attemptId,id);assert(active(a).hintsOpen);assert.equal(a.value('Object.keys(saved.rtm1.eventsById).length'),first);events.push({slot,actions:['help','reload','resume-same-attempt']})}
 const solved=response(a,{equivalent:profile==='alternative-route'});trail.push({...solved,slot});a.click('rtmNext');
 }assert.equal(a.value('saved.rtm1.sessions.connected.status'),'completed');assert(a.root.innerHTML.includes('data-connected-summary'));assert.equal(a.value('TransferEvidenceStore.statistics(saved.rtm1).holdoutSubmitted'),0);a.click('rtmConnectedNew');assert(!seen.has(active(a).mathKey));return {a,questions:10,trail,events,solvedExcluded:true,profile};}
module.exports={active,response,journey};
