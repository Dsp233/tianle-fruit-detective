'use strict';
// Event/state tests of the compiled app. Native layout/audio remain separate.
const assert=require('assert/strict'),fs=require('fs'),cp=require('child_process');
const {boot}=require('./test_support'),M=require('./exam_mapping'),C=require('./connected_learning'),K=require('./skills.json'),V=require('./version.json'),S=require('./transfer_evidence_store');
const html=fs.readFileSync('qa/normal/index.html','utf8'),STORE='tianle_amc8_qa_normal_rc'+V.siteVersion.match(/rc\.(\d+)/)[1]+'_v1',rows=[];
const BASELINE=C.coverage();
function seed(examIds=['AMC8-2000-01'],extra={}){return {[STORE]:JSON.stringify({contentRevision:V.contentRevision,storageVersion:V.storageVersion,topicPractice:{sourceIds:['AMC8'],examIds,selectedTopicIds:K.units.map(u=>u.id)},competition:{attempts:[],extensions:[]},rtm1:S.fresh(),...extra})}}
function load(ids,extra){return boot(seed(ids,extra),2000000000000,html)}
function active(a){return a.value('saved.rtm1.sessions.active')}
function correct(a){const t=active(a),v=t.definition.answerContract.expected;if(t.definition.answerContract.kind==='choice')a.click('rtmChoice',{value:String(v)});else a.inputRtm(Array.isArray(v)?v.join(','):String(v));a.click('rtmSubmit');assert.equal(active(a).feedback.outcome,'VERIFIED')}
function test(caseId,fn){try{fn();rows.push({caseId,status:'PASS'})}catch(error){rows.push({caseId,status:'FAIL',error:error.stack})}}

test('same-start-button-connects-all-reviewed-originals-after-the-required-work',()=>{
 const ids=Object.keys(require('./child_form_reviews.json').problems).filter(id=>C.review(M.getProblem(id)).eligible);assert(ids.length>0);
 for(const id of ids){
  const a=load([id]);assert(a.root.innerHTML.includes('data-action="topicStart"'));assert(!a.root.innerHTML.includes('打开真题应用'));
  a.click('topicStart');assert.equal(a.value('view'),'examMapping',id);let count=0;const tasks=[];
  while(active(a).kind==='training'){
   const item=active(a);tasks.push(item.id);assert(!a.root.innerHTML.includes('换练习类型'));assert(!a.root.innerHTML.includes('rtmDiagnostic'));
   assert(!a.root.innerHTML.includes('data-rtm-help-figure'));assert(a.root.innerHTML.indexOf('competition-hints')<a.root.innerHTML.indexOf('<form'));
   a.click('rtmRead');assert.equal(a.spoken.at(-1),item.definition.prompt+' '+(item.definition.givenText||''));
   correct(a);a.click('rtmNext');assert(++count<8,id);
  }
  const target=active(a);assert.equal(target.examId,id);assert.equal(target.mode,'practice');assert.equal(target.connectedStage,'application');
  assert(target.readinessSnapshot.evidence.length>=3,id);assert.equal(target.readinessSnapshot.independentHoldout,false);assert(target.priorMethodHelp);
  assert.deepEqual(target.readinessSnapshot.evidence.map(e=>e.taskId).sort(),tasks.sort());
  correct(a);assert.equal(a.value('TransferEvidenceStore.statistics(saved.rtm1).holdoutSubmitted'),0);
  const before=a.value('Object.keys(saved.rtm1.eventsById).length');a.click('rtmSubmit');assert.equal(a.value('Object.keys(saved.rtm1.eventsById).length'),before);
  a.click('rtmNext');assert(a.root.innerHTML.includes('data-connected-summary'));assert.equal(a.value('saved.rtm1.sessions.connected.status'),'exhausted');
  assert.equal(a.value('TransferEvidenceStore.history(saved.rtm1).solvedMathKeys.includes(saved.rtm1.sessions.active.mathKey)'),true);
 }
});

test('source-givens-are-visible-before-help-and-missing-assets-close-delivery',()=>{
 const a=load(['AMC8-2009-03']);a.click('topicStart');while(active(a).kind==='training'){correct(a);a.click('rtmNext')}
 assert.equal(active(a).examId,'AMC8-2009-03');assert(a.root.innerHTML.includes('data-rtm-given-figure'));
 assert(!a.root.innerHTML.includes('data-rtm-help-figure'));assert(a.root.innerHTML.indexOf('data-rtm-given-figure')<a.root.innerHTML.indexOf('competition-hints'));
 assert(a.root.innerHTML.includes('data:image/png;base64,'));assert(!active(a).hintsOpen);
 const b=load(['AMC8-2009-03']);b.run('window.__AMC8_SOURCE_FIGURES={}');assert.equal(b.value('ExamMappingUI.connectedAvailability()'),0);
 b.click('topicStart');assert.equal(b.value('Object.keys(saved.rtm1.eventsById).length'),0);
});

test('exact-source-and-exam-scope-bounds-expensive-knowledge-checks',()=>{
 const a=load(['AMC8-2009-01']);
 a.run('window.scopeChecks={tasks:0,problems:0};window.oldTaskAllowed=ExamMapping.taskAllowed;window.oldProblemCheck=ExamMapping.check;ExamMapping.taskAllowed=function(...args){window.scopeChecks.tasks++;return window.oldTaskAllowed(...args)};ExamMapping.check=function(...args){window.scopeChecks.problems++;return window.oldProblemCheck(...args)}');
 assert.equal(a.value('ExamMappingUI.connectedAvailability()'),1);
 assert.equal(a.value('window.scopeChecks.tasks'),6);
 assert.equal(a.value('window.scopeChecks.problems'),2);
 a.run('saved.topicPractice.excludedSkillIds=["L02.01"]');
 assert.equal(a.value('ExamMappingUI.connectedAvailability()'),0);
 a.run('window.scopeChecks={tasks:0,problems:0};saved.topicPractice.sourceIds=["original"]');
 assert.equal(a.value('ExamMappingUI.connectedAvailability()'),0);
 assert.deepEqual(a.value('window.scopeChecks'),{tasks:0,problems:0});
});

test('wrong-or-skipped-work-does-not-unlock-an-original',()=>{
 const a=load();a.click('topicStart');const first=active(a);a.click('rtmChoice',{value:'wrong_reference'});a.click('rtmSubmit');assert.equal(active(a).feedback.outcome,'INCORRECT');
 a.click('rtmNext');assert.equal(a.value('saved.rtm1.sessions.connected.status'),'exhausted');
 assert.equal(a.value('Object.values(saved.rtm1.eventsById).filter(e=>e.type==="problem_presented"&&e.examId).length'),0);
 assert(a.value('saved.rtm1.sessions.connected.deferredExamIds').includes('AMC8-2000-01'));
 a.click('rtmConnectedNew');assert.equal(active(a).id,first.id);correct(a);
 assert.equal(a.value('TransferEvidenceStore.instance(saved.rtm1,saved.rtm1.sessions.active.mathKey).firstSubmission.input'),'wrong_reference');
});

test('parent-review-counts-traverse-current-snapshots-once-without-stale-caching',()=>{
 const a=load();
 a.run('window.coverageCalls=0;window.coverageCanonicalCalls=0;window.originalCoverage=ConnectedLearning.coverage;window.originalCoverageCanonical=ExamMapping.canonical;ConnectedLearning.coverage=function(...args){window.coverageCalls++;return window.originalCoverage(...args)};ExamMapping.canonical=function(...args){window.coverageCanonicalCalls++;return window.originalCoverageCanonical(...args)}');
 assert.deepEqual(a.value('ConnectedLearning.coverage()'),BASELINE);
 const snapshotBudget=a.value('Object.values(window.__AMC8_CHILD_FORMS.problems).filter(p=>p.status==="REVIEWED").reduce((n,p)=>n+2*(1+Object.keys(p.tasks).length),0)');
 assert(a.value('window.coverageCanonicalCalls')<=snapshotBudget,'One snapshot comparison per approved original and task');
 a.run('window.coverageCalls=0');a.click('rtmOpen');
 assert.equal(a.value('window.coverageCalls'),1);assert(a.root.innerHTML.includes(BASELINE.reviewed+' 题'));assert(a.root.innerHTML.includes(BASELINE.pending+' 题'));
 a.run('ExamMapping.data.problems["AMC8-2000-01"].presentation.prompt+="（审校快照已变化）";window.coverageCalls=0');a.click('rtmOpen');
 assert.equal(a.value('window.coverageCalls'),1);assert(a.root.innerHTML.includes((BASELINE.reviewed-1)+' 题'));assert(a.root.innerHTML.includes('需复审 1 题'));
 assert.deepEqual(a.value('ConnectedLearning.coverage()'),{...BASELINE,reviewed:BASELINE.reviewed-1,stale:BASELINE.stale+1,assessed:BASELINE.assessed-1});
});

test('two-judgments-without-integration-are-insufficient',()=>{
 const a=load();a.click('topicStart');for(let i=0;i<2;i++){correct(a);a.click('rtmNext')}
 assert.equal(active(a).definition.role,'integration');a.click('rtmNext');
 assert.equal(a.value('Object.values(saved.rtm1.eventsById).some(e=>e.type==="problem_presented"&&e.examId)'),false);
});

test('assisted-readiness-is-application-and-preserves-first-response',()=>{
 const a=load();a.click('topicStart');a.click('rtmChoice',{value:'wrong_reference'});a.click('rtmSubmit');a.click('rtmHint');correct(a);a.click('rtmNext');
 while(active(a).kind==='training'){correct(a);a.click('rtmNext')}
 const evidence=active(a).readinessSnapshot.evidence;assert(evidence.some(e=>e.usedHelp&&!e.firstCorrect));
 correct(a);assert.equal(active(a).mode,'practice');assert.equal(a.value('TransferEvidenceStore.statistics(saved.rtm1).holdoutFirstUnassistedCorrect'),0);
 const response=a.value('TransferEvidenceStore.attempt(saved.rtm1,saved.rtm1.sessions.active.attemptId).firstSubmission');assert(response.supportSnapshot.methodHelpCount>0);
});

test('refresh-retains-original-snapshot-but-resumes-only-with-current-eligibility',()=>{
 const a=load();a.click('topicStart');a.click('rtmHint');a.click('rtmChoice',{value:'wrong_reference'});const before=active(a),originalProfile=before.profileSnapshot;a.click('rtmBack');a.run('saved.topicPractice.selectedTopicIds=[];saved.topicPractice.sourceIds=[];saved.topicPractice.examIds=["AMC8-2023-09"];persist()');const b=boot(a.storage,2000000001000,html);b.click('rtmConnectedResume');assert.equal(active(b).attemptId,before.attemptId);assert.equal(active(b).input,'wrong_reference');assert(active(b).hintsOpen);assert.deepEqual(active(b).profileSnapshot,originalProfile);assert(b.root.innerHTML.includes('data-rtm-scope-paused'));const events=b.value('saved.rtm1.eventsById');b.click('rtmSubmit');b.click('rtmHint');assert.deepEqual(b.value('saved.rtm1.eventsById'),events);b.click('rtmBack');for(const code of K.units.map(u=>u.id))b.click('topicSelect',{code});b.click('sourceToggle',{code:'AMC8'});b.click('sourceExamClear');b.click('sourceExamToggle',{code:'AMC8-2000-01'});b.click('rtmConnectedResume');assert.equal(active(b).attemptId,before.attemptId);while(active(b).kind==='training'){correct(b);b.click('rtmNext')}assert.equal(active(b).examId,'AMC8-2000-01');assert.deepEqual(active(b).profileSnapshot,originalProfile);
});

test('changed-knowledge-source-exam-or-load-does-not-create-an-illegal-route',()=>{
 const a=load();assert.equal(a.value('ExamMappingUI.connectedAvailability()'),1);
 for(const mutation of ['saved.topicPractice.excludedSkillIds=["L02.01"]','saved.topicPractice.sourceIds=[]','saved.topicPractice.examIds=["AMC8-2008-21"]','saved.topicPractice.maxCalculationLoad=1','saved.topicPractice.maxReadingLoad=1']){
  const b=load();b.run(mutation);assert.equal(b.value('ExamMappingUI.connectedAvailability()'),0,mutation);
 }
});

test('parent-selector-shows-650-mapped-exams-and-keeps-child-review-separate',()=>{
 const a=load([]);assert(a.root.innerHTML.includes('data-source-exam-picker'));
 const chooser=a.root.innerHTML.match(/<select data-source-exam-picker[\s\S]*?<\/select>/)[0];assert.equal((chooser.match(/<option value="AMC8-/g)||[]).length,650);assert.equal((chooser.match(/<option value="AMC8-[^"]+" disabled>/g)||[]).length,0);
 a.click('sourceExamToggle',{code:'AMC8-2026-01'});assert.deepEqual(a.value('saved.topicPractice.examIds'),['AMC8-2026-01']);a.click('sourceExamToggle',{code:'AMC8-2026-01'});assert.deepEqual(a.value('saved.topicPractice.examIds'),[]);
 a.click('sourceExamToggle',{code:'AMC8-2000-01'});assert.deepEqual(a.value('saved.topicPractice.examIds'),['AMC8-2000-01']);assert.equal(a.value('ExamMappingUI.connectedAvailability()'),1);
 a.click('sourceExamClear');a.click('sourceExamToggle',{code:'AMC8-2023-09'});assert.equal(a.value('ExamMappingUI.connectedAvailability()'),1);
 a.click('sourceExamClear');a.click('sourceExamToggle',{code:'AMC8-2008-21'});assert.equal(a.value('ExamMappingUI.connectedAvailability()'),0);
});

test('unreviewed-original-cannot-fall-through-to-the-legacy-child-pool',()=>{
 const a=load(['AMC8-2000-23']);a.run('window.__AMC8_CHILD_FORMS.problems["AMC8-2000-23"]={status:"PENDING"}');assert.equal(a.value('ExamMappingUI.connectedAvailability()'),0);
 a.click('topicStart');assert.equal(a.value('view'),'home');assert.equal(a.value('topicSession()'),null);assert.equal(a.value('Object.keys(saved.rtm1.eventsById).length'),0);
 const b=load([],{topicPractice:{selectedTopicIds:K.units.map(u=>u.id),sourceIds:['original'],examIds:[]}});b.click('topicStart');assert.equal(b.value('view'),'competition');
 assert.equal(b.value('taskNow().competition.sourceProvenance.sourceId'),'original');
});

test('mapped-exam-with-pending-child-form-in-saved-settings-stays-closed-and-can-be-removed',()=>{
 const a=load(['AMC8-2026-12']);a.run('window.__AMC8_CHILD_FORMS.problems["AMC8-2026-12"]={status:"PENDING"};render()');assert.equal(a.value('ExamMappingUI.connectedAvailability()'),0);
 a.click('topicStart');assert.equal(a.value('view'),'home');assert.equal(a.value('topicSession()'),null);
 assert.equal(a.value('Object.keys(saved.rtm1.eventsById).length'),0);
 a.click('sourceExamToggle',{code:'AMC8-2026-12'});assert.deepEqual(a.value('saved.topicPractice.examIds'),[]);
});

test('parent-catalog-lists-26-years-and-distinguishes-math-and-child-review',()=>{
 const a=load([]);a.click('catalog');assert.equal(a.value('view'),'catalog');
 assert(a.root.innerHTML.includes('26 届 · 650 题'));assert(a.root.innerHTML.includes('完成解法与训练映射 650 题'));
 a.run('filterYear="2026";catalogPage=0;render()');assert(a.root.innerHTML.includes('当前 25 题'));
 assert.equal((a.root.innerHTML.match(/class="catalog-item"/g)||[]).length,25);
 a.run('filterYear="";filterTopic="__pending__";catalogPage=0;render()');assert(a.root.innerHTML.includes('当前 0 题'));
 assert(!a.root.innerHTML.includes('本轮已核原题与独立解法'));
});

test('old-original-draft-remains-recorded-without-a-child-resume-bypass',()=>{
 const debugHtml=fs.readFileSync('qa/index.html','utf8'),old=boot({},2000000000000,debugHtml);
 old.run('saved.topicPractice.selectedTopicIds='+JSON.stringify(K.units.map(u=>u.id))+';saved.topicPractice.examIds=["AMC8-2000-23"];saved.topicPractice.sourceIds=["AMC8"]');old.click('topicStart');assert.equal(old.value('view'),'competition');
 const before=old.value('saved'),a=boot({[STORE]:JSON.stringify(before)},2000000001000,html),session=a.value('saved.topicPractice.session');
 assert(!a.root.innerHTML.includes('data-action="topicResume"'));a.click('topicResume');assert.equal(a.value('view'),'home');assert(a.root.innerHTML.includes('旧真题草稿已保留'));assert.deepEqual(a.value('saved.topicPractice.session'),session);
});

test('presentation-approval-is-independent-and-invalidates-on-content-change',()=>{
 const a=load(['AMC8-2023-09','AMC8-2020-04','AMC8-2023-01']);assert.equal(a.value('ExamMappingUI.connectedAvailability()'),3);
 a.run('for(const id of ["AMC8-2023-09","AMC8-2020-04","AMC8-2023-01"])window.__AMC8_CHILD_FORMS.problems[id]={status:"PENDING"};render()');assert.equal(a.value('ExamMappingUI.connectedAvailability()'),0);
 for(const mutation of ['ExamMapping.data.problems["AMC8-2000-01"].presentation.prompt+="额外条件"','ExamMapping.data.tasks["RTM-2000-01-INTEGRATION"].options=[{id:"x",text:"16"}]','ExamMapping.data.tasks["RTM-2000-01-CONTRAST"].prompt="哪个答案正确？"','ExamMapping.data.routes["AMC8-2000-01:facts-to-goal"].requiredKnowledge.push("G01.01")','ExamMapping.data.bindings["B-AMC8-2000-01-choose"].matchLevel="NO_MATCH"']){
  const b=load();b.run(mutation);assert.equal(b.value('ExamMappingUI.connectedAvailability()'),0,mutation);
 }
});

test('presentation-fixes-keep-variation-hints-and-condition-context-local',()=>{
 const a=load(['AMC8-2000-01']);a.click('topicStart');a.click('rtmHint');assert(!a.root.innerHTML.includes('小5岁'));assert(!a.spoken.some(x=>x.includes('小5岁')));
 const b=load(['AMC8-2020-01']);b.click('topicStart');correct(b);b.click('rtmNext');assert(active(b).definition.prompt.includes('糖是柠檬汁的2倍'));assert(!b.root.innerHTML.includes('换练习类型'));
 const c=load(['AMC8-2023-10']);c.click('topicStart');while(active(c).kind==='training'){correct(c);c.click('rtmNext')}
 assert(active(c).definition.prompt.includes('驼鹿吃掉余下的1/2'));assert.equal(active(c).definition.answerContract.expected,'1/4');
});

test('original-requires-evidence-for-exact-reviewed-presentations',()=>{
 const a=load();a.click('topicStart');correct(a);a.click('rtmNext');correct(a);a.click('rtmNext');correct(a);
 a.run('for(const e of Object.values(saved.rtm1.eventsById))if(e.type==="response_submitted")delete e.taskEvidenceKey');
 a.click('rtmNext');assert.equal(a.value('Object.values(saved.rtm1.eventsById).some(e=>e.type==="problem_presented"&&e.examId)'),false);
});

test('ten-question-boundary-keeps-preparation-for-the-following-group',()=>{
 const a=load([]);a.click('topicStart');const ids=[];
 for(let i=0;i<10;i++){const item=active(a);assert(!ids.includes(item.mathKey));ids.push(item.mathKey);correct(a);a.click('rtmNext')}
 assert.equal(a.value('saved.rtm1.sessions.connected.status'),'completed');assert(a.root.innerHTML.includes('data-connected-summary'));
 const count=a.value('Object.values(saved.rtm1.eventsById).filter(e=>e.type==="problem_presented").length');assert.equal(count,10);
 a.click('rtmConnectedNew');assert.equal(a.value('saved.rtm1.sessions.connected.attemptIds.length'),1);assert(!ids.includes(active(a).mathKey));
});

test('quota-failure-does-not-count-a-prompt-that-was-never-committed',()=>{
 const a=load(),before=a.storage[STORE];a.run('localStorage.setItem=()=>{throw Object.assign(new Error("quota fixture"),{name:"QuotaExceededError"})}');a.click('topicStart');
 assert.equal(a.storage[STORE],before);assert.equal(a.value('saved.rtm1.sessions.active'),undefined);assert.equal(a.value('Object.keys(saved.rtm1.eventsById).length'),0);
});

test('mapping-version-change-preserves-the-old-draft-without-promotion',()=>{
 const a=load();a.click('topicStart');const id=active(a).attemptId;a.run('ExamMapping.data.mappingBuildId="new-content-fixture"');a.click('rtmBack');a.click('rtmConnectedResume');
 assert(a.root.innerHTML.includes('内容版本发生变化'));assert.equal(active(a).attemptId,id);assert.equal(a.value('Object.values(saved.rtm1.eventsById).filter(e=>e.type==="response_submitted").length'),0);
});

test('malformed-connected-session-is-retained-and-cannot-bypass-scope',()=>{
 const a=load();a.click('topicStart');const original=active(a);a.run('saved.rtm1.sessions.connected.profileSnapshot.declaredSkillIds=[];persist()');
 const b=boot(a.storage,2000000001000,html);assert.equal(b.value('ExamMappingUI.connectedStatus()'),null);assert(!b.root.innerHTML.includes('rtmConnectedResume'));
 b.click('rtmOpen');assert(b.root.innerHTML.includes('资料不完整'));b.click('rtmBack');b.click('topicStart');
 assert.notEqual(active(b).attemptId,original.attemptId);assert.equal(b.value('saved.rtm1.sessions.connectedArchive.length'),1);
});

test('review-data-reproduces-from-explicit-editorial-decisions',()=>{
 const result=cp.execFileSync('python3',['-c','import sys,json,runpy;sys.path.insert(0,"source"); m=runpy.run_path("source/author_child_form_reviews.py"); assert m["materialize"]()==json.load(open("source/child_form_reviews.json")); print("PASS")'],{encoding:'utf8'});assert(result.includes('PASS'));
 assert.equal(C.coverage().mapped,650);assert.equal(C.coverage().reviewed,BASELINE.reviewed);assert.equal(C.coverage().pending,BASELINE.pending);
});

test('history-keeps-each-attempts-first-answer-and-readonly-source-material',()=>{
 const a=load(['AMC8-2009-03']);a.click('rtmOpen');a.click('rtmStart',{mode:'practice'});
 const first=active(a);assert.equal(first.kind,'exam');a.inputRtm('0');a.click('rtmSubmit');
 assert.notEqual(active(a).feedback.outcome,'VERIFIED');a.click('rtmStart',{mode:'practice'});
 const second=active(a);assert.notEqual(second.attemptId,first.attemptId);correct(a);
 a.run('saved.rtm1.sessions.active.definition.givenTable=[[1,2],[3,4]]');
 a.click('rtmRead');assert(a.spoken.at(-1).includes('数据表第2行：3，4'));
 const before=a.value('JSON.stringify(saved.rtm1)');a.click('rtmHistory');a.click('rtmReview',{id:first.attemptId});
 assert(a.root.innerHTML.includes('本次尝试首次提交：0'));assert(a.root.innerHTML.includes('data-rtm-given-figure'));
 assert(!a.root.innerHTML.includes('data-rtm-form'));assert(!a.root.innerHTML.includes('data-action="rtmChoice"'));
 a.click('rtmReview',{id:second.attemptId});assert(a.root.innerHTML.includes('本次尝试首次提交：'+second.definition.answerContract.expected));
 assert(a.root.innerHTML.includes('data-rtm-given-table'));assert(a.root.innerHTML.includes('<td>4</td>'));
 assert.equal(a.value('JSON.stringify(saved.rtm1)'),before);
 assert.equal(a.value('TransferEvidenceStore.instance(saved.rtm1,saved.rtm1.sessions.active.mathKey).firstSubmission.input'),'0');
});

test('restricted-review-is-an-assessed-conclusion-and-never-automatic-supply',()=>{
 const a=load();a.run('window.__AMC8_CHILD_FORMS.problems["AMC8-2000-01"].status="REVIEWED_RESTRICTED";window.__AMC8_CHILD_FORMS.problems["AMC8-2000-01"].restrictionReason="fixture restriction"');
 assert.equal(a.value('ConnectedLearning.coverage().restricted'),BASELINE.restricted+1);
 assert.equal(a.value('ConnectedLearning.coverage().pending'),BASELINE.pending);
 assert.equal(a.value('ExamMappingUI.connectedAvailability()'),0);
 a.click('rtmStart',{mode:'practice'});assert.equal(a.value('Object.keys(saved.rtm1.eventsById).length'),0);
});

test('frozen-saved-journals-support-reads-and-the-entire-connected-path',()=>{
 const a=load();a.click('topicStart');
 a.run('window.freezeJournal=function(value){if(value&&typeof value==="object"&&!Object.isFrozen(value)){for(const child of Object.values(value))window.freezeJournal(child);Object.freeze(value)}return value};window.journalWriter=localStorage.setItem;localStorage.setItem=function(...args){window.journalWriter.apply(this,args);window.freezeJournal(saved.rtm1)}');
 let attempts=0;
 while(true){
  const item=active(a),before=a.value('JSON.stringify(saved.rtm1)');
  a.run('window.freezeJournal(saved.rtm1);ExamMappingUI.page();ExamMappingUI.history();ExamMappingUI.connectedStatus();ExamMappingUI.exportDraft()');
  assert.equal(a.value('JSON.stringify(saved.rtm1)'),before);
  a.click('rtmRead');a.click('rtmHint');a.inputRtm('wrong reference');a.click('rtmSubmit');correct(a);
  assert.equal(a.value('TransferEvidenceStore.instance(saved.rtm1,saved.rtm1.sessions.active.mathKey).firstSubmission.input'),'wrong reference');
  a.run('window.freezeJournal(saved.rtm1)');a.click('rtmNext');assert(++attempts<6);
  if(item.kind==='exam')break;
 }
 assert.equal(active(a).examId,'AMC8-2000-01');assert.equal(a.value('saved.rtm1.sessions.connected.status'),'exhausted');
 assert.equal(a.value('TransferEvidenceStore.statistics(saved.rtm1).firstUnassistedCorrect'),0);
});

test('failed-next-step-keeps-the-saved-connected-target-and-journal',()=>{
 const a=load();a.click('topicStart');correct(a);a.click('rtmModes');
 const before=a.value('JSON.stringify(saved.rtm1)'),disk=a.storage[STORE];
 a.run('localStorage.setItem=()=>{throw Error("quota fixture")}');a.click('rtmNext');
 assert.equal(a.value('JSON.stringify(saved.rtm1)'),before);assert.equal(a.storage[STORE],disk);
});

const report={result:rows.every(r=>r.status==='PASS')?'PASS':'FAIL',coverage:C.coverage(),rows,scope:'bundled DOM/event/state harness; native browser and real learning effects not measured'};
console.log(JSON.stringify(report,null,2));if(report.result!=='PASS')process.exitCode=1;
