'use strict';
const assert=require('assert'),fs=require('fs'),{save}=require('./rc68_evidence'),Sources=require('./source_catalog'),S=require('./structured_recipes'),skills=require('./skills.json');
const {COMPETITION_REVIEWED:families,competitionCreate:create}=require('./competition_reviewed'),{boot}=require('./test_support');
const all=skills.units.map(u=>u.id),report=[],failures=[],qaHtml=fs.readFileSync('qa/index.html','utf8');let cases=0;
for(const [familyId,def]of Object.entries(Sources.definitions).filter(([,v])=>v.examId)){
 try{
  const pool=Sources.eligible(families,{topicIds:all,sourceIds:['AMC8'],examIds:[def.examId]});const blocked=familyId==='signedProduct';assert.equal(pool.length,blocked?0:1);if(!blocked){assert.equal(pool[0].id,familyId);assert.equal(pool[0].configurationId,def.configId)}
  const task=create({engine:3,generatorRevision:4,familyId,configurationId:def.configId,seed:1});assert.equal(task.competition.sourceProvenance.examId,def.examId);cases++;
  for(const route of def.routes){const exact=Sources.allowedRoutes(def.routes,route.requiredSkills);assert.equal(exact.some(x=>x.id===route.id),!blocked);cases++;
   for(const skill of route.requiredSkills){assert(!Sources.allowedRoutes([route],route.requiredSkills.filter(x=>x!==skill)).length);cases++}
   const extra=Sources.allowedRoutes(def.routes,[...route.requiredSkills,skills.skills.find(s=>!route.requiredSkills.includes(s.id)).id]);assert.equal(extra.some(x=>x.id===route.id),!blocked);cases++;
  }
  if(familyId==='signedProduct'){const category=def.routes[0].requiredSkills,allowed=Sources.allowedRoutes(def.routes,category);assert.equal(allowed.length,0);assert(def.routes.every(r=>r.unverifiedKnowledge.some(g=>g.id==='negative-integer-products')));cases++}
  const app=boot({},2000000000000,qaHtml);app.run('window.AMC8_QA.loadCase('+JSON.stringify({familyId,configuration:def.configId,seed:1,generatorRevision:4})+',true)');assert.equal(app.value('taskNow().id'),task.id);assert.equal(app.value('taskNow().prompt'),task.prompt);assert(app.root.innerHTML.includes(require('./competition_content_contracts').resolve(task).promptText));if(!blocked){app.click('competitionHint');assert(app.root.innerHTML.includes('competition-hint'));}cases++;
  report.push({examId:def.examId,familyId,configurationId:def.configId,result:'passed',teachingEligibility:blocked?'BLOCKED_UNTAUGHT_NEGATIVE_MULTIPLICATION':'AVAILABLE',routes:def.routes.map(r=>({id:r.id,requiredSkills:r.requiredSkills}))});
 }catch(e){failures.push({familyId,error:e.message})}
}
try{
 assert.equal(Sources.eligible(families,{topicIds:all,sourceIds:['AMC8']}).length,3);assert(Sources.eligible(families,{topicIds:all,sourceIds:['AMC8']}).every(x=>x.sourceId==='AMC8'));assert.equal(Sources.eligible(families,{topicIds:[],sourceIds:['AMC8']}).length,0);assert.equal(Sources.eligible(families,{topicIds:all,sourceIds:['AMC8'],examIds:['AMC8-2000-01']}).length,0);cases+=3;
 const app=boot();app.click('topicSelect',{code:'G03'});app.click('topicStart');assert.equal(app.value('view'),'home');assert(app.root.innerHTML.includes('data-pool-status="NO_REVIEWED_CONNECTED_SUPPLY"'));cases++;
 app.run('saved.topicPractice.selectedTopicIds='+JSON.stringify(all));app.click('sourceToggle',{code:'original'});app.click('sourceExamToggle',{code:'AMC8-2000-23'});const settings=app.value('saved.topicPractice');const restored=boot(app.storage);assert.deepStrictEqual(restored.value('saved.topicPractice.sourceIds'),settings.sourceIds);assert.deepStrictEqual(restored.value('saved.topicPractice.examIds'),settings.examIds);assert.deepStrictEqual(restored.value('saved.topicPractice.selectedTopicIds'),all);cases++;
 app.click('topicStart');assert.equal(app.value('view'),'examMapping');assert.equal(app.value('saved.rtm1.sessions.active.originProblemGroupId'),'AMC8-2000-23');cases++;
 const noFraction=Sources.eligible(families,{topicIds:all.filter(id=>id!=='A03'),sourceIds:['AMC8'],examIds:['AMC8-2000-23']});assert.equal(noFraction.length,0);cases++;
 const ledger=require('./source_supply.json').ledger,baseline=fs.readFileSync('docs/exam-review-ledger.csv');assert.equal(ledger.length,650);assert.equal(new Set(ledger.map(r=>r.examId)).size,650);assert(ledger.every(r=>r.reviewStatus&&r.supplyStatus!=='simulation_ready'));cases++;
}catch(e){failures.push({case:'scope-persistence',error:e.message})}
for(const [familyId,routeId,hidden]of [['lShapeArea','disjoint-strips','推得边长后补形'],['signedProduct','sign-categories','完整枚举']]){try{
 const t=create({engine:3,familyId,configurationId:S.sourceConfigs[familyId],generatorRevision:4,seed:1}),r=Sources.taskRoutes(t).find(r=>r.id===routeId),excluded=skills.skills.filter(s=>!r.requiredSkills.includes(s.id)).map(s=>s.id),a=boot({},2000000000000,qaHtml);
 a.run('window.AMC8_QA.loadCase('+JSON.stringify({familyId,configuration:S.sourceConfigs[familyId],generatorRevision:4,seed:1,topicIds:all,excludedSkillIds:excluded})+',true)');
 if(familyId==='signedProduct'){assert(!Sources.taskAllowed(t,{topicIds:all}).length);assert(a.value('competitionScopedContent(taskNow()).scopeBlocked'));a.click('competitionPick',{index:String(t.answer)});a.click('check');assert.equal(a.value('feedback.status'),'unsupported_scope');assert(!a.value('topicCurrent().passed'));assert(!a.value('saved.competition.attempts.length'));assert(a.root.innerHTML.includes('负数乘法'));cases+=7;continue;}
 assert.deepStrictEqual(a.value('SourceCatalog.taskAllowed(taskNow(),{topicIds:topicSession().topicIds,excludedSkillIds:saved.topicPractice.excludedSkillIds}).map(r=>r.id)'),[routeId]);a.click('competitionHint');assert.equal(a.value('competitionScopedContent(taskNow()).hints[0]'),t.competition.routes.find(r=>r.id===routeId).nodes[0].prompt);
 a.click('competitionPick',{index:String(t.answer)});a.click('check');a.click('competitionShowSolution');assert(!a.root.innerHTML.includes(hidden));assert.equal(a.value('competitionScopedContent(taskNow()).methods.length'),1);a.click('competitionReadStep',{index:'0'});assert(a.spoken.length);
 a.click('competitionIndependentVariation');a.inputCompetition('extension',t.competition.extension.answer);a.click('competitionExtensionCheck');assert(a.value('saved.competition.extensions.at(-1).correct'));if(familyId==='signedProduct')assert(!a.value('competitionScopedContent(taskNow()).extension.solution').includes('列举'));cases+=7;
}catch(e){failures.push({familyId,routeId,error:e.message})}}
save('sources/acceptance',{result:failures.length?'failed':'passed',cases,anchors:report,failures,limits:['Actual Node production handlers and DOM; real browser source controls still required','Original configurations have developer use contracts; semantic, native and independent teaching acceptance remain pending']});if(failures.length)process.exitCode=1;
