'use strict';
// Full bundled application in the existing deterministic event harness.
// This is DOM/event/state coverage, explicitly not native browser or audio QA.
const fs=require('fs'),assert=require('assert/strict'),path=require('path');
const {boot}=require('./test_support'),K=require('./skills.json'),V=require('./version.json'),M=require('./exam_mapping');
const release=V.siteVersion.match(/rc\.(\d+)/)[1],STORE='tianle_amc8_qa_normal_rc'+release+'_v1';
const html=fs.readFileSync('qa/normal/index.html','utf8'),rows=[];
const inspectionHtml=fs.readFileSync('qa/index.html','utf8'),inspectionStore='tianle_amc8_qa_rc'+release+'_v1';
function load(examIds=[],extra={},inspection=false){
 const seed={contentRevision:V.contentRevision,storageVersion:V.storageVersion,
  topicPractice:{sourceIds:['AMC8'],examIds,selectedTopicIds:K.units.map(u=>u.id),nextSeed:1},
  competition:{attempts:[],extensions:[]},rtm1:{schemaVersion:1,eventsById:{},sessions:{nextSeed:1}},...extra};
 const a=boot({[inspection?inspectionStore:STORE]:JSON.stringify(seed)},2000000000000,inspection?inspectionHtml:html);a.click('rtmOpen');return a;
}
function active(a){return a.value('saved.rtm1.sessions.active')}
function submit(a,value){const current=active(a),c=current.definition.answerContract;
 if(c.kind==='choice')a.click('rtmChoice',{value:String(value)});else a.inputRtm(Array.isArray(value)?value.join(','):String(value));a.click('rtmSubmit');
}
function correct(a){submit(a,active(a).definition.answerContract.expected)}
function test(caseId,fn){try{fn();rows.push({caseId,status:'PASS'})}catch(error){rows.push({caseId,status:'FAIL',error:error.stack})}}

test('candidate-production-entry-enabled-for-predeployment-verification',()=>{
 const production=fs.readFileSync('index.html','utf8'),a=boot({},2000000000000,production);assert.equal(a.value('ExamMappingUI.enabled()'),true);a.click('topicStart');assert.equal(a.value('view'),'home');assert(!a.value('saved.rtm1?.sessions?.active'));assert.equal(a.value('saved.topicPractice.selectedTopicIds.length'),0);
});

test('inspection-surface-renders-every-math-eligible-original-without-granting-child-approval',()=>{
 const a=load([],{},true),expected=Object.values(M.data.problems).filter(p=>p.status.runtimeStatus==='eligible'),seen=new Set();
 assert.equal(expected.length,614);
 for(const p of expected){
  a.run('saved.topicPractice.examIds='+JSON.stringify([p.examId]));a.click('rtmStart',{mode:'practice'});
  const key=p.recipe?require('./competition_identity').key(require('./competition_reviewed').competitionCreate(p.recipe)):M.problemKey(p);
  if(seen.has(key)){
   assert(a.root.innerHTML.includes('没有合格的新题'),p.examId);
   const isolated=load([p.examId],{},true);isolated.click('rtmStart',{mode:'practice'});correct(isolated);
   assert.equal(active(isolated).examId,p.examId);assert.equal(active(isolated).feedback.outcome,'VERIFIED');continue;
  }
  seen.add(key);
  assert.equal(active(a).examId,p.examId);assert(active(a).shown);
  correct(a);assert.equal(active(a).feedback.outcome,'VERIFIED',p.examId);
  a.click('rtmNext');assert(active(a).finished);assert(a.root.innerHTML.includes('没有合格的新题'));
 }
 assert.equal(seen.size,expected.length-1,'the reviewed 2004/2012 remainder alias shares one full mathematical identity');
 assert.equal(a.value('TransferEvidenceStore.statistics(saved.rtm1).submitted'),seen.size);
 assert.equal(a.value('TransferEvidenceStore.statistics(saved.rtm1).holdoutSubmitted'),0);
});

test('legacy-cross-year-wrong-answer-and-hint-carry-into-alternate-version',()=>{
 const S=require('./transfer_evidence_store'),oldKey='rtm:'+M.canonical(M.getProblem('AMC8-2004-19').mathFacts);
 let journal=S.fresh();
 const base={attemptId:'legacy-alias',mathKey:oldKey,mappingBuildId:'legacy-alias-build',at:1000,originProblemGroupId:'AMC8-2004-19',presentationKind:'equivalent_translation',mode:'practice'};
 for(const e of [
  {...base,eventId:'old-alias:1',sequence:1,type:'problem_presented'},
  {...base,eventId:'old-alias:2',sequence:2,type:'response_submitted',submissionOrdinal:1,input:'A',result:{outcome:'INCORRECT'}},
  {...base,eventId:'old-alias:3',sequence:3,type:'hint_revealed'}]){const r=S.append(journal,e);assert(r.ok);journal=r.state}
 const oldEvents=JSON.stringify(journal.eventsById),closed=load(['AMC8-2012-15'],{rtm1:journal});
 closed.run('window.__AMC8_CHILD_FORMS.problems["AMC8-2012-15"]={status:"PENDING"}');
 closed.click('rtmStart',{mode:'practice'});assert.equal(active(closed),undefined);
 const a=load(['AMC8-2012-15'],{rtm1:journal},true);
 a.click('rtmStart',{mode:'exam_holdout'});assert.equal(active(a),undefined);assert(a.root.innerHTML.includes('没有合格的新题'));
 a.click('rtmStart',{mode:'practice'});assert.equal(active(a).examId,'AMC8-2012-15');assert(active(a).priorExposure);assert(active(a).priorMethodHelp);
 correct(a);assert.equal(active(a).feedback.outcome,'VERIFIED');
 assert.equal(a.value('TransferEvidenceStore.instance(saved.rtm1,saved.rtm1.sessions.active.mathKey).firstSubmission.input'),'A');
 assert.equal(a.value('TransferEvidenceStore.statistics(saved.rtm1).firstUnassistedCorrect'),0);
 assert.equal(JSON.stringify(Object.fromEntries(Object.entries(a.value('saved.rtm1.eventsById')).filter(([k])=>k.startsWith('old-alias:')))),oldEvents);
});

test('training-reserves-target-before-display-and-reaches-independent-original',()=>{
 const a=load(['AMC8-2000-01','AMC8-2001-03']);a.click('rtmPathway');
 const assignment=a.value('Object.values(saved.rtm1.assignmentsById)[0]');assert(assignment);
 assert.equal(active(a).originProblemGroupId,'AMC8-2000-01');
 assert.equal(assignment.holdoutExamId,'AMC8-2001-03');
 assert(!a.root.innerHTML.includes('AMC8-2001-03')); // No target or method label before the test.
 const frozen=JSON.stringify(assignment),training=[];
 while(active(a).pathwayStage==='training'){
  const current=active(a);assert(!training.includes(current.id));training.push(current.id);
  correct(a);a.click('rtmNext');assert(training.length<=3);
 }
 assert.equal(training.length,3);assert.equal(active(a).mode,'exam_holdout');assert.equal(active(a).examId,assignment.holdoutExamId);
 correct(a);
 const stats=a.value('TransferEvidenceStore.statistics(saved.rtm1)');
 assert.equal(stats.holdoutSubmitted,1);assert.equal(stats.holdoutFirstUnassistedCorrect,1);
 assert.equal(active(a).feedback.level,null);assert.equal(JSON.stringify(a.value('Object.values(saved.rtm1.assignmentsById)[0]')),frozen);
 a.click('rtmNext');assert.equal(a.value('saved.rtm1.sessions.pathway.stage'),'completed');
});

test('cross-representation-area-pathway-keeps-independent-origins',()=>{
 const closed=load(['AMC8-2000-06','AMC8-2002-11']);
 closed.run('window.__AMC8_CHILD_FORMS.problems["AMC8-2002-11"]={status:"PENDING"}');
 closed.click('rtmPathway');assert.equal(active(closed),undefined);
 assert.equal(closed.value('Object.keys(saved.rtm1.eventsById).length'),0);
 const a=load(['AMC8-2000-06','AMC8-2002-11']);a.click('rtmPathway');
 const plan=a.value('Object.values(saved.rtm1.assignmentsById)[0]');assert.equal(plan.structureClusterId,'square-area-difference');
 let count=0;while(active(a).pathwayStage==='training'){correct(a);a.click('rtmNext');assert(++count<12)}
 assert.equal(active(a).examId,'AMC8-2002-11');assert.equal(active(a).mode,'exam_holdout');
 assert.equal(a.value('TransferEvidenceStore.history(saved.rtm1).assistedOriginGroups.includes("AMC8-2002-11")'),false);
});

test('pending-child-forms-close-both-content-and-legacy-recipe-delivery-branches',()=>{
 for(const id of ['AMC8-2000-03','AMC8-2000-06','AMC8-2000-11','AMC8-2000-23']){
  for(const mode of ['practice','exam_holdout','training']){
   const a=load([id]);a.run('window.__AMC8_CHILD_FORMS.problems['+JSON.stringify(id)+']={status:"PENDING"}');a.click('rtmStart',{mode});assert.equal(active(a),undefined,id+' '+mode);
   assert.equal(a.value('Object.keys(saved.rtm1.eventsById).length'),0);
  }
 }
});

test('holdout-help-converts-mode-and-does-not-create-independent-success',()=>{
 const a=load(['AMC8-2000-01']);a.click('rtmStart',{mode:'exam_holdout'});a.click('rtmHint');
 assert.equal(active(a).mode,'practice');assert(active(a).independentAbandoned);
 correct(a);const stats=a.value('TransferEvidenceStore.statistics(saved.rtm1)');
 assert.equal(stats.holdoutSubmitted,1);assert.equal(stats.holdoutFirstUnassistedCorrect,0);assert.equal(stats.holdoutHelpConversions,1);
 assert.equal(a.value('Object.values(saved.rtm1.eventsById).filter(e=>e.type==="mode_changed").length'),1);
});

test('diagnostic-probe-is-separate-and-return-keeps-the-wrong-first-answer',()=>{
 const a=load(['AMC8-2000-01']);a.click('rtmStart',{mode:'exam_holdout'});submit(a,'15');
 const parent=active(a);a.click('rtmDiagnostic');assert.equal(active(a).kind,'training');assert.equal(active(a).diagnosticOf.attemptId,parent.attemptId);
 correct(a);assert.equal(a.value('Object.values(saved.rtm1.eventsById).filter(e=>e.type==="diagnostic_probe_submitted").length'),1);
 a.click('rtmReturnParent');assert.equal(active(a).attemptId,parent.attemptId);assert.equal(active(a).mode,'practice');
 correct(a);
 assert.equal(a.value('TransferEvidenceStore.instance(saved.rtm1,saved.rtm1.sessions.active.mathKey).firstSubmission.input'),'15');
 assert.equal(a.value('TransferEvidenceStore.statistics(saved.rtm1).holdoutFirstUnassistedCorrect'),0);
 assert.equal(a.value('saved.topicPractice.selectedTopicIds.length'),33);
});

test('pathway-rechecks-scope-instead-of-relaxing-it',()=>{
 const a=load(['AMC8-2000-01','AMC8-2001-03']);a.click('rtmPathway');correct(a);
 a.run('saved.topicPractice.selectedTopicIds=[]');a.click('rtmNext');
 assert.equal(a.value('saved.rtm1.sessions.pathway.stage'),'blocked');assert(active(a).finished);
 assert(a.root.innerHTML.includes('暂不能计作未见检验'));
});

test('future-journal-refuses-pathway-without-touching-original-bytes',()=>{
 const original={schemaVersion:999,future:{keep:['原始记录',1]}},a=load([],{rtm1:original});
 a.click('rtmPathway');assert.deepEqual(a.value('saved.rtm1'),original);assert(a.root.innerHTML.includes('只读'));
});

test('quota-after-existing-draft-does-not-submit-stale-input-or-false-success',()=>{
 const a=load(['AMC8-2000-01']);a.click('rtmStart',{mode:'practice'});submit(a,'15');
 const before=a.value('JSON.stringify(saved.rtm1)'),disk=a.storage[STORE];
 a.run('localStorage.setItem=()=>{throw Error("quota fixture")}');a.inputRtm('16');a.click('rtmSubmit');
 assert.equal(a.value('JSON.stringify(saved.rtm1)'),before);assert.equal(a.storage[STORE],disk);
 assert.equal(a.value('ExamMappingUI.exportDraft().activeInput'),'16');assert.equal(active(a).feedback.outcome,'INCORRECT');
 assert(a.root.innerHTML.includes('未能保存')||a.root.innerHTML.includes('暂不能写入'));
});

test('refresh-keeps-assignment-first-answer-and-guidance-conversion',()=>{
 let a=load(['AMC8-2000-01']);a.click('rtmStart',{mode:'exam_holdout'});submit(a,'15');a.click('rtmHint');
 a=boot(a.storage,2000000001000,html);a.click('rtmOpen');correct(a);
 assert.equal(active(a).mode,'practice');assert.equal(a.value('TransferEvidenceStore.instance(saved.rtm1,saved.rtm1.sessions.active.mathKey).firstSubmission.input'),'15');
 assert.equal(a.value('TransferEvidenceStore.statistics(saved.rtm1).holdoutFirstUnassistedCorrect'),0);
});

for(const r of rows)if(r.status==='FAIL')console.error(r.caseId,r.error);
const report={result:rows.every(r=>r.status==='PASS')?'PASS':'FAIL',cases:rows.length,rows,nativeBrowser:false,learningEffect:'NOT_MEASURED'};
if(process.env.AMC8_RC70_EVIDENCE){const out=process.env.AMC8_RC70_EVIDENCE;fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'rtm1-event-journeys.json'),JSON.stringify(report,null,2)+'\n')}
console.log(JSON.stringify(report,null,2));if(report.result!=='PASS')process.exitCode=1;
