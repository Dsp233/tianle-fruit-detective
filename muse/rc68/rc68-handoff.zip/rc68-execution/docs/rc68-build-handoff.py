"""Prepare reviewable RC68 handoff from actual production exports and evidence.

This changes documents only. It never changes the frozen candidate or Pages.
"""
import collections, hashlib, html, json, pathlib, shutil, subprocess, zipfile

root = pathlib.Path(__file__).resolve().parent.parent
out = root / 'muse/rc68'
evidence = root / 'docs/evidence/rc68'
subprocess.run(['node', 'source/export_muse_rc68.js'], cwd=root, check=True)
identity = json.loads(subprocess.check_output(['node', '-e', "process.stdout.write(JSON.stringify(require('./source/rc68_evidence').identity()))"], cwd=root))
progress = json.loads((root / 'docs/rc68-progress.json').read_text())
for generated_old_directory in (out / 'evidence').glob('*/'):
    if generated_old_directory.is_dir():
        shutil.rmtree(generated_old_directory)
families_path = out / 'families.json'
families = json.loads(families_path.read_text())
families['limits'][0] = 'Publication status is reported separately in acceptance-index.json; this is the actual frozen production-code inventory.'
families_path.write_text(json.dumps(families, ensure_ascii=False, indent=2) + '\n')
def public_evidence_path(path):
    parts = path.relative_to(evidence).parts if path.is_relative_to(evidence) else ('reference', *path.relative_to(root).parts)
    return out / 'evidence' / '--'.join(parts)
reports = []
for path in sorted(evidence.rglob('*')):
    if path.is_file() and path.suffix in ['.json', '.log', '.md', '.png', '.pdf']:
        target = public_evidence_path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        if path.suffix == '.json':
            d = json.loads(path.read_text())
            verdict = d.get('result', d.get('summary', {}).get('result')) if isinstance(d, dict) else None
            reports.append({'path': str(target.relative_to(out)), 'result': verdict,
                            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                            'sameCandidate': isinstance(d, dict) and all(d.get(k) == identity[k] for k in ['sourceTreeHash', 'buildSha256'])})
package_rows = []
for work in progress['packages']:
    row = dict(work)
    row['actualEvidence'] = []
    for name in work['evidence']:
        path = root / name
        if path.is_file():
            value = json.loads(path.read_text()) if path.suffix == '.json' else {}
            published = public_evidence_path(path)
            published.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, published)
            row['actualEvidence'].append({'path': str(public_evidence_path(path).relative_to(out)), 'originalPath': name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                         'result': value.get('result') if isinstance(value, dict) else None,
                                         'sourceCommit': value.get('sourceCommit') if isinstance(value, dict) else None})
    package_rows.append(row)
(out / 'work-packages.json').write_text(json.dumps({'schemaVersion': 1, **identity, 'completed': progress['completed'], 'total': 20, 'packages': package_rows}, ensure_ascii=False, indent=2) + '\n')
code = """const V=require('./source/validation_runtime'),F=require('./source/validation_fixtures'),G=require('./source/reasoning_graph');V.register(F);process.stdout.write(JSON.stringify(F.map(f=>{const recipe={engine:4,familyId:f.id,configurationId:'contract-v1',generatorRevision:1,seed:1},t=V.create(recipe);return {familyId:f.id,normalSupply:false,recipe,qa:'../../qa/?'+new URLSearchParams({familyId:f.id,configuration:'contract-v1',generatorRevision:'1',seed:'1'}),problemState:t.competition.problemState,variantState:t.competition.extension.problemState,routes:G.create(t.competition).routes}})))"""
validation = json.loads(subprocess.check_output(['node', '-e', code], cwd=root))
(out / 'qa-only-validation.json').write_text(json.dumps({'schemaVersion': 1, **identity, 'families': validation, 'normalSupply': False}, ensure_ascii=False, indent=2) + '\n')
browser_path = evidence / 'browser/results.json'
browser = json.loads(browser_path.read_text()) if browser_path.exists() else {}
browser_passed = browser.get('result') == 'passed' and all(browser.get(k) == identity[k] for k in ['sourceTreeHash', 'buildSha256']) and browser.get('executedBasicScenes') == 846
closure = json.loads((root / 'docs/rc68-muse-closure-matrix.json').read_text())
regression = json.loads((evidence / 'regression/muse-issues.json').read_text())
observed = {x['id']: x for x in regression['issues']}
closure.update(purpose='Actual RC68 regression joined to original Muse classifications; independent re-acceptance remains separate.', **identity)
for issue in closure['issues']:
    row = observed.get(issue['id'])
    if row:
        issue['rc68Regression'] = row
        issue['rc68ResolutionStatus'] = ('fixed_regression_passed' if issue['independentReviewStatus'] == 'confirmed' else 'original_classification_preserved_extended_regression_passed') if row['result'] == 'regression_passed' else row['result']
        issue['rc68Evidence'] = ['evidence/regression--muse-issues.json', 'evidence/regression--semantic-audit.json']
        issue['nativeBrowser'] = 'same-candidate automated browser passed' if browser_passed else 'pending'
        issue['museIndependentReAcceptance'] = 'pending; no new original Muse result received'
withdrawn_results = {x['id']: x for x in regression['withdrawn']}
for issue in closure['withdrawn']:
    issue['rc68Regression'] = withdrawn_results[issue['id']]
    issue['rc68ResolutionStatus'] = 'withdrawn_retained_regression_passed'
    issue['museIndependentReAcceptance'] = 'pending'
for gap in closure['requirementGaps']:
    gap['rc68ResolutionStatus'] = 'implemented_production_flagship_and_same_candidate_regression_passed'
    gap['rc68Evidence'] = ['evidence/prototype--reasoning.json', 'evidence/contracts--state.json', 'evidence/browser--results.json']
    gap['museIndependentReAcceptance'] = 'pending'
(out / 'muse-closure.json').write_text(json.dumps(closure, ensure_ascii=False, indent=2) + '\n')
publication_path = evidence / 'release/publication.json'
publication = json.loads(publication_path.read_text()) if publication_path.exists() else {'publicDeployment': False}
data = {'schemaVersion': 1, **identity, 'completedPackages': progress['completed'], 'totalPackages': 20,
        'percent': progress['percent'], 'productionFamilies': 141, 'productionConfigurations': 148,
        'qaOnlyEngineeringFamilies': 4, 'seedsPerConfiguration': 131, 'browserAcceptancePassed': browser_passed,
        'publicDeployment': publication.get('publicDeployment') is True, 'publication': publication,
        'reports': reports, 'remainingPackages': [{'id': w['id'], 'title': w['title'], 'blockers': w['blockers']} for w in progress['packages'] if w['status'] != 'completed'],
        'supersededPendingNotes': ['Prototype reasoning F13 browser pending is resolved by browser/results.json on the identical source/build.', 'Holdout migration package15 pending is resolved by same-candidate browser acceptance and work-package15 completion. Original test-report text is preserved.'],
        'limits': ['Regression is separate from Muse independent re-acceptance.', 'Actual iPad/Safari and audible speech quality are untested.', '500-row source ledger is not 500 verified full source structures.', 'Legacy route prerequisites use conservative topic closures; arbitrary free-text mathematical proof is not automatically certified.']}
(out / 'acceptance-index.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
esc = html.escape
state = '已部署；已确认发布结果及版本。发布后功能复验由Muse执行' if data['publicDeployment'] else '发布前验收已通过，主站尚未替换'
rows = ''.join('<tr><td>'+esc(w['id'])+'</td><td>'+esc(w['title'])+'</td><td>'+esc(w['status'])+'</td><td>'+', '.join(esc(x) for x in w['blockers'])+'</td></tr>' for w in progress['packages'])
links = ''.join('<li><a href="'+esc(x['path'])+'">'+esc(x['path'])+'</a>：'+esc(str(x['result']))+'；同候选 '+str(x['sameCandidate'])+'</li>' for x in reports if x['result'])
page = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RC68 Muse 交接与验收证据</title><style>body{font:16px/1.7 system-ui;max-width:1100px;margin:24px auto;padding:16px;color:#173b48}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccd5d7;padding:8px;text-align:left;overflow-wrap:anywhere}a{color:#125c79}code{overflow-wrap:anywhere}</style>'
page += '<h1>RC68 Muse 交接与验收证据</h1><p>'+esc(state)+'。已验收 '+str(data['completedPackages'])+'/20（'+str(data['percent'])+'%）。</p><p>源码 SHA：<code>'+esc(identity['sourceCommit'])+'</code><br>构建 SHA256：<code>'+esc(identity['buildSha256'])+'</code></p>'
page += '<p><a href="rc68-handoff.zip">完整源码、构建及验收交接包</a> · <a href="work-packages.json">20项工作包逐项证据与哈希</a> · <a href="final-implementation-report.md">最终实施报告</a></p>'
page += '<p><a href="families.html">141题族与148个配置</a> · <a href="families.json">完整路线、节点、技能与答案合同</a> · <a href="manifest.json">全部131个seed及参数范围</a> · <a href="qa-only-validation.json">4个仅用于QA的新留出题族</a> · <a href="source-supply.json">500条来源台账</a> · <a href="acceptance-index.json">验收索引</a> · <a href="../../qa/">定向QA</a> · <a href="../../qa/normal/">隔离正常入口</a> · <a href="../../qa/history/">合成历史兼容入口</a></p>'
page += '<p>在QA中选择familyId、configuration、generatorRevision与seed，点击载入，再从首屏检查图文、答案披露、各节点提示、学生作答、解法及变式。新结构配置使用版本4；仅QA新留出使用版本1。清理测试记录只影响QA专用存储。</p><p>已掌握技能不足时检查空池及必要前提，不自动扩大学习范围。提示、示例、看解法与近期关联方法暴露都保留在记录中。24小时窗口是操作分类规则，不是儿童独立能力的科学证明。</p>'
if browser_passed:
    native = browser['retrieval']
    page += '<p>发布前真实Chrome：846/846页面场景、1,046推导节点、1,372提示阶段、215路线；四类正常入口旅程与合成历史回放通过。<a href="'+esc(native['runUrl'])+'">原生运行记录</a> · <a href="'+esc(native['artifactUrl'])+'">原生截图/DOM/报告附件</a>（保留7天，Muse应及时下载）。原生附件SHA256：<code>'+esc(native['artifactSha256'])+'</code>。本会话读取了可见摘要及哈希，没有下载或逐图检查整个附件。</p>'
page += '<p>Muse发布后检查：核对主站RC68版本与资源；分别从定向QA、隔离正常入口和合成历史入口检查图文一致、未作答答案披露、提示、解法、变式与刷新；核对141题族/148配置清单，实际设备与声音另行记录。普通主站使用原存储键；QA三种入口分别使用独立测试存储。</p>'
page += '<h2>20工作包</h2><table><tr><th>编号</th><th>工作包</th><th>验收状态</th><th>阻断项</th></tr>'+rows+'</table><h2>实际证据</h2><ul>'+links+'</ul><p><a href="muse-closure.json">原Muse36项分类与2项撤销记录</a>保留原始判断；自测回归与Muse独立复验分别报告。原生截图、DOM及环境报告以实际浏览器运行附件为准，缺失附件不能记为已查看。</p>'
page += '<h2>回滚</h2><p>通过普通Git revert或新的恢复提交恢复发布前静态文件，保留远端后续更新，禁止强推。保留所有localStorage和<code>tianle_amc8_question_design_v1_backup_before_rc68</code>；旧页面遇到更新版本记录采取只读保护。未正式发布时无需回滚主站。</p><p>未测：真实iPad/Safari、声音听感与儿童学习效果。自由文字推理无法识别时保留为未核验。</p></html>'
(out / 'index.html').write_text(page)
final_report = root / 'docs/rc68-final-implementation-report.md'
if final_report.exists():
    shutil.copyfile(final_report, out / 'final-implementation-report.md')
target = root / 'muse/rc68-handoff.zip'
paths = list((root / 'source').glob('*')) + list(out.rglob('*'))
paths += [root / p for p in ['index.html', 'amc8/index.html', 'qa/index.html', 'qa/normal/index.html', 'qa/history/index.html']]
paths += list((root / 'docs').glob('rc68-*'))
paths += [root / 'docs/exam-review-ledger.csv']
paths += list(evidence.rglob('*'))
paths += list((evidence / 'sources').glob('*.pdf')) + list((evidence / 'sources').glob('*.png'))
paths += list((root / 'docs/evidence/2026-10-08-rc67-full/baseline').glob('*.json'))
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(set(paths)):
        if path.is_file() and path != target and path.suffix in ['.json', '.js', '.py', '.html', '.css', '.md', '.log', '.csv', '.pdf', '.png']:
            z.write(path, 'rc68-execution/' + str(path.relative_to(root)))
    legacy_html = root.parent / 'rc67-browser-candidate/index.html'
    z.write(legacy_html, 'rc67-browser-candidate/index.html')
    z.writestr('README.md', '# RC68 Muse交接包\n\n源码及所有候选构建在 rc68-execution/。旁边的 rc67-browser-candidate/index.html 是回退只读保护测试使用的静态历史页，不含学习记录。\n\n进入 rc68-execution 后使用 source/run_rc68_gates.py；真实浏览器回归需已安装的 Chrome 和 Playwright。实际原生 CI 的截图与 DOM 在交接页所链接的官方附件，保留7天，请及时下载。此包不冒充已逐图审阅该附件，也不代表 Muse 独立复验。\n')
    z.writestr('handoff-manifest.json', json.dumps(data, ensure_ascii=False, indent=2)+'\n')
shutil.copyfile(target, out / 'rc68-handoff.zip')
print(json.dumps({'path': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'bytes': target.stat().st_size, 'completed': progress['completed'], 'publicDeployment': data['publicDeployment']}, ensure_ascii=False))
