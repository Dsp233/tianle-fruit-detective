# 天乐的数学侦探学院

当前源码 **V12.0-rc.65 本地出题规则试用版**：页面内容修订97、存储2、证据规则4；活动题engine3数学合同仍为93。本候选只在独立工作树开发，本轮未执行公网发布，原上线基线为RC64；当前目标为拓展解题思路和AMC8竞赛能力。有效需求见 `docs/product-requirements-competition.md`。

保留33主题多选UI；勾选表示本次知识范围、假设已经会，直接出题。先选自然成立的竞赛题，再匹配所需主题是否在范围内。每题可用一个或几个相关主题，没有固定主题数量，也没有整组覆盖全部所选的配额；一组默认10题。号码卡、多情境条件拼接不再供应。

候选活动题库为140个可选题族/规则配置：原127族（104单主题、23自然综合）加6个公共模型的13种目标/条件配置。原127族包括52修订既有题族、67个RC61新增题族及8个RC64新结构。33主题各至少3种题族；综合关系来自真实题目，不宣称覆盖全部528对/5456三主题。参数变化不是新增题型，当前是原创AMC8风格训练，不是已复核真题或全难度题库。

答前只呈现条件与中性题名，可排除选项、记思路、请求切入提示；答后按实际内容显示一条或不同路线，并可作答条件变化题。推理按起步/进阶/挑战分层，下一题依据真实首答、提示与变式表现选择，升档需不同结构及更高层试探。选题参考本组与最近12个不同问题的题型暴露，减少连续换数字；低档需要帮助时优先维持可做难度，不为变化强行升难。上一题不重复记账，刷新/退出续做恢复草稿。记录在 `saved.competition`，不写成掌握或教学通过。RC59答案、变式和暴露保留；RC60/61/62未完成题组保留原题/草稿续做，下一题接当前选题器，更早题组仍归 `legacySession`。同数学签名不会因换版本/种子/重排而获得新首答机会。

RC63朗读补齐得分柱图给定柱高，并把分数、比例、百分数、根号和幂改为语义读法；结束/失败提示能处理每次重建的竞赛题，换题后旧回调失效。主答500条、变式300条明细之外，按数学身份保留首次提交、答对与最近活动事实。累计完成数、首答、难度回放和本组续做不再随明细截短丢失；旧已丢失凭据的历史不会凭暴露标记补造。512题实际提交压力、357次只读条件朗读与RC62真实数据迁移模拟通过，实际设备语音仍待验。

RC62补齐无盖盒子的四角剪切与折叠图、斜边中点所求线段及3:4边长比例；角比标在顶点，截断柱图保留全部小格且减少数字刻度。长宽极值、逆向递推、负乘积极值、台阶积木、剪角盒子共5族补全推理/枚举过程；三个因数题保留完整质数平方方法。RC64基线58族单路线、69族多路线，不强制两解。119×128个主问题/变式的条件、答案、选项、数学身份和判分合同与RC61逐一一致。

179基础教学资源、95旧共享题族及旧认证记录保留于家长辅助入口。剩余84教学族不再自动属于当前必做范围。保留知识结构33区域179节点388关系、358双书引用及原题87已核/412待核/1差异的历史口径。

页面不依赖外部CDN、账户或数据库。根与amc8同origin共享本机键`tianle_amc8_question_design_v1`。损坏/未知新版数据不覆盖，旧独立/帮助/暴露保留历史。主动导入导出及多标签冲突仍待实现。

RC64新增两盒转移、四块面积、最坏情况、停止边界、连续整数表示、余数概率、旋转等价和逐步随机路线。提示展开后可听、停止、重播；只读可见提示，帮助事实不随播放次数重复。精确比例显示消除价格解析浮点尾数；刷新恢复经选项核验的错误反馈；变式检查后保持展开，直接呈现反馈。详见 `docs/delivery-review-rc64.md`。

现有测试的证据输出通过测试专用预加载器重定向，避免覆盖历史报告。运行时设置 `AMC8_EVIDENCE_DIR=docs/evidence/2026-10-07-rc65-local` 和 `NODE_OPTIONS="--require ./source/test_evidence_sink.js"`。仓库根执行：

```sh
node source/build_knowledge_graph.js --check
python3 source/build.py
python3 source/build.py --check
python3 source/build.py --local-prototype
python3 source/build.py --local-prototype --check
node source/test_rc65.js
node source/test_rc64.js
node source/test_competition_reviewed.js
node source/test_competition_adaptive.js
node source/test_competition_polish.js
node source/test_competition_continuity.js
node source/test_topic_session.js
node source/test_knowledge_graph_ui.js
node source/test_knowledge.js
node source/test_joint.js
node source/test_joint_raffle.js
node source/test_joint_rates.js
node source/test_joint_logic.js
node source/test_joint_numbers.js
node source/test_joint_role_migration.js
node source/test_curriculum.js
node source/test.js
python3 source/test_delivery.py
```

构建生成同字节`source/index.html`、根`index.html`、`amc8/index.html`。候选字节数与SHA256见 `docs/evidence/2026-10-07-rc65-local/regression-summary.json`。新增模块显式接入模板/构建与手工测试启动器，不单改生成物。

实施范围与证据见`docs/AMC8_知识网学练测通_全量实施与部署_GPT61Sol_执行方案.md`、`docs/implementation-status-knowledge-network.md`、`docs/requirements-traceability.csv`及`docs/delivery-review-rc64.md`、`docs/deployment-2026-10-07-rc64.md`。iPad横屏1024×768、1180×820、1194×834待真机；375px只兼容。

图谱的原生节点选择/分组展开/1–2.5倍缩放已有模拟证据；89整包实例标签已纠正为N01.02余数，真实旧候选签名/角色/待作答打开事实迁移通过模拟；只改合同不生成新独立机会，旧认证未见替补题池保留为历史待办。

RC65实现与使用：`docs/rc65-methods.md`、`docs/delivery-review-rc65-local.md`、`local-preview/README.md`。本地独立构建用存储键 `tianle_amc8_rc65_local_v1`；默认三个构建入口保留旧键以验证迁移。共享关系同时驱动题面、答案、解法、图解、误区及条件变化；6个旧族已适配，其他121族走原兼容路径。13种配置不能称为13种新策略。真实浏览器、iPad和发音验收仍待完成。
