# 合成数据与故障注入操作手册

本目录只供工程执行者。不要把标准关系、候选表或源码合同展示给参加学习观察的孩子。

## 1. 每个 fixture 的生命周期

新建独立浏览器 context → 打开精确 QA URL → 等待 `progressStore.getStatus()==='ready'` → 导出 before → 注入合成数据 → 通过真实 UI 执行 → 导出 after 和真实下载 → 关闭 context。不同测试不复用状态。多标签专用用例才共享 context。

`window.AMC8_QA.loadCase(recipe, true)` 会清空该 QA 合成场景；仅在新建测试 context 使用。不要在真实家庭浏览器 profile 执行下面代码。Node fixture 使用候选的 `source/test_support.js` boot 和相应源码测试作为参考，浏览器结果仍需真实 DOM 观察。

## 2. 未来主变草图注入

在独立 `qa/` 页的工程控制台执行。这段只准备数据，不证明 UI 已通过。执行前后仍应另存完整原文与实际页面。schema 类型按 future-sketch-1..5.json 分别修改，不能先全部转为字符串。

```javascript
if (!location.pathname.includes('/qa/') || typeof STORE !== 'string' || !STORE.startsWith('tianle_amc8_qa_rc72_')) throw Error('仅限独立 RC72 QA');
const task = playerTask();
const work = competitionState();
const variationScope = CompetitionWork.variationId(task);
const rawMain = {
  schemaVersion: 3,
  signature: task.competition.signature,
  nodes: [{id:'future-node', label:'保留的草稿', unknown:{list:[1,'二',null,false]}}],
  futureExtension: {original:'主问题原文，不能覆盖'}
};
const rawVariation = {...rawMain, signature:task.competition.signature+':'+variationScope,
  futureExtension:{original:'变式原文，不能串题'}};
work.scopes.main.sketch = rawMain;
work.scopes[variationScope].sketch = rawVariation;
persist();
render();
```

保留 rawMain/rawVariation 的 JSON 文件作为 oracle。保护结果应能由 `LearnerSketch.original(...)` 读出；下载的 JSON 必须深度比较原始值。不要把 `retainedDraft` 包装本身当原始内容。

## 3. 旧候选证明与历史记录

先按方案第9节通过真实 UI 建立完整有效过程，再导出 before。旧候选合同模拟：只将 `competitionState().scopes.main.model.candidateProof.contractVersion` 改成 2，保存和刷新；旧证明应保留但重新核验前不能通过。

旧历史模拟必须从当前真实生成的一条记录派生，不能手写猜测整份记录格式。在独立 QA 中：

```javascript
if (!location.pathname.includes('/qa/') || !STORE.startsWith('tianle_amc8_qa_rc72_')) throw Error('仅限独立 RC72 QA');
for (const attempt of saved.competition.attempts) delete attempt.processVerificationVersion;
for (const view of Object.values(saved.competition.views)) {
  for (const key of ['first','solved','last']) {
    if (view[key]) delete view[key].processVerificationVersion;
  }
}
persist();
```

刷新检查 legacyProcessEvidence 与正确、首次正确、答案、时间。截断测试另建 fixture：只清空合成 `saved.competition.attempts` 明细，保留 views，再保存刷新。不能因此删真实历史。

## 4. 存储故障与未来完整记录

Node 参考 `source/test_rc69_records.js`；浏览器使用新 context 的 init script，针对当前测试 namespace 注入合成 raw。损坏原文 `broken-json` 与未来 `{contentRevision:999, storageVersion:999}` 分开测试。操作前后对原始 storage 字符串做 SHA256；不把损坏 JSON 先解析再重写。

额度故障只在测试 context 拦截 setItem，对目标 namespace 抛出合成 quota 异常；保存备份写入也需分别覆盖。保留判题结果、内存导出和“未能保存”提示。恢复原方法/关闭 context 后再做下项，不让故障注入污染其他 worker。

## 5. 作者语义合同

`integrated-author-contracts.json` 含四个综合主任务×五个固定 seed 的当前 taskSignature、variationScope、量定义、规则、依赖与技能。生成自冻结源码，20项全部带来源说明。它用于构造工程输入和核对自动核验边界；数学复核者须先独立求解，避免同源逻辑互证。

schemaVersion 为 null 的非空对象仍需保护；`raw=null` 本身表示无草图，应正常获得新的空状态。正常 schema1/2 的恢复与未知 schema 防覆盖要分别记录。
