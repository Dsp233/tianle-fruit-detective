#!/usr/bin/env python3
"""Offline scope/evidence audit. No network, browser, application tests or publishing."""
import argparse, collections, csv, datetime, hashlib, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readjson(p):return json.loads(p.read_text(encoding='utf-8'))
def csvrows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def jsonlines(p):
 if not p.exists():return []
 return [json.loads(line) for line in p.read_text(encoding='utf-8').splitlines() if line.strip()]
def timestamp(s):
 value=datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
 if value.tzinfo is None:raise ValueError('timezone required')
 return value
def package():
 manifest=readjson(ROOT/'package-manifest.json');errors=[]
 for x in manifest['files']:
  p=ROOT/x['path']
  if not p.is_file() or p.stat().st_size!=x['bytes'] or sha(p)!=x['sha256']:errors.append('FILE_IDENTITY '+x['path'])
 actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='package-manifest.json' and '__pycache__' not in p.parts}
 expected={x['path'] for x in manifest['files']}
 if actual!=expected:errors.append('FILE_SET '+str(sorted(actual^expected)))
 definitions=manifest['definitionFiles'];payload={f:sha(ROOT/f) for f in definitions}
 if hashlib.sha256(canonical(payload)).hexdigest()!=manifest['testDefinitionHash']:errors.append('DEFINITION_HASH')
 registry=csvrows(ROOT/'cases/execution-registry.csv');ids=[x['executionId'] for x in registry]
 if len(ids)!=len(set(ids)):errors.append('DUPLICATE_EXECUTION_ID')
 catalog=readjson(ROOT/'cases/catalog.json')['cases'];caseids=[x['caseId'] for x in catalog]
 if len(caseids)!=198 or len(set(caseids))!=198:errors.append('CATALOG_198')
 for x in catalog:
  if not all(x.get(f) for f in ['caseId','preconditions','steps','expected','requiredEvidence','environments']):errors.append('INCOMPLETE_CASE '+x['caseId'])
 populations=readjson(ROOT/'contracts/populations.json')
 allrows=[]
 for name,count in populations['ledgerCounts'].items():
  rows=csvrows(ROOT/'ledgers'/name);allrows+=rows
  if len(rows)!=count:errors.append('COUNT '+name)
  if any(r['status']!='NOT_RUN' for r in rows):errors.append('TEMPLATE_RESULT_PREFILLED '+name)
 if {r['executionId'] for r in allrows}!=set(ids) or len(allrows)!=len(ids):errors.append('LEDGER_REGISTRY_MISMATCH')
 instances=csvrows(ROOT/'ledgers/instance-environments.csv')
 for env in ['node_vm','native_chrome']:
  rows=[r for r in instances if r['environment']==env];keys={(r['familyId'],r['configurationId'],r['seed']) for r in rows}
  if len(rows)!=765 or len(keys)!=765:errors.append('INSTANCE_POPULATION '+env)
  if {r['seed'] for r in rows}!={'1','2','129','2147483646','2147483647'}:errors.append('SEEDS '+env)
  tracks=collections.Counter(r['expectedTrack'] for r in rows)
  if tracks!={'ANSWERABLE':755,'POLICY_BLOCKED':10}:errors.append('POLICY_COUNTS '+str(tracks))
 routes=csvrows(ROOT/'ledgers/routes-208.csv')
 if len(routes)!=208 or sum(r['policyBlocked']=='True' for r in routes)!=4:errors.append('ROUTES')
 skills=csvrows(ROOT/'ledgers/skills-179.csv')
 if len(skills)!=179 or len({r['unitId'] for r in skills})!=33:errors.append('SKILLS')
 p31=next(x for x in catalog if x['caseId']=='M72-P031')['testData']
 p33=next(x for x in catalog if x['caseId']=='M72-P033')['testData']
 if type(p31['schemaVersion']) is not int or type(p33['schemaVersion']) is not str:errors.append('TYPED_SCHEMA_COLLISION')
 print(json.dumps({'audit':'package','result':'VALID' if not errors else 'INVALID','catalogCases':len(catalog),'executionRows':len(registry),'testDefinitionHash':manifest['testDefinitionHash'],'errors':errors},ensure_ascii=False,indent=2))
 return 1 if errors else 0
def candidate(folder):
 baseline=readjson(ROOT/'contracts/baseline.json');errors=[]
 release=readjson(folder/'release-contract.json')
 for field in ['buildId','sourceCommit','sourceTreeHash','buildSha256','release']:
  if release.get(field)!=baseline.get(field):errors.append('BASELINE '+field)
 payload={k:v for k,v in release.items() if k!='buildId'}
 if hashlib.sha256(canonical(payload)).hexdigest()!=release.get('buildId'):errors.append('BUILD_ID_PAYLOAD')
 for name,digest in {**release['files'],**release.get('fixtures',{})}.items():
  p=folder/name
  if not p.is_file() or sha(p)!=digest:errors.append('CANDIDATE_FILE '+name)
 source=sorted(p for p in (folder/'source').iterdir() if p.suffix in {'.js','.json','.py','.css','.html'} and p.name!='index.html')
 tree=hashlib.sha256('\n'.join(p.name+':'+sha(p) for p in source).encode()).hexdigest()
 if tree!=baseline['sourceTreeHash']:errors.append('SOURCE_TREE')
 if hashlib.sha256(canonical(readjson(folder/'scope.json'))).hexdigest()!=baseline['registrySha256']:errors.append('SCOPE_REGISTRY')
 print(json.dumps({'audit':'candidate','result':'MATCH' if not errors else 'MISMATCH','errors':errors},ensure_ascii=False,indent=2))
 return 1 if errors else 0
def results(run,gate):
 errors=[];incomplete=[];manifest=readjson(ROOT/'package-manifest.json');baseline=readjson(ROOT/'contracts/baseline.json')
 registry={r['executionId']:r for r in csvrows(ROOT/'cases/execution-registry.csv')}
 selected={k:v for k,v in registry.items() if gate=='all' or v['gate'] in {'G0',gate}}
 if not (run/'run-manifest.json').exists():
  print(json.dumps({'audit':'results','result':'INCOMPLETE','missing':['run-manifest.json'],'requiredExecutionRows':len(selected)},ensure_ascii=False,indent=2));return 2
 rm=readjson(run/'run-manifest.json')
 for f,exp in [('buildId',baseline['buildId']),('sourceCommit',baseline['sourceCommit']),('testDefinitionHash',manifest['testDefinitionHash'])]:
  if rm.get(f)!=exp:errors.append('RUN_IDENTITY '+f)
 if not rm.get('runId') or 'REPLACE' in rm['runId']:errors.append('RUN_ID_REQUIRED')
 rows=jsonlines(run/'results.jsonl');attempts=jsonlines(run/'attempts.jsonl')
 evidence=readjson(run/'evidence-index.json').get('items',[]) if (run/'evidence-index.json').exists() else []
 eids={};root=run.resolve()
 for e in evidence:
  key=e.get('evidenceId')
  if not key or key in eids:errors.append('EVIDENCE_ID '+str(key));continue
  eids[key]=e;p=(run/e.get('path','')).resolve()
  if not p.is_relative_to(root) or not p.is_file():errors.append('EVIDENCE_PATH '+str(key));continue
  if e.get('bytes')!=p.stat().st_size or e.get('sha256')!=sha(p):errors.append('EVIDENCE_HASH '+str(key))
 byattempt=collections.defaultdict(list);attemptkeys=set()
 for a in attempts:
  k=(a.get('executionId'),a.get('attempt'))
  if k in attemptkeys:errors.append('DUPLICATE_ATTEMPT '+str(k))
  attemptkeys.add(k);byattempt[k[0]].append(a)
  if k[0] not in registry:errors.append('UNKNOWN_ATTEMPT '+str(k))
  if a.get('runId')!=rm.get('runId'):errors.append('ATTEMPT_RUN '+str(k))
 for eid,arr in byattempt.items():
  nums=sorted(a['attempt'] for a in arr)
  if nums!=list(range(1,len(nums)+1)):errors.append('ATTEMPT_SEQUENCE '+eid)
  if len(arr)>4:errors.append('RETRY_LIMIT '+eid)
  ordered=sorted(arr,key=lambda a:a['attempt'])
  for prev,nxt in zip(ordered,ordered[1:]):
   if prev.get('failureClass')!='INFRA':errors.append('RETRY_NOT_INFRA '+eid)
   try:
    waited=(timestamp(nxt['startedAt'])-timestamp(prev['finishedAt'])).total_seconds()
    minimum=max([30,120,300][prev['attempt']-1]*.8,prev.get('retryAfterSeconds',0))
    if waited<minimum:errors.append('RETRY_TOO_EARLY '+eid)
   except (KeyError,ValueError,IndexError,TypeError):errors.append('RETRY_TIME '+eid)
 allowed={'NOT_RUN','PASS','POLICY_PASS','FAIL','BLOCKED_VERSION','BLOCKED_INFRA','BLOCKED_MISSING_EVIDENCE','BLOCKED_MATERIAL','BLOCKED_UNKNOWN','NOT_APPLICABLE'}
 seen={}
 for r in rows:
  eid=r.get('executionId')
  if eid not in registry:errors.append('UNKNOWN_EXECUTION '+str(eid));continue
  if eid in seen:errors.append('DUPLICATE_RESULT '+eid);continue
  seen[eid]=r;expected=registry[eid];status=r.get('status')
  for f in ['caseId','environment','suite']:
   if r.get(f)!=expected[f]:errors.append('RESULT_IDENTITY '+eid+' '+f)
  for f in ['runId','buildId','testDefinitionHash']:
   if r.get(f)!=rm.get(f):errors.append('RESULT_RUN '+eid+' '+f)
  if status not in allowed:errors.append('STATUS '+eid)
  if status=='NOT_RUN':continue
  if not r.get('actual') or not r.get('reviewer'):errors.append('RESULT_CONTENT '+eid)
  try:
   if timestamp(r['finishedAt'])<timestamp(r['startedAt']):raise ValueError('reversed')
  except (ValueError,KeyError,TypeError):errors.append('RESULT_TIME '+eid)
  if not r.get('evidenceRefs') or any(e not in eids for e in r.get('evidenceRefs',[])):errors.append('RESULT_EVIDENCE '+eid)
  history=byattempt.get(eid,[])
  if not history or r.get('attempt')!=max(a['attempt'] for a in history):errors.append('RESULT_ATTEMPT '+eid)
  if history:
   latest=max(history,key=lambda a:a['attempt'])
   if latest.get('status')!=status:errors.append('FINAL_ATTEMPT_STATUS '+eid)
   if status in ['PASS','POLICY_PASS'] and latest.get('failureClass') is not None:errors.append('SUCCESS_WITH_FAILURE_CLASS '+eid)
   if any(e not in eids for a in history for e in a.get('evidenceRefs',[])):errors.append('ATTEMPT_EVIDENCE '+eid)
  if status in ['PASS','POLICY_PASS'] and any(a.get('failureClass')=='PRODUCT' for a in history):errors.append('PRODUCT_FAILURE_STICKY '+eid)
  if status=='POLICY_PASS' and expected['expectedTrack']!='POLICY_BLOCKED':errors.append('UNEXPECTED_POLICY_PASS '+eid)
  if status=='PASS' and expected['expectedTrack']=='POLICY_BLOCKED':errors.append('POLICY_STATUS_REQUIRED '+eid)
  if expected['suite']=='instances' and status=='PASS':
   if r.get('mainStatus')!='PASS' or r.get('variationStatus')!='PASS':errors.append('PAIR_INCOMPLETE '+eid)
 for eid in selected:
  r=seen.get(eid)
  if not r or r.get('status') not in ['PASS','POLICY_PASS']:incomplete.append({'executionId':eid,'status':r.get('status') if r else 'MISSING'})
 summary=collections.Counter(seen[k]['status'] if k in seen else 'MISSING' for k in selected)
 result='INVALID' if errors else 'INCOMPLETE' if incomplete else 'COMPLETE_FOR_MANUAL_REVIEW'
 print(json.dumps({'audit':'results','gateFilter':gate,'result':result,'requiredExecutionRows':len(selected),'statusCounts':dict(summary),'errors':errors,'incompleteCount':len(incomplete),'incompleteSample':incomplete[:20],'limits':'File, identity, retry and coverage validation only. No application assertions or teaching conclusions are certified.'},ensure_ascii=False,indent=2))
 return 1 if errors else 2 if incomplete else 0
def main():
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
 sub.add_parser('package')
 a=sub.add_parser('candidate');a.add_argument('--candidate-dir',type=pathlib.Path,required=True)
 a=sub.add_parser('results');a.add_argument('--run-dir',type=pathlib.Path,required=True);a.add_argument('--gate',choices=['all','G0','G1','G2','G3','G4','G5'],default='all')
 a=p.parse_args()
 try:
  if a.command=='package':return package()
  if a.command=='candidate':return candidate(a.candidate_dir)
  return results(a.run_dir,a.gate)
 except (OSError,ValueError,KeyError,TypeError) as e:
  print(json.dumps({'result':'INVALID','error':str(e)},ensure_ascii=False));return 1
if __name__=='__main__':sys.exit(main())
