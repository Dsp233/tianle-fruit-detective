"""Package committed source, builds and verification contracts for read-only CI."""
import hashlib,json,pathlib,subprocess,zipfile
root=pathlib.Path(__file__).resolve().parent.parent
identity=json.loads(subprocess.check_output(['node','-e',"process.stdout.write(JSON.stringify(require('./source/rc68_evidence').identity()))"],cwd=root,text=True))
tracked=subprocess.check_output(['git','status','--porcelain','--','source','index.html','amc8/index.html','qa'],cwd=root,text=True)
if tracked.strip(): raise RuntimeError('Commit candidate source/build changes before packaging')
target=root/'muse/rc68-candidate.zip';target.parent.mkdir(exist_ok=True)
paths=list((root/'source').glob('*'))
paths += [root/'index.html',root/'amc8/index.html',root/'qa/index.html',root/'qa/normal/index.html',root/'qa/history/index.html',root/'docs/rc68-execution-manifest.json',root/'docs/evidence/rc68/holdout/interface-freeze-v2.json']
files=[p for p in paths if p.is_file() and p.suffix in ['.js','.py','.json','.css','.html','.csv']]
entries=[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)]
manifest={'schemaVersion':1,**identity,'files':entries,'productionSupplyCount':141,'qaOnlyValidationFamilies':4,'productionDeployment':False,'expectedQaSha256':hashlib.sha256((root/'qa/index.html').read_bytes()).hexdigest()}
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files): z.write(p,str(p.relative_to(root)))
    z.writestr('frozen-identity.json',json.dumps(identity,ensure_ascii=False,indent=2)+'\n')
    z.writestr('transfer-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
summary={'path':str(target),**identity,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'fileCount':len(entries)}
(root/'docs/evidence/rc68/release/ci-package.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
