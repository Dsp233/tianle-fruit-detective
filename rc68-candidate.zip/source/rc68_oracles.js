'use strict';
// Independent algorithms: combination enumeration, integer search and unit cells.
// Never reads c.answer, methods or diagram coordinates as the expected answer.
const {designOracle}=require('./competition_design_oracles');
const rational=s=>String(s).replace(/−/g,'-').split('/').map(Number).reduce((a,b)=>a/b);
function combos(cards,count){let products=[];for(let mask=0;mask<2**cards.length;mask++){const pick=cards.filter((_,i)=>mask&(1<<i));if(pick.length===count)products.push(pick.reduce((a,b)=>a*b,1))}return Math.min(...products)}
function groups(p){const found=[];for(let B=1;B<=p.T;B++)for(let A=1;A<=p.T-B;A++){const C=p.T-A-B;if(C>0&&A-B===p.direction*p.d&&C===p.k*(p.ref==='A'?A:B))found.push({A,B,C})}if(found.length!==1)throw Error('Expected one discrete group solution; got '+found.length);return found[0][p.goal]}
function range(p){let n=0;for(let x=p.lo+1;x<p.hi;x++){let digits=String(x),unit=Number(digits.at(-1));if(unit!==0&&x/unit===Math.floor(x/unit)&&(!p.evenOnly||x%2===0))n++}return n}
function lArea(p){let n=0;const side=p.inner+p.border;for(let y=0;y<side;y++)for(let x=0;x<side;x++)if(x<p.border||y<p.border)n++;return n}
function oracle(task,f){const c=task.competition,p=c.math,v=c.extension.math;
 if(f.id==='threeGroupBalance')return {answer:groups(p),extension:groups(v)};
 if(c.configurationId){
  if(f.id==='signedProduct')return {answer:combos(p.cards,3),extension:combos(v.cards,2)};
  if(f.id==='digitDivisor')return {answer:range(p),extension:range(v)};
  if(f.id==='lShapeArea')return {answer:lArea(p),extension:4*(p.inner+p.border)};
  if(f.id==='overlapAverages')return {answer:p.values[3],extension:v.values[4]};
 }
 return designOracle(task,f);
}
module.exports={oracle,rational,groups,range,lArea,combos};
