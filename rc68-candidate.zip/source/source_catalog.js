'use strict';
const SourceCatalog=((data)=>{
 const skills=new Map(data.skills.map(s=>[s.id,s]));
 function closure(ids){const out=new Set();function add(id){if(out.has(id))return;if(!skills.has(id))throw Error('Unknown required skill '+id);out.add(id);skills.get(id).prerequisiteIds.forEach(add)}ids.forEach(add);return [...out].sort()}
 const route=(id,direct)=>({id,directSkills:direct,requiredSkills:closure(direct)});
 const groupBase=['A02.01','A02.03','A02.04','A02.05','R01.01','L01.01'];
 const definitions={
  overlapAverages:{examId:'AMC8-2000-23',configId:'amc2000-23-full',routes:[route('sum-overlap',['D02.02','A02.04','A02.03','A03.02','A03.04']),route('remove-nonoverlap',['D02.02','A02.04','A02.03','A03.02','A03.04'])]},
  signedProduct:{examId:'AMC8-2000-07',configId:'amc2000-07-full',routes:[route('sign-categories',['A05.01','A05.02','A02.04','A02.06']),route('complete-enumeration',['A05.01','A05.02','A02.04','C02.03'])]},
  digitDivisor:{examId:'AMC8-2000-11',configId:'amc2000-11-full',routes:[route('units-groups',['N01.01','N01.02','A01.03','C02.03']),route('tens-groups',['N01.01','N01.02','A01.03','C02.03'])]},
  lShapeArea:{examId:'AMC8-2000-06',configId:'amc2000-06-full',routes:[route('complete-remove',['G03.02','G01.02']),route('disjoint-strips',['G03.01','G01.02'])]},
  threeGroupBalance:{configId:'main',routes:[route('reference-B',groupBase),route('direct-C',groupBase),route('ordered-trial',[...groupBase,'C02.03'])]}
 };
 function knownTopics(topicIds,excluded=[]){const set=new Set(topicIds),removed=new Set(excluded);return data.skills.filter(s=>set.has(s.unitId)&&!removed.has(s.id)).map(s=>s.id)}
 function allowedRoutes(routes,mastered){const set=new Set(mastered);return routes.filter(r=>r.requiredSkills.every(id=>set.has(id)))}
 function taskRoutes(task){
  const c=task.competition,base=closure(data.skills.filter(s=>(c.topicIds||[]).includes(s.unitId)).map(s=>s.id));
  const common=[c.prompt,c.extension.prompt,c.answer,c.extension.answer].join(' ');
  const extras=text=>{
   const ids=[];if(/[-−]?\d+\s*\/\s*\d+/.test(text))ids.push('A03.02','A03.04');
   if(/\d+\.\d+/.test(text))ids.push('A03.06');
   return ids;
  };
  return (c.routes||[]).map(r=>({id:r.id,requiredSkills:closure([...(c.sourceProvenance?.matchType==='full_structure'||c.family==='threeGroupBalance'?r.requiredSkills:[...base,...r.requiredSkills]),...extras(common+' '+r.nodes.map(n=>n.answer+' '+n.hints.join(' ')).join(' '))])}));
 }
 function taskAllowed(task,settings){return allowedRoutes(taskRoutes(task),knownTopics(settings.topicIds,settings.excludedSkillIds))}
 function loadsAllowed(task,settings){const c=task.competition;return (!settings.maxCalculationLoad||c.calculationLoad.level<=settings.maxCalculationLoad)&&(!settings.maxReadingLoad||c.readingLoad.level<=settings.maxReadingLoad)}
 const previewTasks=new Map();
 function preview(item,seed){
  const recipe={engine:3,familyId:item.id,seed,generatorRevision:item.generatorRevision||3,...(item.configurationId?{configurationId:item.configurationId}:{})},key=JSON.stringify(recipe);
  if(!previewTasks.has(key))previewTasks.set(key,(typeof module!=='undefined'?require('./competition_reviewed').competitionCreate:competitionCreate)(recipe));
  return previewTasks.get(key);
 }
 function eligible(families,settings){
  const mastered=knownTopics(settings.topicIds,settings.excludedSkillIds),scope=new Set(settings.topicIds),sources=settings.sourceIds||['AMC8'],ids=new Set(settings.examIds||[]),result=[];
  for(const f of families){const def=definitions[f.id];
   if(sources.includes('AMC8')&&def?.examId&&(!ids.size||ids.has(def.examId))){const routes=allowedRoutes(def.routes,mastered);if(routes.length)result.push({...f,configurationId:def.configId,generatorRevision:4,sourceId:'AMC8',sourceExamId:def.examId,allowedRouteIds:routes.map(r=>r.id),requiredSkillsByRoute:routes})}
   if(sources.includes('original')&&!ids.size&&f.topicIds.every(x=>scope.has(x))){
    // Original route scopes are conservative until per-route contracts are reviewed.
    const routes=def&&!def.examId?def.routes:[route('legacy-topic-scope',data.skills.filter(s=>f.topicIds.includes(s.unitId)).map(s=>s.id))],allowed=allowedRoutes(routes,mastered);
    if(allowed.length)result.push({...f,configurationId:f.id==='threeGroupBalance'?'main':undefined,generatorRevision:f.id==='threeGroupBalance'?4:3,sourceId:'original',allowedRouteIds:allowed.map(r=>r.id),requiredSkillsByRoute:allowed})
   }
  }return result.filter(item=>[1,2,3,129,2147483647].some(seed=>{const t=preview(item,seed);return taskAllowed(t,settings).length&&loadsAllowed(t,settings)}));
 }
 function provenance(id,config){const d=definitions[id];return d?.examId&&d.configId===config?{sourceId:'AMC8',examId:d.examId,matchType:'full_structure',configurationId:config,reference:'docs/evidence/rc68/sources/original-check.json',sourceStatus:'structure_verified_local',acceptanceEvidence:['docs/evidence/rc68/sources/original-check.json','docs/evidence/rc68/sources/acceptance.json','docs/evidence/rc68/contracts/state.json'],releaseAcceptance:'pending'}:{sourceId:'original',matchType:'original',configurationId:config||'legacy-default'}}
 return {definitions,closure,knownTopics,allowedRoutes,taskRoutes,taskAllowed,loadsAllowed,eligible,provenance};
})(typeof module!=='undefined'?require('./skills.json'):window.__AMC8_SKILLS);
if(typeof module!=='undefined')module.exports=SourceCatalog;
