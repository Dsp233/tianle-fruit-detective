'use strict';
function sourceSelectionPanel(topicIds){
 const state=saved.topicPractice,sourceIds=state.sourceIds||['AMC8'],excluded=state.excludedSkillIds||[],pool=SourceCatalog.eligible(COMPETITION_REVIEWED,{topicIds,sourceIds,maxCalculationLoad:state.maxCalculationLoad,maxReadingLoad:state.maxReadingLoad,excludedSkillIds:excluded,examIds:state.examIds||[]}),skills=SKILL_DATA.skills.filter(s=>topicIds.includes(s.unitId));
 return `<section class="panel source-selection"><h2>参考来源</h2><div class="source-choices">${[['AMC8','AMC8 结构仿真'],['original','原创拓展']].map(([id,name])=>`<button class="secondary" data-action="sourceToggle" data-code="${id}" aria-pressed="${sourceIds.includes(id)}">${sourceIds.includes(id)?'✓ ':''}${name}</button>`).join('')}</div><p role="status">当前范围有 ${pool.length} 个可用结构配置。${!pool.length?'暂无匹配：请确认基础算术、前置知识和来源；系统保留所选范围。':''}</p>${feedback?.ok===false?`<p role="status">${esc(feedback.text)}</p>`:''}<details><summary>细化已掌握知识 / 指定真题</summary>${sourceLoadControls(state)}<p>主题内默认全部已掌握；取消尚未学过的小项会立即影响出题与提示。</p><div class="stage-buttons">${skills.map(s=>`<button class="secondary" data-action="sourceSkillToggle" data-code="${s.id}" aria-pressed="${!excluded.includes(s.id)}">${!excluded.includes(s.id)?'✓ ':''}${esc(s.title)}</button>`).join('')}</div><p>首批真题结构：</p><div class="stage-buttons">${Object.values(SourceCatalog.definitions).filter(d=>d.examId).map(d=>`<button class="secondary" data-action="sourceExamToggle" data-code="${d.examId}" aria-pressed="${(state.examIds||[]).includes(d.examId)}">${(state.examIds||[]).includes(d.examId)?'✓ ':''}${d.examId}</button>`).join('')}</div><button class="secondary" data-action="sourceExamClear">使用全部已验证真题结构</button></details></section>`;
}
function sourceSelectionAction(action,data){
 if(!action.startsWith('source'))return false;if(view!=='home')return true;const s=saved.topicPractice;
 if(action==='sourceToggle'&&['AMC8','original'].includes(data.code)){const set=new Set(s.sourceIds||['AMC8']);set.has(data.code)?set.delete(data.code):set.add(data.code);s.sourceIds=[...set]}
 if(action==='sourceSkillToggle'&&SKILL_DATA.skills.some(x=>x.id===data.code)){const set=new Set(s.excludedSkillIds||[]);set.has(data.code)?set.delete(data.code):set.add(data.code);s.excludedSkillIds=[...set]}
 if(action==='sourceExamToggle'&&Object.values(SourceCatalog.definitions).some(x=>x.examId===data.code)){const set=new Set(s.examIds||[]);set.has(data.code)?set.delete(data.code):set.add(data.code);s.examIds=[...set]}
 if(action==='sourceLoad'&&['calculation','reading'].includes(data.code)&&[1,2,3].includes(Number(data.index)))s[data.code==='calculation'?'maxCalculationLoad':'maxReadingLoad']=Number(data.index)===3?null:Number(data.index);
 if(action==='sourceExamClear')s.examIds=[];feedback=null;persist();render();return true;
}

function sourceLoadControls(state){
 return '<div class="source-load-controls">'+[['calculation','计算量','maxCalculationLoad',['少算一点','适中','不限']],['reading','阅读量','maxReadingLoad',['简短','适中','不限']]].map(([code,label,key,labels])=>'<p><b>'+label+'</b> <span class="stage-buttons">'+labels.map((name,i)=>'<button class="secondary" data-action="sourceLoad" data-code="'+code+'" data-index="'+(i+1)+'" aria-pressed="'+((state[key]||3)===i+1)+'">'+name+'</button>').join('')+'</span></p>').join('')+'<p>这两项分别限制计算和阅读负担，关键思路难度仍单独调整。没有合格题时会说明原因。</p></div>';
}
