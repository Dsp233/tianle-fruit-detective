'use strict';
// New mathematical configurations use revision 4. Revisions 1--3 stay replayable.
const StructuredRecipes=((h)=>{
 const {competitionRng:rng,competitionNumericOptions:options,competitionFraction:F}=h;
 const M=(name,...steps)=>({name,steps}),copy=x=>JSON.parse(JSON.stringify(x));
 const catalog=[{id:'threeGroupBalance',topicIds:['A02','R01','L01'],level:3,title:'三个小组',strategy:'统一参照与总量',reasoningKey:'three-group-reference',origin:'rc68-original',insight:'选择共同参照，区分均等份和额外量，再检验三个条件',build:seed=>create('threeGroupBalance','main',seed)}];
 const sourceConfigs={overlapAverages:'amc2000-23-full',signedProduct:'amc2000-07-full',digitDivisor:'amc2000-11-full',lShapeArea:'amc2000-06-full'};
 function minProducts(cards,n){let best=Infinity,plans=[];function walk(start,pick){if(pick.length===n){const product=pick.reduce((a,b)=>a*b,1);if(product<best){best=product;plans=[pick]}else if(product===best)plans.push(pick);return}for(let i=start;i<cards.length;i++)walk(i+1,[...pick,cards[i]])}walk(0,[]);return {best,plans}}
 function groupState(T,d,k,config){
  const direction=config==='change-difference-direction'?-1:1,ref=config==='change-ratio-reference'?'A':'B',goal=config==='change-goal'?'B':'C';
  const B=(T-direction*d*(ref==='A'?k+1:1))/(k+2),A=B+direction*d,C=k*(ref==='A'?A:B);
  if(![T,d,k,A,B,C].every(Number.isSafeInteger)||Math.min(A,B,C)<=0)throw Error('人数条件没有正整数解');
  return {T,d,k,direction,ref,goal,A,B,C,configurationId:config};
 }
 function create(id,config,seed){
  const r=rng(seed);let c;
  if(id==='threeGroupBalance'){
   if(!['main','change-difference-direction','change-ratio-reference','change-goal','invalid-discrete'].includes(config))throw Error('Unknown group configuration');
   if(config==='invalid-discrete')return groupState(55,6,2,config);
   // Even differences and B>d make the direction/reference variations legal.
   let B,d,k,m;
   if(seed===1){B=12;d=6;k=2}else{k=2+r(3);d=(k===2?2:k===3?5:3)*(1+r(k===2?6:k===3?3:5));B=d+1+r(25-d)}
   const T=(k+2)*B+d;m=groupState(T,d,k,config);
   const relation=m.ref==='A'?'甲':'乙',direction=m.direction===1?'多':'少',answer=String(m[m.goal]);
   const extra=m.direction*d*(m.ref==='A'?k+1:1),net=T-extra,parts=k+2;
   const methods=[M('用乙作共同参照',`甲是乙${m.direction===1?'加':'减'} ${d}；丙是 ${k} 个${relation}。`,`三组总量可写为 ${parts} 个乙${extra>=0?'加':'减'} ${Math.abs(extra)}。`,`去掉额外量：${T}−(${extra})=${net}；乙 ${net}÷${parts}=${m.B}。`,`甲 ${m.A}，乙 ${m.B}，丙 ${m.C}；总和 ${T}、甲乙差 ${d}、丙是${relation} ${k} 倍。`)];
   if(k===2&&m.ref==='B'&&m.goal==='C')methods.push(M('直接表示丙',`甲加乙等于丙${m.direction===1?'加':'减'} ${d}。`,`三组总量是2个丙${m.direction===1?'加':'减'} ${d}；丙 (${T}−(${m.direction*d}))÷2=${m.C}。`,`代回三组条件，甲 ${m.A}、乙 ${m.B}、丙 ${m.C}。`));
   methods.push(M('有序试探并核对',`依次尝试乙为正整数，甲随之${m.direction===1?'加':'减'} ${d}，丙取${relation}的 ${k} 倍。`,`每增加1个乙，总量增加 ${parts} 人，故不会有两个不同解。`,`满足全部条件的是甲 ${m.A}、乙 ${m.B}、丙 ${m.C}。`));
   const vm=groupState(T,d,k,config==='main'?'change-difference-direction':'main');
   c={family:id,title:'三个小组',math:m,answer,prompt:`甲、乙、丙三个小组共有 ${T} 人。甲组比乙组${direction} ${d} 人，丙组人数是${relation}组的 ${k} 倍。${m.goal==='B'?'乙':'丙'}组有多少人？`,methods,rc68Diagram:{kind:'scene-groupDraft',T,d,k,goal:m.goal,ref:m.ref,direction:m.direction},ruleHints:['要得到所求小组人数，还需要知道哪个量？','甲和丙的条件中共同出现了哪一组？它能表示其他组吗？'],extension:{key:vm.configurationId,prompt:`三组仍共 ${T} 人，甲比乙${vm.direction===1?'多':'少'} ${d} 人，丙是乙 ${k} 倍。丙有多少人？`,answer:String(vm.C),solution:`先统一成乙组的份量，总量扣去带符号差额 ${vm.direction*d}，乙=${vm.B}，丙=${vm.C}；代回检验。`,math:vm,kind:'condition-change',rc68Diagram:{kind:'scene-groupDraft',T,d,k,goal:'C',ref:'B',direction:vm.direction}}};
  }else if(id==='signedProduct'&&config===sourceConfigs[id]){
   const branch=(seed-1)%4;
   const sets=[[-8,-6,-4,0,3,5,7],[-9,-8,-7,0,1,2,3],[-8,-6,-4,0,2,3,8],[-8,-6,-4,2,3,5,7]];
   const cards=sets[branch].map((x,i)=>seed<=4?x:x+(i===0?-r(4):i===6?r(4):0)),main=minProducts(cards,3),v=minProducts(cards,2),neg=cards.filter(x=>x<0),pos=cards.filter(x=>x>0),oneNeg=neg[0]*pos.at(-1)*pos.at(-2),threeNeg=neg.reduce((a,b)=>a*b,1);
   c={family:id,math:{cards,configurationId:config},answer:String(main.best),prompt:`数字卡 ${cards.join('、')}，任选三张不同的卡，乘积最小是多少？`,methods:[M('比较两类负乘积',`一负两正的最小候选 ${oneNeg}；三负的候选 ${threeNeg}。`,`含0为0，其余非负；比较两类负乘积，最小 ${main.best}。${main.plans.length>1?'有不同取法达到同一最小值。':''}`),M('完整枚举',`按卡片下标递增选三张，避免同一组合重复。`,`共 ${cards.length*(cards.length-1)*(cards.length-2)/6} 组，最小乘积 ${main.best}。`)],ruleHints:['三张乘积为负，负数张数可能有哪些情况？','各类里怎样选卡值，才能得到更小的负数？再比较类别。'],rc68Diagram:{kind:'scene-slots',values:cards,choose:3,caption:'卡值各不相同；先自主比较符号类别'},extension:{key:'choose-two',prompt:'改为任选两张不同的卡，最小乘积是多少？',answer:String(v.best),solution:`重新列举两张组合，最小 ${v.best}。三张的类别不能原封不动沿用。`,math:{cards,choose:2},kind:'condition-change',rc68Diagram:{kind:'scene-slots',values:cards,choose:2,caption:'任选两张，重新判断负数张数'}}};
  }else if(id==='digitDivisor'&&config===sourceConfigs[id]){
   const lo=seed===1?10:10+10*r(5),hi=seed===1?50:Math.min(99,lo+10*(2+r(3))),valid=[];
   for(let n=lo+1;n<hi;n++)if(n%10&&n%(n%10)===0)valid.push(n);
   const removed=valid.filter(n=>n%2===0);
   c={family:id,math:{lo,hi,valid,configurationId:config},answer:String(valid.length),prompt:`在 ${lo} 与 ${hi} 之间（不含两端）的整数中，有多少个能被自己的非零个位数字整除？`,methods:[M('按个位分组，跨十位检查',`个位只能取1到9，0不能作除数。分别列出范围内各个位的数。`,`逐一用数除以其个位，只有余数0才保留；合法数 ${valid.join('、')}。`,`共 ${valid.length} 个，各数只属于一个个位分组，不重计。`),M('按十位分段',`按各十位段逐段检查，排除不在严格区间内的端点。`,`合并合法数列表并去重，共 ${valid.length} 个。`)],ruleHints:['个位为0时，“被个位整除”有定义吗？其余数可以怎样分组？','选一个个位，检查它在不同十位段是否都能整除；区间两端算不算？'],rc68Diagram:{kind:'scene-digitRange',lo,hi},extension:{key:'even-only',prompt:`范围与整除条件不变，只保留偶数。共有多少个？`,answer:String(removed.length),solution:`从合法集合保留偶数：${removed.join('、')}，共 ${removed.length} 个。`,math:{lo,hi,evenOnly:true},kind:'condition-change',rc68Diagram:{kind:'scene-digitRange',lo,hi,evenOnly:true}}};
  }else if(id==='lShapeArea'&&config===sourceConfigs[id]){
   const inner=seed===1?3:2+r(7),border=seed===1?1:1+r(3),outer=inner+2*border,region=inner+border,answer=region**2-inner**2;
   c={family:id,math:{inner,border,configurationId:config},answer:String(answer),prompt:`大正方形内有三个小正方形：左上和右下的小正方形边长都是 ${border}，中央正方形边长 ${inner}。如图阴影L形面积是多少？`,methods:[M('推得边长后补形',`沿外边连接三段：${border}+${inner}+${border}=${outer}；阴影所在方块的边为 ${outer}−${border}=${region}。`,`从边长 ${region} 的方块减去中央边长 ${inner} 的方块，${region}²−${inner}²=${answer}。`),M('分为不重叠的两条',`阴影的竖条宽 ${border}，长 ${region}；横条宽 ${border}，除去竖条后长 ${inner}。`,`两条面积相加 ${border}×${region}+${border}×${inner}=${answer}，转角只计一次。`)],ruleHints:['图中哪些短边能连接成一条完整边？先找阴影外框的边长。','如果补成一个方块，需要减去哪块？也可以把L形分成不重叠的两条。'],rc68Diagram:{kind:'scene-hiddenL',inner,border},extension:{key:'perimeter',prompt:'尺寸不变，改求阴影L形的周长，是多少？',answer:String(4*region),solution:`外框边长 ${region}，凹进去的两边替代同长度的两段外边；周长为 ${4*region}。面积的相减不能用作周长。`,math:{inner,border,target:'perimeter'},kind:'condition-change',rc68Diagram:{kind:'scene-hiddenL',inner,border,target:'perimeter'}}};
  }else if(id==='overlapAverages'&&config===sourceConfigs[id]){
   const values=seed===1?[4,5,5,6,8,8,10]:Array.from({length:7},()=>2+r(15)),sum=a=>a.reduce((s,x)=>s+x,0),front=sum(values.slice(0,4)),back=sum(values.slice(3)),total=sum(values),answer=values[3],z=[...values,values[0],values[6]],vf=sum(z.slice(0,5)),vb=sum(z.slice(4)),vt=sum(z);
   c={family:id,math:{values,configurationId:config},answer:String(answer),prompt:`7个数，前4个平均 ${F(front,4)}，后4个平均 ${F(back,4)}，全部平均 ${F(total,7)}。第4个数是多少？`,methods:[M('总和与重叠',`先由平均乘人数，前4合计 ${front}，后4合计 ${back}，全部合计 ${total}。`,`两段合并时，第4个数出现两次，其余各一次；${front}+${back}−${total}=${answer}。`),M('先去除不重叠部分',`全部合计减后4合计，前3合计 ${total}−${back}=${total-back}。`,`前4减前3，只剩第4个：${front}−${total-back}=${answer}。`)],ruleHints:['平均数怎样和一段的总和联系？最后要找的是哪个位置？','把前后两段对齐，哪些位置在相加时被数了两次？'],extension:{key:'nine-term-overlap',prompt:`9个数，前5个平均 ${F(vf,5)}，后5个平均 ${F(vb,5)}，全部平均 ${F(vt,9)}。第5个数是多少？`,answer:String(z[4]),solution:`新的共同位置是第5个。还原总和后：${vf}+${vb}−${vt}=${z[4]}。`,math:{values:z,groupSize:5},kind:'condition-change'}};
  }
  else throw Error('Unknown structured configuration '+id+'/'+config);
  const value=Number(c.answer);c.options=Number.isInteger(value)?[value,value+1,value-1,value+3,value-2].map(String).sort(()=>0):options(c.answer,r);
  for(let i=c.options.length-1;i>0;i--){const j=r(i+1);[c.options[i],c.options[j]]=[c.options[j],c.options[i]]}c.configurationId=config;return c;
 }
 return {catalog,sourceConfigs,create,groupState,minProducts};
})(typeof module!=='undefined'?require('./competition'):{competitionRng,competitionNumericOptions,competitionFraction});
if(typeof module!=='undefined')module.exports=StructuredRecipes;
