'use strict';
const assert=require('assert'),fs=require('fs'),{save}=require('./rc68_evidence'),{boot}=require('./test_support'),M=require('./competition_reviewed'),Graph=require('./reasoning_graph');
const matrix=require('../docs/rc68-muse-closure-matrix.json'),html=fs.readFileSync('qa/index.html','utf8'),seeds=[1,2,129,2147483646,2147483647],checks=[],failures=[];let cases=0;
function task(id,seed){return M.competitionCreate(M.competitionReviewedRecipe(id,seed))}function app(id,seed){const a=boot({},2000000000000,html);a.run('window.AMC8_QA.loadCase('+JSON.stringify({familyId:id,seed,generatorRevision:id==='threeGroupBalance'?4:3})+',true)');return a}
function solve(a){const t=a.value('taskNow()');if(t.competition.family==='threeGroupBalance')a.inputCompetition('final',t.competition.answer);else a.click('competitionPick',{index:String(t.answer)});a.click('check');assert.equal(a.value('feedback.ok'),true)}
const tests={
 'V2-P1-001':(t,a)=>assert.deepStrictEqual(t.competition.diagram.positionLabels.slice(-2),[t.competition.math.n-1,t.competition.math.n]),
 'V2-P1-002':(t,a)=>{a.click('competitionHint');a.click('competitionHintMore');assert(a.root.innerHTML.includes(t.competition.hints[1]));a.click('competitionHintMore');assert(a.root.innerHTML.includes('已用完'));a=boot(a.storage,2000000000010,html);a.click('topicResume');assert(a.root.innerHTML.includes(t.competition.hints[1]))},
 'V2-P1-003':(t,a)=>{const d=t.competition.extension.diagram;if(t.competition.family==='adjacentLine')assert.deepStrictEqual(d.values.slice(0,3),['乐','人','明']);else assert.equal(d.both,t.competition.math.both+1)},
 'V2-P2-001':(t,a)=>{assert(a.root.innerHTML.includes('千米/时'));assert(!a.root.innerHTML.includes('米/分钟'))},
 'V2-P2-002':(t,a)=>{solve(a);a.click('competitionIndependentVariation');assert(a.root.innerHTML.includes('精确值'));a.inputCompetition('extension',String(Number(t.competition.extension.answer.split('/')[0])/Number(t.competition.extension.answer.split('/')[1]||1)));if(t.competition.extension.answer.includes('/')){a.inputCompetition('extension','16.67');a.click('competitionExtensionCheck');assert(!a.value('draft.work.extensionResult.ok'))}a.inputCompetition('extension',t.competition.extension.answer);a.click('competitionExtensionCheck');assert(a.value('draft.work.extensionResult.ok'))},
 'V2-P2-003':(t,a)=>{assert(t.competition.diagram.draft);assert(a.root.innerHTML.includes('未预先画出全部答案标记'))},
 'V2-P2-004':(t,a)=>assert.equal(t.competition.diagram.width,t.competition.family==='rule-ratio-length'?null:t.competition.math.params.width),
 'V2-P2-005':(t,a)=>assert.notEqual(t.competition.diagram.repeat,t.competition.extension.diagram.repeat),
 'V2-P2-006':(t,a)=>assert.notEqual(t.competition.diagram.repeat,t.competition.extension.diagram.repeat),
 'V2-P2-007':(t,a)=>{const g=Graph.create(t.competition);assert.equal(t.competition.hints[1],g.routes[0].nodes[1].prompt)},
 'V2-P2-008':()=>{const a=app('exactlyOneSet',1);a.run('topicSession().total=2;topicSession().sourceIds=["original"]');solve(a);a.click('next');assert(!a.value('topicCurrent().passed'));assert(!a.root.innerHTML.includes('class="competition-solutions"'))},
 'V2-P2-009':(t,a)=>assert(!t.competition.hints.some(x=>x===t.competition.insight)),
 'V2-P2-010':(t,a)=>{const g=Graph.create(t.competition);assert.equal(g.routes[0].nodes.at(-1).answer,t.competition.answer);assert(g.routes[0].nodes.some(n=>n.id==='B-total'))},
 'V2-P2-011':()=>{const a=boot();assert.equal(a.value('CompetitionIdentity.counts(saved.competition).solved'),0);a.click('competitionRecords');assert(a.root.innerHTML.includes('已记录完成 0'))},
 'V2-P2-012':()=>{let a=boot();a.click('topicSelect',{code:'A02'});a.click('topicSelect',{code:'G03'});for(let i=0;i<3;i++)a=boot(a.storage);assert.deepStrictEqual(a.value('saved.topicPractice.selectedTopicIds'),['A02','G03'])},
 'V2-P3-001':(t,a)=>{a.click('competitionHint');solve(a);assert(a.root.innerHTML.includes(t.competition.hints[0]));a.click('competitionReadHint');assert(a.spoken.length)},
 'V2-P3-003':(t,a)=>assert(a.root.innerHTML.includes('四个外角各计一次')),
 'V2-P3-004':(t,a)=>{solve(a);assert(a.value('topicCurrent().passed'))},
 'V2-P3-005':(t,a)=>assert.equal(t.competition.hints[1],Graph.create(t.competition).routes[0].nodes[1].prompt),
 'V2-P3-006':(t,a)=>{solve(a);assert(a.value('topicCurrent().passed'))},
 'V2-P3-007':(t,a)=>{solve(a);assert(a.value('topicCurrent().passed'))},
 'V2-P3-008':(t,a)=>{solve(a);a.click('competitionIndependentVariation');assert.equal((a.root.innerHTML.match(/class="competition-extension"/g)||[]).length,1)},
 'V2-P3-009':(t,a)=>assert(t.competition.diagram.closed&&t.competition.diagram.caption.includes('首尾闭合')),
 'V2-P3-010':(t,a)=>assert(!/邻面|一个顶点/.test(t.competition.hints[1])),
 'V2-P3-011':(t,a)=>{const p=t.competition.math.params,cost=[];for(let k=0;k<=Math.ceil(p.count/p.size);k++)if(k*p.pack+Math.max(0,p.count-k*p.size)*p.single===Number(t.competition.answer))cost.push(k);if(cost.length>1)assert(t.competition.methods[0].steps.join('').includes('同价最优'))},
 'V2-P3-012':(t,a)=>{const v=a.value('window.AMC8_QA.validate('+JSON.stringify({familyId:'reverseDigits',seed:2147483647,generatorRevision:3})+')');assert.equal(v.recipe.seed,2147483647)},
 'V2-P3-013':(t,a)=>{const frames=t.competition.methods[0].frames.map(x=>JSON.stringify(x.scene));assert(new Set(frames).size>1)},
 'V2-P3-015':(t,a)=>assert(Graph.create(t.competition).routes[0].nodes.length>=4),
 'V2-P3-016':(t,a)=>{assert(t.competition.diagram.draft);assert(!a.root.innerHTML.includes('这样的完整组共'))},
 'V2-P3-017':(t,a)=>{const d=t.competition.extension.diagram;assert(d.sampleFirst);assert(a.value('competitionDiagram('+JSON.stringify(d)+')').includes('第一张纸为取点范围'))},
 'V2-P3-018':(t,a)=>{assert(a.root.innerHTML.includes('棋类组'));assert(a.root.innerHTML.includes('球类组'))},
 'V2-P3-020':(t,a)=>{a.click('competitionHint');a.click('competitionHintMore');a.click('competitionHintMore');assert(a.root.innerHTML.includes('已用完'));assert(a.root.innerHTML.includes('topicSkip'))}
};
const external={'V2-P1-004':'history/compatibility.json','V2-P3-002':'coverage/reasoning.json','V2-P3-014':'coverage/reasoning.json','V2-P3-019':'prototype/reasoning.json'};
for(const issue of matrix.issues){const fn=tests[issue.id];if(!fn){const file=external[issue.id];let evidence;try{evidence=JSON.parse(fs.readFileSync((process.env.AMC8_RC68_EVIDENCE||'docs/evidence/rc68')+'/'+file))}catch{}checks.push({id:issue.id,result:evidence?.result==='passed'?'regression_passed':'pending',evidence:file||null,originalClaim:issue.independentReviewStatus,realBrowser:'pending'});continue}
 const families=issue.families.length?issue.families:['exactlyOneSet'];let n=0;const errors=[];for(const id of families)for(const seed of seeds){try{const t=task(id,seed),a=app(id,seed);fn(t,a);cases++;n++}catch(e){errors.push({familyId:id,seed,error:e.message})}}checks.push({id:issue.id,result:errors.length?'failed':'regression_passed',cases:n,originalClaim:issue.independentReviewStatus,realBrowser:'pending',errors});failures.push(...errors.map(e=>({...e,id:issue.id})))}
const withdrawn=[];{const a=app('exactlyOneSet',1),id=a.value('taskNow().id');a.click('competitionHint');const b=boot(a.storage,2000000000010,html);b.click('topicResume');assert.equal(b.value('taskNow().id'),id);assert(!b.value('topicCurrent().passed'));assert(b.value('competitionHistory(taskNow()).hinted'));withdrawn.push({id:'V2-P0-001',status:'withdrawn_retained',regression:'passed'})}const sourceEvidence=JSON.parse(fs.readFileSync((process.env.AMC8_RC68_EVIDENCE||'docs/evidence/rc68')+'/sources/acceptance.json'));assert.equal(sourceEvidence.result,'passed');withdrawn.push({id:'V2-P1-005',status:'withdrawn_retained',regression:'passed',evidence:'sources/acceptance.json'});
let browser=null;try{browser=JSON.parse(fs.readFileSync((process.env.AMC8_RC68_EVIDENCE||'docs/evidence/rc68')+'/browser/results.json'))}catch{}
const identity=require('./rc68_evidence').identity(),sameBrowser=browser?.result==='passed'&&browser.sourceTreeHash===identity.sourceTreeHash&&browser.buildSha256===identity.buildSha256&&browser.executedBasicScenes===846&&browser.executedRouteNodes>=browser.declarations.routeNodeCount&&browser.normalJourneys.length===4;
for(const item of checks)item.realBrowser=sameBrowser?'same-build all-family UI regression passed':'pending';
save('regression/muse-issues',{result:failures.length?'failed':sameBrowser&&checks.every(x=>x.result==='regression_passed')?'passed':'partial',cases,issues:checks,failures,withdrawn,limits:['Original incomplete recipes not invented; these five seeds are expanded candidate regression','Independent regression is not Muse re-acceptance','Original report classifications remain unchanged; same-build real-browser coverage is reported separately and is not Muse independent re-acceptance']});if(failures.length)process.exitCode=1;
