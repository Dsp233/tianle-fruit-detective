'use strict';
// RC67: explicit adapters read mathematical data, never reverse-parse a story.
// Presentation is independent of the immutable mathematical recipe version.
const CompetitionDesign=((h,rules,problemState)=>{
 const {competitionRng:rng,competitionFraction:F,competitionNumericOptions:options}=h;
 const copy=x=>JSON.parse(JSON.stringify(x)),sum=a=>a.reduce((s,x)=>s+x,0);
 const method=(name,...steps)=>({name,steps});
 const configs={};
 function define(ids,model,goal,change,constraints){for(const id of ids.split(' '))configs[id]={model,goal,change,constraints}}
 define('reverseDigits digitInsert numberAppend divisibleDigits divisibleEleven natural-digitCount natural-distinctDigitCount digitComplement differentDigits digitDivisor','place-and-choice','数位或有序位置中的合法选择','改变位置、重复规则或目标，重新检查合法选择','各位置按题目顺序；首位和零的限制不能省略');
 define('fractionBackwards fractionDifferentWholes fractionSharedRemainder rule-fraction-reverse rule-fraction-original','changing-wholes','对应整体下的使用量或原量','改变分数所对应的整体','离散物品的每一步数量必须为整数；水量允许分数');
 define('percentRoundTrip percentRestore discountOrder natural-offers','changing-base','当前基准下的价格或临界数量','改变基准、顺序或比较目标','百分比作用于明确的价格；配送费只加一次');
 define('ratioEqualize ratioTotal linkedRatios transferBetweenBoxes ratioUnion','ratio-and-conservation','份数对应的实际数量','区分外部增加、内部转移与交集变化','份数不等于实际个数；转移不改变两边总量');
 define('packPrice mixedPacks rule-packs-exact rule-packs-enough','finite-purchase','合法购买方案中的最低费用','恰好与至少的数量边界','包装不可拆；单件和整包均非负整数；覆盖全部有限候选');
 define('equalDistanceSpeed natural-catch riverTravel jointWork stagedClimb','rate-and-boundary','时间、距离或加权速度','改变时间权重、移动规则或停止边界','速度单位一致；到达后是否继续运动须明确');
 define('oppositeScale mapScale scaleAreaReverse similarAreaPerimeter shadowSimilarity parallelTriangle','length-and-area-scale','长度倍率与面积倍率','改变倍率、光照或所求区域','相似的对应长度用同一倍率；面积倍率平方');
 define('balanceCancel tickets twoCoins stampConstraint machineMeeting','balance-and-constraints','同时满足总量与差额的未知数','改变一个约束并重新检查解集','金额和人数限制共同生效；票、硬币和邮票为完整个体');
 define('recurrenceBackwards recurrenceForward recurrenceTotal recurrenceRemainders','recurrence','初始条件及相邻项确定的数列','改变初始条件或累计区间','项号从1开始；初始项不套用第三项规则');
 define('linearTable repeatedMachine machineOrder','affine-operations','按指定顺序的机器输出','改变运算顺序或共同输入','先乘后加与先加后乘分别绑定；相同输入不会自动消去全部加数');
 define('factorBalance threeDivisors divisorPowers equalBags natural-tiles','factor-constraints','合法因数或共同规格','改变极值目标、袋数要求或缩放','正整数因数必须覆盖；规格能完整划分对象');
 define('bells offsetBells lastDigit cyclicPosition repeatedOnes','cycle-and-endpoints','循环位置或共同事件','改变方向、起止端点或追加一位','明确起点计不计；余数0对应完整周期而非首位置');
 define('fixedPerimeter boundaryNotch squareBorder rectangleDiagonalArea lShapeArea crossArea overlapSquares','boundary-and-area','边界、面积和新增部分','改变缺口位置、覆盖次数或合法边长','正尺寸；同一边界不重计；面积和周长分别求解');
 define('outsideAngle natural-angleRatio angleMarks polygonTurn semicircleBoundary circleRoute circleRingRatio','angle-and-circle','角量、弧长与完整边界','改变图形总量、行走方向或直边是否外露','按指定圆周率；弧和直径属于不同边界部分');
 define('ladderShift natural-coordinateDistance coordinateHorizontal hypotenuseMidpoint','distance-geometry','直线距离和对应直角边','改变已知边、路径限制或中点位置','坐标差与坐标值分开；网格行走不是直线距离');
 define('paintedCube cubeProbability cubeSteps openBox','spatial-boundary','空间位置分类或合法体积','改变涂色面、层数、样本空间或可用材料','角、棱、面不重复；盒底与高为正；遮挡不改变数量');
 define('exactlyOneSet setOutside threeSetExactlyTwo natural-unionChance natural-complementChance','sets-and-multiplicity','交集与补集中的不同对象','改变交集或样本范围','所有人数为整数；交集属于各组，不能重复计总人数');
 define('gridDetour routeProbability stepwiseRoute','route-and-sampling','受限制路径及其机会','改变路径限制或随机选择规则','完整路线等可能与每个岔口等可能是不同实验');
 define('adjacentLine restrictedTeam unorderedPairs circularSeating parityPermutations menuBranches binaryNoNeighbors allThreeColors rotatingColors','arrangement-and-equivalence','合法排列、分类或等价类','改变相邻限制、样本角色、旋转等价或可用类别','有序/无序和旋转等价明确；分类互斥且完整');
 define('chartScale chartAverage truncatedBars cumulativeChart','chart-and-scale','图表刻度及非重计总量','改变柱高、档位或累计区间','起点、每格、累计/单档须区分；不把图高当总量');
 define('missingAverage natural-weighted natural-fractionWeighted rule-weighted-mean rule-weighted-score overlapAverages medianSort','total-and-position','权重、总和或排序位置','改变人数、重叠位置、删放次数或极端值','人数权重不等时不能直接平均两组；重叠只能扣一次');
 define('diceSum natural-pairChance conditionalBalls spinnerLabels remainderProbability overlapProbability','sample-space','等可能具体结果中的有利部分','改变放回规则、条件样本空间或卡片范围','概率分母对应真正等可能对象；条件变化要同时复核分子');
 define('foldHoles quarterTurn transformOrder','transformation','同一对象在变换后的对应位置','改变折痕位置、转向或操作顺序','折痕上的点与内部点复制次数不同；镜像与旋转不可任意交换');
 define('checkerDomino lightSwitchParity ballReplacement worstCaseColors','invariant-and-guarantee','不变量给出的限制或最坏失败方案','改变颜色约束、开关次数或保证目标','上界须有达到它的构造；保证问题先构造最大失败情况');
 define('pairedSum telescopingDifferences neighborProducts consecutiveRepresentations squareBounds signedProduct','structure-and-domain','配对、消去、平方界或符号筛选','改变累计范围、允许的首项、因子个数或上下界','检查完整合法候选；负号、首项与非平方边界保留');
 define('rule-join-open rule-join-closed rule-join-piece','joined-length','连接后总长度或单段长度','长条改闭环，首尾是否新增连接处','每个连接处只扣一次重叠；材料必须适合弯曲或直排');
 define('rule-posts-both rule-posts-neither','interval-endpoints','间隔与标记的对应','两个端点计入与否','距离能被间隔整除；内部点与端点明确');
 define('rule-ratio-length rule-ratio-perimeter','ratio-perimeter','长宽份数与半周长','改变已知量、目标或整体尺度','周长是两条长和两条宽；长宽均正');
 define('unitConversion','unit-conversion','把容量转换为同一单位再求杯数','改变单杯容量','升和毫升不能直接相除；完整杯数为整数');
 define('ageDifference','constant-age-gap','同一年龄差下的倍数关系','改变时间和年龄倍数','同时长一岁不会改变年龄差；过去和现在的年龄不能混用');
 define('rectanglePointAreas','shared-height-balance','同一长方形中相对三角形的面积和','只平移内部点并改变所求面积','点在内部；相对三角形共享等长底边，两条高的和固定');
 define('threeGroupBalance','three-group-reference','用共同参照确定三组人数','改变差额方向、倍数参照或目标','三组正整数，三个条件同时满足');
 const variations={};
 const variation=(ids,category,recheck)=>{for(const id of ids.split(' '))variations[id]={category,recheck}};
 variation('reverseDigits','dependency','位值差换成数字差；由互换后两数之和还原数字和，再确定较小数');
 variation('digitInsert factorBalance','goal','在同一完整合法候选集合中把最大和最小目标互换');
 variation('numberAppend','dependency','追加的数字从个位移到百位，原数的位值不再整体乘10');
 variation('fractionBackwards fractionSharedRemainder rule-fraction-original','whole','第二次分数的整体在原量与余量之间改变，重建两次用量关系');
 variation('rule-fraction-reverse','whole','第二次分数改以第一次用量为整体；第一次用量与余量不相等');
 variation('fractionDifferentWholes','goal','所求从两盒取出量改为余量；各盒分数仍分别对应各自整体');
 variation('percentRoundTrip percentRestore','whole','恢复原价需要除以变化后的价格，不能沿用原百分数');
 variation('discountOrder linearTable repeatedMachine transformOrder','dependency','互换两步操作，追踪先操作的增量是否被后一步乘或反射');
 variation('squareBorder','boundary','完整外圈改为左上两边，新增外角与两条边分别只计一次');
 variation('ratioEqualize','goal','只加红球改为只减蓝球；相等后的数量对应原来的红球量');
 variation('ratioTotal transferBetweenBoxes','dependency','外部只向一边加入，数量差只缩小加入量；内部转移会同时改变两边');
 variation('linkedRatios','goal','只变蓝色到与绿色相等；原两个比例不再同时保持');
 variation('packPrice mixedPacks rule-packs-exact','constraint','数量恰好改为至少，额外整包成为合法候选；重新比较边界方案');
 variation('rule-packs-enough','constraint','禁止单买并要求恰好；先检查整包整除可行性，再考虑费用');
 variation('equalDistanceSpeed','whole','等路程改为等时间，平均速度使用的时间权重改变');
 variation('natural-catch','dependency','追上后快者停止，之后间距增长率由慢者速度决定');
 variation('jointWork riverTravel','dependency','取消一人工作或水流后，各段有效速率改变，总工作量或路程保留');
 variation('stagedClimb','boundary','白天到达后停止改为每夜都回退，比较完整昼夜位置而非白天峰值');
 variation('oppositeScale','constraint','取消面积固定，两个长度同倍率改变，面积使用倍率平方');
 variation('mapScale scaleAreaReverse','dependency','增加或取消一次缩放，每个长度倍率对应各自的阶段整体');
 variation('similarAreaPerimeter','dependency','由周长倍率求面积倍率，改走长度到面积的方向');
 variation('shadowSimilarity','invariant','光照改变使同一时刻两杆影长同倍率缩短，高度仍不变');
 variation('parallelTriangle','whole','改为半边长的小相似三角形，梯形占比需要先平方再取补集');
 variation('natural-tiles','invariant','地面加倍且允许重新选最大砖，地面与砖的面积同乘4，块数保持');
 variation('unitConversion','invariant','总容量不变，每杯容量加倍，完整杯数按反比改变');
 variation('balanceCancel','dependency','只从天平右边移去一个盒子，需在同侧补回其重量');
 variation('tickets stampConstraint','constraint','解除总人数或两种都须出现的约束；重新列完整非负整数解');
 variation('twoCoins','goal','每种各取一枚后求总金额，减少的金额与减少的枚数不同');
 variation('ageDifference','invariant','改问未来2倍年龄时刻，年龄差保持，倍数对应的时间改变');
 variation('recurrenceBackwards','dependency','只增加第一项，增量从1、0开始同规则递推，第二项保持');
 variation('recurrenceForward','dependency','交换不相等的初始项，按同一规则重新推进到指定项号');
 variation('recurrenceTotal','boundary','累计区间去掉第一项，起点和消去后的剩余边界改变');
 variation('recurrenceRemainders','dependency','初始项加倍但取余不是线性求和，1与2的余数类别交换');
 variation('machineMeeting','dependency','只给甲输出加1，共同输出的交点改变，差速保持');
 variation('machineOrder','invariant','共同输入加倍，两个合成式的输入项仍抵消，检查差由常数项决定');
 variation('divisibleDigits','constraint','末位被5整除改为偶数，再与数字和被9整除联合筛选');
 variation('digitDivisor','constraint','允许个位为0不能使除以0有定义，区分规则非法与计数增加');
 variation('divisibleEleven threeDivisors','goal','保留完整合法列表，从取最大或计数改为计数或取最大');
 variation('divisorPowers','constraint','只保留平方因数，各质因数指数必须为偶数');
 variation('equalBags','constraint','不再要求袋数最多，袋数必须是共同规格的因数，不能任取');
 variation('bells rule-posts-both rule-posts-neither','boundary','重新核对起点和终点是否计入，间隔数不等于点数');
 variation('offsetBells','boundary','从实际第一次共同响继续一个共同周期，不以第0分钟替代实际起点');
 variation('lastDigit','goal','从一个幂的末位改为两个相邻幂之和的末位，需分别定位并再取个位');
 variation('cyclicPosition quarterTurn','dependency','从同一个起点逆向走或转，余步相同但位置对应方向相反');
 variation('repeatedOnes','dependency','末尾添1把当前余数映射为10倍加1再取余，不能直接把余数加1');
 variation('fixedPerimeter','constraint','最大面积改为边长至少3时的最小面积，合法边界和极值方向同时改变');
 variation('rectangleDiagonalArea','invariant','只有长乘3/2，三角形仍占长方形一半，面积只随这一个长度变化');
 variation('boundaryNotch','boundary','中间凹口改为内部洞，外边没有被替换，内外两圈边界都要计入');
 variation('outsideAngle','goal','已知同一外角改求另一个底角，使用互补与等腰对应关系');
 variation('angleMarks','goal','较短方向角改为另一个方向围角，两个目标合计一整圈');
 variation('polygonTurn','boundary','只累计实际经过的顶点，奇数顶点的取整规则不能省略');
 variation('overlapSquares','goal','至少一张覆盖改为恰好一张，交集从扣一次改为扣两次');
 variation('lShapeArea','invariant','缺口移到内部，轮廓改变但挖去面积不变；重新核对所求仍为面积');
 variation('crossArea','goal','并集面积改为交叉面积，重计修正与目标区域不同');
 variation('circleRoute','constraint','较短补弧改为往返且覆盖全圆，目标受覆盖下界限制');
 variation('semicircleBoundary','boundary','两块沿直径合回整圆，原直径变成内部接触边不计外周');
 variation('circleRingRatio','invariant','半径都加倍，分子分母面积同乘4，占比保持');
 variation('ladderShift','dependency','固定梯长，把高度作为已知边求底距，已知未知位置交换');
 variation('coordinateHorizontal','invariant','两点同时平移，坐标差保持，不能把平移量加到距离');
 variation('natural-coordinateDistance','constraint','直线移动改为只走水平竖直网格，最短距离的合法路径集合改变');
 variation('hypotenuseMidpoint','dependency','中点移到较长直角边，不能沿用斜边中点到三顶点等距的关系');
 variation('paintedCube','constraint','只涂互不相邻的顶底面，恰好一面涂色分类改为两个完整表层');
 variation('cubeSteps','invariant','每列前后厚度都加倍，所有层数量加倍，列高关系保留');
 variation('openBox','goal','固定剪角为1并改求底面积，不再枚举体积最大值');
 variation('exactlyOneSet setOutside','dependency','同一个人增加另一个组，组计数可增两次，不同人数只增一次');
 variation('ratioUnion','dependency','同一位只在棋组的人加入球组，球组和交集同时加1，不同总人数保持，原比例失效');
 variation('threeSetExactlyTwo','goal','恰好两组改为至少两组，三组交集应只加回一次');
 variation('gridDetour routeProbability','constraint','避开P改为固定第一步向上，不再扣通过P的路线');
 variation('menuBranches','dependency','饮料选择作用于整份午餐，包括米饭和面两种互斥分支');
 variation('binaryNoNeighbors','constraint','第一盏必须亮会迫使第二盏灭，不能把全部安排简单减半');
 variation('adjacentLine','constraint','必须相邻改为不能相邻，用完整排列集合减相邻集合');
 variation('restrictedTeam','constraint','禁止两人同时入选改为必须同选，无职位的剩余位置只选第三人');
 variation('unorderedPairs differentDigits','constraint','是否分职位或交换顺序算不同改变，成对重复计数因子改变');
 variation('circularSeating','constraint','去掉相邻限制，但仍需固定旋转参照，镜像规则保持');
 variation('parityPermutations','constraint','奇偶交换限制角色，重查主体人数和空位是否足够，不能只改名称');
 variation('digitComplement','constraint','至少出现一次改为恰好一次，其他位置禁止再出现该数字');
 variation('allThreeColors','constraint','三色全出现改为恰好两色，先选颜色组再排除两种纯色');
 variation('natural-digitCount natural-distinctDigitCount','constraint','允许或禁止同一个数字重复使用，再与整除条件联合筛选');
 variation('chartScale','dependency','所有柱各加一格但刻度保持，总人数增加量由柱数乘每格人数');
 variation('truncatedBars','goal','实际总人数改为人数差，共同纵轴起点只在相减时抵消');
 variation('cumulativeChart','goal','改变实际分数档，累计上界之差对应新的目标区间');
 variation('chartAverage','dependency','新增一名6分者，总分与人数同时改变，重新核对平均权重');
 variation('missingAverage','dependency','被删数放回两次，总和和人数都增加，不能只改平均数');
 variation('medianSort','invariant','只增加最大值，排序中间位置保持；中位数与平均数响应不同');
 variation('overlapAverages','dependency','前后段从4+4改为5+5，唯一重叠位置从第4个移到第5个，总和乘数改变');
 variation('natural-weighted natural-fractionWeighted','whole','交换两队人数权重，个人积分不变，重新确定两组总分占比');
 variation('rule-weighted-mean rule-weighted-score rule-ratio-length rule-ratio-perimeter','dependency','沿用明确比例但交换已知和未知，重新确定总量、份量和所求的依赖方向');
 variation('diceSum natural-unionChance natural-complementChance cubeProbability spinnerLabels conditionalBalls overlapProbability','sampling','新条件或区域改变等可能样本空间，分子分母都需重新检查');
 variation('natural-pairChance','sampling','不放回改为放回，第二次红球数和总数保持，具体结果的概率关系改变');
 variation('stepwiseRoute','sampling','每岔口等概率改为完整路线等概率，同一P的路径权重改变');
 variation('foldHoles','dependency','一个孔从单折痕移到内部，对称复制次数由2改为4');
 variation('checkerDomino','constraint','去除两同色角改为一黑一白，颜色上界改变，还需给达到上界的铺法');
 variation('lightSwitchParity ballReplacement','invariant','只增加一次翻转或一个白球，使决定最终状态的奇偶改变');
 variation('pairedSum telescopingDifferences','boundary','求和只留偶数或去掉首项，配对和消去后的端点改变');
 variation('neighborProducts','invariant','对称偏移从1改为2，中间一次项仍抵消，差等于偏移的平方');
 variation('squareBounds','goal','不超过平方根改为不小于，非平方数的两侧整数不同');
 variation('signedProduct','constraint','改为选两张而非三张，负乘积需要的符号组合及枚举集合改变');
 variation('rule-join-open rule-join-closed rule-join-piece','boundary','长条与闭环互换，首尾闭合会增一个连接处；单段未知先还原各段总和');
 variation('rectanglePointAreas','invariant','P水平移动，左右三角形面积和保持，上下两块不变，重新定位改变的区域');
 variation('worstCaseColors','constraint','提高保证的同色数量，各色最大失败取数受库存上界共同限制');
 variation('consecutiveRepresentations','constraint','首项允许0，新增写法只能从0开始，是否新增必须独立检查三角数条件');
 variation('remainderProbability','sampling','加入写0卡，分母必增1，分子仅目标余数为0时增加');
 variation('rotatingColors','constraint','加入固定星标后旋转不再合并，每个递增红位置集合单独计数');
 variation('natural-offers','goal','两店单次费用差改为最低整数购买量，固定配送费与每本价差确定临界点');
 variation('natural-angleRatio','whole','三角形改为四边形，总角量从180改360，比例份数及所求角同步改变');
 const hintPolicy={
  'place-and-choice':'把不同位置分别列出，再用题目的零、重复、整除或数位条件筛选。哪些选择先被排除？',
  'changing-wholes':'给每次分数圈出它的整体。后一次的整体是原量、余量，还是前一次的用量？',
  'changing-base':'把每个百分比连到它实际作用的价格。固定金额和百分比作用于同一个量吗？',
  'ratio-and-conservation':'画同一大小的份数。改变一边时，另一边是否也同时改变？',
  'finite-purchase':'先判定数量是否满足限制，再比较完整方案的费用。允许多买时，边界外哪一个整包方案需要补查？',
  'rate-and-boundary':'把每段经过的时间、距离和停止规则分开。最后一步还会发生下一次变化吗？',
  'length-and-area-scale':'先找对应长度的倍率，再判断所求量含一个长度还是两个长度。',
  'balance-and-constraints':'先固定一种数量，看另一种数量能否同时满足总量与差额；不能只核对一个条件。',
  'recurrence':'标清项号，从已知的相邻两项向需要的方向推进。改变初始项后，增量是否也遵守同一规则？',
  'affine-operations':'把输入沿箭头依次送进每一步。先加的量会不会在后一步被乘？',
  'factor-constraints':'把合法因数配成完整的一对，检查所有边界，再比较题目要的是最大还是最小。',
  'cycle-and-endpoints':'先找一次完整循环，再从原起点数余下部分；检查起点与终点的计数规则。',
  'boundary-and-area':'沿轮廓或新增部分观察。哪些只是替换，哪些确实多出？面积与边界长度分别计算。',
  'angle-and-circle':'先确定完整图形的角总量或一周边界，再检查直边、补弧与转角的角色。',
  'distance-geometry':'只使用已知的边或坐标差。所求是直线、网格路线，还是中点到顶点？',
  'spatial-boundary':'按空间位置分组：角、棱、面、内部是否重复？先确认每块属于哪一类。',
  'sets-and-multiplicity':'追踪一个同时参加多组的人，在各项中被数了几次；目标希望最终保留几次？',
  'route-and-sampling':'在格点上标合法出口。题目随机的是每个岔口，还是已经完整列出的路线？',
  'arrangement-and-equivalence':'找一个不会重复的分类或参照位置。交换顺序、旋转和镜像分别算不算不同？',
  'chart-and-scale':'先看坐标起点、每格和累计含义；新增一格或减少一档分别对应什么数量？',
  'total-and-position':'平均数要和人数一起看；中位数要和排序位置一起看。哪一个整体或位置固定？',
  'sample-space':'先列真正等可能的具体对象，再圈出符合条件的部分；新条件排除了哪些结果？',
  'transformation':'逐步追踪同一点或方向，不跳过中间操作；位于折痕和内部的点是否相同？',
  'invariant-and-guarantee':'检查一次操作能改变什么、保留什么；保证问题先构造仍会失败的最多数量。',
  'structure-and-domain':'先按合法符号、位置或边界分类，再看能否配对、消去或用相邻平方夹住。',
  'joined-length':'数连接处而不是只数材料段；首尾闭合后是否还多一个连接处？',
  'interval-endpoints':'先区分线段间隔与圆点标记；两端加入或去掉时改变的是哪个数量？',
  'ratio-perimeter':'沿长方形走一周，有几条长和几条宽？一条长加一条宽对应哪部分周长？',
  'unit-conversion':'把总量和每份容量都写成相同单位，再比较有多少个完整份。',
  'constant-age-gap':'把过去、现在和未来分开；两人一起长大时，哪个差保持不变？',
  'shared-height-balance':'把相对的两块三角形放在一起，观察相同底边和两条高的总长度。'
 };

 variation('threeGroupBalance','dependency','差额方向或倍数参照改变，重新连接总量');
 hintPolicy['three-group-reference']='把每条关系连接到总人数；多出的部分属于哪一组？';
 function load(c,f){
  const id=f.id,m=c.math,p=m.params||m;
  const enumerations={fixedPerimeter:Math.floor(m.half/2),factorBalance:Math.floor(Math.sqrt(m.product)),signedProduct:20,divisibleDigits:20,divisibleEleven:20,openBox:Math.floor((m.side-1)/2),stampConstraint:Math.floor(m.total/3),consecutiveRepresentations:Math.floor(Math.sqrt(2*m.total)),rotatingColors:2**m.n};
  const enumeration=enumerations[id]||(/packs|packPrice|mixedPacks/.test(id)?Math.ceil((p.count||0)/(p.size||4))+1:0);
  const shortcut=['pairedSum','telescopingDifferences','neighborProducts','machineOrder','recurrenceTotal','lightSwitchParity','ballReplacement','boundaryNotch'].includes(id);
  const fractional=['natural-weighted','natural-fractionWeighted'].includes(id)?c.answer.includes('/')||m.den!==1:/fraction|percentRestore|Probability|Chance|diceSum|spinnerLabels|mean/.test(id);
  const answerMagnitude=String(c.answer).split('/').map(Number).filter(Number.isFinite);
  const digits=Math.max(...Object.values(p).filter(x=>typeof x==='number').concat(answerMagnitude).map(x=>String(Math.abs(Math.trunc(x))).length),1);
  const operations=shortcut?2:Math.min(8,c.methods[0].steps.length+Number(fractional));
  const score=operations+Number(fractional)*2+Number(digits>2&&!shortcut)*2+Number(digits>3&&!shortcut)*2+Number(enumeration>12)*3;
  return {reasoningLoad:{level:f.level,reason:f.insight},calculationLoad:{level:score<=4?1:score<=7?2:3,operations,fractional,enumeration,digits,reason:shortcut?'可利用已定义的消去、配对或不变量简算':`有效路线约 ${operations} 步${fractional?'，含分数或比值':''}${enumeration?`；需检查至多 ${enumeration} 个候选`:''}`},readingLoad:{level:c.prompt.length<100?1:c.prompt.length<165?2:3,characters:c.prompt.length,reason:'按一个情境、目标和必要限制的实际文本长度估计'}};
 }

 function revise(c,f,seed){
  const r=rng(seed),id=f.id;
  if(id==='packPrice'){
   const single=3+r(6),branch=r(3),count=6+3*r(3)+(branch===2?1:2),pack=branch===0?single+1+r(single-1):branch===1?2*single:2*single+1+r(single-1);
   const full=Math.floor(count/3),loose=count%3,exact=full*pack+loose*single,extra=(full+1)*pack,answer=String(exact);
   c={...c,math:{single,pack,count},answer,options:options(answer,r),prompt:`一种笔单支 ${single} 元，3 支装每包 ${pack} 元。可以混合买，但必须恰好买 ${count} 支。最少花多少元？`};
   c.methods=[method('逐个比较合法包数',`整包不能拆，包数从0到 ${full}；余下的笔单买。`,`每包比3支单买少 ${3*single-pack} 元，所以合法范围内包数越多越省。`,`买 ${full} 包、单买 ${loose} 支，费用 ${full}×${pack}+${loose}×${single}=${exact} 元。`)];
   c.extension={prompt:'数量条件改为至少买够，允许多买；最少需要多少元？',answer:String(Math.min(exact,extra)),solution:`必须补查 ${full+1} 包的方案：共 ${(full+1)*3} 支，费用 ${extra} 元。原来的恰好方案为 ${exact} 元。${extra<exact?'多买反而更省':extra===exact?'两种方案费用相同':'恰好方案更省'}，最低 ${Math.min(exact,extra)} 元。`,kind:'condition-change',math:{single,pack,count,atLeast:true}};
  }
  if(id==='mixedPacks'){
   const p=9+r(6),branch=r(3),q=branch===0?p-1-r(3):branch===1?p:p+3+r(3),count=8+6*r(3),plans=[];
   for(let a=0;a<=Math.ceil(count/4);a++)for(let b=0;b<=Math.ceil(count/6);b++)if(4*a+6*b>=count)plans.push({a,b,bought:4*a+6*b,cost:a*p+b*q});
   const exact=plans.filter(x=>x.bought===count).sort((a,b)=>a.cost-b.cost)[0],enough=plans.sort((a,b)=>a.cost-b.cost||a.bought-b.bought)[0],answer=String(exact.cost);
   c={...c,math:{p,q,count},answer,options:options(answer,r),prompt:`笔只有4支装和6支装，分别 ${p} 元、${q} 元。必须恰好买 ${count} 支，不能拆包。最少花多少元？`};
   c.methods=[method('固定一种包数，完整检查另一种',`4支装从0包到 ${Math.floor(count/4)} 包；余下数量必须能被6整除。`,`逐个核对 4×包数+6×包数=${count}，再比较所有合法方案费用。`,`最低方案：4支装 ${exact.a} 包、6支装 ${exact.b} 包，${exact.a}×${p}+${exact.b}×${q}=${exact.cost} 元。`)];
   c.extension={prompt:'如果允许买超过需要的数量，最少花多少元？',answer:String(enough.cost),solution:`分别检查4支装至 ${Math.ceil(count/4)} 包、6支装至 ${Math.ceil(count/6)} 包，数量至少 ${count}。最低买4支装 ${enough.a} 包、6支装 ${enough.b} 包，共 ${enough.bought} 支，${enough.cost} 元。边界外的方案也必须比较，不能只看原来的恰好方案。`,kind:'condition-change',math:{p,q,count,atLeast:true}};
  }
  if(id==='natural-weighted'||id==='natural-fractionWeighted'){
   const red=1+r(3),blue=red+1+r(2),low=2+r(4),high=low+(id==='natural-weighted'?(red+blue)*(1+r(2)):2+r(4)),total=red+blue;
   c={...c,math:{red,blue,redScore:low,blueScore:high,den:1,total},answer:F(red*low+blue*high,total)};
   c.prompt=`红队与蓝队人数比为 ${red}:${blue}。红队每人得 ${low} 分，蓝队每人得 ${high} 分。所有队员的平均分是多少？`;
   c.options=options(c.answer,r);
   c.methods=[method('按人数份数合计',`取红 ${red} 人、蓝 ${blue} 人的一组作代表，共 ${total} 人。`,`两队分别得 ${red}×${low}=${red*low} 与 ${blue}×${high}=${blue*high} 分，总分 ${red*low+blue*high}。`,`每人平均 ${red*low+blue*high}÷${total}=${c.answer} 分。`),method('以低分作基准补上差额',`如果每人都得 ${low} 分，平均也是 ${low} 分。`,`蓝队每人多 ${high-low} 分，${blue} 份共多 ${blue*(high-low)} 分。`,`把差额平均到 ${total} 份，${low}+${F(blue*(high-low),total)}=${c.answer} 分。`)];
   const next=F(blue*low+red*high,total);
   c.extension={prompt:`把两队的人数比改为 ${blue}:${red}，每人得分保持不变。新的平均分是多少？`,answer:next,solution:`改变的是人数权重。红 ${blue} 份得 ${blue*low} 分，蓝 ${red} 份得 ${red*high} 分，共 ${total} 份。新平均 (${blue*low}+${red*high})÷${total}=${next} 分。`,kind:'condition-change',key:'swap-weights',math:{red:blue,blue:red,redScore:low,blueScore:high,den:1,total}};
   c.ruleHints=['两队人数不同，直接把两个分数平均合适吗？','用每个队的代表人数，把每人得分转成整队得分。'];
  }
  if(id==='overlapAverages'){
   const u=7+r(4),v=u+3+r(3),w=Math.floor((4*u+4*v-4)/7),x=4*u+4*v-7*w;
   const split=n=>{const q=Math.floor(n/3);return [q,q,n-2*q]};
   const values=[...split(4*u-x),x,...split(4*v-x)];
   c={...c,math:{values},answer:String(x),prompt:`7个数，前4个平均 ${u}，后4个平均 ${v}，全部平均 ${w}。第4个数是多少？`,options:options(String(x),r)};
   c.methods=[method('先还原总和再去重',`前4个合计 ${4*u}，后4个合计 ${4*v}，全部合计 ${7*w}。`,`两段相加时只有第4个出现两次；${4*u}+${4*v}−${7*w}=${x}。`),method('先找不重叠部分',`全部总和减后4个总和，前3个合计 ${7*w-4*v}。`,`前4个再减前3个，只剩第4个：${4*u}−${7*w-4*v}=${x}。`)];
   const z=[...values,values[0],values[6]],a=sum(z.slice(0,5)),b=sum(z.slice(4)),all=sum(z);
   c.extension={prompt:`另有9个数，前5个平均 ${F(a,5)}，后5个平均 ${F(b,5)}，全部平均 ${F(all,9)}。第5个数是多少？`,answer:String(z[4]),solution:`重叠位置改为第5个。先还原三种总和 ${a}、${b}、${all}，第5个=${a}+${b}−${all}=${z[4]}。`,kind:'condition-change',math:{values:z,groupSize:5}};
  }
  if(id==='fixedPerimeter'){
   const half=c.math.half,min=3,answer=min*(half-min);
   c.extension={prompt:`周长仍为 ${2*half}。两边都是至少 ${min} 的整数，改为求最小面积，是多少？`,answer:String(answer),solution:`长宽和 ${half}。合法短边从 ${min} 到 ${Math.floor(half/2)}；面积在两边靠近时增大，所以最小在最远的一对 ${min}、${half-min}，面积 ${answer}。`,math:{half,minSide:min,target:'minimum-area'},key:'minimum-with-lower-bound',kind:'condition-change'};
  }
  if(id==='boundaryNotch'){
   const {w,h,a,depth}=c.math,outer=2*(w+h),inner=2*(a+depth);
   c.extension={prompt:`把同样宽 ${a}、深 ${depth} 的长方形改为完全挖在纸片内部，不碰外边。外边界和洞口边界都计入，它们的总长度是多少？`,answer:String(outer+inner),solution:`外边界仍为 ${outer}，洞口新形成一整圈 ${a}+${depth}+${a}+${depth}=${inner}。没有原边被替换，所以合计 ${outer+inner}；不能沿用中间凹口只增加两条深度边的规则。`,math:{w,h,a,b:depth,placement:'internal',countInner:true},key:'internal-hole-count-both-boundaries',kind:'condition-change'};
  }
  if(id==='rule-packs-enough'){
   const p=c.math.params,possible=p.count%p.size===0,answer=possible?p.count/p.size*p.pack:0;
   const unit=c.math.context==='seedlings'?'棵树苗':'支画笔';
   c.extension={prompt:`需求仍为 ${p.count} ${unit}，现在只能买 ${p.size} ${unit}装的整包，每包 ${p.pack} 元，不能单买，而且必须恰好。若做不到填写0；能做到填写最少费用。`,answer:String(answer),solution:possible?`${p.count} 能被 ${p.size} 整除，买 ${p.count/p.size} 包恰好，费用 ${answer}。`:`整包只能组成 ${p.size} 的整数倍，${p.count} 不是这样的倍数；费用再便宜也没有合法方案，填写0。`,math:{variant:'packs-only-exact',context:c.math.context,params:copy(p)},key:'whole-pack-feasibility',kind:'condition-change'};
  }
  if(id==='rule-fraction-reverse'){
   // If the first use were one half, its amount would equal the remainder.
   // Build integral supplies backwards with unequal wholes in revision 3.
   const prior=c.math.params,k=prior.left/((prior.d1-1)*(prior.d2-1)),d1=3+r(2);
   c=rules.create('fraction-reverse',{d1,d2:prior.d2,left:(d1-1)*(prior.d2-1)*k},c.math.context,r);
   const p=c.math.params,start=p.left*p.d1*p.d2/((p.d1-1)*(p.d2-1)),first=start/p.d1,second=first/p.d2,left=start-first-second,unit=c.math.context==='supplies'?'张':'升';
   c.extension={prompt:`沿用原来的 ${start} ${unit}。第一次仍用掉原量的 1/${p.d1}，第二次改为用掉“第一次用掉的量”的 1/${p.d2}。最后剩多少${unit}？`,answer:String(left),solution:`第二次的整体是第一次用量 ${first}，不是余量。第二次用 ${first}÷${p.d2}=${second}；原量减两次用量，${start}−${first}−${second}=${left} ${unit}。`,math:{variant:'fraction-of-used',context:c.math.context,params:{d1:p.d1,d2:p.d2,start}},key:'second-fraction-of-first-use',kind:'condition-change'};
  }
  if(id==='quarterTurn'||id==='transformOrder'){
   const start=r(4),count=id==='quarterTurn'?1+2*r(4):1+2*r(2),names=['上','右','下','左'],mirror=v=>(4-v)%4;
   const answer=id==='quarterTurn'?(start+count)%4:mirror((start+count)%4),changed=id==='quarterTurn'?((start-count)%4+4)%4:(mirror(start)+count)%4;
   c={...c,math:id==='quarterTurn'?{start,turns:count}:{start,rot:count},answer:String(answer),options:options(String(answer),r)};
   c.prompt=id==='quarterTurn'?`箭头最初向${names[start]}，每次顺时针旋转90°，连续旋转 ${count} 次。最后向哪个方向？上填0，右填1，下填2，左填3。`:`箭头方向用上0、右1、下2、左3表示，最初是 ${start}。先顺时针转 ${count} 个90°，再沿竖直轴作镜像（左右交换，上下不变），最后方向填几？`;
   c.methods=[method('按指定次序追踪',`从 ${names[start]} 开始，顺时针转 ${count} 个90°，先到 ${names[(start+count)%4]}。`,id==='quarterTurn'?`到 ${names[answer]}，填 ${answer}。`:`接着作左右镜像，到 ${names[answer]}，填 ${answer}。`)];
   c.extension={prompt:id==='quarterTurn'?'改为逆时针旋转同样次数，填哪个数字？':'先镜像、再做相同旋转，最终方向填几？',answer:String(changed),solution:id==='quarterTurn'?`从相同起点逆向转 ${count} 次，最后 ${names[changed]}，填 ${changed}。方向相反时不能沿用原来的结果。`:`先镜像到 ${names[mirror(start)]}，再顺时针转 ${count} 次，到 ${names[changed]}，填 ${changed}。每一步都合法，次序改变了结果。`,math:id==='quarterTurn'?{start,turns:count,direction:'anticlockwise'}:{start,rot:count,order:'mirror-first'},key:'reverse-direction-or-order',kind:'condition-change'};
  }
  return c;
 }

 function units(groups,caption='',extra={}){return {kind:'scene-units',groups,caption,...extra}}
 function slots(values,caption='',extra={}){return {kind:'scene-slots',values,caption,...extra}}
 function flow(nodes,caption='',extra={}){return {kind:'scene-flow',nodes,caption,...extra}}
 function strips(rows,caption='',extra={}){return {kind:'scene-strips',rows,caption,...extra}}
 function circle(values,caption='',extra={}){return {kind:'scene-circle',values,caption,...extra}}
 function timeline(events,caption='',extra={}){return {kind:'scene-timeline',events,caption,...extra}}
 const group=(name,count,unit='份',score=null)=>({name,count,unit,score});
 const row=(label,parts,value='?')=>({label,parts,value});
 const items=(n,text='?')=>Array.from({length:n},()=>text);
 function scene(c,f,variation=false){
  const id=f.id,m=c.math,p=m.params||m,v=variation,E=c.extension,state=problemState.create(c,f,v);
  if(c.rc68Diagram)return copy(v?E.rc68Diagram:c.rc68Diagram);
  if(id.startsWith('rule-')){
   const math=v?E.math:m,k=math.variant,a=math.params,context=math.context;
   if(k.startsWith('join-'))return {kind:'scene-join',n:Number(a.n),piece:k==='join-piece'?'?':Number(a.piece),lap:Number(a.lap),closed:k==='join-closed',total:k==='join-piece'?Number(a.total):'?',caption:k==='join-closed'?'首尾闭合；每个连接处只计一次重叠':context==='panels'?'展示板接成长条':'软材料拼接；阴影是重叠部分'};
   if(k.startsWith('posts-'))return {kind:'scene-intervals',distance:Number(a.distance),gap:Number(a.gap),ends:k==='posts-both',draft:true,caption:'先画一个间隔；其余标记由你建立'};
   if(k.startsWith('weighted-'))return units([group('甲',Number(a.a),'人数份',k==='weighted-score'?'?':a.low),group('乙',Number(a.b),'人数份',a.high)],'用比例中的一组作代表；不是实际总人数',{average:k==='weighted-score'?a.mean:'?',object:'person'});
   if(k.startsWith('ratio-'))return {kind:'scene-ratioRectangle',a:Number(a.a),b:Number(a.b),perimeter:k==='ratio-length'?a.perimeter:'?',width:k==='ratio-perimeter'?a.width:null,length:k==='ratio-length'?'?':null,caption:'长与宽同一份；两条长、两条宽组成一周'};
   if(k.startsWith('fraction-'))return {kind:'scene-fractions',d1:Number(a.d1),d2:Number(a.d2),original:k==='fraction-original',secondOfUsed:k==='fraction-of-used',left:k==='fraction-reverse'?a.left:'?',start:['fraction-original','fraction-of-used'].includes(k)?a.start:'?',unit:context==='supplies'?'张':'升',caption:'第二次分数的整体用括号标出'};
   if(k.startsWith('packs-'))return {kind:'scene-purchase',size:Number(a.size),single:k==='packs-only-exact'?undefined:a.single,pack:a.pack,count:Number(a.count),enough:k==='packs-enough',object:context==='seedlings'?'棵树苗':'支画笔',caption:k==='packs-only-exact'?'只能买整包，必须恰好':k==='packs-enough'?'允许多买，包装完整':'必须恰好，包装完整'};
   throw Error('No rule scene '+k);
  }
  switch(id){
   case 'natural-weighted':case 'natural-fractionWeighted':{const a=v&&E.key==='swap-weights'?E.math:{...m,red:v?2*m.red:m.red};return units([group('红队',a.red,'人数份',F(a.redScore,a.den)),group('蓝队',a.blue,'人数份',F(a.blueScore,a.den))],'按比例取一组代表；每人分数见积分标记',{object:'person',average:'?'})}
   case 'fractionBackwards':return {kind:'scene-fractions',d1:2,d2:3,original:v,left:v?'?':m.left,start:'?',unit:'枚',caption:v?'两次都按最初总数':'第二次按第一天剩下的贴纸'};
   case 'fractionSharedRemainder':return flow([{label:'最初',value:'?'},{label:'取原量1/3',value:'−'},{label:'放回',value:m.add+' 个'},{label:v?'取原量3/8':'取现有3/8',value:'−'},{label:'最后',value:v?'?':(5*m.unit+5*m.add/8)+' 个'}],'两个分数是否对应同一整体？');
   case 'fractionDifferentWholes':return strips([row('甲盒：'+m.a+' 颗',4,v?'剩余3份':'取出1份'),row('乙盒：'+m.b+' 颗',3,v?'剩余2份':'取出1份')],'每条代表各自的整体；两条不是同一份大小',{selected:v?'remaining':'removed',separateWholes:true});
   case 'packPrice':return {kind:'scene-purchase',size:3,single:m.single,pack:m.pack,count:m.count,enough:v,object:'支笔',caption:v?'至少买够，允许多买':'必须恰好买足'};
   case 'mixedPacks':return {kind:'scene-purchase',packs:[{size:4,price:m.p},{size:6,price:m.q}],count:m.count,enough:v,object:'支笔',caption:'不能拆包；分别比较4支装与6支装'};
   case 'ratioEqualize':return strips([row('红',m.a),row('蓝',m.b)],v?'只从蓝取走 '+(m.b-m.a)*m.unit+' 个':'只向红加入 '+(m.b-m.a)*m.unit+' 个',{equalAfter:true,changeSide:v?'blue':'red'});
   case 'ratioTotal':return strips([row('红',m.a),row('蓝',m.b)],'两色原来合计 '+(m.a+m.b)*m.u+' 块'+(v?'；只加 '+(m.b-m.a)+' 块红色':''));
   case 'linkedRatios':return strips([row('红:蓝',m.a+m.b,`${m.a}:${m.b}`),row('蓝:绿',m.c+m.d,`${m.c}:${m.d}`)],'绿 '+m.b*m.d*m.u+' 块'+(v?'；只改变蓝色':'；两行蓝色为同一数量'),{linked:true});
   case 'transferBetweenBoxes':return strips([row('甲',m.a),row('乙',m.b)],v?`外部只向甲加入 ${m.moved} 块`:`从乙移 ${m.moved} 块给甲后相等`,{transfer:v?'external':'between',moved:m.moved});
   case 'balanceCancel':return {kind:'scene-balance',left:{boxes:v?m.a+1:m.a+1,weight:m.b},right:{boxes:v?m.a-1:m.a,weight:m.x+m.b},caption:v?'右边少一个盒子，需要补砝码':'相同盒子，同一副水平天平'};
   case 'tickets':return units([group('成人票',1,'种',m.adult),group('儿童票',1,'种',m.child)],`总价 ${m.adults*m.adult+(m.people-m.adults)*m.child} 元${v?'；不限总人数':`；共 ${m.people} 人`}`,{object:'ticket'});
   case 'twoCoins':return units([group('1元币','?','枚',1),group('2元币','?','枚',2)],`${v?'取走每种各1枚前：':''}共 ${m.n} 枚，${m.n+m.twos} 元`,{object:'coin'});
   case 'stampConstraint':return units([group('3元邮票','?','张',3),group('5元邮票','?','张',5)],`恰好 ${m.total} 元；${v?'允许一种不用':'每种至少一张'}`,{object:'stamp'});
   case 'repeatedMachine':return flow([{label:'输入',value:v?m.x:'?'},{label:'第1次',value:v?`(+${m.b})×${m.a}`:`×${m.a}+${m.b}`},{label:'第2次',value:v?`(+${m.b})×${m.a}`:`×${m.a}+${m.b}`},{label:'输出',value:v?'?':(m.x*m.a+m.b)*m.a+m.b}],'机器每次使用同一个规则');
   case 'machineOrder':return {kind:'scene-twoFlows',rows:[{name:'先甲后乙',nodes:[v?2*m.x:m.x,`×${m.a}+${m.b}`,`×${m.c}+${m.d}`,'?']},{name:'先乙后甲',nodes:[v?2*m.x:m.x,`×${m.c}+${m.d}`,`×${m.a}+${m.b}`,'?']}],caption:'同一个输入，两种顺序'};
   case 'machineMeeting':return {kind:'scene-twoFlows',rows:[{name:'甲',nodes:['?',`×${m.a}+${m.d+(v?1:0)}`,'同一输出']},{name:'乙',nodes:['?',`×${m.c}+${m.b}`,'同一输出']}],caption:'比较每增加1输入，两边输出怎样变化'};
   case 'linearTable':return v?flow([{label:'输入',value:m.target},{label:'先加',value:m.b},{label:'后乘',value:m.k},{label:'输出',value:'?'}],'沿用从原表发现的两个固定数'):{kind:'table',rows:[['输入',m.x,m.x+2,m.target],['输出',m.k*m.x+m.b,m.k*(m.x+2)+m.b,'?']]};
   case 'percentRoundTrip':return flow([{label:'原价',value:m.start+' 元'},{label:'上涨',value:m.percent+'%'},{label:v?'恢复原价':'下降',value:v?'? %':m.percent+'%'},{label:v?'目标价格':'便宜多少',value:v?m.start+' 元':'? 元'}],'每个百分比的括号都指向它前面的价格');
   case 'discountOrder':return flow([{label:'原价',value:m.price},{label:v?'先用券':'先折扣',value:v?'−'+m.q:'×'+(100-m.p)+'%'},{label:v?'后折扣':'后用券',value:v?'×'+(100-m.p)+'%':'−'+m.q},{label:'价格',value:'?'}],'操作顺序决定百分比的整体');
   case 'percentRestore':{const p=v&&m.p===100?50:m.p;return strips([row('原价',100,100),row(v?'先降后的价':'先涨后的价',v?100-p:100+p,v?100-p:100+p)],v?'从降低后的价格涨回100':'从提高后的价格降回100',{continuous:true})}
   case 'natural-offers':return {kind:'scene-twoFlows',rows:[{name:'甲店',nodes:[v?'? 本':m.count+' 本',m.price+' 元/本','×75%','+'+m.fee+' 配送']},{name:'乙店',nodes:[v?'? 本':m.count+' 本',m.price-1+' 元/本','免配送']}],caption:v?'求甲总价不高于乙的最少整数本数':'比较同样本数的整单费用'};
   case 'equalDistanceSpeed':return {kind:'scene-journey',segments:[{name:'去',speed:m.speed},{name:'回',speed:2*m.speed}],speedUnit:state.units.speed,equal:v?'time':'distance',caption:v?'去回时间相同':'去回路程相同，时间未必相同'};
   case 'natural-catch':return {kind:'scene-journey',segments:[{name:'小乐',speed:m.slow},{name:'小明',speed:m.fast}],delay:m.delay,afterCatch:v,caption:v?`追上后小明停，小乐再走 ${m.delay} 分钟`:`小乐先走 ${m.delay} 分钟，小明再出发`};
   case 'riverTravel':return {kind:'scene-journey',segments:[{name:'顺流',speed:v?m.v:'?'},{name:'逆流',speed:v?m.v:'?'}],distance:m.distance,equal:'distance',caption:v?'取消水流，静水速度 '+m.v+' 千米/时':'已知静水 '+m.v+'，水流 '+m.c+' 千米/时；实际行驶速度由你推导'};
   case 'jointWork':return units([group('甲',1,'人',m.a),...(!v?[group('乙',1,'人',m.b)]:[])],`每分钟分别完成图中数量；目标 ${(m.a+m.b)*m.t} 个盒子`,{object:'person',scoreUnit:'个/分钟'});
   case 'unitConversion':return flow([{label:'总量',value:m.liters+' 升'},{label:'统一单位',value:'1升=1000毫升'},{label:'每杯',value:m.cup*(v?2:1)+' 毫升'},{label:'杯数',value:'?'}],'同一单位的容量相除');
   case 'stagedClimb':return {kind:'scene-climb',up:m.up,down:m.down,height:m.height,stop:!v,caption:v?'每个夜晚都完整回退':'白天到标记立即停，不再夜间回退'};
   case 'fixedPerimeter':return {kind:'scene-fixedPerimeter',half:m.half,even:v&&!E.math?.minSide,minSide:v?E.math?.minSide:null,caption:`周长 ${2*m.half}，${v&&E.math?.minSide?'每边至少 '+E.math.minSide:v?'两边为正偶数':'两边为正整数'}；${v&&E.math?.minSide?'求最小':'比较'}面积`};
   case 'overlapAverages':{const a=v?(E.math?.values||[...m.values,m.values[0],m.values[6]]):m.values,n=a.length,k=(n+1)/2;return {kind:'scene-overlapSequence',n,k,means:[F(sum(a.slice(0,k)),k),F(sum(a.slice(k-1)),k),F(sum(a),n)],caption:`第 ${k} 个位置同时属于前后两段；只给平均，不给各数`}}
   case 'missingAverage':return strips([row('原来 '+m.count+' 个',m.count,'平均 '+m.mean),row('余下 '+(m.count-1)+' 个',m.count-1,'平均 '+m.other),row(v?'再放回两次':'删去',v?2:1,'?')],v?'余下的数与两份删去数合并':'两条的总量差对应删去的数');
   case 'medianSort':{const a=[m.start+4*m.gap+(v?100:0),m.start,m.start+3*m.gap,m.start+m.gap,m.start+2*m.gap];return slots(a,'先比较大小，再确定中间位置',{positions:true})}
   case 'chartAverage':{const counts=m.counts.map((x,i)=>x+Number(v&&i===2));return {kind:'bars',values:counts,names:['2分','4分','6分']}}
   case 'cumulativeChart':return {kind:'scene-cumulative',values:[m.a,m.a+m.b,m.a+m.b+m.c,m.a+m.b+m.c+m.d],target:v?[3,4]:[1,3],caption:v?'恰好4分':'恰好2分或3分；每个累计包含前面的档'};
   case 'reverseDigits':return {kind:'scene-placeValue',rows:[{label:'原数',digits:v?['小','大']:['大','小']},{label:'交换',digits:v?['大','小']:['小','大']}],caption:v?`数字和 ${m.a+m.b}、差 ${m.a-m.b}`:`数字和 ${m.a+m.b}、交换后小 ${9*(m.a-m.b)}`};
   case 'digitInsert':return {kind:'scene-placeValue',rows:[{label:'位置1',digits:[m.d,m.a,m.b]},{label:'位置2',digits:[m.a,m.d,m.b]},{label:'位置3',digits:[m.a,m.b,m.d]}],caption:v?'比较同一组位置，取最小':'原来两张卡顺序保留；比较大小'};
   case 'numberAppend':return {kind:'scene-placeValue',rows:[{label:'原数',digits:['?','?']},{label:v?'前添':'末添',digits:v?[m.digit,'?','?']:['?','?',m.digit]}],caption:v?'前添的数字占百位':'新数比原数多 '+(9*m.n+m.digit)};
   case 'divisibleDigits':case 'divisibleEleven':return slots([m.a,'□',m.b??m.c,'□'],id==='divisibleDigits'?(v?'被9整除且为偶数':'同时被9和5整除'):(v?'数全部合法选择':'同时被11和5整除'),{positions:true});
   case 'natural-digitCount':case 'natural-distinctDigitCount':return {kind:'scene-choices',values:m.digits,places:2,repeat:state.projection.repeat,caption:'十位与个位有序；数字和须被3整除'};
   case 'digitComplement':return slots(items(m.length,`0…9`),v?`恰好一位 ${m.digit}`:`至少一位 ${m.digit}`,{positions:true});
   case 'differentDigits':return slots([`1…${m.digits}`,`1…${m.digits}`],v?'两位不同；交换顺序合为同一个':'两位必须不同；顺序不同算不同',{positions:true,exchangeEquivalent:v});
   case 'digitDivisor':return slots([m.tens,v?'0…9':'1…9'],'个位作除数'+(v?'：0能作除数吗？':''),{positions:true});
   case 'pairedSum':return strips([row(v?'只取偶数':'连续整数',m.n,`1、2、…、${m.n}`),row('反向排列',m.n,`${m.n}、…、2、1`)],'对应位置配对',{pairing:true});
   case 'telescopingDifferences':{const first=m.start+(v?m.step:0),left=m.start+2*m.step,right=m.start+(m.n-1)*m.step;return timeline([...new Set([first,...(!v?[m.start+m.step]:[]),left,right,m.start+m.n*m.step])].sort((a,b)=>a-b),'只标题目给出的端点，中间项仍省略',{omittedInterval:right>left+m.step?[left,right]:null})};
   case 'neighborProducts':return {kind:'scene-product',n:m.n,delta:v?2:1,caption:'比较 n×n 与 (n−d)×(n+d)，方格只表示对应关系'};
   case 'signedProduct':return slots([-4*m.k,-3*m.k,-m.k,0,2*m.k,5*m.k],v?'任选2张，先比较符号':'任选3张，先比较符号',{positions:false,choose:v?2:3});
   case 'squareBounds':return {kind:'scene-squareBounds',n:m.n,upper:v,caption:'找相邻整数的平方夹住这个数；边界整数未知'};
   case 'consecutiveRepresentations':return strips([row('连续数',5,v?'a≥0':'a≥1')],`总和 ${m.total}；至少2项；首项、项数都未知`,{sequence:true});
   case 'recurrenceForward':case 'recurrenceTotal':case 'recurrenceBackwards':case 'recurrenceRemainders':{let a=m.a??m.first??(v?2:1),b=m.b??m.second??(v?2:1);if(v&&id==='recurrenceForward')[a,b]=[b,a];const seq=[a,b];while(seq.length<m.n)seq.push(seq.at(-1)+seq.at(-2));return slots(id==='recurrenceBackwards'?['?', '?','…',seq.at(-2),seq.at(-1)]:[a,b,'?','?','…'],`${m.n} 项；从第3项起前两项相加`+(v&&id==='recurrenceBackwards'?'；第1项增加1':v&&id==='recurrenceTotal'?'；只加第2项起':''),{positions:true,positionLabels:state.projection.termIndices})}
   case 'factorBalance':return {kind:'scene-factorPairs',product:m.product,caption:v?'合法因数对中比较最大和':'合法因数对中比较最小和'};
   case 'threeDivisors':return timeline([1,m.limit],v?'恰好3个因数：找最大合法数':'区间内检查恰好3个因数',{domain:'integer'});
   case 'divisorPowers':return {kind:'scene-exponentGrid',a:m.a,b:m.b,even:v,caption:v?'两个指数都须为偶数':'每个因数由两个指数唯一确定'};
   case 'equalBags':return units([group('红糖',m.a,'颗'),group('蓝糖',m.b,'颗')],v?'比较所有可行袋数':'两色全部用完；每袋两色数量分别相同',{object:'ball',compress:true});
   case 'bells':return {kind:'scene-twoTimelines',periods:[m.a,m.b],start:0,end:v?(m.a*m.b/((a,b)=>{while(b)[a,b]=[b,a%b];return a})(m.a,m.b)):m.duration,includeStart:v,caption:v?'起点和终点都计入':'不算起点，结束时刻计入'};
   case 'offsetBells':return {kind:'scene-twoTimelines',periods:[m.a,m.b],offsets:[0,m.offset],start:0,end:m.a*m.b+m.offset,caption:v?'下一次同时响':'第一次同时响在0之后'};
   case 'lastDigit':return flow([{label:'底数',value:m.base},{label:'指数',value:v?`${m.exponent} 与 ${m.exponent+1}`:m.exponent},{label:v?'相邻幂相加个位':'个位',value:'?'}],'寻找从一次方开始的个位循环');
   case 'cyclicPosition':return circle(Array.from({length:m.size},(_,i)=>i+1),`从 ${m.start} 开始，${v?'逆':'顺'}时针 ${m.steps} 步`,{start:m.start,direction:v?-1:1});
   case 'repeatedOnes':return slots(['1','1','…','1'],`${v?m.n+1:m.n} 个1；除以7取余`,{positions:true});
   case 'menuBranches':return {kind:'scene-branch',branches:[{label:'米饭',count:m.rice,next:{label:'菜',count:m.dish}},{label:'面',count:m.noodle}],drinks:v?3:null,caption:v?'每份午餐都再配3选1饮料':'米饭配菜，或单独一份面'};
   case 'adjacentLine':return slots(state.projection.line,v?'两人不能相邻；这只是一个合法例子':'两人必须相邻；其余人各不相同',{positions:true,adjacent:state.math.adjacent});
   case 'restrictedTeam':return units([group('小乐',1,'人'),group('小明',1,'人'),group('其他',m.n-2,'人')],v?'小乐小明都必须入选，第3人待选':'选3人，无职位；乐明不能同选',{object:'person'});
   case 'unorderedPairs':return units([group('不同小朋友',m.n,'人')],v?'每对搭档指定角色':'选2人作搭档，不分先后',{object:'person'});
   case 'circularSeating':return circle(items(m.n,'人'),v?'取消相邻限制；旋转合并':'乐明相邻；旋转合并，镜像不合并',{special:['乐','明'],adjacent:!v});
   case 'parityPermutations':return slots(Array.from({length:m.n},(_,i)=>i+1),v?'奇数彼此不能相邻':'偶数彼此不能相邻',{positions:true});
   case 'binaryNoNeighbors':return slots([v?'●':'○/●',...items(m.n-1,'○/●')],v?'第一盏必须亮；亮灯不能相邻':'每盏亮或灭；亮灯不能相邻',{positions:true});
   case 'allThreeColors':return slots(items(m.n,'红/蓝/绿'),v?'三色中恰好出现两种':'三种颜色都必须出现',{positions:true});
   case 'spinnerLabels':return circle([...items(m.a,'A'),...items(m.b,'B'),...items(m.c,'C')],v?'已知不是C，只在A/B扇区比较':'每个扇区等面积、等机会',{sectors:true,excluded:v?['C']:[]});
   case 'natural-pairChance':case 'conditionalBalls':return units([group('红',m.red,'个'),group('蓝',m.blue,'个')],id==='natural-pairChance'?(v?'每次放回并混合':'不放回取2个，具体球对等可能'):(v?'已知两球颜色相同':'已知至少一个红球'),{object:'ball',sample:2});
   case 'diceSum':return {kind:'scene-diceGrid',faces:m.faces,target:m.target,different:v,caption:v?'只保留两个点数不同的有序对':'行列各对应一枚骰子的实际点数'};
   case 'remainderProbability':return {kind:'scene-remainderCards',mod:m.mod,count:m.count,wanted:m.wanted,includeZero:v,draft:true,caption:'每张卡等可能；分组与尾段由你建立'};
   case 'worstCaseColors':return units(m.caps.map((n,i)=>group(['红','蓝','绿'][i],n,'个')),`不放回；保证 ${m.k+Number(v)} 个同色`,{object:'ball',guarantee:m.k+Number(v)});
   case 'setOutside':case 'exactlyOneSet':case 'natural-unionChance':case 'natural-complementChance':case 'ratioUnion':{const s=state.projection.sets;return {kind:'scene-sets',a:id==='ratioUnion'?m.a+' 份':s.a,b:id==='ratioUnion'?m.b+' 份':s.b,both:s.both,total:s.total??(id==='ratioUnion'?(m.a+m.b)*m.unit-m.both:null),names:id==='ratioUnion'?['棋类组','球类组']:['甲组','乙组'],change:v&&['exactlyOneSet','ratioUnion'].includes(id)?'one-joins-second':v&&id==='setOutside'?'one-outside-joins-both':null,conditional:v&&id.startsWith('natural-'),caption:v?E.prompt:'两组交叠区域属于两组；圈外属于都没参加'}};
   case 'threeSetExactlyTwo':return {kind:'scene-threeSets',ab:m.ab,ac:m.ac,bc:m.bc,triple:m.triple,caption:v?'至少两组：中央三组区域也符合':'恰好两组：每个两组交集都包含中央三组交集'};
   case 'lightSwitchParity':return flow([{label:'开始',value:m.on?'亮':'灭'},{label:'重复按',value:`${m.groups}×${m.per}`},{label:'再按',value:m.extra+(v?1:0)},{label:'最后',value:'?'}],'每次在亮灭之间切换');
   case 'ballReplacement':return {kind:'scene-ballRule',white:m.white+Number(v),black:m.black,caption:'同色→黑；异色→白；每次少一球'};
   case 'quarterTurn':case 'transformOrder':return {kind:'scene-direction',start:m.start,turns:id==='quarterTurn'?m.turns:m.rot,mirror:id==='transformOrder',reverseOrder:v&&id==='transformOrder',anticlockwise:v&&id==='quarterTurn',caption:'上0、右1、下2、左3；按条件顺序追踪'};
   case 'cubeSteps':return {kind:'scene-stairs',n:m.n,depth:v?2:1,caption:`每列 ${v?2:1} 块厚；列高1到 ${m.n}`};
   case 'natural-tiles':{const scale=v?2:1;return {kind:'scene-tiledRectangle',w:m.w*scale,h:m.h*scale,caption:'同规格正方形砖铺满，不切砖；先找最大整数边长'}};
   case 'mapScale':return strips([row('甲地图',m.a,m.a+'厘米'),row('乙地图',m.a*m.k*(v?.5:1),'?')],v?'乙再缩成当前1/2':'乙所有长度为甲的 '+m.k+' 倍',{continuous:true});
   case 'scaleAreaReverse':return flow([{label:'原面积',value:'?'},{label:'长放大',value:m.k+' 倍'},...(v?[]:[{label:'长缩为当前',value:'1/'+m.s}]),{label:'面积',value:v?'?':m.old*m.k*m.k/(m.s*m.s)}],'长度倍率与面积倍率分别追踪');
   case 'oppositeScale':return strips([row('原长',m.a,m.a+'份'),row('新长',m.b,m.b+'份'),row('原宽',m.b,m.old),row('新宽',v?m.b*m.b/m.a:m.a,'?')],v?'长宽使用同一倍率，面积不再固定':'面积不变：宽须使用反向倍率',{continuous:true});
   case 'similarAreaPerimeter':return v?strips([row('小图周长',1,'1份'),row('新图周长',m.b,m.b+'份')],`已知周长倍率 ${m.b}，面积倍率待求`,{continuous:true}):strips([row('小面积',m.a*m.a,m.a*m.a+'份'),row('大面积',m.b*m.b,m.b*m.b+'份')],`小图周长 ${m.a*m.unit}；对应长度比由你推导`,{continuous:true});
   case 'shadowSimilarity':return {kind:'scene-shadows',smallHeight:m.a,smallShadow:v?'?':2*m.a,bigShadow:v?m.b*m.unit:2*m.b*m.unit,bigHeight:v?'原高不变':'?',caption:v?'两杆高度均不变，比较同一时刻的影长变化':'同一时刻、竖直杆、同一阳光方向'};
   case 'ageDifference':return {kind:'scene-age',ago:m.ago,gap:m.parent-m.child,child:v?m.child:'?',parent:v?m.parent:'?',caption:v?'年龄差不变，找未来2倍时刻':`${m.ago} 年前大人是孩子3倍；求孩子现在年龄`};
   default:return geometry(c,f,v);
  }
 }

 function geometry(c,f,v){
  const m=c.math,id=f.id,E=c.extension,d=copy(c.diagram||{});
  if(!v&&id!=='squareBorder'&&d.kind&&!['table','rule-table','line','digits','cuboid','coordinate','sets','meeting','garden','balls','rectangle'].includes(d.kind))return d;
  switch(id){
   case 'natural-coordinateDistance':return {kind:'scene-coordinates',a:[m.x,m.y],b:[m.x+m.dx,m.y+m.dy],gridOnly:v,caption:v?'只允许水平和竖直走':'比较直线与网格距离'};
   case 'coordinateHorizontal':return {kind:'scene-coordinates',a:[m.a+(v?5:0),m.y],b:[m.b+(v?5:0),m.y],caption:'两点同一纵坐标'};
   case 'paintedCube':case 'cubeProbability':return {kind:'scene-cube',n:m.n,faces:v&&id==='paintedCube'?['top','bottom']:['all'],conditional:v&&id==='cubeProbability',caption:v?configs[id].change:'棱上每边 '+m.n+' 个小块；角另分一类'};
   case 'ladderShift':return {kind:'scene-ladder',length:5*m.k,base:v?'?':3*m.k,nextBase:v?null:4*m.k,height:v?4*m.k:'?',caption:v?'已知高度，求底端距离':'同一根梯子；斜边长度不变'};
   case 'boundaryNotch':return v?(E.math?.placement==='internal'?{kind:'scene-holeRectangle',...E.math,caption:'外边与内洞都计入边界总长度'}:{kind:'lShape',w:m.w,h:m.h,a:m.a,b:m.depth,caption:'缺口在角上；比较移除与补入的边'}):{kind:'notch',...m,caption:'中间缺口；口宽与深度作用不同'};
   case 'rectangleDiagonalArea':return {kind:'rectangleDiagonal',w:m.w*(v?1.5:1),h:m.h};
   case 'lShapeArea':return v?{kind:'scene-holeRectangle',...m,caption:'洞在内部；面积与轮廓变化分开'}:{kind:'lShape',...m};
   case 'crossArea':return {kind:'cross',...m,intersectionOnly:v};
   case 'semicircleBoundary':return v?{kind:'scene-fullCircle',radius:m.radius,caption:'两条直径拼到内部，不属于外周'}:{kind:'semicircle',...m};
   case 'circleRingRatio':return {kind:'ring',r1:m.r1*(v?2:1),r2:m.r2*(v?2:1)};
   case 'parallelTriangle':return {kind:'parallelTriangle',n:v?2:m.n,k:v?1:m.k};
   case 'hypotenuseMidpoint':return {kind:'hypotenuseMidpoint',...m,legMidpoint:v};
   case 'openBox':return {kind:'boxNet',side:m.side,cut:v?1:null,caption:v?'固定每角剪1×1，求底面积':'x未知；底边必须为正'};
   case 'circleRoute':return {kind:'circleRoute',...m,whole:v};
   case 'outsideAngle':return {kind:'isoscelesExterior',...m,target:v?'other-base':'exterior'};
   case 'natural-angleRatio':return v?{kind:'scene-polygonAngles',ratios:[...m.ratios,m.ratios[2]],sides:4,caption:'四边形角总量360°'}:{kind:'angleRatioTriangle',ratios:m.ratios};
   case 'angleMarks':return {kind:'scene-rays',marks:m.marks,steps:m.step,other:v,caption:v?'沿另一个方向围出的角':'沿较短方向相隔 '+m.step+' 段'};
   case 'polygonTurn':return {kind:'scene-polygon',n:m.n,steps:v?Math.floor(m.n/2):m.n,caption:'沿边行走，外转角在顶点标出'};
   case 'overlapSquares':case 'overlapProbability':return {kind:'overlapSquares',...m,exclusive:v&&id==='overlapSquares',sampleFirst:v&&id==='overlapProbability'};
   case 'gridDetour':case 'routeProbability':case 'stepwiseRoute':return {kind:'routes',...m,firstUp:v&&id!=='stepwiseRoute',sampling:id==='stepwiseRoute'?!v:false};
   case 'rectanglePointAreas':return {kind:'fourAreas',top:m.top,left:m.left+(v?1:0),right:v?'?':m.right,bottom:'?',caption:v?'P只向右；左右总面积保持不变':'各三角形面积按标签给出，不按图估算'};
   case 'squareBorder':return {kind:'scene-border',n:m.n,partial:v,caption:v?'只加左、上；外角不重复':'外侧加一圈，原有格子不算新增'};
   case 'checkerDomino':return {kind:'checker',...m,removeTop:v};
   case 'foldHoles':return {kind:'foldHoles',interior:m.interior+Number(v),edge:m.edge-Number(v),center:m.center};
   case 'chartScale':return {kind:'bars',values:[m.a+Number(v),m.b+Number(v),m.c+Number(v)],names:['甲','乙','丙'],known:v?null:0,knownValue:m.a*m.unit,unit:v?m.unit:null};
   case 'truncatedBars':return {kind:'truncatedBars',...m,caption:v?'求乙比甲多的人数，刻度起点仍相同':'求两组实际总人数'};
   case 'rotatingColors':return {kind:'necklaceBlank',...m,fixed:v};
   default:throw Error('Missing explicit RC67 representation '+id);
  }
 }

 function decorate(c,f,generatorRevision){
  const config=configs[f.id];if(!config)throw Error('Missing family contract '+f.id);
  if(generatorRevision>=3){
   const unambiguous=text=>String(text).replace(/÷\s*([-−]?\d+(?:\.\d+)?\/[-−]?\d+(?:\.\d+)?)/g,'÷ ($1)');
   c={...c,methods:c.methods.map(m=>({...m,steps:m.steps.map(unambiguous)})),extension:{...c.extension,solution:unambiguous(c.extension.solution)}};
  }
  const initial=scene(c,f),variation=scene(c,f,true),loads=load(c,f);
  const original=copy(c.math);
  if(!variations[f.id])throw Error('Missing variation value contract '+f.id);
  const variationSpec=generatorRevision>=3?variations[f.id]:{category:'legacy-condition',recheck:config.change};
  const contract={schemaVersion:1,familyId:f.id,modelId:config.model,requiredTopics:[...f.topicIds],goal:config.goal,question:c.prompt,givens:original,constraints:config.constraints,criticalDecision:f.insight,reasoningKey:f.reasoningKey,configurationKey:f.structureKey||f.id,...loads,parameterPolicy:{domain:config.constraints,bounded:true,maxTrials:120,ordinaryScore:'integer',fractionReason:'fraction, ratio, probability, measurement or weighted result'},diagramSpec:{kind:initial.kind,source:'competition.math',stages:['initial','hint','solution','variation'],representationReason:config.model},variationSpec:{change:c.extension.prompt,category:variationSpec.category,decision:variationSpec.recheck,preserved:'未声明变化的原条件',independent:true,newStrategyClaim:false},validation:{oracle:'source/competition_reviewed_oracles.js + RC67 independent overrides',seeds:128}};
  c={...c,...loads,quality:contract,diagram:initial,problemState:problemState.create(c,f),displayRevision:2};
  const familyHints={openBox:['要使体积最大，需要同时知道哪些长度？','剪角长度决定底边和高度，先列合法剪角，再比较体积。'],menuBranches:['两种午餐选择会同时发生，还是只能选一种？','把米饭配菜与单独选面分成互斥分支；新增饮料作用于整份午餐。'],rotatingColors:['旋转后相同的涂法，能否当成两种？','找一个固定参照，检查每个涂法在旋转中重复几次；不是一律除以位置数。'],recurrenceBackwards:['从末尾两个已知数，能得到它们前面的哪个数？','向前是两个相邻数相加，倒推需要使用怎样的逆运算？']};
  c.ruleHints=c.ruleHints||familyHints[f.id]||['要得到题目问的量，还需要哪些条件？先选择一个能确定的中间量。',hintPolicy[config.model]];
  if(!c.ruleHints.every(Boolean))throw Error('Missing hint policy '+f.id);
  c.quality.hintStages=c.ruleHints.map((text,i)=>({level:i+1,text,representation:initial.kind}));
  c.hintDiagram={...copy(initial),stage:{kind:'hint',text:c.ruleHints[1]}};
  c.methods=c.methods.map((method,route)=>({...method,frames:method.steps.map((text,step)=>({kind:'scene-stage',scene:solutionScene(c,f,route,step,initial),stage:{kind:'solution',route,step,text},routeDiagram:method.frames?.[step]||null}))}));
  const solvedVariation=copy(variation);
  if(solvedVariation.average==='?')solvedVariation.average=c.extension.answer;
  if(solvedVariation.kind==='scene-fractions'){if(solvedVariation.start==='?'&&solvedVariation.left!=='?')solvedVariation.start=c.extension.answer;else if(solvedVariation.left==='?')solvedVariation.left=c.extension.answer}
  const extension={...c.extension,diagram:variation,problemState:problemState.create(c,f,true),solutionFrames:[{kind:'scene-stage',scene:solvedVariation,stage:{kind:'solution',step:0,text:c.extension.solution}}]};
  if(generatorRevision>=3){
   extension.math=extension.math||{...original,baseFamily:f.id,condition:config.change};
   // Adding a diagram or explicit provenance must not create a new first chance.
   // Only a genuinely changed target/condition supplies a new key in revise().
  }
  c.extension=extension;return c;
 }
 function solutionScene(c,f,route,step,initial){
  const m=c.math;
  if(f.id==='riverTravel')return {...copy(initial),segments:[{name:'顺流',speed:m.v+m.c},{name:'逆流',speed:step>0?m.v-m.c:'?'}],caption:'按当前解法步骤确认实际速度'};
  if(f.id==='telescopingDifferences')return timeline(Array.from({length:m.n+1},(_,i)=>m.start+i*m.step),'解法回顾：按相邻关系补齐后核对端点');
  if(['natural-weighted','natural-fractionWeighted'].includes(f.id)&&m.den===1){
   const a=m.red,b=m.blue,low=m.redScore,high=m.blueScore,total=a+b,answer=c.answer;
   if(!route&&step===0)return copy(initial);
   if(!route&&step===1)return units([group('红队合计',a,'人数份',a*low),group('蓝队合计',b,'人数份',b*high)],'先分别合计，不把总分当每人分数',{object:'person',scoreLabel:'整队共'});
   if(route&&step===0)return units([group('红队',a,'人数份',low),group('蓝队',b,'人数份',low)],'假设每人先拿同样的低分',{object:'person'});
   if(route&&step===1)return units([group('红队额外',a,'人数份',0),group('蓝队额外',b,'人数份',high-low)],'只有蓝队高出基准；这部分要分给全体',{object:'person'});
   return {kind:'scene-share',people:total,average:answer,totalScore:a*low+b*high,base:route?low:null,extraAverage:route?F(b*(high-low),total):null,caption:route?'先均分额外分数，再加每人的基准分':'总分平均分到代表组的每个人'};
  }
  if(f.id==='overlapAverages'){
   const d=copy(initial),values=m.values,k=4;d.totals=[sum(values.slice(0,k)),sum(values.slice(k-1)),sum(values)];d.knownMiddle=step===c.methods[route].steps.length-1?values[k-1]:null;d.caption=route?'用整体减后段，找到前面不重叠的部分':'从两段合计中扣去整段，留下重叠位置';return d;
  }
  if(f.id==='fixedPerimeter'){
   const half=m.half,short=Math.floor(half/2),rows=[];
   if(!route&&step===1){for(let x=1;x<=short;x++)rows.push({w:x,h:half-x,area:x*(half-x)});return {kind:'scene-areaPairs',rows,caption:'合法短边逐个列出，交换长宽不新增面积'}};
   if(route&&step<2){const w=Math.max(1,short-2),h=half-w;return {kind:'scene-areaPairs',rows:[{w,h,area:w*h},{w:w+1,h:h-1,area:(w+1)*(h-1)}],caption:'长减1、短加1：长宽和不变，比较增加与去掉的条'}};
   if(step===c.methods[route].steps.length-1)return {kind:'scene-areaPairs',rows:[{w:short,h:half-short,area:short*(half-short)}],caption:'最接近的一对达到最大面积'};
  }
  return copy(initial);
 }
 function family(f){const config=configs[f.id];if(!config)throw Error('Unregistered RC67 family '+f.id);const sameWeights=['natural-weighted','natural-fractionWeighted','rule-weighted-mean','rule-weighted-score'];return {...f,modelId:config.model,criticalDecision:f.insight,qualityPolicy:config,selectionReasoningKey:sameWeights.includes(f.id)?'weighted-total':f.reasoningKey}}
 function comfort(c){const a=c.calculationLoad||load(c,{id:c.family,level:c.level||1,insight:c.insight||''}).calculationLoad,b=c.readingLoad;return a.level*10+a.operations+Math.min(a.enumeration,50)/10+Number(a.fractional)+a.digits/10+(b?.level||1)*2}
 function familyLoads(f){return f.selectionLoads||(f.selectionLoads=load(revise(f.build(1,2),f,1),f))}
 return {configs,family,revise,decorate,scene,load,comfort,familyLoads};
})(typeof module!=='undefined'?require('./competition'):{competitionRng,competitionFraction,competitionNumericOptions},typeof module!=='undefined'?require('./competition_rules'):CompetitionRules,typeof module!=='undefined'?require('./problem_state'):ProblemState);
if(typeof module!=='undefined')module.exports=CompetitionDesign;
