'use strict';
// Engine 3 is an editorial layer. Engine 1/2 stay unchanged for record replay.
const {COMPETITION_REVIEWED,competitionReviewedEligible,competitionReviewedCreate,competitionReviewedRecipe}=((base,extra,helpers,fresh,rules,design,structured,sources)=>{
 const {competitionCanonicalIds,competitionHash,competitionFraction:F,competitionRatioText}=helpers;
 const revision=93;
 const descriptions={1:'关系较直接，辨认一个关键条件后即可求解',2:'需要衔接两步推理，或在两种表示之间转换',3:'需要处理多重约束、隐含结构，或证明极值与不变量'};
 // Each row records a content decision, not a claim of learning effectiveness.
 const rows=[
 ['reverseDigits',2,'交换数字','交换前后的位值差与数字和共同确定两个数字'],
 ['fractionBackwards',2,'两天的贴纸','两次分数的整体不同，可逆推或统一原量'],
 ['percentRoundTrip',2,'价格变化','两次百分比的基准不同，变化量不能直接抵消'],
 ['squareBorder',2,'积木边框','求新增部分可用面积差或不重叠的边界计数'],
 ['ratioEqualize',2,'两色球','增加量对应比例中的差额而非总份数'],
 ['packPrice',2,'买笔','便宜单位价仍受整包与恰好数量约束'],
 ['equalDistanceSpeed',2,'往返行程','相等路程对应不等时间，平均速度的权重是时间'],
 ['oppositeScale',2,'图形尺寸','面积不变要求两个方向的长度倍率互为倒数'],
 ['balanceCancel',1,'天平上的盒子','相同部分可从平衡的两边同时移去'],
 ['tickets',2,'买票的人数','人数与总价共同约束两类数量'],
 ['recurrenceBackwards',2,'数列的起点','给定相邻末项后，递推可通过相减反向还原'],
 ['linearTable',1,'机器表格','输入差与输出差确定固定变化率'],
 ['divisibleDigits',3,'数字空格','同时满足两种整除限制并比较位值取得最大数'],
 ['factorBalance',2,'一对整数','合法因数对中比较和，需覆盖全部候选'],
 ['bells',2,'两只铃','共同周期的计数必须同时处理起止端点'],
 ['lastDigit',2,'幂的个位','指数的余数必须对应从一次方开始的循环位置'],
 ['fixedPerimeter',3,'长方形设计','整数约束下证明边长尽量接近会增大面积'],
 ['outsideAngle',2,'三角形的外角','等腰条件与内外角关系可沿两条路线使用'],
 ['overlapSquares',2,'两张正方形纸','移动量决定交集边长，覆盖区域须避免重计'],
 ['circleRoute',1,'圆形跑道','圆周的两条补弧中比较较短的一条'],
 ['similarAreaPerimeter',2,'两个相似图形','面积比先还原为长度比，再用于周长'],
 ['ladderShift',2,'靠墙的梯子','固定斜边对应两组直角边，可计算或识别结构'],
 ['paintedCube',2,'涂色小块','边界位置决定涂色面数，角块须单独分类'],
 ['exactlyOneSet',2,'两个活动组','恰好一组与至少一组对交集有不同处理'],
 ['gridDetour',3,'方格中的路线','通过限制点的前后路径配对，或直接逐点递推'],
 ['adjacentLine',2,'朋友排队','相邻对象可捆绑，也可先选相邻位置'],
 ['restrictedTeam',3,'三人小队','无序选人与禁止同选的约束需要完整分类'],
 ['digitComplement',2,'数字密码','至少出现一次可用补集或首个出现位置计数'],
 ['chartScale',1,'三个小组','已知柱高确定刻度，再转换另一部分的数量'],
 ['missingAverage',2,'删去的数','平均数要与人数结合为总和，也可平衡偏差'],
 ['diceSum',2,'两枚骰子','等可能对象是有序点数对，数字和并不等可能'],
 ['foldHoles',2,'纸上的孔','折痕上的孔与内部孔有不同的对称复制次数'],
 ['checkerDomino',3,'棋盘与骨牌','颜色给出上界后，还需构造达到上界的摆法'],
 ['natural-weighted',2,'两队的得分','人数比例决定平均数的权重'],
 ['natural-fractionWeighted',2,'两队的积分','人数权重决定平均结果，不能直接平均两个队的每人得分'],
 ['natural-catch',2,'两人的行程','领先距离由延迟形成，差速决定追及时间'],
 ['natural-tiles',2,'铺地砖','边长须共同整除两边，求最大规格后数铺排'],
 ['natural-pairChance',2,'袋中的球','不放回的球对可按无序组合或有序取出计数'],
 ['natural-unionChance',2,'抽到的组员','先去重确定有利人数，再与全体比较'],
 ['natural-complementChance',2,'抽到的小朋友','既未参加任何组的人数是并集的补集'],
 ['natural-offers',2,'两家商店','固定配送费和每件折后价作用于不同量'],
 ['natural-angleRatio',1,'三角形的三个角','内角总和对应完整比例份数'],
 ['natural-digitCount',2,'两位数卡','十位个位的有序选择同时受整除限制'],
 ['natural-distinctDigitCount',3,'两位数卡','有序选择、整除和不重复三项约束共同限制'],
 ['natural-coordinateDistance',2,'两个点','直线距离与横纵距离的合计不是同一个量'],
 ['routeProbability',3,'随机路线','完整路线等可能，受限制的路径数决定概率'],
 ['cubeProbability',2,'随机小块','空间边界分类得到有利数，分母为全部小块'],
 ['overlapProbability',2,'随机落点','等可能区域是并集，交集面积不能重复放入分母'],
 ['ratioUnion',3,'参加活动的人','先从不同人数还原参加次数，再用比例反求各组'],
 ['chartAverage',2,'得分图','频数决定权重，可合计总分或平衡基准偏差'],
 ['parityPermutations',3,'数字排列','先确定不相邻的位置，再安排不同数字'],
 ['recurrenceRemainders',3,'数列的余数','相邻余数对构成状态，确认周期后分段求和']
 ];
 const benchmarkMap={
 signedProduct:['AMC8-2000-07'],digitDivisor:['AMC8-2000-11'],overlapAverages:['AMC8-2000-23'],
 ageDifference:['AMC8-2000-01'],lShapeArea:['AMC8-2000-06'],cumulativeChart:['AMC8-2000-04'],
 fixedPerimeter:['AMC8-2000-16'],tickets:['AMC8-2000-20'],stampConstraint:['AMC8-2000-20'],
 missingAverage:['AMC8-2000-23'],outsideAngle:['AMC8-2000-13'],parallelTriangle:['AMC8-2000-25'],
 paintedCube:['AMC8-2000-08','AMC8-2000-22'],cubeProbability:['AMC8-2000-08'],
 lastDigit:['AMC8-2000-14'],recurrenceRemainders:['AMC8-2000-14'],divisibleDigits:['AMC8-2000-09']
 };
 const oneMethod=new Set(['factorBalance','lastDigit','similarAreaPerimeter','natural-tiles','natural-angleRatio','parityPermutations','recurrenceRemainders','pairedSum','percentRestore','divisorPowers','circleRingRatio','cubeSteps','numberAppend','riverTravel','parallelTriangle','cumulativeChart','allThreeColors','fractionSharedRemainder','threeDivisors']);
 const M=(name,...steps)=>({name,steps});
 const X=(prompt,answer,solution)=>({prompt,answer:String(answer),solution,kind:'condition-change',key:'condition-transfer'});
 const fact=n=>n<2?1:n*fact(n-1);
 const choose=(n,k)=>k<0||k>n?0:Array.from({length:k},(_,i)=>i+1).reduce((v,i)=>v*(n-i+1)/i,1);
 const routes=(w,h,blocked)=>{let a=Array.from({length:h+1},()=>Array(w+1).fill(0));for(let y=0;y<=h;y++)for(let x=0;x<=w;x++)a[y][x]=blocked&&x===blocked[0]&&y===blocked[1]?0:x+y===0?1:(x?a[y][x-1]:0)+(y?a[y-1][x]:0);return a[h][w]};
 function transfer(id,m,c){
  switch(id){
   case 'reverseDigits':return X(`现在改为两个数字相差 ${m.a-m.b}，交换前后两个数的和仍与原题相同。满足条件的较小两位数是多少？`,10*m.b+m.a,'数位互换后，两数之和等于数字和的11倍。先还原数字和，再配合数字差；把较小数字放十位。');
   case 'fractionBackwards':return X('第二天改为用掉最初总数的 1/3，其余不变。最后剩多少枚？',F(m.left,2),'新的两次分数都以最初总数为整体，剩下1−1/2−1/3=1/6；不能沿用原题剩原量1/3的结论。');
   case 'percentRoundTrip':return X(`只涨价 ${m.percent}% 后，若想恢复原价，应按涨后价降百分之几？填写百分号前的数。`,F(100*m.percent,100+m.percent),'需减少的是原价的涨幅，但分母改为涨后的价格；可取原价100比较。');
   case 'squareBorder':return X('改成只在左侧与上侧加宽1块的一条边框，两侧在左上角相接。需要增加多少块？',2*m.n+1,'大阵每边只多1；新增两条各长n的边和一个公共外角，计2n+1。');
   case 'ratioEqualize':return X(`改为只取走 ${((m.b-m.a)*m.unit)} 个蓝球，不加红球。此时两种球合计多少个？`,2*m.a*m.unit,'取走的数量仍是原来的数量差；两种都变成原来的红球数，而非原来的蓝球数。');
   case 'packPrice':{let cost=Infinity;for(let k=0;k<=Math.ceil(m.count/3);k++)cost=Math.min(cost,k*m.pack+Math.max(0,m.count-3*k)*m.single);return X('数量条件改为至少买够，允许多买；最少需要多少元？',cost,'比较原来的恰好方案与再多买一整包的方案。单价便宜不能代替对总费用的比较。')}
   case 'equalDistanceSpeed':return X('两段速度不变，改为在两个方向行走同样长的时间，平均速度是多少？',F(3*m.speed,2),'这次权重是相同时间，两个速度可以等权平均；原题是相同路程，不能照搬。');
   case 'oppositeScale':return X('两边都改为原来长的相同倍率，面积是原来的几倍？',F(m.b*m.b,m.a*m.a),'面积随两个长度倍率相乘；原题保持面积不变的条件已取消。');
   case 'balanceCancel':return X('同一副天平，右边拿走一个盒子后，为重新平衡，右边应该加几克砝码？',m.x,'去掉右边一个盒子的重量后，补回等量砝码。重量差变化，而不是两边仍有相同盒子数。');
   case 'tickets':{const total=m.adults*m.adult+(m.people-m.adults)*m.child;return X(`票价不变，但同样总价 ${total} 元不限定总人数，允许一种票完全不买。不同的成人、儿童人数方案有几种？`,(()=>{let n=0;for(let a=0;a*m.adult<=total;a++)if((total-a*m.adult)%m.child===0)n++;return n})(),'解除人数限制后，固定成人票数，检查余款能否恰好买整数张儿童票。原来的唯一人数不能直接沿用。')}
   case 'recurrenceBackwards':return X('把求出的第一项增加1，第二项不变，递推规则不变。原题最后已知的那一项会增加多少？',(()=>{let a=1,b=0;for(let i=2;i<m.n;i++)[a,b]=[b,a+b];return b})(),'增量也满足相同递推，从1、0开始逐项相加；不必把原数列从头重算。');
   case 'linearTable':return X(`把每次规则改为先加原来的固定加数、再乘原来的固定乘数，输入 ${m.target} 的输出是多少？`,m.k*(m.target+m.b),'先由两个已知对应求乘数和加数，再按新顺序计算；两个步骤不可任意交换。');
   case 'divisibleDigits':return X('仍用原题数字空格，但改成被9整除且为偶数，求最大的四位数。',(()=>{let best=0;for(let b=0;b<10;b++)for(let d=0;d<10;d+=2){const n=1000*m.a+100*b+10*m.b+d;if(n%9===0)best=Math.max(best,n)}return best})(),'末位的可选数字改为0、2、4、6、8；再检查数字和。原来的末位0或5限制已不成立。');
   case 'factorBalance':return X('如果改为求这两个正整数的和最大，答案是多少？',m.product+1,'检查因数对的另一个极端：1与原乘积。不能把求最小和的“尽量接近”直接用于最大和。');
   case 'bells':{let t=m.a;while(t%m.b)t+=m.a;return X(`时间改为恰好 ${t} 分钟，而且起点与终点都计入。两铃同时响几次？`,2,'区间是闭区间，0与一个完整共同周期这两个端点都应计入。')}
   case 'lastDigit':return X(`把两个连续幂 ${m.base} 的 ${m.exponent} 次方与 ${m.exponent+1} 次方相加，和的个位是多少？`,(Number(c.answer)+Number(BigInt(m.base)**BigInt(m.exponent+1)%10n))%10,'分别定位两个相邻幂的末位，再把末位相加取个位；循环位置不直接成为和的末位。');
   case 'fixedPerimeter':return X('周长不变，改为要求两边都是正偶数。若没有这样的长方形，填写0；否则填最大面积。',(()=>{let a=0;for(let w=2;w<m.half;w+=2)if((m.half-w)%2===0)a=Math.max(a,w*(m.half-w));return a})(),'先检查长宽和能否由两个偶数组成；若可行，在偶数的合法候选中找最接近的一对。');
   case 'outsideAngle':return X('若给定的同一个外角不变，但改问另一个底角，是多少度？',90-m.apex/2,'外角与相邻底角互补；等腰使另一个底角相同。目标改变后不能仍填写原外角。');
   case 'overlapSquares':return X('改为只给恰好被一张纸覆盖的部分上色，面积是多少？',2*m.n*m.n-2*(m.n-m.dx)*(m.n-m.dy),'两张面积相加后，重叠中的每一点出现两次；现在两次都要扣除。');
   case 'circleRoute':return X('若要从A到B再回A，并且必须经过跑道的每一段至少一次，最短总路程是多少米？',m.sectors*m.unit,'走完整圆周可满足要求；每段至少走一次意味着总长不能少于圆周长，两条补弧分别用于去和回。');
   case 'similarAreaPerimeter':return X(`再做一个周长为较小图形 ${m.b} 倍的相似图形，它的面积是较小图形的几倍？`,m.b*m.b,'周长给出长度倍率，面积要用倍率的平方；这次不是从面积比开平方。');
   case 'ladderShift':return X(`仍用这根梯子，让梯顶离地 ${4*m.k} 米，底端离墙多少米？`,3*m.k,'改为以高度作为已知直角边，用固定梯长求另一直角边，或识别原来的3-4-5对应。');
   case 'paintedCube':return X('改为只涂大正方体顶面和底面，再按原样切开。恰好一个面涂色的小块有多少个？',2*m.n*m.n,'顶底面互不相邻，没有小块同时接触这两个面；因此两个完整表层都符合，不能仍只数棱。');
   case 'exactlyOneSet':return X('有一个原来只在棋类组的人又加入球类组，总人数不变。此后恰好参加一组的人数是多少？',Number(c.answer)-1,'棋类不变，球类与交集各增1；只有这一个人由恰好一组变为两组。');
   case 'gridDetour':return X('取消避开P的限制，改为要求路线的第一步向上。这样的最短路线有多少条？',routes(m.w,m.h-1),'第一步已固定，之后剩下同一个宽度、少一段向上的自由路径；无需扣原来的P。');
   case 'adjacentLine':return X('改为小乐与小明不能相邻，共有多少种排列？',fact(m.n)-2*fact(m.n-1),'用所有排列减相邻排列；内部两种顺序仍要包括在被扣除的部分中。');
   case 'restrictedTeam':return X('仍不分职位，但改为必须同时选中小乐和小明，第三人有几种选择？',m.n-2,'两人已固定，只从剩余人中选第三人。原题的禁止条件变成必须条件。');
   case 'digitComplement':return X(`改为恰好一位是 ${m.digit}，密码有多少个？`,m.length*9**(m.length-1),'先选唯一一次出现的位置，其他每位都不能再用它；不是原题的“至少一次”。');
   case 'chartScale':return X('三组柱高各增加一格，但刻度不变。合计人数增加多少？',3*m.unit,'每格所代表的人数由原图确定；三个柱各加一格，合计增加三格。');
   case 'missingAverage':return X('删去的数已取出；现在把它再放回去两次。新平均数是多少？',F(m.count*m.mean+Number(c.answer),m.count+1),'原来全部数放回后，再多一个被删去的数；总和与人数都要增加，不能只给平均数加2。');
   case 'diceSum':{let v=0;for(let a=1;a<=m.faces;a++)for(let b=1;b<=m.faces;b++)if(a+b===m.target&&a!==b)v++;return X(`已知两枚点数不同，点数和仍为 ${m.target} 的概率是多少？`,F(v,m.faces*(m.faces-1)),'新的样本空间去掉所有点数相同的结果；分子也要重新检查是否有原先符合但点数相同的结果。')}
   case 'foldHoles':return X('把其中一个位于单条折痕边的孔移到内部，其余孔不变。展开后总孔数是多少？',Number(c.answer)+2,'该孔由两个镜像位置变成四个位置，增加2；不是一律乘4或总数加4。');
   case 'checkerDomino':return X('改为去掉左上角和右上角，其他条件不变，最多能放几块骨牌？',m.w*m.h/2-1,'去掉一黑一白，第一行剩偶数格可横铺，其余各行也可横铺。颜色数量允许且构造达到剩余格数的一半。');
   case 'natural-weighted':case 'natural-fractionWeighted':{
    const red=2*m.red,blue=m.blue,people=red+blue,redScore=F(m.redScore,m.den),blueScore=F(m.blueScore,m.den);
    const redTotal=F(red*m.redScore,m.den),blueTotal=F(blue*m.blueScore,m.den),total=F(red*m.redScore+blue*m.blueScore,m.den),average=F(red*m.redScore+blue*m.blueScore,people*m.den);
    const operand=v=>String(v).includes('/')?'('+v+')':String(v);
    return X('把红队人数变为原来两倍，蓝队人数不变，每人得分不变。新的平均分是多少？',average,
     `改变的是权重，不是每人得分；重新计算总份数和总得分，不能把原平均数直接加倍。按新人数比取红队 ${red} 人、蓝队 ${blue} 人的一组，共 ${people} 人。红队总分 ${red} × ${operand(redScore)} = ${redTotal}，蓝队总分 ${blue} × ${operand(blueScore)} = ${blueTotal}。合计 ${operand(redTotal)} + ${operand(blueTotal)} = ${total} 分。新平均 ${operand(total)} ÷ ${people} = ${average} 分。`);
   }
   case 'natural-catch':return X('小明追上后立即停住，让小乐再走原来的延迟时长，两人的距离是多少米？',m.slow*m.delay,'追上时领先距离归零；此后只有小乐移动，距离按他的速度与这段时间计算，差速不再适用。');
   case 'natural-tiles':return X('地面尺寸都变为两倍，并且允许重新选择最大的整块正方形砖。最少需要多少块砖？',m.w*m.h/(m.side*m.side),'长宽的最大公因数也变为两倍；砖面积与地面面积同时变为四倍，所以最少块数不变。');
   case 'natural-pairChance':return X('改成每次取球后放回并充分混合，再取第二次。两次都是红球的概率是多少？',F(m.red*m.red,(m.red+m.blue)**2),'放回后每次红球比例不变，两次概率相乘；原题第二次分母减1的规则失效。');
   case 'natural-unionChance':case 'natural-complementChance':return X('改为已知抽到的人至少参加了其中一组。这个人参加两组的概率是多少？',F(m.both,m.red+m.blue-m.both),'样本范围缩到至少一组的不同人数；用交集人数除以并集人数，不能仍除以全体。');
   case 'natural-offers':return X('价格规则不变，至少买多少件时甲店整单总价不高于乙店？件数必须是整数。',Math.ceil(m.fee/(m.price/4-1)),'每件价差与固定配送费共同决定临界数量。甲折后单价是原价的3/4，乙是原单价少1元；固定费除以每件差后向上取整数，再核对相邻件数。');
   case 'natural-angleRatio':return X(`另一个四边形的四个内角之比为 ${[...m.ratios,Math.max(...m.ratios)].join(':')}。最小内角是多少度？`,F(360*Math.min(...m.ratios),m.ratios.reduce((a,b)=>a+b,0)+Math.max(...m.ratios)),'四边形内角和为360°，共有新的四个比例份数；先确定图形的总角量，不能沿用三角形的180°。');
   case 'natural-digitCount':case 'natural-distinctDigitCount':return {...c.extension,kind:'condition-change',key:'repeat-permission'};
   case 'natural-coordinateDistance':return {...c.extension,kind:'condition-change',key:'grid-distance'};
   case 'routeProbability':return X('取消P的限制，随机路线第一步向上的概率是多少？',F(routes(m.w,m.h-1),routes(m.w,m.h)),'仍然是完整路线等可能。固定第一步向上后的路线数与全部路线数比较，不能默认两个方向各1/2。');
   case 'cubeProbability':return X('已知取到的小块至少一面涂色，恰好两面涂色的概率是多少？',F(12*(m.n-2),m.n**3-(m.n-2)**3),'样本空间变成外层小块，先排除完全未涂色的小块；符合数量仍为棱上非角的小块。');
   case 'overlapProbability':return X('改为只在第一张正方形的区域中等可能选点，落在重叠区域的概率是多少？',F((m.n-m.dx)*(m.n-m.dy),m.n*m.n),'重叠面积不变，可选整体从并集变成一个正方形，因此只改变分母。');
   case 'ratioUnion':return X('有一个原来只参加棋类组的人又加入球类组，其他人不变。新的棋类与球类人数之比为多少？请填写棋类人数除以球类人数。',F(m.a*m.unit,m.b*m.unit+1),'棋类人数不变，球类加1，交集也加1，不同人数不变。原比例不能沿用来重新分配全部人。');
   case 'chartAverage':return X('再来一个得6分的人，原来的其他人得分不变。新的平均分是多少？',F(2*m.counts[0]+4*m.counts[1]+6*m.counts[2]+6,m.counts.reduce((a,b)=>a+b,0)+1),'总分加6，总人数加1；平均数改变取决于新分数与原平均的关系。');
   case 'parityPermutations':return X('改为任意两个奇数都不能相邻，其余不变。有多少种排列？',fact(Math.floor(m.n/2))*choose(Math.floor(m.n/2)+1,Math.ceil(m.n/2))*fact(Math.ceil(m.n/2)),'先排偶数再把奇数放入空位，核对空位数量是否足够。原题奇偶可交换角色，但两类数量未必相同。');
   case 'recurrenceRemainders':return X(`前两项都改为2，递推规则不变，前 ${m.n} 项各自除以3的余数之和是多少？`,(()=>{let a=2,b=2,s=0;for(let i=0;i<m.n;i++){s+=a%3;[a,b]=[b,(a+b)%3]}return s})(),'数列加倍后，原余数1变2、2变1、0仍为0；余数的和不能直接加倍，需重算周期和及余段。');
   default:throw Error('Missing reviewed transfer: '+id);
  }
 }
 function polish(c,id){
  if(id==='percentRoundTrip'){
   const {start,percent}=c.math;
   c.methods=c.methods.map(m=>({...m,steps:[...m.steps]}));
   const parts=100/percent,first=start/parts,raised=start+first;
   c.methods[0].steps=[`把原价 ${start} 元分成 ${parts} 等份，${percent}% 是其中一份：${start}÷${parts}=${first} 元。加上这一份，涨后 ${raised} 元。`,
    `第二次以涨后 ${raised} 元为整体，再分成 ${parts} 等份，每份 ${F(raised,parts)} 元。减去这一份，剩 ${F(raised*(parts-1),parts)} 元；与原价相比少 ${F(first,parts)} 元。`];
  }
  const m=c.math;
  if(id==='fixedPerimeter'){
   const pairs=Array.from({length:Math.floor(m.half/2)},(_,i)=>[i+1,m.half-i-1]),a=Math.floor(m.half/2),b=m.half-a;
   c.methods=[M('列全长宽配对并比较',`由周长得到长+宽=${m.half}。交换长宽不改变面积，只列短边不大于长边的配对。`,pairs.map(([x,y])=>`${x}×${y}=${x*y}`).join('；')+'。',`比较全部合法面积，最大为${a}×${b}=${c.answer}。`),M('把较长一边挪给较短一边',`当长边比短边至少长2时，把长减1、短加1，长宽和不变。`,`增加的一排有“原长−1”个单位格，去掉的一排有“原短”个单位格；前者至少多1格，面积增加。`,`不断这样调整，直到两边相等或只差1，故最优边长${a}与${b}，面积${c.answer}。`)];
  }
  if(id==='recurrenceBackwards'){
   const seq=[m.first,m.second],coeff=[[1,0],[0,1]];for(let i=2;i<m.n;i++){seq.push(seq[i-1]+seq[i-2]);coeff.push([coeff[i-1][0]+coeff[i-2][0],coeff[i-1][1]+coeff[i-2][1]])}
   const p=coeff[m.n-2],q=coeff[m.n-1],x=seq[m.n-2],y=seq[m.n-1],det=p[0]*q[1]-q[0]*p[1],rhs=q[1]*x-p[1]*y;
   c.methods=[c.methods[0],M('用未知起点表示并消去第二项','设第1项为a，第2项为b，每个后续项都按同样的相加规则表示。',`第${m.n-1}项：${p[0]}a+${p[1]}b=${x}；第${m.n}项：${q[0]}a+${q[1]}b=${y}。`,`第一式乘${q[1]}，第二式乘${p[1]}再相减，b项抵消，得到${det}a=${rhs}，所以a=${m.first}。`,`代回得b=${m.second}；从这两项正向相加，可核对最后两个已知数。`)];
  }
  if(id==='signedProduct'){
   const cards=[-4*m.k,-3*m.k,-m.k,0,2*m.k,5*m.k],negative=[];for(let a=0;a<cards.length;a++)for(let b=a+1;b<cards.length;b++)for(let d=b+1;d<cards.length;d++){const v=cards[a]*cards[b]*cards[d];if(v<0)negative.push(`${cards[a]}×${cards[b]}×${cards[d]}=${v}`)}
   c.methods=[c.methods[0],M('列出负乘积逐个比较','有负乘积可选，零和正乘积都不会取得最小值；按数字卡顺序列每一组三张，避免重复。',negative.join('；')+'。',`所有负乘积都在这张列表内，比较得到最小值${c.answer}。`)];
  }
  if(id==='cubeSteps')c.methods=[M('把列高正反写成两行',`每列只有1块宽，块数为1+2+……+${m.n}。把这列高度再倒写一行。`,`两行同一列的和都是${m.n+1}，共${m.n}列，所以两倍块数=${m.n}×${m.n+1}。`,`除以2得到${c.answer}块；列数为奇数时也适用。`)];
  if(id==='openBox'){
   const choices=[];for(let x=1;2*x<m.side;x++)choices.push(`x=${x}时体积${x*(m.side-2*x)**2}`);
   c.diagram={kind:'boxNet',side:m.side};c.methods=[M('由展开图确定尺寸再比较',`每条底边的两端各少x，高为x，故底边=${m.side}−2x，体积=x×(${m.side}−2x)²。`,`x为正整数且底边为正，只需检查1到${(m.side-2)/2}。`,choices.join('；')+'。',`完整比较这些合法切角方案，最大体积为${c.answer}。`)];
  }
  if(id==='natural-angleRatio')c.diagram={kind:'angleRatioTriangle',ratios:[...m.ratios]};
  return c;
 }
 function edit(family,seed){
  const t=base.competitionCreate({engine:2,familyId:family.id,seed}),c={...t.competition},m=c.math;
  c.title=family.title;c.level=family.level;c.insight=family.insight;c.extension=transfer(family.id,m,c);
  if(oneMethod.has(family.id))c.methods=[c.methods[0]];
  if(family.id==='fractionBackwards')c.diagram=null;
  if(family.id==='fixedPerimeter')c.diagram={kind:'rectangle',labels:['长 ?','宽 ?',`周长 ${2*m.half}，边长为正整数`]};
  if(['paintedCube','cubeProbability'].includes(family.id))c.methods=[c.methods[0],M('按六个面计数再去重',`每个面边缘去掉四个角，剩4×${m.n-2}个有两个面涂色的小块，共计六个面。`,`每个这样的块在两个面中各计一次，所以总数6×4×${m.n-2}÷2=${12*(m.n-2)}。`+(family.id==='cubeProbability'?`再除全部${m.n**3}块得到概率。`:''))];
  if(family.id==='checkerDomino')c.methods=[M('颜色上界与达到上界的摆法',...c.methods[0].steps,...c.methods[1].steps)];
  if(family.id==='routeProbability')c.methods=[c.methods[0],M('直接逐点累加可行路线',`A写1，P写0；其余点写左边和下边的路线数之和，直接得到不经过P的${routes(m.w,m.h,[m.x,m.y])}条路线。`,`分母用不封闭P的同类路径表，得到${routes(m.w,m.h)}条。两者之比为${c.answer}。`)];
  return polish(c,family.id);
 }
 const COMPETITION_REVIEWED=rows.map(([id,level,title,insight])=>{const f=base.COMPETITION_CATALOG.find(x=>x.id===id);return {...f,level,title,insight,origin:'reviewed-rc60',build:seed=>edit({id,level,title,insight},seed)}}).concat(extra.COMPETITION_EXPANSION.map(f=>({...f,origin:'new-structure',build(seed){const c=f.build(seed);if(oneMethod.has(f.id))c.methods=[c.methods[0]];return polish(c,f.id)}}))).concat(fresh.COMPETITION_FRESH.map(f=>({...f,origin:'rc64-structure'}))).map(f=>({...f,levelReason:descriptions[f.level]+'；'+f.insight,benchmarkMatch:['signedProduct','digitDivisor','overlapAverages','ageDifference','lShapeArea'].includes(f.id)?'相近推理结构':'同领域推理参照，不宣称同构',benchmarks:benchmarkMap[f.id]||[],benchmarkKind:benchmarkMap[f.id]?'已复核台账中的结构参照，原创题不等同真题':'原创结构，未宣称对应已复核真题'}));
 COMPETITION_REVIEWED.push(...rules.catalog.map(f=>({...f,levelReason:descriptions[f.level]+'；'+f.insight,benchmarkKind:'原创规则题，未宣称对应真题',benchmarks:[]})));
 COMPETITION_REVIEWED.push(...structured.catalog);
 for(const f of COMPETITION_REVIEWED){f.reasoningKey=f.reasoningKey||rules.reasoningKey(f.id)||f.strategy;Object.assign(f,design.family(f))}
 function competitionReviewedEligible(ids){const scope=new Set(competitionCanonicalIds(ids));return COMPETITION_REVIEWED.filter(f=>f.topicIds.every(id=>scope.has(id)))}
 function competitionReviewedCreate(recipe){
  const f=COMPETITION_REVIEWED.find(f=>f.id===recipe?.familyId),seed=recipe?.seed;
  const generatorRevision=recipe?.generatorRevision===undefined?1:recipe.generatorRevision;
  if(recipe?.engine!==3||!f||![1,2,3,4].includes(generatorRevision)||!Number.isInteger(seed)||seed<1||seed>2147483647)throw Error('Invalid reviewed competition recipe');
  if(f.id==='threeGroupBalance'&&generatorRevision!==4)throw Error('New family requires generator revision 4');
  const config=recipe.configurationId;
  if(config&&generatorRevision!==4)throw Error('New configurations require generator revision 4');
  let c=(generatorRevision===4&&(config||f.id==='threeGroupBalance'))?structured.create(f.id,config||'main',seed):null;
  if(!c){c=rules.decorate(f.build(seed,generatorRevision>=3?2:generatorRevision),f.id);if(generatorRevision>=3)c=design.revise(c,f,seed);if(config){c.configurationId=config;c.math={...c.math,configurationId:config}}}
  c=design.decorate(c,f,generatorRevision);
  if(f.id==='parityPermutations'&&config==='first-odd-transfer')c.quality.variationSpec={...c.quality.variationSpec,
   decision:'首位新增限制使第一个空隙不可用；重查可用空隙和不同数字的顺序',transferStrength:'changed-boundary'};
  else if(f.id==='parityPermutations')c.quality.variationSpec={...c.quality.variationSpec,
   transferStrength:c.math.n%2===0?'isomorphic-role-swap':'unequal-role-swap'};
  c=(typeof module!=='undefined'?require('./variation_state'):VariationState).normalize(c,f,generatorRevision);
  c.sourceProvenance=sources.provenance(f.id,config);c.requiredSkillsByRoute=sources.definitions[f.id]?.routes||[];
  if(generatorRevision===3&&!config||generatorRevision===4&&f.id==='parityPermutations'&&config==='first-odd-transfer')c.skillContractKey=sources.skillContractKey(f.id);
  const authoredGraph=(typeof module!=='undefined'?require('./reasoning_graph'):ReasoningGraph).create(c);
  c.routes=authoredGraph.routes;c.reasoningCoverage=authoredGraph.coverageStatus;c.answerContract=c.problemState.answerContract;
  if(c.sourceProvenance.matchType==='full_structure'||f.id==='threeGroupBalance'){if(c.methods.length!==authoredGraph.routes.length)throw Error('Source method/route mapping mismatch');c.methods=c.methods.map((m,i)=>({...m,routeId:authoredGraph.routes[i].id}));}
  c.variantTransform={kind:'declared-family-change',conditionId:c.extension.key||'condition-transfer',description:c.quality.variationSpec.change,baseStateId:c.problemState.id,targetStateId:c.extension.problemState.id,normalizationStatus:c.extension.problemState.adapterStatus};
  if(authoredGraph.routes.length&&!c.rc68Diagram){const ns=authoredGraph.routes[0].nodes;c.ruleHints=[ns[0].prompt,ns[Math.min(1,ns.length-1)].prompt];c.hintDiagram={...c.diagram,stage:{kind:'hint',text:c.ruleHints[1]}}}
  const rc69Hints={
   coordinateHorizontal:['两点的哪个坐标相同？先确定要沿哪条数轴比较。','在同一条数轴上标出两个横坐标，检查从左点到右点跨过多少单位。'],
   repeatedOnes:['先试由1个1和2个1组成的数，比较除以7的余数。','在末尾添1相当于原数乘10再加1；只追踪余数，看看何时重复。'],
   mixedPacks:['必须恰好，还是至少买够？先保留满足数量要求的整包方案。','尝试不同包数，核对总支数是否合格，再比较费用；不要只比较单包价格。'],
   mapScale:['同一条路在两张地图上的长度怎样对应？','把原长度看成同样的一份，检查放大或缩小的是哪一张地图。'],
   riverTravel:['顺流和逆流时，船与水流的方向分别是什么？','先求两段实际速度，再检查去回路程相同是否代表时间也相同。'],
   telescopingDifferences:['同一个中间数在相邻两个括号中怎样出现？','先写出相邻的两项比较，检查哪些项会抵消；由你确认最后留下的端点。']
  };
  if(rc69Hints[f.id]){c.ruleHints=rc69Hints[f.id];c.hintDiagram={...c.diagram,stage:{kind:'hint',text:c.ruleHints[1]}};}
  // Presentation-only staged quantities leave historical mathematical identity intact.
  if(['recurrenceRemainders','consecutiveRepresentations','remainderProbability','rotatingColors','stepwiseRoute'].includes(f.id)){
   const graph=(typeof module!=='undefined'?require('./reasoning_graph'):ReasoningGraph).create(c),nodes=graph.routes[0].nodes;
   c.methods=c.methods.map(method=>({...method,frames:method.steps.map((text,step)=>({kind:'scene-stage',scene:{kind:'scene-quantities',quantities:nodes.slice(0,Math.max(1,Math.ceil((step+1)*nodes.length/method.steps.length))).map(n=>({label:n.prompt,value:n.answer,unit:n.unit})),caption:'按这条路线连接已经得到的量'},stage:{kind:'solution',step,text}}))}));
  }
  if(f.id==='rule-packs-enough'){
   const p=c.math.params,plans=[];for(let k=0;k<=Math.ceil(p.count/p.size);k++){const single=Math.max(0,p.count-k*p.size),cost=k*p.pack+single*p.single;if(cost===Number(c.answer))plans.push(`${k}包加${single}支单买`)}
   if(plans.length>1)c.methods[0].steps[c.methods[0].steps.length-1]+=' 同价最优方案：'+plans.join('；')+'。';
  }
  const ids=competitionCanonicalIds(f.topicIds);
  const identityMath=f.origin==='rc65-rules'?{ruleVersion:c.math.ruleVersion,variant:c.math.variant,params:c.math.params}:c.math;
  // RC65 identities are immutable. New fractional recipes distinguish reviewed
  // countable-item and volume domains rather than silently conflating units.
  if(generatorRevision>=2&&f.origin==='rc65-rules'&&c.relationModel.key==='fraction-wholes')identityMath.quantityDomain=c.math.context==='supplies'?'count-items':'volume-litre';
  const signature=JSON.stringify({engine:1,topicIds:ids,family:c.family,math:identityMath}),id='COMP-'+competitionHash(signature);
  if(!c.prompt||c.clues||!c.extension||c.options.length!==5||new Set(c.options).size!==5||!c.options.includes(c.answer)||c.methods.length<1||c.methods.length>3)throw Error('Invalid reviewed competition content');
  const extension={...c.extension,key:c.extension.key||'condition-transfer'};
  extension.signature=JSON.stringify({main:signature,variation:extension.key});
  if(extension.topicIds&&!extension.topicIds.every(t=>ids.includes(t)))throw Error('Variation outside main scope');
  const restoredRecipe={engine:3,familyId:f.id,seed};if(recipe.generatorRevision!==undefined)restoredRecipe.generatorRevision=generatorRevision;if(config)restoredRecipe.configurationId=config;
  return {id,contentVersion:revision,skillId:ids[0]+'.01',phase:'挑战',mode:'competition',prompt:c.prompt,options:c.options,optionIds:c.options.map(v=>id+':'+v),answer:c.options.indexOf(c.answer),competition:{...c,reasoningKey:f.reasoningKey,hints:c.ruleHints||[f.insight],level:f.level,levelReason:f.levelReason,insight:f.insight,benchmarks:f.benchmarks,benchmarkKind:c.sourceProvenance.matchType==='full_structure'?'四个首批来源的完整结构配置，本地数学与结构已核验；整版发布验收待完成':'原创配置；历史索引仅作领域参考，未宣称完整同构',extension,signature,topicIds:ids,recipe:restoredRecipe}};
 }
 function competitionReviewedRecipe(familyId,seed){return {engine:3,familyId,seed,generatorRevision:familyId==='threeGroupBalance'?4:3}}
 return {COMPETITION_REVIEWED,competitionReviewedEligible,competitionReviewedCreate,competitionReviewedRecipe};
})(typeof module!=='undefined'?require('./competition_catalog'):{COMPETITION_CATALOG,competitionCreate:competitionCatalogCreate},typeof module!=='undefined'?require('./competition_expansion'):{COMPETITION_EXPANSION},typeof module!=='undefined'?require('./competition'):{competitionCanonicalIds,competitionHash,competitionFraction,competitionRatioText},typeof module!=='undefined'?require('./competition_fresh'):{COMPETITION_FRESH},typeof module!=='undefined'?require('./competition_rules'):CompetitionRules,typeof module!=='undefined'?require('./competition_design'):CompetitionDesign,typeof module!=='undefined'?require('./structured_recipes'):StructuredRecipes,typeof module!=='undefined'?require('./source_catalog'):SourceCatalog);
if(typeof module!=='undefined')module.exports={COMPETITION_REVIEWED,competitionReviewedEligible,competitionCreate:competitionReviewedCreate,competitionReviewedRecipe};
