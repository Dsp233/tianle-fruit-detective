'use strict';
// Student-created scratch models. Arithmetic checks never certify an invented
// relationship as relevant to the problem or as an independently proved route.
const LearnerSketch=((P)=>{
 const kinds=['quantity','bar','group','balance','set','timeline','table','area','stack'],relations=['=','+','−','×','÷','关联'],roles=['known','target','conjecture'];
 const fresh=signature=>({schemaVersion:1,signature,open:false,nodes:[],edges:[],nextId:1,selected:null,linkFrom:null,kindInput:'quantity',countInput:'1',unitInput:'',roleInput:'known',relationInput:'关联',labelInput:'',valueInput:'',expressionInput:'',feedback:null,undo:[],events:[]});
 const event=(s,type,data={})=>s.events.push({type,at:Date.now(),...data,help:false});
 function restore(value,signature){
  if(value?.schemaVersion!==1||value.signature!==signature)return fresh(signature);
  const s={...fresh(signature),open:value.open===true,kindInput:kinds.includes(value.kindInput)?value.kindInput:'quantity',countInput:String(value.countInput||'1').slice(0,2),unitInput:String(value.unitInput||'').slice(0,12),roleInput:roles.includes(value.roleInput)?value.roleInput:'known',relationInput:relations.includes(value.relationInput)?value.relationInput:'关联',labelInput:String(value.labelInput||'').slice(0,40),valueInput:String(value.valueInput||'').slice(0,160),expressionInput:String(value.expressionInput||'').slice(0,160),feedback:typeof value.feedback==='string'?value.feedback.slice(0,1000):null};
  const cleanNodes=items=>{const seen=new Set();return (Array.isArray(items)?items:[]).filter(n=>{if(!n||typeof n.id!=='string'||seen.has(n.id)||typeof n.label!=='string'||typeof n.value!=='string'||!Number.isFinite(n.x)||!Number.isFinite(n.y))return false;seen.add(n.id);return true}).slice(0,40).map(n=>({...n,label:n.label.slice(0,40),value:n.value.slice(0,160),unit:String(n.unit||'').slice(0,12),role:roles.includes(n.role)?n.role:'known',kind:kinds.includes(n.kind)?n.kind:'quantity',count:Number.isInteger(n.count)&&n.count>=1&&n.count<=12?n.count:1,x:Math.max(55,Math.min(465,n.x)),y:Math.max(55,Math.min(1800,n.y)),verification:'student-draft'}))};
  const cleanEdges=(items,ids)=>(Array.isArray(items)?items:[]).filter(e=>e&&ids.has(e.from)&&ids.has(e.to)&&e.from!==e.to&&relations.includes(e.label)).map(e=>({...e,verification:'student-draft'}));
  s.nodes=cleanNodes(value.nodes);const ids=new Set(s.nodes.map(n=>n.id));s.edges=cleanEdges(value.edges,ids);
  s.selected=ids.has(value.selected)?value.selected:null;s.linkFrom=ids.has(value.linkFrom)?value.linkFrom:null;s.nextId=Math.max(s.nodes.length+1,...s.nodes.map(n=>Number(n.id.match(/^student-(\d+)$/)?.[1]||0)+1),Number.isSafeInteger(value.nextId)?value.nextId:1);
  s.undo=(Array.isArray(value.undo)?value.undo:[]).slice(-20).map(old=>{const nodes=cleanNodes(old?.nodes),oldIds=new Set(nodes.map(n=>n.id));return {nodes,edges:cleanEdges(old?.edges,oldIds),selected:oldIds.has(old?.selected)?old.selected:null,linkFrom:oldIds.has(old?.linkFrom)?old.linkFrom:null}});
  s.events=(Array.isArray(value.events)?value.events:[]).filter(e=>e&&typeof e.type==='string'&&Number.isFinite(e.at)).map(e=>({...e,help:false}));
  return s;
 }
 function remember(s){s.undo.push({nodes:JSON.parse(JSON.stringify(s.nodes)),edges:JSON.parse(JSON.stringify(s.edges)),selected:s.selected,linkFrom:s.linkFrom});if(s.undo.length>20)s.undo.shift()}
 function attributes(s){const count=Number(s.countInput);if(!/^\d{1,2}$/.test(s.countInput)||count<1||count>12){s.feedback='图中份数或物件数请填 1 至 12；它由你决定，不是题目答案。';return null}return {kind:kinds.includes(s.kindInput)?s.kindInput:'quantity',count,unit:String(s.unitInput||'').slice(0,12),role:roles.includes(s.roleInput)?s.roleInput:'known'}}
 function add(s){
  const label=s.labelInput.trim(),value=s.valueInput.trim();if(!label){s.feedback='给这个量起一个名字，例如“红队人数”。';return false}if(s.nodes.length>=40){s.feedback='先整理已有的量，或保留这张图后另画一张。';return false}
  const attrs=attributes(s);if(!attrs)return false;remember(s);const i=s.nodes.length,id='student-'+s.nextId++;s.nodes.push({id,label:label.slice(0,40),value:value.slice(0,160),...attrs,x:85+(i%3)*175,y:65+Math.floor(i/3)*130,verification:'student-draft'});s.selected=id;s.linkFrom=null;s.labelInput='';s.valueInput='';s.feedback='这个量已放进你的草图。可选一个量作为连线起点。';event(s,'quantity-added',{nodeId:id,label,value,...attrs});return true;
 }
 function link(s,id,label='关联'){
  if(!s.nodes.some(n=>n.id===id))return false;
  if(!s.linkFrom){s.selected=id;const n=s.nodes.find(n=>n.id===id);s.labelInput=n.label;s.valueInput=n.value;s.kindInput=n.kind||'quantity';s.countInput=String(n.count||1);s.unitInput=n.unit||'';s.roleInput=n.role||'known';return true}
  if(!relations.includes(label))return false;
  if(s.linkFrom===id)return true;
  const from=s.linkFrom;if(s.edges.some(e=>e.from===from&&e.to===id&&e.label===label)){s.selected=id;s.linkFrom=null;return true}
  remember(s);s.edges.push({from,to:id,label,verification:'student-draft'});s.selected=id;s.linkFrom=null;s.feedback='关系已记下。检查它是否能由题目条件得到。';event(s,'relation-drafted',{from,to:id,label});return true;
 }
 function update(s){const n=s.nodes.find(n=>n.id===s.selected);if(!n||!s.labelInput.trim())return false;const attrs=attributes(s);if(!attrs)return false;remember(s);n.label=s.labelInput.trim().slice(0,40);n.value=s.valueInput.trim().slice(0,160);Object.assign(n,attrs);s.feedback='已修改这个量，使用它的关系也请重新核对。';event(s,'quantity-revised',{nodeId:n.id,label:n.label,value:n.value,...attrs});return true}
 function remove(s){if(!s.selected)return;remember(s);const id=s.selected;s.nodes=s.nodes.filter(n=>n.id!==id);s.edges=s.edges.filter(e=>e.from!==id&&e.to!==id);s.selected=null;if(s.linkFrom===id)s.linkFrom=null;event(s,'quantity-removed',{nodeId:id})}
 function move(s,dx,dy){const n=s.nodes.find(n=>n.id===s.selected);if(!n||!Number.isFinite(dx)||!Number.isFinite(dy))return;remember(s);n.x=Math.max(55,Math.min(465,n.x+dx));n.y=Math.max(55,Math.min(1800,n.y+dy));event(s,'quantity-moved',{nodeId:n.id,x:n.x,y:n.y})}
 function undo(s){const old=s.undo.pop();if(!old)return false;Object.assign(s,old);s.feedback='已撤回上一步，原操作仍保留在记录中。';event(s,'undo');return true}
 function calculate(s){
  const n=s.nodes.find(n=>n.id===s.selected),value=P.arithmetic(s.expressionInput);if(!n){s.feedback='先选你正在求的量。';return false}if(!value){s.feedback='算式已保留。可使用数、分数、括号及四则运算。';return false}
  const ok=n.value.trim()?P.equal(s.expressionInput,n.value):null;s.feedback=ok===null?'算式已记下。把计算结果写到对应的量，再代回题目条件。':ok?'计算一致。再检查这个量和所画关系是否符合题目条件。':'算式和这个量的数值还不一致，先核对计算。';
  event(s,'arithmetic-check',{nodeId:n.id,expression:s.expressionInput,arithmeticCorrect:ok,processVerified:false});return ok;
 }
 return {fresh,restore,event,add,link,update,remove,move,undo,calculate,kinds,relations,roles};
})(typeof module!=='undefined'?require('./problem_state'):ProblemState);
if(typeof module!=='undefined')module.exports=LearnerSketch;
