'use strict';
function learnerSketchState(task=playerTask()){
 const work=competitionState();if(!work.sketch||work.sketch.signature!==task.competition.signature)work.sketch=LearnerSketch.fresh(task.competition.signature);
 if(work.sketch.needsValidation){work.sketch=LearnerSketch.restore(work.sketch,task.competition.signature)}return work.sketch;
}
function learnerSketchGlyph(n){
 const count=n.count||1,shape='class="competition-shape"',line='class="competition-line"';let art='';
 if(n.kind==='quantity')return '<rect x="-39" y="-34" width="78" height="35" rx="7" '+shape+'/>';
 if(n.kind==='bar'){for(let i=0;i<count;i++)art+='<rect x="'+(-39+i*78/count)+'" y="-31" width="'+(78/count)+'" height="23" '+shape+'/>';return art}
 if(n.kind==='group'||n.kind==='set'||n.kind==='balance'){
  if(n.kind==='set')art+='<ellipse cx="0" cy="-18" rx="43" ry="26" '+shape+'/>';
  if(n.kind==='balance')art+='<path d="M-41-8 L-26 4 H26 L41-8 M0 4 V13 M-23 13 H23" '+line+' fill="none"/>';
  const columns=Math.min(4,count),rows=Math.ceil(count/columns);for(let i=0;i<count;i++)art+='<circle cx="'+((i%columns-(columns-1)/2)*17)+'" cy="'+(-24+Math.floor(i/columns)*13-(rows-1)*3)+'" r="5" '+shape+'/>';return art;
 }
 if(n.kind==='timeline'){art+='<path d="M-40-18 H40 M32-24 L40-18 L32-12" '+line+' fill="none"/>';for(let i=0;i<count;i++)art+='<path d="M'+(-34+i*68/Math.max(1,count-1))+'-24 V-12" '+line+'/>';return art}
 if(n.kind==='table'){
  const rowHeight=Math.min(16,50/(count+1));for(let row=0;row<=count;row++)for(let col=0;col<2;col++)art+='<rect x="'+(-36+col*36)+'" y="'+(-39+row*rowHeight)+'" width="36" height="'+rowHeight+'" fill="'+(row===0?'#c5dfd9':'white')+'" stroke="#286e78"/>';return art;
 }
 if(n.kind==='area'){
  const columns=Math.ceil(Math.sqrt(count)),rows=Math.ceil(count/columns),size=Math.min(19,50/rows);
  for(let i=0;i<count;i++)art+='<rect x="'+((i%columns-columns/2)*size)+'" y="'+(-38+Math.floor(i/columns)*size)+'" width="'+size+'" height="'+size+'" '+shape+'/>';return art;
 }
 if(n.kind==='stack'){for(let i=0;i<count;i++){const x=(i%4-1.5)*15,y=-14-Math.floor(i/4)*12;art+='<g data-student-block="true"><path d="M'+x+' '+y+' v-13 l7-5 13 0 v13 l-7 5 z" '+shape+'/><path d="M'+x+' '+(y-13)+' h13 v13 M'+(x+13)+' '+(y-13)+' l7-5" '+line+' fill="none"/></g>'}return art}
 return '';
}
function learnerSketchPanel(task){
 const s=learnerSketchState(task);if(!s.open)return '<button class="secondary" data-action="learnerSketchOpen">自己画一张关系草图</button>';
 const byId=new Map(s.nodes.map(n=>[n.id,n])),height=Math.max(170,...s.nodes.map(n=>n.y+68));
 let art='';for(const e of s.edges){const a=byId.get(e.from),b=byId.get(e.to);if(!a||!b)continue;art+='<path class="competition-line" d="M'+a.x+' '+a.y+' L'+b.x+' '+b.y+'" stroke-dasharray="4 3"/>'+ '<text x="'+((a.x+b.x)/2)+'" y="'+((a.y+b.y)/2-7)+'" text-anchor="middle">'+esc(e.label)+'</text>'}
 for(const n of s.nodes){art+='<g transform="translate('+n.x+' '+n.y+')" data-action="learnerSketchSelect" data-model-kind="'+esc(n.kind)+'" data-code="'+esc(n.id)+'" role="button" tabindex="0" aria-label="'+esc(n.label+'，'+(n.value||'未知量')+(n.unit||'')+'，'+({known:'自己标的已知',target:'自己选的目标',conjecture:'待检查的猜测'}[n.role]||''))+'"><rect x="-49" y="-46" width="98" height="104" rx="9" fill="white" stroke="'+(n.id===s.selected?'#ba7116':'#bed5d0')+'" stroke-width="'+(n.id===s.selected?3:1)+'"/>'+learnerSketchGlyph(n)+'<text x="-42" y="-40" font-size="9">'+esc({known:'已知',target:'要找',conjecture:'猜测'}[n.role]||'猜测')+'</text>';const lines=n.label.match(/.{1,6}/gu)||[''];lines.slice(0,2).forEach((l,i)=>art+='<text x="0" y="'+(20+i*14)+'" text-anchor="middle">'+esc(l)+'</text>');const v=(n.value||'?')+(n.unit||'');art+='<text x="0" y="49" text-anchor="middle">'+esc(v.length>10?v.slice(0,9)+'…':v)+'</text></g>'}
 return '<section class="learner-sketch panel" data-student-model="draft"><h2>我的关系草图</h2><p>自己放数量、连关系。图形是示意；份数或物件数由你填写，再核对题目。</p><div class="learner-sketch-scroll"><svg class="competition-diagram learner-sketch-canvas" viewBox="0 0 520 '+height+'" role="img" aria-label="孩子自己搭建的数量草图">'+art+'</svg></div><p class="tiny-note">可左右查看草图，也可用下面的数量按钮选择。</p><div class="learner-sketch-inputs"><label>这个量叫什么<input data-learner-sketch-input="labelInput" value="'+esc(s.labelInput)+'" maxlength="40" placeholder="例如红队人数"></label><label>数量或算式<input data-learner-sketch-input="valueInput" value="'+esc(s.valueInput)+'" placeholder="未知时可以留空"></label><label>用什么图形<select data-learner-sketch-input="kindInput">'+[['quantity','数量卡'],['bar','份数条'],['group','分组'],['balance','天平盘'],['set','集合圈'],['timeline','数轴标记'],['table','候选表格'],['area','面积格'],['stack','立体块']].map(([id,name])=>'<option value="'+id+'" '+(s.kindInput===id?'selected':'')+'>'+name+'</option>').join('')+'</select></label><label>图中份数或物件数<input data-learner-sketch-input="countInput" type="text" inputmode="numeric" value="'+esc(s.countInput)+'" maxlength="2"></label><label>单位<input data-learner-sketch-input="unitInput" value="'+esc(s.unitInput)+'" maxlength="12" placeholder="例如人、厘米"></label><label>这个量的作用<select data-learner-sketch-input="roleInput">'+[['known','已知条件'],['target','我要找的量'],['conjecture','我的猜测']].map(([id,name])=>'<option value="'+id+'" '+(s.roleInput===id?'selected':'')+'>'+name+'</option>').join('')+'</select></label><button class="secondary" data-action="learnerSketchAdd">放进草图</button><button class="secondary" data-action="learnerSketchUpdate">更新选中的量</button></div><div class="stage-buttons">'+s.nodes.map(n=>'<button class="secondary" data-action="learnerSketchSelect" data-code="'+esc(n.id)+'" aria-pressed="'+(s.selected===n.id)+'">'+esc(n.label)+'</button>').join('')+'</div><p>'+ (s.linkFrom?'已选连线起点，请选择另一个量。':'先选择一个量，再点连线。')+'</p><label>关系<select data-learner-sketch-input="relationInput">'+['关联','=','+','−','×','÷'].map(id=>'<option value="'+id+'" '+(s.relationInput===id?'selected':'')+'>'+id+'</option>').join('')+'</select></label><button class="secondary" data-action="learnerSketchLink">从选中量连线</button><div class="stage-buttons"><button class="secondary" data-action="learnerSketchMove" data-code="left">←</button><button class="secondary" data-action="learnerSketchMove" data-code="right">→</button><button class="secondary" data-action="learnerSketchMove" data-code="up">↑</button><button class="secondary" data-action="learnerSketchMove" data-code="down">↓</button><button class="secondary" data-action="learnerSketchRemove">移除选中的量</button><button class="secondary" data-action="learnerSketchUndo">撤回一步</button><button class="secondary" data-action="learnerSketchRedo">重做一步</button></div><label>这个量的计算<input data-learner-sketch-input="expressionInput" value="'+esc(s.expressionInput)+'" placeholder="写出你的算式"></label><button class="secondary" data-action="learnerSketchCheck">核对计算</button>'+(s.feedback?'<p role="status">'+esc(s.feedback)+'</p>':'')+'<button class="secondary" data-action="learnerSketchClose">收起，保留草图</button></section>';
}
function learnerSketchHandleInput(target){const key=target.dataset?.learnerSketchInput;if(!key||!['labelInput','valueInput','expressionInput','kindInput','relationInput','countInput','unitInput','roleInput'].includes(key)||view!=='competition')return false;learnerSketchState()[key]=String(target.value).slice(0,key==='labelInput'?40:160);persist();return true}
function learnerSketchHandleAction(action,data){
 if(!action.startsWith('learnerSketch'))return false;if(view!=='competition'||!playerTask()?.competition)return true;const s=learnerSketchState();
 if(action==='learnerSketchOpen'){s.open=true;LearnerSketch.event(s,'scratch-open')}
 if(action==='learnerSketchClose')s.open=false;
 if(action==='learnerSketchAdd')LearnerSketch.add(s);
 if(action==='learnerSketchSelect')LearnerSketch.link(s,data.code,s.relationInput);
 if(action==='learnerSketchUpdate')LearnerSketch.update(s);
 if(action==='learnerSketchLink'){s.linkFrom=s.selected;s.feedback=s.selected?'选择要连接的另一个量。':'先选一个量作为起点。';}
 if(action==='learnerSketchRemove')LearnerSketch.remove(s);
 if(action==='learnerSketchUndo')LearnerSketch.undo(s);
 if(action==='learnerSketchRedo')LearnerSketch.redo(s);
 if(action==='learnerSketchCheck')LearnerSketch.calculate(s);
 if(action==='learnerSketchMove'){const delta={left:[-20,0],right:[20,0],up:[0,-20],down:[0,20]}[data.code];if(delta)LearnerSketch.move(s,...delta)}
 persist();render();return true;
}
