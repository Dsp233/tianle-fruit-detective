"""Package committed code and frozen contracts for isolated native CI."""
import hashlib,json,pathlib,subprocess,tempfile,zipfile
root=pathlib.Path(__file__).resolve().parent.parent
identity=json.loads(subprocess.check_output(['node','-e',"process.stdout.write(JSON.stringify(require('./source/rc69_evidence').identity()))"],cwd=root,text=True))
tracked=subprocess.check_output(['git','status','--porcelain','--','source','index.html','amc8/index.html','qa'],cwd=root,text=True)
if tracked.strip():raise RuntimeError('Commit candidate code and builds before packaging')
target=root/'muse/rc69-candidate.zip';target.parent.mkdir(exist_ok=True)
paths=list((root/'source').glob('*'))+[root/p for p in ['index.html','amc8/index.html','qa/index.html','qa/normal/index.html','qa/history/index.html','docs/exam-review-ledger.csv','docs/rc68-execution-manifest.json','docs/rc69-execution-manifest.json','docs/evidence/rc68/holdout/interface-freeze-v2.json','docs/evidence/rc69/baseline/rc68-main.html']]
files=[p for p in paths if p.is_file() and p.suffix in ['.js','.py','.json','.css','.html','.csv']]
entries=[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)]
manifest={'schemaVersion':1,**identity,'files':entries,'productionSupplyCount':141,'productionConfigurations':148,'publicDeployment':False,'expectedQaSha256':hashlib.sha256((root/'qa/index.html').read_bytes()).hexdigest()}
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,str(p.relative_to(root)))
 z.writestr('frozen-identity.json',json.dumps(identity,ensure_ascii=False,indent=2)+'\n')
 z.writestr('transfer-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with tempfile.TemporaryDirectory(prefix='rc69-package-check-') as isolated:
 with zipfile.ZipFile(target) as z:z.extractall(isolated)
 for cmd in [['python3','source/build.py','--check'],['python3','source/build_qa.py','--check']]:subprocess.run(cmd,cwd=isolated,check=True,capture_output=True)
summary={'path':str(target),**identity,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'fileCount':len(entries)}
p=root/'docs/evidence/rc69/release/ci-package.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))
