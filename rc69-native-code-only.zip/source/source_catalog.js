'use strict';
const SourceCatalog=((data,registry)=>{
 const skills=new Map(data.skills.map(s=>[s.id,s]));
 function closure(ids){const out=new Set();function add(id){if(out.has(id))return;if(!skills.has(id))throw Error('Unknown required skill '+id);out.add(id);skills.get(id).prerequisiteIds.forEach(add)}ids.forEach(add);return [...out].sort()}
 const route=(id,direct)=>({id,directSkills:direct,requiredSkills:closure(direct)});
 const groupBase=['A02.01','A02.03','A02.04','A02.05','R01.01','L01.01'];
 const definitions=Object.fromEntries(registry.anchors.map(a=>[a.familyId,{examId:a.examId,configId:a.configurationId,sourceId:a.sourceId,routes:a.routes.map(r=>route(r.id,r.directSkills))}]));
 definitions.threeGroupBalance={configId:'main',routes:[route('reference-B',groupBase),route('direct-C',groupBase),route('ordered-trial',[...groupBase,'C02.03'])]};
 function definitionFor(id,config){const a=registry.anchors.find(a=>a.familyId===id&&a.configurationId===config);return a?{examId:a.examId,configId:a.configurationId,sourceId:a.sourceId,routes:a.routes.map(r=>route(r.id,r.directSkills))}:definitions[id]}
 function knownTopics(topicIds,excluded=[]){const set=new Set(topicIds),removed=new Set(excluded);return data.skills.filter(s=>set.has(s.unitId)&&!removed.has(s.id)).map(s=>s.id)}
 function allowedRoutes(routes,mastered){const set=new Set(mastered);return routes.filter(r=>r.requiredSkills.every(id=>set.has(id)))}
 function taskRoutes(task){
  const c=task.competition,base=closure(data.skills.filter(s=>(c.topicIds||[]).includes(s.unitId)).map(s=>s.id));
  const common=[c.prompt,c.extension.prompt,c.answer,c.extension.answer].join(' ');
  const extras=text=>{
   const ids=[];if(/[-−]?\d+\s*\/\s*\d+/.test(text))ids.push('A03.02','A03.04');
   if(/\d+\.\d+/.test(text))ids.push('A03.06');
   return ids;
  };
  return (c.routes||[]).map(r=>({id:r.id,requiredSkills:closure([...(c.sourceProvenance?.matchType==='full_structure'||c.family==='threeGroupBalance'?r.requiredSkills:[...base,...r.requiredSkills]),...extras(common+' '+r.nodes.map(n=>n.answer+' '+n.hints.join(' ')).join(' '))])}));
 }
 function taskAllowed(task,settings){return allowedRoutes(taskRoutes(task),knownTopics(settings.topicIds,settings.excludedSkillIds))}
 function loadsAllowed(task,settings){const c=task.competition;return (!settings.maxCalculationLoad||c.calculationLoad.level<=settings.maxCalculationLoad)&&(!settings.maxReadingLoad||c.readingLoad.level<=settings.maxReadingLoad)}
 const previewTasks=new Map();
 function preview(item,seed){
  const recipe={engine:3,familyId:item.id,seed,generatorRevision:item.generatorRevision||3,...(item.configurationId?{configurationId:item.configurationId}:{})},key=JSON.stringify(recipe);
  if(!previewTasks.has(key))previewTasks.set(key,(typeof module!=='undefined'?require('./competition_reviewed').competitionCreate:competitionCreate)(recipe));
  return previewTasks.get(key);
 }
 function eligible(families,settings){
  const mastered=knownTopics(settings.topicIds,settings.excludedSkillIds),scope=new Set(settings.topicIds),sources=settings.sourceIds||['AMC8'],ids=new Set(settings.examIds||[]),result=[];
  for(const f of families){const def=definitions[f.id];
   for(const a of registry.anchors.filter(a=>a.familyId===f.id)){
    if(!sources.includes(a.sourceId)||!registry.banks.some(b=>b.id===a.sourceId&&b.enabled)||!['structure_verified_local','runtime_verified','accepted'].includes(a.supplyStatus)||ids.size&&!ids.has(a.examId))continue;
    const routes=allowedRoutes(a.routes.map(r=>route(r.id,r.directSkills)),mastered);if(routes.length)result.push({...f,configurationId:a.configurationId,generatorRevision:a.generatorRevision,sourceId:a.sourceId,sourceExamId:a.examId,allowedRouteIds:routes.map(r=>r.id),requiredSkillsByRoute:routes});
   }
   if(sources.includes('original')&&!ids.size&&f.topicIds.every(x=>scope.has(x))){
    // Original route scopes are conservative until per-route contracts are reviewed.
    const routes=def&&!def.examId?def.routes:[route('legacy-topic-scope',data.skills.filter(s=>f.topicIds.includes(s.unitId)).map(s=>s.id))],allowed=allowedRoutes(routes,mastered);
    if(allowed.length)result.push({...f,configurationId:f.id==='threeGroupBalance'?'main':undefined,generatorRevision:f.id==='threeGroupBalance'?4:3,sourceId:'original',allowedRouteIds:allowed.map(r=>r.id),requiredSkillsByRoute:allowed})
   }
  }return result.filter(item=>[1,2,3,129,2147483647].some(seed=>{const t=preview(item,seed);return taskAllowed(t,settings).length&&loadsAllowed(t,settings)}));
 }
 function explain(families,settings){
  const topics=settings.topicIds||[],sourceIds=settings.sourceIds||['AMC8'],pool=eligible(families,settings),result={available:pool.length>0,count:pool.length,code:'available',message:'当前范围可开始挑战。',missingSkillIds:[]};if(pool.length)return result;
  if(!topics.length)return {...result,code:'no_topics',message:'先选你已经掌握的知识。'};
  if(!sourceIds.length)return {...result,code:'no_sources',message:'还没有选择参考来源，请勾选一种。'};
  const active=sourceIds.filter(id=>registry.banks.some(b=>b.id===id&&b.enabled));if(!active.length)return {...result,code:'source_material_missing',message:'所选来源的原始资料还未核验，暂时不能供题。'};
  if((settings.examIds||[]).length)return {...result,code:'exam_scope',message:'指定真题与当前知识范围没有匹配，请调整题号或已掌握范围。'};
  if(eligible(families,{...settings,maxCalculationLoad:null,maxReadingLoad:null}).length)return {...result,code:'load_limit',message:'计算量或阅读量限制挡住了可用题，可调整这两项。'};
  const mastered=new Set(knownTopics(topics,settings.excludedSkillIds)),scope=new Set(topics),candidates=[];
  for(const f of families){const d=definitions[f.id];if(active.includes('AMC8')&&d?.examId&&f.topicIds.some(id=>scope.has(id)))candidates.push(...d.routes);if(active.includes('original')&&f.topicIds.every(id=>scope.has(id)))candidates.push(...(d&&!d.examId?d.routes:[route('legacy-topic-scope',data.skills.filter(x=>f.topicIds.includes(x.unitId)).map(x=>x.id))]))}
  const missing=candidates.map(r=>r.requiredSkills.filter(id=>!mastered.has(id))).filter(x=>x.length).sort((a,b)=>a.length-b.length)[0];
  if(missing)return {...result,code:'missing_prerequisites',missingSkillIds:missing,message:'当前可用结构还需要：'+missing.slice(0,4).map(id=>skills.get(id).title).join('、')+(missing.length>4?'等知识':'')+'。只有确实已掌握时才调整范围。'};
  return {...result,code:'source_coverage_gap',message:'已核验的来源结构暂未覆盖当前选择。可以查看来源情况，或自行调整已掌握范围。'};
 }
 function provenance(id,config){const a=registry.anchors.find(a=>a.familyId===id&&a.configurationId===config);return a?{sourceId:a.sourceId,examId:a.examId,matchType:'full_structure',configurationId:config,reference:a.reference,sourceStatus:a.supplyStatus,acceptanceEvidence:[...(a.acceptanceEvidence||[])],releaseAcceptance:'pending'}:{sourceId:'original',matchType:'original',configurationId:config||'legacy-default'}}
 return {definitions,definitionFor,closure,knownTopics,allowedRoutes,taskRoutes,taskAllowed,loadsAllowed,eligible,provenance,explain,banks:registry.banks};
})(typeof module!=='undefined'?require('./skills.json'):window.__AMC8_SKILLS,typeof module!=='undefined'?require('./source_registry.json'):window.__AMC8_SOURCE_REGISTRY);
if(typeof module!=='undefined')module.exports=SourceCatalog;
