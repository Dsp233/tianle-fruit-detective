'use strict';
const assert=require('assert'),{save}=require('./rc68_evidence'),{oracle,rational,exactInput,groups}=require('./rc68_oracles'),MathState=require('./problem_state');
const {COMPETITION_REVIEWED:families,competitionCreate:create,competitionReviewedRecipe:recipe}=require('./competition_reviewed'),{StructuredRecipes}= {StructuredRecipes:require('./structured_recipes')}, {boot}=require('./test_support');
const seeds=[...Array.from({length:128},(_,i)=>i+1),129,2147483646,2147483647],app=boot(),rows=[],failures=[];let cases=0,renders=0;
const near=(a,b,label)=>assert(Number.isFinite(b)&&Math.abs(rational(a)-b)<1e-8,label+': '+a+' / '+b);
for(const f of families){const configs=[null,...(StructuredRecipes.sourceConfigs[f.id]?[StructuredRecipes.sourceConfigs[f.id]]:[]),...(StructuredRecipes.extraConfigs[f.id]||[]),...(f.id==='threeGroupBalance'?['change-difference-direction','change-ratio-reference','change-goal']:[])];
 for(const config of configs){let passed=0;
  for(const seed of seeds){try{
   const r=config?{...recipe(f.id,seed),generatorRevision:4,configurationId:config}:recipe(f.id,seed),task=create(r),c=task.competition,o=oracle(task,f);
   near(c.answer,o.answer,'main');near(c.extension.answer,o.extension,'variation');assert(MathState.equal(exactInput(o.extension),c.extension.answer),'Exact independent UI input disagrees with variant contract');assert.equal(task.options.filter(x=>Math.abs(rational(x)-o.answer)<1e-8).length,1);assert.equal(new Set(task.options.map(rational)).size,5);
   for(const d of [c.diagram,c.hintDiagram,c.extension.diagram,...c.methods.flatMap(m=>m.frames),...c.extension.solutionFrames]){const html=app.value('competitionDiagram('+JSON.stringify(d)+')');assert(html&&/<svg|class="scene-|class="competition-scene|<table/.test(html));assert(!/undefined|NaN|Infinity/.test(html));renders++}
   assert(c.problemState&&c.extension.problemState);const vs=c.extension.problemState;assert.equal(vs.adapterStatus,'explicit');near(vs.expectedAnswer,o.extension,'normalized variant oracle');assert.equal(vs.goal.id,c.extension.diagram.targetQuantityId);for(const frame of c.extension.solutionFrames){assert.equal(frame.mathStateId,vs.id);assert.equal(frame.scene.targetQuantityId,vs.goal.id);assert.equal(frame.stage.mathStateId,vs.id)}assert.equal(vs.answerContract.unit,vs.goal.unit);assert(vs.relations.length);assert.deepStrictEqual(vs.projection.diagram,c.extension.diagram);assert.equal(new Set(vs.quantityIds.map(x=>x.id)).size,vs.quantityIds.length);if(['setOutside','exactlyOneSet'].includes(f.id))assert.deepStrictEqual(c.extension.diagram.a,c.extension.problemState.math.a);
   if(f.id==='natural-digitCount'||f.id==='natural-distinctDigitCount')assert.notEqual(c.diagram.repeat,c.extension.diagram.repeat);
   if(f.id==='recurrenceBackwards')assert.deepStrictEqual(c.diagram.positionLabels.slice(-2),[c.math.n-1,c.math.n]);
   passed++;cases++;
  }catch(e){failures.push({familyId:f.id,configurationId:config,seed,error:e.message});break}}
  rows.push({familyId:f.id,configurationId:config||'default',passed,planned:131})
 }
}
for(const B of [2,25])for(const d of [1,15])for(const k of [2,4]){const p={T:(k+2)*B+d,d,k,direction:1,ref:'B',goal:'C'};assert.equal(groups(p),k*B)}
assert.throws(()=>StructuredRecipes.groupState(55,6,2,'invalid-discrete'));
const r=save('contracts/state',{result:failures.length?'failed':'passed',cases,renders,seedsPerConfiguration:131,families:families.length,rows,failures,limits:['Node production DOM, not browser geometry','Legacy independent oracles retained; new configurations use separately implemented algorithms']});if(r.result!=='passed')process.exitCode=1;
