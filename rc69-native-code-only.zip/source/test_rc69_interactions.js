'use strict';
// Production handler/state checks. A Node VM is explicitly not browser evidence.
const fs=require('fs'),assert=require('assert'),{boot}=require('./test_support'),M=require('./competition_reviewed'),{oracle,exactInput,rational}=require('./rc68_oracles'),{save,identity,hash}=require('./rc69_evidence');
const manifest=require('../docs/rc69-execution-manifest.json'),html=fs.readFileSync('qa/index.html','utf8');
const testedIdentity=identity(),qaBuildSha256=hash(html),release=require('./version.json'),reportName=process.env.AMC8_RC69_INTERACTION_REPORT||'regression/interactions';
const seeds=(process.env.AMC8_RC69_TEST_SEEDS||'1,2,129,2147483646,2147483647').split(',').map(Number);
const subset=process.env.AMC8_RC69_TEST_FAMILIES?.split(','),configs=manifest.configurations.filter(c=>!subset||subset.includes(c.familyId));
const rows=[],failures=[];let cases=0;
function check(a,c,seed,name,expected,action){
 cases++;
 const row={...testedIdentity,caseId:c.familyId+'/'+c.configurationId+'/'+seed+'/'+name,familyId:c.familyId,configurationId:c.configurationId,generatorRevision:c.rc68Recipe.generatorRevision,seed,contentRevision:release.contentRevision,runner:'Node VM production handlers',browser:null,steps:[name],expected,status:'NOT_RUN',observedAt:new Date().toISOString(),evidencePaths:[reportName+'.json']};
 try{row.actual=action();assert(row.actual.ok,row.actual.detail||name);row.status='PASS'}catch(e){row.status='FAIL';row.actual={error:e.message};failures.push(row)}rows.push(row);
}
for(const c of configs){const a=boot({},2000000000000,html),family=M.COMPETITION_REVIEWED.find(f=>f.id===c.familyId);
 for(const seed of seeds){
  const q={familyId:c.familyId,configuration:c.configurationId,seed,generatorRevision:c.rc68Recipe.generatorRevision};
  const load=()=>a.run('window.AMC8_QA.loadCase('+JSON.stringify(q)+',true)');load();const t=a.value('taskNow()'),o=oracle(t,family),mainInput=exactInput(o.answer),variantInput=exactInput(o.extension),isFree=c.familyId==='threeGroupBalance';
  const correct=t.options.findIndex(x=>Math.abs(rational(x)-rational(mainInput))<1e-8);assert(correct>=0);
  const pick=i=>isFree?a.inputCompetition('final',t.options[i]):a.click('competitionPick',{index:String(i)});
  check(a,c,seed,'empty-main','Visible validation and no attempt recorded',()=>{a.click('check');return {ok:!!a.value('feedback.text')&&a.value('saved.competition.attempts.length')===0,feedback:a.value('feedback')}});
  check(a,c,seed,'empty-main-refresh','Submitted empty validation survives refresh without an attempt',()=>{const b=boot(a.storage,2000000000001,html);b.run('window.AMC8_QA.loadCase('+JSON.stringify(q)+',false)');return {ok:b.value('feedback.status')==='awaiting_input'&&b.value('saved.competition.attempts.length')===0,feedback:b.value('feedback')}});
  if(isFree){for(const input of ['abc','987654']){load();a.inputCompetition('final',input);a.click('check');check(a,c,seed,'free-main-refresh-'+input,'Actual free input and typed feedback survive refresh',()=>{const b=boot(a.storage,2000000000001,html);b.run('window.AMC8_QA.loadCase('+JSON.stringify(q)+',false)');return {ok:b.value('reasoningState().state.finalInput')===input&&b.value('feedback.status')===(input==='abc'?'invalid_input':'needs_revision')&&!b.value('topicCurrent().passed'),feedback:b.value('feedback')}})}}
  for(let i=0;i<t.options.length;i++)if(i!==correct){
   load();pick(i);check(a,c,seed,'wrong-main-'+i,'Visible wrong-answer feedback; session remains editable',()=>{a.click('check');const f=a.value('feedback');return {ok:!!f?.text&&a.root.innerHTML.includes(a.value('esc(feedback.text)'))&&f.ok===false&&!a.value('topicCurrent().passed')&&a.value('saved.competition.attempts.at(-1).correct')===false,feedback:f,input:t.options[i]}});
   check(a,c,seed,'wrong-main-refresh-'+i,'Feedback and selected draft survive reload',()=>{const b=boot(a.storage,2000000000001,html);b.run('window.AMC8_QA.loadCase('+JSON.stringify(q)+',false)');return {ok:b.value('feedback.ok')===false&&!!b.value('feedback.text')&&!b.value('topicCurrent().passed'),feedback:b.value('feedback')}});
  }
  load();pick(correct);check(a,c,seed,'correct-main','Independent oracle answer completes this question',()=>{a.click('check');return {ok:a.value('topicCurrent().passed')===true&&a.value('feedback.ok')===true,answer:mainInput,feedback:a.value('feedback')}});
  check(a,c,seed,'repeat-correct-main','No duplicate completion or attempt',()=>{const count=a.value('saved.competition.attempts.length');a.click('check');return {ok:a.value('saved.competition.attempts.length')===count,count}});
  a.click('competitionIndependentVariation');
  check(a,c,seed,'empty-variant','Visible validation; no submission stored',()=>{a.click('competitionExtensionCheck');return {ok:!!a.value('draft.work.extensionResult')&&a.value('draft.work.extensionResult.ok')===false&&a.value('saved.competition.extensions.length')===0,result:a.value('draft.work.extensionResult')}});
  a.inputCompetition('extension','abc');a.click('competitionExtensionCheck');
  check(a,c,seed,'invalid-variant-refresh','Invalid format and draft survive refresh without a math attempt',()=>{const b=boot(a.storage,2000000000002,html);b.run('window.AMC8_QA.loadCase('+JSON.stringify(q)+',false)');return {ok:b.value('draft.work.extensionInput')==='abc'&&b.value('draft.work.extensionResult.status')==='invalid_input'&&b.value('saved.competition.extensions.length')===0,result:b.value('draft.work.extensionResult')}});
  a.inputCompetition('extension',exactInput(rational(variantInput)+1));
  check(a,c,seed,'wrong-variant','Visible wrong-answer result without losing the main pass',()=>{a.click('competitionExtensionCheck');const renderedFeedback=a.root.innerHTML.includes('class="variation-feedback"')&&a.root.innerHTML.includes('data-answer-status="needs_revision"');return {ok:renderedFeedback&&a.value('draft.work.extensionResult.ok')===false&&a.value('saved.competition.extensions.at(-1).correct')===false&&a.value('topicCurrent().passed')===true,result:a.value('draft.work.extensionResult'),renderedFeedback}});
  check(a,c,seed,'wrong-variant-refresh','Wrong variant draft/result survive reload',()=>{const b=boot(a.storage,2000000000002,html);b.run('window.AMC8_QA.loadCase('+JSON.stringify(q)+',false)');return {ok:b.value('draft.work.extensionResult.ok')===false&&b.value('topicCurrent().passed')===true,result:b.value('draft.work.extensionResult')}});
  a.inputCompetition('extension',variantInput);
  check(a,c,seed,'correct-variant','Independent oracle answer gives explicit confirmation',()=>{a.click('competitionExtensionCheck');return {ok:a.value('draft.work.extensionResult.ok')===true&&a.value('saved.competition.extensions.at(-1).correct')===true,result:a.value('draft.work.extensionResult'),answer:variantInput}});
  check(a,c,seed,'repeat-correct-variant','No duplicate successful variation record',()=>{const count=a.value('saved.competition.extensions.length');a.click('competitionExtensionCheck');return {ok:a.value('saved.competition.extensions.length')===count,count}});
 }
 console.log('Interaction configs '+(configs.indexOf(c)+1)+'/'+configs.length+' '+c.familyId);
}
save(reportName,{...testedIdentity,qaBuildSha256,result:failures.length?'failed':'passed',cases,passedChecks:cases-failures.length,configurationCount:configs.length,seeds,rows,failures,limits:['Node VM only; actual browser, layout, pointer and keyboard evidence remain separate','Independent oracle computes expected math; no real user records used']});if(failures.length)process.exitCode=1;
