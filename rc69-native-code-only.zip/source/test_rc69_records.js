'use strict';
const assert=require('assert'),fs=require('fs'),{boot,QA_STORE}=require('./test_support'),{save,identity}=require('./rc69_evidence');
const stamp=identity(),html=fs.readFileSync('qa/index.html','utf8'),formal='tianle_amc8_question_design_v1';let cases=0;const rows=[],failures=[];
function check(name,fn){cases++;try{const actual=fn();rows.push({name,status:'PASS',actual})}catch(e){failures.push({name,error:e.message});rows.push({name,status:'FAIL',error:e.message})}}
for(const entry of ['index.html','qa/normal/index.html'])check('Wrong-answer reload stays writable through correction and invalid variation: '+entry,()=>{
 const entryHtml=fs.readFileSync(entry,'utf8');let a=boot({},2000000000000,entryHtml);
 a.run('saved.topicPractice.selectedTopicIds=["A01"];saved.topicPractice.sourceIds=["original"]');a.click('topicStart');assert(!a.value('taskNow()?.competition'));assert.deepStrictEqual(a.value('saved.topicPractice.selectedTopicIds'),['A01']);
 // The recovery journey declares the arithmetic its actual task uses. A failed
 // supply attempt must never expand the child's knowledge declaration.
 a.run('saved.topicPractice.selectedTopicIds=["A01","A02"]');a.click('topicStart');const t=a.value('taskNow()');assert(t?.competition);assert.notEqual(t.competition.family,'threeGroupBalance');
 const resume=()=>{a.click('topicResume');while(a.value('topicSession().cursor')>0)a.click('topicPrevious');assert.equal(a.value('taskNow().id'),t.id)};
 a.click('competitionPick',{index:String((t.answer+1)%t.options.length)});a.click('check');assert.equal(a.value('feedback.ok'),false);
 a=boot(a.storage,2000000000001,entryHtml);assert.equal(a.value('canPersist'),true);assert.equal(a.value('storageMessage'),'');resume();assert.equal(a.value('feedback.ok'),false);
 a.click('competitionPick',{index:String(t.answer)});a.click('check');assert.equal(a.value('topicCurrent().passed'),true);
 a=boot(a.storage,2000000000002,entryHtml);assert.equal(a.value('canPersist'),true);resume();assert.equal(a.value('topicCurrent().passed'),true);
 a.click('competitionIndependentVariation');a.inputCompetition('extension','abc');a.click('competitionExtensionCheck');assert.equal(a.value('draft.work.extensionResult.status'),'invalid_input');
 a=boot(a.storage,2000000000003,entryHtml);assert.equal(a.value('canPersist'),true);resume();assert.equal(a.value('draft.work.extensionInput'),'abc');assert.equal(a.value('draft.work.extensionResult.status'),'invalid_input');
 assert(a.root.innerHTML.includes('data-answer-status="invalid_input"'));assert(a.root.innerHTML.includes('competition-extension" open'));
 return {entry,arithmeticExplicitlyDeclared:true,unsupportedScopeNotAutoExpanded:true,wrongFeedbackRestored:true,correctionPersisted:true,invalidVariantRestored:true,writableAfterEachReload:true};
});
check('Selection B remains after continuing old session A',()=>{
 let a=boot();for(const id of ['A01','A02','R01','L01'])a.click('topicSelect',{code:id});a.click('sourceToggle',{code:'original'});a.click('topicStart');const old=a.value('topicSession().topicIds');a.click('topicExit');a.click('topicClear');for(const id of ['L03','N04'])a.click('topicSelect',{code:id});a=boot(a.storage);assert.deepStrictEqual(a.value('saved.topicPractice.selectedTopicIds'),['L03','N04']);a.click('topicResume');assert.deepStrictEqual(a.value('topicSession().topicIds'),old);a.click('topicExit');assert.deepStrictEqual(a.value('saved.topicPractice.selectedTopicIds'),['L03','N04']);return {oldSession:old,currentPreference:['L03','N04']};
});
check('Concurrent write protection preserves newer stored record',()=>{
 const a=boot();a.click('topicSelect',{code:'A02'});const other=JSON.parse(a.storage[formal]);other.topicPractice.selectedTopicIds=['G03'];const changed=JSON.stringify(other);a.storage[formal]=changed;a.click('topicSelect',{code:'R01'});assert.equal(a.storage[formal],changed);assert.equal(a.value('canPersist'),false);assert(a.value('storageMessage').includes('另一个页面'));assert.deepStrictEqual(a.value('progressSnapshot().record.topicPractice.selectedTopicIds'),['A02','R01']);return {storedPreference:['G03'],draftPreference:['A02','R01']};
});
check('Upgrade backup and unknown fields retained',()=>{
 const a=boot();a.click('topicSelect',{code:'A02'});const old=JSON.parse(a.storage[formal]);old.contentRevision=101;old.customHistory={unrecognized:[{note:'must preserve'}]};const raw=JSON.stringify(old),b=boot({[formal]:raw});assert.equal(b.storage[formal+'_backup_before_rc69'],raw);b.click('topicSelect',{code:'R01'});assert.deepStrictEqual(JSON.parse(b.storage[formal]).customHistory,old.customHistory);return {backupExact:true,unknownFieldsPreserved:true};
});
check('All saved main and variation records above legacy caps survive',()=>{
 const a=boot({},2000000000000,html);a.run('window.AMC8_QA.loadCase({familyId:"bells",seed:1,generatorRevision:3},true)');const t=a.value('taskNow()');a.click('competitionPick',{index:String(t.answer)});a.click('check');a.click('competitionIndependentVariation');a.inputCompetition('extension',a.value('taskNow().competition.extension.answer'));a.click('competitionExtensionCheck');
 a.run('saved.competition.attempts=Array.from({length:520},(_,i)=>({...saved.competition.attempts[0],at:Date.now()+i,order:i+1}));saved.competition.extensions=Array.from({length:320},(_,i)=>({...saved.competition.extensions[0],at:Date.now()+i,order:i+1}));persist()');
 const b=boot(a.storage,2000000001000,html);assert.equal(b.value('saved.competition.attempts.length'),520);assert.equal(b.value('saved.competition.extensions.length'),320);assert.equal(b.value('CompetitionIdentity.counts(saved.competition).solved'),1);assert.equal(b.value('CompetitionIdentity.counts(saved.competition).extensions'),1);return {mainRows:520,variantRows:320,distinctMain:1,distinctVariant:1};
});
check('QA namespace leaves production marker untouched',()=>{
 const a=boot({[formal]:'synthetic marker'},2000000000000,html);a.run('window.AMC8_QA.loadCase({familyId:"bells",seed:1,generatorRevision:3},true)');a.click('competitionPick',{index:'0'});a.click('check');assert.equal(a.storage[formal],'synthetic marker');assert(a.storage[QA_STORE]);assert.equal(a.value('progressSnapshot().store'),QA_STORE);return {qaStore:QA_STORE,formalUntouched:true};
});
check('Corrupt and future stores remain unchanged',()=>{
 for(const raw of ['broken-json',JSON.stringify({contentRevision:999,storageVersion:999})]){const a=boot({[formal]:raw});a.click('topicSelect',{code:'A02'});assert.equal(a.storage[formal],raw);assert.equal(a.value('canPersist'),false)}return {cases:2};
});
check('Old RC68 rollback refuses to overwrite RC69 records',()=>{
 const oldHtml=fs.readFileSync('docs/evidence/rc69/baseline/rc68-main.html','utf8'),a=boot();a.click('topicSelect',{code:'A02'});const raw=a.storage[formal],b=boot(a.storage,2000000001000,oldHtml);assert.equal(b.value('canPersist'),false);b.click('topicSelect',{code:'R01'});assert.equal(b.storage[formal],raw);assert(b.value('storageMessage').includes('更新的版本'));return {oldBuild:require('./rc69_evidence').hash(oldHtml),rollbackReadOnly:true,recordUnchanged:true};
});
check('Storage quota failure keeps the judged result and in-memory draft visible',()=>{
 const a=boot({},2000000000000,html);a.run('window.AMC8_QA.loadCase({familyId:"bells",seed:1,generatorRevision:3},true)');const t=a.value('taskNow()');a.run('localStorage.setItem=()=>{throw Error("synthetic quota failure")}');a.click('competitionPick',{index:String((t.answer+1)%t.options.length)});a.click('check');assert.equal(a.value('feedback.ok'),false);assert(a.root.innerHTML.includes(a.value('esc(feedback.text)')));assert(a.value('storageMessage').includes('未能保存'));assert.equal(a.value('saved.competition.attempts.length'),1);return {feedbackVisible:true,memoryDraftRetained:true,storageFailureExplicit:true};
});
save('history/records',{...stamp,result:failures.length?'failed':'passed',cases,rows,failures,limits:['Synthetic stores and Node production handlers; actual browser and old-version rollback separately required']});if(failures.length)process.exitCode=1;
