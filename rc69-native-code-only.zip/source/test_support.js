'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm');
function boot(seed={},now=2000000000000,htmlOverride=null){
 const storage={...seed},root={innerHTML:''},status={},events={},spoken=[],utterances=[];
 const document={getElementById:id=>id==='app'?root:status,addEventListener:(name,cb)=>events[name]=cb};
 const window={scrollTo(){},speechSynthesis:{cancel(){},speak(u){spoken.push(u.text);utterances.push(u)}}};
 const ctx={window,document,console,localStorage:{getItem:k=>storage[k]||null,setItem:(k,v)=>storage[k]=v,removeItem:k=>delete storage[k]},SpeechSynthesisUtterance:function(text){this.text=text},Date:class extends Date{static now(){return typeof now==='object'?now.now:now}},setTimeout,clearTimeout};
 vm.createContext(ctx);const html=typeof htmlOverride==='string'?htmlOverride:fs.readFileSync(path.join(__dirname,'index.html'),'utf8');for(const [,code] of html.matchAll(/<script>([\s\S]*?)<\/script>/g))vm.runInContext(code,ctx);
 return {ctx,root,storage,spoken,utterances,click(action,extra={}){const target={dataset:{action,...extra},closest(){return this}};events.click({target})},inputJoint(field,value){events.input({target:{dataset:{jointField:field},value:String(value),matches:()=>false}})},inputCompetition(field,value){events.input({target:{dataset:{competitionInput:field},value:String(value),matches:()=>false}})},value(code){const v=vm.runInContext(code,ctx);return v===undefined?undefined:JSON.parse(JSON.stringify(v))},run(code){return vm.runInContext(code,ctx)}};
}
const release=require('./version.json'),releaseId='rc'+release.siteVersion.match(/rc\.(\d+)/)[1];
module.exports={boot,QA_STORE:'tianle_amc8_qa_'+releaseId+'_v1',QA_HISTORY_STORE:'tianle_amc8_qa_history_'+releaseId+'_v1'};
