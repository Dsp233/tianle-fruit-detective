'use strict';
// Current variants have their own conditions, target and quantity domain.
// Original recipe maths is immutable; this module does not rewrite signatures.
const VariationState=((h,math)=>{
 const F=h.competitionFraction,copy=x=>JSON.parse(JSON.stringify(x)),sum=a=>a.reduce((s,x)=>s+x,0),num=x=>String(x).split('/').map(Number).reduce((a,b)=>a/b);
 const fact=n=>{let v=1;for(let i=2;i<=n;i++)v*=i;return v};
 const choose=(n,k)=>{if(k<0||k>n)return 0;let v=1;for(let i=1;i<=k;i++)v=v*(n-i+1)/i;return v};
 const gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return a},lcm=(a,b)=>a*b/gcd(a,b);
 const sequence=(a,b,n)=>{const s=[a,b];while(s.length<n)s.push(s.at(-1)+s.at(-2));return s};
 const productMin=(a,k)=>{let best=Infinity;function visit(i,left,p){if(!left){best=Math.min(best,p);return}for(let j=i;j<=a.length-left;j++)visit(j+1,left-1,p*a[j])}visit(0,k,1);return best};
 const modPower=(a,k,m)=>{let v=1;while(k){if(k%2)v=v*a%m;a=a*a%m;k=Math.floor(k/2)}return v};
 function describe(c,f,revision){
  const id=f.id,m=c.math,v=c.extension.math||{},key=c.extension.key;let p,goal,value,unit='',model,conditions=[];
  const set=(type,parameters,target,result,u='',rules=[])=>{model=type;p=parameters;goal=target;value=String(result);unit=u;conditions=rules};
  if(c.configurationId&&id==='threeGroupBalance'){
   const q=v,extra=q.direction*q.d*(q.ref==='A'?q.k+1:1),B=(q.T-extra)/(q.k+2),A=B+q.direction*q.d,C=q.k*(q.ref==='A'?A:B);
   if(![A,B,C].every(x=>Number.isInteger(x)&&x>0))throw Error('Invalid discrete group variant');
   set('three-group-reference',{T:q.T,d:q.d,k:q.k,direction:q.direction,reference:q.ref,targetGroup:q.goal},'group-'+q.goal,({A,B,C})[q.goal],'人',['A+B+C=T','A-B=direction*d','C=k*reference']);
  }else if(c.configurationId&&id==='signedProduct')set('signed-card-product',{cards:v.cards,choose:2},'minimum-product',productMin(v.cards,2),'',['Distinct card positions','Exactly two cards']);
  else if(c.configurationId&&id==='digitDivisor'){
   const q=v;let count=0;for(let n=q.lo+1;n<q.hi;n++){const u=n%10;if(u&&n%u===0&&n%2===0)count++}
   set('strict-digit-divisor',{lower:q.lo,upper:q.hi,lowerIncluded:false,upperIncluded:false,zeroDivisorAllowed:false,evenOnly:true},'legal-count',count,'个',['Two-digit integers','Nonzero unit digit divides number','Even integer']);
  }else if(c.configurationId&&id==='lShapeArea')set('hidden-L-perimeter',{inner:m.inner,border:m.border,regionSide:m.inner+m.border},'shaded-boundary',4*(m.inner+m.border),'长度单位',['Boundary replaces removed inner edges','Area and perimeter are different targets']);
  else if(c.configurationId&&id==='overlapAverages'){const values=v.values,front=sum(values.slice(0,5)),back=sum(values.slice(4)),all=sum(values);set('overlap-averages',{frontMean:F(front,5),backMean:F(back,5),allMean:F(all,9),n:9,segmentSize:5,middlePosition:5},'middle-number',front+back-all,'',['First and last five overlap only at position five'])}
  else if(id.startsWith('rule-')){
   const q=Object.fromEntries(Object.entries(v.params).map(([k,x])=>[k,num(x)])),type=v.variant;
   if(type.startsWith('join-')){const joins=type==='join-closed'?q.n:q.n-1;set('joined-length',{...q,closed:type==='join-closed',joinCount:joins},type==='join-piece'?'piece-length':'joined-length',type==='join-piece'?F(q.total+joins*q.lap,q.n):q.n*q.piece-joins*q.lap,'厘米',['Each join removes one overlap length'])}
   else if(type.startsWith('posts-'))set('interval-endpoints',{...q,includeBothEnds:type==='posts-both'},'marker-count',q.distance/q.gap+(type==='posts-both'?1:-1),'个',['Equal whole intervals','Endpoint inclusion changes marker count']);
   else if(type==='weighted-mean')set('weighted-average',q,'mean-score',F(q.a*q.low+q.b*q.high,q.a+q.b),'分',['Scores are weighted by representative population parts']);
   else if(type==='weighted-score'){const [a,d=1]=String(v.params.mean).split('/').map(Number);set('weighted-score',q,'low-score',F(a*(q.a+q.b)-q.b*q.high*d,d*q.a),'分',['Representative total minus known group total'])}
   else if(type==='ratio-length')set('ratio-perimeter',q,'length',F(q.perimeter*q.b,2*(q.a+q.b)),'米',['Two lengths and two widths make perimeter']);
   else if(type==='ratio-perimeter')set('ratio-perimeter',q,'perimeter',F(2*q.width*(q.a+q.b),q.a),'米',['A width has a parts; length has b parts']);
   else if(type==='fraction-reverse')set('fraction-wholes',{...q,secondWhole:'remainder'},'original-amount',F(q.left*q.d1*q.d2,(q.d1-1)*(q.d2-1)),v.context==='supplies'?'张':'升',['Second fraction uses first remainder']);
   else if(type==='fraction-original')set('fraction-wholes',{...q,secondWhole:'original'},'remaining-amount',F(q.start*(q.d1*q.d2-q.d1-q.d2),q.d1*q.d2),v.context==='supplies'?'张':'升',['Both fractions use original amount']);
   else if(type==='fraction-of-used')set('fraction-wholes',{...q,secondWhole:'first-used'},'remaining-amount',F(q.start*(q.d1*q.d2-q.d2-1),q.d1*q.d2),v.context==='supplies'?'张':'升',['Second fraction uses first used amount']);
   else if(type.startsWith('packs-')){let best=Infinity;for(let n=0;n<=Math.ceil(q.count/q.size);n++){const remaining=q.count-n*q.size;if(type==='packs-only-exact'){if(remaining===0)best=Math.min(best,n*q.pack)}else if(type==='packs-exact'){if(remaining>=0)best=Math.min(best,n*q.pack+remaining*q.single)}else best=Math.min(best,n*q.pack+Math.max(0,remaining)*q.single)}set('finite-purchase',{...q,requirement:type==='packs-enough'?'at-least':'exact',singleAllowed:type!=='packs-only-exact'},'minimum-cost',Number.isFinite(best)?best:0,'元',['Whole packages','Positive costs','No feasible exact plan uses result zero'])}
   else throw Error('Unregistered rule variant '+type);
  }else switch(id){
   case 'reverseDigits':set('place-value',{digitSum:m.a+m.b,digitDifference:m.a-m.b,order:'smaller'},'two-digit-number',10*m.b+m.a,'',['Both digits nonzero','Swapped sum is 11 times digit sum']);break;
   case 'fractionBackwards':set('fraction-wholes',{original:3*m.left,d1:2,d2:3,secondWhole:'original'},'remaining-amount',F(m.left,2),'枚',['Both uses refer to original total']);break;
   case 'percentRoundTrip':set('changing-percent-base',{original:m.start,increasePercent:m.percent,secondGoal:'restore-original',secondBase:'raised-price'},'decrease-percent',F(100*m.percent,100+m.percent),'%前的数',['Reduction amount is divided by raised price']);break;
   case 'squareBorder':set('partial-border',{originalSide:m.n,width:1,sides:['left','top'],cornerCount:1},'new-cells',2*m.n+1,'块',['Top-left added corner counted once']);break;
   case 'ratioEqualize':set('external-removal',{red:m.a*m.unit,blue:m.b*m.unit,removedBlue:(m.b-m.a)*m.unit},'remaining-total',2*m.a*m.unit,'个',['Red amount unchanged','Blue reduced externally']);break;
   case 'packPrice':{let best=Infinity;for(let k=0;k<=Math.ceil(m.count/3);k++)best=Math.min(best,k*m.pack+Math.max(0,m.count-3*k)*m.single);set('finite-purchase',{...m,size:3,requirement:'at-least'},'minimum-cost',best,'元',['Whole packages','Surplus allowed']);break}
   case 'equalDistanceSpeed':set('journey',{speeds:[m.speed,2*m.speed],equalQuantity:'time'},'mean-speed',F(3*m.speed,2),'千米/时',['Equal time, not equal distance']);break;
   case 'oppositeScale':set('area-scale',{lengthNumerator:m.b,lengthDenominator:m.a,bothSidesScale:true},'area-multiplier',F(m.b*m.b,m.a*m.a),'倍',['Area uses two length factors']);break;
   case 'balanceCancel':set('balance',{boxWeight:m.x,removedBoxes:1,removedSide:'right'},'added-mass',m.x,'克',['A removed box needs equal replacement mass']);break;
   case 'tickets':{const total=m.adults*m.adult+(m.people-m.adults)*m.child;let count=0;for(let a=0;a*m.adult<=total;a++)if((total-a*m.adult)%m.child===0)count++;set('integer-ticket-plans',{adultPrice:m.adult,childPrice:m.child,total,peopleConstraint:null,zeroAllowed:true},'plan-count',count,'种',['Nonnegative integer ticket counts']);break}
   case 'recurrenceBackwards':{const delta=sequence(1,0,m.n).at(-1);set('recurrence-increment',{firstIncrease:1,secondIncrease:0,termCount:m.n,rule:'sum-previous-two'},'last-increase',delta,'',['Delta follows same recurrence']);break}
   case 'linearTable':set('ordered-machine',{multiplier:m.k,addition:m.b,input:m.target,order:'add-then-multiply'},'output',(m.target+m.b)*m.k,'',['Fixed constants preserved; operation order changes']);break;
   case 'divisibleDigits':{let max=0;for(let b=0;b<10;b++)for(let d=0;d<10;d+=2){const n=1000*m.a+100*b+10*m.b+d;if(n%9===0)max=Math.max(max,n)}set('digit-constraints',{thousands:m.a,tens:m.b,divisors:[9,2]},'maximum-number',max,'',['Four digits','Unknown hundreds and units']);break}
   case 'factorBalance':set('factor-pairs',{product:m.product,positiveIntegers:true,objective:'maximum-sum'},'factor-sum',m.product+1,'',['All positive factor pairs']);break;
   case 'bells':set('period-events',{periods:[m.a,m.b],start:0,end:lcm(m.a,m.b),includeStart:true,includeEnd:true},'simultaneous-count',2,'次',['Both boundaries included']);break;
   case 'lastDigit':set('last-digit',{base:m.base,exponents:[m.exponent,m.exponent+1],combine:'sum'},'units-digit',(modPower(m.base,m.exponent,10)+modPower(m.base,m.exponent+1,10))%10,'',['Add the two units before reducing modulo ten']);break;
   case 'fixedPerimeter':{const min=revision>=3?v.minSide:2,half=m.half,areas=[];for(let a=min;a<=half-min;a++)if(revision>=3||a%2===0&&(half-a)%2===0)areas.push(a*(half-a));set('integer-rectangle',{halfPerimeter:half,minSide:min,evenOnly:revision<3,objective:revision>=3?'minimum-area':'maximum-area'},'area',revision>=3?Math.min(...areas):Math.max(...areas),'面积单位',['Both sides positive and satisfy bounds']);break}
   case 'outsideAngle':set('isosceles-angle',{apex:m.apex,target:'other-base',knownExterior:90+m.apex/2},'base-angle',F(180-m.apex,2),'度',['Equal base angles']);break;
   case 'overlapSquares':set('square-overlap',{side:m.n,dx:m.dx,dy:m.dy,colorCoverage:'exactly-one'},'colored-area',2*(m.n*m.n-(m.n-m.dx)*(m.n-m.dy)),'面积单位',['Intersection removed from both sheets']);break;
   case 'circleRoute':set('cycle-cover',{segments:m.sectors,lengthPerSegment:m.unit,mustReturn:true,mustCoverAll:true},'shortest-distance',m.sectors*m.unit,'米',['At least one traversal per segment']);break;
   case 'similarAreaPerimeter':set('similar-scale',{perimeterMultiplier:m.b},'area-multiplier',m.b*m.b,'倍',['Length ratio squared']);break;
   case 'ladderShift':set('right-triangle',{hypotenuse:5*m.k,height:4*m.k},'base-distance',3*m.k,'米',['Same ladder length']);break;
   case 'paintedCube':set('painted-cube',{n:m.n,paintedFaces:['top','bottom'],exactPaintedFaceCount:1},'cube-count',2*m.n*m.n,'块',['Opposite faces do not share small cubes']);break;
   case 'exactlyOneSet':set('sets',{a:m.a,b:m.b+1,both:m.both+1},'exactly-one-count',m.a+m.b-2*m.both-1,'人',['One A-only person joins B']);break;
   case 'gridDetour':set('grid-routes',{w:m.w,h:m.h,excludedPoint:null,requiredFirstStep:'up'},'route-count',choose(m.w+m.h-1,m.w),'条',['Shortest right/up route']);break;
   case 'adjacentLine':set('line-arrangements',{n:m.n,specialPeople:2,adjacent:false},'arrangement-count',fact(m.n)-2*fact(m.n-1),'种',['People distinct','Special pair nonadjacent']);break;
   case 'restrictedTeam':set('team-selection',{n:m.n,teamSize:3,mandatoryPeople:2,roles:false},'team-count',m.n-2,'种',['Two mandatory people occupy two positions']);break;
   case 'digitComplement':set('passwords',{alphabetSize:10,length:m.length,targetDigit:m.digit,requiredOccurrences:1,leadingZeroAllowed:true},'password-count',m.length*9**(m.length-1),'个',['Exactly one position has target digit']);break;
   case 'chartScale':set('chart-increment',{originalHeights:[m.a,m.b,m.c],incrementEach:1,unit:m.unit},'population-increase',3*m.unit,'人',['Same scale for all three bars']);break;
   case 'missingAverage':{const omitted=m.count*m.mean-(m.count-1)*m.other;set('average-members',{remainingCount:m.count-1,remainingTotal:(m.count-1)*m.other,omitted,omittedCopies:2,newCount:m.count+1},'new-average',F((m.count-1)*m.other+2*omitted,m.count+1),'',['Duplicated omitted value changes numerator and denominator']);break}
   case 'diceSum':{let good=0;for(let a=1;a<=m.faces;a++){const b=m.target-a;if(b>=1&&b<=m.faces&&a!==b)good++}set('conditional-dice',{faces:m.faces,targetSum:m.target,different:true,sampleSize:m.faces*(m.faces-1)},'probability',F(good,m.faces*(m.faces-1)),'',['Ordered outcomes','Diagonal outcomes excluded']);break}
   case 'foldHoles':set('folded-holes',{interior:m.interior+1,edge:m.edge-1,center:m.center},'unfolded-count',4*(m.interior+1)+2*(m.edge-1)+m.center,'个',['Moved edge hole now has four symmetric copies']);break;
   case 'checkerDomino':set('domino-board',{w:m.w,h:m.h,removedCorners:['top-left','top-right']},'maximum-dominoes',(m.w*m.h-2)/2,'块',['Even board dimensions','Removed corners have opposite colors']);break;
   case 'natural-weighted':case 'natural-fractionWeighted':{const swap=revision>=3,red=swap?m.blue:2*m.red,blue=swap?m.red:m.blue;set('weighted-average',{red,blue,redScore:m.redScore,blueScore:m.blueScore,scoreDenominator:m.den,change:swap?'swap-population-parts':'double-red'},'mean-score',F(red*m.redScore+blue*m.blueScore,m.den*(red+blue)),'分',['Population weights change; scores unchanged']);break}
   case 'natural-catch':set('post-meeting-journey',{movingSpeed:m.slow,stationarySpeed:0,time:m.delay},'separation-distance',m.slow*m.delay,'米',['Fast walker stops after meeting']);break;
   case 'natural-tiles':{const w=2*m.w,h=2*m.h,s=gcd(w,h);set('square-tiling',{w,h,allowCut:false,side:s},'minimum-tiles',w*h/(s*s),'块',['Largest whole square side divides both dimensions']);break}
   case 'natural-pairChance':set('replacement-sampling',{red:m.red,blue:m.blue,draws:2,replacement:true},'two-red-probability',F(m.red*m.red,(m.red+m.blue)**2),'',['Independent draws after remix']);break;
   case 'natural-unionChance':case 'natural-complementChance':set('conditional-sets',{a:m.red,b:m.blue,both:m.both,total:m.total,condition:'union'},'both-given-union',F(m.both,m.red+m.blue-m.both),'',['Conditional denominator is union']);break;
   case 'natural-offers':set('price-threshold',{price:m.price,fee:m.fee,discountNumerator:3,discountDenominator:4,otherDiscountAmount:1,quantityDomain:'positive-integer'},'least-quantity',Math.ceil(4*m.fee/(m.price-4)),'件',['Compare whole orders','Round up to integer']);break;
   case 'natural-angleRatio':{const ratios=[...m.ratios,Math.max(...m.ratios)];set('polygon-angle-parts',{ratios,sides:4,totalAngle:360},'smallest-angle',F(360*Math.min(...ratios),sum(ratios)),'度',['Four interior angles']);break}
   case 'natural-digitCount':case 'natural-distinctDigitCount':{const distinct=!m.distinct;let count=0;for(const a of m.digits)for(const b of m.digits)if((!distinct||a!==b)&&(10*a+b)%3===0)count++;set('digit-choice',{digits:m.digits,distinct,divisor:3},'number-count',count,'个',['Digit repetition rule changed']);break}
   case 'natural-coordinateDistance':set('grid-distance',{start:[m.x,m.y],end:[m.x+m.dx,m.y+m.dy],allowedAxes:['horizontal','vertical']},'shortest-distance',Math.abs(m.dx)+Math.abs(m.dy),'长度单位',['No diagonal movement']);break;
   case 'routeProbability':set('uniform-grid-routes',{w:m.w,h:m.h,requiredFirstStep:'up',excludedPoint:null},'probability',F(m.h,m.w+m.h),'',['Complete shortest routes equiprobable']);break;
   case 'cubeProbability':set('conditional-painted-cube',{n:m.n,paintedFaces:6,condition:'at-least-one',targetPaintedFaces:2},'probability',F(12*(m.n-2),m.n**3-(m.n-2)**3),'',['Only boundary cubes form sample space']);break;
   case 'overlapProbability':set('square-overlap',{side:m.n,dx:m.dx,dy:m.dy,sample:'first-sheet'},'probability',F((m.n-m.dx)*(m.n-m.dy),m.n*m.n),'',['Sample space is one full first square']);break;
   case 'ratioUnion':set('set-ratio',{chess:m.a*m.unit,ball:m.b*m.unit+1,both:m.both+1,total:(m.a+m.b)*m.unit-m.both},'chess-over-ball',F(m.a*m.unit,m.b*m.unit+1),'',['One chess-only person joins ball group','Union unchanged','Original ratio no longer applies']);break;
   case 'chartAverage':{const counts=[...m.counts];counts[2]++;set('weighted-chart',{counts,scores:[2,4,6],newScore:6},'mean-score',F(counts[0]*2+counts[1]*4+counts[2]*6,sum(counts)),'分',['A new person joins top score bin']);break}
   case 'parityPermutations':{
    const odd=Math.ceil(m.n/2),even=Math.floor(m.n/2);
    if(c.configurationId==='first-odd-transfer')set('nonadjacent-evens-first-odd',{n:m.n,odd,even,distinct:true,firstParity:'odd',nonadjacent:'even'},'arrangement-count',fact(odd)*choose(odd,even)*fact(even),'种',['All evens occupy separate odd gaps','Leading gap is unavailable because the first number is odd']);
    else set('nonadjacent-odds',{n:m.n,odd,even,distinct:true},'arrangement-count',fact(even)*choose(even+1,odd)*fact(odd),'种',['All odd numbers placed in separate even gaps']);break}
   case 'recurrenceRemainders':{let a=2,b=2,total=0;for(let i=0;i<m.n;i++){total+=a%3;[a,b]=[b%3,(a+b)%3]}set('recurrence-remainders',{first:2,second:2,n:m.n,modulus:3},'remainder-sum',total,'',['Reduce each term before summing']);break}
   default:return describeMore(c,f,revision,set);
  }
  return finalize(id,model,p,goal,value,unit,conditions);
 }
 function finalize(id,model,p,goal,value,unit,conditions){return {schemaVersion:1,familyId:id,model,parameters:copy(p),goal:{id:id+':variation:'+goal,name:goal,unit},expectedAnswer:String(value),conditions:conditions.map((statement,i)=>({id:id+':variation:condition-'+(i+1),statement})),quantityDomain:unit||'dimensionless-exact'}}
 function describeMore(c,f,revision){
  const id=f.id,m=c.math,v=c.extension.math||{},set=(type,p,goal,value,unit='',rules=[])=>finalize(id,type,p,goal,value,unit,rules);
  switch(id){
   case 'digitInsert':{const s=String(10*m.a+m.b),candidates=[Number(String(m.d)+s),Number(String(m.a)+m.d+m.b),Number(s+m.d)];return set('digit-insertion',{originalDigits:[m.a,m.b],inserted:m.d,positions:3,objective:'minimum'},'number',Math.min(...candidates),'',['Original digit order preserved'])}
   case 'numberAppend':return set('place-value-prefix',{original:m.n,prefix:m.digit||1,originalDigits:2},'increase',100*(m.digit||1),'',['Two-digit original retains its value']);
   case 'pairedSum':{const k=Math.floor(m.n/2);return set('arithmetic-sum',{first:2,last:2*k,gap:2,count:k},'sum',k*(k+1),'',['Only even terms retained'])}
   case 'telescopingDifferences':return set('consecutive-differences',{start:m.start+m.step,step:m.step,terms:m.n-1},'sum',(m.n-1)*m.step,'',['First difference term omitted']);
   case 'neighborProducts':return set('neighbor-products',{center:m.n,offset:2},'difference',4,'',['Compare center square with symmetric product']);
   case 'fractionDifferentWholes':return set('separate-fraction-wholes',{firstWhole:m.a,secondWhole:m.b,firstUsedDenominator:4,secondUsedDenominator:3},'remaining-total',F(9*m.a+8*m.b,12),'颗',['Each fraction keeps its own box as whole']);
   case 'fractionSharedRemainder':{const original=12*m.unit;return set('fraction-wholes',{original,firstDenominator:3,externalAdded:m.add,secondNumerator:3,secondDenominator:8,secondWhole:'original'},'remaining-amount',F(7*original+24*m.add,24),'个',['External addition follows first use','Second use changes to original whole'])}
   case 'discountOrder':return set('ordered-price',{price:m.price,coupon:m.q,discountPercent:m.p,order:'coupon-then-percent'},'final-price',F((m.price-m.q)*(100-m.p),100),'元',['Percent applies after fixed coupon']);
   case 'percentRestore':{const percent=m.p===100?50:m.p;return set('restore-after-decrease',{originalReference:100,decreasePercent:percent,current:100-percent},'increase-percent',F(100*percent,100-percent),'%前的数',['Increase measured against decreased current price'])}
   case 'squareBounds':return set('square-root-bound',{number:m.n,direction:'upper-inclusive'},'integer',m.k*m.k===m.n?m.k:m.k+1,'',['Equality permitted at perfect square']);
   case 'signedProduct':{const cards=[-4*m.k,-3*m.k,-m.k,0,2*m.k,5*m.k];return set('signed-card-product',{cards,choose:2},'minimum-product',productMin(cards,2),'',['Two distinct cards'])}
   case 'ratioTotal':return set('external-addition',{red:m.a*m.u,blue:m.b*m.u,addedRed:m.b-m.a},'absolute-difference',Math.abs(m.b*m.u-m.a*m.u-(m.b-m.a)),'块',['Blue unchanged']);
   case 'linkedRatios':{const blue=m.b*m.c*m.u,green=m.b*m.d*m.u;return set('equalize-blue-green',{blue,green,changeOnly:'blue'},'adjustment',Math.abs(green-blue),'块',['Add if fewer; remove if more'])}
   case 'unitConversion':return set('capacity-units',{totalMilliliters:1000*m.liters,cupMilliliters:2*m.cup,wholeCupsOnly:true},'full-cups',Math.floor(1000*m.liters/(2*m.cup)),'杯',['Use same volume unit']);
   case 'mixedPacks':{let best=Infinity;for(let a=0;a<=Math.ceil(m.count/4);a++)for(let b=0;b<=Math.ceil(m.count/6);b++)if(4*a+6*b>=m.count)best=Math.min(best,a*m.p+b*m.q);return set('finite-purchase',{sizes:[4,6],prices:[m.p,m.q],count:m.count,requirement:'at-least',singleAllowed:false},'minimum-cost',best,'元',['Whole package types','Surplus allowed'])}
   case 'jointWork':return set('single-worker',{rate:m.a,total:(m.a+m.b)*m.t},'time',F((m.a+m.b)*m.t,m.a),'分钟',['Same work amount; only A works']);
   case 'riverTravel':return set('still-water-round-trip',{speed:m.v,waterSpeed:0,oneWay:m.distance,legs:2},'time',F(2*m.distance,m.v),'小时',['Current removed; both legs remain']);
   case 'mapScale':return set('map-scale',{originalLength:m.a,firstMultiplier:m.k,secondNumerator:1,secondDenominator:2},'map-length',F(m.a*m.k,2),'厘米',['Second scaling applies to current map']);
   case 'scaleAreaReverse':return set('area-scale',{originalArea:m.old,lengthMultiplier:m.k,secondScaling:false},'area',m.old*m.k*m.k,'面积单位',['Only first enlargement occurs']);
   case 'ageDifference':return set('future-age-ratio',{childNow:m.child,parentNow:m.parent,targetRatio:2},'elapsed-years',m.parent-2*m.child,'年',['Both ages increase by same time']);
   case 'repeatedMachine':{const first=m.a*(m.x+m.b);return set('repeated-machine',{input:m.x,addition:m.b,multiplier:m.a,order:'add-then-multiply',repetitions:2},'output',m.a*(first+m.b),'',['Same constants, new operation order'])}
   case 'twoCoins':return set('coin-removal',{coinCount:m.n,oneUnitCount:m.n-m.twos,twoUnitCount:m.twos,removed:[1,2]},'remaining-value',m.n+m.twos-3,'元',['Remove one of each coin type']);
   case 'stampConstraint':{let count=0;for(let a=0;3*a<=m.total;a++)if((m.total-3*a)%5===0)count++;return set('integer-stamp-plans',{prices:[3,5],total:m.total,zeroAllowed:true},'plan-count',count,'种',['Nonnegative counts; same amount'])}
   case 'recurrenceForward':return set('recurrence',{first:m.b,second:m.a,n:m.n,rule:'sum-previous-two'},'term',sequence(m.b,m.a,m.n).at(-1),'',['Initial terms exchanged']);
   case 'recurrenceTotal':return set('recurrence-sum',{first:m.a,second:m.b,n:m.n,startTerm:2,endTerm:m.n},'sum',sum(sequence(m.a,m.b,m.n).slice(1)),'',['Term one excluded']);
   case 'machineMeeting':return set('equal-machine-output',{leftMultiplier:m.a,leftAddition:m.d+1,rightMultiplier:m.c,rightAddition:m.b},'input',F(m.d+1-m.b,m.c-m.a),'',['Only left output gets extra one']);
   case 'machineOrder':{const x=2*m.x,ab=m.c*(m.a*x+m.b)+m.d,ba=m.a*(m.c*x+m.d)+m.b;return set('composition-order',{A:[m.a,m.b],B:[m.c,m.d],input:x},'absolute-output-difference',Math.abs(ab-ba),'',['Compare both full operation orders'])}
   case 'digitDivisor':return set('division-domain',{tens:m.tens,units:0,divisor:0},'rule-is-meaningful',0,'0/1',['Division by zero has no meaning']);
   case 'divisibleEleven':{let count=0;for(let b=0;b<=9;b++)for(const d of [0,5])if((1000*m.a+100*b+10*m.c+d)%11===0)count++;return set('digit-constraints',{thousands:m.a,tens:m.c,divisors:[11,5]},'legal-count',count,'个',['Count all valid four-digit integers'])}
   case 'threeDivisors':{let best=0;for(let p=2;p*p<=m.limit;p++){let prime=true;for(let d=2;d*d<=p;d++)if(p%d===0){prime=false;break}if(prime)best=p*p}return set('three-positive-divisors',{limit:m.limit,objective:'largest'},'integer',best,'',['Exactly three positive divisors'])}
   case 'divisorPowers':return set('square-divisors',{primeExponents:[m.a,m.b],primes:[2,3],exponentParity:'even'},'count',(Math.floor(m.a/2)+1)*(Math.floor(m.b/2)+1),'个',['Both prime exponents even']);
   case 'equalBags':{const g=gcd(m.a,m.b);let count=0;for(let n=1;n<=g;n++)if(g%n===0)count++;return set('equal-bag-counts',{amounts:[m.a,m.b],commonDivisor:g,objective:'count-all'},'bag-count-options',count,'种',['Bag count divides both stocks'])}
   case 'offsetBells':{let first=m.a;while((first-m.offset)%m.b!==0||first<m.offset)first+=m.a;return set('offset-period-events',{periods:[m.a,m.b],offset:m.offset,occurrence:2,includeStart:false},'time',first+lcm(m.a,m.b),'分钟',['Find next full simultaneous period'])}
   case 'cyclicPosition':return set('cyclic-walk',{size:m.size,start:m.start,steps:m.steps,direction:-1},'position',((m.start-1-m.steps)%m.size+m.size)%m.size+1,'',['Positions labeled one through size']);
   case 'repeatedOnes':{let r=0;for(let i=0;i<m.n+1;i++)r=(10*r+1)%7;return set('decimal-remainder',{digit:1,length:m.n+1,divisor:7},'remainder',r,'',['Append one more decimal digit'])}
   case 'rectangleDiagonalArea':return set('diagonal-area',{widthNumerator:3*m.w,widthDenominator:2,height:m.h,areaFraction:'1/2'},'triangle-area',F(3*m.w*m.h,4),'面积单位',['Only width increased by half']);
   case 'boundaryNotch':return revision>=3?set('internal-hole-boundary',{outer:[v.w,v.h],hole:[v.a,v.b],placement:'internal',includeHoleBoundary:true},'boundary-length',2*(v.w+v.h+v.a+v.b),'长度单位',['Outer and hole outlines both counted']):set('corner-notch',{outer:[m.w,m.h],notch:[m.a,m.depth],placement:'corner'},'boundary-length',2*(m.w+m.h),'长度单位',['Removed corner edges replaced by equal-length inner edges']);
   case 'angleMarks':return set('circle-angle',{marks:m.marks,steps:m.marks-m.step,direction:'other'},'angle',F(360*(m.marks-m.step),m.marks),'度',['Use complementary arc']);
   case 'polygonTurn':return set('polygon-turns',{sides:m.n,passedVertices:Math.floor(m.n/2)},'total-turn',F(360*Math.floor(m.n/2),m.n),'度',['Count actual passed vertices']);
   case 'lShapeArea':return set('internal-hole-area',{outer:[m.w,m.h],hole:[m.a,m.b],placement:'internal'},'remaining-area',m.w*m.h-m.a*m.b,'面积单位',['Same hole area, new placement']);
   case 'crossArea':return set('strip-intersection',{outer:[m.w,m.h],stripWidths:[m.a,m.b],target:'intersection'},'area',m.a*m.b,'面积单位',['Only region covered by both strips']);
   case 'semicircleBoundary':return set('whole-circle',{radius:m.radius,pi:3,joinedDiametersAreInternal:true},'outer-boundary',6*m.radius,'长度单位',['Straight joining edges are internal']);
   case 'circleRingRatio':return set('circle-ring',{innerRadius:2*m.r1,outerRadius:2*m.r2,sample:'outer-disk'},'area-ratio',F(m.r2*m.r2-m.r1*m.r1,m.r2*m.r2),'',['Common radius factor cancels']);
   case 'shadowSimilarity':return set('shadow-ratio',{smallHeight:m.a,bigHeight:m.b*m.unit,bigShadow:m.b*m.unit,timeChanged:true},'small-shadow',m.a,'长度单位',['New equal shadow-to-height ratio']);
   case 'parallelTriangle':return set('parallel-triangle',{originalArea:m.area,lengthRatio:'1/2',target:'lower-trapezoid-ratio'},'area-ratio','3/4','',['Triangle area ratio is length ratio squared']);
   case 'coordinateHorizontal':return set('horizontal-distance',{start:[m.a+5,m.y],end:[m.b+5,m.y],shift:5},'distance',Math.abs(m.b-m.a),'长度单位',['Both points share same translation']);
   case 'hypotenuseMidpoint':return set('leg-midpoint',{shortLeg:3*m.k,longLeg:4*m.k,midpointSide:'long-leg'},'vertex-distance',2*m.k,'长度单位',['Midpoint on a leg, not hypotenuse']);
   case 'cubeSteps':return set('stair-cubes',{columns:m.n,heights:'1..n',depth:2},'cube-count',m.n*(m.n+1),'块',['Thickness doubles all columns']);
   case 'openBox':return set('box-base',{paperSide:m.side,cornerCut:1,bottomSide:m.side-2},'bottom-area',(m.side-2)**2,'面积单位',['Fixed cut; target is bottom area, not volume']);
   case 'setOutside':return set('sets',{a:m.a+1,b:m.b+1,both:m.both+1,total:m.total},'outside-count',m.total-m.a-m.b+m.both-1,'人',['One previously outside person joins both groups']);
   case 'threeSetExactlyTwo':return set('three-sets',{ab:m.ab,ac:m.ac,bc:m.bc,triple:m.triple,pairCountsIncludeTriple:true},'at-least-two-count',m.ab+m.ac+m.bc-2*m.triple,'人',['Triple-members included once in target']);
   case 'menuBranches':return set('menu-branches',{rice:m.rice,dish:m.dish,noodle:m.noodle,drinks:3},'menu-count',3*(m.rice*m.dish+m.noodle),'种',['One of rice-with-dish or noodle; every lunch gets a drink']);
   case 'binaryNoNeighbors':{let count=0;for(let mask=0;mask<2**m.n;mask++)if((mask>>(m.n-1)&1)&&!(mask&(mask<<1)))count++;return set('binary-lights',{positions:m.n,adjacentOnAllowed:false,firstOn:true},'configuration-count',count,'种',['First position lit; no adjacent lit positions'])}
   case 'unorderedPairs':return set('distinct-roles',{n:m.n,roles:2,oneRolePerPerson:true},'arrangement-count',m.n*(m.n-1),'种',['Role order distinguishes arrangements']);
   case 'circularSeating':return set('circular-arrangements',{people:m.n,rotationEquivalent:true,adjacencyConstraint:null},'arrangement-count',fact(m.n-1),'种',['Fix a reference seat; no special adjacency']);
   case 'differentDigits':return set('unordered-code-symbols',{symbols:m.digits,choose:2,repeat:false,exchangeEquivalent:true},'code-count',choose(m.digits,2),'个',['Symbols distinct; exchanged positions equivalent']);
   case 'allThreeColors':return set('exact-color-usage',{positions:m.n,availableColors:3,requiredColors:2},'coloring-count',3*(2**m.n-2),'种',['Choose used pair; exclude its two single-color assignments']);
   case 'truncatedBars':return set('bar-difference',{base:m.base,step:m.step,heights:[m.a,m.b]},'population-difference',(m.b-m.a)*m.step,'人',['Common axis baseline cancels']);
   case 'cumulativeChart':return set('cumulative-chart',{counts:[m.a,m.b,m.c,m.d],targetExactScore:4},'count',m.d,'人',['Fourth exact bin, not cumulative total']);
   case 'medianSort':return set('median-change',{sortedOriginal:Array.from({length:5},(_,i)=>m.start+i*m.gap),changedIndex:4,increase:100},'median',m.start+2*m.gap,'',['Largest value remains largest']);
   case 'overlapAverages':{const values=[...m.values,m.values[0],m.values[6]],front=sum(values.slice(0,5)),back=sum(values.slice(4)),all=sum(values);return set('overlap-averages',{frontMean:F(front,5),backMean:F(back,5),allMean:F(all,9),n:9,segmentSize:5,middlePosition:5},'middle-number',front+back-all,'',['Position five is shared by two five-term segments'])}
   case 'spinnerLabels':return set('conditional-spinner',{counts:{A:m.a,B:m.b,C:m.c},excludedLabels:['C'],targetLabel:'A'},'probability',F(m.a,m.a+m.b),'',['All sectors equal area','Condition changes sample space']);
   case 'conditionalBalls':return set('conditional-ball-pairs',{red:m.red,blue:m.blue,draws:2,replacement:false,condition:'same-color'},'both-red-probability',F(m.red*(m.red-1),m.red*(m.red-1)+m.blue*(m.blue-1)),'',['Nonreplacement pairs; condition removes mixed pairs']);
   case 'quarterTurn':return set('quarter-turn',{start:m.start,turns:m.turns,direction:-1},'direction',((m.start-m.turns)%4+4)%4,'0..3',['Counterclockwise rotation']);
   case 'transformOrder':{const reflected=(4-m.start)%4;return set('transform-order',{start:m.start,rotation:m.rot,order:['mirror','rotate']},'direction',(reflected+m.rot)%4,'0..3',['Reflection precedes rotation'])}
   case 'lightSwitchParity':return set('toggle-state',{initial:m.on,presses:m.groups*m.per+m.extra+1},'final-state',(m.on+m.groups*m.per+m.extra+1)%2,'0/1',['One extra toggle']);
   case 'ballReplacement':return set('replacement-invariant',{white:m.white+1,black:m.black,rule:'same-black-different-white'},'last-ball-code',(m.white+1)%2,'0/1',['White parity preserved']);
   case 'transferBetweenBoxes':return set('external-box-addition',{firstBefore:F(2*m.a*m.moved,m.b-m.a),secondBefore:F(2*m.b*m.moved,m.b-m.a),externalAdded:m.moved,target:'remaining-gap'},'difference',m.moved,'块',['Addition from outside, not internal transfer']);
   case 'rectanglePointAreas':return set('point-area-balance',{leftBefore:m.left,rightBefore:m.right,leftIncrease:1,verticalPositionUnchanged:true},'right-area',m.right-1,'面积单位',['Opposite triangle areas have fixed sum']);
   case 'worstCaseColors':return set('guarantee-colors',{capacities:m.caps,targetSameColor:m.k+1},'draw-count',sum(m.caps.map(x=>Math.min(x,m.k)))+1,'个',['Maximal still-failing draw plus one']);
   case 'stagedClimb':return set('complete-day-night',{up:m.up,down:m.down,threshold:m.height,earlyStop:false,observedTime:'after-night'},'day-count',Math.ceil(m.height/(m.up-m.down)),'天',['Every nightly retreat is completed']);
   case 'consecutiveRepresentations':{let count=0;for(let n=2;n*(n-1)/2<=m.total;n++){const a=(m.total-n*(n-1)/2)/n;if(Number.isInteger(a)&&a>=0)count++}return set('consecutive-sum',{total:m.total,minStart:0,minTerms:2},'representation-count',count,'种',['Nonnegative, consecutive, at least two terms'])}
   case 'remainderProbability':{let good=0;for(let n=0;n<=m.count;n++)if(n%m.mod===m.wanted)good++;return set('remainder-cards',{start:0,end:m.count,modulus:m.mod,targetRemainder:m.wanted},'probability',F(good,m.count+1),'',['Zero included as one additional equally likely card'])}
   case 'rotatingColors':return set('marked-ring',{positions:m.n,red:m.red,fixedReference:true,rotationEquivalent:false},'coloring-count',choose(m.n,m.red),'种',['Star fixes position numbering']);
   case 'stepwiseRoute':return set('uniform-complete-routes',{w:m.w,h:m.h,point:[m.x,m.y],sampling:'complete-routes'},'through-point-probability',F(choose(m.x+m.y,m.x)*choose(m.w+m.h-m.x-m.y,m.w-m.x),choose(m.w+m.h,m.w)),'',['Complete routes equiprobable; no per-junction weighting']);
   default:return null;
  }
 }
 function normalize(c,f,revision){
  const prior=c.extension.problemState;
  // Historical recipes remain replayable under their original mathematical
  // contract. New state contracts apply to current revisions three and four.
  if(revision<3)return {...c,extension:{...c.extension,problemState:{...prior,legacyNormalization:'historical-contract-preserved'}}};
  const n=describe(c,f,revision);if(!n)throw Error('Missing current variant state '+f.id);
  if(!math.equal(n.expectedAnswer,c.extension.answer))throw Error('Variant state answer disagreement '+f.id);
  const d=copy(c.extension.diagram),before=['ratioUnion','ratioEqualize','ratioTotal'].includes(f.id);
  const captions={
   ratioUnion:'变化前的份数关系；同一位棋类组成员又加入球类组，原比例不再适用',
   ratioEqualize:'变化前的红蓝份数；只取走蓝球，红球不变',
   ratioTotal:'变化前的红蓝份数；增加的是实际红积木数量',
   cubeProbability:'取样范围：至少一面涂色的小块',
   paintedCube:'只涂顶面和底面；找恰好一面涂色的小块',
   fixedPerimeter:revision>=3?'周长不变；两边至少'+n.parameters.minSide+'，比较合法的最小面积':'周长不变；两条正偶数边，比较最大面积',
   naturalUnion:'已知至少参加一组；圈外不属于本次取样范围'
  };
  d.mathStateId=f.id+':variation';d.targetQuantityId=n.goal.id;d.statePhase=before?'before-change-with-operation':'variation-givens';
  if(captions[f.id])d.caption=captions[f.id];
  if(['natural-unionChance','natural-complementChance'].includes(f.id))d.caption=captions.naturalUnion;
  const state={...prior,math:n.parameters,normalizedModel:n.model,goal:n.goal,relations:n.conditions,quantityDomain:n.quantityDomain,expectedAnswer:n.expectedAnswer,adapterStatus:'explicit',quantityIds:Object.keys(n.parameters).map(key=>({id:f.id+':variation:'+key,key})),projection:{...prior.projection,diagram:d,diagramPhase:d.statePhase},answerContract:{kind:n.model==='whole-circle'?'exact-under-stated-assumption':'exact-rational',value:c.extension.answer,unit:n.goal.unit,allowApproximation:false,assumptions:n.parameters.pi?['pi='+n.parameters.pi]:[]}};
  const solutionFrames=(c.extension.solutionFrames||[]).map(frame=>({...frame,mathStateId:state.id,targetQuantityId:n.goal.id,scene:{...frame.scene,mathStateId:state.id,targetQuantityId:n.goal.id,statePhase:'variation-solution',...(captions[f.id]?{caption:captions[f.id]}:{})},stage:{...frame.stage,mathStateId:state.id,targetQuantityId:n.goal.id}}));
  return {...c,extension:{...c.extension,diagram:d,problemState:state,answerContract:state.answerContract,solutionFrames}};
 }
 return {describe,finalize,normalize};
})(typeof module!=='undefined'?require('./competition'):{competitionFraction},typeof module!=='undefined'?require('./problem_state'):ProblemState);
if(typeof module!=='undefined')module.exports=VariationState;
