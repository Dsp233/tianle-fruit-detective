'use strict';
const {competitionAdaptiveProfile,competitionAdaptiveTarget}=((catalog,create,valueEqual,identity)=>{
 const byId=new Map(catalog.map(f=>[f.id,f]));
 function competitionAdaptiveProfile(records,extensionRecords,topicIds,extensionViews={},mainViews={}){
  const scope=new Set(topicIds),events=[],seen=new Set(),variations=new Map(),state={attempts:records,extensions:extensionRecords,views:mainViews,extensionViews};
  for(const h of Object.values(extensionViews||{})){
   if(!h.attempted||typeof h.firstInput!=='string')continue;
   try{const t=create(h.recipe);if(h.signature===t.competition.extension.signature&&h.mainSignature===t.competition.signature){const g=identity.exposure(state,t,'extension');variations.set(h.mainSignature,g.first?.kind==='extension'&&g.cleanFirst)}}catch{}
  }
  // Retrying a variation is useful practice but never an independent first try.
  for(const a of extensionRecords||[]){
   if(a.firstAttempt!==true||variations.has(a.signature))continue;
   try{const t=create(a.recipe);if(t.competition.signature===a.signature&&a.variationSignature===t.competition.extension.signature){const g=typeof a.input==='string'?identity.exposure(state,t,'extension'):null;variations.set(a.signature,g?g.first?.kind==='extension'&&g.cleanFirst:a.correct===true)}}catch{}
  }
  const durable=[];
  for(const h of Object.values(mainViews||{})){
   const a=h.first;if(!a||a.priorSolutionViewed===true)continue;
   try{const t=create(a.recipe);if(t.competition.signature!==h.signature||!Number.isInteger(a.choice)||a.choice<0||a.choice>=5||!Number.isFinite(a.at)||a.at<=0)continue;durable.push({...a,signature:h.signature,correct:a.choice===t.answer,firstAttempt:true,firstCorrect:a.choice===t.answer&&a.hinted!==true})}catch{}
  }
  const candidates=durable.concat(records||[]).map((a,index)=>({...a,order:Number.isSafeInteger(a.order)&&a.order>0?a.order:index+1})).sort((a,b)=>a.at-b.at||a.order-b.order);
  for(const a of candidates){
   const f=byId.get(a.recipe?.familyId);if(!f||!f.topicIds.every(id=>scope.has(id)))continue;
   // Old first-correct facts are usable; unknown first failures are not invented.
   if(!(a.firstAttempt===true&&a.priorSolutionViewed!==true)&&a.firstCorrect!==true)continue;
   let t;try{t=create(a.recipe);if(t.competition.signature!==a.signature||a.correct!==(a.choice===t.answer))continue}catch{continue}
   const canonical=identity.key(t),g=identity.exposure(state,t);if(seen.has(canonical)||g.first?.kind!=='main'||g.first.signature!==a.signature||g.first.at!==a.at)continue;
   seen.add(canonical);
   const recentMethodOnly=a.correct===true&&a.strategyIndependent===false&&a.relatedMethodExposure?.recent===true&&!a.hinted&&!a.priorSolutionViewed;
   events.push({signature:a.signature,mathKey:canonical,at:a.at,topicIds:f.topicIds,structure:f.reasoningKey||f.strategy,level:f.level,clean:g.cleanFirst===true&&a.strategyIndependent===true,recentMethodOnly,transfer:variations.get(a.signature)});
  }
  const topics={};
  for(const id of topicIds){
   let band=2,stage=[],recent=[],promotions=0,demotions=0;
   for(const e of events.filter(e=>e.topicIds.includes(id))){
    recent.push(e);recent=recent.slice(-4);stage.push(e);stage=stage.slice(-8);
    const struggle=e=>!e.clean&&!e.recentMethodOnly||e.transfer===false;
    // Require two different first attempts, never two clicks on one problem.
    if(recent.filter(struggle).length>=2&&struggle(e)){
     if(band>1){band--;demotions++}recent=[];stage=[];continue;
    }
    const clean=stage.filter(e=>e.clean&&e.transfer!==false&&e.level>=band),structures=new Set(clean.map(e=>e.structure));
    const transfer=clean.some(e=>e.transfer===true),probe=clean.some(e=>e.level>band);
    if(band<3&&probe&&structures.size>=2&&clean.length>=(transfer?2:3)){
     band++;promotions++;stage=[];recent=[];
    }
   }
   const clean=stage.filter(e=>e.clean&&e.transfer!==false&&e.level>=band);
   const ready=band<3&&recent.length>=2&&recent.slice(-2).every(e=>e.clean&&e.transfer!==false&&e.level>=band);
   topics[id]={band,target:ready?band+1:band,probe:ready,firstProblems:events.filter(e=>e.topicIds.includes(id)).length,promotions,demotions,cleanRecent:clean.length};
  }
  return {topics,eventCount:events.length};
 }
 function competitionAdaptiveTarget(profile,family){
  const rows=family.topicIds.map(id=>profile.topics[id]||{band:2,target:2,probe:false});
  return {level:Math.min(...rows.map(r=>r.target)),probe:rows.every(r=>r.probe),band:Math.min(...rows.map(r=>r.band))};
 }
 return {competitionAdaptiveProfile,competitionAdaptiveTarget};
})(typeof module!=='undefined'?require('./competition_reviewed').COMPETITION_REVIEWED:COMPETITION_REVIEWED,typeof module!=='undefined'?require('./competition').competitionCreate:competitionCreate,typeof module!=='undefined'?require('./competition').competitionValueEqual:competitionValueEqual,typeof module!=='undefined'?require('./competition_identity'):CompetitionIdentity);
if(typeof module!=='undefined')module.exports={competitionAdaptiveProfile,competitionAdaptiveTarget};
