'use strict';
const CompetitionController=(()=>{
 let epoch=0;
 function invalidate(){epoch++;competitionStopCurrentSpeech()}
 function prepare(task){
  draft.work=CompetitionWork.restore(draft.work,task,{sessionId:topicSession()?.id});
  const m=draft.work.scopes.main;
  const free=task.competition.family==='threeGroupBalance'||task.competition.integrated;
  if(!free&&m.input.selectedOptionId)draft.choice=task.optionIds.indexOf(m.input.selectedOptionId);
  else if(!free&&draft.choice>=0)m.input.selectedOptionId=task.optionIds[draft.choice];
  for(const scope of Object.values(draft.work.scopes))CompetitionModelWorkspace.ensure(scope);
  reasoningState(task);learnerSketchState(task);learnerSketchState(task,CompetitionWork.variationId(task));competitionHistory(task);displayOrder(task,'options');
  const r=draft.work.reasoning;if(r){if(!m.input.raw)m.input.raw=String(r.finalInput||'');Object.defineProperty(r,'finalInput',{configurable:true,get:()=>m.input.raw,set:value=>CompetitionWork.setInput(draft.work,'main',value)})}
  const v=draft.work.scopes[CompetitionWork.variationId(task)],last=saved.competition.extensions.findLast(a=>a.signature===task.competition.signature&&a.variationSignature===competitionVariationSignature(task)&&a.input===v.input.raw);
  if(last){const checked=SubmissionContract.numeric(v.input.raw,task.competition.extension.answer);v.feedback={...checked,input:v.input.raw,variationSignature:competitionVariationSignature(task)};v.answerState=checked.ok?'correct':'incorrect'}
  if(!last&&['awaiting_input','invalid_input'].includes(v.feedback?.status))v.feedback=SubmissionContract.numeric(v.input.raw,task.competition.extension.answer);
  return draft.work;
 }
 function dispatch(command){if(command.runEpoch!==undefined&&command.runEpoch!==epoch)return {handled:true,changed:false,resultCode:'STALE_VIEW'};if(command.type==='RESET_QA'){invalidate();return {handled:true,changed:true,resultCode:'RESET'}}if(command.type==='SET_INPUT'){if(draft.work.activeScopeId!==command.scopeId)competitionStopCurrentSpeech();CompetitionWork.setInput(draft.work,command.scopeId,command.payload.raw,command.payload.optionId);return {handled:true,changed:true,resultCode:'EDITED'}}return {handled:false,changed:false,resultCode:'UNHANDLED'}}
 return {prepare,dispatch,invalidate,getEpoch:()=>epoch};
})();
