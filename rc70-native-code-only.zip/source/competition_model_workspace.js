'use strict';
// Student-authored relationships are checked structurally. A coincident number
// does not establish a relation, and unsupported notation remains an editable draft.
const CompetitionModelWorkspace=(()=>{
 const clean=x=>String(x).replace(/\s/g,'').replace(/×/g,'*').replace(/÷/g,'/').replace(/[−–]/g,'-').replace(/＝/g,'=').replace(/≥/g,'>=').replace(/≤/g,'<=');
 function parse(source){
  const text=clean(source),tokens=text.match(/\d+(?:\.\d+)?|[\p{L}_][\p{L}\p{N}_]*|>=|<=|[<>()+*/-]/gu)||[];
  if(tokens.join('')!==text||text.length>160)return null;let i=0;
  function atom(){const t=tokens[i++];if(t==='('){const n=sum();if(tokens[i++]!==')')throw Error('paren');return n}if(t==='-')return {op:'neg',items:[atom()]};if(/^\d/.test(t||''))return {op:'number',value:t};if(/^[\p{L}_]/u.test(t||''))return {op:'quantity',value:t};throw Error('token')}
  function product(){let n=atom();while(tokens[i]==='*'||tokens[i]==='/'){const op=tokens[i++];n={op,items:[n,atom()]}}return n}
  function sum(){let n=product();while(tokens[i]==='+'||tokens[i]==='-'){const op=tokens[i++];n={op,items:[n,product()]}}return n}
  try{let result=sum();if(['>=','<=','>','<'].includes(tokens[i])){const op=tokens[i++];result={op,items:[result,sum()]}}return i===tokens.length?result:null}catch{return null}
 }
 function canonical(ast){if(!ast)return null;if(ast.value!==undefined)return ast.op+':'+ast.value;let nodes=ast.items.map(canonical);if(['+','*'].includes(ast.op)){function flatten(n){return n.op===ast.op?n.items.flatMap(flatten):[canonical(n)]}nodes=ast.items.flatMap(flatten).sort()}return ast.op+'('+nodes.join(',')+')'}
 const rule=(id,left,forms,skills,deps=[])=>({id,left,forms,skills,deps});
 function contract(task,scopeId='main'){
  if(scopeId!=='main'||!task.competition.integrated)return null;
  const kind=task.competition.configurationId;
  const weighted=[rule('counts','红队人数',['总人数*2/5','2*总人数/5'],['R01.01']),rule('blue-count','蓝队人数',['总人数-红队人数','总人数*3/5'],['R01.01'],['counts'])];
  if(kind==='mean-admission')return {rules:[...weighted,rule('total','原总分',['红队人数*红队均分+蓝队人数*蓝队均分'],['D02.02'],['counts','blue-count']),rule('new-mean','新均分',['(原总分+新增人数*新增均分)/(总人数+新增人数)'],['D02.02'],['total']),rule('people','活动人数',['总人数+新增人数'],['A02.01'],['new-mean']),rule('materials','材料份数',['活动人数*4'],['A02.04'],['people']),rule('packing-enough','整包条件',['包数*8>=材料份数'],['N01.02'],['materials']),rule('packing-minimal','最少整包',['(包数-1)*8<材料份数'],['N01.02'],['packing-enough']),rule('cost','总费用',['包数*18'],['A02.04'],['materials'])],required:['total','new-mean','materials','packing-enough','packing-minimal','cost'],enumeration:true};
  if(kind==='score-training')return {rules:[...weighted,rule('red-score','红队原分',['(总人数*全体均分-蓝队人数*蓝队均分)/红队人数'],['D02.02'],['counts','blue-count']),rule('deficit','所需增分',['总人数*目标均分-总人数*全体均分','总人数*(目标均分-全体均分)'],['D02.02'],['red-score']),rule('personal','个人增分',['个人班目标分-红队原分'],['A02.01'],['red-score']),rule('group','小组增分',['3*(小组班目标分-红队原分)'],['A02.04'],['red-score']),rule('cost','总费用',['小组数*16+个人数*12'],['A02.04'],['deficit','personal','group'])],required:['red-score','deficit','personal','group','cost'],enumeration:true};
  if(kind==='length-border')return {rules:[rule('side-sum','长宽和',['周长/2'],['G01.02']),rule('width','宽',['长宽和*2/5','长宽和/5*2'],['R01.05'],['side-sum']),rule('length','长',['长宽和-宽','宽/2*3'],['R01.01'],['width']),rule('inner-length','内长',['长-2*边框宽'],['G01.03'],['length']),rule('inner-width','内宽',['宽-2*边框宽'],['G01.03'],['width']),rule('area','边框面积',['长*宽-内长*内宽'],['G01.03'],['inner-length','inner-width']),rule('tiles','砖块数',['边框面积/0.25'],['A03.04'],['area']),rule('packing-enough','整包条件',['包数*10>=砖块数'],['N01.02'],['tiles']),rule('packing-minimal','最少整包',['(包数-1)*10<砖块数'],['N01.02'],['packing-enough']),rule('cost','总费用',['包数*每包价格'],['A02.04'],['tiles'])],required:['side-sum','width','area','tiles','packing-enough','packing-minimal','cost'],enumeration:false};
  return {rules:[rule('length','长',['宽/2*3','宽*3/2'],['R01.05']),rule('perimeter','周长',['2*(长+宽)'],['G01.02'],['length']),rule('fence','围栏长度',['周长-门洞宽'],['A02.01'],['perimeter']),rule('panels','板材长度',['板数*2'],['A02.04'],['fence']),rule('panels-minimal','最少整板',['(板数-1)*2<围栏长度'],['N01.02'],['panels']),rule('panels-enough','整板条件',['板数*2>=围栏长度'],['N01.02'],['panels']),rule('purchase','板材费用',['整包数*70+单块数*15'],['A02.04'],['panels']),rule('cost','总费用',['板材费用+4*6'],['A02.04'],['purchase'])],required:['length','perimeter','fence','panels','panels-minimal','panels-enough','purchase','cost'],enumeration:true};
 }
 function ensure(scope){return scope.model??(scope.model={open:false,selectedSkillIds:[],draft:'',tableDraft:'',relations:{},candidateProof:null,events:[],feedback:null,processVerified:false})}
 function verifyRelation(task,work,scopeId,input){
  const s=ensure(work.scopes[scopeId]),definition=contract(task,scopeId),text=clean(input),equal=text.indexOf('='),parts=equal<0?[]:[text.slice(0,equal),text.slice(equal+1)],ast=parts.length===2?parse(parts[1]):null;
  if(!definition||!ast){s.feedback='草稿已保留，这段表达暂未自动核验。可以继续完善或提交最终答案。';s.processVerified=false;return false}
  const r=definition.rules.find(r=>r.left===parts[0]&&r.forms.some(f=>canonical(parse(f))===canonical(ast)));
  if(!r){const prior=definition.rules.find(node=>node.left===parts[0]);if(prior&&s.relations[prior.id]){const changed=new Set([prior.id]);for(const node of definition.rules)if(node.deps.some(id=>changed.has(id)))changed.add(node.id);for(const id of changed)if(s.relations[id])s.relations[id].status='stale';s.candidateProof=null;}s.feedback='这段数量关系已保留，暂未核验量的对应、整体与单位。';s.processVerified=false;return false}
  if(r.deps.some(id=>s.relations[id]?.status!=='verified')){s.feedback='这段关系涉及的前置量还未核验，请先确认你使用的量。';s.processVerified=false;return false}
  const invalid=new Set([r.id]);if(s.relations[r.id]?.semanticDigest!==canonical(ast)){for(const node of definition.rules)if(node.deps.some(id=>invalid.has(id)))invalid.add(node.id);for(const id of invalid)if(s.relations[id])s.relations[id].status='stale';s.candidateProof=null}
  s.relations[r.id]={input,status:'verified',providedBy:'student',quantityId:r.left,ruleId:r.id,semanticDigest:canonical(ast),usedSkillIds:r.skills,at:Date.now()};s.events.push({type:'relation-verified',ruleId:r.id,input,help:false});s.feedback='数量关系与条件一致。';assess(task,work,scopeId);return true;
 }
 function verifyCandidates(task,work,scopeId){
  const scope=work.scopes[scopeId],s=ensure(scope),m=task.competition.math,kind=task.competition.configurationId;
  if(scopeId!=='main'||!task.competition.integrated)return false;
  const entries=s.tableDraft.split(/[,，、;；\s]+/).filter(Boolean).map(x=>x.split(/[:：]/)),values=entries.map(x=>Number(x[0]));if(!values.length||entries.some(x=>!/^\d+$/.test(x[0]))||values.some(x=>!Number.isInteger(x)||x<0)||new Set(values).size!==values.length){s.feedback='保留候选草稿，请逐个填写不重复的非负整数。';return false}
  let required=[];
  if(kind==='mean-admission'){let k=0;while(k<=m.cap&&(m.total+k*m.score)<m.target*(m.N+k))k++;required=Array.from({length:k+1},(_,i)=>i)}
  else if(kind==='score-training')required=[0,1,2];
  else if(kind==='perimeter-fence')required=Array.from({length:Math.ceil(m.panels/5)+1},(_,i)=>i);
  else{s.feedback='该任务按单位面积与完整包装核对，保留你的关系和最终答案。';return false}
  if(required.some(x=>!values.includes(x))||values.some(x=>x>(kind==='mean-admission'?m.cap:kind==='score-training'?2:Math.ceil(m.panels/5)))){s.feedback='候选范围还有遗漏；检查起点、边界以及是否覆盖所有可能更优的情况。';return false}
  const results=entries.map(x=>x[1]),expected=values.map(value=>{if(kind==='mean-admission')return m.total+value*m.score>=m.target*(m.N+value)?'是':'否';if(kind==='score-training'){const personal=Math.max(0,Math.ceil((m.deficit-value*3*(m.high-10-m.low))/(m.high-m.low)));return value*3+personal<=m.red?String(value*16+personal*12):'不可行'}const singles=Math.max(0,m.panels-value*5);return String(value*70+singles*15)});
  if(results.some((x,i)=>x!==expected[i])){s.candidateProof=null;s.processVerified=false;s.feedback='候选已保留；还需逐个填写并核对该候选的达标判断或最低费用。只列候选编号不足以验证最优性。';return false}
  s.candidateProof={contractVersion:2,decisions:entries.map((x,i)=>({candidate:values[i],result:results[i],providedBy:'student'})),candidates:values,coverage:'complete',providedBy:'student',usedSkillIds:['C02.03','A01.04','N01.02'],at:Date.now()};s.feedback='候选范围完整；仍需结合已建立的关系与最终答案核对可行性和最优性。';assess(task,work,scopeId);return true;
 }
 function assess(task,work,scopeId='main',finalCorrect){
  const scope=work.scopes[scopeId],s=ensure(scope),definition=contract(task,scopeId);if(!definition){s.processVerified=false;return false}
  const complete=definition.required.every(id=>s.relations[id]?.status==='verified'),used=new Set(Object.values(s.relations).filter(r=>r.status==='verified').flatMap(r=>r.usedSkillIds));if(s.candidateProof)for(const id of s.candidateProof.usedSkillIds)used.add(id);
  const chosen=s.selectedSkillIds,tools=used.size>0&&[...used].every(id=>chosen.includes(id))&&chosen.every(id=>used.has(id));
  s.processVerified=complete&&tools&&(!definition.enumeration||s.candidateProof?.contractVersion===2)&&(finalCorrect??scope.answerState==='correct');return s.processVerified;
 }
 function panel(task,work,scopeId='main'){
  const scope=work.scopes[scopeId],s=scope.model;if(!s)return '';const e=esc,declared=new Set(topicSessionSettings().declaredSkillIds),skills=SKILL_DATA.skills.filter(k=>declared.has(k.id));
  return `<section class="model-workspace" data-scope-id="${e(scopeId)}"><button type="button" class="secondary" data-action="competitionModelToggle" data-scope="${e(scopeId)}">${s.open?'收起，保留我的工具和关系':'选择我的工具 / 写数量关系'}</button>${s.open?`<div class="model-tools">${SKILL_DATA.units.map(u=>{const available=skills.filter(k=>k.unitId===u.id);return available.length?`<details${s.selectedSkillIds.some(id=>id.startsWith(u.id+'.'))?' open':''}><summary>${e(u.title)}</summary>${available.map(k=>`<button type="button" class="secondary" data-action="competitionTool" data-scope="${e(scopeId)}" data-code="${e(k.id)}" aria-pressed="${s.selectedSkillIds.includes(k.id)}">${e(k.title)}</button>`).join('')}</details>`:''}).join('')}</div><p>先选你认为有用的已学知识，再写出量之间的关系。没有预选工具。</p><label>我的数量关系<input data-competition-input="relation" data-scope="${e(scopeId)}" maxlength="160" value="${e(s.draft)}" placeholder="量名=你建立的数量关系"></label><button type="button" class="secondary" data-action="competitionRelationCheck" data-scope="${e(scopeId)}">核对数量关系</button><ul>${Object.values(s.relations).map(r=>`<li>${e(r.input)} · ${r.status==='verified'?'关系已核验':'保留草稿，需重核'}</li>`).join('')}</ul><p>${task.competition.integrated&&scopeId==='main'?(task.competition.configurationId==='mean-admission'?'逐个记录 人数:是 或 人数:否，表示是否达到均分目标。':task.competition.configurationId==='length-border'?'核对单位面积与完整包装的数量关系。':'逐个记录 候选编号:最低费用；不可行时填写 不可行。'):'可记录自己检查过的整数候选。'}</p><label>我的候选检查表<input data-competition-input="candidates" data-scope="${e(scopeId)}" maxlength="160" value="${e(s.tableDraft)}" placeholder="候选:判断或费用，用分号分隔"></label><button type="button" class="secondary" data-action="competitionCandidatesCheck" data-scope="${e(scopeId)}">核对候选范围</button>${s.feedback?`<p role="status">${e(s.feedback)}</p>`:''}${s.processVerified?'<p role="status">工具、数量关系和目标检查均有可核验记录。</p>':''}`:''}</section>`;
 }
 return {parse,canonical,contract,ensure,verifyRelation,verifyCandidates,assess,panel};
})();
if(typeof module!=='undefined')module.exports=CompetitionModelWorkspace;
