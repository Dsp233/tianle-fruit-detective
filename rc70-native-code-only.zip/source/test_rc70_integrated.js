'use strict';
const assert=require('assert'),fs=require('fs'),path=require('path'),M=require('./competition_reviewed'),I=require('./competition_integrated'),O=require('./rc70_oracles'),P=require('./problem_state'),G=require('./reasoning_graph'),S=require('./source_catalog'),K=require('./skills.json'),W=require('./competition_work'),Model=require('./competition_model_workspace');
const rows=[],failures=[],seeds=[...Array.from({length:128},(_,i)=>i+1),129,2147483646,2147483647];
function check(caseId,fn){try{rows.push({caseId,status:'PASS',actual:fn()})}catch(e){const r={caseId,status:'FAIL',error:e.stack};rows.push(r);failures.push(r)}}
for(const f of I.catalog)for(const configurationId of f.configurations)for(const seed of seeds)check(f.id+'/'+configurationId+'/'+seed,()=>{
 const t=M.competitionCreate({engine:3,familyId:f.id,configurationId,generatorRevision:5,seed}),o=O.integrated(t);assert(P.equal(t.competition.answer,String(o.answer)));assert(P.equal(t.competition.extension.answer,String(o.extension)));assert.deepStrictEqual(G.validate(G.create(t.competition)),[]);assert(S.taskAllowed(t,{topicIds:K.units.map(u=>u.id)}).length);return o;
});
const examples=[['integratedWeightedPlan','mean-admission',324],['integratedWeightedPlan','score-training',52],['integratedRatioPlan','length-border',375],['integratedRatioPlan','perimeter-fence',294]];
for(const [familyId,configurationId,expected]of examples)check('fixed-example/'+configurationId,()=>{const t=M.competitionCreate({engine:3,familyId,configurationId,generatorRevision:5,seed:1});assert(P.equal(t.competition.answer,expected));assert.equal(O.integrated(t).answer,expected);return expected});
check('relation-parser-safe',()=>{assert.equal(Model.parse('alert(1);'),null);assert.notEqual(Model.canonical(Model.parse('人数*平均分')),Model.canonical(Model.parse('总分')));assert.equal(Model.canonical(Model.parse('人数*平均分')),Model.canonical(Model.parse('平均分*人数')));return {noEval:true,commutative:true}});
check('student-model-and-dependency',()=>{
 const t=M.competitionCreate({engine:3,familyId:'integratedWeightedPlan',configurationId:'mean-admission',generatorRevision:5,seed:1}),work=W.create(t),model=Model.ensure(work.scopes.main);
 assert(!Model.verifyRelation(t,work,'main','原总分=2160'));assert(!Model.assess(t,work,'main',true));
 const relations=['红队人数=总人数*2/5','蓝队人数=总人数-红队人数','原总分=红队人数*红队均分+蓝队人数*蓝队均分','新均分=(原总分+新增人数*新增均分)/(总人数+新增人数)','活动人数=总人数+新增人数','材料份数=活动人数*4','整包条件=包数*8>=材料份数','最少整包=(包数-1)*8<材料份数','总费用=包数*18'];
 for(const text of relations)assert(Model.verifyRelation(t,work,'main',text),text);
 model.tableDraft='0,1,2,3,4,5';assert(!Model.verifyCandidates(t,work,'main'));model.tableDraft='0,1,2,3,4,5,6';assert(Model.verifyCandidates(t,work,'main'));
 model.selectedSkillIds=['R01.01','D02.02','A02.01','A02.04','C02.03','A01.04','N01.02'];assert(Model.assess(t,work,'main',true));model.selectedSkillIds.push('G02.01');assert(!Model.assess(t,work,'main',true));model.selectedSkillIds.pop();assert(Model.assess(t,work,'main',true));
 assert(Model.verifyRelation(t,work,'main','红队人数=2*总人数/5'));assert.equal(model.relations.total.status,'verified');assert(Model.verifyRelation(t,work,'main','蓝队人数=总人数*3/5'));assert.equal(model.relations.total.status,'stale');assert.equal(model.relations['new-mean'].status,'stale');assert(!model.processVerified);return {numericGuessRejected:true,completeModelVerified:true,unrelatedToolNotCounted:true,dependentsInvalidated:true};
});
for(const seed of seeds)check('weighted-removal/'+seed,()=>{
 const t=M.competitionCreate(M.competitionReviewedRecipe('natural-weighted',seed)),c=t.competition,p=c.extension.problemState.math;assert.equal(c.extension.key,'remove-high-to-target-v2');const k=Number(c.extension.answer);assert(k>=0&&k<=p.highCount);assert((p.total-p.score*k)/(p.count-k)<=p.target+1e-12);if(k>0)assert((p.total-p.score*(k-1))/(p.count-k+1)>p.target);const old=M.competitionCreate({...c.recipe,generatorRevision:3});assert.equal(old.competition.extension.key,'swap-weights');return {minimum:k,oldReplay:true};
});
const out=process.env.AMC8_RC70_EVIDENCE||'tmp/rc70/checks';fs.mkdirSync(out,{recursive:true});const result={result:failures.length?'FAIL':'PASS',cases:rows.length,rows,failures};fs.writeFileSync(path.join(out,'integrated.json'),JSON.stringify(result,null,2)+'\n');console.log(result.result,rows.length,'cases');if(failures.length){console.log(JSON.stringify(failures.slice(0,3)));process.exitCode=1}
