'use strict';
const CompetitionContentContracts=(()=>{
 const essential=new Set(['routes','fourAreas','rectangleDiagonal','notch','lShape','cross','semicircle','ring','parallelTriangle','hypotenuseMidpoint','boxNet','bars','table','truncatedBars','pie','isoscelesExterior','scene-coordinate','scene-angleRatio']);
 const helperOnly=new Set(['exactlyOneSet','digitInsert','divisorPowers','rectanglePointAreas','telescopingDifferences','riverTravel']);
 function resolve(task,scopeId='main'){
  const c=task.competition,v=scopeId!=='main',source=v?c.extension:c,ps=source.problemState||c.problemState;
  const rawGoal=typeof ps?.goal==='object'?ps.goal:{},goal={...rawGoal,id:rawGoal.id||c.recipe.familyId+':'+(v?'variation':'main')+':'+(rawGoal.quantityId||rawGoal.targetGroup||'target'),quantityId:rawGoal.quantityId||rawGoal.targetGroup||'target',questionText:rawGoal.questionText||(v?c.extension.prompt:task.prompt),unit:rawGoal.unit||source.unit||''};
  const answerContract=ps?.answerContract||source.answerContract||{kind:'exact-rational',value:source.answer,unit:source.unit||''};const math=typeof module!=='undefined'?require('./problem_state'):ProblemState;if(!math.equal(answerContract.value,source.answer)||source.answerContract&&!math.equal(source.answerContract.value,source.answer))throw Error('SCOPE_ANSWER_CONTRACT_MISMATCH');
  return {contractVersion:1,configurationId:c.recipe.configurationId||c.recipe.familyId,scopeId,modelId:c.quality?.modelId||c.quality?.model||c.modelId||'structure-and-domain',goal,answerContract,hints:(v?(source.hints||['比较变式和主问题：已知条件、所求目标或整体发生了什么变化？','按照变式的新条件重新建立数量关系，再检查单位与边界。']):c.hints||[]).map((prompt,i)=>({id:(v?'variation':'main')+'-h'+(i+1),order:i+1,prompt,narrationText:prompt})),diagram:source.diagram||null,initialDiagramAllowed:!helperOnly.has(c.family)&&(/如图|如表|图中|表中/.test(v?source.prompt:task.prompt)||essential.has(source.diagram?.kind))};
 }
 function validate(c){if(!c.goal||!c.answerContract||!c.scopeId)throw Error('INVALID_CONTENT_CONTRACT');return true}
 return {resolve,validate};
})();
if(typeof module!=='undefined')module.exports=CompetitionContentContracts;
