'use strict';
// Mathematical aliases are reviewed explicitly. Strategy names and coincident
// answers never identify the same problem. Raw task signatures stay unchanged.
const CompetitionIdentity=((create,math)=>{
 const rules=typeof module!=='undefined'?require('./evidence_rules'):EvidenceRules;
 const cache=new WeakMap();
 const METHOD_WINDOW_MS=24*60*60*1000;
 const affinities={
  'natural-weighted':'weighted-total','natural-fractionWeighted':'weighted-total','rule-weighted-mean':'weighted-total','rule-weighted-score':'weighted-total',
  fractionBackwards:'fraction-wholes','rule-fraction-reverse':'fraction-wholes','rule-fraction-original':'fraction-wholes',
  packPrice:'whole-pack-and-single','rule-packs-exact':'whole-pack-and-single','rule-packs-enough':'whole-pack-and-single'
 };
 const methodKey=recipe=>'method-v1:'+(affinities[recipe?.familyId]||recipe?.familyId||'unknown');
 function noteMethodExposure(state,task,type,at=Date.now()){
  state.methodExposures||={};const key=methodKey(task.competition.recipe),prior=state.methodExposures[key];
  state.methodExposures[key]={key,firstAt:Math.min(prior?.firstAt||at,at),lastAt:Math.max(prior?.lastAt||at,at),types:[...new Set([...(prior?.types||[]),type])].slice(-20),recipe:task.competition.recipe,exactTimestamp:true};
 }
 function methodContext(state,task,now=Date.now()){
  const key=methodKey(task.competition.recipe),times=[],bounds=[],sources=[],stored=state.methodExposures?.[key];let estimated=false;
  if(stored){times.push(stored.lastAt);sources.push('method-exposure-log');estimated||=stored.exactTimestamp!==true}
  for(const e of state.events||[])if(e.help&&e.recipe&&methodKey(e.recipe)===key&&Number.isFinite(e.at)&&e.at<=now){times.push(e.at);sources.push(e.type)}
  // A legacy opening time is not the time help was seen. The first RC68
  // observation supplies an upper bound, never a fabricated exposure time.
  for(const h of [...Object.values(state.views||{}),...Object.values(state.extensionViews||{})]){
   let recipe=h.recipe;try{recipe||={familyId:JSON.parse(h.signature).family}}catch{}
   if(!recipe||methodKey(recipe)!==key||!(h.hinted||h.solutionViewed||h.priorSolutionViewed))continue;
   const precise=[h.hinted&&h.hintedAt,(h.solutionViewed||h.priorSolutionViewed)&&h.solutionViewedAt].filter(t=>Number.isFinite(t)&&t>0&&t<=now);
   times.push(...precise);sources.push('historical-view');
   if(h.hinted&&!h.hintedAt||(h.solutionViewed||h.priorSolutionViewed)&&!h.solutionViewedAt){estimated=true;const upper=state.methodHistoryObservedAt;if(Number.isFinite(upper)&&upper>0&&upper<=now)bounds.push(upper);else bounds.push(now)}
  }
  const valid=times.filter(t=>Number.isFinite(t)&&t>0&&t<=now),lastAt=valid.length?Math.max(...valid):null;
  const recentExact=lastAt!==null&&now-lastAt<METHOD_WINDOW_MS,upperBound=bounds.length?Math.max(...bounds):null,possiblyRecent=upperBound!==null&&now-upperBound<METHOD_WINDOW_MS;
  return {affinityId:key,everExposed:lastAt!==null||bounds.length>0,lastAt,elapsedMs:lastAt===null?null:now-lastAt,recent:recentExact||possiblyRecent,recentStatus:recentExact?'known_recent':possiblyRecent?'possibly_recent':lastAt!==null||bounds.length?'outside_window':'none',windowMs:METHOD_WINDOW_MS,timestampEstimated:estimated,unknownTimestampUpperBound:upperBound,sources:[...new Set(sources)]};
 }
 const integer=v=>{const n=Number(v);if(!Number.isSafeInteger(n))throw Error('Unsafe identity quantity');return n};
 function fraction(variant,params,domain){
  const p={d1:integer(params.d1),d2:integer(params.d2)};
  p[variant==='fraction-reverse'?'left':'start']=integer(params[variant==='fraction-reverse'?'left':'start']);
  return 'math-v1:'+JSON.stringify({model:'fraction-wholes',domain,variant,params:p});
 }
 function purchase(variant,params){
  const p={};for(const key of ['size','single','pack','count'])p[key]=integer(params[key]);
  return 'math-v1:'+JSON.stringify({model:'finite-purchase',domain:'count-items/yuan',variant,params:p});
 }
 function semantic(family,math,kind='main',context=null){
  if(family==='fractionBackwards')return fraction(kind==='main'?'fraction-reverse':'fraction-original',{d1:2,d2:3,left:math.left,start:3*integer(math.left)},'count-items');
  if(family==='packPrice')return purchase(kind==='main'?'packs-exact':'packs-enough',{...math,size:3});
  const variant=math.variant,p=math.params;
  if(family.startsWith('rule-')&&p){
   if(['packs-exact','packs-enough'].includes(variant))return purchase(variant,p);
   if(['fraction-reverse','fraction-original'].includes(variant)){
    const domain=context==='supplies'?'count-items':context==='water'?'volume-litre':math.quantityDomain;
    if(domain)return fraction(variant,p,domain);
   }
  }
  return null;
 }
 function key(task,kind='main'){
  const c=task.competition,m=kind==='main'?c.math:c.extension.math;
  try{return semantic(c.family,m||c.math,kind,m?.context)||'signature:'+(kind==='main'?c.signature:c.extension.signature)}catch{return 'signature:'+(kind==='main'?c.signature:c.extension.signature)}
 }
 function signatureKey(signature){
  try{const s=JSON.parse(signature);if(s.family&&s.math)return semantic(s.family,s.math)||'signature:'+signature}catch{}
  return 'signature:'+signature;
 }
 function uncertainKeys(signature){
  // RC65 omitted both unit domain and recipe on help-only new-rule views.
  // Keep that uncertainty; block an unsupported fresh first opportunity without
  // asserting which domain was actually seen or merging their solved counts.
  try{const s=JSON.parse(signature),m=s.math;if(s.family?.startsWith('rule-fraction-')&&m?.params&&!m.quantityDomain)return ['count-items','volume-litre'].map(d=>fraction(m.variant,m.params,d))}catch{}
  return [];
 }
 const earlier=(a,b)=>a.at-b.at||(a.order||0)-(b.order||0)||(a.correct===true?1:0)-(b.correct===true?1:0);
 function index(state){
  const cached=cache.get(state);if(cached&&cached.attempts===state.attempts&&cached.extensions===state.extensions&&cached.views===state.views&&cached.extensionViews===state.extensionViews&&cached.sequence===state.sequence&&cached.attemptCount===(state.attempts||[]).length&&cached.extensionCount===(state.extensions||[]).length&&cached.viewCount===Object.keys(state.views||{}).length)return cached.groups;
  const groups=new Map(),tasks=new Map(),add=(k)=>{if(!groups.has(k))groups.set(k,{key:k,attempted:false,hinted:false,solutionViewed:false,first:null,unknown:[],solvedMain:false,solvedExtension:false,firstCandidates:[]});return groups.get(k)};
  function task(recipe,signature,kind){
   if(!recipe)return null;const rk=JSON.stringify(recipe),t=tasks.has(rk)?tasks.get(rk):(()=>{try{return create(recipe)}catch{return null}})();tasks.set(rk,t);
   return t&&(kind==='main'?t.competition.signature:t.competition.extension.signature)===signature?t:null;
  }
  function first(g,s){g.firstCandidates.push(s);if(!g.first||earlier(s,g.first)<0)g.first=s}
  function mainSnapshot(t,s){
   if(!s||!Number.isFinite(s.at)||s.at<=0||(!(s.inputMode==='free'&&typeof s.freeInput==='string')&&(!Number.isInteger(s.choice)||s.choice<0||s.choice>=5)))return null;
   return {...s,kind:'main',independenceStatus:rules.known(s.evidenceVersion)?'known':'unknown',signature:t.competition.signature,recipe:t.competition.recipe,correct:s.inputMode==='free'?math.equal(s.freeInput,t.competition.answer):s.choice===t.answer,independent:s.independent!==false};
  }
  for(const h of Object.values(state.views||{})){
   const t=task(h.recipe,h.signature,'main')||task(h.first?.recipe,h.signature,'main')||task(h.last?.recipe,h.signature,'main')||task(h.solved?.recipe,h.signature,'main')||task((state.attempts||[]).find(a=>a.signature===h.signature)?.recipe,h.signature,'main');
   if(!t&&(h.attempted||h.hinted||h.solutionViewed))for(const possible of uncertainKeys(h.signature)){const g=add(possible);g.uncertain=true;g.unknown.push({at:h.at,order:0})}
   const g=add(t?key(t):signatureKey(h.signature));g.hinted||=h.hinted===true;g.solutionViewed||=h.solutionViewed===true;g.attempted||=h.attempted===true;
   const f=t?mainSnapshot(t,h.first):null,solved=t?mainSnapshot(t,h.solved):null;
   if(f){first(g,f);g.attempted=true}
   if(solved?.correct||f?.correct){g.solvedMain=true}
   if(!f&&(h.attempted||h.hinted||h.solutionViewed))g.unknown.push({at:h.hintedAt||h.at,order:h.hintOrder||0,attempted:h.attempted===true,helped:h.hinted===true||h.solutionViewed===true});
  }
  for(const a of state.attempts||[]){
   const t=task(a.recipe,a.signature,'main'),s=t?mainSnapshot(t,a):null;if(!s)continue;
   const g=add(key(t));g.attempted=true;g.hinted||=a.hinted===true;g.solutionViewed||=a.priorSolutionViewed===true;g.solvedMain||=s.correct;
   if(a.firstAttempt===true||a.firstCorrect===true)first(g,s);
  }
  for(const h of Object.values(state.extensionViews||{})){
   const t=task(h.recipe,h.signature,'extension')||task(h.solved?.recipe,h.signature,'extension'),g=add(t?key(t,'extension'):'signature:'+h.signature);g.attempted||=h.attempted===true;
   if(t&&typeof h.firstInput==='string'){
    const correct=rules.known(h.evidenceVersion)?math.equal(h.firstInput,t.competition.extension.answer):valueEqual(h.firstInput,t.competition.extension.answer);
    first(g,{kind:'extension',recipe:t.competition.recipe,signature:h.signature,at:h.at,order:h.order||0,correct,independent:h.firstIndependent!==false&&h.independenceStatus!=='unknown',relatedMainSolutionViewed:h.relatedMainSolutionViewed===true,hinted:h.hinted===true,priorSolutionViewed:h.priorSolutionViewed===true,input:h.firstInput});
    g.solvedExtension||=correct;g.solutionViewed||=correct;
   }else if(h.attempted)g.unknown.push({at:h.at,attempted:true});
   if(t&&h.solved&&((rules.known(h.solved.evidenceVersion)||rules.known(h.evidenceVersion))?math.equal(h.solved.input,t.competition.extension.answer):valueEqual(h.solved.input,t.competition.extension.answer))){g.solvedExtension=true;g.solutionViewed=true}
  }
  for(const a of state.extensions||[]){
   const t=task(a.recipe,a.variationSignature,'extension');if(!t||typeof a.input!=='string')continue;
   const g=add(key(t,'extension')),correct=rules.known(a.evidenceVersion)?math.equal(a.input,t.competition.extension.answer):valueEqual(a.input,t.competition.extension.answer);g.attempted=true;g.solvedExtension||=correct;g.solutionViewed||=correct;
   if(a.firstAttempt===true)first(g,{...a,kind:'extension',correct,independent:rules.known(a.evidenceVersion)?a.independent===true:undefined,independenceStatus:rules.known(a.evidenceVersion)?'known':'unknown'});
  }
  for(const g of groups.values())g.cleanFirst=!!g.first&&g.first.correct&&g.first.independenceStatus!=='unknown'&&(g.first.kind==='extension'?g.first.independent===true:g.first.independent!==false)&&!g.first.hinted&&!g.first.priorSolutionViewed&&!g.first.relatedMainSolutionViewed&&!g.unknown.some(u=>!Number.isFinite(u.at)||earlier(u,g.first)<=0);
  cache.set(state,{groups,attempts:state.attempts,extensions:state.extensions,views:state.views,extensionViews:state.extensionViews,sequence:state.sequence,attemptCount:(state.attempts||[]).length,extensionCount:(state.extensions||[]).length,viewCount:Object.keys(state.views||{}).length});return groups;
 }
 function valueEqual(a,b){const n=s=>{const p=String(s).trim().split('/').map(Number);return p.length===1?p[0]:p.length===2&&p[1]!==0?p[0]/p[1]:NaN};return Number.isFinite(n(a))&&Math.abs(n(a)-n(b))<1e-10}
 function exposure(state,task,kind='main'){const groups=index(state),own=groups.get(key(task,kind))||{attempted:false,hinted:false,solutionViewed:false,first:null,cleanFirst:false},relatedMethod=methodContext(state,task);if(kind!=='extension')return {...own,relatedMethod};const main=groups.get(key(task)),events=(state.events||[]).filter(e=>e.signature===task.competition.signature&&e.type==='solution-main');return {...own,relatedMethod,relatedMainSolutionViewed:main?.solutionViewed===true||events.length>0,relatedSolutionAt:events.at(-1)?.at||null}}
 function counts(state){const g=[...index(state).values()];return {solved:g.filter(x=>x.solvedMain).length,first:g.filter(x=>x.solvedMain&&x.first?.kind==='main'&&x.cleanFirst).length,extensions:g.filter(x=>x.solvedExtension).length}}
 return {key,signatureKey,index,exposure,counts,methodKey,methodContext,noteMethodExposure,METHOD_WINDOW_MS,invalidate:state=>cache.delete(state)};
})(typeof module!=='undefined'?require('./competition').competitionCreate:competitionCreate,typeof module!=='undefined'?require('./problem_state'):ProblemState);
if(typeof module!=='undefined')module.exports=CompetitionIdentity;
