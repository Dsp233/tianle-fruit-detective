"""Resource-bounded parallel RC70 gates, with durable retry and resume state."""
import argparse, concurrent.futures, fcntl, hashlib, json, os, pathlib, random, re, shutil, signal, sqlite3, subprocess, sys, time
from gate_resources import snapshot, task_budget, worker_limit, retry_delay, oom_kills

CORE = ['audit_rc67_muse_v2','test_rc68_coverage','test_rc68_history','test_rc68_holdout','test_rc68_muse','test_rc68_normal_entry','test_rc68_reasoning','test_rc68_sources','test_rc68_state','test_rc69_acceptance','test_rc69_cohort_four_routes','test_rc69_cohort_three_routes','test_rc69_curriculum_scope','test_rc69_education','test_rc69_final_routes','test_rc69_profiles','test_rc69_records','test_rc69_sketch','test_rc69_skill_routes','test_rc69_stage_skill_routes','test_rc69_teaching_paths','test_rc70_work','test_rc70_integrated','test_rc70_feedback','test_rc70_acceptance','test_rc71_sketch_semantics','test_rc72_protection']

def sha(data):return hashlib.sha256(data).hexdigest()

CORE += ['test_rc73_diagram_contract','test_rc73_session_contract','test_rc73_export_scopes','test_rc73_selection']

def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');tmp.replace(path)

def make_plan(manifest):
    identity=json.loads(manifest.read_text());payload={k:v for k,v in identity.items() if k!='buildId'}
    assert sha(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==identity['buildId'],'Candidate identity payload mismatch'
    for name,h in {**identity['files'],**identity.get('fixtures',{})}.items():assert sha((manifest.parent/name).read_bytes())==h,'Candidate bytes changed: '+name
    source=sorted(p for p in (manifest.parent/'source').iterdir() if p.suffix in {'.js','.json','.py','.css','.html'} and p.name!='index.html')
    assert sha('\n'.join(p.name+':'+sha(p.read_bytes()) for p in source).encode())==identity['sourceTreeHash'],'Candidate source changed'
    tasks=[{'caseId':'core/'+name,'script':'source/'+name+'.js','kind':'cpu','gate':'development','owner':'developer'} for name in CORE]
    tasks.append({'caseId':'core/test_rc73_runner_resources','script':'source/test_rc73_runner_resources.py','runtime':'python','kind':'cpu','gate':'development','owner':'developer'})
    for task in tasks:
        if task['caseId']=='core/test_rc68_muse':task['dependsOn']=['core/test_rc68_sources','core/test_rc68_history','core/test_rc68_coverage','core/test_rc68_reasoning']
    tasks += [{'caseId':'matrix/shard-'+str(i),'script':'source/test_rc70_matrix.js','kind':'cpu','gate':'development','owner':'developer','shard':i,'shards':4} for i in range(4)]
    tasks += [{'caseId':'browser/shard-'+str(i),'script':'source/test_rc70_browser.js','kind':'browser','gate':'development','owner':'developer','shard':i,'shards':4} for i in range(4)]
    for task in tasks:task.setdefault('runtime','node')
    definition={'buildId':identity['buildId'],'tasks':tasks}
    return {**definition,'testDefinitionHash':sha(json.dumps(definition,sort_keys=True,separators=(',',':')).encode()),'manifestPath':str(manifest.resolve()),'candidateDir':str(manifest.parent.resolve()),'independentAcceptance':'INDEPENDENT_PENDING'}

def resource_limit(kind='cpu',resources=None,reserved_bytes=0):
    return worker_limit(kind,resources,reserved_bytes)

def classify(code,log):
    if code==0:return 'PASS',None
    if code in [-9,137,-6] and any(s in log for s in ['heap out of memory','Out of memory','Killed','OOM']):return 'BLOCKED','INFRA'
    if any(s in log for s in ['EAGAIN','EMFILE','EADDRINUSE','EPERM','EACCES','ERR_BLOCKED_BY_LOCAL_NETWORK_ACCESS_CHECKS','429 Too Many Requests','rate limit exceeded']):return 'BLOCKED','INFRA'
    if 'BROWSER_UNAVAILABLE' in log:return 'BLOCKED','MISSING_EVIDENCE'
    if code in [-9,137,-6,-5,133,124] or 'SIGTRAP' in log or 'TimeoutError' in log:return 'BLOCKED','UNKNOWN'
    return 'FAIL','PRODUCT'

def execute(task,attempt,plan,run):
    folder=run/'cases'/task['caseId']/('attempt-'+str(attempt));folder.mkdir(parents=True,exist_ok=True)
    candidate=pathlib.Path(plan['candidateDir']);env={**os.environ,'AMC8_RC68_FROZEN_IDENTITY':str(candidate/'frozen-identity.json'),
        'AMC8_RC69_EVIDENCE':str(folder/'legacy'),'AMC8_RC68_EVIDENCE':str(folder/'legacy'),'AMC8_RC70_EVIDENCE':str(folder/'evidence'),
        'AMC8_MUSE_AUDIT_OUTPUT':str(folder/'legacy/audit'),'AMC8_RC69_HISTORY_BASELINE':str(candidate/'docs/evidence/rc69/baseline/cab77e6-qa.html'),
        'AMC8_RC70_CANDIDATE':str(candidate),'AMC8_RC70_SHARD':str(task.get('shard',0)),'AMC8_RC70_SHARDS':str(task.get('shards',1))}
    reports={'core/test_rc68_sources':'sources/acceptance.json','core/test_rc68_history':'history/compatibility.json','core/test_rc68_coverage':'coverage/reasoning.json','core/test_rc68_reasoning':'prototype/reasoning.json'}
    for dependency in task.get('dependsOn',[]):
        attempts=sorted((run/'cases'/dependency).glob('attempt-*'),key=lambda p:int(p.name.split('-')[-1]))
        if attempts and dependency in reports:
            source=attempts[-1]/'legacy'/reports[dependency]
            if source.exists():target=folder/'legacy'/reports[dependency];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    started=time.time();logfile=folder/'stdout.log';before_oom=oom_kills()
    command=[sys.executable,task['script']] if task.get('runtime')=='python' else ['node','--max-old-space-size=768',task['script']]
    with logfile.open('w') as log:
        process=subprocess.Popen(command,cwd=candidate,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:code=process.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            try:os.killpg(process.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                process.wait()
            code=124;log.write('\nUNCLASSIFIED_TASK_TIMEOUT\n')
    log=logfile.read_text(errors='replace');status,kind=classify(code,log)
    after_oom=oom_kills()
    if code in [-9,137] and before_oom is not None and after_oom is not None and after_oom>before_oom:status,kind='BLOCKED','INFRA'
    if code:print(task['caseId']+' failure output: '+log[-6000:],flush=True)
    if code==124:status,kind='BLOCKED','UNKNOWN'
    artifacts=[{'path':str(p.relative_to(run)),'sha256':sha(p.read_bytes()),'kind':p.suffix.lstrip('.') or 'file'} for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='result.json']
    result={'schema':1,'buildId':plan['buildId'],'testDefinitionHash':plan['testDefinitionHash'],'caseId':task['caseId'],'attempt':attempt,
            'owner':'developer','gate':'development','status':status,'failureClass':kind,'exitCode':code,'artifacts':artifacts,
            'startedAt':started,'finishedAt':time.time(),'environment':{'runtime':task.get('runtime','node'),'node':subprocess.check_output(['node','--version'],text=True).strip(),'ciRunId':os.environ.get('GITHUB_RUN_ID'),'oomKillsBefore':before_oom,'oomKillsAfter':after_oom}}
    retry_after=re.search(r'Retry-After:\s*(\d+)',log,re.I)
    if retry_after:result['retryAfterSeconds']=int(retry_after.group(1))
    write_json(folder/'result.json',result);return result

def run_plan(plan,run,only='all',workers='auto-max',delays=(30,120,300),case_filter=None):
    run.mkdir(parents=True,exist_ok=True)
    coordinator=(run/'coordinator.lock').open('a+')
    try:fcntl.flock(coordinator,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise RuntimeError('Another coordinator owns this run; use its progress instead of starting a duplicate')
    existing=run/'plan.json'
    if existing.exists() and json.loads(existing.read_text())['testDefinitionHash']!=plan['testDefinitionHash']:raise RuntimeError('Resume definition mismatch')
    write_json(existing,plan);db=sqlite3.connect(run/'run-state.sqlite');db.execute('pragma journal_mode=WAL')
    db.execute('create table if not exists tasks (id text primary key,status text,attempt integer,notBefore real,leaseUntil real,failureClass text)')
    selected=[t for t in plan['tasks'] if (only=='all' or only=='retryable' or t['kind']==only) and (not case_filter or t['caseId']==case_filter)]
    for task in selected:db.execute('insert or ignore into tasks values (?,?,?,?,?,?)',(task['caseId'],'QUEUED',0,0,0,None))
    for case_id,n in db.execute("select id,attempt from tasks where status='RUNNING'").fetchall():
        result=run/'cases'/case_id/('attempt-'+str(n))/'result.json'
        if result.exists():
            r=json.loads(result.read_text());assert r['buildId']==plan['buildId'] and r['testDefinitionHash']==plan['testDefinitionHash']
            retry=r['failureClass']=='INFRA' and n<=len(delays)
            not_before=max(time.time(),r['finishedAt']+max(delays[n-1],r.get('retryAfterSeconds',0))) if retry else 0
            db.execute("update tasks set status=?,failureClass=?,notBefore=?,leaseUntil=0 where id=?",('WAIT_RETRY' if retry else 'DONE',r['failureClass'],not_before,case_id))
        else:
            folder=result.parent;folder.mkdir(parents=True,exist_ok=True)
            marker=folder/'interruption.json';write_json(marker,{'reason':'Execution interrupted before a durable result; original attempt retained','detectedAt':time.time()})
            artifacts=[{'path':str(p.relative_to(run)),'sha256':sha(p.read_bytes()),'kind':p.suffix.lstrip('.') or 'file'} for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='result.json']
            interrupted={'schema':1,'buildId':plan['buildId'],'testDefinitionHash':plan['testDefinitionHash'],'caseId':case_id,'attempt':n,'owner':'developer','gate':'development','status':'BLOCKED','failureClass':'UNKNOWN','exitCode':None,'startedAt':None,'finishedAt':time.time(),'artifacts':artifacts}
            write_json(result,interrupted);db.execute("update tasks set status='DONE',failureClass='UNKNOWN',leaseUntil=0 where id=?",(case_id,))
    db.commit()
    tasks={t['caseId']:t for t in selected};maximum=min(snapshot()['cpus'],len(selected)) if workers=='auto-max' else min(max(1,int(workers)),snapshot()['cpus'],len(selected));current=max(1,maximum)
    write_json(run/'resources.json',{'maximumWorkers':min(maximum,resource_limit('browser' if only=='browser' else 'cpu')),'resourceRule':'cgroup remaining memory, kind-specific process-tree budget and in-flight reservation','cpuTaskBytes':task_budget('cpu'),'browserTaskBytes':task_budget('browser'),'only':only,**snapshot()})
    inflight={};completed_window=[];resource_wait_since=None;resource_blocked=False
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,maximum)) as pool:
        while True:
            ready=db.execute("select id,attempt from tasks where status in ('QUEUED','WAIT_RETRY') and notBefore<=? order by id",(time.time(),)).fetchall()
            for case_id,n in ready:
                if len(inflight)>=current:break
                if case_id not in tasks:continue
                if only=='retryable' and n==0:continue
                reserved=sum(task_budget(tasks[v]['kind']) for v in inflight.values())
                if resource_limit(tasks[case_id]['kind'],reserved_bytes=reserved)==0:continue
                dependencies=tasks[case_id].get('dependsOn',[])
                if any(db.execute('select status from tasks where id=?',(d,)).fetchone() not in [('DONE',),('BLOCKED',)] for d in dependencies):continue
                n+=1;db.execute("update tasks set status='RUNNING',attempt=?,leaseUntil=? where id=?",(n,time.time()+1900,case_id));db.commit()
                inflight[pool.submit(execute,tasks[case_id],n,plan,run)]=case_id
                resource_wait_since=None
            if not inflight:
                pending=[r for r in db.execute("select id,status,notBefore,attempt from tasks where status in ('QUEUED','WAIT_RETRY','RUNNING')").fetchall() if r[0] in tasks and (only!='retryable' or r[3]>0)]
                if not pending:break
                if any(row[2]<=time.time() for row in pending):
                    if resource_wait_since is None:resource_wait_since=time.time()
                    if time.time()-resource_wait_since>=int(os.environ.get('AMC8_RESOURCE_WAIT_SECONDS','60')):
                        resource_blocked=True;write_json(run/'resource-blocked.json',{'status':'BLOCKED','reason':'NO_ADMISSIBLE_TASK_OR_RESOURCE','tasks':pending,**snapshot()});break
                else:resource_wait_since=None
                time.sleep(min(1,max(.05,min(r[2] for r in pending)-time.time())));continue
            done,_=concurrent.futures.wait(inflight,timeout=1,return_when=concurrent.futures.FIRST_COMPLETED)
            for future in done:
                case_id=inflight.pop(future)
                try:r=future.result()
                except Exception as error:
                    db.execute("update tasks set status='BLOCKED',failureClass='UNKNOWN' where id=?",(case_id,));db.commit();print(case_id,'BLOCKED',str(error),flush=True);continue
                retry=r['failureClass']=='INFRA' and r['attempt']<=len(delays)
                delay=retry_delay(r['attempt'],delays,r.get('retryAfterSeconds',0)) if retry else 0
                not_before=time.time()+delay if retry else 0
                db.execute('update tasks set status=?,notBefore=?,leaseUntil=0,failureClass=? where id=?',('WAIT_RETRY' if retry else 'DONE',not_before,r['failureClass'],case_id));db.commit()
                if r['failureClass']=='INFRA':current=max(1,current//2)
                completed_window.append(r['failureClass'])
                if len(completed_window)>=20:
                    if 'INFRA' not in completed_window:current=min(maximum,current+1)
                    completed_window=[]
                print(json.dumps({'caseId':case_id,'attempt':r['attempt'],'status':r['status'],'failureClass':r['failureClass'],'retryScheduled':retry,'workers':current}),flush=True)
    state=[dict(zip(['caseId','status','attempt','notBefore','leaseUntil','failureClass'],row)) for row in db.execute('select * from tasks')];write_json(run/'run-summary.json',{'buildId':plan['buildId'],'tasks':state,'independentAcceptance':'INDEPENDENT_PENDING'});db.close();coordinator.close()
    observed=[r for r in state if r['caseId'] in tasks and r['attempt']>0]
    return 1 if any(r['failureClass']=='PRODUCT' for r in observed) else 2 if resource_blocked or any(r['failureClass'] for r in observed) else 0

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('plan');a.add_argument('--manifest',type=pathlib.Path,required=True);a.add_argument('--out',type=pathlib.Path,required=True);a.add_argument('--gate',default='development');a.add_argument('--dry-run',action='store_true')
    for name in ['run','resume']:
        a=sub.add_parser(name);a.add_argument('--plan',type=pathlib.Path);a.add_argument('--run-dir',type=pathlib.Path,required=True);a.add_argument('--workers',default='auto-max');a.add_argument('--case-id');a.add_argument('--only',choices=['all','cpu','browser','retryable'],default='all');a.add_argument('--retry-delays',default='30,120,300');a.add_argument('--dry-run',action='store_true')
    a=p.parse_args()
    if a.command=='plan':
        plan=make_plan(a.manifest)
        if a.dry_run:print(json.dumps(plan,ensure_ascii=False,indent=2))
        else:write_json(a.out,plan);print(a.out)
    else:
        plan=json.loads((a.plan or a.run_dir/'plan.json').read_text());run=a.run_dir.resolve()
        if a.dry_run:print(json.dumps({'run':str(run),'tasks':len(plan['tasks']),'maximumWorkers':resource_limit()}))
        else:raise SystemExit(run_plan(plan,run,a.only,a.workers,tuple(map(int,a.retry_delays.split(','))),a.case_id))

if __name__=='__main__':main()
