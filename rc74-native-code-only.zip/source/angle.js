'use strict';
const ANGLE_TASKS={
 'G02.01':{kind:'arms',target:60,lengths:[95,110],context:'转出同顶点两射线',prompt:'从重合的两射线开始，把AC转到与AB成60°，实际选出从A出发的两条角边；BC连接线不是角边。',explain:'角的两边是同顶点A出发的AB、AC射线；转动决定张角，BC不是从A出发的角边。',reason:{prompt:'为什么BC不是∠BAC的角边？',options:['它没有从顶点A出发','它看起来更短','只要连着两个点就是角边'],answer:0}},
 'G02.02':{kind:'turn',targets:[180,360],context:'平角与周角的实际转动',prompt:'两张转动盘分别从0°开始。实际转出半圈180°和整圈360°，保留每一步；整圈回到原方向但转过的量不是0。',explain:'半圈180°是平角，整圈360°是周角；末方向相同不能抹掉整圈转动。',reason:{prompt:'整圈回到原方向为什么仍是360°？',options:['记录的是实际扫过的整圈转角','只看末方向，所以一定0°','平角和周角都是180°'],answer:0}},
 'G02.03':{kind:'triangle',angles:[50,60,70],unknown:2,context:'把三个角片拼成平角',prompt:'三角形A角50°、B角60°。把三个实际角片依次移到同一个点旁拼成平角，再调出C角的度数。',explain:'三个内角拼成180°；C＝180－50－60＝70°。',reason:{prompt:'三个角片拼成什么？',options:['同一个点上的平角180°','一整圈360°','只把前两个角相加就结束'],answer:0}},
 'G02.04':{kind:'polygon',sides:5,anchor:0,rotation:0,context:'实际分割凸五边形',prompt:'从顶点A实际画有效对角线，把凸五边形分成不重叠三角形。再数三角形数量并给出内角总和。',explain:'A连C、D分成3个三角形，内角总和3×180＝540°。',reason:{prompt:'为什么不是5×180°？',options:['要数实际分出的3个三角形','有5条边就有5个三角形','只要画一条线就总是360°'],answer:0}},
 'G02.05':{kind:'conditions',angles:[30,60,90],unknown:1,context:'先读标记再求角',prompt:'先实际点读题图的已知角和直角标记，排除“边看起来长”的猜测。再把三个角片拼成平角，调出未知B角。',explain:'A标30°、C有直角标记90°，所以B＝60°；不能按视觉边长猜角。',reason:{prompt:'求B需要哪两个已知条件？',options:['A的30°和C的直角标记','边AB看起来最长','B已经标成直角'],answer:0}}
};
for(const [skillId,t] of Object.entries(ANGLE_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:41,mode:'angleLab',phase:'练',hint:'角看转动和同一顶点，不看边长；三角形拼平角，凸多边形实际分成三角形；先读标记。'});
if(typeof module!=='undefined')module.exports={ANGLE_TASKS};
