'use strict';
const ANGLE_CASES={
 'G02.01':[
  [{kind:'arms',target:60,lengths:[105,95],mustResize:true,context:'改长度不改角'},'转出60°的AB、AC两射线，再实际改变两条角边长度；选择真正角边，核对张角不变。','长度改变，张角仍60°；BC不是角边。','改变角边长度而保持转角，不能按线长判断角度'],
  [{kind:'arms',target:90,lengths:[95,105],context:'独立转直角'},'独立把AC转成与AB成90°，并选同顶点A的两个角边。','AB与AC构成90°直角。','无提示：转角90°'],
  [{kind:'arms',target:120,lengths:[100,110],context:'隔日钝角'},'隔日实际转出120°并选同顶点两射线。','120°，两边是AB、AC。','隔日：钝角'],
  [{kind:'arms',target:45,lengths:[90,105],context:'四十五度'},'独立实际转出45°并选择∠BAC的两条角边。','45°，不把BC连接线当角边。','备用：较小锐角']
 ],
 'G02.02':[
  [{kind:'turn',targets:[90,180,360],context:'四分之一、半圈和整圈'},'三张盘实际分别转90°、180°和360°，保留每一步，比较末方向与转过的量。','四分之一圈90、半圈180、整圈360。','增加四分之一圈比较，不能仅看末方向'],
  [{kind:'turn',targets:[360,180],context:'顺序交换的转盘'},'独立把第一盘实际转整圈360°，第二盘转半圈180°。','第一盘周角，第二盘平角。','无提示：任务顺序交换'],
  [{kind:'turn',targets:[180,90],context:'隔日两种转动'},'隔日实际把两盘分别转半圈180°和四分之一圈90°。','180平角，90直角。','隔日：半圈与四分之一圈'],
  [{kind:'turn',targets:[270,360],context:'备用三四分之一圈整圈'},'独立实际转出270°与360°并保留完整路径。','270°是四分之三圈、360°是一整圈。','备用：整圈不能当0']
 ],
 'G02.03':[
  [{kind:'triangle',angles:[40,65,75],unknown:1,context:'已知角位置改变'},'A标40°、C标75°。实际移动三个角片拼平角，再调出未知B角。','B＝65°。','已知从A/B改为A/C，未知角位置改变'],
  [{kind:'triangle',angles:[55,65,60],unknown:2,context:'独立拼三角'},'独立把A55°、B65°、未知C三个角片拼平角，再给C度数。','C60°。','无提示：两已知角改变'],
  [{kind:'triangle',angles:[30,80,70],unknown:0,context:'隔日未知A'},'隔日B80°、C70°，实际拼角再调出A。','A30°。','隔日：未知角转为A'],
  [{kind:'triangle',angles:[45,60,75],unknown:2,context:'备用三角形'},'独立把三角形A45°、B60°的三个角片拼成平角，调出未知C。','C75°。','备用：未知75°']
 ],
 'G02.04':[
  [{kind:'polygon',sides:6,anchor:1,rotation:25,context:'旋转凸六边形'},'从指定顶点B实际画对角线，把旋转的凸六边形分成不重叠三角形，再数数量与角和。','4个三角形，总720°。','五边换六边，锚点改B并旋转图形'],
  [{kind:'polygon',sides:4,anchor:0,rotation:15,context:'凸四边形'},'独立从A画有效对角线拆凸四边形，数三角形并给内角总和。','2个三角形，总360°。','无提示：四边形'],
  [{kind:'polygon',sides:7,anchor:2,rotation:10,context:'隔日凸七边形'},'隔日从C实际分割凸七边形，再数三角形与角和。','5个三角形，总900°。','隔日：指定C，七条边'],
  [{kind:'polygon',sides:6,anchor:0,rotation:0,context:'备用凸六边形'},'独立从A实际分割凸六边形，数三角形并给角和。','4个三角形，总720°。','备用：锚点A']
 ],
 'G02.05':[
  [{kind:'conditions',angles:[50,40,90],unknown:0,context:'未知A的条件读取'},'先实际点读B的40°与C的直角标记，再拼三个角片成平角并给未知A。','A50°。','已知角与未知角位置交换'],
  [{kind:'conditions',angles:[45,45,90],unknown:1,context:'独立读直角标记'},'独立点读A45°和C直角标记，实际拼角，再给B。','B45°。','无提示：两个锐角相同'],
  [{kind:'conditions',angles:[90,35,55],unknown:2,context:'直角换位置'},'隔日先读A的直角标记及B35°，实际拼三个角片，再给未知C。','C55°；直角在A，不在原来C。','隔日：直角标记的位置改变'],
  [{kind:'conditions',angles:[30,90,60],unknown:2,context:'B为直角'},'独立先读A30°与B直角标记，实际拼角再给C；不能凭边长猜。','C60°。','备用：直角在B']
 ]
};
const angleStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(ANGLE_CASES)){
 if(cases.length!==4)throw Error('Four G02 cases required: '+skillId);angleStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];angleStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:42,mode:'angleLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,contentVersion:['triangle','conditions'].includes(params.kind)||skillId==='G02.02'&&i===3?71:42,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先读顶点、已知标记与分割条件，再实际转动、拼角或画对角线。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={ANGLE_CASES};
