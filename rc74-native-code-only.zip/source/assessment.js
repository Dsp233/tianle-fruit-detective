'use strict';
// Presentation order never determines an answer's identity. Versioned IDs keep
// older instance records interpretable when authored content changes.
const ASSESSMENT_RULES=Object.freeze({version:4,independentSuccesses:2,reviewDelayMs:24*60*60*1000});
function assessmentHash(value){let h=2166136261;for(const char of String(value)){h^=char.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function assessmentOptionId(task,kind,index){const explicit=kind==='reason'?task.reason?.optionIds:kind==='objects'?task.objectIds:task.optionIds;return explicit?.[index]||`${task.id}:v${task.contentVersion??5}:${kind}:${index}`}
function assessmentPermutation(length,seed){const out=Array.from({length},(_,i)=>i);let state=assessmentHash(seed)||1;for(let i=length-1;i>0;i--){state^=state<<13;state^=state>>>17;state^=state<<5;const j=(state>>>0)%(i+1);[out[i],out[j]]=[out[j],out[i]]}return out}
function assessmentValidOrder(order,length){return Array.isArray(order)&&order.length===length&&new Set(order).size===length&&order.every(i=>Number.isInteger(i)&&i>=0&&i<length)}
function assessmentFormal(task){return task.phase==='测'||task.phase==='巩固'}
function assessmentEvidenceContext(task,context={}){
 const kind=context.stageKind||'',phase=task.phase||'样题';
 if(context.view==='competition')return {evidenceScope:'competition-reasoning',assessmentType:'competition-challenge',formalEligible:false};
 if(context.view==='joint'){const kind=task.joint?.kind;return {evidenceScope:'knowledge-relation',assessmentType:kind==='G'?'guided-application':kind==='D'?'delayed-application':'independent-application',formalEligible:['I1','I2','D'].includes(kind)}}
 if(context.view==='stage'){
  const independent=/^independent(?:[2-4])?$/.test(kind)&&phase==='测';
  const review=/^delayed(?:7|21)?$/.test(kind)&&phase==='巩固';
  return {evidenceScope:'micro-skill',assessmentType:independent?'independent':review?'delayed-review':'guided-transfer',formalEligible:independent||review};
 }
 if(['fruit','course','transfer'].includes(context.view))return {evidenceScope:'legacy-route',assessmentType:assessmentFormal(task)?phase==='测'?'route-assessment':'route-review':phase==='学'?'learning-example':'practice',formalEligible:assessmentFormal(task)};
 if(context.view==='sample')return {evidenceScope:'legacy-route',assessmentType:'sample',formalEligible:false};
 return {evidenceScope:'micro-skill',assessmentType:context.view==='micro'?'local-diagnostic':context.view==='demo'?'demonstration':'practice',formalEligible:false};
}
function assessmentMigrateAttempt(attempt,descriptor){
 if(attempt.evidenceVersion!==2){
  if(attempt.evidenceStatus!=='legacy-unverified'){attempt.legacyIndependent=attempt.independent===true;attempt.legacyFirstSubmissionCorrect=attempt.firstSubmissionCorrect===true}
  attempt.independent=false;attempt.firstSubmissionCorrect=false;attempt.evidenceScope='historical-unverified';attempt.evidenceStatus='legacy-unverified';return attempt;
 }
 if(attempt.evidenceRuleVersion!==ASSESSMENT_RULES.version)attempt.previousEvidence??={ruleVersion:attempt.evidenceRuleVersion||3,independent:attempt.independent===true,phase:attempt.phase||null,stageKind:attempt.stageKind||null};
 if(!descriptor){attempt.priorFormalEvidence??={contentVersion:attempt.contentVersion,ruleVersion:attempt.evidenceRuleVersion||3,independent:attempt.independent===true,firstSubmissionCorrect:attempt.firstSubmissionCorrect===true,evidenceScope:attempt.evidenceScope||null,assessmentType:attempt.assessmentType||null};attempt.independent=false;attempt.evidenceScope='historical-unverified';attempt.assessmentType='unknown-or-revised-task';attempt.evidenceStatus='version-unverified';return attempt}
 const contract=assessmentEvidenceContext(descriptor.task,descriptor);
 const unassisted=attempt.firstSubmissionCorrect===true&&attempt.gradingResult==='correct'&&attempt.modelViewed===false&&Array.isArray(attempt.hintEvents)&&!attempt.hintEvents.length;
 attempt.unassistedFirstSubmissionCorrect=unassisted;
 attempt.independent=attempt.independent===true&&unassisted&&contract.formalEligible;
 Object.assign(attempt,contract,{phase:descriptor.task.phase||'样题',stageKind:descriptor.stageKind||null,evidenceRuleVersion:ASSESSMENT_RULES.version});
 attempt.evidenceStatus=attempt.previousEvidence?.independent&&!contract.formalEligible?'scope-corrected':'record-contract-checked';
 return attempt;
}
function assessmentIndependentRecord(attempt){return attempt.evidenceVersion===2&&attempt.evidenceRuleVersion===ASSESSMENT_RULES.version&&attempt.independent===true&&attempt.firstSubmissionCorrect===true&&attempt.gradingResult==='correct'&&attempt.modelViewed===false&&Array.isArray(attempt.hintEvents)&&!attempt.hintEvents.length&&attempt.formalEligible===true}
function assessmentEvidenceCounts(attempts){
 const scopes={'micro-skill':new Set(),'legacy-route':new Set()};
 for(const a of attempts)if(assessmentIndependentRecord(a)&&scopes[a.evidenceScope])scopes[a.evidenceScope].add(a.contentVersion+':'+a.taskInstanceId);
 return {microSkill:scopes['micro-skill'].size,legacyRoute:scopes['legacy-route'].size};
}
function assessmentReviewProgress(previous,tasks,attempts=[]){
 const state={...previous,reviewInstances:[]},reviews=Object.entries(tasks).filter(([kind])=>/^delayed(?:7|21)?$/.test(kind));
 const keep=a=>{const match=reviews.find(([,t])=>t.id===a?.taskInstanceId&&(t.contentVersion??5)===a.contentVersion);if(!match||a.evidenceScope!=='micro-skill'||a.assessmentType!=='delayed-review'||!assessmentIndependentRecord(a)||!Number.isFinite(a.submittedAt))return;const [kind]=match,days=kind==='delayed7'?7:kind==='delayed21'?21:1;if(!state.independentQualifiedAt||a.submittedAt<state.independentQualifiedAt+days*ASSESSMENT_RULES.reviewDelayMs)return;if(!state.reviewInstances.some(r=>r.taskInstanceId===a.taskInstanceId&&r.contentVersion===a.contentVersion))state.reviewInstances.push({...a,hintEvents:[],operationSummary:undefined,answer:undefined,explanationEvidence:undefined})};
 for(const a of Array.isArray(previous?.reviewInstances)?previous.reviewInstances:[]){if(reviews.some(([,t])=>t.id===a.taskInstanceId&&(t.contentVersion??5)===a.contentVersion))keep(attempts.find(r=>r.id===a.id)||a);else{state.legacyReviewInstances??=[];if(!state.legacyReviewInstances.some(r=>r.id===a.id))state.legacyReviewInstances.push(a)}}
 for(const a of attempts)keep(a);
 for(const [kind,t] of reviews)state[kind+'FirstCorrect']=state.reviewInstances.some(a=>a.taskInstanceId===t.id&&(t.contentVersion??5)===a.contentVersion);
 return state;
}
function choiceButtons(task,pairs,action,group='answer',selected=draft.work?.choice){
 const proxy={...task,options:pairs.map(p=>p[1]),optionIds:pairs.map(([v])=>`${task.id}:v${taskVersion(task)}:control:${group}:${v}`)};
 return `<div class="fraction-choices">${displayOrder(proxy,'control:'+group).map(i=>`<span class="semantic-choice"><button class="secondary" data-action="${esc(action)}" data-value="${esc(pairs[i][0])}" data-option-id="${esc(proxy.optionIds[i])}" aria-pressed="${selected===pairs[i][0]}">${esc(pairs[i][1])}</button><button class="speak-inline" data-action="speakControl" data-label="${esc(pairs[i][1])}" aria-label="朗读这张选择卡">🔊</button></span>`).join('')}</div>`;
}
function assessmentStageProgress(previous,tasks,attempts=[]){
 const state={...previous,cleanInstances:[]};
 const independent=Object.entries(tasks).filter(([kind])=>kind.startsWith('independent')).map(([,t])=>t);
 const keep=a=>{const t=independent.find(t=>t.id===a?.taskInstanceId&&(t.contentVersion??5)===a.contentVersion);if(t&&a.evidenceScope==='micro-skill'&&a.assessmentType==='independent'&&assessmentIndependentRecord(a)&&Number.isFinite(a.submittedAt)&&a.submittedAt>0&&!state.cleanInstances.some(x=>x.taskId===a.taskInstanceId&&x.contentVersion===a.contentVersion))state.cleanInstances.push({taskId:a.taskInstanceId,contentVersion:a.contentVersion,at:a.submittedAt,attemptId:a.id,evidenceRuleVersion:ASSESSMENT_RULES.version,record:{id:a.id,taskInstanceId:a.taskInstanceId,contentVersion:a.contentVersion,submittedAt:a.submittedAt,evidenceVersion:2,evidenceRuleVersion:ASSESSMENT_RULES.version,evidenceScope:'micro-skill',assessmentType:'independent',formalEligible:true,independent:true,firstSubmissionCorrect:true,gradingResult:'correct',modelViewed:false,hintEvents:[]}})};
 const historical=[];
 for(const entry of Array.isArray(previous?.cleanInstances)?previous.cleanInstances:[]){
  if(entry.evidenceRuleVersion===ASSESSMENT_RULES.version&&entry.record&&entry.attemptId===entry.record.id&&independent.some(t=>t.id===entry.taskId&&(t.contentVersion??5)===entry.contentVersion))keep(attempts.find(a=>a.id===entry.attemptId)||entry.record);
  else historical.push(entry);
 }
 if(historical.length)state.legacyCleanInstances=historical;
 for(const a of attempts)keep(a);
 state.cleanInstances.sort((a,b)=>a.at-b.at);
 state.cleanIndependentAt=state.cleanInstances[0]?.at||0;
 state.cleanTaskId=state.cleanInstances.at(-1)?.taskId||'';
 state.independentQualifiedAt=state.cleanInstances.length>=ASSESSMENT_RULES.independentSuccesses?state.cleanInstances[ASSESSMENT_RULES.independentSuccesses-1].at:0;
 return state;
}
if(typeof module!=='undefined')module.exports={ASSESSMENT_RULES,assessmentHash,assessmentOptionId,assessmentPermutation,assessmentValidOrder,assessmentFormal,assessmentEvidenceContext,assessmentMigrateAttempt,assessmentIndependentRecord,assessmentEvidenceCounts,assessmentStageProgress,assessmentReviewProgress};
