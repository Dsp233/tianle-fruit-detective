"""Locate answer labels in scanned user PDFs and compare 20 years to ledger.

This OCR audit corroborates reference answer letters only. It never upgrades a
problem to independently reviewed; every ambiguous OCR result stays pending.
Usage: python audit_answer_pdfs.py --answers-dir /path/to/upload
"""
import argparse
import csv
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image


def answer_marks(png):
    image = Image.open(png).convert('RGB')
    pixels = np.asarray(image)
    height, width = pixels.shape[:2]
    left = int(width * .07)
    section = pixels[:, left:int(width*.32)]
    red, green, blue = (section[:, :, i].astype(np.int16) for i in range(3))
    mask = (green > 125) & (red < 190) & (green > red * 1.13) & (green > blue * 1.15)
    ys = np.where(mask.sum(axis=1) > width * .021)[0]
    bands = []
    for raw_y in ys:
        y = int(raw_y)
        if not bands or y > bands[-1][-1] + 1:
            bands.append([y])
        else:
            bands[-1].append(y)
    marks = []
    for band in bands:
        y1, y2 = band[0], band[-1]
        if y2-y1 < height*.017:
            continue
        xs = np.where(mask[y1:y2+1].any(axis=0))[0]
        if not len(xs):
            continue
        x1, x2 = int(xs.min()+left), int(xs.max()+left)
        if not (.044*width <= x2-x1 <= .073*width):
            continue
        # Some answer booklets place a green "解析" box 58 px after "答案".
        if marks and y1-marks[-1][1] < .06*height:
            continue
        # The single Latin A-E appears directly to the right of the green 答案 tag.
        crop = image.crop((x2+2, max(0,y1-4), min(width,x2+int(.06*width)), min(height,y2+5)))
        crop = crop.resize((360, 220))
        with tempfile.NamedTemporaryFile(suffix='.png') as scratch:
            crop.save(scratch.name)
            result = subprocess.run(['tesseract',scratch.name,'stdout','--psm','6',
                                     '-c','tessedit_char_whitelist=ABCDE'],
                                    text=True,capture_output=True,check=True)
        detected = ''.join(ch for ch in result.stdout if ch in 'ABCDE')
        marks.append((detected if len(detected)==1 else '?', y1))
    return marks


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--answers-dir',type=Path,required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent.parent
    with (root/'docs'/'exam-review-ledger.csv').open(encoding='utf-8-sig',newline='') as stream:
        ledger=list(csv.DictReader(stream))
    assert len(ledger)==500
    years=sorted({int(row['year']) for row in ledger})
    report=[]
    # These two answers continue on the next page after a green tag at page end.
    split_page_answers={(2002,12):('B','第7页首行'),(2003,9):('C','第6页首行')}
    # Manually inspected page-top 解析 tags; they continue the preceding answer.
    explanation_continuations={(2015,3),(2015,15),(2018,3),(2020,14)}
    for year in years:
        source=args.answers_dir/f'{year} AMC8 (答案).pdf'
        if not source.exists():
            raise FileNotFoundError(source)
        with tempfile.TemporaryDirectory(prefix=f'amc{year}answers-') as directory:
            prefix=Path(directory)/'page'
            subprocess.run(['pdftoppm','-scale-to','1300','-png',str(source),str(prefix)],
                           check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            marks=[]
            for page in sorted(Path(directory).glob('page-*.png')):
                page_marks=answer_marks(page)
                page_number=int(page.stem.split('-')[-1])
                if (year,page_number) in explanation_continuations:
                    if not page_marks or page_marks[0][1] > 125:
                        raise ValueError(f'Expected a page-top explanation: {year} page {page_number}')
                    page_marks=page_marks[1:]
                marks.extend((letter,page.name,y) for letter,y in page_marks)
        questions=sorted((row for row in ledger if int(row['year'])==year),key=lambda r:int(r['problemNumber']))
        valid_count=len(marks)==25
        for index,row in enumerate(questions):
            detected,page,y=marks[index] if valid_count else ('','','')
            note=''
            if valid_count and (year,index+1) in split_page_answers and detected=='?':
                detected,note=split_page_answers[(year,index+1)]
            status=('待人工定位：标签数'+str(len(marks)) if not valid_count else
                    '待人工辨认OCR' if detected=='?' else
                    '人工目视一致' if note and detected==row['referenceAnswer'] else
                    '与登记答案一致' if detected==row['referenceAnswer'] else '答案冲突待人工复核')
            report.append(dict(examId=row['examId'],referenceAnswer=row['referenceAnswer'],
                               pdfAnswer=detected,pdfPage=page,markerTop=y,
                               detectedMarks=len(marks),status=status,
                               answerFile=source.name,manualNote=note))
        print(f'{year}: {len(marks)} marks; '+str(sum(r['status']=='与登记答案一致' for r in report[-25:]))+' matches',flush=True)
    target=root/'docs'/'answer-pdf-audit.csv'
    with target.open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(report[0]),lineterminator='\n')
        writer.writeheader();writer.writerows(report)
    from collections import Counter
    print('TOTAL',dict(Counter(row['status'] for row in report)),flush=True)


if __name__=='__main__':
    main()
