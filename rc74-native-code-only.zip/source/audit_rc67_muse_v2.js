'use strict';
// Independent semantic checks added after Muse V2. A failing audit is an
// open defect, not a failed attempt to run the tests. No production writes.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),cp=require('child_process');
const {competitionCreate:create,competitionReviewedRecipe:recipe}=require('./competition_reviewed');
const {boot}=require('./test_support');
const out=process.env.AMC8_MUSE_AUDIT_OUTPUT||'docs/evidence/2026-10-08-muse-v2-reconciliation';
fs.mkdirSync(out,{recursive:true});
const app=boot(),checks=[],observations=[];
const render=d=>app.value('competitionDiagram('+JSON.stringify(d)+')');
const strip=s=>s.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
function check(issue,familyId,seed,assertion,actual,expected){checks.push({issue,familyId,seed,generatorRevision:3,assertion,actual,expected,result:JSON.stringify(actual)===JSON.stringify(expected)?'passed':'failed'});}
for(const seed of [1,2,129,2147483646,2147483647]){
 for(const familyId of ['recurrenceBackwards','exactlyOneSet','setOutside','adjacentLine','natural-digitCount','natural-distinctDigitCount','equalDistanceSpeed']){
  const t=create(recipe(familyId,seed)),c=t.competition,m=c.math,d=c.extension.diagram;
  if(familyId==='recurrenceBackwards'){
   const positions=[...render(c.diagram).matchAll(/<div class="scene-slot"><b>([^<]*)<\/b><span>([^<]*)<\/span>/g)];
   check('V2-P1-001',familyId,seed,'Last two visible known terms have the question\'s actual term indices',positions.slice(-2).map(x=>Number(x[2].replace(/^第|项$/g,''))),[m.n-1,m.n]);
  }
  if(familyId==='exactlyOneSet')check('V2-P1-003',familyId,seed,'One A-only member joins B: A unchanged, B and intersection each +1',[d.a,d.b,d.both],[m.a,m.b+1,m.both+1]);
  if(familyId==='setOutside')check('V2-P1-003',familyId,seed,'One outside member joins both groups: A/B/intersection +1, population unchanged',[d.a,d.b,d.both,d.total],[m.a+1,m.b+1,m.both+1,m.total]);
  if(familyId==='adjacentLine'){
   const values=[...render(d).matchAll(/<div class="scene-slot"><b>([^<]*)<\/b>/g)].map(x=>x[1]);
   check('V2-P1-003',familyId,seed,'Displayed example obeys the non-adjacency constraint',Math.abs(values.indexOf('乐')-values.indexOf('明'))>1,true);
  }
  if(familyId.startsWith('natural-'))check(familyId==='natural-digitCount'?'V2-P2-005':'V2-P2-006',familyId,seed,'Changing repeat permission changes the rendered repeat label',strip(render(d)).includes('允许重复'),m.distinct);
  if(familyId==='equalDistanceSpeed')check('V2-P2-001',familyId,seed,'Trip speed uses the question\'s kilometres/hour unit',strip(render(c.diagram)).includes('千米/时'),true);
 }
}
// Observe actual production handlers in a Node VM; these are not browser runs.
const qa=boot({},2000000000000,fs.readFileSync('qa/index.html','utf8'));
function load(id){qa.run('window.AMC8_QA.loadCase('+JSON.stringify({familyId:id,seed:1,generatorRevision:3})+',true)');return qa.value('taskNow()');}
function solve(t){qa.click('competitionPick',{index:String(t.answer)});qa.click('check');}
for(const id of ['signedProduct','exactlyOneSet','setOutside','threeSetExactlyTwo','gridDetour','menuBranches']){
 const t=load(id);qa.click('competitionHint');qa.click('competitionHintMore');
 if(id==='signedProduct'){check('V2-P1-002',id,1,'Untaught signed multiplication withholds both hints and creates no assistance record',qa.value('competitionScopedContent(taskNow()).scopeBlocked')&&qa.value('saved.competition.events.length')===0&&qa.value('feedback.status')==='unsupported_scope',true);observations.push({issue:'V2-P1-002',familyId:id,status:'BLOCKED_UNTAUGHT_NEGATIVE_MULTIPLICATION',authoredHintsRetained:t.competition.hints.length,level:qa.value('draft.work.hintLevel'),scopeBlocked:true});continue;}
 check('V2-P1-002',id,1,'Both hints occur in the rendered hint panel',t.competition.hints.every(h=>qa.root.innerHTML.includes(h)),true);
 observations.push({issue:'V2-P1-002',familyId:id,hints:t.competition.hints,level:qa.value('draft.work.hintLevel'),moreButtonPresent:qa.root.innerHTML.includes('data-action="competitionHintMore"')});
}
for(const id of ['linkedRatios','crossArea','rectanglePointAreas']){
 const t=load(id);solve(t);qa.inputCompetition('extension',t.competition.extension.answer);qa.click('competitionExtensionCheck');
 check('V2-P3-004/006/007',id,1,'Successful variation displays an explicit check mark',(/<p\b[^>]*data-answer-status="correct"[^>]*>✓ /.test(qa.root.innerHTML)&&qa.value('draft.work.extensionResult.ok')===true),true);
}
for(const id of ['recurrenceRemainders','consecutiveRepresentations','remainderProbability','rotatingColors','stepwiseRoute']){
 const c=create(recipe(id,1)).competition;
 observations.push({issue:'V2-P3-013',familyId:id,methodStepCounts:c.methods.map(m=>m.steps.length),uniqueRenderedPicturesPerMethod:c.methods.map(m=>new Set(m.frames.map(frame=>render(frame.routeDiagram||frame.scene))).size)});
}
for(const id of ['rule-posts-both','rule-posts-neither']){
 const c=create(recipe(id,1)).competition;
 observations.push({issue:'V2-P2-003',familyId:id,mainAnswer:c.answer,mainCountableMarks:(render(c.diagram).match(/class="scene-mark"/g)||[]).length,variationAnswer:c.extension.answer,variationCountableMarks:(render(c.extension.diagram).match(/class="scene-mark"/g)||[]).length});
}
const c=load('setOutside');solve(c);qa.inputCompetition('extension',c.competition.extension.answer);qa.click('competitionExtensionCheck');
observations.push({issue:'V2-P1-004',familyId:'setOutside',mainSolutionAndVariationInSameSection:/<section class="competition-solutions">[\s\S]*<ol>[\s\S]*<details class="competition-extension"/.test(qa.root.innerHTML),mainSolutionViewed:qa.value('competitionHistory(taskNow()).solutionViewed'),variationRecord:qa.value('saved.competition.extensions.at(-1)'),variationFirstRecord:qa.value('Object.values(saved.competition.extensionViews).at(-1)'),interpretation:'Main solution exposure is not sufficient to prove an unassisted transfer attempt; UI/record wording needs an explicit exposure contract.'});
const failed=checks.filter(x=>x.result==='failed');
const summary={schemaVersion:1,observedAt:new Date().toISOString(),sourceCommit:require('./rc68_evidence').identity().sourceCommit,productionCandidateSha256:crypto.createHash('sha256').update(fs.readFileSync('index.html')).digest('hex'),result:failed.length?'failed':'passed',checks:checks.length,passed:checks.length-failed.length,failed:failed.length,openIssueIds:[...new Set(failed.map(x=>x.issue))],limits:['Node production generator and rendered HTML checks, not browser geometry or sound','Five fixed seeds per semantic case, not all possible parameters','Observations are evidence for triage, not automatic proof of every Muse claim']};
fs.writeFileSync(path.join(out,'semantic-audit.json'),JSON.stringify({...require('./rc68_evidence').identity(),result:summary.result,summary,checks,observations},null,2)+'\n');
console.log(JSON.stringify(summary,null,2));
process.exitCode=failed.length?1:0;
