/* Rebuild a factual 33-unit status matrix from executable course definitions. */
'use strict';
const fs=require('fs');
const path=require('path');
const {readCsv}=require('./csv');
const {FRUIT_TASKS}=require('./fruit');
const {FOUNDATION_COURSES}=require('./foundation');
const {EXTENSION_COURSES}=require('./extension');
const {REMAINING_COURSES}=require('./remaining');
const {FOCUS_REVIEW}=require('./focus');
const {MICRO_TASKS}=require('./micro');
const {WORKSHOP_TASKS}=require('./workshop');
const {STAGED_TASKS}=require('./staged');
require('./foundation_staged');
const {FRACTION_TASKS}=require('./fraction');
require('./fraction_staged');
require('./percent_staged');
const {PERCENT_TASKS}=require('./percent');
require('./integer_staged');
const {INTEGER_TASKS}=require('./integer');
require('./ratio_staged');
const {RATIO_TASKS}=require('./ratio');
require('./rate_staged');
const {RATE_TASKS}=require('./rate');
require('./journey_staged');
const {JOURNEY_TASKS}=require('./journey');
require('./scale_staged');
const {SCALE_TASKS}=require('./scale');
require('./equation_staged');
const {EQUATION_TASKS}=require('./equation');
require('./constraint_staged');
const {CONSTRAINT_TASKS}=require('./constraint');
require('./pattern_staged');
const {PATTERN_TASKS}=require('./pattern');
require('./coordinate_staged');
const {COORDINATE_TASKS}=require('./coordinate');
require('./grouping_staged');
const {GROUPING_TASKS}=require('./grouping');
require('./factor_staged');
const {FACTOR_TASKS}=require('./factor');
require('./common_staged');
const {COMMON_TASKS}=require('./common');
require('./cycle_staged');
const {CYCLE_TASKS}=require('./cycle');
require('./measure_staged');
const {MEASURE_TASKS}=require('./measure');
require('./angle_staged');
const {ANGLE_TASKS}=require('./angle');
require('./composite_staged');
const {COMPOSITE_TASKS}=require('./composite');
require('./circle_staged');
const {CIRCLE_TASKS}=require('./circle');
require('./similar_staged');
const {SIMILAR_TASKS}=require('./similar');
require('./right_staged');
const {RIGHT_TASKS}=require('./right');
require('./solid_staged');
const {SOLID_TASKS}=require('./solid');
require('./sets_staged');
require('./invariant_staged');
require('./motion_staged');
require('./chance_staged');
require('./stats_staged');
require('./chart_staged');
require('./combin_staged');
const {SETS_TASKS}=require('./sets');
const {INVARIANT_TASKS}=require('./invariant');
const {MOTION_TASKS}=require('./motion');
const {CHANCE_TASKS}=require('./chance');
const {STATS_TASKS}=require('./stats');
const {CHART_TASKS}=require('./chart');
const {COMBIN_TASKS}=require('./combin');
require('./breadth');
require('./enrichment');
require('./transfer_enrichment');
const {DEMO_TASKS}=require('./pool_tasks');
const skills=require('./skills.json');
const courses={...FOUNDATION_COURSES,...EXTENSION_COURSES,...REMAINING_COURSES};
const operationModes=new Set(['people','formula','bundleTen','balanceUnknown','enumerate','netFold','netSelect','selectIcons','cycleOverlap','parityMoves','tenTap','sequence','lineWalk','barBuild','arcSelect','sides','placeValue','gridSelect','redistribute','pairs']);
const q=x=>'"'+String(x??'').replaceAll('"','""')+'"';
const fields=['unitId','skillIds','prerequisiteChecked','mathReviewed','demoTaskIds','operationTaskIds','objectSortingTaskIds','explanationTaskIds','transferTaskIds','independentTaskIds','delayedTaskIds','speechChecked','browserEvidencePaths','ipadStatus','bookReferenceIds','examReferenceIds','doneItemIds','pendingItemIds','blockers','status'];
const args=process.argv.slice(2);let check=false,target=path.join(__dirname,'..','docs','unit-acceptance.csv');
while(args.length){const arg=args.shift();if(arg==='--check')check=true;else if(arg==='--output'&&args.length)target=path.resolve(args.shift());else throw Error('Unknown or incomplete argument: '+arg);}
const previous=new Map();
if(fs.existsSync(target)){
 const old=readCsv(fs.readFileSync(target,'utf8'));
 if(!old.fields.includes('unitId'))throw Error('Existing matrix has no unitId; refusing to overwrite');
 for(const field of old.fields)if(!fields.includes(field))fields.push(field);
 for(const row of old.rows){
  if(previous.has(row.unitId)||!skills.units.some(u=>u.id===row.unitId))throw Error('Duplicate or unknown unit in existing matrix: '+row.unitId);
  previous.set(row.unitId,row);
 }
}
const rows=[];
for(const unit of skills.units){
 const code=unit.id,tasks=code==='C01'?FRUIT_TASKS:courses[code]?.steps,delay=FOCUS_REVIEW[code];
 if(!tasks||!delay)throw Error('Missing course/review: '+code);
 const collect=(items,criterion)=>items.filter(criterion).map(t=>t.id).join(';');
 const micro=unit.skillIds.map(id=>MICRO_TASKS[id]);
 if(micro.some(t=>!t))throw Error('Missing micro task in '+code);
 const workshops=unit.skillIds.map(id=>WORKSHOP_TASKS[id]).filter(Boolean);
 const fractionTasks=unit.skillIds.map(id=>FRACTION_TASKS[id]).filter(Boolean);
 const percentTasks=unit.skillIds.map(id=>PERCENT_TASKS[id]).filter(Boolean);
 const integerTasks=unit.skillIds.map(id=>INTEGER_TASKS[id]).filter(Boolean);
 const ratioTasks=unit.skillIds.map(id=>RATIO_TASKS[id]).filter(Boolean);
 const rateTasks=unit.skillIds.map(id=>RATE_TASKS[id]).filter(Boolean);
 const journeyTasks=unit.skillIds.map(id=>JOURNEY_TASKS[id]).filter(Boolean);
 const scaleTasks=unit.skillIds.map(id=>SCALE_TASKS[id]).filter(Boolean);
 const equationTasks=unit.skillIds.map(id=>EQUATION_TASKS[id]).filter(Boolean);
 const constraintTasks=unit.skillIds.map(id=>CONSTRAINT_TASKS[id]).filter(Boolean);
 const patternTasks=unit.skillIds.map(id=>PATTERN_TASKS[id]).filter(Boolean);
 const coordinateTasks=unit.skillIds.map(id=>COORDINATE_TASKS[id]).filter(Boolean);
 const groupingTasks=unit.skillIds.map(id=>GROUPING_TASKS[id]).filter(Boolean);
 const factorTasks=unit.skillIds.map(id=>FACTOR_TASKS[id]).filter(Boolean);
 const commonTasks=unit.skillIds.map(id=>COMMON_TASKS[id]).filter(Boolean);
 const cycleTasks=unit.skillIds.map(id=>CYCLE_TASKS[id]).filter(Boolean);
 const measureTasks=unit.skillIds.map(id=>MEASURE_TASKS[id]).filter(Boolean);
 const angleTasks=unit.skillIds.map(id=>ANGLE_TASKS[id]).filter(Boolean);
 const compositeTasks=unit.skillIds.map(id=>COMPOSITE_TASKS[id]).filter(Boolean);
 const circleTasks=unit.skillIds.map(id=>CIRCLE_TASKS[id]).filter(Boolean);
 const similarTasks=unit.skillIds.map(id=>SIMILAR_TASKS[id]).filter(Boolean);
 const rightTasks=unit.skillIds.map(id=>RIGHT_TASKS[id]).filter(Boolean);
 const solidTasks=unit.skillIds.map(id=>SOLID_TASKS[id]).filter(Boolean);
 const setsTasks=unit.skillIds.map(id=>SETS_TASKS[id]).filter(Boolean);
 const combinTasks=unit.skillIds.map(id=>COMBIN_TASKS[id]).filter(Boolean);
 const chartTasks=unit.skillIds.map(id=>CHART_TASKS[id]).filter(Boolean);
 const statsTasks=unit.skillIds.map(id=>STATS_TASKS[id]).filter(Boolean);
 const chanceTasks=unit.skillIds.map(id=>CHANCE_TASKS[id]).filter(Boolean);
 const motionTasks=unit.skillIds.map(id=>MOTION_TASKS[id]).filter(Boolean);
 const invariantTasks=unit.skillIds.map(id=>INVARIANT_TASKS[id]).filter(Boolean);
 const stages=unit.skillIds.map(id=>STAGED_TASKS[id]).filter(Boolean);
 const generated={unitId:code,skillIds:unit.skillIds.join(';'),demoTaskIds:[...tasks.filter(t=>!!t.worked).map(t=>t.id),...unit.skillIds.filter(id=>DEMO_TASKS[id]).map(id=>DEMO_TASKS[id].id)].join(';'),operationTaskIds:collect([...tasks,...workshops,...fractionTasks,...percentTasks,...integerTasks,...ratioTasks,...rateTasks,...journeyTasks,...scaleTasks,...equationTasks,...constraintTasks,...patternTasks,...coordinateTasks,...groupingTasks,...factorTasks,...commonTasks,...cycleTasks,...measureTasks,...angleTasks,...compositeTasks,...circleTasks,...similarTasks,...rightTasks,...solidTasks,...setsTasks,...invariantTasks,...motionTasks,...chanceTasks,...statsTasks,...chartTasks,...combinTasks],t=>operationModes.has(t.mode)||!!t.skillId),objectSortingTaskIds:micro.map(t=>t.id).join(';'),explanationTaskIds:collect([...tasks,...workshops,...fractionTasks,...percentTasks,...integerTasks,...ratioTasks,...rateTasks,...journeyTasks,...scaleTasks,...equationTasks,...constraintTasks,...patternTasks,...coordinateTasks,...groupingTasks,...factorTasks,...commonTasks,...cycleTasks,...measureTasks,...angleTasks,...compositeTasks,...circleTasks,...similarTasks,...rightTasks,...solidTasks,...setsTasks,...invariantTasks,...motionTasks,...chanceTasks,...statsTasks,...chartTasks,...combinTasks],t=>!!t.reason||t.mode==='formula'),transferTaskIds:stages.map(s=>s.transfer.id).join(';'),independentTaskIds:[...tasks.filter(t=>t.phase==='测').map(t=>t.id),...stages.flatMap(s=>['independent','independent2','independent3','independent4'].map(k=>s[k]?.id).filter(Boolean))].join(';'),delayedTaskIds:[...delay.map(t=>t.id),...stages.flatMap(s=>['delayed','delayed7','delayed21'].map(k=>s[k]?.id).filter(Boolean))].join(';')};
 rows.push({unitId:code,skillIds:unit.skillIds.join(';'),prerequisiteChecked:'先修关系仅初步登记；未验证每条教学链',mathReviewed:'部分风险点已校正；全任务数学审校未完成',
  demoTaskIds:collect(tasks,t=>!!t.worked),operationTaskIds:collect(tasks,t=>operationModes.has(t.mode)),objectSortingTaskIds:micro.map(t=>t.id).join(';'),explanationTaskIds:collect(tasks,t=>!!t.reason||t.mode==='formula'),
  transferTaskIds:'',independentTaskIds:collect(tasks,t=>t.phase==='测'),delayedTaskIds:delay.map(t=>t.id).join(';'),
  speechChecked:'语音入口有模拟回归；逐项设备未验',browserEvidencePaths:'',ipadStatus:'待iPad横屏真机验收',bookReferenceIds:'',examReferenceIds:'',
  doneItemIds:'已有路线任务ID及模式盘点；179个对象辨识任务已绑定',pendingItemIds:'完整操作覆盖;解释;表示与情境迁移;新实例测验;延迟新实例;双书真题映射',
  blockers:'浏览器设备证据不可得；教材和真题尚未完成逐项核对',status:'进行中',...previous.get(code),...generated});
}
if(rows.length!==33)throw Error('Not all 33 units are accounted for');
const output='\ufeff'+fields.map(q).join(',')+'\n'+rows.map(row=>fields.map(f=>q(row[f])).join(',')).join('\n')+'\n';
if(check){if(!fs.existsSync(target)||fs.readFileSync(target,'utf8')!==output)throw Error('Unit matrix is stale; run node source/audit_units.js');}
else{const temp=target+'.tmp';fs.writeFileSync(temp,output);fs.renameSync(temp,target);}
const noOperation=rows.filter(row=>!row.operationTaskIds).map(row=>row.unitId);
console.log(`${rows.length} units; ${noOperation.length} with no current mathematical operation. Manual evidence preserved; ${check?'checked':'updated'} generated task columns.`);
