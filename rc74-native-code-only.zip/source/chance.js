'use strict';
function chanceBag(colors,extra={}){return {type:'bag',name:'混匀袋中每个球等可能',atoms:colors.map((color,i)=>({id:'B'+(i+1),label:color+'球'+(i+1),color})),...extra}}
function chanceCoin(extra={}){return {type:'coin',name:'公平硬币',atoms:[{id:'H',label:'正',color:'正'},{id:'T',label:'反',color:'反'}],...extra}}
function chanceDie(n=3,extra={}){return {type:'die',name:'等可能编号卡',atoms:Array.from({length:n},(_,i)=>({id:'F'+(i+1),label:String(i+1),color:String(i+1)})),...extra}}
function chanceSpinner(sectors,extra={}){return {type:'spinner',name:'面积等效的等角小扇区',sectors:sectors.map(([color,size])=>({color,size})),atoms:sectors.flatMap(([color,size],sector)=>Array.from({length:size},(_,i)=>({id:`S${sector+1}-${i+1}`,label:color+'等角片'+(i+1),color,sector}))),...extra}}
const CHANCE_TASKS={
 'D03.01':{kind:'certainty',models:[chanceBag(['红','红','红'],{event:{type:'color',color:'红'},eventLabel:'取到红球'}),chanceBag(['蓝','蓝'],{event:{type:'color',color:'绿'},eventLabel:'取到绿球'}),chanceBag(['红','红','红','蓝'],{event:{type:'color',color:'红'},eventLabel:'取到红球'})],prompt:'分别亲手收录每袋的全部具体球身份，圈所问事件的球，判断一定、不可能或可能但不一定。没有有利结果时明确标空。',explain:'全红袋红球一定，蓝袋绿球不可能；3红1蓝更可能取红但仍可能取蓝，不是一定。'},
 'D03.02':{kind:'space',models:[chanceBag(['红','红','蓝'],{event:{type:'all'},eventLabel:'所有具体身份'})],prompt:'亲手逐球列一次取球的全部具体结果。两个红球颜色相同但编号不同；每个原身份收录一次，删除重复并补缺项。',explain:'B1、B2、B3是3个等可能原球身份，不能合并成只有红、蓝两个等可能结果。'},
 'D03.03':{kind:'equal',models:[chanceBag(['红','红','红','蓝'],{event:{type:'color',color:'红'},eventLabel:'颜色红与蓝是否等可能'})],prompt:'列全等可能原球身份，再区分“具体球等可能”与“红蓝颜色事件等可能”，分别作判断。',explain:'4个具体球各1/4；红3个身份、蓝1个身份，颜色概率3/4与1/4，不相等。'},
 'D03.04':{kind:'favorable',models:[chanceDie(4,{event:{type:'even'},eventLabel:'编号为偶数'})],prompt:'列全等可能编号卡，逐条圈有利结果“编号为偶数”，填写有利结果/全部结果的概率。可用等值分数。',explain:'2、4两个有利，共4个等可能结果；2/4＝1/2。'},
 'D03.05':{kind:'two',models:[chanceCoin({second:chanceCoin(),replacement:true,event:{type:'exact',color:'正',count:1},eventLabel:'两次恰好一次正面'})],prompt:'两次独立抛公平硬币。实际摆第一、第二次卡，按第一结果收录完整树，圈恰好一次正面的叶，填写概率。',explain:'正正、正反、反正、反反共4；正反、反正有利，2/4＝1/2。'},
 'D03.06':{kind:'weighted',models:[chanceSpinner([['红',3],['蓝',1]],{event:{type:'color',color:'红'},eventLabel:'转到红色',compare:['红','蓝']})],prompt:'转盘红色占270°、蓝色90°，按4块等角原片逐片收录并圈红色片，填写概率，比较红蓝哪个更可能。',explain:'按等角小扇区计，红3/4、蓝1/4；两种颜色不代表各1/2。'}
};
for(const [skillId,t] of Object.entries(CHANCE_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,mode:'chanceLab',contentVersion:61,phase:'练',context:'具体结果、事件与等可能条件',hint:'先列全具体等可能身份；两次按第一结果逐分支摆卡。颜色是事件，不自动是等可能基本结果。',reason:{prompt:'概率结论需要什么依据？',options:['完整列举具体结果，先确认基本结果等可能，再把所问事件的有利身份或叶与全体比较','只看有几种颜色就平均分概率','尝试没出现某结果就能证明它不可能'],answer:0}});
if(typeof module!=='undefined')module.exports={CHANCE_TASKS,chanceBag,chanceCoin,chanceDie,chanceSpinner};
