'use strict';
const chanceFactory=typeof module!=='undefined'?require('./chance'):{chanceBag,chanceCoin,chanceDie,chanceSpinner},cBag=chanceFactory.chanceBag,cCoin=chanceFactory.chanceCoin,cDie=chanceFactory.chanceDie,cSpin=chanceFactory.chanceSpinner;
const CHANCE_CASES={
 'D03.01':[
  [[cCoin({event:{type:'all'},eventLabel:'出现正或反'}),cCoin({event:{type:'color',color:'侧立'},eventLabel:'本题模型仅正反，问出现侧立'})],'按仅含正反的公平硬币模型列全并判断两事件。','正或反一定；模型内侧立不可能。','球袋改明确的两结果模型'],
  [[cDie(3,{event:{type:'even'},eventLabel:'偶数'}),cDie(3,{event:{type:'color',color:'4'},eventLabel:'编号4'})],'独立列全三张等可能卡，圈事件并判一定/不可能/可能。','偶数可能非一定，4不可能。','无提示：编号条件与不存在结果'],
  [[cBag(['蓝','蓝','蓝','红'],{event:{type:'color',color:'蓝'},eventLabel:'取蓝'}),cBag(['红'],{event:{type:'color',color:'红'},eventLabel:'取红'})],'隔日列全各袋实际球并判断事件；更可能仍不保证发生。','第一袋蓝可能非一定，第二袋红一定。','隔日：更可能反例与单球边界'],
  [[cSpin([['红',1],['蓝',1]],{event:{type:'color',color:'绿'},eventLabel:'绿'}),cSpin([['红',2]],{event:{type:'color',color:'红'},eventLabel:'红'})],'独立列转盘等角片结果并判断事件范围。','绿不可能；全红盘红一定。','备用：转盘与空/全事件']
 ],
 'D03.02':[
  [[cCoin({second:cCoin(),replacement:true,event:{type:'all'},eventLabel:'全部两次叶'})],'自己摆两次硬币卡并按第一结果列完整树，每个叶收录一次。','正正、正反、反正、反反共4。','一次身份改两阶段样本树'],
  [[cBag(['红','红','蓝','绿'],{event:{type:'all'},eventLabel:'所有球身份'})],'独立列全一次抽球的具体编号结果，不能合并同色。','4个不同具体球身份。','无提示：三颜色不等于四个球'],
  [[cDie(3,{second:cCoin(),replacement:true,event:{type:'all'},eventLabel:'编号加硬币'})],'隔日先抽等可能编号1/2/3，再抛硬币，摆卡列全结果树。','每编号有正反，共6叶。','隔日：两个不同设备的顺序步骤'],
  [[cSpin([['红',2],['蓝',1]],{event:{type:'all'},eventLabel:'全部等角片'})],'独立按3片等角基本结果收录转盘样本空间。','三个等角结果，红事件包含其中两个。','备用：扇区分割与事件身份']
 ],
 'D03.03':[
  [[cCoin({event:{type:'all'},eventLabel:'正反是否等可能'})],'列全公平硬币基本结果，分别判断基本结果与正反事件等可能。','基本结果等可能，两个单结果事件也相等。','颜色不等例改等可能正反边界'],
  [[cSpin([['红',1],['蓝',3]],{event:{type:'color',color:'蓝'},eventLabel:'红蓝是否等可能'})],'独立收录所有等角片，判断等角基本结果与红蓝事件是否等可能。','等角片各1/4，颜色1/4与3/4不相等。','无提示：非等大实际扇区'],
  [[cBag(['红','红','蓝','蓝'],{event:{type:'all'},eventLabel:'颜色是否等可能'})],'隔日列全部四球身份，再判断球与颜色的等可能性。','每球等可能，红蓝各2/4也相等。','隔日：颜色频数相等的有效条件'],
  [[cBag(['红','红','红','蓝','绿'],{event:{type:'all'},eventLabel:'三个颜色是否都等可能'})],'独立列五球身份并判断基本球和三个颜色事件的等可能性。','具体球相等，红3/5与蓝绿各1/5不全相等。','备用：三个事件中只有两个相等']
 ],
 'D03.04':[
  [[cBag(['红','红','红','蓝'],{event:{type:'color',color:'红'},eventLabel:'红球'})],'列全部具体球身份，圈红事件身份后填概率。','3/4。','编号条件改颜色合并事件'],
  [[cDie(5,{event:{type:'atLeast',value:4},eventLabel:'编号至少4'})],'独立列1至5，圈编号至少4的结果并填写概率。','4、5有利，2/5。','无提示：不等式事件与五结果'],
  [[cCoin({second:cCoin(),replacement:true,event:{type:'atLeastCount',color:'正',count:1},eventLabel:'至少一次正面'})],'隔日列两次硬币结果并圈至少一次正面，填写概率。','正正、正反、反正，共3/4。','隔日：恰好改至少的事件差别'],
  [[cBag(['红','蓝'],{event:{type:'color',color:'绿'},eventLabel:'绿球'})],'独立列具体球，明确标无有利结果并填写绿事件概率。','0/2＝0。','备用：空事件概率']
 ],
 'D03.05':[
  [[cDie(3,{second:cCoin(),replacement:true,event:{type:'firstEvenSecond',color:'正'},eventLabel:'编号偶数且硬币正面'})],'先抽编号1/2/3，再抛硬币，列完整树并圈两个条件都满足的叶，填概率。','仅2正有利，1/6。','两个不同设备与且条件'],
  [[cBag(['红','红','蓝'],{second:cBag(['红','红','蓝']),replacement:false,event:{type:'both',color:'红'},eventLabel:'两次均红，不放回'})],'独立从三球混匀袋连续取两球不放回，列具体身份树，圈两次都红的叶，填概率。','B1B2、B2B1有利，2/6＝1/3。','无提示：不放回，第二支不能重复原身份'],
  [[cCoin({second:cCoin(),replacement:true,event:{type:'same'},eventLabel:'两次相同'})],'隔日两次独立公平硬币，列树圈两次相同并填概率。','正正、反反，共2/4。','隔日：事件由恰好一次改同结果'],
  [[cBag(['红','蓝'],{second:cBag(['红','蓝']),replacement:true,event:{type:'both',color:'红'},eventLabel:'两次均红，每次放回'})],'独立两球袋取一次放回混匀再取，列树圈两次红，填概率。','红红有利，1/4；同一球身份可以再次取到。','备用：放回与不放回条件对照']
 ],
 'D03.06':[
  [[cBag(['红','红','红','蓝'],{event:{type:'color',color:'红'},eventLabel:'取红',compare:['红','蓝']})],'转盘换球袋：列等可能具体球，圈红事件、填概率并比较红蓝。','红3/4，蓝1/4。','角度权重换实际球频数'],
  [[cSpin([['红',1],['蓝',2],['绿',1]],{event:{type:'color',color:'蓝'},eventLabel:'蓝色',compare:['红','蓝']})],'独立按等角片列转盘空间，圈蓝、填概率并比较红蓝。','蓝2/4＝1/2，红1/4；蓝更可能。','无提示：三色与非等大扇区'],
  [[cSpin([['红',2],['蓝',2]],{event:{type:'color',color:'红'},eventLabel:'红色',compare:['红','蓝']})],'隔日按四等角片列空间，圈红事件并比较两个颜色概率。','红蓝各2/4，相同。','隔日：等大事件边界'],
  [[cBag(['红','蓝','蓝','蓝','蓝'],{event:{type:'color',color:'蓝'},eventLabel:'蓝球',compare:['红','蓝']})],'独立列五个具体球，圈蓝球身份、填概率并比较红蓝。','蓝4/5，红1/5，蓝更可能。','备用：多球身份和方向反转']
 ]
};
const chanceSource=typeof module!=='undefined'?require('./chance').CHANCE_TASKS:CHANCE_TASKS,chanceTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(CHANCE_CASES)){chanceTarget[skillId]={};for(const [i,stage] of ['transfer','independent','delayed','independent2'].entries()){const [models,prompt,explain,changeDimension]=cases[i];chanceTarget[skillId][stage]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,mode:'chanceLab',kind:chanceSource[skillId].kind,contentVersion:62,phase:stage==='transfer'?'迁移':stage==='delayed'?'巩固':'测',models,prompt,explain,changeDimension,context:'完整空间与有利结果',...(stage==='transfer'?{hint:'从等可能基本身份开始，按第一结果列所有后续；明确放回/不放回与事件条件。'}:{})}}}
if(typeof module!=='undefined')module.exports={CHANCE_CASES};
