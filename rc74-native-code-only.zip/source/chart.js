'use strict';
function chartBars(labels,values,gap=2,unit='本',extra={}){const max=Math.ceil(Math.max(...values)/gap)+1;return {labels,values,gap,unit,ticks:Array.from({length:max+1},(_,i)=>i*gap),...extra}}
function chartIcons(labels,icons,legend=2,unit='人'){return {labels,icons,legend,unit,values:icons.map(n=>n*legend)}}
function chartLine(points,threshold,relation='above',timeStep=1){return {points,threshold,relation,timeStep,unit:'分钟',valueUnit:'厘米',values:[]}}
const CHART_TASKS={
 'D01.01':{kind:'legend',...chartIcons(['甲班','乙班'],[3,2],2),prompt:'图例中一个完整图标代表2人。逐个拆开实际图标，把生成的单位点移到对应班级的计数盘，再填写各班人数。',explain:'甲班3个图标拆成6人，乙班2个拆成4人；图标数不是人数。'},
 'D01.02':{kind:'read',...chartBars(['阅读','绘画'],[6,10],2,'分钟'),prompt:'按柱图读两项活动用时。先在每根柱顶标出对应刻度，再填写数值并选择单位。',explain:'每相邻刻度差2分钟，柱顶为6与10分钟；不能写成6人/10人。'},
 'D01.03':{kind:'ticks',...chartBars(['甲'],[10],2,'件'),prompt:'纵轴各刻度等距，底端0、顶端12已给出。逐个把数值卡放到中间刻度，建立完整量尺。',explain:'6个相等间隔对应12件，每间隔2件；0、2、4、6、8、10、12。'},
 'D01.04':{kind:'build',...chartBars(['苹果','梨','桃'],[4,8,6],2,'个'),prompt:'根据表格亲手画柱：每格代表2个。选一类后逐格添柱或取回柱块；填写各类数量和单位。',explain:'4、8、6分别画2、4、3格；柱从0基线连续堆起。'},
 'D01.05':{kind:'convert',direction:'read',...chartBars(['红队','蓝队','绿队'],[10,15,5],5,'分'),prompt:'把每格5分的柱图转成表格。标出各柱顶刻度，把读出的数据填到对应表行并选单位。',explain:'对应队名填10、15、5分，不能把柱块数2、3、1当分数。'},
 'D01.06':{kind:'interval',...chartLine([[0,2],[2,6],[4,2],[6,6],[8,2]],4),prompt:'折线表示水位随时间变化，两点间直线变化。圈出水位高于4厘米的所有时间小段，累计这些不连续区间的分钟数，再选择单位。',explain:'1–3与5–7分钟高于4厘米，共2＋2＝4分钟；首末之间不是全都符合。'}
};
for(const [skillId,t] of Object.entries(CHART_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,mode:'chartLab',contentVersion:57,phase:'练',context:'真实图例、量尺与时间区间',hint:'先读图例、轴单位和刻度差，再操作对应图形。时间小段按整段值是否符合条件判断；端点瞬间不增加时长。',reason:{prompt:'什么证据能支持这题的读图结果？',options:['图例/轴单位与等距刻度相符，实际柱或单位点匹配数据；累计时间只加符合条件的实际区间','只比较图中图标数或柱块数就能确定原数据','从第一次到最后一次符合时刻之间全都算进去'],answer:0}});
if(typeof module!=='undefined')module.exports={CHART_TASKS,chartBars,chartIcons,chartLine};
