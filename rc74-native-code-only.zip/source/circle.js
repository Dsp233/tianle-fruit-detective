'use strict';
const CIRCLE_TASKS={
 'G04.01':{kind:'center',radius:3,rotation:0,points:[0,120,240],context:'从候选点实际连到圆周',prompt:'O、P是两个候选点。选一个点作为起点，实际连到圆周B、C、D；找出到三点距离相同的圆心。',explain:'圆心O到圆周各点距离都等于半径；偏离圆心的P连到这三点长度不同。',reason:{prompt:'怎样确认圆心？',options:['从该点到圆周各点的距离相同','任意选一个圆内点','圆周上的点就是圆心'],answer:0}},
 'G04.02':{kind:'radii',radius:3,rotation:0,context:'两条反向半径接成直径',prompt:'实际连接OA、OB两条半径，再把它们接成穿过O的AB直径。填写直径长度并选单位。A、B位于圆的相对两端。',explain:'OA和OB共线反向，各3厘米；AB直径6厘米。AC弦不通过圆心。',reason:{prompt:'为什么AB是直径而AC不是？',options:['AB的两端在圆周且中间通过圆心O','连接任意两个圆周点都是直径','直径只从圆心出发到一端'],answer:0}},
 'G04.03':{kind:'walk',radius:3,parts:12,targetSteps:12,given:'diameter',context:'沿圆周实际走整圈',prompt:'圆直径6厘米。从A沿圆周逐段走完一整圈，再填写精确长度（π的系数）和单位。不要进入圆内。',explain:'走整圈是圆周长，直径6厘米，所以6π厘米。',reason:{prompt:'为什么这里用长度单位？',options:['走的是圆的边界，一维长度','圆内涂色区域的面积','每走一段就乘一个平方单位'],answer:0}},
 'G04.04':{kind:'area',radii:[3],parts:12,context:'搬动实际扇形片观察面积',prompt:'把圆的12片扇形逐一搬入交错条带，保留全部材料。条带近似底πr、高r；填写原圆面积（π的系数）与单位。半径3厘米。',explain:'切开并移动不增减材料；近似条带底πr、高r，圆面积πr²＝9π平方厘米。',reason:{prompt:'为什么移动扇形片后面积仍相同？',options:['原来的全部扇形片都保留，只改变位置','近似条带必须是精确长方形','半径直接就是面积'],answer:0}},
 'G04.05':{kind:'arc',parts:4,start:0,count:1,totalCirc:20,context:'只选择A到B的连续圆弧',prompt:'圆周长20厘米，四等分。实际选出从A顺时针到B的四分之一圆弧，填写占整圈的分数、弧长和单位。',explain:'只选圆边上的连续一段，占1/4，长度20÷4＝5厘米。',reason:{prompt:'弧长量的是什么？',options:['沿圆周走过的连续边界长度','圆内扇形涂色面积','两端之间穿过圆内的直线'],answer:0}},
 'G04.06':{kind:'objects',radius:4,parts:4,start:0,count:1,context:'分别操作弧与扇形',prompt:'同样半径4厘米。第一盘实际选A到B的四分之一弧，第二盘选相应扇形区域；分别填写π的系数与正确单位。',explain:'弧长2π厘米；扇形面积4π平方厘米。边界与内部区域是不同对象。',reason:{prompt:'为什么两盘单位不同？',options:['弧是一维长度，扇形是二维面积','只因为盘子颜色不同','弧和扇形都用平方厘米'],answer:0}}
};
for(const [skillId,t] of Object.entries(CIRCLE_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:45,mode:'circleLab',phase:'练',hint:'圆心到圆周是半径，两条反向半径成直径；沿边界量长度，内部区域量面积。'});
if(typeof module!=='undefined')module.exports={CIRCLE_TASKS};
