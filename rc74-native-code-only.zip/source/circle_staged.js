'use strict';
const CIRCLE_CASES={
 'G04.01':[
  [{kind:'center',radius:2,rotation:45,points:[0,90,180,270],context:'旋转圆图的四段测量'},'圆图转过45°。从候选O、P中选起点，实际连接四个圆周点，找出四段距离相同的圆心。','O到四点均2厘米，P不能与所有圆周点等距。','图形旋转并由三个点增加到四个点'],
  [{kind:'center',radius:2,rotation:60,points:[0,120,240],context:'独立确定圆心'},'独立选圆心并连接B、C、D三个圆周点；验证它到三点等距。','O是圆心，三段均2厘米。','无提示：圆图方向改变'],
  [{kind:'center',radius:4,rotation:30,points:[0,120,240],context:'隔日等距起点'},'隔日实际选等距起点，连接圆周B、C、D，确认圆心。','O到圆周各点等距。','隔日：转向与半径改变'],
  [{kind:'center',radius:3,rotation:90,points:[0,90,180,270],context:'备用四点验证'},'独立从候选点实际连到四个圆周点，找出等距的起点。','O是圆心，不能以偏移点P替代。','备用：四点与另一个转向']
 ],
 'G04.02':[
  [{kind:'radii',radius:5,rotation:30,given:'diameter',answerTarget:'radius',context:'已知直径反求半径'},'已知AB直径10厘米。实际画OA、OB并接成AB，填写每条半径长度；图中半径是未知量。','每条半径10÷2＝5厘米。','已知直径反求半径，线段转向'],
  [{kind:'radii',radius:4,rotation:90,context:'独立接直径'},'半径4厘米。独立画OA、OB两条反向半径，实际接成AB，填写直径长度和单位。','直径8厘米。','无提示：直径改竖向'],
  [{kind:'radii',radius:1.5,rotation:45,context:'隔日斜向直径'},'隔日圆半径1.5厘米。实际画两条反向半径并接成AB，填写直径和单位。','3厘米，直径仍通过圆心。','隔日：小数半径与斜向直径'],
  [{kind:'radii',radius:2,rotation:60,context:'备用两半径'},'独立画半径OA、OB并接成AB；半径2厘米，填写直径长度与单位。','4厘米。','备用：另一个转向']
 ],
 'G04.03':[
  [{kind:'walk',context:'半圈路程与半圆纸片边界',routes:[{radius:3,parts:8,targetSteps:4,includeDiameter:false,label:'第一盘：只沿圆周走半圈'},{radius:3,parts:8,targetSteps:4,includeDiameter:true,label:'第二盘：描半圆纸片整条边界'}]},'两盘半径都是3厘米。第一盘只沿圆周走半圈；第二盘沿半圆纸片的完整边界，还须实际连接直径边。分别填写精确长度与单位。','半圈路程3π厘米；半圆边界3π＋6厘米。','同图改测量对象，弧与闭合边界分开'],
  [{kind:'walk',radius:2,parts:8,targetSteps:8,context:'独立走整圈'},'独立沿半径2厘米的圆走完整一圈，填写π系数、其他长度与单位。','4π厘米，额外直线长度0。','无提示：半径已知而非直径'],
  [{kind:'walk',radius:4,parts:12,targetSteps:6,context:'隔日半圈路程'},'隔日沿半径4厘米的圆只走半圈，不穿过圆内，填写走过的精确长度和单位。','4π厘米，不加直径8厘米。','隔日：只量半圈弧'],
  [{kind:'walk',radius:2,parts:8,targetSteps:4,includeDiameter:true,context:'备用半圆边界'},'独立描半径2厘米半圆纸片的整条边界，实际走弧并接直径，填写精确长度与单位。','2π＋4厘米。','备用：完整边界含直径']
 ],
 'G04.04':[
  [{kind:'area',radii:[2,4],parts:16,compare:true,context:'半径加倍与面积倍数'},'两圆半径分别2、4厘米。实际把各圆全部16片扇形搬成近似条带，填写各面积和单位，再判断第二圆面积是第一圆几倍。','4π、16π平方厘米；半径加倍，面积4倍。','两圆共用画图比例，半径倍数与面积倍数比较'],
  [{kind:'area',radii:[2],parts:16,context:'独立保留全部扇形'},'独立把半径2厘米的圆全部16片扇形搬入近似条带，填写面积与单位。','4π平方厘米。','无提示：改变切片数量'],
  [{kind:'area',radii:[1],parts:8,context:'隔日单位半径圆'},'隔日搬动半径1厘米圆的全部8片扇形，填写圆面积与正确单位；条带是近似形状。','π平方厘米。','隔日：单位半径，切片更少'],
  [{kind:'area',radii:[2.5],parts:12,context:'备用小数半径'},'独立搬动半径2.5厘米圆的全部12片扇形，填写面积中π的系数与单位。','6.25π平方厘米。','备用：小数半径的平方']
 ],
 'G04.05':[
  [{kind:'arc',parts:8,start:7,count:3,totalCirc:32,context:'跨过起始线的连续弧'},'圆周长32厘米，八等分。从A顺时针到B实际选出连续三段，路径跨过第8段与第1段交界。填写所占分数、弧长及单位。','3/8圆周，弧长12厘米；第8、1、2段相连。','四等分改单八等分，连续弧跨过编号交界'],
  [{kind:'arc',parts:6,start:2,count:2,totalCirc:30,context:'独立连续两段'},'独立选六等分圆周中从A顺时针到B的连续两段。整圈30厘米，填写分数、长度与单位。','2/6＝1/3，长10厘米。','无提示：六等分与可约分比例'],
  [{kind:'arc',parts:8,start:4,count:1,totalCirc:24,context:'隔日八分之一弧'},'隔日圆周24厘米，八等分。实际选A顺时针到B的一段弧，填写占比与弧长。','1/8，3厘米。','隔日：起点移到另一侧'],
  [{kind:'arc',parts:4,start:1,count:2,totalCirc:40,context:'备用连续半圈'},'独立在四等分圆周选从A顺时针到B的连续两段。整圈40厘米，填写占比、弧长与单位。','2/4＝1/2，20厘米。','备用：半圈由两相邻段组成']
 ],
 'G04.06':[
  [{kind:'objects',radius:2,parts:4,start:3,count:1,rotation:30,context:'数值相同仍是不同对象'},'半径2厘米。第一盘实际选A到B的四分之一弧，第二盘选相应扇形。分别填π系数与单位：数值系数恰好相同仍要分清对象。','弧π厘米，扇形π平方厘米；系数同为1，单位与对象不同。','相同系数反例，旋转并换到另一段'],
  [{kind:'objects',radius:4,parts:4,start:1,count:2,context:'独立半圈与半圆面'},'独立分别选A到B半圈弧与半圆扇形区域。半径4厘米，填写各π系数和单位。','4π厘米；8π平方厘米。','无提示：目标变半圆'],
  [{kind:'objects',radius:6,parts:4,start:2,count:1,rotation:15,context:'隔日另一侧四分之一'},'隔日半径6厘米。实际分别选指定四分之一弧与扇形，填写π系数和单位。','3π厘米；9π平方厘米。','隔日：另一侧弧和更大半径'],
  [{kind:'objects',radius:2,parts:4,start:0,count:2,context:'备用同系数半圆'},'独立分别操作半径2厘米的半圈弧和半圆扇形，填写π系数及单位。','两系数都2；弧2π厘米，面2π平方厘米。','备用：半圆系数相同仍不能交换对象']
 ]
};
const circleStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(CIRCLE_CASES)){
 if(cases.length!==4)throw Error('Four G04 cases required: '+skillId);circleStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];circleStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:46,mode:'circleLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先读具体测量对象；沿边界量长度，搬全部材料量面积，分别核对弧和扇形。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={CIRCLE_CASES};
