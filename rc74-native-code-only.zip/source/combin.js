'use strict';
function combinPair(name,first,second,options={}){return {type:'pair',name,first:first.map(id=>({id,label:id})),second:second.map(id=>({id,label:id})),...options}}
function combinOrder(name,ids,size,ordered=true,options={}){return {type:'order',name,items:ids.map(id=>({id,label:id})),size,ordered,repeat:false,...options}}
const COMBIN_TASKS={
 'C02.01':{kind:'group',models:[combinPair('上衣与帽子',['红衣','蓝衣','绿衣'],['白帽','黄帽'])],prompt:'逐个摆上衣、帽子卡并收录搭配。先选一个上衣分组，再把该上衣的全部搭配放进这一组，直到每组列全。',explain:'每个首选择分别配两种帽子；三组互不重复，共6种。'},
 'C02.02':{kind:'pair',models:[combinPair('午餐套餐',['饭','面'],['汤','奶','水'])],prompt:'套餐要主食与饮品各选一件。亲手把两类卡放进选择位，记录每个不同搭配，最后填写总数。',explain:'两个选择步骤，每种主食都有三种饮品搭配，共6种。'},
 'C02.03':{kind:'complete',models:[combinPair('车站路线',['A站','B站','C站'],['东线','西线'],{seed:[['A站','东线'],['A站','西线'],['B站','东线']]})],prompt:'当前路线表只收录了部分搭配。用卡补足全部“起点站＋线路”，保留正确记录，删除重复或不合条件项，填写不同路线数。',explain:'检查每个起点的所有线路，不能只把已有行数当全部；共6条。'},
 'C02.04':{kind:'dedup',models:[combinPair('饮料与杯型',['茶','奶'],['圆杯','方杯'],{seed:[['茶','圆杯'],['茶','圆杯'],['茶','方杯'],['奶','圆杯']]})],prompt:'记录中有重复搭配。逐行核对具体两张卡，删去多算的一行，补上漏掉的搭配，再填写不同搭配数。',explain:'同一两类选择只是一种结果；茶圆杯只保留一次，共4种。'},
 'C02.05':{kind:'rule',models:[combinPair('先选活动再选时段',['游泳','绘画'],['上午','下午','晚上'],{forbidden:[['游泳','晚上']]})],prompt:'游泳只有上午、下午；绘画三个时段都开放。摆卡列全实际可用报名方案，选择适用计数条件并填写总数。',explain:'分支可选数不同，用2＋3＝5；不能机械用2×3。'},
 'C03.01':{kind:'orderMeaning',models:[combinOrder('前后站位',['安','贝'],2,true),combinOrder('无序搭档',['安','贝'],2,false)],prompt:'同样两人，分别摆出全部前后站位和全部无序搭档。收录两盘结果并填各盘总数，判断交换前后是否产生新结果。',explain:'站位安贝与贝安不同，共2；搭档两人相同，共1。'},
 'C03.02':{kind:'queue',models:[combinOrder('三人队列',['安','贝','晨'],3,true)],prompt:'把三张不同人卡逐张摆进前、中、后位，记录全部不同队列。不许同一人在一个队列重复出现，填写队列数。',explain:'按首位分三组，每组后两人能交换，共6队。'},
 'C03.03':{kind:'choose',models:[combinOrder('三选二搭档',['安','贝','晨'],2,false)],prompt:'从三人选两人当搭档，逐张摆卡并记录全部不同组。安贝和贝安是同一组；删除多算的记录，再填写组数。',explain:'安贝、安晨、贝晨共3组；组内顺序不重要。'},
 'C03.04':{kind:'limit',models:[combinOrder('安必须在首位',['安','贝','晨'],3,true,{fixed:{0:'安'}})],prompt:'三人排队，安必须在第一位。摆卡记录全部符合条件的队列，剔除不合条件的记录，填写种数。',explain:'安固定后，其余两人的顺序可交换，共2种。'},
 'C03.05':{kind:'system',models:[combinOrder('三选二前后位',['安','贝','晨'],2,true)],prompt:'从三人选不同的两人站前后位。按第一位的人分组，亲手列全每组队列，检查无漏无重复，填写总数。',explain:'每个首位都有其余两人可作第二位，三组共6种。'}
};
for(const [skillId,t] of Object.entries(COMBIN_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:55,mode:'combinLab',phase:'练',context:'摆卡、收录与实际列举',hint:'先选分组，再逐张摆卡收录具体结果。逐组检查遗漏、重复和限制。',reason:{prompt:'怎样证明这盘结果已经列全且没有重数？',options:['每个首选择的可行后续都逐一检查，同一具体结果只留一次，并遵守本题顺序和限制','已有行数刚好等于心算答案，就不必检查具体结果','任何选择题都用两个数字相乘'],answer:0}});
if(typeof module!=='undefined')module.exports={COMBIN_TASKS,combinPair,combinOrder};
