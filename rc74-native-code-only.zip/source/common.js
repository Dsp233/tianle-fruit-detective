'use strict';
const COMMON_TASKS={
 'N03.01':{kind:'multiples',periods:[4,6],horizon:24,context:'两盏灯的时间线',prompt:'甲每4分钟、乙每6分钟亮一次，0分钟一起亮。逐次生成两条时间线到24分钟，选出此后所有同时亮的时刻。',explain:'0之后24分钟内的共同亮灯时刻是12、24；它们同时在两条时间线上。',reason:{prompt:'为什么12是共同亮灯时刻？',options:['12同时是4与6的倍数','只在甲的时间线上就够','共同亮灯只发生在0'],answer:0}},
 'N03.02':{kind:'least',periods:[4,6],horizon:24,context:'下一次同时响铃',prompt:'两铃0分钟同时响，此后各每4、6分钟响。逐次摆两条时间线，选择下一次同时响的时刻；0不能算下一次。',explain:'最早的正重合是12；0是出发时刻，24虽然重合却更晚。',reason:{prompt:'这里为什么不选0或24？',options:['要找0之后最早的重合，12先于24','0最小就永远选0','任何重合都叫下一次'],answer:0}},
 'N03.03':{kind:'divisors',numbers:[12,18],context:'两盘同组量分装',prompt:'12与18两盘都按同一个每组数量分装。实际试装、保留不足组，收录能让两盘都没有剩余的全部正组量。',explain:'1、2、3、6可同时整除12与18；4只能整除12，不能同时分完。',reason:{prompt:'共同因数需要满足什么？',options:['同一组量能分别完整分完两盘','能分完其中一盘就够','两盘剩相同个数也算整除'],answer:0}},
 'N03.04':{kind:'greatest',dims:[12,18],context:'纸板铺最大正方形',prompt:'12×18纸板要铺同样大小的整数边长正方形，不能留边角。实际试铺并选最大可行边长；再试它以上到短边的所有整数，排除更大的方案。',explain:'边长6恰好铺2×3个正方形；7到12都不能同时整除两边，6最大。',reason:{prompt:'为什么只把短边分完还不够？',options:['边长必须同时整除长和宽，并取其中最大','只要短边无余就行','面积足够就能随便铺'],answer:0}},
 'N03.05':{kind:'contexts',bells:{periods:[4,6],horizon:24},paper:{dims:[8,12]},context:'响铃与切纸的两种目标',prompt:'先操作4、6分钟的两铃，找下一次正重合；再在8×12纸板上铺最大整数边长正方形并排除更大方案。分别选择两个故事要找最小还是最大。',explain:'响铃找最小正公倍数12；切纸找最大公因数4，目标由故事条件决定。',reason:{prompt:'两个故事的目标怎样对应？',options:['响铃取最小正重合，切纸取最大可行边长','两个故事都取最大','两个故事都取最小且允许0'],answer:0}}
};
for(const [skillId,t] of Object.entries(COMMON_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:35,mode:'commonLab',phase:'练',hint:'共同表示两边同时满足；下一次取正数中的最早，最大铺砖要核对两条边并排除更大边长。'});
if(typeof module!=='undefined')module.exports={COMMON_TASKS};
