'use strict';
const COMMON_CASES={
 'N03.01':[
  [{kind:'multiples',periods:[3,5],horizon:30,context:'两台打印机的完成时间'},'两机0分钟一起完成一张，此后每3、5分钟各完成一张。生成到30分钟的两条线，选全部正重合时刻。','15、30。','灯换打印完成事件，周期换互质的3与5'],
  [{kind:'multiples',periods:[2,3],horizon:12,context:'两铃的全部重合'},'独立生成每2、3分钟的两铃到12分钟的事件，选0后的全部同时响时刻。','6、12。','无提示：两次正重合'],
  [{kind:'multiples',periods:[3,4],horizon:24,context:'隔日两灯'},'隔日生成3、4分钟两灯到24分钟的事件线，并选全部正重合。','12、24。','隔日：周期不同但正重合与原例相同'],
  [{kind:'multiples',periods:[2,5],horizon:20,context:'两轮提醒'},'独立生成2、5分钟的事件到20分钟，选全部正重合。','10、20。','备用：共同倍数10和20']
 ],
 'N03.02':[
  [{kind:'least',periods:[3,5],horizon:30,context:'下一次共同完成'},'0分钟两机共同完成，之后每3、5分钟。实际生成两条线，找下一次共同完成时刻。','15分钟；0不是下一次，30更晚。','响铃换完成事件，周期互质'],
  [{kind:'least',periods:[2,3],horizon:12,context:'最早正重合'},'0分钟共同开始，两事件每2、3分钟重复。独立生成并选下一次正重合。','6分钟。','无提示：较短周期'],
  [{kind:'least',periods:[4,8],horizon:16,context:'周期整倍关系'},'隔日从0起，每4、8分钟两事件重复。找下一次共同发生。','8分钟，一个周期是另一个的倍数。','隔日：整倍关系，不能机械相乘'],
  [{kind:'least',periods:[2,5],horizon:20,context:'再次同时'},'独立从0生成2、5分钟的两线，选下一次同时发生。','10分钟。','备用：排除0与20']
 ],
 'N03.03':[
  [{kind:'divisors',numbers:[8,12],context:'不同总量的同组量'},'8枚与12枚都要按同一个组量完整分装。实际试两盘，收录全部共同正因数。','1、2、4；3只能分完12。','加入只能分完第二盘的反例'],
  [{kind:'divisors',numbers:[9,12],context:'三的共同分组'},'独立给9与12按相同组量试装，收录两盘都无余的全部正组量。','1、3。','无提示：共同因数只有两个'],
  [{kind:'divisors',numbers:[10,15],context:'隔日分装'},'隔日实际分装10与15，收录全部共同正因数。','1、5。','隔日：共同组量由3改5'],
  [{kind:'divisors',numbers:[6,9],context:'六与九的共同组量'},'独立试装6与9并收录全部共同正组量。','1、3。','备用：不同总量但共同集合相同']
 ],
 'N03.04':[
  [{kind:'greatest',dims:[8,12],context:'较小纸板的最大正方形'},'8×12纸板铺最大整数边长正方形。试铺并选择，试它以上到短边8的全部整数，排除更大方案。','边长4铺满；5到8均有边角余量。','两边改变，不能沿用边长6'],
  [{kind:'greatest',dims:[9,12],context:'独立铺纸板'},'独立在9×12纸板上试铺并选最大可行边长，试它以上到9的全部整数。','边长3最大。','无提示：最大边长3'],
  [{kind:'greatest',dims:[10,15],context:'隔日最大切分'},'隔日在10×15纸板试铺并选最大整数边长，试它以上到10的全部整数。','边长5最大。','隔日：最大边长5'],
  [{kind:'greatest',dims:[6,9],context:'备用切分'},'独立在6×9纸板上试铺并选最大整数边长，试它以上到6的全部整数。','边长3最大。','备用：短边6的上界']
 ],
 'N03.05':[
  [{kind:'contexts',bells:{periods:[3,5],horizon:30},paper:{dims:[6,9]},context:'打印重合与纸板铺砖'},'两机每3、5分钟完成，0分钟共同完成；找下一次。6×9纸板找最大整方块，并试更大整数到短边。操作两套材料并分别选最小或最大目标。','完成取最小正重合15；铺砖取最大边长3。','响铃改完成事件，取值目标仍依故事不同'],
  [{kind:'contexts',bells:{periods:[2,3],horizon:12},paper:{dims:[4,6]},context:'两种故事独立判断'},'独立操作每2、3分钟的两铃，找0后的下一次；4×6纸板找最大正方形并试更大到短边。为两故事选目标。','响铃6取最小正重合；纸板2取最大可行。','无提示：两模型都换参数'],
  [{kind:'contexts',bells:{periods:[3,4],horizon:24},paper:{dims:[6,8]},context:'隔日双模型'},'隔日操作3、4分钟两事件找下一次，及6×8纸板找最大方块并排除更大到短边；分别选目标。','事件12取最小正重合，纸板2取最大。','隔日：两目标数值不相同'],
  [{kind:'contexts',bells:{periods:[2,5],horizon:20},paper:{dims:[4,10]},context:'备用故事判别'},'独立操作2、5分钟找下一次正重合，4×10纸板找最大方块并试更大到短边；选对应目标。','10最小正重合；2最大可行边长。','备用：更长纸板与不同周期']
 ]
};
const commonStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(COMMON_CASES)){
 if(cases.length!==4)throw Error('Four N03 cases required: '+skillId);commonStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];commonStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:36,mode:'commonLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'共同要同时满足两边；读清取最早正重合还是最大可行组量。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={COMMON_CASES};
