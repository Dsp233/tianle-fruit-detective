'use strict';
// Deterministic, local competition problems. Selected topics are assumed
// available; this engine neither reads nor awards teaching/mastery gates.
const COMPETITION_VERSION=93;
const COMPETITION_TOPIC_IDS=['A01','A02','A03','A04','A05','R01','R02','R03','R04','L01','L02','L03','L04','N01','N02','N03','N04','G01','G02','G03','G04','G05','G06','G07','C01','C02','C03','C04','D01','D02','D03','S01','S02'];
function competitionGcd(a,b){while(b){[a,b]=[b,a%b]}return a}
function competitionFraction(a,b){const d=competitionGcd(Math.abs(a),Math.abs(b));return b/d===1?String(a/d):`${a/d}/${b/d}`}
// Display a rational exactly: terminating decimals stay decimals, others stay fractions.
function competitionRatioText(a,b=1){
 if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||b===0)throw Error('Invalid display ratio');
 const divisor=competitionGcd(Math.abs(a),Math.abs(b)),num=a/divisor*(b<0?-1:1),den=Math.abs(b/divisor);
 let rest=den;while(rest%2===0)rest/=2;while(rest%5===0)rest/=5;
 if(rest!==1)return competitionFraction(num,den);
 let n=BigInt(Math.abs(num)),d=BigInt(den),remainder=n%d,text=String(n/d);
 if(remainder){text+='.';while(remainder){remainder*=10n;text+=String(remainder/d);remainder%=d}}
 return (num<0?'-':'')+text;
}
function competitionDivisors(n){let count=0;for(let i=1;i*i<=n;i++)if(n%i===0)count+=i*i===n?1:2;return count}
function competitionSumDigits(n){return [...String(n)].reduce((s,v)=>s+Number(v),0)}
function competitionHash(value){let h=2166136261;for(const c of String(value)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return (h>>>0).toString(16).toUpperCase().padStart(8,'0')}
function competitionRng(seed){let state=(seed>>>0)||1;return max=>{state^=state<<13;state^=state>>>17;state^=state<<5;return (state>>>0)%max}}
function competitionShuffle(list,rng){const out=[...list];for(let i=out.length-1;i>0;i--){const j=rng(i+1);[out[i],out[j]]=[out[j],out[i]]}return out}
function competitionCanonicalIds(ids){const wanted=new Set(Array.isArray(ids)?ids:[]);return COMPETITION_TOPIC_IDS.filter(id=>wanted.has(id))}

// Each clue computes a quantity from the SAME unknown n. Its allowed values
// leave several possible cards; intersecting the clues gives the only answer.
// Topic tags come from the actual model, never from text matching.
function competitionModel(topicId,seed){
 const r=competitionRng(seed),k=2+r(4),b=2+r(5);
 switch(topicId){
 case 'A01':return {kind:'place',text:`一个数有 n 个十和 ${b} 个一。这个数`,value:n=>10*n+b,calculation:n=>`${n}×10+${b}=${10*n+b}`,diagram:{kind:'place',labels:['n 个十',`${b} 个一`]}};
 case 'A02':return {kind:'bill',text:`每袋 ${k} 枚徽章，买 n 袋后再送 ${b} 枚。徽章总数`,value:n=>k*n+b,calculation:n=>`${k}×${n}+${b}=${k*n+b}`,diagram:{kind:'bags',labels:[`${k} 枚/袋`,'n 袋',`另送 ${b} 枚`]}};
 case 'A03':return {kind:'fraction',text:`一条长 n 米的彩带，取出它的 1/${k}。取出的长度（米）`,value:n=>competitionFraction(n,k),calculation:n=>`${n}÷${k}=${competitionFraction(n,k)} 米`,diagram:{kind:'strip',parts:k,labels:['总长 n 米',`取 1/${k}`]}};
 case 'A04':return {kind:'discount',text:'原价 n 元的徽章打八折。现价（元）',value:n=>competitionFraction(4*n,5),calculation:n=>`${n}×80%=${competitionFraction(4*n,5)} 元`,diagram:{kind:'strip',parts:5,filled:4,labels:['原价 n 元','现价 80%']}};
 case 'A05':return {kind:'square',text:'边长 n 的正方形，面积',value:n=>n*n,calculation:n=>`${n}²=${n*n}`,diagram:{kind:'rectangle',labels:['n','n']}};
 case 'R01':return {kind:'ratio',text:`红卡与蓝卡数量比为 1:${k}，红卡有 n 张。卡片总数`,value:n=>(k+1)*n,calculation:n=>`${n}×(1+${k})=${(k+1)*n}`,diagram:{kind:'ratio',parts:k+1,labels:['红 n 张',`红:蓝=1:${k}`]}};
 case 'R02':return {kind:'unit',text:`n 分钟，每分钟前进 ${k} 米。前进的路程（米）`,value:n=>k*n,calculation:n=>`${k} 米/分×${n} 分=${k*n} 米`,diagram:{kind:'line',labels:['n 分钟',`${k} 米/分钟`]}};
 case 'R03':return {kind:'meeting',text:`两人相向而行，速度是 ${k} 和 ${b} 米/分，n 分钟相遇。原来的距离（米）`,value:n=>(k+b)*n,calculation:n=>`(${k}+${b})×${n}=${(k+b)*n} 米`,diagram:{kind:'meeting',labels:[`${k} 米/分`,'n 分钟',`${b} 米/分`]}};
 case 'R04':return {kind:'scale',text:`长 n、宽 2 的长方形，两边都放大 ${k} 倍。新面积`,value:n=>2*n*k*k,calculation:n=>`(${n}×${k})×(2×${k})=${2*n*k*k}`,diagram:{kind:'rectangle',labels:['n','2',`边长 ×${k}`]}};
 case 'L01':return {kind:'equality',text:`天平一边是 ${k} 个同重的袋子，每袋 n 克，另加 ${b} 克。另一边的重量（克）`,value:n=>k*n+b,calculation:n=>`${k}×${n}+${b}=${k*n+b} 克`,diagram:{kind:'balance',labels:[`${k} 袋 + ${b} 克`,'每袋 n 克','另一边 ?']}};
 case 'L02':return {kind:'system',text:`大袋比小袋多 ${b} 枚，小袋有 n 枚。2 个大袋和 1 个小袋共有`,value:n=>3*n+2*b,calculation:n=>`2×(${n}+${b})+${n}=${3*n+2*b}`,diagram:{kind:'bags',labels:['小袋 n',`大袋 n+${b}`,'2 大 + 1 小']}};
 case 'L03':return {kind:'sequence',text:`数列 ${b}、${b+k}、${b+2*k}……每次加 ${k}。第 n 项`,value:n=>b+(n-1)*k,calculation:n=>`${b}+(${n}−1)×${k}=${b+(n-1)*k}`,diagram:{kind:'sequence',labels:[String(b),String(b+k),String(b+2*k),'…','第 n 项']}};
 case 'L04':return {kind:'function',text:`表格遵循 y=${k}x+${b}，x=n 时。y 的值`,value:n=>k*n+b,calculation:n=>`${k}×${n}+${b}=${k*n+b}`,diagram:{kind:'table',rows:[['x','1','2','n'],['y',String(k+b),String(2*k+b),'?']]}};
 case 'N01':return {kind:'digits',text:'整数 100+n 的各位数字之和',value:n=>competitionSumDigits(100+n),calculation:n=>`${100+n} 的数字相加得 ${competitionSumDigits(100+n)}`,diagram:{kind:'digits',labels:['100 + n','各位数字相加']}};
 case 'N02':return {kind:'factors',text:'n² 的正因数个数（包括 1 和它本身）',value:n=>competitionDivisors(n*n),calculation:n=>`${n}²=${n*n}，共有 ${competitionDivisors(n*n)} 个正因数`,diagram:{kind:'factors',labels:['n²','找所有正因数']}};
 case 'N03':return {kind:'lcm',text:'n 和 n+1 的最小公倍数',value:n=>n*(n+1),calculation:n=>`${n} 与 ${n+1} 互质，最小公倍数=${n}×${n+1}=${n*(n+1)}`,diagram:{kind:'line',labels:['每 n 分钟','每 n+1 分钟','第一次同时']}};
 case 'N04':return {kind:'remainder',text:`23 格圆环编号 0–22，从第 ${b} 格起每次前进 ${k} 格，走 n 次。最后的格号`,value:n=>(k*n+b)%23,calculation:n=>`前进后总格号 ${k}×${n}+${b}=${k*n+b}，除以 23 的余数是 ${(k*n+b)%23}`,diagram:{kind:'cycle',labels:['23 格一轮',`从 ${b} 起，每次 +${k}`,'走 n 次']}};
 case 'G01':return {kind:'perimeter',text:`长 n、宽 ${b} 的长方形，周长`,value:n=>2*(n+b),calculation:n=>`2×(${n}+${b})=${2*(n+b)}`,diagram:{kind:'rectangle',labels:['n',String(b)]}};
 case 'G02':return {kind:'angle',text:'三角形两个角为 n° 和 2n°。第三个角（度）',value:n=>180-3*n,calculation:n=>`180−${n}−2×${n}=${180-3*n}°`,diagram:{kind:'triangle',labels:['n°','2n°','?°']}};
 case 'G03':return {kind:'cutArea',text:'长 n、宽 n+2 的纸，沿长边剪去宽 1 的一条。剩余面积',value:n=>n*(n+1),calculation:n=>`${n}×(${n}+2)−${n}×1=${n*(n+1)}`,diagram:{kind:'cut',labels:['n','n+2','剪去宽 1']}};
 case 'G04':return {kind:'circle',text:'半径 n 的圆，圆周长',value:n=>`${2*n}π`,calculation:n=>`2π×${n}=${2*n}π`,diagram:{kind:'circle',labels:['半径 n']}};
 case 'G05':return {kind:'similar',text:`相似三角形中，小边 ${b} 对应大边 ${2*b}；另一条小边是 n。对应大边`,value:n=>2*n,calculation:n=>`${2*b}÷${b}=2，${n}×2=${2*n}`,diagram:{kind:'similar',labels:[String(b),String(2*b),'n','?']}};
 case 'G06':return {kind:'right',text:'直角三角形两条直角边是 3n 和 4n。斜边',value:n=>5*n,calculation:n=>`√[(${3*n})²+(${4*n})²]=${5*n}`,diagram:{kind:'right',labels:['3n','4n','?']}};
 case 'G07':return {kind:'volume',text:`长 n、宽 ${k}、高 ${b} 的长方体，体积`,value:n=>n*k*b,calculation:n=>`${n}×${k}×${b}=${n*k*b}`,diagram:{kind:'cuboid',labels:['n',String(k),String(b)]}};
 case 'C01':return {kind:'union',text:'红组 n+2 人，蓝组 n+3 人，两组都参加的 n 人。至少参加一组的人数',value:n=>n+5,calculation:n=>`(${n}+2)+(${n}+3)−${n}=${n+5}`,diagram:{kind:'sets',labels:['红 n+2','蓝 n+3','重叠 n']}};
 case 'C02':return {kind:'product',text:`n 种饼干配 ${k} 种饮料，每种各选一种。搭配数`,value:n=>n*k,calculation:n=>`${n}×${k}=${n*k} 种`,diagram:{kind:'tree',labels:['n 种饼干',`${k} 种饮料`]}};
 case 'C03':return {kind:'pairs',text:'从 n 名队员中选两名，先后顺序不计。选法数',value:n=>n*(n-1)/2,calculation:n=>`${n}×(${n}−1)÷2=${n*(n-1)/2}`,diagram:{kind:'pairs',labels:['n 名队员','每组 2 人','不计顺序']}};
 case 'C04':return {kind:'complement',text:'共 2n+8 人，红组 n+2 人，蓝组 n+3 人，重叠 n 人。不参加任何组的人数',value:n=>n+3,calculation:n=>`(2×${n}+8)−[(${n}+2)+(${n}+3)−${n}]=${n+3}`,diagram:{kind:'sets',labels:['全体 2n+8','红 n+2 / 蓝 n+3','重叠 n']}};
 case 'D01':return {kind:'chart',text:`柱形图从 0 开始，每格 ${k} 张，柱顶在第 n 格。张数`,value:n=>n*k,calculation:n=>`${n} 格×${k} 张/格=${n*k} 张`,diagram:{kind:'chart',step:k,labels:['n 格',`每格 ${k} 张`]}};
 case 'D02':return {kind:'mean',text:`三次得分为 n、${b}、${b+4}。平均分`,value:n=>competitionFraction(n+2*b+4,3),calculation:n=>`(${n}+${b}+${b+4})÷3=${competitionFraction(n+2*b+4,3)}`,diagram:{kind:'table',rows:[['第一','第二','第三'],['n',String(b),String(b+4)]]}};
 case 'D03':return {kind:'probability',text:`袋中 n 个红球、${b} 个蓝球，每球等可能取到。取到红球的概率`,value:n=>competitionFraction(n,n+b),calculation:n=>`${n}÷(${n}+${b})=${competitionFraction(n,n+b)}`,diagram:{kind:'balls',labels:['红球 n',`蓝球 ${b}`,'等可能取 1 个']}};
 case 'S01':return {kind:'mirror',text:'一张左右对称的图，左半边 n 个星，轴上没有星。全图星数',value:n=>2*n,calculation:n=>`对称的一对一配对：${n}+${n}=${2*n}`,diagram:{kind:'mirror',labels:['左侧 n 个','轴上 0 个','右侧 ?']}};
 case 'S02':return {kind:'invariant',text:'n 枚硬币均为反面；每步把恰好 2 枚反面改成正面，不再改回。全部变正面所需步数',value:n=>n/2,calculation:n=>`每步反面减少 2 枚，${n}÷2=${n/2} 步`,diagram:{kind:'coins',labels:['反面 n 枚','每步改 2 枚','不改回']}};
 default:throw Error('Unknown competition topic');
 }
}

function competitionConstraintProblem(ids,seed){
 const r=competitionRng(seed),models=ids.map((id,i)=>competitionModel(id,seed+97*(i+1)));
 // Distinct images prevent accidental clue redundancy. The small domain is
 // explicit in the five answer cards, not an unstated range assumption.
 const universe=competitionShuffle([2,4,6,8,10,12,14,16,18,20],r),domain=[];
 const find=start=>{if(domain.length===5)return true;for(let i=start;i<universe.length;i++){const n=universe[i];if(models.every(m=>!domain.some(v=>String(m.value(v))===String(m.value(n))))){domain.push(n);if(find(i+1))return true;domain.pop()}}return false};
 if(!find(0))throw Error('No valid constraint domain');
 const options=domain.slice(0,5),target=options[r(5)],others=competitionShuffle(options.filter(n=>n!==target),r);
 const accepted=ids.length===1?[[target]]:ids.length===2?[[target,...others.slice(0,2)],[target,...others.slice(2)]]:[[target,...others.slice(0,3)],[target,others[0],others[1],others[3]],[target,others[2],others[3]]];
 const clues=models.map((m,i)=>{const allowed=competitionShuffle(accepted[i].map(n=>String(m.value(n))),r);return {topicId:ids[i],modelSeed:seed+97*(i+1),kind:m.kind,allowed,text:m.text+'是 '+allowed.join('、')+' 中的一个。',diagram:m.diagram}});
 const survivors=(omit=-1)=>options.filter(n=>clues.every((clue,i)=>i===omit||clue.allowed.includes(String(models[i].value(n)))));
 if(survivors().length!==1||ids.length>1&&clues.some((_,i)=>survivors(i).length<2))throw Error('Nonessential combination');
 const order=competitionShuffle(ids.map((_,i)=>i),r),steps=[],remaining=[...options];
 for(const i of order){for(let j=remaining.length-1;j>=0;j--)if(!clues[i].allowed.includes(String(models[i].value(remaining[j]))))remaining.splice(j,1);steps.push(`用条件 ${i+1}，留下 ${remaining.join('、')}。`)}
 steps.push('所有条件要一起成立，不能只凭一条条件选答案。');
 const verify=models.map((m,i)=>`条件 ${i+1}：${m.calculation(target)}，在允许的值中。`);
 const omitted=r(ids.length),left=survivors(omitted);
 return {family:'constraints',prompt:'只有一张号码卡同时满足所有条件。它的号码是多少？',options:options.map(String),answer:String(target),clues,
  hints:['先挑一条容易算的条件，划掉不符合的号码卡。','再核对剩下的卡；满足一条条件还不够。'],
  methods:[{name:'逐条排除',steps},{name:'代入验证',steps:[`逐张代入。${target} 满足：`,...verify,'每张其他卡至少违反一条条件。']}],
  extension:{prompt:`如果取消条件 ${omitted+1}，还有几张可能的号码卡？`,answer:String(left.length),solution:`剩下 ${left.join('、')}，共 ${left.length} 张。`},
  verification:options.map(n=>({number:n,checks:clues.map((clue,i)=>({value:String(models[i].value(n)),ok:clue.allowed.includes(String(models[i].value(n)))}))})),
  math:{options:[...options].sort((a,b)=>a-b),target,clues:clues.map((c,i)=>({topicId:c.topicId,model:{kind:models[i].kind,text:models[i].text,diagram:models[i].diagram},allowed:[...c.allowed].sort()}))},ablation:ids.map((_,i)=>survivors(i))};
}

const COMPETITION_INTEGRATED_KEYS={
 'A03,G01':'garden','D03,G01':'areaChance','A03,D03,G01':'gardenChance',
 'D02,R01':'weighted','A03,D02,R01':'fractionWeighted','A03,D02':'fractionMean',
 'L01,R03':'catch','G01,N03':'tiles','C03,D03':'pairChance',
 'C01,D03':'unionChance','C04,D03':'complementChance','A04,R02':'offers',
 'G01,R04':'scaleArea','G01,G05':'similarArea','G06,L04':'coordinateDistance',
 'G02,R01':'angleRatio','N03,R03':'departures','C02,N01':'digitCount','C03,N01':'distinctDigitCount'
};
function competitionNumericOptions(answer,r){
 const a=String(answer),set=new Set([a]);
 if(a.includes('/')){const [n,d]=a.split('/').map(Number);for(const [x,y] of [[n+1,d],[n,d+1],[n+2,d+2],[Math.max(0,n-1),d],[n+1,d+2],[0,1],[1,1]])set.add(competitionFraction(x,y))}
 else {const n=Number(a);for(const delta of competitionShuffle([-2,-1,1,2,3,5,7],r))if(n+delta>=0)set.add(String(n+delta))}
 return competitionShuffle([...set].slice(0,5),r);
}
function competitionIntegratedProblem(ids,seed){
 const family=COMPETITION_INTEGRATED_KEYS[[...ids].sort().join(',')];if(!family)return null;
 const r=competitionRng(seed),k=2+r(3),b=2+r(3);let prompt,answer,diagram,methods,extension,math,hints;
 const method=(name,...steps)=>({name,steps});
 if(['garden','areaChance','gardenChance'].includes(family)){
  const width=2*(3+r(4)),height=4+r(4),cutHeight=1+r(height-1),area=width*height;
  if(family==='garden'){
   answer=String(area/2);prompt=`长 ${width} 米、宽 ${height} 米的花园，有 1/2 种花。没有种花的面积是多少平方米？`;
   methods=[method('先算整体',`${width}×${height}=${area} 平方米。`,`没有种花的也是 1/2：${area}÷2=${answer}。`),method('先切图形',`沿长边分成两半，每半长 ${width/2} 米。`,`${width/2}×${height}=${answer} 平方米。`)];
   extension={prompt:'如果改成 1/4 种花，没有种花的面积是多少平方米？',answer:competitionFraction(3*area,4),solution:`剩下 3/4：${area}×3÷4=${competitionFraction(3*area,4)}。`};
  }else{
   const cutWidth=family==='gardenChance'?width/2:1+r(width-1),patch=cutWidth*cutHeight;
   answer=competitionFraction(patch,area);prompt=family==='gardenChance'?`花园长 ${width} 米、宽 ${height} 米。左侧 1/2 的部分中，底部 ${cutHeight} 米种花。在整座花园等可能随机选一点，落在花区的概率是多少？`:`花园长 ${width} 米、宽 ${height} 米，角落有长 ${cutWidth} 米、宽 ${cutHeight} 米的花区。在整座花园等可能随机选一点，落在花区的概率是多少？`;
   methods=[method('用面积比较',`花区 ${cutWidth}×${cutHeight}=${patch}。整园 ${width}×${height}=${area}。`,`概率=${patch}/${area}=${answer}。`),method('按单位小格数',`把花园分成 ${area} 个面积为 1 的小格。`,`有 ${patch} 格属于花区，等可能取点的概率是 ${answer}。`)];
   extension={prompt:'落在花区外的概率是多少？',answer:competitionFraction(area-patch,area),solution:`用补集：1−${answer}=${competitionFraction(area-patch,area)}。`};
   diagram={kind:'garden',width,height,cutWidth,cutHeight};math={width,height,cutWidth,cutHeight};
  }
  diagram??={kind:'garden',width,height,cutWidth:width/2,cutHeight:height};math??={width,height,shade:'1/2'};
 }else if(['weighted','fractionWeighted','fractionMean'].includes(family)){
  const red=k,blue=b,den=family==='weighted'?1:2,redScore=den===1?2+r(3):3+2*r(2),blueScore=redScore+2*(1+r(2)),total=family==='fractionMean'?3:red+blue;
  const numerator=family==='fractionMean'?redScore+blueScore+blueScore:red*redScore+blue*blueScore;
  answer=competitionFraction(numerator,den*total);
  prompt=family==='fractionMean'?`三次得分为 ${competitionFraction(redScore,den)}、${competitionFraction(blueScore,den)}、${competitionFraction(blueScore,den)}。平均分是多少？`:`红队与蓝队人数比为 ${red}:${blue}。红队每人得 ${competitionFraction(redScore,den)} 分，蓝队每人得 ${competitionFraction(blueScore,den)} 分。所有队员的平均分是多少？`;
  const highCount=family==='fractionMean'?2:blue;
  methods=[method('合计后平均',family==='fractionMean'?'把三次得分合起来。':`按红队 ${red} 人、蓝队 ${blue} 人的一组计算。`,`总分=${competitionFraction(numerator,den)}，平均=${competitionFraction(numerator,den)}÷${total}=${answer}。`),method('从低分补上差额',`先把所有得分看作 ${competitionFraction(redScore,den)}。`,`补上 ${highCount}/${total}×${competitionFraction(blueScore-redScore,den)}，平均为 ${answer}。${family==='fractionMean'?'':'人数不同不能直接平均两种分数。'}`)];
  extension={prompt:'每个人（或每次）的得分都增加 1 分，平均分是多少？',answer:competitionFraction(numerator+den*total,den*total),solution:'总分增加的人均量为 1，所以平均分也增加 1。'};diagram={kind:'table',rows:family==='fractionMean'?[['次数','1','2','3'],['得分',competitionFraction(redScore,den),competitionFraction(blueScore,den),competitionFraction(blueScore,den)]]:[['队伍','人数比','每人得分'],['红',String(red),competitionFraction(redScore,den)],['蓝',String(blue),competitionFraction(blueScore,den)]]};math={red,blue,redScore,blueScore,den,total};
 }else if(family==='catch'){
  const slow=k,fast=k+1,delay=b;answer=String(slow*delay);
  prompt=`小乐每分钟走 ${slow} 米，先走了 ${delay} 分钟；小明从同一点每分钟走 ${fast} 米追赶。小明出发后几分钟追上？`;
  methods=[method('看每分钟缩小多少',`领先 ${slow}×${delay}=${slow*delay} 米。`,`每分钟缩小 ${fast}−${slow}=1 米，需 ${answer} 分钟。`),method('列等量关系',`设追了 t 分钟：${fast}t=${slow}(t+${delay})。`,`两边同时减 ${slow}t，得 t=${answer}。`)];
  extension={prompt:`小乐改成先走 ${delay+1} 分钟，小明出发后几分钟追上？`,answer:String(slow*(delay+1)),solution:`领先变成 ${slow*(delay+1)} 米，差速仍为 1 米/分。`};diagram={kind:'meeting',labels:[`小乐 ${slow} 米/分`,`先走 ${delay} 分`,`小明 ${fast} 米/分`]};math={slow,fast,delay};
 }else if(family==='tiles'){
  const unit=k,w=unit*(2+r(3)),h=unit*(3+r(3)),side=competitionGcd(w,h);answer=String(w*h/(side*side));prompt=`用同样大的正方形砖铺满长 ${w} 米、宽 ${h} 米的地面，不切砖。砖的边长取最大的整数米，需要多少块？`;
  methods=[method('先找最大边长',`边长要同时整除 ${w} 和 ${h}，最大是 ${side}。`,`横向 ${w/side} 块、纵向 ${h/side} 块，共 ${answer} 块。`),method('用面积核对',`地面面积 ${w*h}，每砖面积 ${side*side}。`,`${w*h}÷${side*side}=${answer}；更大边长不能同时整除两边。`)];
  extension={prompt:'地面的长和宽都变成原来的 2 倍，仍用原来的砖，需要多少块？',answer:String(Number(answer)*4),solution:'两个方向的砖数都乘 2，总块数乘 4。'};diagram={kind:'garden',width:w,height:h};math={w,h,side};
 }else if(family==='pairChance'){
  const red=k+1,blue=b,total=red+blue,pairs=total*(total-1)/2,good=red*(red-1)/2;answer=competitionFraction(good,pairs);prompt=`袋中有 ${red} 个红球、${blue} 个蓝球，不放回地随机取出两个球。每一对球等可能，两个都是红球的概率是多少？`;
  methods=[method('数不计顺序的球对',`全部有 ${total}×${total-1}÷2=${pairs} 对。`,`红红有 ${red}×${red-1}÷2=${good} 对，概率=${answer}。`),method('按先后顺序',`第一次红球概率 ${red}/${total}。`,`取走红球后剩 ${red-1} 红、${total-1} 总：相乘得 ${answer}。`)];
  extension={prompt:'两个球不全是红球的概率是多少？',answer:competitionFraction(pairs-good,pairs),solution:`用补集：1−${answer}=${competitionFraction(pairs-good,pairs)}。`};diagram={kind:'balls',red,blue,labels:[`红 ${red} / 蓝 ${blue}`,'不放回取 2 个']};math={red,blue};
 }else if(['unionChance','complementChance'].includes(family)){
  const red=k+3,blue=b+3,both=1+r(Math.min(red,blue)-1),union=red+blue-both,total=union+2+r(4),want=family==='unionChance'?union:total-union;answer=competitionFraction(want,total);prompt=`共有 ${total} 位小朋友，${red} 人参加红组，${blue} 人参加蓝组，其中 ${both} 人两组都参加。等可能随机选一人，${family==='unionChance'?'至少参加一组':'两个组都没参加'}的概率是多少？`;
  methods=[method('先去掉重复',`至少一组：${red}+${blue}−${both}=${union} 人。`,`${family==='unionChance'?union:total+'−'+union+'='+want} 人符合，概率=${answer}。`),method('按互不重叠的区域数',`只红 ${red-both}、只蓝 ${blue-both}、重叠 ${both}、组外 ${total-union}。`,`符合的人数 ${want}，总数 ${total}，概率=${answer}。`)];
  extension={prompt:`${family==='unionChance'?'两个组都没参加':'至少参加一组'}的概率是多少？`,answer:competitionFraction(total-want,total),solution:'与刚才的事件互为补集，概率之和为 1。'};diagram={kind:'sets',labels:[`红 ${red}`,`蓝 ${blue}`,`重叠 ${both} / 全体 ${total}`]};math={red,blue,both,total,want};
 }else if(family==='offers'){
  const count=4*(1+r(3)),price=4*(2+r(3)),fee=2+r(5),first=count*price*3/4+fee,second=count*(price-1),gap=Math.abs(first-second);answer=String(gap);prompt=`买 ${count} 本本子。甲店每本 ${price} 元，全单打七五折，另收 ${fee} 元配送费；乙店每本 ${price-1} 元，免配送费。两店总价相差多少元？`;
  methods=[method('分别算整单',`甲：${count}×${price}×75%+${fee}=${first}。乙：${count}×${price-1}=${second}。`,`差额 ${gap} 元。${gap===0?'两店同价。':(first<second?'甲':'乙')+'便宜。'}`),method('先比折后单价',`甲折后每本 ${price*3/4} 元，先比较 ${count} 本的差额。`,`再把只属于甲的 ${fee} 元费用加回，差额是 ${gap} 元。配送费不能一起打折。`)];
  extension={prompt:'甲店配送费改成 0 元，甲店整单总价是多少元？',answer:String(count*price*3/4),solution:`只去掉配送费：${first}−${fee}=${count*price*3/4}。`};diagram={kind:'table',rows:[['店','单价','规则'],['甲',String(price),'75% + 配送'+fee],['乙',String(price-1),'免配送']]};math={count,price,fee};
 }else if(['scaleArea','similarArea'].includes(family)){
  const w=k+2,h=b+2,factor=2+r(2),old=w*h,next=old*factor*factor;answer=String(next-old);prompt=`长 ${w}、宽 ${h} 的长方形，两条边都放大 ${factor} 倍。面积比原来增加多少？`;
  methods=[method('先算两张图',`原面积 ${w}×${h}=${old}，新面积 ${w*factor}×${h*factor}=${next}。`,`${next}−${old}=${answer}。`),method('先看面积倍数',`边长乘 ${factor}，面积乘 ${factor}²=${factor*factor}。`,`增加了原来的 ${factor*factor-1} 倍：${old}×${factor*factor-1}=${answer}。`)];
  extension={prompt:`如果只有长放大 ${factor} 倍、宽不变，面积是多少？`,answer:String(old*factor),solution:`只有一个方向变，面积只乘 ${factor}。`};diagram={kind:'rectangle',labels:[String(w),String(h),`两边 ×${factor}`]};math={w,h,factor};
 }else if(family==='coordinateDistance'){
  const scale=1+r(3),x=1+r(3),y=1+r(3),dx=3*scale,dy=4*scale;answer=String(5*scale);prompt=`坐标图上 A=(${x},${y})，B=(${x+dx},${y+dy})。从 A 到 B 的直线距离是多少？`;
  methods=[method('补成直角三角形',`横向差 ${dx}，纵向差 ${dy}。`,`距离²=${dx}²+${dy}²=${25*scale*scale}，距离=${answer}。`),method('识别缩放的 3-4-5',`两直角边为 3×${scale}、4×${scale}。`,`斜边也乘 ${scale}，为 5×${scale}=${answer}。沿网格绕行的长度不是直线距离。`)];
  extension={prompt:'若只沿水平和竖直线，从 A 到 B 最短需要走多少单位？',answer:String(dx+dy),solution:`沿网格至少走横向 ${dx} 加纵向 ${dy}，合计 ${dx+dy}。`};diagram={kind:'coordinate',x,y,dx,dy};math={x,y,dx,dy};
 }else if(family==='angleRatio'){
  const ratios=r(2)?[1,2,3]:[2,3,4],sum=ratios.reduce((a,v)=>a+v,0);answer=String(180*ratios[2]/sum);prompt=`三角形的三个内角之比为 ${ratios.join(':')}。最大的角是多少度？`;
  methods=[method('先求一份',`共 ${sum} 份，1 份是 180÷${sum}=${180/sum}°。`,`最大角 ${ratios[2]} 份，为 ${answer}°。`),method('直接看占比',`最大角占全部角的 ${ratios[2]}/${sum}。`,`180×${ratios[2]}/${sum}=${answer}°，三个角加起来必须是 180°。`)];
  extension={prompt:'最大的角比最小的角多多少度？',answer:String(180*(ratios[2]-ratios[0])/sum),solution:`份数相差 ${ratios[2]-ratios[0]}，乘每份 ${180/sum}°。`};diagram={kind:'triangle',labels:ratios.map(v=>v+' 份')};math={ratios};
 }else if(family==='departures'){
  const a=k+1,c=b+2,time=a*c/competitionGcd(a,c),speed=2+r(3);answer=String(time*speed);prompt=`两辆观光车同时出发，之后分别每 ${a} 分钟、${c} 分钟发车一次。一名游客从开始每分钟走 ${speed} 米。下一次两车同时发车时，游客已走多少米？`;
  methods=[method('先找共同时间',`${a} 与 ${c} 的最小公倍数是 ${time} 分钟。`,`${time}×${speed}=${answer} 米。`),method('按发车时刻列举',`两组发车时刻中，0 之后第一次相同是 ${time}。`,`同一个 ${time} 分钟用于路程计算，得到 ${answer} 米。`)];
  extension={prompt:'再下一次两车同时发车时，游客从开始共走多少米？',answer:String(2*time*speed),solution:`共同发车周期是 ${time} 分钟，第二次是 ${2*time} 分钟。`};diagram={kind:'line',labels:[`每 ${a} 分钟`,`每 ${c} 分钟`,`${speed} 米/分`]};math={a,c,speed};
 }else if(['digitCount','distinctDigitCount'].includes(family)){
  const digits=competitionShuffle([1,2,3,4,5,6,7,8,9],r).slice(0,4).sort(),distinct=family==='distinctDigitCount',numbers=[];
  for(const a of digits)for(const c of digits)if((!distinct||a!==c)&&(a+c)%3===0)numbers.push(10*a+c);
  answer=String(numbers.length);prompt=`从数字 ${digits.join('、')} 中各选一个作十位和个位，${distinct?'不能重复用同一个数字':'允许重复'}。能组成多少个被 3 整除的两位数？`;
  methods=[method('按十位有序列举',`符合的数：${numbers.length?numbers.join('、'):'没有'}。`,`没有重复或遗漏，共 ${answer} 个。`),method('先按余数分类',`各位数之和被 3 整除，才能被 3 整除。`,`只配 0+0、1+2、2+1 的余数组${distinct?'，去掉同数字重复':''}，共有 ${answer} 个。`)];
  const alt=[];for(const a of digits)for(const c of digits)if((distinct||a!==c)&&(a+c)%3===0)alt.push(10*a+c);
  extension={prompt:`如果改成${distinct?'允许重复':'不能重复'}，有多少个符合的两位数？`,answer:String(alt.length),solution:`重新检查同一个数字能否用两次，符合的是 ${alt.join('、')||'没有'}。`};diagram={kind:'digits',labels:[digits.join('、'),'十位 □ / 个位 □','被 3 整除']};math={digits,distinct};
 }else throw Error('Missing integrated family');
 hints??=['先找连接两个主题的共同量，再求题目最后问的量。','可以画图、列举或倒推；核对单位和每一条限制。'];
 return {family,prompt,answer,options:competitionNumericOptions(answer,r),diagram,methods,extension,hints,math};
}
// RC59 decoder remains only to read old answers. The active picker never
// requests a constraint-card recipe. A release change must not erase history.
function competitionLegacyCreate(recipe){
 const ids=competitionCanonicalIds(recipe?.topicIds),seed=recipe?.seed,format=recipe?.format??'auto';
 if(!ids.length||ids.length>3||!Number.isInteger(seed)||seed<1||seed>2147483647||!['auto','constraints'].includes(format))throw Error('Invalid competition recipe');
 const core=(format==='auto'?competitionIntegratedProblem(ids,seed):null)||competitionConstraintProblem(ids,seed);
 if(core.options.length!==5||new Set(core.options).size!==5||!core.options.includes(core.answer))throw Error('Invalid competition choices');
 const signature=JSON.stringify({engine:1,topicIds:ids,family:core.family,math:core.math}),id='COMP-'+competitionHash(signature);
 return {id,contentVersion:91,skillId:ids[0]+'.01',phase:'挑战',mode:'competition',prompt:core.prompt,options:core.options,optionIds:core.options.map(v=>id+':'+v),answer:core.options.indexOf(core.answer),competition:{...core,signature,topicIds:ids,recipe:{topicIds:ids,seed,format}}};
}
function competitionCreate(recipe){
 if(recipe?.engine===4)return typeof module!=='undefined'?require('./validation_runtime').create(recipe):ValidationRuntime.create(recipe);
 if(recipe?.engine===3)return typeof module!=='undefined'?require('./competition_reviewed').competitionCreate(recipe):competitionReviewedCreate(recipe);
 if(recipe?.engine===2)return typeof module!=='undefined'?require('./competition_catalog').competitionCreate(recipe):competitionCatalogCreate(recipe);
 if(recipe?.engine!==undefined)throw Error('Unknown competition engine');
 return competitionLegacyCreate(recipe);
}
function competitionValueEqual(input,expected){
 const parse=value=>{const s=String(value).trim();if(/^[-+]?\d+(?:\.\d+)?$/.test(s))return Number(s);if(/^[-+]?\d+\s*\/\s*\d+$/.test(s)){const [a,b]=s.split('/').map(Number);return b?a/b:NaN}return NaN};
 const a=parse(input),b=parse(expected);return Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<1e-10;
}
if(typeof module!=='undefined')module.exports={COMPETITION_VERSION,COMPETITION_TOPIC_IDS,COMPETITION_INTEGRATED_KEYS,competitionModel,competitionCreate,competitionLegacyCreate,competitionConstraintProblem,competitionIntegratedProblem,competitionValueEqual,competitionGcd,competitionDivisors,competitionFraction,competitionRatioText,competitionRng,competitionShuffle,competitionCanonicalIds,competitionNumericOptions,competitionHash};
