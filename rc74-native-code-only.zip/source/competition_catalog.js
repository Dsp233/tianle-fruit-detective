'use strict';
// Curated problem structures come first; selected themes only bound the pool.
// One setting, one question, no quota of tags and no synthetic clue fallback.
const {COMPETITION_CATALOG,COMPETITION_REUSED,competitionEligible,competitionCatalogCreate}=((deps)=>{
const {competitionRng,competitionCanonicalIds,competitionNumericOptions,competitionHash,competitionFraction,competitionIntegratedProblem}=deps;
// Engine-2 math contracts keep their revision across page-only releases.
const COMPETITION_CATALOG_REVISION=92;
const COMPETITION_CATALOG=[];
function competitionRegister(id,topicIds,title,strategy,build){COMPETITION_CATALOG.push({id,topicIds:competitionCanonicalIds(topicIds),title,strategy,build})}
function competitionMethod(name,...steps){return {name,steps}}
function competitionFamily(id,topicIds,title,strategy,build){competitionRegister(id,topicIds,title,strategy,(seed)=>{const r=competitionRng(seed),p=build(r);return {...p,family:id,title,strategy,options:competitionNumericOptions(p.answer,r),hints:p.hints||[p.methods[0].name+'：先找最能简化问题的关系。']}})}
function competitionFactorial(n){let v=1;for(let i=2;i<=n;i++)v*=i;return v}
function competitionChoose(n,k){let v=1;for(let i=1;i<=k;i++)v=v*(n-i+1)/i;return v}
function competitionRouteCount(w,h,blocked=null){const a=Array.from({length:h+1},()=>Array(w+1).fill(0));for(let y=0;y<=h;y++)for(let x=0;x<=w;x++)a[y][x]=blocked&&x===blocked[0]&&y===blocked[1]?0:x===0&&y===0?1:(x?a[y][x-1]:0)+(y?a[y-1][x]:0);return a[h][w]}

competitionFamily('reverseDigits',['A01'],'倒过来的两位数','位值与逆推',r=>{
 const a=3+r(6),b=1+r(a-1),sum=a+b,diff=9*(a-b),answer=String(10*a+b);
 return {prompt:`一个两位数的十位数字比个位数字大，两个数字的和是 ${sum}。把两个数字交换后，数比原来小 ${diff}。原来的数是多少？`,answer,math:{a,b},diagram:{kind:'digits',labels:['原数：十位 □ / 个位 □','交换：十位 □ / 个位 □',`相差 ${diff}`]},methods:[competitionMethod('把位值差拆开',`交换让十位减少 10×(十位−个位)，个位增加同样的数字差。`,`所以数字差为 ${diff}÷9=${a-b}；与和 ${sum} 配合，得到十位 ${a}、个位 ${b}，原数 ${answer}。`),competitionMethod('列出数字对',`先列出和为 ${sum}、十位大于个位的数字对。`,`逐一交换核对差 ${diff}，只有 ${a} 与 ${b} 符合。`)],extension:{prompt:'交换后的数是多少？',answer:String(10*b+a),solution:`把个位放到十位：10×${b}+${a}=${10*b+a}。`}};
});
competitionFamily('groupProducts',['A02'],'不用逐项乘','提取共同部分',r=>{
 const price=13+r(37),a=2+r(7),b=10-a,c=1+r(4),answer=String(price*10-c);
 return {prompt:`同一种贴纸每包 ${price} 枚。小乐先买 ${a} 包，再买 ${b} 包，然后送出 ${c} 枚。他还剩多少枚？`,answer,math:{price,a,b,c},diagram:{kind:'table',rows:[['每包',String(price)+' 枚'],['两次购买',a+' 包 + '+b+' 包'],['送出',c+' 枚']]},methods:[competitionMethod('先合并包数',`${a}+${b}=10 包，先算 10×${price}。`,`再减送出的 ${c}，剩 ${answer} 枚。`),competitionMethod('分别算再合并',`${a}×${price}=${a*price}，${b}×${price}=${b*price}。`,`两次合计后减 ${c}，也得到 ${answer}。共同单价使合并计算更快。`)],extension:{prompt:'如果第二次多买 1 包，最后剩多少枚？',answer:String(Number(answer)+price),solution:`增加一包只需在原答案上加 ${price}。`}};
});
competitionFamily('fractionBackwards',['A03'],'最后剩下的一份','逆推与份数',r=>{
 const left=2+2*r(15),answer=String(3*left);
 return {prompt:`小乐第一天用掉贴纸的 1/2，第二天用掉剩下贴纸的 1/3，最后还剩 ${left} 枚。最初有多少枚？`,answer,math:{left},diagram:{kind:'strip',parts:6,filled:2,labels:['最初分成 6 份','第二天的 1/3 是剩下部分的 1/3']},methods:[competitionMethod('从最后倒着走',`第二天结束剩下第二天开始的 2/3，所以第二天开始有 ${left}÷2×3=${left*3/2} 枚。`,`这又是最初的一半，最初有 ${left*3} 枚。`),competitionMethod('统一看最初的份数',`最初分 6 份：第一天用 3 份，第二天用余下 3 份的 1 份。`,`最后 2 份是 ${left} 枚，6 份就是 ${answer} 枚。两次的分数对应的整体不同。`)],extension:{prompt:'第二天用掉了多少枚？',answer:competitionFraction(left,2),solution:`最后剩 2 份，第二天用 1 份，所以是 ${left}÷2。`}};
});
competitionFamily('percentRoundTrip',['A04'],'涨回去了吗？','基准量变化',r=>{
 const percent=[10,20,25,50][r(4)],start=100*(1+r(12)),answer=String(start*percent*percent/10000);
 return {prompt:`一件商品原价 ${start} 元，先涨价 ${percent}%，再按涨后的价格降价 ${percent}%。最后比原价便宜多少元？`,answer,math:{percent,start},diagram:{kind:'table',rows:[['原价',start+' 元'],['先涨',percent+'%'],['再降',percent+'%（按涨后价）']]},methods:[competitionMethod('逐次换基准',`涨后 ${start}×${1+percent/100}=${start*(1+percent/100)} 元。`,`再乘 ${1-percent/100}，最后比原价少 ${answer} 元。`),competitionMethod('比较两次变化量',`第一次涨 ${start*percent/100} 元。第二次还会对这段涨价降 ${percent}%。`,`这额外降下的 ${start*percent/100}×${percent}/100=${answer} 元就是净损失。`)],extension:{prompt:'最后的价格是多少元？',answer:String(start-Number(answer)),solution:`原价减净损失：${start}−${answer}=${start-Number(answer)}。`}};
});
competitionFamily('squareBorder',['A05'],'只数新边框','平方差与分割',r=>{
 const n=3+r(20),answer=String(4*n+4);
 return {prompt:`小方块排成每行 ${n} 块、共 ${n} 行的正方阵。在外面加一圈宽 1 块的边框，形成更大的正方阵。需要增加多少块？`,answer,math:{n},diagram:{kind:'squareBorder',n},methods:[competitionMethod('大平方减小平方',`新阵每边 ${n+2} 块。`,`${n+2}²−${n}²=${answer} 块。`),competitionMethod('只数四条新边',`上、下各 ${n+2} 块；左、右不再重复数角，各 ${n} 块。`,`2×${n+2}+2×${n}=${answer}，不必计算两个大平方。`)],extension:{prompt:'若边框改成宽 2 块，需要增加多少块？',answer:String(8*n+16),solution:`每边增加 4：${n+4}²−${n}²=${8*n+16}。`}};
});
competitionFamily('ratioEqualize',['R01'],'补到一样多','份数差',r=>{
 const a=1+r(4),b=a+1+r(3),unit=2+r(8),add=(b-a)*unit,answer=String(b*unit);
 return {prompt:`盒中红球与蓝球数量之比是 ${a}:${b}。只加入 ${add} 个红球后，两种球一样多。原来有多少个蓝球？`,answer,math:{a,b,unit},diagram:{kind:'table',rows:[['红球',a+' 份'],['蓝球',b+' 份'],['只增加红球',String(add)+' 个']]},methods:[competitionMethod('抓住份数差',`蓝球比红球多 ${b-a} 份，这就是加入的 ${add} 个。`,`一份 ${unit} 个，蓝球 ${b} 份，共 ${answer} 个。`),competitionMethod('从相等状态倒推',`原红球是蓝球的 ${a}/${b}，两种球的差是蓝球的 ${b-a}/${b}。`,`差 ${add} 个，对应蓝球 ${add}÷(${b-a}/${b})=${answer} 个。`)],extension:{prompt:'原来两种球一共有多少个？',answer:String((a+b)*unit),solution:`原来共 ${a+b} 份，每份 ${unit} 个。`}};
});
competitionFamily('packPrice',['R02'],'怎样买最省','单位率与有限比较',r=>{
 const single=3+r(5),pack=3*single-2-r(single-1),count=7+r(8),packs=Math.floor(count/3),cost=packs*pack+(count%3)*single;
 return {prompt:`一种笔单支 ${single} 元，3 支装每包 ${pack} 元。可以混合买，但必须恰好买 ${count} 支。最少花多少元？`,answer:String(cost),math:{single,pack,count},diagram:{kind:'table',rows:[['单支',single+' 元'],['3 支装',pack+' 元'],['必须恰好买',count+' 支']]},methods:[competitionMethod('用便宜的整包替换',`3 支单买要 ${3*single} 元，比一包贵 ${3*single-pack} 元。`,`所以尽可能买 ${packs} 包，再单买 ${count%3} 支，共 ${cost} 元。`),competitionMethod('按包数列方案',`包数只能为 0 到 ${packs}，每加一包就少买 3 支单支笔。`,`总价每次减少 ${3*single-pack} 元，最后一种方案最省。`)],extension:{prompt:'如果全部单支购买，要多花多少元？',answer:String(count*single-cost),solution:`全部单买 ${count*single} 元，减去最省方案 ${cost} 元。`}};
});
competitionFamily('equalDistanceSpeed',['R03'],'来回平均速度','统一路程',r=>{
 const speed=2+r(20),distance=6*speed,answer=competitionFraction(4*speed,3);
 return {prompt:`小乐沿同一路线往返，去程速度 ${speed} 千米/时，回程速度 ${2*speed} 千米/时。去、回路程相等，中途不停。整个往返的平均速度是多少千米/时？`,answer,math:{speed},diagram:{kind:'line',labels:[`去程：${speed} 千米/时`,`回程：${2*speed} 千米/时`,'两段路程相等']},methods:[competitionMethod('选方便的单程距离',`不妨令单程 ${distance} 千米，去程 6 小时、回程 3 小时。`,`总路程 ${2*distance} 除总时间 9，平均速度 ${answer}。不能直接平均两个速度。`),competitionMethod('按时间份数加权',`回程速度是去程的 2 倍，相同路程用时只有一半。`,`用时比 2:1，所以平均是 (${speed}×2+${2*speed})÷3=${answer}。`)],extension:{prompt:'去程时间是回程时间的几倍？',answer:'2',solution:'相等路程中速度越快用时越少，速度比 1:2 对应用时比 2:1。'}};
});
competitionFamily('oppositeScale',['R04'],'两边怎样配合','乘法比例',r=>{
 const a=2+r(7),b=a+1+r(4),old=10*(1+r(10)),answer=competitionFraction(old*a,b);
 return {prompt:`一个长方形的长变成原来的 ${b}/${a}，面积保持不变。原来的宽是 ${old}，新的宽是多少？`,answer,math:{a,b,old},diagram:{kind:'rectangle',labels:[`长 ×${b}/${a}`,`原宽 ${old}`,'面积不变']},methods:[competitionMethod('面积的两个方向相乘',`长乘 ${b}/${a}，宽必须乘倒数 ${a}/${b}。`,`新宽 ${old}×${a}/${b}=${answer}。`),competitionMethod('取一个方便的原长',`可令原长为 ${a}，原面积 ${a*old}。新长成为 ${b}。`,`新宽 ${a*old}÷${b}=${answer}。原长取多少都不影响宽的变化比例。`)],extension:{prompt:'如果宽也变成原来的相同倍数，面积是原来的几倍？',answer:competitionFraction(b*b,a*a),solution:`两个方向都乘 ${b}/${a}，面积乘它的平方。`}};
});
competitionFamily('balanceCancel',['L01'],'两边都有的先拿走','等量消去',r=>{
 const x=3+r(20),a=2+r(4),b=1+r(10),right=b+x,answer=String(x);
 return {prompt:`天平左边有 ${a+1} 个相同盒子和 ${b} 克砝码，右边有 ${a} 个同样的盒子和 ${right} 克砝码，天平平衡。每个盒子重多少克？`,answer,math:{x,a,b},diagram:{kind:'table',rows:[['左边',(a+1)+' 个盒子 + '+b+' 克'],['右边',a+' 个盒子 + '+right+' 克']]},methods:[competitionMethod('两边拿走相同部分',`两边各拿走 ${a} 个盒子。左边只剩 1 个盒子和 ${b} 克，右边剩 ${right} 克。`,`再拿走同样的 ${b} 克，盒子重 ${right}−${b}=${x} 克。`),competitionMethod('列等式',`设盒子重 t 克：${a+1}t+${b}=${a}t+${right}。`,`合并得到 t=${x}。用原天平两边核对总重量相等。`)],extension:{prompt:'两个这样的盒子共重多少克？',answer:String(2*x),solution:`2×${x}=${2*x}。`}};
});
competitionFamily('tickets',['L02'],'多出的票钱','假设与整数约束',r=>{
 const child=2+r(5),adult=child+2+r(4),people=8+r(13),adults=1+r(people-1),total=adults*adult+(people-adults)*child;
 return {prompt:`${people} 人买票，每人一张。成人票 ${adult} 元，儿童票 ${child} 元，共付 ${total} 元。成人有多少人？`,answer:String(adults),math:{child,adult,people,adults},diagram:{kind:'table',rows:[['成人',adult+' 元/张'],['儿童',child+' 元/张'],['总计',people+' 人，'+total+' 元']]},methods:[competitionMethod('先假设全是儿童',`全是儿童只需 ${people*child} 元，实际多 ${total-people*child} 元。`,`每换成一个成人多 ${adult-child} 元，所以有 ${(total-people*child)}/${adult-child}=${adults} 个成人。`),competitionMethod('列人数与费用关系',`设成人 t 人，儿童 ${people}−t 人。`,`费用 ${adult}t+${child}(${people}−t)=${total}，解得 t=${adults}，人数须为整数。`)],extension:{prompt:'如果成人和儿童各少 1 人，总价少多少元？',answer:String(adult+child),solution:`少一张成人票和一张儿童票，共 ${adult+child} 元。`}};
});
competitionFamily('recurrenceBackwards',['L03'],'把递推倒过来','逆向递推',r=>{
 const first=1+r(8),second=2+r(9),n=5+r(4),seq=[first,second];for(let i=2;i<n;i++)seq.push(seq[i-1]+seq[i-2]);
 return {prompt:`一列数从第 3 项起，每项等于前两项之和。第 ${n-1} 项是 ${seq[n-2]}，第 ${n} 项是 ${seq[n-1]}。第 1 项是多少？`,answer:String(first),math:{first,second,n},diagram:{kind:'table',rows:[['项号',String(n-1),String(n)],['数值',String(seq[n-2]),String(seq[n-1])]]},methods:[competitionMethod('从后往前相减',`前一项 = 当前项−紧邻的前项。`,`依次倒推：${[...seq].reverse().join(' → ')}。所以第一项 ${first}。`),competitionMethod('用未知起点表示',`把前两项写成 a、b，后面依次是 a+b、a+2b、2a+3b……。`,`将最后两个已知数代入，得到 a=${first}、b=${second}；正向核对满足每次相加。`)],extension:{prompt:`第 ${n+1} 项是多少？`,answer:String(seq[n-2]+seq[n-1]),solution:`最后两项相加：${seq[n-2]}+${seq[n-1]}=${seq[n-2]+seq[n-1]}。`}};
});
competitionFamily('linearTable',['L04'],'不用写完整公式','表格中的固定变化',r=>{
 const k=2+r(7),b=1+r(15),x=1+r(5),target=x+4+r(7),answer=k*target+b;
 return {prompt:`一台机器对每个输入都用同一规则：先乘一个固定数，再加一个固定数。输入 ${x} 时输出 ${k*x+b}，输入 ${x+2} 时输出 ${k*(x+2)+b}。输入 ${target} 时输出多少？`,answer:String(answer),math:{k,b,x,target},diagram:{kind:'table',rows:[['输入',String(x),String(x+2),String(target)],['输出',String(k*x+b),String(k*(x+2)+b),'?']]},methods:[competitionMethod('只追踪输入差',`输入增加 2，输出增加 ${2*k}，所以每增加 1 输出增加 ${k}。`,`从 ${x} 到 ${target} 增加 ${target-x}，输出为 ${k*x+b}+${target-x}×${k}=${answer}。`),competitionMethod('找出机器规则',`固定乘数 ${2*k}÷2=${k}，固定加数 ${k*x+b}−${x}×${k}=${b}。`,`输入 ${target}：${target}×${k}+${b}=${answer}。`)],extension:{prompt:'若输入再增加 3，输出增加多少？',answer:String(3*k),solution:`固定加数不变，输出只增加 3×${k}。`}};
});
competitionFamily('divisibleDigits',['N01'],'缺失的数字','整除特征',r=>{
 const a=1+r(8),b=1+r(9),possible=[];for(let x=0;x<=9;x++)for(const tail of [0,5]){const v=1000*a+100*x+10*b+tail;if(v%9===0)possible.push(v)}const answer=String(Math.max(...possible)),digit=Math.floor(Number(answer)/100)%10,tail=Number(answer)%10;
 return {prompt:`四位数 ${a}□${b}□ 能同时被 9 和 5 整除。符合条件的最大四位数是多少？`,answer,math:{a,b},diagram:{kind:'digits',labels:[`${a} □ ${b} □`,'被 9 和 5 整除','求最大的数']},methods:[competitionMethod('先限制末位再看数字和',`末位只可能是 0 或 5。分别补百位，让四个数字的和成为 9 的倍数。`,`符合的数：${possible.join('、')}。最大是 ${answer}。`),competitionMethod('从最大百位往下检验',`先从百位 9 开始往下试，每个百位先检查末位 5，再检查 0。`,`第一次两个整除条件都满足时，百位是 ${digit}、末位是 ${tail}，得到 ${answer}。顺序保证这是最大值。`)],extension:{prompt:'符合条件的四位数有几个？',answer:String(possible.length),solution:`符合的是 ${possible.join('、')}，共 ${possible.length} 个。`}};
});
competitionFamily('factorBalance',['N02'],'因数对靠近一些','因数配对与极值',r=>{
 const product=[24,30,36,40,42,48,54,56,60,63,70,72,80,84,90,96,100,108,120,144][r(20)],pairs=[];for(let a=1;a*a<=product;a++)if(product%a===0)pairs.push([a,product/a]);const best=pairs[pairs.length-1];
 return {prompt:`两个正整数的乘积是 ${product}。它们的和最小是多少？`,answer:String(best[0]+best[1]),math:{product},diagram:{kind:'table',rows:[['乘积',String(product)],['两个数','正整数'],['目标','和尽量小']]},methods:[competitionMethod('列出不重复的因数对',`因数对：${pairs.map(p=>p.join('×')).join('，')}。`,`逐对比较和，最小为 ${best.join('+')}=${best[0]+best[1]}。`),competitionMethod('先找靠近平方根的因数',`乘积固定时，两数靠近通常能让和更小，先检查平方根附近的因数。`,`最近的整数因数对为 ${best.join('、')}；用完整因数表核对，没有更小的和。`)],extension:{prompt:'若不计两个数的顺序，一共有几对？',answer:String(pairs.length),solution:`每个不超过平方根的因数对应唯一一对，共 ${pairs.length} 对。`}};
});
competitionFamily('bells',['N03'],'不要多算出发时刻','共同周期与端点',r=>{
 const a=3+r(8),b=4+r(9);let period=a;while(period%b)period+=a;const duration=period*(2+r(6))+r(period),answer=Math.floor(duration/period);
 return {prompt:`两只铃在开始时同时响，之后分别每 ${a} 分钟和每 ${b} 分钟响一次。在随后 ${duration} 分钟内（包括结束时刻，不算开始时刻），同时响了几次？`,answer:String(answer),math:{a,b,duration},diagram:{kind:'line',labels:[`每 ${a} 分钟`,`每 ${b} 分钟`,`0 之后，到 ${duration} 分钟`] },methods:[competitionMethod('先找共同周期',`下一次同时响是 ${period} 分钟，以后每 ${period} 分钟一次。`,`在 ${duration} 分钟内有 ${answer} 个完整周期。开始的 0 不计。`),competitionMethod('列共同时刻',`列出两种铃声时刻，重合的是 ${Array.from({length:answer},(_,i)=>(i+1)*period).join('、')} 分钟。`,`全部在区间内，共 ${answer} 次；下一次已超过结束时刻。`)],extension:{prompt:`如果也算开始时刻，共有几次同时响？`,answer:String(answer+1),solution:'在刚才的次数上加上 0 时刻的一次。'}};
});
competitionFamily('lastDigit',['N04'],'大指数的小循环','周期与余数',r=>{
 const base=[2,3,7,8][r(4)],exponent=20+r(180),cycle=Array.from({length:4},(_,i)=>(base**(i+1))%10),answer=cycle[(exponent-1)%4];
 return {prompt:`${base} 的 ${exponent} 次方的个位数字是多少？`,answer:String(answer),math:{base,exponent},diagram:{kind:'digits',labels:[`${base} × ${base} × … × ${base}`,`共 ${exponent} 个因子`,'只求个位数字']},methods:[competitionMethod('找末位的循环',`从一次方起，末位依次 ${cycle.join('、')}，4 次一循环。`,`${exponent} 除以 4 余 ${exponent%4}，对到循环中得到 ${answer}；余 0 时看第 4 个。`),competitionMethod('每四个因子成组',`四个 ${base} 的积末位是 ${base**4%10}，再乘本题循环中的末位仍保持那个末位。`,`保留最后 ${exponent%4||4} 个因子核对，末位 ${answer}。`)],extension:{prompt:`${base} 的 ${exponent+1} 次方的个位数字是多少？`,answer:String(cycle[exponent%4]),solution:`在循环中再前进一位，或把原个位 ${answer} 再乘 ${base} 后取个位。`}};
});
competitionFamily('fixedPerimeter',['G01'],'同样的周长','配对与极值',r=>{
 const half=6+r(20),a=Math.floor(half/2),b=half-a,answer=a*b;
 return {prompt:`长方形的长和宽都是正整数，周长是 ${2*half}。它的面积最大是多少？`,answer:String(answer),math:{half},diagram:{kind:'rectangle',labels:[`长 + 宽 = ${half}`,'边长为整数',`周长 ${2*half}`]},methods:[competitionMethod('枚举长宽配对',`长+宽=${half}，依次检查 1 与 ${half-1}、2 与 ${half-2}……。`,`乘积在 ${a} 与 ${b} 时最大，面积 ${answer}。`),competitionMethod('把较长一边挪给较短一边',`设较长边比短边多至少 2，把长减 1、短加 1，周长不变而面积增加。`,`所以最优两边相等或只差 1：${a}、${b}，面积 ${answer}。`)],extension:{prompt:'若周长增加 4，同样要求整数边长，最大面积是多少？',answer:String((a+1)*(b+1)),solution:`长宽和增加 2，最优两边各增加 1。`}};
});
competitionFamily('outsideAngle',['G02'],'外角不用绕远路','角关系',r=>{
 const apex=20+2*r(61),answer=90+apex/2;
 return {prompt:`等腰三角形的顶角是 ${apex}°。把一条腰经过底角的顶点向外延长，形成与这个底角相邻的外角。这个外角是多少度？`,answer:String(answer),math:{apex},diagram:{kind:'isoscelesExterior',apex},methods:[competitionMethod('先求两个相等的底角',`每个底角为 (180−${apex})÷2=${90-apex/2}°。`,`外角与底角合为 180°，所以外角 ${answer}°。`),competitionMethod('用不相邻的两个内角',`外角等于顶角加另一个底角。`,`${apex}+(180−${apex})÷2=90+${apex}/2=${answer}°。`)],extension:{prompt:'两个底角加起来是多少度？',answer:String(180-apex),solution:`三个内角总和 180°，减去顶角 ${apex}°。`}};
});
competitionFamily('overlapSquares',['G03'],'重叠部分数了几次','分割与去重',r=>{
 const n=5+r(8),dx=1+r(n-1),dy=1+r(n-1),overlap=(n-dx)*(n-dy),area=2*n*n-overlap;
 return {prompt:`两个边长都为 ${n} 的正方形，边互相平行。第二个比第一个向右移 ${dx}、向上移 ${dy}。两块正方形合起来覆盖的面积是多少？重叠部分只算一次。`,answer:String(area),math:{n,dx,dy},diagram:{kind:'overlapSquares',n,dx,dy},methods:[competitionMethod('两块相加再减重叠',`重叠长方形的边长是 ${n-dx} 和 ${n-dy}，面积 ${overlap}。`,`2×${n}²−${overlap}=${area}。`),competitionMethod('只加第二块新增的部分',`第一块有 ${n*n}。第二块新增右侧条带 ${dx*n} 和上侧余下条带 ${(n-dx)*dy}。`,`合计 ${n*n}+${dx*n}+${(n-dx)*dy}=${area}。条带的拐角不再重复数。`)],extension:{prompt:'重叠部分的面积是多少？',answer:String(overlap),solution:`重叠边长 ${n-dx} 与 ${n-dy}，相乘得 ${overlap}。`}};
});
competitionFamily('circleRoute',['G04'],'绕圆的两条路','弧长与补路',r=>{
 const sectors=8+r(5),unit=2+r(8),steps=1+r(sectors-1),short=Math.min(steps,sectors-steps),circumference=sectors*unit;
 return {prompt:`圆形跑道长 ${circumference} 米，被标记点分成 ${sectors} 段等长的弧。从 A 顺时针经过 ${steps} 段弧到 B。沿跑道从 A 到 B 的较短路线长多少米？`,answer:String(short*unit),math:{sectors,unit,steps},diagram:{kind:'circleRoute',sectors,steps},methods:[competitionMethod('比较两个方向的段数',`顺时针 ${steps} 段，另一个方向 ${sectors-steps} 段，较短 ${short} 段。`,`每段 ${circumference}÷${sectors}=${unit} 米，较短路线 ${short*unit} 米。`),competitionMethod('先算一条弧再求补弧',`顺时针弧长 ${steps*unit} 米，余下弧长 ${circumference}−${steps*unit}=${(sectors-steps)*unit} 米。`,`取两者较小值 ${short*unit}；经过较多标记点未必是较短方向。`)],extension:{prompt:'较长路线比较短路线长多少米？',answer:String(Math.abs(sectors-2*steps)*unit),solution:`两条弧段数之差为 ${Math.abs(sectors-2*steps)}，乘每段 ${unit} 米。`}};
});
competitionFamily('similarAreaPerimeter',['G05'],'面积比不是边长比','识别平方比例',r=>{
 const a=2+r(4),b=a+1+r(4),unit=3+r(12),perimeter=a*unit;
 return {prompt:`两个相似图形的面积之比是 ${a*a}:${b*b}。较小图形的周长是 ${perimeter}，较大图形的周长是多少？`,answer:String(b*unit),math:{a,b,unit},diagram:{kind:'table',rows:[['小图形面积',a*a+' 份'],['大图形面积',b*b+' 份'],['小图形周长',String(perimeter)]]},methods:[competitionMethod('先还原长度比',`面积比是长度比的平方，长度比为 ${a}:${b}。`,`周长也按长度比变化：${perimeter}÷${a}×${b}=${b*unit}。`),competitionMethod('看每条边如何缩放',`所有对应边都乘 ${b}/${a}，面积才会乘 ${b*b}/${a*a}。`,`边长相加的周长也乘 ${b}/${a}，得到 ${b*unit}。`)],extension:{prompt:'把较小图形所有边放大 2 倍，面积是原来的几倍？',answer:'4',solution:'长度变 2 倍，两个方向共同作用，面积变 2²=4 倍。'}};
});
competitionFamily('ladderShift',['G06'],'梯子两端的交换','勾股与结构识别',r=>{
 const k=1+r(20);
 return {prompt:`一根长 ${5*k} 米的梯子斜靠竖直墙面，底端离墙 ${3*k} 米。把底端移到离墙 ${4*k} 米的位置，梯顶仍贴墙。梯顶下降了多少米？`,answer:String(k),math:{k},diagram:{kind:'right',labels:[`原高度 ?`,`${3*k} → ${4*k}`,`梯长 ${5*k}`]},methods:[competitionMethod('分别求两次高度',`原高度²=${5*k}²−${3*k}²=${16*k*k}，原高度 ${4*k}。`,`新高度²=${5*k}²−${4*k}²=${9*k*k}，新高度 ${3*k}，下降 ${k} 米。`),competitionMethod('识别 3-4-5 的交换',`梯长不变，两次直角边都是 ${k} 倍的 3、4。`,`底端从 3 份变 4 份，高度从 4 份变 3 份，下降一份 ${k}。`)],extension:{prompt:'梯子竖直靠墙时，梯顶比移动后的高度高多少米？',answer:String(2*k),solution:`竖直时高度 ${5*k}，移动后 ${3*k}，相差 ${2*k}。`}};
});
competitionFamily('paintedCube',['G07'],'只有两个面涂色','分类与边界',r=>{
 const n=3+r(15),answer=12*(n-2);
 return {prompt:`一个大正方体的六个面都涂色，再切成每条棱上有 ${n} 个的小正方体。恰好有两个面涂色的小正方体有多少个？`,answer:String(answer),math:{n},diagram:{kind:'cuboid',labels:[`每棱 ${n} 个`,'六面涂色','恰好两面涂色']},methods:[competitionMethod('只数棱的中间',`恰好两面涂色的小块在棱上，但不是角块。每棱 ${n-2} 个。`,`12 条棱，共 12×${n-2}=${answer} 个。角块有 3 面涂色。`),competitionMethod('按三个方向分类',`每个方向有 4 条平行棱，每条去掉两个端点。`,`三个方向合计 3×4×${n-2}=${answer}，分类互不重叠。`)],extension:{prompt:'一个面也没有涂色的小正方体有多少个？',answer:String((n-2)**3),solution:`去掉外层后，里面每边 ${n-2} 个，共 ${n-2}³ 个。`}};
});
competitionFamily('exactlyOneSet',['C01'],'只参加一个组','不重叠分类',r=>{
 const a=6+r(18),b=5+r(18),both=1+r(Math.min(a,b)-1),answer=a+b-2*both;
 return {prompt:`参加棋类组的有 ${a} 人，参加球类组的有 ${b} 人，其中 ${both} 人两组都参加。恰好参加一个组的有多少人？`,answer:String(answer),math:{a,b,both},diagram:{kind:'sets',labels:[`棋 ${a}`,`球 ${b}`,`两组都参加 ${both}`]},methods:[competitionMethod('分别减去两组都参加的人',`只棋 ${a}−${both}=${a-both}，只球 ${b}−${both}=${b-both}。`,`两部分不重叠，合计 ${answer} 人。`),competitionMethod('从至少参加一组再扣掉交集',`至少一组 ${a}+${b}−${both}=${a+b-both}。`,`再减两组都参加的 ${both}，得到 ${answer}。两个“至少”和“恰好”不同。`)],extension:{prompt:'至少参加一个组的有多少人？',answer:String(a+b-both),solution:`两组人数相加时交集重复一次，减 ${both}。`}};
});
competitionFamily('gridDetour',['C02'],'最短路线绕过一点','分类与补集',r=>{
 const w=2+r(4),h=2+r(3),x=1+r(w-1),y=1+r(h-1),all=competitionRouteCount(w,h),through=competitionRouteCount(x,y)*competitionRouteCount(w-x,h-y),good=all-through;
 return {prompt:`方格路从 A 到 B，要向右走 ${w} 段、向上走 ${h} 段；每一步只能向右或向上。点 P 在 A 右方 ${x} 段、上方 ${y} 段。不能经过 P 的最短路线有多少条？`,answer:String(good),math:{w,h,x,y},diagram:{kind:'routes',w,h,x,y},methods:[competitionMethod('先数全部再减经过 P',`全部最短路线 ${all} 条。到 P 有 ${competitionRouteCount(x,y)} 条，从 P 到 B 有 ${competitionRouteCount(w-x,h-y)} 条。`,`经过 P 的 ${through} 条必须去掉，剩 ${all}−${through}=${good}。`),competitionMethod('逐点累加路线数',`A 写 1。每个点的路线数等于左边和下面的路线数之和，P 写 0。`,`按从左下到右上的顺序计算，B 得到 ${good}。这条路线数表直接排除了经过 P 的路。`)],extension:{prompt:'经过 P 的最短路线有多少条？',answer:String(through),solution:`到 P 的走法和从 P 出发的走法可独立配对，相乘得 ${through}。`}};
});
competitionFamily('adjacentLine',['C03'],'相邻的一对','捆绑与位置计数',r=>{
 const n=4+r(5),answer=2*competitionFactorial(n-1);
 return {prompt:`${n} 位不同的小朋友排成一列，其中小乐和小明必须相邻。共有多少种排列？`,answer:String(answer),math:{n},diagram:{kind:'line',labels:[`${n} 位不同的人`,'小乐、小明必须相邻','先后顺序算不同']},methods:[competitionMethod('把两人暂时捆成一块',`两人合成一块，连同其他人共有 ${n-1} 个对象，排法 ${(competitionFactorial(n-1))} 种。`,`块里两人可交换，所以乘 2，得到 ${answer}。`),competitionMethod('先选相邻位置',`相邻位置可从第 1 到第 ${n-1} 位开始，共 ${n-1} 种；两人内部 2 种。`,`其他 ${n-2} 人有 ${competitionFactorial(n-2)} 种排列，乘起来 ${answer}。`)],extension:{prompt:'如果小乐必须紧挨在小明左边，共有多少种排列？',answer:String(competitionFactorial(n-1)),solution:'两人的内部顺序固定，不再乘 2。'}};
});
competitionFamily('digitComplement',['C04'],'至少出现一次','补集与去重',r=>{
 const digit=r(10),length=2+r(2),all=10**length,without=9**length,answer=all-without;
 return {prompt:`有 ${length} 位的数字密码，每位可以用 0 到 9，开头也可以是 0。至少有一位是 ${digit} 的密码有多少个？`,answer:String(answer),math:{digit,length},diagram:{kind:'digits',labels:[Array(length).fill('□').join(' '),'允许开头为 0',`至少一个 ${digit}`]},methods:[competitionMethod('减掉一次也没出现的',`全部 ${length} 位密码 ${all} 个。每位不用 ${digit} 只有 9 种，共 ${without} 个。`,`至少出现一次：${all}−${without}=${answer}。`),competitionMethod('按第一次出现的位置分类',`第一次 ${digit} 在第 j 位：前面每位 9 种，后面每位 10 种。`,`各位置数 ${Array.from({length},(_,j)=>9**j*10**(length-j-1)).join(' + ')}，合计 ${answer}，分类不会重复。`)],extension:{prompt:`恰好最后一位是 ${digit}、前面各位都不是 ${digit} 的密码有多少个？`,answer:String(9**(length-1)),solution:`前 ${length-1} 位各 9 种，最后固定，共 ${9**(length-1)}。`}};
});
competitionFamily('restrictedTeam',['C03'],'不能同时入选','限制组合与分类',r=>{
 const n=6+r(15),all=competitionChoose(n,3),bad=n-2,answer=all-bad;
 return {prompt:`从 ${n} 位不同的小朋友中选 3 人组成小队，不分职位。其中小乐和小明不能同时入选。可以选出多少个不同的小队？`,answer:String(answer),math:{n},diagram:{kind:'line',labels:[`${n} 人中选 3 人`,'不计队内顺序','小乐、小明不能同时入选']},methods:[competitionMethod('减去不允许的小队',`全部 3 人小队 ${all} 个。不允许的小队已固定小乐和小明，第三人有 ${n-2} 种选法。`,`所以 ${all}−${n-2}=${answer} 个。`),competitionMethod('按选中两人的人数分类',`两人都不选：从其余 ${n-2} 人选 3，有 ${competitionChoose(n-2,3)} 个。`,`恰选一个：2×${competitionChoose(n-2,2)}=${2*competitionChoose(n-2,2)} 个。两类相加得 ${answer}。`)],extension:{prompt:'如果必须恰好选中小乐、小明中的一个，可选多少个小队？',answer:String(2*competitionChoose(n-2,2)),solution:`先选这两人中的一个，再从其余 ${n-2} 人中选 2。`}};
});
competitionFamily('chartScale',['D01'],'先读懂每一格','刻度与比例读图',r=>{
 const unit=2+r(8),a=2+r(4),b=2+r(5),c=2+r(4),answer=(b+c)*unit;
 return {prompt:`下面的柱状图从 0 起，每一横格代表相同人数。甲柱高 ${a} 格，表示 ${a*unit} 人；乙柱高 ${b} 格，丙柱高 ${c} 格。乙、丙两组共有多少人？`,answer:String(answer),math:{unit,a,b,c},diagram:{kind:'bars',values:[a,b,c],names:['甲','乙','丙'],known:0,knownValue:a*unit},methods:[competitionMethod('先求每格人数',`${a} 格表示 ${a*unit} 人，每格 ${unit} 人。`,`乙、丙共 ${b+c} 格，表示 ${(b+c)*unit} 人。`),competitionMethod('先看合并柱高与甲的比',`乙丙合并柱高为 ${b+c} 格，是甲的 (${b+c})/${a} 倍。`,`甲人数 ${a*unit} 乘这个倍数，得到 ${answer}。刻度代表人数，不能把格数当人数。`)],extension:{prompt:'三组共有多少人？',answer:String((a+b+c)*unit),solution:`三柱共 ${a+b+c} 格，乘每格 ${unit} 人。`}};
});
competitionFamily('missingAverage',['D02'],'消失的一个数','总量与偏差',r=>{
 const count=4+r(7),mean=8+r(13),other=mean-1-r(4),answer=count*mean-(count-1)*other;
 return {prompt:`${count} 个数的平均数是 ${mean}。删去其中一个后，其余 ${count-1} 个数的平均数是 ${other}。删去的数是多少？`,answer:String(answer),math:{count,mean,other},diagram:{kind:'table',rows:[['原来',count+' 个，平均 '+mean],['删去后',(count-1)+' 个，平均 '+other]]},methods:[competitionMethod('比较两个总和',`原总和 ${count}×${mean}=${count*mean}，余下总和 ${count-1}×${other}=${(count-1)*other}。`,`差就是删去的数 ${answer}。`),competitionMethod('用平均数作基准',`余下每个数相对原平均合计少 ${count-1}×(${mean}−${other})=${(count-1)*(mean-other)}。`,`删去的数必须比原平均多同样的量：${mean}+${(count-1)*(mean-other)}=${answer}。`)],extension:{prompt:'若每个原数都增加 2，原来的平均数是多少？',answer:String(mean+2),solution:'每个数同增 2，平均数也增加 2。'}};
});
competitionFamily('diceSum',['D03'],'哪些结果等可能？','样本空间',r=>{
 const faces=4+r(5),target=faces+1+r(3),pairs=[];for(let a=1;a<=faces;a++)for(let b=1;b<=faces;b++)if(a+b===target)pairs.push([a,b]);
 return {prompt:`同时掷两枚公平的 ${faces} 面骰子，每枚的数字为 1 到 ${faces}。两个数字之和是 ${target} 的概率是多少？`,answer:competitionFraction(pairs.length,faces*faces),math:{faces,target},diagram:{kind:'table',rows:[['第一枚',`1 到 ${faces}`],['第二枚',`1 到 ${faces}`],['目标和',String(target)]]},methods:[competitionMethod('列出有顺序的结果',`全部等可能结果 ${faces*faces} 个。符合的结果：${pairs.map(p=>'('+p.join(',')+')').join('、')}。`,`所以概率 ${pairs.length}/${faces*faces}=${competitionFraction(pairs.length,faces*faces)}。数字和本身并不等可能。`),competitionMethod('固定第一枚找搭档',`第一枚为 a 时，第二枚只能是 ${target}−a，且必须在 1 到 ${faces} 之间。`,`有 ${pairs.length} 个合法 a，每种只配一个结果，得到相同概率。`)],extension:{prompt:`两个数字之和不是 ${target} 的概率是多少？`,answer:competitionFraction(faces*faces-pairs.length,faces*faces),solution:'与原事件互为补集，用 1 减原概率。'}};
});
competitionFamily('foldHoles',['S01'],'展开后会有几个孔','对称中的固定位置',r=>{
 const interior=1+r(4),edge=1+r(4),center=r(2),answer=4*interior+2*edge+center;
 return {prompt:`正方形纸沿水平、竖直中线各折一次，折成四层的小正方形。剪出 ${interior} 个位于内部的孔、${edge} 个位于一条折痕边上的孔${center?'，另在两条折痕的交点剪一个孔':''}。各孔彼此分开，不碰纸的外边。完全展开后有多少个孔？`,answer:String(answer),math:{interior,edge,center},diagram:{kind:'foldHoles',interior,edge,center},methods:[competitionMethod('按孔的位置分类',`内部孔展开变 4 个，单条折痕边上的孔变 2 个，两条折痕交点的孔变 1 个。`,`总数 4×${interior}+2×${edge}${center?'+1':''}=${answer}。不能所有孔都乘 4。`),competitionMethod('分两次展开',`先展开一条折痕，再展开另一条。离开折痕的孔会复制，在折痕上的孔与镜像连成同一个孔。`,`按两次对称逐个追踪，内部各 4 个、折痕边各 2 个${center?'、交点 1 个':''}，共 ${answer}。`)],extension:{prompt:'如果在小正方形内部再剪一个孔，展开后总共多少个孔？',answer:String(answer+4),solution:'新增内部孔会出现 4 个，所以原数加 4。'}};
});
competitionFamily('checkerDomino',['S02'],'剩下够大，还能铺吗？','染色与构造',r=>{
 const w=4+2*r(5),h=2+2*r(6),answer=w*h/2-2;
 return {prompt:`一张 ${w} 列、${h} 行的棋盘，黑白格相间，左上角为黑格。去掉左上角和右下角两个格子。每块骨牌恰好覆盖两个相邻格子，不能重叠或盖到空缺。最多能放几块骨牌？`,answer:String(answer),math:{w,h},diagram:{kind:'checker',w,h},methods:[competitionMethod('先看每块必须覆盖的颜色',`两个被去掉的角都是黑格，剩黑格 ${answer}、白格 ${answer+2}。每块骨牌盖一黑一白。`,`最多 ${answer} 块；把首尾两行从缺口旁横着配对、中间行铺满，能达到这个数。光把剩余格数除以 2 会多算 1 块。`),competitionMethod('画出达到上限的摆法',`第一行从第 2 列向右成对摆，留最右一白格；最后一行从左成对摆，留最左一白格。`,`中间各行全部横着配对，共 ${answer} 块。剩下的两格是白格，所有黑格已用完，不能再多放一块。`)],extension:{prompt:'若不去掉任何格子，最多能放几块？',answer:String(w*h/2),solution:`每行有偶数格，可以两两横着摆，覆盖整个棋盘。`}};
});

// These RC59 natural scenarios keep their original mathematical signatures.
// Routine filler and the unrelated bell/traveller construction are excluded.
const COMPETITION_REUSED=[
 ['weighted',['R01','D02'],'两队平均分','份数与加权'],
 ['fractionWeighted',['A03','R01','D02'],'分数得分的平均','份数与加权'],
 ['catch',['L01','R03'],'什么时候追上？','差速与等量'],
 ['tiles',['N03','G01'],'最大的地砖','公因数与铺排'],
 ['pairChance',['C03','D03'],'不放回取球','组合与样本空间'],
 ['unionChance',['C01','D03'],'抽到组员','去重与概率'],
 ['complementChance',['C04','D03'],'两个组都没参加','补集与容斥'],
 ['offers',['A04','R02'],'折扣和配送费','单位价与整单价'],
 ['angleRatio',['R01','G02'],'角度的份数','整体与比例'],
 ['digitCount',['N01','C02'],'拼出整除的数','余数分类与计数'],
 ['distinctDigitCount',['N01','C03'],'数字不能重复','整除与限制排列'],
 ['coordinateDistance',['L04','G06'],'坐标里的直线距离','坐标与勾股']
];
for(const [family,topics,title,strategy] of COMPETITION_REUSED)competitionRegister('natural-'+family,topics,title,strategy,seed=>({...competitionIntegratedProblem(topics,seed),title,strategy,legacyIdentity:true}));

competitionFamily('routeProbability',['C02','D03'],'随机选一条路线','计数转概率',r=>{
 const w=2+r(4),h=2+r(3),x=1+r(w-1),y=1+r(h-1),all=competitionRouteCount(w,h),through=competitionRouteCount(x,y)*competitionRouteCount(w-x,h-y);
 return {prompt:`从 A 到 B 的最短方格路线都要向右 ${w} 段、向上 ${h} 段。等可能地随机选其中一条完整路线（每条路线被选中的机会相同）。P 在 A 右方 ${x} 段、上方 ${y} 段。选中的路线不经过 P 的概率是多少？`,answer:competitionFraction(all-through,all),math:{w,h,x,y},diagram:{kind:'routes',w,h,x,y},methods:[competitionMethod('先数路线再求比例',`全部最短路线 ${all} 条，经过 P 的有 ${through} 条。`,`不经过的 ${all-through} 条，概率 ${competitionFraction(all-through,all)}。这里等可能的是完整路线。`),competitionMethod('用经过 P 的补集',`到 P 与从 P 到 B 的路线可以配对，共 ${competitionRouteCount(x,y)}×${competitionRouteCount(w-x,h-y)}=${through} 条。`,`经过的概率 ${competitionFraction(through,all)}，用 1 减去它。`)],extension:{prompt:'经过 P 的概率是多少？',answer:competitionFraction(through,all),solution:'与不经过互补，概率之和为 1。'}};
});
competitionFamily('cubeProbability',['G07','D03'],'随机拿到棱块','空间分类转概率',r=>{
 const n=3+r(8),good=12*(n-2),all=n**3;
 return {prompt:`大正方体的六面都涂色，再切成每条棱 ${n} 个的小正方体，把所有小块打散。等可能随机取一块，恰好两个面涂色的概率是多少？`,answer:competitionFraction(good,all),math:{n},diagram:{kind:'cuboid',labels:[`每棱 ${n} 个`,'从全部小块中随机取 1 块','恰好两面涂色']},methods:[competitionMethod('先确定符合的小块',`恰好两个面涂色在棱的中间，12×(${n}−2)=${good} 块。`,`总共 ${n}³=${all} 块，概率 ${competitionFraction(good,all)}。`),competitionMethod('按方向分类后合并',`三个方向各有 4 条棱，每棱 ${n-2} 个符合。`,`每个方向符合 ${4*(n-2)} 块，把三类数量合计，再除全部 ${all} 块。`)],extension:{prompt:'随机取到三个面都涂色的小块的概率是多少？',answer:competitionFraction(8,all),solution:`只有 8 个角块有三个涂色面，概率 8/${all}。`}};
});
competitionFamily('overlapProbability',['G03','D03'],'重叠区域的机会','面积转概率',r=>{
 const n=5+r(7),dx=1+r(n-1),dy=1+r(n-1),overlap=(n-dx)*(n-dy),union=2*n*n-overlap;
 return {prompt:`两块边长 ${n} 的正方形边互相平行，第二块比第一块向右 ${dx}、向上 ${dy}。在两块合起来覆盖的区域中等可能选一点，落在重叠区域的概率是多少？`,answer:competitionFraction(overlap,union),math:{n,dx,dy},diagram:{kind:'overlapSquares',n,dx,dy},methods:[competitionMethod('画出共同覆盖的长方形',`重叠面积 (${n}−${dx})×(${n}−${dy})=${overlap}。`,`可选区域面积 2×${n}²−${overlap}=${union}，概率 ${competitionFraction(overlap,union)}。`),competitionMethod('把整体分成三块',`只第一块 ${n*n-overlap}、只第二块 ${n*n-overlap}、重叠 ${overlap}。`,`分母是这三块之和，不是两块面积直接相加；再求重叠占比。`)],extension:{prompt:'落在恰好一块正方形内的概率是多少？',answer:competitionFraction(union-overlap,union),solution:'在合起来的区域中，恰好一块与重叠互为补集。'}};
});
competitionFamily('ratioUnion',['R01','C01'],'先算参加次数','去重后的份数',r=>{
 const unit=3+r(8),a=2+r(3),b=a+1+r(3),both=1+r(a*unit-1),red=a*unit,blue=b*unit,union=red+blue-both;
 return {prompt:`每个小朋友至少参加棋类组或球类组之一，两组人数比是 ${a}:${b}。共有 ${union} 个不同的小朋友，其中 ${both} 人两组都参加。只参加球类组的有多少人？`,answer:String(blue-both),math:{unit,a,b,both},diagram:{kind:'sets',labels:[`棋 ${a} 份`,`球 ${b} 份`,`总人数 ${union}，重叠 ${both}`]},methods:[competitionMethod('先把重复参加加回来',`两组人数相加会把 ${both} 人数两遍，所以合计参加次数 ${union}+${both}=${red+blue}。`,`共 ${a+b} 份，每份 ${unit} 人；球类 ${blue} 人，减交集 ${both} 得 ${blue-both}。`),competitionMethod('用份数写集合关系',`设一份 t 人，不同人数 ${a}t+${b}t−${both}=${union}。`,`求出 t=${unit}，只球类为 ${b}t−${both}=${blue-both}。`)],extension:{prompt:'只参加棋类组的有多少人？',answer:String(red-both),solution:`棋类共 ${red} 人，减两组都参加的 ${both}。`}};
});
competitionFamily('chartAverage',['D01','D02'],'平均到哪一格？','频数与加权',r=>{
 const values=[2,4,6],counts=[1+r(5),1+r(5),1+r(5)],total=counts.reduce((a,b)=>a+b,0),sum=counts.reduce((a,b,i)=>a+b*values[i],0);
 return {prompt:`柱状图记录所有人的得分：得 2 分、4 分、6 分的人数分别如图（每格代表 1 人）。所有人的平均分是多少？`,answer:competitionFraction(sum,total),math:{counts},diagram:{kind:'bars',values:counts,names:['2 分','4 分','6 分']},methods:[competitionMethod('每个得分乘它的人数',`总人数 ${counts.join('+')}=${total}；总分 2×${counts[0]}+4×${counts[1]}+6×${counts[2]}=${sum}。`,`平均 ${sum}÷${total}=${competitionFraction(sum,total)}，三种分数的人数不同。`),competitionMethod('用中间的 4 分作基准',`先令每人都是 4 分，低分组每人少 2，高分组每人多 2。`,`平均为 4+2×(${counts[2]}−${counts[0]})/${total}=${competitionFraction(sum,total)}。`)],extension:{prompt:'每个人得分增加 1 后，平均分是多少？',answer:competitionFraction(sum+total,total),solution:'每人同增 1，平均也增 1。'}};
});
competitionFamily('parityPermutations',['C03','S02'],'偶数不能挨着','先安排再插空',r=>{
 const n=4+r(5),evens=Math.floor(n/2),odds=n-evens,answer=competitionFactorial(odds)*competitionChoose(odds+1,evens)*competitionFactorial(evens);
 return {prompt:`把 1 到 ${n} 这些不同的数字排成一行，要求任何两个偶数都不相邻。共有多少种排列？`,answer:String(answer),math:{n},diagram:{kind:'digits',labels:[`数字 1 到 ${n}`,'任意两个偶数不能相邻','奇数之间可以相邻']},methods:[competitionMethod('先放奇数再插入偶数',`${odds} 个奇数先排，有 ${competitionFactorial(odds)} 种；产生 ${odds+1} 个空位。`,`选 ${evens} 个空位各放一个偶数，有 ${competitionChoose(odds+1,evens)} 种选法；偶数再排列 ${competitionFactorial(evens)} 种，总共 ${answer}。`),competitionMethod('先确定奇偶位置模式',`先列出所有 ${evens} 个偶数位互不相邻的模式，共 ${competitionChoose(odds+1,evens)} 种。`,`每种模式中奇数可互换、偶数可互换，分别乘 ${competitionFactorial(odds)} 和 ${competitionFactorial(evens)}。`)],extension:{prompt:'如果按从小到大固定奇数的先后，仍允许偶数互换，有多少种？',answer:String(competitionChoose(odds+1,evens)*competitionFactorial(evens)),solution:`奇数只有一种先后顺序，去掉乘数 ${competitionFactorial(odds)}。`}};
});
competitionFamily('recurrenceRemainders',['L03','N04'],'递推里的余数周期','状态与循环',r=>{
 const n=12+r(80),period=[1,1,2,0,2,2,1,0],prefix=[0];for(const v of period)prefix.push(prefix[prefix.length-1]+v);const answer=9*Math.floor(n/8)+prefix[n%8];
 return {prompt:`数列前两项都是 1，从第三项起每项是前两项之和。把前 ${n} 项各自除以 3 后的余数加起来，得到多少？`,answer:String(answer),math:{n},diagram:{kind:'digits',labels:['1、1、2、3、5、8、…','每项都取除以 3 的余数',`加前 ${n} 项的余数`]},methods:[competitionMethod('余数也能递推',`余数依次 ${period.join('、')}，下一对又回到 1、1，于是 8 项循环，每轮和 9。`,`${n}=${Math.floor(n/8)}×8+${n%8}，总和 ${Math.floor(n/8)}×9+${prefix[n%8]}=${answer}。`),competitionMethod('用相邻余数对确认重复',`只知道单个余数相同还不能确定重复；要跟踪相邻两项。`,`从 (1,1) 开始，8 步后同一状态再次出现。完整轮数和剩余前缀分别相加，得到 ${answer}。`)],extension:{prompt:`第 ${n+1} 项除以 3 的余数是多少？`,answer:String(period[n%8]),solution:`第 ${n+1} 项对应循环中第 ${n%8+1} 项，余数 ${period[n%8]}。`}};
});

function competitionEligible(ids){const scope=new Set(competitionCanonicalIds(ids));return COMPETITION_CATALOG.filter(f=>f.topicIds.every(id=>scope.has(id)))}
function competitionCatalogCreate(recipe){
 const family=COMPETITION_CATALOG.find(f=>f.id===recipe?.familyId),seed=recipe?.seed;
 if(recipe?.engine!==2||!family||!Number.isInteger(seed)||seed<1||seed>2147483647)throw Error('Invalid natural competition recipe');
 const core=family.build(seed),ids=[...family.topicIds];
 if(!core.prompt||core.clues||core.family==='constraints'||core.options.length!==5||new Set(core.options).size!==5||!core.options.includes(core.answer)||core.methods.length!==2||!core.extension)throw Error('Invalid natural competition problem');
 // Reusing an unchanged RC59 scenario cannot turn exposure into a fresh try.
 const signature=JSON.stringify({engine:1,topicIds:ids,family:core.family,math:core.math}),id='COMP-'+competitionHash(signature);
 return {id,contentVersion:COMPETITION_CATALOG_REVISION,skillId:ids[0]+'.01',phase:'挑战',mode:'competition',prompt:core.prompt,options:core.options,optionIds:core.options.map(v=>id+':'+v),answer:core.options.indexOf(core.answer),competition:{...core,signature,topicIds:ids,recipe:{engine:2,familyId:family.id,seed}}};
}
return {COMPETITION_CATALOG,COMPETITION_REUSED,competitionEligible,competitionCatalogCreate};
})(typeof module!=='undefined'?require('./competition'):{competitionRng,competitionCanonicalIds,competitionNumericOptions,competitionHash,competitionFraction,competitionIntegratedProblem});
if(typeof module!=='undefined')module.exports={COMPETITION_CATALOG,COMPETITION_REUSED,competitionEligible,competitionCreate:competitionCatalogCreate};
