'use strict';
const CompetitionContentContracts=(()=>{
 function givenText(source,prompt){
  if(!/如图|如表|图中|表中/.test(prompt))return '';
  const d=source.diagram;if(!d)return '';
  if(d.kind==='bars')return '题中数据：'+d.values.map((v,i)=>d.names[i]+'对应'+v+'格'+(d.known===i?'，标注'+d.knownValue+'人':'')).join('；')+'。';
  if(d.kind==='table')return '题中数据：'+d.rows.map(row=>row.join('：')).join('；')+'。';
  if(d.kind==='scene-hiddenL')return '三个小正方形沿大正方形的左上到右下依次顶点相接。阴影是贴着大正方形左边和下边的等宽L形条带，条带宽度等于角上小正方形的边长；左上和右下的小正方形不计入阴影，条带交叠处只算一次。';
  if(d.labels?.length)return '题中条件：'+d.labels.join('；')+'。';
  throw Error('MISSING_TEXTUAL_DIAGRAM_GIVENS');
 }
 function presentation(task,variation){
  const c=task.competition,source=variation?c.extension:c,m=c.math,family=c.recipe.familyId;
  let promptText=variation?source.prompt:task.prompt,conditions=givenText(source,promptText);
  if(family==='natural-coordinateDistance'){
   const points=`A=(${m.x},${m.y})，B=(${m.x+m.dx},${m.y+m.dy})`;
   if(variation)conditions='两点坐标：'+points+'。';
   else promptText=promptText.replace('坐标图上','坐标平面中');
  }
  if(family==='chartAverage'){
   conditions=(variation?'原有人数：':'题中人数：')+m.counts.map((count,i)=>`得 ${2*(i+1)} 分的有 ${count} 人`).join('；')+'。';
   if(!variation)promptText='所有人的得分分为 2 分、4 分、6 分，人数条件如下。所有人的平均分是多少？';
  }
  if(variation&&family==='oppositeScale')promptText=`长和宽都变成原来的 ${m.b}/${m.a}，面积是原来的几倍？`;
  if(!variation&&family==='lShapeArea')promptText=promptText.replace('如图阴影L形','下方文字描述的阴影L形');
  return {promptText,givenText:conditions,narrationText:[promptText,conditions].filter(Boolean).join(' ')};
 }
 function resolve(task,scopeId='main'){
  const c=task.competition,v=scopeId!=='main',source=v?c.extension:c,ps=source.problemState||c.problemState;
  const text=presentation(task,v),rawGoal=typeof ps?.goal==='object'?ps.goal:{},goal={...rawGoal,id:rawGoal.id||c.recipe.familyId+':'+(v?'variation':'main')+':'+(rawGoal.quantityId||rawGoal.targetGroup||'target'),quantityId:rawGoal.quantityId||rawGoal.targetGroup||'target',questionText:text.promptText,unit:rawGoal.unit||source.unit||''};
  const answerContract=ps?.answerContract||source.answerContract||{kind:'exact-rational',value:source.answer,unit:source.unit||''};const math=typeof module!=='undefined'?require('./problem_state'):ProblemState;if(!math.equal(answerContract.value,source.answer)||source.answerContract&&!math.equal(source.answerContract.value,source.answer))throw Error('SCOPE_ANSWER_CONTRACT_MISMATCH');
  return {contractVersion:3,configurationId:c.recipe.configurationId||c.recipe.familyId,scopeId,modelId:c.quality?.modelId||c.quality?.model||c.modelId||'structure-and-domain',goal,answerContract,hints:(v?(source.hints||['比较变式和主问题：已知条件、所求目标或整体发生了什么变化？','按照变式的新条件重新建立数量关系，再检查单位与边界。']):c.hints||[]).map((prompt,i)=>({id:(v?'variation':'main')+'-h'+(i+1),order:i+1,prompt,narrationText:prompt})),diagram:source.diagram||null,...text,diagramRole:'hint',initialDiagramAllowed:false};
 }
 function validate(c){if(!c.goal||!c.answerContract||!c.scopeId)throw Error('INVALID_CONTENT_CONTRACT');return true}
 return {resolve,validate,givenText};
})();
if(typeof module!=='undefined')module.exports=CompetitionContentContracts;
