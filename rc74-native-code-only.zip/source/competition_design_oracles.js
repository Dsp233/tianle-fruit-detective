'use strict';
// Independent checks: concrete people, integer candidates and polygon edges.
// Does not read published answers, generator decision labels or solution text.
const assert=require('assert');
const {oracle:catalogOracle}=require('./test_competition');
const base=require('./competition_catalog');
const {expansionOracle,reviewedTransferOracle}=require('./competition_reviewed_oracles');
const {freshOracle}=require('./competition_fresh_oracles');
const {rulesOracle}=require('./competition_rules_oracle');
const perimeter=points=>points.reduce((total,p,i)=>{const q=points[(i+1)%points.length];return total+Math.abs(q[0]-p[0])+Math.abs(q[1]-p[1])},0);
function designOracle(task,f){
 const c=task.competition,m=c.math,id=f.id;let result;
 if(['natural-weighted','natural-fractionWeighted'].includes(id)&&c.recipe.generatorRevision===3){
  const red=Array(m.red).fill(m.redScore/m.den),blue=Array(m.blue).fill(m.blueScore/m.den),people=[...red,...blue];
  const changed=[...Array(m.blue).fill(m.redScore/m.den),...Array(m.red).fill(m.blueScore/m.den)];
  result={answer:people.reduce((a,b)=>a+b,0)/people.length,extension:changed.reduce((a,b)=>a+b,0)/changed.length};
 }else if(c.recipe.generatorRevision===3&&['packPrice','mixedPacks'].includes(id)){
  const costs=[];
  // Complete independent item-by-item/package enumeration, bounded by one
  // extra package; positive prices make larger redundant purchases unnecessary.
  if(id==='packPrice')for(let boxes=0;boxes<=Math.ceil(m.count/3);boxes++)for(let singles=0;singles<=m.count;singles++)costs.push({n:3*boxes+singles,cost:boxes*m.pack+singles*m.single});
  else for(let small=0;small<=Math.ceil(m.count/4);small++)for(let large=0;large<=Math.ceil(m.count/6);large++)costs.push({n:4*small+6*large,cost:small*m.p+large*m.q});
  result={answer:Math.min(...costs.filter(x=>x.n===m.count).map(x=>x.cost)),extension:Math.min(...costs.filter(x=>x.n>=m.count).map(x=>x.cost))};
 }else if(f.origin==='reviewed-rc60'){
  const original=base.competitionCreate({engine:2,familyId:id,seed:c.recipe.seed});
  assert.deepStrictEqual(m,original.competition.math);
  result={answer:catalogOracle(original).answer,extension:reviewedTransferOracle(id,m)};
 }else if(f.origin==='rc65-rules')result={answer:rulesOracle(m),extension:['packs-only-exact','fraction-of-used'].includes(c.extension.math.variant)?null:rulesOracle(c.extension.math)};
 else result=f.origin==='rc64-structure'?freshOracle(id,m):expansionOracle(id,m);
 if(c.recipe.generatorRevision===3){
  if(id==='fixedPerimeter'){
   const p=c.extension.math,areas=[];for(let a=p.minSide;a<=p.half-p.minSide;a++)areas.push(a*(p.half-a));result.extension=Math.min(...areas);
  }
  if(id==='boundaryNotch'){
   const p=c.extension.math;result.extension=perimeter([[0,0],[p.w,0],[p.w,p.h],[0,p.h]])+perimeter([[0,0],[p.a,0],[p.a,p.b],[0,p.b]]);
  }
  if(id==='rule-packs-enough'){
   const p=c.extension.math.params,costs=[];for(let packages=0;packages<=p.count;packages++)if(packages*p.size===p.count)costs.push(packages*p.pack);result.extension=costs.length?Math.min(...costs):0;
  }
  if(id==='rule-fraction-reverse'){
   const p=c.extension.math.params,first=p.start/p.d1,second=first/p.d2;result.extension=p.start-first-second;
  }
 }
 return result;
}
module.exports={designOracle,perimeter};
