'use strict';
const COMPETITION_EXPANSION=((deps)=>{
 const {competitionRng:rng,competitionFraction:F,competitionNumericOptions:legacyOptions}=deps,out=[];
 const options=(answer,r)=>{if(Number(answer)>=0||String(answer).includes('/'))return legacyOptions(answer,r);const n=Number(answer),values=[n,n-1,n+1,-n,0];for(let k=2;new Set(values).size<5;k++)values.push(n+k);return requireShuffle([...new Set(values)].slice(0,5).map(String),r)};
 const requireShuffle=(a,r)=>{for(let i=a.length-1;i>0;i--){const j=r(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
 const method=(name,...steps)=>({name,steps});
 const change=(prompt,answer,solution)=>({prompt,answer:String(answer),solution,kind:'condition-change'});
 const add=(id,topic,level,title,strategy,insight,build)=>out.push({id,topicIds:[topic],level,title,strategy,insight,build(seed){const r=rng(seed),p=build(r);return {...p,family:id,title,strategy,options:options(String(p.answer),r),answer:String(p.answer),hints:p.hints||[p.methods[0].name+'：先找题目中可以确定的关系。']}}});
 const gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return a};
 const fact=n=>n<2?1:n*fact(n-1);
 const choose=(n,k)=>{let a=1;for(let i=1;i<=k;i++)a=a*(n-i+1)/i;return a};
 add('digitInsert','A01',1,'数字卡','位值比较','比较各个插入位置，前面的数位决定大小',r=>{
  const a=2+r(7),b=1+r(a-1),d=a+1,values=[100*d+10*a+b,100*a+10*d+b,100*a+10*b+d];
  return {prompt:`在两位数 ${10*a+b} 中插入数字 ${d}，原来的两个数字先后不变。能得到的最大三位数是多少？`,answer:Math.max(...values),math:{a,b,d},methods:[method('按数位比较',`可能的数是 ${values.join('、')}。`,`最高位越大，整个数越大，最大为 ${Math.max(...values)}。`)],extension:change('如果求最小三位数，答案是多少？',Math.min(...values),`仍比较同样三个位置，最小为 ${Math.min(...values)}。`)};
 });
 add('numberAppend','A01',2,'末尾的一位','位值等量','添一位会把原数乘十，改变的是数的表示',r=>{
  const n=12+r(76),digit=r(10),gap=9*n+digit;
  return {prompt:`在一个两位数的末尾添上数字 ${digit}，得到的三位数比原数大 ${gap}。原来的两位数是多少？`,answer:n,math:{n,digit},methods:[method('比较添位前后',`添位后等于原数的 10 倍再加 ${digit}。`,`所以差为原数的 9 倍加 ${digit}，原数 (${gap}−${digit})÷9=${n}。`),method('按候选数验证',`原数在 10 到 99 之间，添位后可直接减回原数。`,`验证 ${n}：${10*n+digit}−${n}=${gap}；相邻原数的差额会相差 9，所以答案唯一。`)],extension:change(`改为在原数前面添 ${digit||1}，新数比原数大多少？`,100*(digit||1),`添在前面增加的是 ${digit||1} 个百，原来的两位保持不变。`)};
 });
 add('pairedSum','A02',1,'连续的数字','首尾配对','相同总和的配对可以减少逐项运算',r=>{
  const n=8+2*r(16),answer=n*(n+1)/2;
  return {prompt:`把 1 到 ${n} 的所有整数加起来，和是多少？`,answer,math:{n},methods:[method('首尾配对',`1+${n}、2+${n-1}……，每对都是 ${n+1}，共 ${n/2} 对。`,`所以和是 ${n/2}×${n+1}=${answer}。`),method('正反两行相加',`把这列数正写、倒写，两行同列之和都是 ${n+1}。`,`两倍总和为 ${n}×${n+1}，除以 2 得 ${answer}。`)],extension:change(`只加其中的偶数，和是多少？`,(n/2)*(n/2+1),`偶数是 1 到 ${n/2} 各乘 2，先求这些数的和，再乘 2。`)};
 });
 add('telescopingDifferences','A02',2,'一串差','消去共同项','展开后中间项抵消，只留下端点',r=>{
  const start=12+r(20),n=4+r(12),step=2+r(7),end=start+n*step;
  return {prompt:`计算 (${start+step}−${start})+(${start+2*step}−${start+step})+……+(${end}−${end-step})。省略部分保持同样的相邻两数相减。结果是多少？`,answer:n*step,math:{start,n,step},methods:[method('只看最后留下的数',`展开后，中间的数各有一次加和一次减，会抵消。`,`只剩 ${end}−${start}=${n*step}。`),method('按每一段计算',`每个括号的差都是 ${step}，共有 ${n} 个括号。`,`合计 ${n}×${step}=${n*step}。`)],extension:change('如果去掉第一个括号，结果是多少？',(n-1)*step,`去掉一个差 ${step}，剩 ${n-1} 段；新的起点是 ${start+step}。`)};
 });
 add('neighborProducts','A02',3,'两张乘积卡','分配与抵消','相邻因子的乘积差可化为小量',r=>{
  const n=12+r(35);
  return {prompt:`两张卡分别写着 ${n}×${n} 和 ${n-1}×${n+1}。第一张的结果比第二张大多少？`,answer:1,math:{n},methods:[method('比较增加和减少的部分',`把 ${n-1}×${n+1} 拆成 (${n-1})×${n}+(${n-1})。`,`它比 ${n}×${n} 少 ${n}、又多 ${n-1}，最终少 1。`),method('计算核对',`第一张是 ${n*n}，第二张是 ${(n-1)*(n+1)}。`,`相减为 1。分配比较解释了为何换数字仍有同样结果。`)],extension:change(`第二张改写为 ${n-2}×${n+2}，第一张比它大多少？`,4,'两边各改动 2，展开后中间项抵消，第二张比平方少 2×2=4。')};
 });
 add('fractionDifferentWholes','A03',1,'两盒糖果','确定整体','同样的分数对应不同整体，数量未必相等',r=>{
  const a=4*(3+r(12)),b=3*(3+r(12));
  return {prompt:`甲盒有 ${a} 颗糖，取出 1/4；乙盒有 ${b} 颗糖，取出 1/3。两盒一共取出多少颗？`,answer:a/4+b/3,math:{a,b},methods:[method('分别确定每个分数的整体',`甲的整体是 ${a}，取出 ${a/4}；乙的整体是 ${b}，取出 ${b/3}。`,`相加得 ${a/4+b/3}，不能把两个分数直接作用到同一个整体。`)],extension:change('两盒剩下的糖果一共多少颗？',3*a/4+2*b/3,`从总数 ${a+b} 减去刚才取出的数量；或分别算两个盒子剩下的部分。`)};
 });
 add('fractionSharedRemainder','A03',3,'箱中的球','整体变化的逆推','中途补回固定数量，不能只相乘两次保留比例',r=>{
  const unit=2+2*r(8),add=8*(1+r(5)),total=12*unit,left=5*unit+5*add/8;
  return {prompt:`一箱球先取出原来总数的1/3，再放回 ${add} 个，接着取出现有球的3/8，最后剩 ${left} 个。最初有多少个？`,answer:total,math:{unit,add},methods:[method('逆着还原每次变化',`最后是第三次开始的5/8，所以第三次开始有 ${left}×8÷5=${8*unit+add} 个。`,`减去中途放回的 ${add}，剩 ${8*unit}，这是原来的2/3；再乘3/2，得 ${total}。`),method('先统一最后的整体',`原量的2/3加 ${add} 是最后一次的整体，它的5/8等于 ${left}。`,`先由5/8求这个整体，再扣固定加入量，原来的2/3便确定为 ${8*unit}，原量 ${total}。这是部分与固定量共同限制，而非纯倍率。`)],extension:change('最后一次改为取出最初总数的3/8，其余不变，最后剩多少个？',7*unit/2+add,`这次两个分数都以最初总数为整体，剩原量的7/24，再加中途放回的 ${add} 个，得 ${7*unit/2+add}。`)};
 });
 add('discountOrder','A04',1,'两张优惠券','固定量与百分比','减固定金额与按现价百分比减价的顺序会影响结果',r=>{
  const price=100*(2+r(10)),p=[10,20,25][r(3)],q=[10,20,50][r(3)],final=price*(100-p)/100-q;
  return {prompt:`一件商品原价 ${price} 元，先减价 ${p}%，再减去 ${q} 元优惠券。最后价格是多少元？`,answer:final,math:{price,p,q},methods:[method('按两种优惠的实际基准计算',`第一次按原价减去 ${price*p/100} 元，剩 ${price*(100-p)/100}。`,`第二次是固定金额，再减 ${q} 元，最终 ${final} 元。`)],extension:change(`把顺序改为先减 ${q} 元，再减现价的 ${p}%，最后价格是多少？`,(price-q)*(100-p)/100,`新的百分比基准是 ${price-q}，乘 ${100-p}/100；优惠券也受到百分比影响，两种顺序不再同价。`)};
 });
 add('percentRestore','A04',2,'恢复原价','逆向百分比','回到原价时，下降的基准是已经上涨的价格',r=>{
  const p=[10,20,25,50,60,100][r(6)],answer=F(100*p,100+p);
  return {prompt:`商品先涨价 ${p}%。要按涨后的价格打折恢复原价，应降价百分之几？请填写百分号前的数。`,answer,math:{p},methods:[method('取原价 100 作比较',`原价若为 100，涨后 ${100+p}，需减少 ${p}。`,`降价比例是 ${p}/${100+p}，百分号前的数为 ${answer}。`),method('看需要保留的比例',`恢复原价要保留涨后价的 100/${100+p}。`,`其余部分须去掉，1−100/${100+p}=${p}/${100+p}，换成百分数得 ${answer}%。`)],extension:change(`若先降价 ${p===100?50:p}%，恢复原价应涨价百分之几？`,F(100*(p===100?50:p),100-(p===100?50:p)),`这次基准是降低后的 ${100-(p===100?50:p)} 份，增加的份额要除以这个新基准。`)};
 });
 add('squareBounds','A05',1,'平方之间','平方界限','利用相邻平方确定平方根的位置',r=>{
  const k=3+r(15),n=k*k+1+r(2*k);
  return {prompt:`哪个整数是 √${n} 左边最近的整数？即不超过 √${n} 的最大整数是多少？`,answer:k,math:{k,n},methods:[method('比较相邻的平方',`${k}²=${k*k}，${k+1}²=${(k+1)**2}。`,`因为 ${n} 在这两个平方之间，√${n} 在 ${k} 与 ${k+1} 之间，答案为 ${k}。`)],extension:change(`不小于 √${n} 的最小整数是多少？`,k+1,`这个数不是完全平方数，所以右边最近的整数是 ${k+1}。`)};
 });
 add('signedProduct','A05',3,'三张数字卡','正负分类与极值','最小乘积需要比较一负两正和三负两类',r=>{
  const k=2+r(9),cards=[-4*k,-3*k,-k,0,2*k,5*k],answer=-40*k**3;
  return {prompt:`数字卡 ${cards.join('、')}，任选三张不同的卡，乘积最小是多少？`,answer,math:{k},methods:[method('按负数的个数分类',`负乘积可能来自一负两正，或三个负数。前者最小为 ${-4*k}×${2*k}×${5*k}=${answer}。`,`三负乘积为 ${-12*k**3}，含 0 为 0，其他乘积为正，所以最小为 ${answer}。`),method('有限列举并比较',`三张组合只需列 20 组；先剔除非负乘积。`,`在剩下的负乘积中比较绝对值，最大的负绝对值为 ${40*k**3}，对应最小乘积 ${answer}。`)],extension:change('如果改为任选两张卡，乘积最小是多少？',-20*k*k,`一负一正才为负；绝对值最大的负卡 ${-4*k} 与正卡 ${5*k} 相乘。`)};
 });
 add('ratioTotal','R01',1,'两色积木','整体份数','合计人数或物品数对应比例的总份数',r=>{
  const a=1+r(4),b=a+1+r(4),u=3+r(12);
  return {prompt:`红积木与蓝积木之比为 ${a}:${b}，总共有 ${(a+b)*u} 块。红积木有多少块？`,answer:a*u,math:{a,b,u},methods:[method('把整体分成份',`总共 ${a+b} 份，每份 ${u} 块。`,`红积木 ${a} 份，共 ${a*u} 块。`)],extension:change(`如果只增加 ${b-a} 块红积木，红蓝数量之差是多少？`,(b-a)*(u-1),`原差 ${(b-a)*u}，只增加红色会把差缩小 ${b-a}，剩 ${(b-a)*(u-1)}。`)};
 });
 add('linkedRatios','R01',2,'三色积木','统一共同份额','两个比通过同一种物品衔接',r=>{
  const a=1+r(4),b=2+r(4),c=2+r(4),d=1+r(4),u=2+r(7),red=a*c*u,blue=b*c*u,green=b*d*u;
  return {prompt:`红与蓝积木之比 ${a}:${b}，蓝与绿之比 ${c}:${d}。绿积木有 ${green} 块。三色一共有多少块？`,answer:red+blue+green,math:{a,b,c,d,u},methods:[method('把两个比中的蓝色统一',`把第一个比乘 ${c}，第二个比乘 ${b}，得到红:蓝:绿=${a*c}:${b*c}:${b*d}。`,`绿 ${b*d} 份是 ${green}，一份 ${u}，合计 ${red+blue+green}。`),method('从绿依次反求',`由蓝:绿=${c}:${d} 得蓝 ${blue}；再由红:蓝=${a}:${b} 得红 ${red}。`,`三色相加 ${red}+${blue}+${green}=${red+blue+green}。`)],extension:change('只增加蓝积木，使蓝与绿一样多，需要增加多少块？若蓝已经更多，则填写需要取走的块数。',Math.abs(green-blue),`红蓝与蓝绿两个比都会改变，但绿不变；比较原蓝 ${blue} 与绿 ${green} 的差。`)};
 });
 add('unitConversion','R02',1,'配制饮料','单位统一','相同量先用相同单位表达',r=>{
  const liters=2+r(8),cup=[100,125,250][r(3)];
  return {prompt:`有 ${liters} 升饮料，每杯装 ${cup} 毫升，1 升=1000 毫升。能装满多少杯？`,answer:liters*1000/cup,math:{liters,cup},methods:[method('把总量换成毫升',`${liters} 升是 ${liters*1000} 毫升。`,`每杯 ${cup} 毫升，相除得到 ${liters*1000/cup} 杯。`)],extension:change('杯子的容量改为原来两倍，能装满多少杯？',liters*500/cup,'总量不变、每杯容量加倍，杯数减半。')};
 });
 add('mixedPacks','R02',3,'两种包装','单位价格与整包约束','单价最低未必能组成恰好的购买量',r=>{
  const p=5+r(5),q=p+1+r(4),count=10+2*r(15),legal=[];for(let a=0;a*4<=count;a++)for(let b=0;4*a+6*b<=count;b++)if(4*a+6*b===count)legal.push({a,b,cost:a*p+b*q});const best=Math.min(...legal.map(x=>x.cost));
  return {prompt:`笔只有4支装和6支装，分别 ${p} 元、${q} 元。必须恰好买 ${count} 支，不能拆包。最少花多少元？`,answer:best,math:{p,q,count},methods:[method('列出能恰好组成总数的包装',`合法方案（4支包,6支包）：${legal.map(x=>`(${x.a},${x.b})`).join('、')}。`,`对应费用 ${legal.map(x=>x.cost).join('、')}，最小 ${best}。最低单价的包不一定能单独凑齐。`)],extension:change('如果允许买超过需要的数量，最少花多少元？',(()=>{let v=Infinity;for(let a=0;a<=Math.ceil(count/4);a++)for(let b=0;b<=Math.ceil(count/6);b++)if(4*a+6*b>=count)v=Math.min(v,a*p+b*q);return v})(),'把数量条件由等于改为至少，重新比较边界附近的整包方案。')};
 });
 add('jointWork','R03',1,'一起完成','单位时间工作量','合作时合并的是每分钟完成的量',r=>{
  const a=3+r(7),b=2+r(8),t=3+r(8),total=(a+b)*t;
  return {prompt:`甲每分钟装 ${a} 个盒子，乙每分钟装 ${b} 个。两人一起装 ${total} 个盒子，不停顿，需要几分钟？`,answer:t,math:{a,b,t},methods:[method('先求合作的每分钟工作量',`每分钟共同完成 ${a+b} 个。`,`总量 ${total} 除以 ${a+b}，需要 ${t} 分钟。`)],extension:change('如果只有甲完成同样的总量，需要多少分钟？',F(total,a),`只有甲的速率 ${a}，总量不变，时间为 ${total}/${a}。`)};
 });
 add('riverTravel','R03',2,'顺流与逆流','分解速度','同一水流对两个方向的速度作用相反',r=>{
  const v=6+r(10),c=1+r(v-2),distance=(v*v-c*c)*2;
  return {prompt:`船在静水中速度 ${v} 千米/时，水流 ${c} 千米/时。船沿河顺流 ${distance} 千米，再原路逆流返回，不停顿。整个行程多少小时？`,answer:4*v,math:{v,c,distance},methods:[method('分别计算两个方向',`顺流速度 ${v+c}，逆流速度 ${v-c}。`,`时间分别 ${distance/(v+c)} 与 ${distance/(v-c)} 小时，相加 ${4*v}。`),method('统一两个分母',`总时间 ${distance}/(${v+c})+${distance}/(${v-c})。`,`合并为 ${distance}×${2*v}/${v*v-c*c}=${4*v}。这个式子解释水流造成的往返时间变化。`)],extension:change('如果没有水流，同样的往返需要多少小时？',F(2*distance,v),`两个方向都是静水速度 ${v}，总路程 ${2*distance} 除以它。`)};
 });
 add('mapScale','R04',1,'两张地图','长度缩放','同一实际距离在不同缩放图中作比较',r=>{
  const k=2+r(7),a=3+r(12);
  return {prompt:`同一条路在甲地图长 ${a} 厘米。乙地图上所有长度都是甲地图的 ${k} 倍。这条路在乙地图长多少厘米？`,answer:a*k,math:{k,a},methods:[method('对应长度一起缩放',`每段长度都乘 ${k}。`,`同一条路的长度 ${a}×${k}=${a*k} 厘米。`)],extension:change('把乙地图再缩成其长度的 1/2，这条路是多少厘米？',F(a*k,2),'两次长度倍率相乘，第二次的整体是乙地图。')};
 });
 add('scaleAreaReverse','R04',2,'复印图形','平方倍率与逆推','两次缩放的面积变化可反求长度倍率',r=>{
  const k=2+r(5),s=2+r(4),old=s*s*(2+r(10)),final=old*k*k/(s*s);
  return {prompt:`一幅图先把所有长度放大为 ${k} 倍，再把所有长度缩为当前的 1/${s}。最后面积是 ${final}。原来的面积是多少？`,answer:old,math:{k,s,old},methods:[method('合并长度倍率',`最终长度是原来的 ${k}/${s}，面积倍率为 ${k*k}/${s*s}。`,`把最后面积除以这个倍率，得 ${old}。`),method('逐次倒推面积',`最后一次长度缩为 1/${s}，面积缩为 1/${s*s}，先把面积乘 ${s*s}。`,`第一次长度放大 ${k} 倍，面积放大 ${k*k} 倍，再除以 ${k*k}，得到 ${old}。`)],extension:change('若只完成第一次放大，面积是多少？',old*k*k,`第一次的面积倍率是 ${k*k}，原面积乘它。`)};
 });
 add('ageDifference','L01',2,'几年前','不变的差','年龄一起增长，年龄差保持不变',r=>{
  const past=5+r(11),ago=1+r(past-1),child=past+ago,parent=3*past+ago;
  return {prompt:`现在大人的年龄比孩子大 ${parent-child} 岁。${ago} 年前，大人的年龄是孩子的 3 倍。孩子现在几岁？`,answer:child,math:{child,ago,parent},methods:[method('先求当时的一份年龄',`年龄差不变。那时大人比孩子多 2 份，孩子当时为 ${parent-child}÷2=${(parent-child)/2}。`,`再加回 ${ago} 年，得到 ${child}。`)],extension:change('再过多少年，大人的年龄是孩子的 2 倍？',parent-2*child,`年龄差保持 ${parent-child}。成为 2 倍时孩子年龄等于这个差，减现在年龄。`)};
 });
 add('repeatedMachine','L01',2,'机器的输出','连续等量逆推','同一规则连续使用，未知量出现在嵌套关系中',r=>{
  const x=3+r(15),a=2+r(4),b=1+r(8),final=a*(a*x+b)+b;
  return {prompt:`机器每次把输入乘 ${a}，再加 ${b}。一个数连续通过机器两次后得到 ${final}。最初输入是多少？`,answer:x,math:{x,a,b},methods:[method('按相反次序还原',`最后一步先减 ${b} 再除以 ${a}，得到第一次输出 ${a*x+b}。`,`再减 ${b}、除以 ${a}，还原为 ${x}。`),method('写出两次的等量关系',`两次后等于 ${a*a} 倍原数加 ${a*b+b}。`,`所以原数 (${final}−${a*b+b})÷${a*a}=${x}。`)],extension:change('把每次规则改为先加同样的数、再乘同样的数；原输入通过两次后是多少？',a*(a*(x+b)+b),`改变顺序后，每次加上的 ${b} 也会被乘；按新规则逐次计算。`)};
 });
 add('twoCoins','L02',1,'一袋硬币','人数与差额','总枚数与总金额共同限制两类物品',r=>{
  const n=6+r(15),twos=1+r(n-1),total=n+twos;
  return {prompt:`一袋有 ${n} 枚硬币，只有1元和2元，共 ${total} 元。2元硬币有几枚？`,answer:twos,math:{n,twos},methods:[method('先把每枚当成1元',`每枚先算1元，共 ${n} 元，实际多 ${twos} 元。`,`每枚2元会多出1元，所以有 ${twos} 枚。`)],extension:change('如果取走一枚1元和一枚2元，剩下的总金额是多少？',total-3,'每类各取走一枚，金额减少3元，而不是只减少2元。')};
 });
 add('stampConstraint','L02',3,'邮票方案','整数解与约束','精确总价与每种至少一张限制可行方案',r=>{
  const total=17+r(32),legal=[];for(let a=1;3*a<total;a++)for(let b=1;3*a+5*b<=total;b++)if(3*a+5*b===total)legal.push([a,b]);
  return {prompt:`用3元和5元邮票凑恰好 ${total} 元，两种各至少一张。有多少种不同的张数方案？`,answer:legal.length,math:{total},methods:[method('固定一种邮票逐一检查',`5元邮票可从1张开始，每种数量都检查剩余金额能否分成正整数张3元邮票。`,`合法方案（3元张数,5元张数）为 ${legal.map(v=>v.join(',')).join('；')||'没有'}，共 ${legal.length} 种。`)],extension:change('如果允许某一种邮票完全不用，共有多少种方案？',(()=>{let n=0;for(let a=0;3*a<=total;a++)for(let b=0;3*a+5*b<=total;b++)if(3*a+5*b===total)n++;return n})(),'增加的方案只能来自全用3元或全用5元，需要分别检查整除，不是总能加2。')};
 });
 add('recurrenceForward','L03',1,'下一项','明确递推规则','按给定规则推进，而非猜测有限数列',r=>{
  const a=1+r(8),b=2+r(9),n=4+r(4),seq=[a,b];while(seq.length<n)seq.push(seq.at(-1)+seq.at(-2));
  return {prompt:`数列前两项是 ${a}、${b}，从第三项起，每项等于前两项之和。第 ${n} 项是多少？`,answer:seq[n-1],math:{a,b,n},methods:[method('按规则逐项推进',`依次得到 ${seq.join('、')}。`,`第 ${n} 项是 ${seq[n-1]}，每步都只取紧邻的前两项。`)],extension:change('把前两项交换，规则不变，同一个项号的数是多少？',(()=>{const x=[b,a];while(x.length<n)x.push(x.at(-1)+x.at(-2));return x[n-1]})(),'交换初始条件后要重新推进，不能只把最后答案的数字交换。')};
 });
 add('recurrenceTotal','L03',3,'前几项的和','相邻差与总和','递推关系可变成差，累计时中间项抵消',r=>{
  const a=1+r(5),b=1+r(6),n=5+r(6),seq=[a,b];while(seq.length<n+2)seq.push(seq.at(-1)+seq.at(-2));const sum=seq.slice(0,n).reduce((x,y)=>x+y,0);
  return {prompt:`数列前两项为 ${a}、${b}，从第三项起每项等于前两项之和。前 ${n} 项的和是多少？`,answer:sum,math:{a,b,n},methods:[method('列出并累加',`前 ${n} 项为 ${seq.slice(0,n).join('、')}。`,`相加得到 ${sum}。`),method('把每项改写为相邻两项的差',`第 j 项=第 j+2 项−第 j+1 项。相加时中间项抵消。`,`所以前 ${n} 项的和=第 ${n+2} 项−第2项=${seq[n+1]}−${b}=${sum}。`)],extension:change(`只加第2项到第${n}项，和是多少？`,sum-a,`原累计区间去掉第一项 ${a}。也可从差式的起点重新计算。`)};
 });
 add('machineMeeting','L04',2,'相同的输出','表格差与交点','两种线性规则的差每步固定改变',r=>{
  const x=3+r(15),a=2+r(4),b=1+r(4),c=a+1+r(4),d=(c-a)*x+b;
  return {prompt:`甲机器输出 ${a}×输入+${d}，乙机器输出 ${c}×输入+${b}。输入同一个数时，两台输出相等。这个输入是多少？`,answer:x,math:{x,a,b,c,d},methods:[method('看输出差如何消失',`输入0时甲比乙多 ${d-b}，输入每增加1，乙会多追上 ${c-a}。`,`需要 ${d-b}÷${c-a}=${x} 步，输入为 ${x}。`),method('写出相等的输出',`${a}t+${d}=${c}t+${b}。`,`把共同量移开，(${c-a})t=${d-b}，得 t=${x}。`)],extension:change('如果只给甲的输出再加 1，相等输出时的输入是多少？',F(d-b+1,c-a),`开始差增加1，但每步追赶量不变，新输入为 (${d-b}+1)/${c-a}。`)};
 });
 add('machineOrder','L04',3,'两台机器','函数复合次序','不同机器交换顺序时差可能与输入无关',r=>{
  const a=2+r(5),b=1+r(7),c=2+r(4),d=1+r(8),x=3+r(12),ab=c*(a*x+b)+d,ba=a*(c*x+d)+b;
  return {prompt:`甲把输入乘 ${a} 再加 ${b}，乙把输入乘 ${c} 再加 ${d}。输入 ${x}，先甲后乙与先乙后甲的最终结果相差多少？`,answer:Math.abs(ab-ba),math:{a,b,c,d,x},methods:[method('沿两条路径逐次算',`先甲后乙为 ${ab}，先乙后甲为 ${ba}。`,`相差 ${Math.abs(ab-ba)}。`),method('消去共同的输入部分',`两种结果中，原输入都乘 ${a*c}，这部分相同。`,`只需比较额外部分 ${c*b+d} 与 ${a*d+b}，差仍为 ${Math.abs(ab-ba)}。`)],extension:change('原输入改为原来两倍，两种顺序的结果相差多少？',Math.abs(ab-ba),'输入共同部分一起改变，差只来自加数被乘的不同方式，所以不变。')};
 });
 add('digitDivisor','N01',1,'两位数的个位','整除与数位','按非零个位分类检查整除',r=>{
  const tens=1+r(8),legal=[];for(let d=1;d<=9;d++)if((10*tens+d)%d===0)legal.push(10*tens+d);
  return {prompt:`十位是 ${tens} 的两位数中，有多少个能被自己的非零个位数字整除？`,answer:legal.length,math:{tens},methods:[method('逐个个位检验',`个位从1到9检查，符合的数为 ${legal.join('、')}。`,`共 ${legal.length} 个。个位0不能当作除数。`),method('只检查十位部分',`数为 ${10*tens}+d，d 本来就能被自身整除。`,`只需找能整除 ${10*tens} 的1到9，各对应一个数，仍有 ${legal.length} 个。`)],extension:change('允许个位为0，并把它也当作一个符合的数，规则是否有意义？有意义填1，没有意义填0。',0,'除以0没有定义，不能通过放宽个位条件把这种数加入整除计数。')};
 });
 add('divisibleEleven','N01',3,'四位数字','交错数位与整除','同时控制末位和交错数字和',r=>{
  const a=1+r(8),c=1+r(9),legal=[];for(let b=0;b<=9;b++)for(const d of [0,5]){const n=1000*a+100*b+10*c+d;if(n%11===0)legal.push(n)}
  return {prompt:`四位数 ${a}□${c}□ 能同时被11和5整除。这样的数中最大的是多少？`,answer:Math.max(...legal),math:{a,c},methods:[method('限制末位并检查11的规则',`末位为0或5；千位与十位和减去百位与个位和，要为11的倍数。`,`合法数 ${legal.join('、')}，最大 ${Math.max(...legal)}。`),method('检查有限候选',`百位有10种、末位有2种，共20个候选。`,`从大的候选开始做实际除法，第一个被11整除的是 ${Math.max(...legal)}。`)],extension:change('这样的四位数一共有几个？',legal.length,`检查两种末位和全部百位；本题符合的为 ${legal.join('、')}。`)};
 });
 add('threeDivisors','N02',1,'三个因数','因数配对','恰有三个因数意味着是质数的平方',r=>{
  const limit=20+5*r(17),values=[];for(let n=1;n<=limit;n++){let count=0;for(let d=1;d<=n;d++)if(n%d===0)count++;if(count===3)values.push(n)}
  return {prompt:`从1到 ${limit} 的正整数中，恰好有三个正因数的数有几个？`,answer:values.length,math:{limit},methods:[method('利用因数配对',`恰有三个因数时，除了1和自己，还只有一个平方根因数，而且平方根必须为质数。`,`若平方根是合数，还会有额外的因数对。因此只检查质数的平方，符合的是 ${values.join('、')}，共 ${values.length} 个。`),method('按因数个数核查',`对每个候选列正因数，例如4的因数为1、2、4。`,`完整检查1到 ${limit}，恰好三个的仍为 ${values.join('、')}。`)],extension:change('这些符合的数中最大的一个是多少？',Math.max(...values),`从刚才的质数平方列表取最大值；不是取不超过上限的任意平方。`)};
 });
 add('divisorPowers','N02',2,'因数的选择','指数配对计数','每个质因数的指数可独立选取，平方因数另有限制',r=>{
  const a=2+r(5),b=2+r(4),n=2**a*3**b;
  return {prompt:`整数 ${n}=2的${a}次方×3的${b}次方，有多少个正因数？`,answer:(a+1)*(b+1),math:{a,b},methods:[method('按2和3的指数列出所有因数',`因数中2的指数可选0到 ${a}，3的指数可选0到 ${b}。`,`每种指数对产生唯一因数，共 (${a}+1)×(${b}+1)=${(a+1)*(b+1)}。`),method('按3的指数分组',`先固定3的指数，每组包含 ${a+1} 个不同的2次幂倍数。`,`有 ${b+1} 组，互不重复，总数 ${((a+1)*(b+1))}。`)],extension:change('其中是完全平方数的正因数有几个？',(Math.floor(a/2)+1)*(Math.floor(b/2)+1),'平方因数要求两个质因数的指数都是偶数，分别列出可选的偶数指数再配对。')};
 });
 add('equalBags','N03',1,'相同的礼袋','最大共同分组','每种物品的数量都要被礼袋数整除',r=>{
  const k=2+r(10),a=k*(2+r(5)),b=k*(3+r(5)),bags=gcd(a,b);
  return {prompt:`${a} 颗红糖和 ${b} 颗蓝糖装进尽量多的相同礼袋，每袋两种数量分别相同，全部用完。最多几袋？`,answer:bags,math:{a,b},methods:[method('找两种数量的共同因数',`袋数必须同时整除 ${a} 与 ${b}。`,`最大的共同因数为 ${bags}，每袋分别 ${a/bags}、${b/bags} 颗。`)],extension:change('如果不要求袋数最多，所有可能的袋数有几种？',(()=>{let n=0;for(let d=1;d<=bags;d++)if(bags%d===0)n++;return n})(),'可选袋数就是最大公因数的正因数，不是从1到它的每个数都可行。')};
 });
 add('offsetBells','N03',3,'错开的铃声','共同周期与偏移','先找实际重合起点，再使用共同周期',r=>{
  const a=3+r(8),b=4+r(9),target=a*(2+r(6)),offset=target%b,period=a*b/gcd(a,b);let first=a;while((first-offset)%b)first+=a;
  return {prompt:`甲铃在第0分钟响，以后每 ${a} 分钟响；乙铃第一次在第 ${offset} 分钟响，以后每 ${b} 分钟响。第0分钟之后第一次同时响是在第几分钟？`,answer:first,math:{a,b,offset},methods:[method('列实际时刻找第一个重合',`甲的正时刻为 ${a}、${2*a}、${3*a}……，乙从 ${offset} 起每次加 ${b}。`,`第一次正重合为 ${first}；不能直接把最小公倍数当作这个起点。`)],extension:change('再下一次同时响是第几分钟？',first+period,`相邻两次共同响相差最小公倍数 ${period}，加到实际起点 ${first} 上。`)};
 });
 add('cyclicPosition','N04',1,'环形座位','循环与起点','完整圈不改变位置，余步从真实起点计算',r=>{
  const size=5+r(8),start=1+r(size),steps=10+r(80),answer=(start-1+steps)%size+1;
  return {prompt:`${size} 个座位按顺时针编号1到 ${size}。从 ${start} 号座位开始，每一步走到下一个座位，共走 ${steps} 步，停在哪个号？`,answer,math:{size,start,steps},methods:[method('去掉完整圈',`每 ${size} 步一圈，剩 ${steps%size} 步。`,`从 ${start} 号实际前进这些步，落在 ${answer}。起点不算已经走了一步。`)],extension:change('如果改成逆时针走同样多步，停在哪个号？',((start-1-steps)%size+size)%size+1,'余步数量相同，但方向相反，必须从同一个起点向后走。')};
 });
 add('repeatedOnes','N04',3,'一串1','余数状态循环','添一位引起的余数更新而不是直接处理大数',r=>{
  const n=8+r(60),remainders=[];let v=0;for(let i=0;i<n+1;i++){v=(10*v+1)%7;remainders.push(v)}
  return {prompt:`由 ${n} 个数字1组成的整数，除以7的余数是多少？`,answer:remainders[n-1],math:{n},methods:[method('逐次添位只保留余数',`添一个1后的余数为“原余数×10+1”再除以7取余。`,`前6个余数为1、4、6、5、2、0，之后重复；第 ${n} 个对应 ${remainders[n-1]}。`),method('每6个1成一个整块',`111111能被7整除，后面每添6位时，原块乘10的6次方仍被7整除。`,`完整6位块可以去掉，只需检查尾部 ${n%6} 个1（0个时余数0），得 ${remainders[n-1]}。`)],extension:change('末尾再添一个1，余数是多少？',remainders[n],`使用当前余数×10+1，再对7取余，得到 ${remainders[n]}。`)};
 });
 add('rectangleDiagonalArea','G01',1,'对角线两侧','等底等高','对角线把长方形分成等面积两部分',r=>{
  const w=4+2*r(12),h=3+r(14);
  return {prompt:`一个长方形长 ${w}、宽 ${h}，画一条对角线。对角线一侧的三角形面积是多少？`,answer:w*h/2,math:{w,h},diagram:{kind:'rectangleDiagonal',w,h},methods:[method('比较两边的三角形',`两边都用长方形的长和宽作直角边，面积相等。`,`所以每边占长方形面积一半，${w}×${h}÷2=${w*h/2}。`)],extension:change('只把长增加一半，宽不变，对角线一侧的面积是多少？',3*w*h/4,'总面积随长乘3/2，三角形仍占新长方形的一半。')};
 });
 add('boundaryNotch','G01',3,'凹进去的边','边界替换','凹口横向边抵消，新增的是两条深度边',r=>{
  const w=12+r(15),h=8+r(13),a=2+r(w-4),depth=1+r(h-2);
  return {prompt:`长 ${w}、宽 ${h} 的长方形，在一条长边的中间挖去宽 ${a}、深 ${depth} 的长方形凹口，不碰两个角。新图形的周长是多少？`,answer:2*(w+h)+2*depth,math:{w,h,a,depth},diagram:{kind:'notch',w,h,a,depth},methods:[method('比较被替换的边界',`原来长度 ${a} 的一段消失，凹口底边同样长 ${a}，互相抵消。`,`只新增两条深 ${depth} 的边，周长为 ${2*(w+h)}+${2*depth}=${2*(w+h)+2*depth}。`),method('沿新轮廓逐段数',`水平边合计仍为 ${2*w}，竖直边合计 ${2*h+2*depth}。`,`相加 ${2*w}+${2*h+2*depth}=${2*(w+h)+2*depth}。`)],extension:change('同样大小的缺口如果改在角上，新周长是多少？',2*(w+h),'角缺口去掉两条边、补回相同长度的两条边，周长不变。')};
 });
 add('angleMarks','G02',1,'圆周上的射线','角的等分','同一圆周的等间隔方向对应等角',r=>{
  const marks=[8,10,12,15,18][r(5)],step=1+r(Math.floor(marks/2)),angle=360*step/marks;
  return {prompt:`从圆心画出 ${marks} 条等间隔射线。两条射线沿较短方向相隔 ${step} 段等角，它们之间的角是多少度？`,answer:angle,math:{marks,step},methods:[method('先求一个等角',`一整圈360°，每段 ${360/marks}°。`,`相隔 ${step} 段，总角 ${angle}°。`)],extension:change('沿另一个方向围出的角是多少度？',360-angle,'两个方向围出的角合成360°，用整圈减去刚才的角。')};
 });
 add('polygonTurn','G02',2,'绕多边形走','外角与内角','走一圈的转角总和固定，求的不是内角总和',r=>{
  const n=[5,6,8,9,10,12,15,18][r(8)];
  return {prompt:`沿正 ${n} 边形边界走一圈，每个顶点向同一侧转相同的角。每次转向的角是多少度？`,answer:360/n,math:{n},methods:[method('看回到原方向的总转角',`绕一圈总转向360°，有 ${n} 次相同转角。`,`所以每次 ${360/n}°。`),method('从内角求相邻外角',`每个内角为 (${n}−2)×180÷${n}=${180-360/n}°。`,`转角与内角互补，180−${180-360/n}=${360/n}°。`)],extension:change('如果只走到经过一半数量的顶点，累计转了多少度？顶点数为奇数时，经过 (n−1)/2 个。',Math.floor(n/2)*360/n,'累计转角是每次转角乘实际经过顶点数，不是直接取180°。')};
 });
 add('lShapeArea','G03',1,'L形纸片','补形与分块','同一面积可以用大块减缺口或互不重叠块合成',r=>{
  const w=8+r(13),h=7+r(12),a=2+r(w-3),b=2+r(h-3),answer=w*h-a*b;
  return {prompt:`长 ${w}、宽 ${h} 的长方形纸片，从右上角剪去长 ${a}、宽 ${b} 的长方形。剩下的L形面积是多少？`,answer,math:{w,h,a,b},diagram:{kind:'lShape',w,h,a,b},methods:[method('补回完整长方形',`原面积 ${w*h}，剪去面积 ${a*b}。`,`相减得 ${answer}。`),method('分成不重叠的两块',`下面一块面积 ${w*(h-b)}，左上块面积 ${(w-a)*b}。`,`合计 ${answer}，两块没有重叠。`)],extension:change('改在长方形内部挖去同样大的洞，剩下的面积是多少？',answer,'挖去的位置影响轮廓，但没有改变被挖面积，剩下的面积相同。')};
 });
 add('crossArea','G03',2,'交叉的纸条','重叠扣除','横竖纸条重叠的部分被数两次',r=>{
  const w=10+r(15),h=8+r(14),a=1+r(w-2),b=1+r(h-2),answer=a*h+b*w-a*b;
  return {prompt:`长 ${w}、宽 ${h} 的长方形内，有一条贯穿上下、宽 ${a} 的竖纸条，和一条贯穿左右、宽 ${b} 的横纸条。两条覆盖的面积是多少？交叉处只算一次。`,answer,math:{w,h,a,b},diagram:{kind:'cross',w,h,a,b},methods:[method('合并两条再减交叉',`竖条 ${a*h}，横条 ${b*w}，交叉 ${a*b} 被重复一次。`,`覆盖 ${a*h}+${b*w}−${a*b}=${answer}。`),method('先数没有被覆盖的角块',`未覆盖角块合计可拼成边长 ${w-a}、${h-b} 的长方形，面积 ${(w-a)*(h-b)}。`,`用整张面积 ${w*h} 减去它，得到 ${answer}。`)],extension:change('只在交叉处涂色，其面积是多少？',a*b,`交叉的两边长为 ${a} 与 ${b}，只需计算这块面积。`)};
 });
 add('semicircleBoundary','G04',2,'半圆纸片','弧与直边','半圆边界含半个圆周和一条直径',r=>{
  const radius=2+r(20),circumference=6*radius;
  return {prompt:`一个圆的半径 ${radius}。沿直径剪成两个半圆，取其中一块。计算时取 π=3，这块半圆的周长近似是多少？`,answer:5*radius,math:{radius,circumference},diagram:{kind:'semicircle',radius},methods:[method('沿完整边界计算',`弧长是圆周的一半 ${3*radius}，还要加直径 ${2*radius}。`,`合计 ${5*radius}。这里按题目指定的 π=3 计算近似值。`)],extension:change('把两个半圆沿直径重新拼成原圆，仍取 π=3，外周长近似是多少？',circumference,'两条直径接触后成为内部边，不再计入外周长。')};
 });
 add('circleRingRatio','G04',2,'圆环','面积平方比','圆的长度比要平方后才成为面积比',r=>{
  const r1=2+r(5),r2=r1+1+r(5),answer=F(r2*r2-r1*r1,r2*r2);
  return {prompt:`两个同心圆半径分别 ${r1} 与 ${r2}。圆环面积占大圆面积的几分之几？`,answer,math:{r1,r2},diagram:{kind:'ring',r1,r2},methods:[method('两圆面积作差再比较',`两圆面积为 ${r1*r1}π 与 ${r2*r2}π，圆环为 ${r2*r2-r1*r1}π。`,`除以大圆面积，π消去，得到 ${answer}。`),method('先看小圆所占比例',`小圆占大圆面积 ${F(r1*r1,r2*r2)}。`,`其余就是圆环，用1减去它得 ${answer}。`)],extension:change('两圆半径都加倍，圆环占大圆的比例是多少？',answer,'每个面积都乘4，比例不变；只把圆环面积乘2会混淆长度与面积。')};
 });
 add('shadowSimilarity','G05',1,'同一时刻的影子','对应长度比','同角相似形的对应长度保持同一倍率',r=>{
  const unit=2+r(10),a=2+r(5),b=a+1+r(8);
  return {prompt:`同一时刻，竖直小杆高 ${a}，影长 ${2*a}。旁边竖直大杆的影长 ${2*b*unit}，阳光方向相同。大杆高多少？`,answer:b*unit,math:{a,b,unit},methods:[method('利用两组相似直角三角形',`小杆高与影长为1:2，太阳方向相同使两组对应比例相同。`,`大杆高度是影长的一半，为 ${b*unit}。`)],extension:change('若大杆高度不变，换时刻影长变为刚才的一半，小杆同一时刻的影长是多少？',a,'光照角变化使所有杆的影长同倍率减半，小杆原影长也减半。')};
 });
 add('parallelTriangle','G05',3,'三角形中的线段','相似面积与剩余','对应长度比例控制整个相似区域的面积',r=>{
  const n=3+r(7),k=1+r(n-1),area=n*n*(2+r(8));
  return {prompt:`三角形内画一条与底边平行的线段，截出顶端小三角形。小三角形的边长是原来对应边的 ${k}/${n}。原面积 ${area}，下方梯形的面积是多少？`,answer:area*(n*n-k*k)/(n*n),math:{n,k,area},diagram:{kind:'parallelTriangle',n,k},methods:[method('先求小三角形再扣除',`小三角形面积为原来的 ${k*k}/${n*n}，面积 ${area*k*k/(n*n)}。`,`原面积减去它，下方面积 ${area*(n*n-k*k)/(n*n)}。`),method('先求下方占比',`上方占 ${k*k}/${n*n}，下方占 ${n*n-k*k}/${n*n}。`,`这个比例乘原面积，得到同一结果。`)],extension:change('若线段改为对应边长度的一半，下方梯形占原面积的几分之几？','3/4','上方相似三角形占1/4，下方占3/4；不能把边长的一半直接当面积的一半。')};
 });
 add('coordinateHorizontal','G06',1,'两个点','直角坐标差','同一水平线上的直线距离只需横坐标差',r=>{
  const a=-10+r(10),b=1+r(20),y=2+r(8);
  return {prompt:`A=(${a},${y})，B=(${b},${y})。两点之间的直线距离是多少？`,answer:b-a,math:{a,b,y},methods:[method('沿同一水平线比较坐标',`两点纵坐标一样，不需要斜向距离公式。`,`横向跨过 ${b}−(${a})=${b-a} 个单位。`)],extension:change('若只把两点横坐标都增加5，距离是多少？',b-a,'整段平移，两个坐标的差保持不变。')};
 });
 add('hypotenuseMidpoint','G06',3,'斜边中点','补矩形与距离','斜边中点到直角顶点的距离等于斜边一半',r=>{
  const k=2+2*r(15);
  return {prompt:`直角三角形两条直角边为 ${3*k} 与 ${4*k}。M是斜边中点，M到直角顶点的距离是多少？`,answer:5*k/2,math:{k},diagram:{kind:'hypotenuseMidpoint',k},methods:[method('把中点位置放进坐标',`取直角顶点为(0,0)，斜边两端为(${3*k},0)、(0,${4*k})。中点为(${3*k/2},${2*k})。`,`勾股得距离 ${5*k/2}。`),method('补成矩形看中心',`补成边长 ${3*k}、${4*k} 的矩形，M是两条对角线的交点。`,`矩形对角线相等且互相平分，每半条长 ${5*k/2}，就是所求距离。`)],extension:change('若M改为一条长度为较长直角边的边的中点，到直角顶点的距离是多少？',2*k,'这时沿边直接取一半，不能仍把斜边的一半作为答案。')};
 });
 add('cubeSteps','G07',1,'台阶积木','空间分层','空间形状可以按列或按层无遗漏地计数',r=>{
  const n=4+r(12),answer=n*(n+1)/2;
  return {prompt:`用小正方体搭一排台阶，第1列高1块，第2列高2块，依次到第 ${n} 列高 ${n} 块，每列只有1块宽。总共用了多少小正方体？`,answer,math:{n},methods:[method('按列相加',`列高为1到 ${n}，首尾配对得到总数 ${answer}。`,`每块只属于一列，没有重复。`),method('按水平层数',`最底层有 ${n} 块，上一层 ${n-1} 块，直到顶层1块。`,`各层相加同样得 ${answer}；这是从空间形状的另一方向数。`)],extension:change('如果每列前后厚度都变成2块，总共用了多少块？',2*answer,'每层每列都向后多一块，整个数量加倍，而不是只把最高列加倍。')};
 });
 add('openBox','G07',3,'无盖盒子','展开图与有限优化','折叠决定三个维度，最大体积需要比较整数切角',r=>{
  const side=8+2*r(9),values=[];for(let x=1;2*x<side;x++)values.push({x,v:x*(side-2*x)**2});const max=Math.max(...values.map(v=>v.v));
  return {prompt:`边长 ${side} 的正方形纸，从四角各剪去边长x的小正方形，折成无盖盒子。x为正整数，底边长度必须为正。盒子最大体积是多少？`,answer:max,math:{side},methods:[method('先从展开图确定尺寸',`剪角后高为x，底边为 ${side}−2x。合法x为1到 ${(side-2)/2}。`,`分别比较体积 x×(${side}−2x)²：${values.map(v=>v.v).join('、')}，最大 ${max}。`)],extension:change('如果固定剪角边长为1，盒子底面积是多少？',(side-2)**2,'现在问底面积，不是体积；底的两边都因两个角而各减少2。')};
 });
 add('setOutside','C01',1,'兴趣小组','整体与并集','组外与至少一组把整体分成两块',r=>{
  const a=7+r(10),b=8+r(10),both=1+r(Math.min(a,b)-1),outside=2+r(10),total=a+b-both+outside;
  return {prompt:`共有 ${total} 人，${a} 人参加棋组，${b} 人参加球组，${both} 人两组都参加。两个组都没参加的有多少人？`,answer:outside,math:{a,b,both,total},methods:[method('先求至少参加一组的',`两组合计 ${a}+${b}−${both}=${total-outside} 人。`,`组外 ${total}−${total-outside}=${outside}。`)],extension:change('若每个组各增加一人，而且是同一个原来组外的人，两个组都没参加的还有多少人？',outside-1,'组员计数增加两次，但不同的人只增加一个，组外只减少一个。')};
 });
 add('threeSetExactlyTwo','C01',3,'三个小组','交集的重复次数','三组都参加的人在三个两两交集中被数三次',r=>{
  const ab=2+r(8),ac=2+r(8),bc=2+r(8),triple=1+r(Math.min(ab,ac,bc)),answer=ab+ac+bc-3*triple;
  return {prompt:`参加甲乙两组的 ${ab} 人、甲丙两组的 ${ac} 人、乙丙两组的 ${bc} 人，这些数都包括三组全参加的人。三组全参加有 ${triple} 人。恰好参加两组的有多少人？`,answer,math:{ab,ac,bc,triple},methods:[method('把三组都参加的人从每对中去掉',`只甲乙 ${ab-triple}、只甲丙 ${ac-triple}、只乙丙 ${bc-triple}。`,`三块不重叠，相加 ${answer}。`),method('先识别被数的次数',`三个两两交集相加时，恰好两组的人数一次，三组的人数三次。`,`要去掉三组的全部贡献，减3×${triple}，得 ${answer}。`)],extension:change('至少参加两组的有多少人？',answer+triple,'恰好两组与三组全参加是不重叠两类，把交集加回一次。')};
 });
 add('menuBranches','C02',1,'午餐选择','互斥分支加法','各分支选择数先乘，互斥分支再相加',r=>{
  const rice=2+r(6),dish=2+r(5),noodle=1+r(6);
  return {prompt:`午餐可选一份米饭配一道菜，或只选一份面。米饭 ${rice} 种、菜 ${dish} 种、面 ${noodle} 种。共有多少种午餐？`,answer:rice*dish+noodle,math:{rice,dish,noodle},methods:[method('分别数两种午餐分支',`米饭配菜有 ${rice}×${dish}=${rice*dish} 种，面有 ${noodle} 种。`,`两类互斥，相加 ${rice*dish+noodle}。`)],extension:change('如果还要求每份午餐再选一种饮料，饮料有3种，共有多少种？',3*(rice*dish+noodle),'饮料适用于两种午餐分支，乘3要作用到整份午餐数。')};
 });
 add('binaryNoNeighbors','C02',3,'一排灯','分支列举与约束','限制相邻情况会改变后续可选分支',r=>{
  const n=4+r(8);let count=0;for(let mask=0;mask<2**n;mask++)if(!(mask&(mask<<1)))count++;const totals=[1,2];for(let i=2;i<=n;i++)totals.push(totals[i-1]+totals[i-2]);
  return {prompt:`一排 ${n} 盏灯，每盏可亮或灭，要求没有两盏相邻的灯同时亮。不同的亮灭安排有多少种？`,answer:count,math:{n},methods:[method('从左向右分类延伸',`按第一盏分类：灭时剩下n−1盏自由安排，亮时第二盏必须灭、剩n−2盏自由安排。因此n盏的数量等于前两种规模的数量之和。`,`0盏有1种空安排，1盏有2种。从这里逐级得到 ${totals.map((v,i)=>i+'盏:'+v).join('；')}，所以 ${n} 盏有 ${count} 种，不能直接用2的${n}次方。`)],extension:change('如果第一盏必须亮，其他条件相同，有多少种？',(()=>{let c=0;for(let m=1;m<2**n;m+=2)if(!(m&(m<<1)))c++;return c})(),'第一盏亮会迫使第二盏灭，再对后面剩余位置延伸；不能简单除以2。')};
 });
 add('unorderedPairs','C03',1,'两人搭档','有序去重','两个人的先后顺序不能重复计数',r=>{
  const n=5+r(18);
  return {prompt:`${n} 位不同的小朋友任选两人组成搭档，不分先后。不同搭档有多少对？`,answer:n*(n-1)/2,math:{n},methods:[method('先有序选再去掉重复',`先选一人再选另一人有 ${n}×${n-1} 种，同一对被正反数两次。`,`除以2，得到 ${n*(n-1)/2} 对。`),method('按编号只向后选',`第1人与后面 ${n-1} 人，第2人与后面 ${n-2} 人……。`,`这些搭档互不重复，相加得 ${n*(n-1)/2}。`)],extension:change('如果给两人分别担任队长和记录员，有多少种安排？',n*(n-1),'有职位时交换两人会形成另一种安排，不再除以2。')};
 });
 add('circularSeating','C03',3,'围桌坐下','固定参照与相邻块','圆桌旋转相同，要先固定一个参照位置',r=>{
  const n=4+r(5);
  return {prompt:`${n} 位不同的小朋友围圆桌坐，整体旋转视为同一种，左右镜像视为不同。小乐、小明必须相邻。共有多少种坐法？`,answer:2*fact(n-2),math:{n},methods:[method('固定小乐再安排',`固定小乐，消去整体旋转。小明可坐其左边或右边2种。`,`其余 ${n-2} 人排列，共2×${fact(n-2)}=${2*fact(n-2)}。`),method('把相邻两人合成一块',`两人当一块，圆桌上有 ${n-1} 个对象，固定一块后有 ${fact(n-2)} 种顺序。`,`块内顺序2种，合计 ${2*fact(n-2)}。`)],extension:change('如果去掉两人相邻的限制，共有多少种坐法？',fact(n-1),'固定一人以后，其他n−1人的顺序都可选。')};
 });
 add('differentDigits','C04',1,'两位密码','补集','总数减去重复数字的密码',r=>{
  const digits=3+r(12);
  return {prompt:`密码有两位，每位可从 ${digits} 个不同符号中选一个。两位必须不同，一共有多少个密码？`,answer:digits*(digits-1),math:{digits},methods:[method('减去两位一样的',`全部 ${digits*digits} 个，两位相同有 ${digits} 个。`,`减去得 ${digits*(digits-1)}。`),method('直接限制第二位',`第一位 ${digits} 种，第二位不能重复，剩 ${digits-1} 种。`,`相乘得到 ${digits*(digits-1)}。`)],extension:change('如果交换两位也算同一个密码，共有多少个？',digits*(digits-1)/2,'每个不同符号对原来有两种顺序，现在两种合为一种。')};
 });
 add('allThreeColors','C04',3,'三色旗串','容斥','去掉缺色时，只有一种色的安排会被重复扣除',r=>{
  const n=4+r(6),answer=3**n-3*2**n+3;
  return {prompt:`一串 ${n} 面小旗，每个位置可用红、蓝、绿之一，位置顺序算不同。要求三种颜色都出现。共有多少种旗串？`,answer,math:{n},methods:[method('从全部安排中排除缺色',`全部3的${n}次方种。缺少指定一种色有2的${n}次方种，三种缺色都要扣。`,`只有一种颜色的三种旗串被各扣两次，要各加回一次，得到 ${answer}。`),method('按第一次出现和实际用色检查',`列出所有 ${3**n} 个有顺序色串，筛掉只用1色或2色的。`,`恰好3色的计数为 ${answer}；这种列举可作为容斥的独立核对。`)],extension:change('如果只要求恰好使用两种颜色，共有多少种？',3*(2**n-2),'先选缺哪一种颜色3种，每种仅用另两色但两色都出现，所以减去两种纯色。')};
 });
 add('truncatedBars','D01',2,'人数柱状图','刻度起点','柱高差不是从零开始的人数之比',r=>{
  const base=20+5*r(13),step=2+r(7),a=2+r(5),b=a+1+r(4),total=2*base+(a+b)*step;
  return {prompt:`柱状图的纵轴从 ${base} 人开始，每格 ${step} 人。甲柱高出起点 ${a} 格，乙柱高出起点 ${b} 格。两组实际一共有多少人？`,answer:total,math:{base,step,a,b},diagram:{kind:'truncatedBars',base,step,a,b},methods:[method('给每根柱子加回起点',`甲 ${base+a*step}，乙 ${base+b*step}。`,`相加 ${total}。只把柱子的可见高度相加会漏掉两次起点。`)],extension:change('乙组比甲组多多少人？',(b-a)*step,'比较差时共同起点会抵消，只有格数差乘每格人数。')};
 });
 add('cumulativeChart','D01',3,'累计统计表','累计与分段','累计记录相减才得到一段的实际数量',r=>{
  const a=2+r(9),b=2+r(9),c=2+r(9),d=2+r(9);
  return {prompt:`表格列出一次投篮活动“得分不超过某值”的累计人数。≤1分 ${a} 人，≤2分 ${a+b} 人，≤3分 ${a+b+c} 人，≤4分 ${a+b+c+d} 人。恰好2分或3分的有多少人？`,answer:b+c,math:{a,b,c,d},diagram:{kind:'table',rows:[['得分不超过','1','2','3','4'],['累计人数',a,a+b,a+b+c,a+b+c+d]]},methods:[method('从区间末端减起点之前',`≤3分包括1、2、3，去掉≤1分，只剩2、3。`,`${a+b+c}−${a}=${b+c}。`),method('恢复每档人数',`恰好2分=${a+b}−${a}=${b}；恰好3分=${a+b+c}−${a+b}=${c}。`,`两档相加 ${b+c}。不能把两个累计人数直接加。`)],extension:change('恰好4分的人有多少？',d,`≤4减≤3，得到 ${d}。`)};
 });
 add('medianSort','D02',1,'五次成绩','排序与中位数','中位数由位置决定，极端值未必改变它',r=>{
  const start=3+r(15),gap=1+r(7),values=[start+4*gap,start,start+3*gap,start+gap,start+2*gap];
  return {prompt:`五次成绩为 ${values.join('、')}。中位数是多少？`,answer:start+2*gap,math:{start,gap},methods:[method('先排序再找中间位置',`排序为 ${[...values].sort((a,b)=>a-b).join('、')}。`,`五个数的第三个为 ${start+2*gap}。中位数不是未排序列表的中间一项。`)],extension:change('把最大成绩增加100，中位数是多少？',start+2*gap,'只改变最大的一项，第三个位置仍然相同；平均数则会改变。')};
 });
 add('overlapAverages','D02',3,'重叠的平均数','总和与重复','两段平均数转换为总和后，重复部分可反求',r=>{
  const values=Array.from({length:7},()=>3+r(20)),first=values.slice(0,4).reduce((a,b)=>a+b,0),last=values.slice(3).reduce((a,b)=>a+b,0),sum=values.reduce((a,b)=>a+b,0);
  return {prompt:`7个数，前4个平均 ${F(first,4)}，后4个平均 ${F(last,4)}，全部平均 ${F(sum,7)}。第4个数是多少？`,answer:values[3],math:{values},methods:[method('比较两段总和与整体',`前4总和 ${first}，后4总和 ${last}，整体总和 ${sum}。`,`两段相加把第4个重复一次，故第4个=${first}+${last}−${sum}=${values[3]}。`),method('先求其余三项的总和',`整体减后4项，得到前3项总和 ${sum-last}。`,`前4总和再减前3总和，剩第4项 ${values[3]}。`)],extension:(()=>{const v=[...values,values[0],values[6]],a=v.slice(0,5).reduce((s,x)=>s+x,0),b=v.slice(4).reduce((s,x)=>s+x,0),t=v.reduce((s,x)=>s+x,0);return change(`另有9个数，前5个平均 ${F(a,5)}，后5个平均 ${F(b,5)}，全部平均 ${F(t,9)}。第5个数是多少？`,v[4],`这次两段总和分别为 ${a} 与 ${b}，全部总和为 ${t}；重叠的第5个是 ${a}+${b}−${t}=${v[4]}。人数和重叠位置变化，仍先还原总和。`)})()};
 });
 add('spinnerLabels','D03',1,'转盘的字母','等可能区域','字母重复出现时字母本身不等可能',r=>{
  const a=1+r(7),b=1+r(7),c=1+r(7),size=a+b+c;
  return {prompt:`转盘有 ${size} 个等面积扇区，A写在 ${a} 个，B写在 ${b} 个，C写在 ${c} 个。每个扇区被转中的机会相同。转中A或B的概率是多少？`,answer:F(a+b,size),math:{a,b,c},methods:[method('数等可能的扇区',`等可能的是 ${size} 个区域，其中A或B共 ${a+b} 个。`,`概率 ${F(a+b,size)}，不能直接把三个字母当三种等可能结果。`),method('减去C的机会',`C占 ${c}/${size}。`,`其余区域属于A或B，1−${c}/${size}=${F(a+b,size)}。`)],extension:change('在已经知道没转到C的条件下，转到A的概率是多少？',F(a,a+b),'样本空间缩小为A或B的扇区，只在这a+b个区域内比较。')};
 });
 add('conditionalBalls','D03',3,'取出的两个球','条件样本空间','至少一个红球的条件改变分母',r=>{
  const red=2+r(5),blue=2+r(5),all=choose(red+blue,2),valid=all-choose(blue,2),rr=choose(red,2);
  return {prompt:`袋中 ${red} 个红球、${blue} 个蓝球，不放回随机取两个，每一对具体球等可能。已知至少有一个红球，两个都是红球的概率是多少？`,answer:F(rr,valid),math:{red,blue},methods:[method('只数符合已知条件的球对',`原来 ${all} 对，蓝蓝 ${choose(blue,2)} 对不符合条件，所以新的总数 ${valid}。`,`红红 ${rr} 对，条件概率 ${F(rr,valid)}。`),method('把保留结果分成红红与红蓝',`红红 ${rr} 对，红蓝 ${red*blue} 对，二者是不重叠且全部符合条件的结果。`,`用红红除以两类总和，得 ${F(rr,valid)}。`)],extension:change('若改为已知两个颜色相同，两个都是红球的概率是多少？',F(rr,rr+choose(blue,2)),'保留结果变成红红或蓝蓝，新的分母不再含红蓝。')};
 });
 add('quarterTurn','S01',1,'纸上的箭头','旋转方向','旋转只改变方向，按实际角度追踪',r=>{
  const directions=['上','右','下','左'],start=r(4),turns=1+r(7);
  return {prompt:`箭头最初向${directions[start]}，每次顺时针旋转90°，连续旋转 ${turns} 次。最后向哪个方向？上填0，右填1，下填2，左填3。`,answer:(start+turns)%4,math:{start,turns},methods:[method('逐次追踪方向',`顺时针顺序为上、右、下、左。`,`从${directions[start]}出发 ${turns} 次，最后向${directions[(start+turns)%4]}，填 ${(start+turns)%4}。`)],extension:change('改为逆时针旋转同样次数，填哪个数字？',((start-turns)%4+4)%4,'逆时针次序相反，应从相同起点重新追踪。')};
 });
 add('transformOrder','S01',3,'两次变换','变换次序','旋转与反射交换次序通常不等价',r=>{
  const start=r(4),rot=1+r(3),mirror=v=>(4-v)%4,first=mirror((start+rot)%4),second=(mirror(start)+rot)%4;
  return {prompt:`箭头方向用上0、右1、下2、左3表示，最初是 ${start}。先顺时针转 ${rot} 个90°，再沿竖直轴作镜像（左右交换，上下不变），最后方向填几？`,answer:first,math:{start,rot},methods:[method('按次序逐次变换',`先旋转得到 ${(start+rot)%4}。镜像将1与3交换，0与2不变。`,`最终 ${first}。`),method('从最终方向倒着核对',`对候选方向先做同样镜像，再逆转 ${rot} 个90°。`,`只有 ${first} 会回到初始 ${start}，故它符合两步变换。`)],extension:change('先镜像、再做相同旋转，最终方向填几？',second,`交换次序后先变为 ${mirror(start)}，再旋转到 ${second}；两种次序不应默认相同。`)};
 });
 add('lightSwitchParity','S02',1,'一盏灯','奇偶保持','翻转两次恢复原状态',r=>{
  const groups=2+r(11),per=2+r(13),extra=1+r(20),on=r(2),total=groups*per+extra;
  return {prompt:`一盏灯最初${on?'亮':'灭'}。按开关 ${groups} 组，每组 ${per} 次，然后再按 ${extra} 次；每次都会翻转亮灭。最后亮填1，灭填0。`,answer:(on+total)%2,math:{groups,per,extra,on},methods:[method('只看总次数的奇偶',`共按 ${total} 次，偶数次不改状态，奇数次翻转。`,`从最初状态 ${on} 出发，最后填 ${(on+total)%2}。`)],extension:change('再多按一次，最后填几？',1-(on+total)%2,'多一次必然翻转，不需要重新追踪此前所有按键。')};
 });
 add('ballReplacement','S02',2,'盒中的两色球','不变量','每次白球数量的奇偶保持不变',r=>{
  const white=2+r(18),black=2+r(15);
  return {prompt:`盒中 ${white} 个白球、${black} 个黑球。每次取两球：同色放回一个黑球，异色放回一个白球。一直做到只剩一球。最后黑填0，白填1。`,answer:white%2,math:{white,black},methods:[method('检查每种操作对白球的影响',`白白变黑使白球少2；黑黑变黑使白球数不变；白黑变白也不变。`,`白球数奇偶始终不变，最后白球为0或1，所以填 ${white%2}。`)],extension:change('若最初多加一个白球，最后填几？',1-white%2,'初始白球奇偶改变，最终颜色也必然改变；黑球个数不决定这个不变量。')};
 });
 return out;
})(typeof module!=='undefined'?require('./competition'):{competitionRng,competitionFraction,competitionNumericOptions});
if(typeof module!=='undefined')module.exports={COMPETITION_EXPANSION};
