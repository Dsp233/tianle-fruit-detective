'use strict';
const CompetitionFeedback=((P,S)=>{
 function evaluateInput(input,descriptor){const raw=typeof input==='object'?input.raw:input,result=S.numeric(String(raw??''),descriptor.answerContract.value);return {...result,outcome:result.status,scopeId:descriptor.scopeId,goalId:descriptor.goal.id||descriptor.goal.quantityId||'target',recordAttempt:result.recordAttempt===true,confidence:'not_applicable',diagnosticRuleId:null}}
 const targeted={
  missingAverage:(c,v)=>v?'本次求的是新整体的平均数。加入或移除成员后，总和与个数是否同步更新？':'把平均数还原为总和时，原来的个数和移除后的个数相同吗？再检查题目最终求的是哪一个量。',
  conditionalBalls:(c,v)=>v?'附加条件留下了哪些同色球对？分子与分母都应来自这个新样本范围。':'连续取两球且不放回。检查第二次取球时，袋中总数和目标颜色数量怎样变化。',
  diceSum:(c,v)=>v?'变式附加条件改变了哪些允许的点数对？先去掉不允许的对，再比较有利结果与全部允许结果。':'两枚骰子的有序点数对才是等可能对象。相同的点数和可能由几个不同点数对形成？',
  paintedCube:(c,v)=>v?'变式只涂题目指定的面。一个小块能同时接触这些面吗？按实际涂色面重新分类。':'角块、棱中块、面中块分别接触几个涂色面？先确定所求类别，再检查边界是否重复。',
  lightSwitchParity:()=> '从本题的初始开关状态出发，把整组按键与额外按键都计入。检查总次数的奇偶以及0、1所代表的状态。',
  mapScale:()=> '先标清两张地图的对应关系，再把本次给出的长度放到正确的地图上。同一条实际路线是比例的参照。',
  oppositeScale:(c,v)=>v?'变式中两个方向按同一长度倍率变化。你的面积倍率同时包含这两个方向了吗？':'原题要求面积保持不变。检查两个方向的长度倍率相乘后是否满足这个条件。',
  ballReplacement:()=> '逐种比较合法操作会怎样改变白球数。最后只剩一球时，还要核对0、1与颜色的对应，不能把操作次数当成颜色。',
  checkerDomino:()=> '一块骨牌覆盖两个相邻格。面积给出的数量上界能否由合法摆法达到？检查变式中的边界与染色条件。',
  'rule-packs-exact':(c,v)=>{const p=v?c.extension.problemState.math:c.math.params;return '每包'+p.size+'件，需求'+p.count+'件。'+(p.requirement==='at-least'?'本次允许多买，比较总费用而非只看单价。':'检查整包与单买的总数量是否恰好符合条件，再比较费用。')},
  unitConversion:()=> '先把总容量与每杯容量写成同一单位。本次求的是完整杯数还是可分装的精确数量？剩余容量必须按题意处理。',
  equalDistanceSpeed:(c,v)=>v?'这次相同的是时间。检查你的两段权重是否仍沿用了主问题的等路程条件。':'两个方向是等路程。先分别表示所用时间，再用总路程与总时间核对平均速度。',
  'natural-catch':(c,v)=>v?'本次求追上后继续运动的间距。共同起点是哪一时刻？不要把追及时间直接作为距离。':'先行造成的领先距离是多少？后者出发后，每分钟缩短多少距离？检查你的数代表时间还是路程。'
 };
 function diagnose({task,input,scopeId='main'}){
  const c=task.competition,v=scopeId!=='main',family=c.recipe.familyId,descriptor=(typeof module!=='undefined'?require('./competition_content_contracts'):CompetitionContentContracts).resolve(task,scopeId);
  const candidates=v?c.extension.misconceptions:c.misconceptions,explicit=candidates?.find(x=>P.equal(input,x.value));
  const text=explicit?.feedback||targeted[family]?.(c,v)||S.feedback(v?{...c,misconceptions:c.extension.misconceptions}:c,input,v);
  return {ok:false,status:'needs_revision',outcome:'needs_revision',text,scopeId,goalId:descriptor.goal.id||'target',modelId:descriptor.modelId,diagnosticRuleId:family+':'+(v?'variation':'main')+':'+(explicit?'authored-misconception':'condition-check'),confidence:'suggested_check',recordAttempt:true};
 }
 return {evaluateInput,diagnose,format:r=>r.text||r.message||''};
})(typeof module!=='undefined'?require('./problem_state'):ProblemState,typeof module!=='undefined'?require('./submission_contract'):SubmissionContract);
if(typeof module!=='undefined')module.exports=CompetitionFeedback;
