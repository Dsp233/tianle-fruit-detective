'use strict';
// RC64 originals: different constraints/models, not counts of parameter variants.
const COMPETITION_FRESH=((deps)=>{
 const {competitionRng:rng,competitionFraction:F,competitionNumericOptions:options}=deps,out=[];
 const method=(name,...steps)=>({name,steps});
 const change=(prompt,answer,solution)=>({prompt,answer:String(answer),solution,kind:'condition-change'});
 function add(id,topicIds,level,title,strategy,insight,build){out.push({id,topicIds,level,title,strategy,insight,build(seed){
  const r=rng(seed),p=build(r),answer=String(p.answer),values=[],number=v=>String(v).includes('/')?String(v).split('/').map(Number).reduce((a,b)=>a/b):Number(v),probability=topicIds.includes('D03');
  const fallback=probability?['0','1','1/2','1/3','2/3','1/4','3/4','1/5','2/5','3/5','4/5']:options(answer,r);
  for(const v of [answer,...(p.distractors||[]),...fallback]){const text=String(v),n=number(text);if(Number.isFinite(n)&&n>=0&&(!probability||n<=1)&&!values.some(x=>Math.abs(number(x)-n)<1e-12))values.push(text);if(values.length===5)break}
  if(values.length!==5)throw Error('Not enough distinct RC64 options');
  for(let i=values.length-1;i>0;i--){const j=r(i+1);[values[i],values[j]]=[values[j],values[i]]}
  return {...p,family:id,title,strategy,answer,options:values};
 }})}
 const choose=(n,k)=>{let v=1;for(let i=1;i<=k;i++)v=v*(n-i+1)/i;return v};
 const fixedRedSets=(n,k)=>{const out=[];function visit(start,a){if(a.length===k){out.push(a);return}for(let i=start;i<=n-(k-a.length)+1;i++)visit(i+1,[...a,i])}visit(1,[]);return out};
 function cyclicGaps(n,red){
  const representatives=new Map();
  function visit(left,gaps){
   if(gaps.length===red-1){const g=[...gaps,left],keys=g.map((_,i)=>[...g.slice(i),...g.slice(0,i)]),canonical=keys.map(x=>x.join(',')).sort()[0];representatives.set(canonical,canonical.split(',').map(Number));return}
   for(let v=0;v<=left;v++)visit(left-v,[...gaps,v]);
  }
  visit(n-red,[]);return [...representatives.values()].sort((a,b)=>a.join(',').localeCompare(b.join(',')));
 }
 function routeWeights(w,h){
  const denominator=2**(w+h),a=Array.from({length:h+1},()=>Array(w+1).fill(0));a[0][0]=denominator;
  for(let y=0;y<=h;y++)for(let x=0;x<=w;x++){
   const choices=Number(x<w)+Number(y<h);if(!choices)continue;
   if(x<w)a[y][x+1]+=a[y][x]/choices;if(y<h)a[y+1][x]+=a[y][x]/choices;
  }
  return {a,denominator};
 }
 add('transferBetweenBoxes',['R01'],2,'两盒积木','总量不变与双向变化','转移时两边同时改变，先比较转移前后的数量差',r=>{
  const a=1+r(3),b=a+1+r(4),unit=2*(2+r(8)),moved=(b-a)*unit/2,answer=a*unit;
  return {prompt:`甲、乙两盒积木原来的数量之比是 ${a}:${b}。从乙盒拿出 ${moved} 块放入甲盒后，两盒一样多。甲盒原来有多少块？`,answer,distractors:[a*unit/2,answer+moved,(a+b)*unit,b*unit],math:{a,b,moved},diagram:{kind:'table',rows:[['原来甲:乙',`${a}:${b}`],['乙移到甲',`${moved} 块`],['移后','两盒相等']]},methods:[method('一次转移改变两边的差',`乙少 ${moved}、甲多 ${moved}，原来两盒的差是 ${2*moved} 块。`,`差对应 ${b-a} 份，一份 ${2*moved}÷${b-a}=${unit} 块。`,`原来甲有 ${a} 份，所以是 ${a}×${unit}=${answer} 块。`) ],extension:change(`回到原来的两盒。改为从外部只向甲加入 ${moved} 块，乙不变。乙还比甲多多少块？`,moved,`原差 ${2*moved}。从外部加入只缩小一次差，剩 ${2*moved}−${moved}=${moved}；不能按盒间转移缩小两倍来算。`)};
 });
 add('rectanglePointAreas',['G03'],2,'长方形里的点','共有高度与面积平衡','比较左右两块的面积和与上下两块的面积和',r=>{
  const w=4+2*r(7),h=4+2*r(6),x=1+r(w-1),y=1+r(h-1),top=w*(h-y)/2,left=h*x/2,right=h*(w-x)/2,bottom=w*y/2;
  return {prompt:`长方形内有一点P，连接P与四个顶点，分成上、右、下、左四个三角形。上边三角形面积 ${top}，左边 ${left}，右边 ${right}。下边三角形面积是多少？面积单位相同。`,answer:bottom,distractors:[left+right+top,left+right,top,right-left+top],math:{top,left,right},diagram:{kind:'fourAreas',top,left,right},methods:[method('两对相对三角形占同一半',`左右三角形的底边都等于长方形的高；两条对应的高相加等于长方形的宽。因此左右面积和是长方形面积的一半，为 ${left}+${right}=${left+right}。`,`同理，上下三角形面积和也是同一半，所以两对面积和相等。`,`下边面积=${left}+${right}−${top}=${bottom}，不需要求点P的具体位置。`)],extension:change('把P只向右移动，使左边三角形面积增加1，P仍在长方形内部。右边三角形的新面积是多少？',right-1,`左右面积和保持 ${left+right}；左增加1，右就减少1，所以为 ${right}−1=${right-1}。上下两块在这次水平移动中不变。`)};
 });
 add('worstCaseColors',['C04'],2,'袋里的三种球','最坏情况与保证','先想最多取几个仍能避免目标，再考虑下一次',r=>{
  const k=3+r(3),caps=[1+r(k-1),k+1+r(4),k+1+r(4)],safe=caps.map(v=>Math.min(v,k-1)),answer=safe.reduce((a,b)=>a+b,0)+1;
  const next=caps.map(v=>Math.min(v,k));
  return {prompt:`袋里有红球 ${caps[0]} 个、蓝球 ${caps[1]} 个、绿球 ${caps[2]} 个。看不到颜色，取出后不放回。至少取多少个，才能保证其中有 ${k} 个同色球？`,answer,distractors:[answer-1,k,3*(k-1)+1,caps.reduce((a,b)=>a+b,0)],math:{caps,k},diagram:{kind:'table',rows:[['颜色','红','蓝','绿'],['球数',...caps],['目标',`至少 ${k} 个同色`]]},methods:[method('构造还没达到目标的最大取法',`没有 ${k} 个同色时，每种最多取 ${k-1} 个，还要受库存限制。红、蓝、绿分别最多取 ${safe.join('、')} 个。`,`这三种数量可以同时取到，共 ${answer-1} 个，仍没有达到目标，说明少取这么多不能保证成功。`,`再取一个就超过这个最大数量，必有一种达到 ${k} 个；所以最少 ${answer} 个。`)],extension:change(`库存不变，目标改为保证 ${k+1} 个同色球。至少取多少个？`,next.reduce((a,b)=>a+b,0)+1,`避免 ${k+1} 同色时，每种至多取 ${k}，但不能超过库存；最大失败取法为 ${next.join('+')}=${next.reduce((a,b)=>a+b,0)}，再加1。`)};
 });
 add('stagedClimb',['R03'],2,'轨道上的机器人','完整周期与停止边界','先检查最后一次达到目标后，还会不会发生回落',r=>{
  const up=3+r(6),down=1+r(up-1),height=up+1+r(25),net=up-down,days=1+Math.ceil((height-up)/net);
  return {prompt:`机器人从竖直轨道的0米处出发。每天白天向上走 ${up} 米，夜晚向下退 ${down} 米。白天一到达 ${height} 米标记就立即停机，不再回退。它在第几天首次到达标记？`,answer:days,distractors:[Math.ceil(height/net),Math.floor(height/net),days-1,days+1],math:{up,down,height},diagram:{kind:'table',rows:[['白天向上',`${up} 米`],['夜晚回退',`${down} 米`],['停止标记',`${height} 米`]]},methods:[method('最后一天不再扣夜间回退',`一个完整昼夜净前进 ${up}−${down}=${net} 米，但到达标记的最后一天没有夜间回退。`,`第d天白天最高位置是 (d−1)×${net}+${up}。第 ${days-1} 天最高 ${(days-2)*net+up} 米，还未到；第 ${days} 天最高 ${(days-1)*net+up} 米，已到。`,`所以首次到达是第 ${days} 天，不能把整个目标高度直接除以昼夜净增量。`)],extension:change('取消到达标记立即停机的规则，每个夜晚都完整回退。第几天夜晚结束后，位置首次达到或超过这个标记？',Math.ceil(height/net),`每个完整昼夜净前进 ${net} 米。这次比较d×${net}与 ${height}，最小整数天数为 ${Math.ceil(height/net)}。`)};
 });
 add('consecutiveRepresentations',['A02','L02','N02'],3,'一串连续整数','连续和与因数约束','固定项数，检查首项是否为正整数，避免漏掉边界',r=>{
  const total=[9,15,21,25,27,33,35,45,55,63,75,81][r(12)],limit=Math.floor((Math.sqrt(1+8*total)-1)/2),legal=[];
  for(let k=2;k<=limit;k++){const start=(2*total/k-k+1)/2;if(Number.isInteger(start)&&start>=1)legal.push({k,start})}
  const extra=Number(Number.isInteger((Math.sqrt(1+8*total)-1)/2));
  return {prompt:`把 ${total} 写成至少两个连续正整数的和，有多少种写法？例如“首项不同”或“项数不同”都算不同写法，顺序固定为从小到大。`,answer:legal.length,distractors:[legal.length+1,legal.length+extra,Array.from({length:2*total},(_,i)=>i+1).filter(k=>2*total%k===0).length,legal.length-1],math:{total},methods:[method('由项数筛选合法的首项',`设有k项、首项a。首尾配对得总和=k×(2a+k−1)÷2，所以k必须是 ${2*total} 的因数，且a=(${2*total}÷k−k+1)÷2是正整数。`,`从1开始的k项已经是k项连续正整数的最小和，因此只检查2到 ${limit} 项；更长不可能。`,`逐个检查这个范围内的因数，合法情况为 ${legal.map(v=>`${v.k}项，从${v.start}到${v.start+v.k-1}`).join('；')}。`,`这些写法首项和长度均唯一，合计 ${legal.length} 种。`)],extension:change('其余不变，允许首项为0，即改为至少两个连续非负整数的和。有多少种写法？',legal.length+extra,`正整数写法保留。新写法只能从0开始，需要0+1+……+(k−1)=${total}，即k(k−1)÷2=${total}；${extra?'有一个整数k满足，增加1种':'没有整数k满足，没有新增写法'}，共 ${legal.length+extra} 种。`)};
 });
 add('remainderProbability',['N04','D03'],2,'抽到的数字卡','循环尾段与样本空间','每张整数卡等可能，不代表各余数出现次数相同',r=>{
  const mod=3+r(5),count=mod*(2+r(5))+1+r(mod-1),wanted=r(mod),blocks=Math.floor(count/mod),tail=count%mod,good=blocks+Number(wanted>0&&wanted<=tail),after=good+Number(wanted===0);
  return {prompt:`卡片分别写着1到 ${count} 的每个整数，每张被抽到的机会相同。随机抽一张，卡上整数除以 ${mod} 的余数是 ${wanted} 的概率是多少？`,answer:F(good,count),distractors:[F(1,mod),F(good,count+1),F(good+1,count),F(blocks,count)],math:{mod,count,wanted},diagram:{kind:'table',rows:[['卡片',`1 到 ${count}`],['除数',mod],['目标余数',wanted]]},methods:[method('完整循环之后还要数尾段',`每 ${mod} 个连续整数，各余数恰出现一次。完整的 ${blocks} 组贡献 ${blocks} 张符合的卡。`,`剩下 ${tail} 张，余数依次为1到 ${tail}，${wanted>0&&wanted<=tail?'目标余数还出现一次':'目标余数没有再出现'}。`,`所以符合的有 ${good} 张，总数 ${count} 张，概率 ${F(good,count)}。`)],extension:change('加入一张写0的卡，其余卡片不变，仍等概率抽一张。得到原目标余数的概率是多少？',F(after,count+1),`分母增加到 ${count+1}；0除以 ${mod} 余0，所以${wanted===0?'分子也增加1':'原目标余数不是0，分子不变'}，概率 ${F(after,count+1)}。`)};
 });
 add('rotatingColors',['S01','C02'],3,'圆环上的颜色','重复颜色与旋转等价','记录相邻红位置之间的蓝色数量，再检查哪些记录只是换了起点',r=>{
  const n=4+r(4),red=2+r(n-3),groups=cyclicGaps(n,red),fixed=fixedRedSets(n,red);
  return {prompt:`圆环有 ${n} 个等距位置，把其中 ${red} 个涂红，其余涂蓝。没有固定起点，旋转后能完全重合的算同一种涂法；镜像本身不算相同，除非还能旋转重合。共有多少种涂法？`,answer:groups.length,distractors:[choose(n,red),Math.floor(choose(n,red)/n),groups.length-1,groups.length+1],math:{n,red},diagram:{kind:'necklaceBlank',n,red},methods:[method('用间隔记录涂色并按循环归类',`顺时针从一个红位置出发，记录每两个相邻红位置之间的蓝色个数：共 ${red} 个非负整数，总和 ${n-red}。`,`把 ${n-red} 分入这 ${red} 个间隔，逐个列出全部记录；仅循环换起点的记录合并，倒序不能直接合并。`,`合并后可取这些代表：${groups.map(g=>'('+g.join('、')+')').join('；')}。每个代表都能还原一圈涂色，且其他记录都能循环到其中一个。`,`所以有 ${groups.length} 种。有的图案自身会在较小角度旋转后重合，不能把所有有序涂法统一除以 ${n}。`)],extension:change('给圆环的一个位置加上固定星标，以它为1号，顺时针编号到最后一个位置。不同的红色位置集合都算不同，旋转不再合并。共有多少种涂法？',choose(n,red),`依次确定红色位置，编号严格递增，这样每个集合只列一次。合法集合为 ${fixed.map(v=>"("+v.join("、")+")").join("；")}。所有递增选择都在这张列表里，共 ${fixed.length} 种；有固定星标后不能再按旋转合并。`)};
 });
 add('stepwiseRoute',['C02','D03'],3,'方格中的行走','随机过程与路径权重','先看随机规则作用于每个岔口还是整条路线，不能默认路线等可能',r=>{
  const w=2+r(3),h=1+r(3),weights=routeWeights(w,h),targets=[];
  for(let y=0;y<=h;y++)for(let x=1;x<=w;x++)if(x!==w||y!==h){const count=choose(x+y,x)*choose(w+h-x-y,w-x),all=choose(w+h,w);if(weights.a[y][x]*all!==count*weights.denominator)targets.push({x,y,count,all})}
  const {x,y,count,all}=targets[r(targets.length)],answer=F(weights.a[y][x],weights.denominator);
  const table=Array.from({length:y+1},(_,j)=>`y=${j}：`+Array.from({length:x+1},(_,i)=>`(${i},${j})为${F(weights.a[j][i],weights.denominator)}`).join('，'));
  return {prompt:`从方格点A(0,0)走到B(${w},${h})，每步只能向右或向上1格，不能走出长方形。两个方向都能走时，各以1/2概率选择；只剩一个合法方向时必须走它。经过点P(${x},${y})的概率是多少？`,answer,distractors:[F(count,all),F(weights.denominator-weights.a[y][x],weights.denominator),F(1,all),"1/2"],math:{w,h,x,y},diagram:{kind:'routes',w,h,x,y},methods:[method('把到达概率沿合法方向传递',`A的概率为1。每个有两个出口的点，各传一半给右、上邻点；边界只有一个出口时传全部。一个点从不同入口到达的事件互斥，可以相加。`,`依次填到P的各点概率（坐标按题面）：${table.join('；')}。`,`P得到的总概率为 ${answer}。完整路线在这种逐步选择中不一定等可能，所以不能直接用“经过P的路线数÷全部路线数”。`)],extension:change('改为先列出所有从A到B的合法完整路线，再等概率抽一条。经过同一个P的概率是多少？',F(count,all),`这次计数时在起点记1，每个点写左边和下边的路线数之和，得到A到B共 ${all} 条、A到P共 ${choose(x+y,x)} 条。从P同样逐点计数到B，共 ${choose(w+h-x-y,w-x)} 条。前后配对得 ${count} 条经过P。完整路线等可能，所以概率 ${F(count,all)}；不要沿用原来的岔口概率。`)};
 });
 return out;
})(typeof module!=='undefined'?require('./competition'):{competitionRng,competitionFraction,competitionNumericOptions});
if(typeof module!=='undefined')module.exports={COMPETITION_FRESH};
