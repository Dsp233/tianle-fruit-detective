'use strict';
// Independent solvers read conditions only, not generator answers or methods.
const area=p=>Math.abs(p.reduce((s,v,i)=>{const q=p[(i+1)%p.length];return s+v[0]*q[1]-v[1]*q[0]},0))/2;
function consecutive(total,allowZero){let count=0;for(let start=allowZero?0:1;start<=total;start++){let sum=0;for(let end=start;sum<total;end++){sum+=end;if(sum===total&&end-start+1>=2)count++}}return count}
function colorThreshold(caps,k){let most=-1;for(let a=0;a<=caps[0];a++)for(let b=0;b<=caps[1];b++)for(let c=0;c<=caps[2];c++)if(a<k&&b<k&&c<k)most=Math.max(most,a+b+c);return most+1}
function colorings(n,red){const classes=new Set();let fixed=0;for(let mask=0;mask<2**n;mask++){const bits=Array.from({length:n},(_,i)=>(mask>>i)&1);if(bits.reduce((a,b)=>a+b,0)!==red)continue;fixed++;const rotations=bits.map((_,i)=>[...bits.slice(i),...bits.slice(0,i)].join(''));classes.add(rotations.sort()[0])}return {rotating:classes.size,fixed}}
function walks(m){const routes=[];function visit(x,y,weight,hit,route){hit=hit||x===m.x&&y===m.y;if(x===m.w&&y===m.h){routes.push({route,weight,hit});return}const count=Number(x<m.w)+Number(y<m.h);if(x<m.w)visit(x+1,y,weight/count,hit,route+'R');if(y<m.h)visit(x,y+1,weight/count,hit,route+'U')}visit(0,0,1,false,'');return routes}
function freshOracle(id,m){
 switch(id){
 case 'transferBetweenBoxes':{
  const candidates=[];for(let a=1;a<=2*m.moved*(m.a+m.b);a++){const b=a*m.b/m.a;if(Number.isInteger(b)&&b>=m.moved&&a+m.moved===b-m.moved)candidates.push([a,b])}
  if(candidates.length!==1)throw Error('Nonunique box transfer');const [a,b]=candidates[0];return {answer:a,extension:b-a-m.moved};
 }
 case 'rectanglePointAreas':{
  const width=2*(m.left+m.right),p=[2*m.left,1-m.top/(m.left+m.right)];
  if(!(p[0]>0&&p[0]<width&&p[1]>0&&p[1]<1))throw Error('Invalid internal point');
  const a=[0,0],b=[width,0],c=[width,1],d=[0,1],moved=[p[0]+2,p[1]];
  return {answer:area([a,b,p]),extension:area([b,c,moved])};
 }
 case 'worstCaseColors':return {answer:colorThreshold(m.caps,m.k),extension:colorThreshold(m.caps,m.k+1)};
 case 'stagedClimb':{
  let position=0,day=0;while(++day<1000){position+=m.up;if(position>=m.height)break;position-=m.down}
  let x=0,d=0;while(++d<1000){x+=m.up;x-=m.down;if(x>=m.height)break}
  if(day===1000||d===1000)throw Error('Climb does not terminate');return {answer:day,extension:d};
 }
 case 'consecutiveRepresentations':return {answer:consecutive(m.total,false),extension:consecutive(m.total,true)};
 case 'remainderProbability':{
  let good=0,extended=0;for(let i=1;i<=m.count;i++)if(i%m.mod===m.wanted)good++;for(let i=0;i<=m.count;i++)if(i%m.mod===m.wanted)extended++;
  return {answer:good/m.count,extension:extended/(m.count+1)};
 }
 case 'rotatingColors':{const c=colorings(m.n,m.red);return {answer:c.rotating,extension:c.fixed}}
 case 'stepwiseRoute':{const routes=walks(m);return {answer:routes.filter(v=>v.hit).reduce((s,v)=>s+v.weight,0),extension:routes.filter(v=>v.hit).length/routes.length}}
 default:throw Error('Missing RC64 solver '+id);
 }
}
module.exports={freshOracle,colorings,walks};
