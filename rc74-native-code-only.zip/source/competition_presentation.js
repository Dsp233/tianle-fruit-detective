'use strict';
const CompetitionPresentation=(()=>{
 function project(task,work,scopeId='main'){
  const c=CompetitionContentContracts.resolve(task,scopeId),s=CompetitionWork.selectScope(work,scopeId),visible=c.hints.filter(h=>s.help.revealedHintIds.includes(h.id));
  let diagram=c.diagram;const family=task.competition.recipe.familyId,m=task.competition.math;if(scopeId==='main'&&family==='digitInsert')diagram={kind:'scene-placeValue',rows:[{label:'原数字，顺序保持',digits:[m.a,m.b]},{label:'待插入的数字',digits:[m.d]}],caption:'插入位置由你选择'};if(scopeId==='main'&&family==='divisorPowers')diagram={kind:'scene-quantities',quantities:[{label:'2的指数上限',value:String(m.a),unit:''},{label:'3的指数上限',value:String(m.b),unit:''}],caption:'请自己确定每个指数的合法取值'};
  return {scopeId,prompt:c.promptText,givenText:c.givenText,narrationText:c.narrationText,hints:visible,input:{...s.input},feedback:s.feedback,diagram:c.initialDiagramAllowed?diagram:visible.length?diagram:null};
 }
 return {project,projectHint:(task,work,id)=>project(task,work,id).hints,projectDiagram:(task,work,id)=>project(task,work,id).diagram};
})();
