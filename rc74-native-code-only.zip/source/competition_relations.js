'use strict';
// Small, exact relation interpreter. Definitions contain data, never executable
// strings or answers. All question, solution and diagram numbers share bindings.
const CompetitionRelations=(()=>{
 const gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return Math.abs(a)||1};
 function q(n,d=1){if(!Number.isSafeInteger(n)||!Number.isSafeInteger(d)||!d)throw Error('Unsafe rational');const g=gcd(n,d),s=d<0?-1:1;return {n:n/g*s,d:Math.abs(d/g)}}
 function number(v){if(v&&typeof v==='object'&&'n'in v)return q(v.n,v.d);if(typeof v==='string'&&/^-?\d+\/\d+$/.test(v)){const [n,d]=v.split('/').map(Number);return q(n,d)}if(typeof v==='string'&&/^-?\d+$/.test(v))return q(Number(v));if(typeof v==='number')return q(v);throw Error('Invalid relation value '+v)}
 const add=(a,b)=>q(a.n*b.d+b.n*a.d,a.d*b.d),mul=(a,b)=>q(a.n*b.n,a.d*b.d),div=(a,b)=>q(a.n*b.d,a.d*b.n);
 const decimal=a=>a.n/a.d;
 function format(a){a=number(a);return a.d===1?String(a.n):a.n+'/'+a.d}
 // Render evaluated operands from the same expression tree as the relations.
 // Parentheses are structural, including fractional and negative operands.
 function expression(e,env){
  function node(x){
   if(!Array.isArray(x)){const v=evaluate(x,env);return {text:format(v),precedence:v.d===1?4:2,compound:v.d!==1||v.n<0}}
   const op=x[0],parts=x.slice(1).map(node),precedence={add:1,sub:1,mul:2,div:2,pow:3}[op];
   if(op==='floor'||op==='ceil')return {text:(op==='floor'?'向下取整':'向上取整')+'('+parts[0].text+')',precedence:4};
   if(op==='max'||op==='min')return {text:(op==='max'?'最大值':'最小值')+'('+parts.map(p=>p.text).join('，')+')',precedence:4};
   if(!precedence)throw Error('Unsupported display operation '+op);
   const symbol={add:' + ',sub:' − ',mul:' × ',div:' ÷ ',pow:' ^ '}[op];
   const text=parts.map((p,i)=>{
    const wrap=p.compound||p.precedence<precedence||(i>0&&['sub','div','pow'].includes(op)&&p.precedence<=precedence)||(op==='pow'&&i===0&&p.precedence===precedence);
    return wrap?'('+p.text+')':p.text;
   }).join(symbol);
   return {text,precedence};
  }
  return node(e).text;
 }
 function evaluate(e,env){
  if(typeof e==='number')return q(e);
  if(typeof e==='string'){if(e in env)return number(env[e]);if(/^-?\d+(\/\d+)?$/.test(e))return number(e.includes('/')?e:Number(e));throw Error('Unknown quantity '+e)}
  if(!Array.isArray(e)||e.length<2)throw Error('Invalid expression');
  const op=e[0],v=e.slice(1).map(x=>evaluate(x,env));
  if(op==='add')return v.reduce(add,q(0));if(op==='sub')return add(v[0],q(-v[1].n,v[1].d));
  if(op==='mul')return v.reduce(mul,q(1));if(op==='div')return div(v[0],v[1]);
  if(op==='pow'){if(v[1].d!==1||v[1].n<0||v[1].n>6)throw Error('Invalid exponent');return q(v[0].n**v[1].n,v[0].d**v[1].n)}
  if(op==='floor')return q(Math.floor(decimal(v[0])));if(op==='ceil')return q(Math.ceil(decimal(v[0])));
  if(op==='max'||op==='min')return v.reduce((a,b)=>(op==='max'?decimal(a)>decimal(b):decimal(a)<decimal(b))?a:b);
  throw Error('Unsupported operation '+op);
 }
 function condition(c,env){const a=decimal(evaluate(c[1],env)),b=c.length>2?decimal(evaluate(c[2],env)):0;return c[0]==='integer'?Number.isInteger(a):c[0]==='gt'?a>b:c[0]==='ge'?a>=b:c[0]==='lt'?a<b:c[0]==='le'?a<=b:c[0]==='eq'?a===b:c[0]==='ne'?a!==b:false}
 function bind(def,params){
  const env={};for(const key of def.inputs){if(!(key in params))throw Error('Missing '+key);env[key]=number(params[key])}
  if((def.inputChecks||[]).some(c=>!condition(c,env)))throw Error('Illegal relation parameters');
  for(const [key,e]of def.derive||[])env[key]=evaluate(e,env);
  let candidates=[];
  if(def.search){const s=def.search,lo=decimal(evaluate(s.from,env)),hi=decimal(evaluate(s.to,env));if(!Number.isInteger(lo)||!Number.isInteger(hi)||hi-lo>1000||hi<lo)throw Error('Illegal search domain');
   for(let k=lo;k<=hi;k++){const row={...env,[s.variable]:q(k)};for(const [name,e]of s.derive)row[name]=evaluate(e,row);if((s.checks||[]).every(c=>condition(c,row)))candidates.push(row)}
   if(!candidates.length)throw Error('No feasible solution');candidates.sort((a,b)=>decimal(evaluate(s.objective,a))-decimal(evaluate(s.objective,b)));Object.assign(env,candidates[0]);
  }
  for(const [key,e]of def.after||[])env[key]=evaluate(e,env);
  if((def.checks||[]).some(c=>!condition(c,env)))throw Error('Degenerate relation');
  return {env,candidates,answer:format(evaluate(def.target,env))};
 }
 function text(s,env,formulas={}){return String(s).replace(/\{(=?[A-Za-z][A-Za-z0-9]*)\}/g,(_,key)=>{if(key[0]==='='){if(!(key.slice(1)in formulas))throw Error('Unbound equation '+key);return formulas[key.slice(1)]}if(!(key in env))throw Error('Unbound display '+key);return typeof env[key]==='string'&&!/^-?\d+(\/\d+)?$/.test(env[key])?env[key]:format(env[key])})}
 function material(value,env,formulas={}){
  if(Array.isArray(value))return value.map(v=>material(v,env,formulas));
  if(value&&typeof value==='object'){if('$'in value)return decimal(evaluate(value.$,env));return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,material(v,env,formulas)]))}
  return typeof value==='string'?text(value,env,formulas):value;
 }
 function compile(def,params,context){
  const bound=bind(def,params),{env,candidates}=bound,skin=def.contexts[context];if(!skin)throw Error('Unreviewed context');
  // Prompt placeholders can only use declared givens, preventing derived-value leakage.
  const meta=def.contextMeta?.[context]||{},display={...env,...meta},given={...Object.fromEntries(def.inputs.map(k=>[k,env[k]])),...meta},formulas={};
  for(const [key,e]of [...(def.derive||[]),...(def.search?.derive||[]),...(def.after||[])])formulas[key]=expression(e,env)+' = '+format(env[key]);
  if(def.model==='finite-purchase')display.purchasePlan=decimal(env.singles)===0?text('买 {packs} 包即可，共买 {bought} {unit}',display):text('买 {packs} 包，再单买 {singles} {unit}，共买 {bought} {unit}',display);
  const methods=def.methods.map(m=>({name:m.name,steps:m.steps.map(s=>text(s,display,formulas)),frames:(m.frames||[]).map(f=>material(f,display,formulas))}));
  if(context==='supplies'&&['start','first','second','left'].some(k=>env[k]&&env[k].d!==1))throw Error('Paper quantities must be whole');
  const misconceptions=[];for(const m of def.misconceptions||[])try{misconceptions.push({value:format(evaluate(m.expr,env)),feedback:m.feedback})}catch{/* An undefined misconception is not a legal choice. */}
  const ordered=candidates.slice().sort((a,b)=>decimal(a[def.search.variable])-decimal(b[def.search.variable]));
  return {...bound,title:meta.title||def.title,prompt:text(skin, given),methods,hints:def.hints.map(h=>text(h,given)),diagram:material(def.diagram||null,given),hintDiagram:material(def.hintDiagram||null,given),misconceptions,candidateRows:ordered.map(row=>Object.fromEntries((def.search?.columns||[]).map(k=>[k,format(row[k])])))};
 }
 return {q,number,format,decimal,evaluate,expression,condition,bind,compile,material,text};
})();
if(typeof module!=='undefined')module.exports=CompetitionRelations;
