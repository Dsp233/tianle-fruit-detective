'use strict';
// Solvers consume mathematical conditions, never the published answer/steps.
const n=x=>String(x).includes('/')?String(x).split('/').map(Number).reduce((a,b)=>a/b):Number(x);
const combinations=(a,k)=>{const out=[];function visit(i,v){if(v.length===k){out.push(v);return}for(let j=i;j<a.length;j++)visit(j+1,[...v,a[j]])}visit(0,[]);return out};
const permutations=a=>{const out=[];function visit(v,left){if(!left.length){out.push(v);return}left.forEach((x,i)=>visit([...v,x],left.filter((_,j)=>j!==i)))}visit([],a);return out};
const memo=new Map(),cached=(key,f)=>{if(!memo.has(key))memo.set(key,f());return memo.get(key)};
const divisors=v=>Array.from({length:v},(_,i)=>i+1).filter(d=>v%d===0);
function packCost(p,q,count,over){let best=Infinity;for(let a=0;a<=count;a++)for(let b=0;b<=count;b++){const total=4*a+6*b;if(over?total>=count:total===count)best=Math.min(best,a*p+b*q)}return best}
function paths(w,h){let all=0,up=0;function visit(x,y,first){if(x===w&&y===h){all++;if(first==='up')up++;return}if(x<w)visit(x+1,y,first||'right');if(y<h)visit(x,y+1,first||'up')}visit(0,0,'');return {all,up}}
function domino(w,h,removed){const match=new Map();function visit(x,y,seen){for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const a=x+dx,b=y+dy,k=a+','+b;if(a<0||b<0||a>=w||b>=h||removed(a,b)||seen.has(k))continue;seen.add(k);if(!match.has(k)||visit(...match.get(k),seen)){match.set(k,[x,y]);return true}}return false}let count=0;for(let y=0;y<h;y++)for(let x=0;x<w;x++)if((x+y)%2===0&&!removed(x,y)&&visit(x,y,new Set()))count++;return count}
function expansionOracle(id,m){let answer,extension;
 switch(id){
 case 'digitInsert':{const s=String(10*m.a+m.b),v=[0,1,2].map(i=>Number(s.slice(0,i)+m.d+s.slice(i)));answer=Math.max(...v);extension=Math.min(...v);break}
 case 'numberAppend':{const gap=10*m.n+m.digit-m.n,candidates=Array.from({length:90},(_,i)=>i+10).filter(v=>Number(String(v)+m.digit)-v===gap);if(candidates.length!==1)throw Error('Nonunique appended number');answer=candidates[0];extension=Number(String(m.digit||1)+answer)-answer;break}
 case 'pairedSum':{const a=Array.from({length:m.n},(_,i)=>i+1);answer=a.reduce((a,b)=>a+b,0);extension=a.filter(v=>v%2===0).reduce((a,b)=>a+b,0);break}
 case 'telescopingDifferences':{const a=Array.from({length:m.n},(_,i)=>(m.start+(i+1)*m.step)-(m.start+i*m.step));answer=a.reduce((a,b)=>a+b,0);extension=a.slice(1).reduce((a,b)=>a+b,0);break}
 case 'neighborProducts':answer=m.n*m.n-(m.n-1)*(m.n+1);extension=m.n*m.n-(m.n-2)*(m.n+2);break;
 case 'fractionDifferentWholes':answer=m.a/4+m.b/3;extension=m.a+m.b-answer;break;
 case 'fractionSharedRemainder':{const total=Array.from({length:1000},(_,i)=>i+1).find(v=>Number.isInteger(v/3)&&Number.isInteger((v-v/3+m.add)*3/8)&&v-v/3+m.add-(v-v/3+m.add)*3/8===5*m.unit+5*m.add/8);answer=total;extension=total-total/3+m.add-total*3/8;if(!Number.isInteger(extension))throw Error('Fractional balls');break}
 case 'discountOrder':{const p=m.price-m.price*m.p/100;answer=p-m.q;const q=m.price-m.q;extension=q-q*m.p/100;break}
 case 'percentRestore':answer=(100+m.p-100)/(100+m.p)*100;extension=(100-(100-(m.p===100?50:m.p)))/(100-(m.p===100?50:m.p))*100;break;
 case 'squareBounds':{let k=0;while((k+1)**2<=m.n)k++;answer=k;extension=k*k===m.n?k:k+1;break}
 case 'signedProduct':{const cards=[-4*m.k,-3*m.k,-m.k,0,2*m.k,5*m.k];answer=Math.min(...combinations(cards,3).map(v=>v.reduce((a,b)=>a*b,1)));extension=Math.min(...combinations(cards,2).map(v=>v[0]*v[1]));break}
 case 'ratioTotal':{const total=(m.a+m.b)*m.u;answer=Array.from({length:total+1},(_,i)=>i).find(red=>red*m.b===(total-red)*m.a);extension=Math.abs((total-answer)-(answer+m.b-m.a));break}
 case 'linkedRatios':{const green=m.b*m.d*m.u,blue=green*m.c/m.d,red=blue*m.a/m.b;answer=red+blue+green;extension=Math.abs(green-blue);break}
 case 'unitConversion':answer=Math.floor(1000*m.liters/m.cup);extension=Math.floor(1000*m.liters/(2*m.cup));break;
 case 'mixedPacks':answer=packCost(m.p,m.q,m.count,false);extension=packCost(m.p,m.q,m.count,true);break;
 case 'jointWork':{const total=(m.a+m.b)*m.t;answer=0;while(answer*(m.a+m.b)<total)answer++;extension=total/m.a;break}
 case 'riverTravel':answer=m.distance/(m.v+m.c)+m.distance/(m.v-m.c);extension=2*m.distance/m.v;break;
 case 'mapScale':answer=m.a*m.k;extension=answer/2;break;
 case 'scaleAreaReverse':{const final=m.old*(m.k/m.s)**2;answer=final*m.s*m.s/(m.k*m.k);extension=answer*m.k*m.k;break}
 case 'ageDifference':{const diff=m.parent-m.child,candidates=Array.from({length:100},(_,i)=>i+1).filter(child=>child>m.ago&&child+diff-m.ago===3*(child-m.ago));answer=candidates[0];extension=0;while(m.parent+extension!==2*(m.child+extension)){extension++;if(extension>100)throw Error('No future double age')}if(candidates.length!==1)throw Error('Nonunique age');break}
 case 'repeatedMachine':{const output=m.a*(m.a*m.x+m.b)+m.b,candidates=Array.from({length:100},(_,i)=>i).filter(v=>m.a*(m.a*v+m.b)+m.b===output);answer=candidates[0];const one=m.a*(answer+m.b);extension=m.a*(one+m.b);if(candidates.length!==1)throw Error('Nonunique machine');break}
 case 'twoCoins':{const total=m.n+m.twos;answer=Array.from({length:m.n+1},(_,i)=>i).find(k=>2*k+(m.n-k)===total);extension=total-1-2;break}
 case 'stampConstraint':{let all=0,both=0;for(let a=0;3*a<=m.total;a++)for(let b=0;5*b<=m.total;b++)if(3*a+5*b===m.total){all++;if(a&&b)both++}answer=both;extension=all;break}
 case 'recurrenceForward':{const make=(a,b)=>{const seq=[a,b];while(seq.length<m.n)seq.push(seq.at(-1)+seq.at(-2));return seq};answer=make(m.a,m.b).at(-1);extension=make(m.b,m.a).at(-1);break}
 case 'recurrenceTotal':{const seq=[m.a,m.b];while(seq.length<m.n)seq.push(seq.at(-1)+seq.at(-2));answer=seq.reduce((a,b)=>a+b,0);extension=seq.slice(1).reduce((a,b)=>a+b,0);break}
 case 'machineMeeting':answer=(m.d-m.b)/(m.c-m.a);extension=(m.d+1-m.b)/(m.c-m.a);break;
 case 'machineOrder':{const A=x=>m.a*x+m.b,B=x=>m.c*x+m.d;answer=Math.abs(B(A(m.x))-A(B(m.x)));extension=Math.abs(B(A(2*m.x))-A(B(2*m.x)));break}
 case 'digitDivisor':{const legal=[];for(let i=10*m.tens;i<10*m.tens+10;i++)if(i%10!==0&&i%(i%10)===0)legal.push(i);answer=legal.length;extension=0;break}
 case 'divisibleEleven':{const legal=[];for(let i=1000;i<10000;i++)if(Math.floor(i/1000)===m.a&&Math.floor(i/10)%10===m.c&&i%11===0&&i%5===0)legal.push(i);answer=Math.max(...legal);extension=legal.length;break}
 case 'threeDivisors':{const a=cached('threeDivisors-'+m.limit,()=>Array.from({length:m.limit},(_,i)=>i+1).filter(v=>divisors(v).length===3));answer=a.length;extension=Math.max(...a);break}
 case 'divisorPowers':{const d=cached('divisors-'+m.a+'-'+m.b,()=>divisors(2**m.a*3**m.b));answer=d.length;extension=d.filter(v=>Number.isInteger(Math.sqrt(v))).length;break}
 case 'equalBags':{const d=divisors(m.a).filter(d=>m.b%d===0);answer=Math.max(...d);extension=d.length;break}
 case 'offsetBells':{const list=[];for(let t=1;list.length<2;t++)if(t%m.a===0&&t>=m.offset&&(t-m.offset)%m.b===0)list.push(t);answer=list[0];extension=list[1];break}
 case 'cyclicPosition':{let v=m.start;for(let i=0;i<m.steps;i++)v=v===m.size?1:v+1;answer=v;v=m.start;for(let i=0;i<m.steps;i++)v=v===1?m.size:v-1;extension=v;break}
 case 'repeatedOnes':answer=Number(BigInt('1'.repeat(m.n))%7n);extension=Number(BigInt('1'.repeat(m.n+1))%7n);break;
 case 'rectangleDiagonalArea':answer=m.w*m.h/2;extension=(m.w+m.w/2)*m.h/2;break;
 case 'boundaryNotch':{const outline=[m.w-m.a,m.depth,m.a,m.depth,m.h,m.w,m.h];answer=outline.reduce((a,b)=>a+b,0);extension=(m.w-m.a)+(m.h-m.depth)+m.w+m.h+m.a+m.depth;break}
 case 'angleMarks':answer=360/m.marks*m.step;extension=360-answer;break;
 case 'polygonTurn':answer=180-180*(m.n-2)/m.n;extension=answer*Math.floor(m.n/2);break;
 case 'lShapeArea':{let cells=0;for(let x=0;x<m.w;x++)for(let y=0;y<m.h;y++)if(!(x>=m.w-m.a&&y>=m.h-m.b))cells++;answer=cells;extension=m.w*m.h-m.a*m.b;break}
 case 'crossArea':{let covered=0,intersection=0;for(let x=0;x<m.w;x++)for(let y=0;y<m.h;y++){if(x<m.a||y<m.b)covered++;if(x<m.a&&y<m.b)intersection++}answer=covered;extension=intersection;break}
 case 'semicircleBoundary':answer=3*m.radius+2*m.radius;extension=6*m.radius;break;
 case 'circleRingRatio':{const small=Math.PI*m.r1*m.r1,big=Math.PI*m.r2*m.r2;answer=(big-small)/big;extension=(Math.PI*(2*m.r2)**2-Math.PI*(2*m.r1)**2)/(Math.PI*(2*m.r2)**2);break}
 case 'shadowSimilarity':answer=m.a*(2*m.b*m.unit)/(2*m.a);extension=m.a;break;
 case 'parallelTriangle':answer=m.area-m.area*(m.k/m.n)**2;extension=1-0.5**2;break;
 case 'coordinateHorizontal':answer=Math.hypot(m.b-m.a,m.y-m.y);extension=Math.hypot((m.b+5)-(m.a+5),0);break;
 case 'hypotenuseMidpoint':answer=Math.hypot(3*m.k/2,4*m.k/2);extension=4*m.k/2;break;
 case 'cubeSteps':{let cells=0;for(let x=1;x<=m.n;x++)for(let y=1;y<=x;y++)cells++;answer=cells;extension=2*cells;break}
 case 'openBox':{const v=[];for(let x=1;2*x<m.side;x++)v.push(x*(m.side-x-x)*(m.side-x-x));answer=Math.max(...v);extension=(m.side-1-1)**2;break}
 case 'setOutside':{const people=Array.from({length:m.total},(_,i)=>i),A=new Set(people.slice(0,m.a)),B=new Set([...people.slice(0,m.both),...people.slice(m.a,m.a+m.b-m.both)]);answer=people.filter(i=>!A.has(i)&&!B.has(i)).length;extension=answer-1;break}
 case 'threeSetExactlyTwo':{const exactAB=m.ab-m.triple,exactAC=m.ac-m.triple,exactBC=m.bc-m.triple;answer=exactAB+exactAC+exactBC;extension=answer+m.triple;break}
 case 'menuBranches':{const choices=[];for(let a=0;a<m.rice;a++)for(let b=0;b<m.dish;b++)choices.push('R'+a+'D'+b);for(let a=0;a<m.noodle;a++)choices.push('N'+a);answer=choices.length;extension=3*answer;break}
 case 'binaryNoNeighbors':{const valid=cached('binary-'+m.n,()=>Array.from({length:2**m.n},(_,i)=>i.toString(2).padStart(m.n,'0')).filter(s=>!s.includes('11')));answer=valid.length;extension=valid.filter(s=>s[0]==='1').length;break}
 case 'unorderedPairs':{const pairs=combinations(Array.from({length:m.n},(_,i)=>i),2);answer=pairs.length;extension=2*pairs.length;break}
 case 'circularSeating':{const all=cached('circle-'+m.n,()=>permutations(Array.from({length:m.n-1},(_,i)=>i+1)));answer=all.filter(p=>p[0]===1||p.at(-1)===1).length;extension=all.length;break}
 case 'differentDigits':{let count=0;for(let a=0;a<m.digits;a++)for(let b=0;b<m.digits;b++)if(a!==b)count++;answer=count;extension=count/2;break}
 case 'allThreeColors':{const counts=cached('colors-'+m.n,()=>{let all=0,two=0;for(let k=0;k<3**m.n;k++){const digits=k.toString(3).padStart(m.n,'0'),size=new Set(digits).size;if(size===3)all++;if(size===2)two++}return {all,two}});answer=counts.all;extension=counts.two;break}
 case 'truncatedBars':{const A=m.base+m.step*m.a,B=m.base+m.step*m.b;answer=A+B;extension=B-A;break}
 case 'cumulativeChart':{const people=[...Array(m.a).fill(1),...Array(m.b).fill(2),...Array(m.c).fill(3),...Array(m.d).fill(4)];answer=people.filter(v=>v===2||v===3).length;extension=people.filter(v=>v===4).length;break}
 case 'medianSort':{const v=Array.from({length:5},(_,i)=>m.start+i*m.gap);answer=[...v].sort((a,b)=>a-b)[2];v[4]+=100;extension=v.sort((a,b)=>a-b)[2];break}
 case 'overlapAverages':{answer=m.values[3];const v=[...m.values,m.values[0],m.values[6]];extension=v[4];break}
 case 'spinnerLabels':{const fields=[...Array(m.a).fill('A'),...Array(m.b).fill('B'),...Array(m.c).fill('C')];answer=fields.filter(v=>v!=='C').length/fields.length;const remaining=fields.filter(v=>v!=='C');extension=remaining.filter(v=>v==='A').length/remaining.length;break}
 case 'conditionalBalls':{const pairs=combinations([...Array(m.red).fill('R'),...Array(m.blue).fill('B')],2),atLeast=pairs.filter(p=>p.includes('R')),same=pairs.filter(p=>p[0]===p[1]);answer=atLeast.filter(p=>p.every(v=>v==='R')).length/atLeast.length;extension=same.filter(p=>p.every(v=>v==='R')).length/same.length;break}
 case 'quarterTurn':{let a=m.start,b=m.start;for(let i=0;i<m.turns;i++){a=(a+1)%4;b=(b+3)%4}answer=a;extension=b;break}
 case 'transformOrder':{const reflect=[0,3,2,1],rotate=v=>(v+m.rot)%4;answer=reflect[rotate(m.start)];extension=rotate(reflect[m.start]);break}
 case 'lightSwitchParity':{let a=m.on;for(let i=0;i<m.groups*m.per+m.extra;i++)a=1-a;answer=a;extension=1-a;break}
 case 'ballReplacement':{const ends=cached('replace-'+m.white+'-'+m.black,()=>{const memo=new Map();function visit(w,b){const key=w+','+b;if(memo.has(key))return memo.get(key);if(w+b===1)return new Set([w]);const out=new Set();if(w>=2)for(const v of visit(w-2,b+1))out.add(v);if(b>=2)for(const v of visit(w,b-1))out.add(v);if(w&&b)for(const v of visit(w,b-1))out.add(v);memo.set(key,out);return out}return [...visit(m.white,m.black)]});if(ends.length!==1)throw Error('Replacement not invariant');answer=ends[0];extension=1-answer;break}
 default:throw Error('Missing expansion oracle '+id);
 }
 return {answer,extension};
}
function reviewedTransferOracle(id,m){
 switch(id){
 case 'reverseDigits':{const sums=11*(m.a+m.b),gap=m.a-m.b,legal=[];for(let a=1;a<10;a++)for(let b=1;b<10;b++)if(a-b===gap&&(10*a+b+10*b+a)===sums)legal.push(10*b+a);return Math.min(...legal)}
 case 'fractionBackwards':return 3*m.left-3*m.left/2-3*m.left/3;
 case 'percentRoundTrip':return (m.start*(1+m.percent/100)-m.start)/(m.start*(1+m.percent/100))*100;
 case 'squareBorder':return (m.n+1)**2-m.n*m.n;
 case 'ratioEqualize':return m.a*m.unit+m.b*m.unit-(m.b-m.a)*m.unit;
 case 'packPrice':{let v=Infinity;for(let p=0;p<=m.count;p++)for(let s=0;s<=m.count;s++)if(3*p+s>=m.count)v=Math.min(v,p*m.pack+s*m.single);return v}
 case 'equalDistanceSpeed':return (m.speed+2*m.speed)/2;
 case 'oppositeScale':return (m.b/m.a)*(m.b/m.a);
 case 'balanceCancel':return ((m.a+1)*m.x+m.b)-((m.a-1)*m.x+m.b+m.x);
 case 'tickets':{const total=m.adults*m.adult+(m.people-m.adults)*m.child;let count=0;for(let a=0;a<=total;a++)for(let b=0;b<=total;b++)if(a*m.adult+b*m.child===total)count++;return count}
 case 'recurrenceBackwards':{const seq=a=>{const v=[a,m.second];while(v.length<m.n)v.push(v.at(-1)+v.at(-2));return v.at(-1)};return seq(m.first+1)-seq(m.first)}
 case 'linearTable':return (m.target+m.b)*m.k;
 case 'divisibleDigits':{let best=0;for(let v=1000;v<10000;v++)if(Math.floor(v/1000)===m.a&&Math.floor(v/10)%10===m.b&&v%9===0&&v%2===0)best=v;return best}
 case 'factorBalance':return Math.max(...divisors(m.product).map(v=>v+m.product/v));
 case 'bells':{let t=1;while(t%m.a||t%m.b)t++;let count=0;for(let v=0;v<=t;v++)if(v%m.a===0&&v%m.b===0)count++;return count}
 case 'lastDigit':return Number((BigInt(m.base)**BigInt(m.exponent)+BigInt(m.base)**BigInt(m.exponent+1))%10n);
 case 'fixedPerimeter':{let max=0;for(let a=2;a<m.half;a+=2)for(let b=2;b<m.half;b+=2)if(a+b===m.half)max=Math.max(max,a*b);return max}
 case 'outsideAngle':return (180-m.apex)/2;
 case 'overlapSquares':{const first=new Set(),second=new Set();for(let x=0;x<m.n;x++)for(let y=0;y<m.n;y++){first.add(x+','+y);second.add((x+m.dx)+','+(y+m.dy))}return [...new Set([...first,...second])].filter(v=>first.has(v)!==second.has(v)).length}
 case 'circleRoute':return m.sectors*m.unit;
 case 'similarAreaPerimeter':return m.b**2;
 case 'ladderShift':return Math.sqrt((5*m.k)**2-(4*m.k)**2);
 case 'paintedCube':{let count=0;for(let x=0;x<m.n;x++)for(let y=0;y<m.n;y++)for(let z=0;z<m.n;z++)if(Number(z===0)+Number(z===m.n-1)===1)count++;return count}
 case 'exactlyOneSet':return m.a+(m.b+1)-2*(m.both+1);
 case 'gridDetour':return paths(m.w,m.h).up;
 case 'adjacentLine':return cached('not-adjacent-'+m.n,()=>permutations(Array.from({length:m.n},(_,i)=>i)).filter(p=>Math.abs(p.indexOf(0)-p.indexOf(1))!==1).length);
 case 'restrictedTeam':return combinations(Array.from({length:m.n},(_,i)=>i),3).filter(p=>p.includes(0)&&p.includes(1)).length;
 case 'digitComplement':{let count=0;for(let k=0;k<10**m.length;k++)if([...String(k).padStart(m.length,'0')].filter(v=>v===String(m.digit)).length===1)count++;return count}
 case 'chartScale':return ((m.a+1)+(m.b+1)+(m.c+1))*m.unit-(m.a+m.b+m.c)*m.unit;
 case 'missingAverage':{const omitted=m.count*m.mean-(m.count-1)*m.other;return ((m.count-1)*m.other+2*omitted)/(m.count+1)}
 case 'diceSum':{let all=0,good=0;for(let a=1;a<=m.faces;a++)for(let b=1;b<=m.faces;b++)if(a!==b){all++;if(a+b===m.target)good++}return good/all}
 case 'foldHoles':return 4*(m.interior+1)+2*(m.edge-1)+m.center;
 case 'checkerDomino':return cached('top-domino-'+m.w+'-'+m.h,()=>domino(m.w,m.h,(x,y)=>y===0&&(x===0||x===m.w-1)));
 case 'natural-weighted':case 'natural-fractionWeighted':{const scores=[...Array(2*m.red).fill(m.redScore/m.den),...Array(m.blue).fill(m.blueScore/m.den)];return scores.reduce((a,b)=>a+b,0)/scores.length}
 case 'natural-catch':return m.slow*m.delay;
 case 'natural-tiles':{const w=2*m.w,h=2*m.h,candidates=Array.from({length:Math.min(w,h)},(_,i)=>i+1).filter(v=>w%v===0&&h%v===0);return Math.min(...candidates.map(s=>(w/s)*(h/s)))}
 case 'natural-pairChance':{let all=0,good=0;for(let a=0;a<m.red+m.blue;a++)for(let b=0;b<m.red+m.blue;b++){all++;if(a<m.red&&b<m.red)good++}return good/all}
 case 'natural-unionChance':case 'natural-complementChance':return m.both/(m.red+m.blue-m.both);
 case 'natural-offers':{let count=1;while(count*m.price*3/4+m.fee>count*(m.price-1))count++;return count}
 case 'natural-angleRatio':{const parts=[...m.ratios,Math.max(...m.ratios)],unit=360/parts.reduce((a,b)=>a+b,0);return Math.min(...parts)*unit}
 case 'natural-digitCount':case 'natural-distinctDigitCount':{let count=0;for(const a of m.digits)for(const b of m.digits)if((m.distinct||a!==b)&&(10*a+b)%3===0)count++;return count}
 case 'natural-coordinateDistance':return Math.abs(m.dx)+Math.abs(m.dy);
 case 'routeProbability':{const p=paths(m.w,m.h);return p.up/p.all}
 case 'cubeProbability':{let total=0,good=0;for(let x=0;x<m.n;x++)for(let y=0;y<m.n;y++)for(let z=0;z<m.n;z++){const paints=[x,y,z].filter(v=>v===0||v===m.n-1).length;if(paints>0)total++;if(paints===2)good++}return good/total}
 case 'overlapProbability':return (m.n-m.dx)*(m.n-m.dy)/(m.n*m.n);
 case 'ratioUnion':return m.a*m.unit/(m.b*m.unit+1);
 case 'chartAverage':{const scores=m.counts.flatMap((c,i)=>Array(c).fill(2+2*i));scores.push(6);return scores.reduce((a,b)=>a+b,0)/scores.length}
 case 'parityPermutations':return cached('no-adjacent-odd-'+m.n,()=>permutations(Array.from({length:m.n},(_,i)=>i+1)).filter(p=>p.every((v,i)=>i===0||v%2===0||p[i-1]%2===0)).length);
 case 'recurrenceRemainders':{let a=2n,b=2n,sum=0;for(let i=0;i<m.n;i++){sum+=Number(a%3n);[a,b]=[b,a+b]}return sum}
 default:throw Error('Missing reviewed transfer oracle '+id);
 }
}
module.exports={expansionOracle,reviewedTransferOracle,n};
