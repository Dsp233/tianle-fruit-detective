'use strict';
const CompetitionRules=((rel,models,h)=>{
 const {competitionRng:rng,competitionNumericOptions:numericOptions}=h;
 const value=v=>rel.decimal(rel.number(typeof v==='string'&&!v.includes('/')?Number(v):v));
 const A=(...x)=>['add',...x],S=(a,b)=>['sub',a,b],M=(...x)=>['mul',...x],D=(a,b)=>['div',a,b];
 const partners={'join-open':'join-closed','join-closed':'join-open','join-piece':'join-closed','posts-both':'posts-neither','posts-neither':'posts-both','weighted-mean':'weighted-score','weighted-score':'weighted-mean','ratio-length':'ratio-perimeter','ratio-perimeter':'ratio-length','fraction-reverse':'fraction-original','fraction-original':'fraction-reverse','packs-exact':'packs-enough','packs-enough':'packs-exact'};
 const tweaks={'weighted-mean':{mean:A('mean',D('a','people'))},'weighted-score':{low:A('low',1)},'ratio-length':{width:M('width',2)},'ratio-perimeter':{perimeter:M('perimeter',2)}};
 function parameters(key,r,generatorRevision=1){
  const d=models[key];let p,context;
  if(d.model==='joined-length'){const n=3+r(3),piece=18+r(15),lap=1+r(4);p={n,piece,lap,total:n*piece-(n-1)*lap};context=r(2)?'panels':'ribbon'}
  if(d.model==='interval-endpoints'){const gap=3+r(8),intervals=3+r(7);p={distance:gap*intervals,gap};context='trail'}
  if(d.model==='weighted-total'){const a=1+r(3),b=a+1+r(3),low=6+r(10),high=low+2+r(8);p={a,b,low,high,mean:rel.format(rel.evaluate(D(A(M('a','low'),M('b','high')),A('a','b')),{a:rel.q(a),b:rel.q(b),low:rel.q(low),high:rel.q(high)}))};context='teams'}
  if(d.model==='ratio-perimeter'){const a=1+r(3),b=a+1+r(3),unit=2+r(7);p={a,b,width:a*unit,perimeter:2*(a+b)*unit};context='enclosure'}
  if(d.model==='fraction-wholes'){const d1=2+r(3),d2=3+r(3),k=2+r(8);p={d1,d2,start:d1*d2*k,left:(d1-1)*(d2-1)*k};context=key==='fraction-original'?'water':r(2)?'supplies':'water'}
  if(d.model==='finite-purchase'&&generatorRevision===1){const size=3+r(3),single=3+r(6),pack=size*single-1-r(single),count=size+2+r(15);p={size,single,pack,count};context=r(2)?'brushes':'seedlings'}
  // Revision 1 must consume the same RNG calls to replay every RC65 recipe.
  // New recipes sample reviewed decision cases; classification is independently
  // checked by exhaustive purchase plans in the test, not by this case label.
  if(d.model==='finite-purchase'&&generatorRevision===2){
   const size=3+r(3),single=3+r(6),decision=r(4),quotient=2+r(3);
   const remainder=decision===3?0:decision===2?1+r(size-1):size-1;
   const pack=decision===0?(size-2)*single+1+r(single-1):decision===1?(size-1)*single:(size-1)*single+1+r(single-1);
   p={size,single,pack,count:quotient*size+remainder};context=r(2)?'brushes':'seedlings';
  }
  return {params:Object.fromEntries(d.inputs.map(k=>[k,p[k]])),context};
 }
 function options(answer,misconceptions,r){const out=[];for(const v of [answer,...misconceptions.map(m=>m.value),...numericOptions(answer,r)]){const n=value(v);if(Number.isFinite(n)&&n>=0&&!out.some(x=>Math.abs(value(x)-n)<1e-12))out.push(String(v));if(out.length===5)break}if(out.length!==5)throw Error('Five distinct choices unavailable');for(let i=4;i>0;i--){const j=r(i+1);[out[i],out[j]]=[out[j],out[i]]}return out}
 function create(key,params,context,r=rng(1)){
  const def=models[key];if(!def)throw Error('Unknown rule');const c=rel.compile(def,params,context),next=partners[key],env={...c.env};
  for(const [name,e]of Object.entries(tweaks[key]||{}))env[name]=rel.evaluate(e,env);
  const nextDef=models[next],nextParams=Object.fromEntries(nextDef.inputs.map(k=>[k,rel.format(env[k])]));
  let nextContext=context;
  if(nextDef.model==='fraction-wholes'&&context==='supplies'){
   const proposed=rel.bind(nextDef,nextParams).env;
   if(['start','first','second','left'].some(k=>proposed[k]?.d!==1))nextContext='water';
  }
  const changed=rel.compile(nextDef,nextParams,nextContext);
  function attachCandidates(x){for(const method of x.methods)for(const frame of method.frames)if(frame?.kind==='rule-candidates'){frame.rows=x.candidateRows.map(row=>[row.packs,row.singles,row.bought,row.cost]);frame.headers=['包数','单买数','总数量','费用']}}
  attachCandidates(c);attachCandidates(changed);
  return {family:'rule-'+key,title:c.title,strategy:def.reasoningKey,reasoningKey:def.reasoningKey,structureKey:def.model+':'+key,answer:c.answer,options:options(c.answer,c.misconceptions,r),prompt:c.prompt,
   math:{ruleVersion:1,variant:key,context,params},diagram:c.diagram,methods:c.methods,ruleHints:c.hints,hintDiagram:c.hintDiagram,misconceptions:c.misconceptions,
   relationModel:{key:def.model,variant:key,target:def.target,inputs:def.inputs,relations:def.derive||[],search:def.search||null},
   extension:{prompt:(context==='panels'&&def.model==='joined-length'&&next==='join-closed'?'换成同样长度的软塑料条，并改变连接方式：':'条件变化：')+changed.prompt,answer:changed.answer,solution:changed.methods[0].steps.join(' '),kind:'condition-change',key:'rules-v1:'+next+':'+JSON.stringify(nextParams),topicIds:nextDef.topics,math:{variant:next,context:nextContext,params:nextParams},diagram:changed.diagram,solutionFrames:changed.methods[0].frames},
   ruleEvidence:{model:def.model,variant:key,next,changeKind:'goal-or-condition'}};
 }
 const catalog=Object.entries(models).map(([key,def])=>({id:'rule-'+key,topicIds:def.topics,level:def.level,title:def.title,strategy:def.reasoningKey,reasoningKey:def.reasoningKey,structureKey:def.model+':'+key,insight:def.hints[0],origin:'rc65-rules',build(seed,generatorRevision=1){const r=rng(seed),p=parameters(key,r,generatorRevision);return create(key,p.params,p.context,r)}}));
 const cell=(label,amount,caption,role='whole')=>({label,parts:[{size:{$:amount},caption,role}]});
 const bars=(title,...rows)=>({kind:'rule-bars',title,rows});
 const grid=(focus)=>({kind:'rule-border',n:{$:'n'},focus,title:'同一边框中的新增与原有部分'});
 const adapters={
  squareBorder:{reasoningKey:'difference-and-disjoint-parts',params:m=>({n:m.n}),def:{inputs:['n'],derive:[['outer',A('n',2)],['old', ['pow','n',2]],['whole',['pow','outer',2]],['added',S('whole','old')],['partial',S(['pow',A('n',1),2],'old')]],target:'added'},variation:'partial',hints:['先想一想，题目求整个大阵，还是增加的那一圈？','可以只数新增部分；如果分成几条边，要检查角是否重复。'],frames:[grid('whole'),grid('added')],hintDiagram:{kind:'rule-border',n:{$:'n'},focus:'given',title:'原有方阵外加一圈，先找新增部分。'}},
  chartScale:{reasoningKey:'scale-and-total',params:m=>({a:m.a,b:m.b,c:m.c,known:m.a*m.unit}),def:{inputs:['a','b','c','known'],derive:[['unit',D('known','a')],['height',A('b','c')],['total',M('height','unit')],['increment',M(3,'unit')]],target:'total'},variation:'increment',hints:['先确定一格表示多少人。','合并乙丙的格数，再用同一个刻度转换人数。'],frames:[bars('由甲确定同一刻度',cell('甲人数','known','{a} 格 → {known} 人')),bars('格数与人数对应',cell('乙丙人数','total','{height} 格 → {total} 人'))]},
  missingAverage:{reasoningKey:'weighted-total',params:m=>({count:m.count,mean:m.mean,other:m.other}),def:{inputs:['count','mean','other'],derive:[['remaining',S('count',1)],['old',M('count','mean')],['rest',M('remaining','other')],['removed',S('old','rest')],['baseline',M('remaining','mean')],['deviation',M('remaining',S('mean','other'))],['variation',D(A('old','removed'),A('count',1))]],target:'removed'},variation:'variation',hints:['平均数和人数一起，能确定什么总量？','比较删去前后的总和，或比较相对于原平均的偏差。'],frames:[bars('平均数先转换为总和',cell('原总和','old','{count} 个，合计 {old}'),cell('余下总和','rest','{remaining} 个，合计 {rest}')),bars('原总和由剩下与删去两部分组成',{label:'原总和',parts:[{size:{$:'rest'},caption:'余下 {rest}',role:'whole'},{size:{$:'removed'},caption:'删去 {removed}',role:'change'}]})]},
  fractionBackwards:{reasoningKey:'inverse-changing-wholes',params:m=>({d1:2,d2:3,left:m.left}),def:models['fraction-reverse'],variationDef:{inputs:['start'],derive:[['remaining',D('start',6)]],target:'remaining'},hints:models['fraction-reverse'].hints},
  packPrice:{reasoningKey:'minimum-under-equality',params:m=>({size:3,single:m.single,pack:m.pack,count:m.count}),def:models['packs-exact'],variationDef:models['packs-enough'],hints:models['packs-exact'].hints},
  transferBetweenBoxes:{reasoningKey:'difference-and-conservation',params:m=>({a:m.a,b:m.b,moved:m.moved}),def:{inputs:['a','b','moved'],derive:[['difference',M(2,'moved')],['parts',S('b','a')],['unit',D('difference','parts')],['first',M('a','unit')],['second',M('b','unit')],['equal',A('first','moved')],['external',S('difference','moved')]],target:'first'},variation:'external',hints:['一次转移时，两盒各自怎样改变？','原来的数量差，对应的是转移数量的一倍还是两倍？'],frames:[bars('转移同时改变两边',cell('原来甲','first','{first} 块'),cell('原来乙','second','{second} 块')),bars('差与份数对应',cell('原来的差','difference','{parts} 份 → {difference} 块','change'),cell('一份','unit','{unit} 块')),bars('转移后相等，核对总量',cell('甲移后','equal','{equal} 块'),cell('乙移后','equal','{equal} 块'))]}
 };
 // Each old route receives frames for its own reasoning order, while its
 // wording, options and mathematical identity remain unchanged.
 const routeFrames={
  squareBorder:env=>[[grid('whole'),grid('added')],[{...grid('sides'),title:'上、下各 {outer} 块；左、右不重复角，各 {n} 块'},grid('added')]],
  chartScale:env=>[null,[{kind:'rule-table',title:'先比较柱高',rows:[['甲','{a} 格'],['乙丙','{height} 格'],['乙丙是甲的','{height}/{a} 倍']]},bars('同刻度下，人数随柱高同比变化',cell('甲','known','{known} 人'),cell('乙丙','total','{total} 人'))]],
  missingAverage:env=>[null,[bars('余下各数相对原平均的合计',cell('按原平均计','baseline','{remaining}×{mean}={baseline}'),cell('实际合计','rest','{remaining}×{other}={rest}')),bars('删去的数补足同样的偏差',{label:'删去的数',parts:[{size:{$:'mean'},caption:'原平均 {mean}',role:'whole'},{size:{$:'deviation'},caption:'补偿 {deviation}',role:'change'}]})]],
  fractionBackwards:env=>[[bars('先还原第二天开始的整体',{label:'第二天开始',parts:[{size:{$:'second'},caption:'第二天用 {second}',role:'change'},{size:{$:'left'},caption:'剩余 {left}',role:'whole'}]}),bars('再还原最初的整体',{label:'最初',parts:[{size:{$:'first'},caption:'第一天用 {first}',role:'change'},{size:{$:'afterFirst'},caption:'第一天后 {afterFirst}',role:'whole'}]})],[bars('把最初的六份对应到两次使用',{label:'最初的六份',parts:[{size:{$:'first'},caption:'第一天 3 份：{first}',role:'change'},{size:{$:'second'},caption:'第二天 1 份：{second}',role:'change'},{size:{$:'left'},caption:'最后 2 份：{left}',role:'whole'}]}),bars('由剩余的两份还原六份',cell('2 份','left','{left} 枚'),cell('6 份','start','{start} 枚'))]],
  packPrice:env=>[[{kind:'rule-table',title:'每包替代同样数量的单买',rows:[['{size} 支单买',rel.format(rel.evaluate(M('size','single'),env))+' 元'],['一包','{pack} 元'],['每替换一包省',rel.format(rel.evaluate(S(M('size','single'),'pack'),env))+' 元']]},bars('最低费用对应的恰好方案',cell('最低费用','cost','{packs} 包＋{singles} 支，共 {cost} 元'))],null],
  transferBetweenBoxes:env=>[[bars('转移让两边的差同时缩小',{label:'原来的差',parts:[{size:{$:'moved'},caption:'乙减少 {moved}',role:'change'},{size:{$:'moved'},caption:'甲增加 {moved}',role:'change'}]}),bars('差与份数对应',cell('原来的差','difference','{parts} 份 → {difference} 块'),cell('一份','unit','{unit} 块')),bars('原来甲的份数确定其数量',cell('原来甲','first','{a} 份 → {first} 块'))]]
 };
 function decorate(c,id){
  const a=adapters[id];if(!a)return c;const p=a.params(c.math),bound=rel.bind(a.def,p),env=bound.env;
  if(Math.abs(value(bound.answer)-value(c.answer))>1e-10)throw Error('Legacy rule mismatch '+id);
  const variation=a.variationDef?rel.bind(a.variationDef,Object.fromEntries(a.variationDef.inputs.map(k=>[k,rel.format(env[k])]))).answer:rel.format(env[a.variation]);
  if(Math.abs(value(variation)-value(c.extension.answer))>1e-10)throw Error('Legacy transfer mismatch '+id);
  let frames=a.frames?.map(f=>rel.material(f,env));
  if(a.def.contexts){const compiled=rel.compile(a.def,p,id==='fractionBackwards'?'water':'brushes');frames=compiled.methods[0].frames;for(const f of frames)if(f?.kind==='rule-candidates'){f.headers=['包数','单买数','总数量','费用'];f.rows=compiled.candidateRows.map(row=>[row.packs,row.singles,row.bought,row.cost])}}
  const perRoute=routeFrames[id]?.(env)||[];
  c.methods=c.methods.map((m,route)=>{const selected=perRoute[route]?perRoute[route].map(f=>rel.material(f,env)):frames;return {...m,frames:m.steps.map((_,i)=>selected[Math.min(i,selected.length-1)])}});
  c.ruleHints=a.hints.map(h=>rel.text(h,env));c.hintDiagram=a.hintDiagram?rel.material(a.hintDiagram,env):null;c.reasoningKey=a.reasoningKey;c.structureKey='legacy:'+id;
  c.relationModel={key:'legacy:'+id,target:a.def.target,inputs:a.def.inputs,relations:a.def.derive||[],search:a.def.search||null};return c;
 }
 return {catalog,models,adapters,create,decorate,parameters,reasoningKey:id=>adapters[id]?.reasoningKey};
})(typeof module!=='undefined'?require('./competition_relations'):CompetitionRelations,typeof module!=='undefined'?require('./competition_rule_models'):COMPETITION_RULE_MODELS,typeof module!=='undefined'?require('./competition'):{competitionRng,competitionNumericOptions});
if(typeof module!=='undefined')module.exports=CompetitionRules;
