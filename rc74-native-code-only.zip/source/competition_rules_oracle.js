'use strict';
// Separate numerical/physical solver. No generator, relation DSL or answers.
const number=x=>String(x).includes('/')?String(x).split('/').map(Number).reduce((a,b)=>a/b):Number(x);
function searchMonotone(target,f){let lo=0,hi=100000;for(let i=0;i<60;i++){const m=(lo+hi)/2;if(f(m)<target)lo=m;else hi=m}return (lo+hi)/2}
function rulesOracle(math){
 const key=math.variant,p=Object.fromEntries(Object.entries(math.params).map(([k,v])=>[k,number(v)]));
 if(key.startsWith('join-')){function length(each,closed){let total=each;for(let i=1;i<p.n;i++)total+=each-p.lap;return closed?total-p.lap:total}if(key==='join-piece')return searchMonotone(p.total,x=>length(x,false));return length(p.piece,key==='join-closed')}
 if(key.startsWith('posts-')){let count=0;for(let x=0;x<=p.distance;x+=p.gap)if(key==='posts-both'||x>0&&x<p.distance)count++;return count}
 if(key.startsWith('weighted-')){function mean(score){const all=[...Array(p.a).fill(score),...Array(p.b).fill(p.high)];return all.reduce((s,v)=>s+v,0)/all.length}return key==='weighted-mean'?mean(p.low):searchMonotone(p.mean,mean)}
 if(key.startsWith('ratio-')){if(key==='ratio-perimeter'){const width=p.width,length=width*p.b/p.a;return width+length+width+length}const unit=searchMonotone(p.perimeter,u=>u*p.a+u*p.b+u*p.a+u*p.b);return unit*p.b}
 if(key.startsWith('fraction-')){if(key==='fraction-original'){const used=[p.start/p.d1,p.start/p.d2];return used.reduce((left,v)=>left-v,p.start)}return searchMonotone(p.left,start=>{const afterFirst=start-start/p.d1;return afterFirst-afterFirst/p.d2})}
 if(key.startsWith('packs-')){let min=Infinity;for(let a=0;a<=p.count;a++)for(let b=0;b<=p.count;b++){const bought=a*p.size+b;if(key==='packs-exact'?bought===p.count:bought>=p.count)min=Math.min(min,a*p.pack+b*p.single)}return min}
 throw Error('Independent oracle missing '+key);
}
module.exports={rulesOracle};
