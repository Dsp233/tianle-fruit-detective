'use strict';
const CompetitionSpeech=(()=>{
 let sequence=0,active=null;
 function stop(){sequence++;active=null;if(typeof window!=='undefined'&&window.speechSynthesis)window.speechSynthesis.cancel()}
 function speak(request,engine=window.speechSynthesis){stop();if(!engine||typeof SpeechSynthesisUtterance!=='function')return false;const n=sequence,u=new SpeechSynthesisUtterance(request.text);u.lang='zh-CN';active={...request,sequence:n};u.onend=u.onerror=()=>{if(sequence===n)active=null};engine.speak(u);return true}
 function numericOption(value){const text=String(value).replace(/[％]/g,'%').replace(/\s/g,'');return /^[+−\-]?(?:\d+(?:\.\d+)?(?:\/\d+(?:\.\d+)?)?%?|[\d()+−\-*/×÷.]+)$/.test(text)}
 return {speak,stop,numericOption,getStatus:()=>active?{...active}:null};
})();
if(typeof module!=='undefined')module.exports=CompetitionSpeech;
