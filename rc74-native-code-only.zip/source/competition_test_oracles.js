'use strict';
const assert=require('assert');
const num=s=>String(s).includes('/')?String(s).split('/').map(Number).reduce((a,b)=>a/b):Number(s);
const equal=(a,b)=>Math.abs(num(a)-num(b))<1e-9;
function integratedOracle(task){
 const p=task.competition,m=p.math;let answer,extension;
 switch(p.family){
 case 'garden':answer=m.width*m.height/2;extension=m.width*m.height*0.75;break;
 case 'areaChance':case 'gardenChance':answer=(m.cutWidth/m.width)*(m.cutHeight/m.height);extension=1-answer;break;
 case 'weighted':case 'fractionWeighted':answer=(m.red*m.redScore/m.den+m.blue*m.blueScore/m.den)/(m.red+m.blue);extension=answer+1;break;
 case 'fractionMean':answer=(m.redScore/m.den+2*m.blueScore/m.den)/3;extension=answer+1;break;
 case 'catch':{let t=0;while(m.fast*t!==m.slow*(t+m.delay)){t++;assert(t<1000)}answer=t;let e=0;while(m.fast*e!==m.slow*(e+m.delay+1))e++;extension=e;break;}
 case 'tiles':{let largest=1;for(let s=1;s<=Math.min(m.w,m.h);s++)if(m.w%s===0&&m.h%s===0)largest=s;answer=(m.w/largest)*(m.h/largest);extension=answer*4;break;}
 case 'pairChance':{let all=0,good=0;for(let a=0;a<m.red+m.blue;a++)for(let b=a+1;b<m.red+m.blue;b++){all++;if(a<m.red&&b<m.red)good++}answer=good/all;extension=(all-good)/all;break;}
 case 'unionChance':case 'complementChance':{const red=new Set(Array.from({length:m.red},(_,i)=>i)),blue=new Set([...Array.from({length:m.both},(_,i)=>i),...Array.from({length:m.blue-m.both},(_,i)=>m.red+i)]),joined=new Set([...red,...blue]).size;answer=(p.family==='unionChance'?joined:m.total-joined)/m.total;extension=1-answer;break;}
 case 'offers':{let base=0,second=0;for(let i=0;i<m.count;i++){base+=m.price;second+=m.price-1}answer=Math.abs(base*0.75+m.fee-second);extension=base*0.75;break;}
 case 'scaleArea':case 'similarArea':answer=(m.w*m.factor)*(m.h*m.factor)-m.w*m.h;extension=m.w*m.factor*m.h;break;
 case 'coordinateDistance':answer=Math.hypot(m.dx,m.dy);extension=m.dx+m.dy;break;
 case 'angleRatio':answer=180*m.ratios[2]/m.ratios.reduce((a,b)=>a+b,0);extension=answer-180*m.ratios[0]/m.ratios.reduce((a,b)=>a+b,0);break;
 case 'departures':{let t=1;while(t%m.a||t%m.c)t++;answer=t*m.speed;extension=2*t*m.speed;break;}
 case 'digitCount':case 'distinctDigitCount':{let count=0,other=0;for(let n=10;n<100;n++){const a=Math.floor(n/10),b=n%10;if(m.digits.includes(a)&&m.digits.includes(b)&&n%3===0){if(!m.distinct||a!==b)count++;if(m.distinct||a!==b)other++}}answer=count;extension=other;break;}
 default:throw Error('Missing integrated oracle');
 }
 assert(equal(p.answer,answer),p.family+' independent solution');assert(equal(p.extension.answer,extension),p.family+' independent variation');
 return {answer,extension};
}
module.exports={integratedOracle};
