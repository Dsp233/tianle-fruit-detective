'use strict';
const CompetitionWork=(()=>{
 const clone=x=>x==null?x:JSON.parse(JSON.stringify(x));
 const emptyScope=id=>({scopeId:id,input:{raw:'',selectedOptionId:null,revision:0},eliminatedOptionIds:[],answerState:'editing',feedback:null,lastSubmissionKey:null,attemptIds:[],help:{open:false,revealedHintIds:[],solutionSeen:false,firstSeenAtByHint:{},legacyExposure:'known'},reasoning:null,sketch:null});
 const variationId=task=>'variation:'+task.competition.extension.key;
 function bind(work,task){
  const main=work.scopes.main,variation=work.scopes[variationId(task)];
  for(const [name,scope,key] of [['extensionInput',variation,'input'],['extensionResult',variation,'feedback'],['reasoning',main,'reasoning'],['sketch',main,'sketch'],['solutionOpen',main,'solutionSeen']]){
   Object.defineProperty(work,name,{configurable:true,get(){return key==='input'?scope.input.raw:key==='solutionSeen'?scope.help.solutionSeen:scope[key]},set(value){if(key==='input'){if(scope.input.raw!==value)scope.input.revision++;scope.input.raw=String(value)}else if(key==='solutionSeen')scope.help.solutionSeen=value===true;else scope[key]=value}});
  }
  Object.defineProperty(work,'hintLevel',{configurable:true,get:()=>main.help.revealedHintIds.length,set(value){for(let i=main.help.revealedHintIds.length;i<value;i++)main.help.revealedHintIds.push('main-h'+(i+1));main.help.open=value>0}});
  return work;
 }
 function restore(raw,task,ctx={}){
  if(raw?.schema>2)throw Error('FUTURE_WORK_SCHEMA');
  const variant=variationId(task),work={kind:'competition-work',schema:2,workId:(ctx.sessionId||'session')+':'+task.id,recipe:clone(task.competition.recipe),activeScopeId:'main',viewMode:'question',scopes:{main:emptyScope('main'),[variant]:emptyScope(variant)},notes:String(raw?.notes||'').slice(0,1200),eliminated:[],method:0,step:0,variationMode:null};
  if(raw?.schema===2&&(raw.workId!==work.workId||JSON.stringify(raw.recipe)!==JSON.stringify(task.competition.recipe))){work.migration={fromSchema:2,reason:'WORK_IDENTITY_MISMATCH',retainedDraft:clone(raw)};return bind(work,task);}
  if(raw?.schema===2){
   for(const id of ['main',variant])if(raw.scopes?.[id]){
    const s=raw.scopes[id],fresh=emptyScope(id);
    work.scopes[id]={...fresh,...clone(s),scopeId:id,input:{...fresh.input,...clone(s.input)},help:{...fresh.help,...clone(s.help)}};
   }
   work.activeScopeId=work.scopes[raw.activeScopeId]?raw.activeScopeId:'main';
  }else if(raw){
   const m=work.scopes.main,v=work.scopes[variant];m.input.raw=String(raw.reasoning?.finalInput||'').slice(0,40);m.reasoning=clone(raw.reasoning);m.sketch=clone(raw.sketch);m.help.solutionSeen=raw.solutionOpen===true;
   for(let i=0;i<Math.min(4,raw.hintLevel||0);i++)m.help.revealedHintIds.push('main-h'+(i+1));m.help.open=m.help.revealedHintIds.length>0;
   v.input.raw=String(raw.extensionInput||'').slice(0,40);v.feedback=clone(raw.extensionResult);m.help.legacyExposure=raw.hintLevel?'unknown':'known';
   work.migration={fromSchema:1};
  }
  for(const field of ['method','step'])work[field]=Number.isInteger(raw?.[field])?raw[field]:0;
  work.eliminated=Array.isArray(raw?.eliminated)?raw.eliminated.filter(n=>Number.isInteger(n)&&n>=0&&n<5):[];
  work.variationMode=['comparison','independent'].includes(raw?.variationMode)?raw.variationMode:null;
  work.scopes.main.eliminatedOptionIds=work.eliminated.map(i=>task.optionIds?.[i]||String(i));
  return bind(work,task);
 }
 function create(task,ctx){return restore(null,task,ctx)}
 function selectScope(work,id){if(!work.scopes[id])throw Error('UNKNOWN_SCOPE');return work.scopes[id]}
 function setInput(work,id,raw,optionId=null){work.activeScopeId=id;const s=selectScope(work,id),text=String(raw??'').slice(0,40);if(s.input.raw!==text||s.input.selectedOptionId!==optionId)s.input.revision++;s.input.raw=text;s.input.selectedOptionId=optionId;s.feedback=null;s.answerState='editing';return s}
 function reduce(work,command,decision={}){const next=clone(work),s=selectScope(next,command.scopeId);if(command.type==='SET_INPUT')setInput(next,command.scopeId,command.payload.raw,command.payload.optionId);if(command.type==='SUBMIT'){s.feedback=clone(decision);s.answerState=decision.ok?'correct':'incorrect';s.lastSubmissionKey=decision.submissionKey||null;if(decision.eventId)s.attemptIds.push(decision.eventId)}return next}
 function submissionKey(work,id,input){const s=selectScope(work,id);return JSON.stringify([work.workId,id,s.input.revision,String(input).trim(),s.modelRevision||0])}
 return {create,restore,bind,selectScope,setInput,variationId,submissionKey,reduce};
})();
if(typeof module!=='undefined')module.exports=CompetitionWork;
