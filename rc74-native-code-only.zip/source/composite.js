'use strict';
function compositeRect(rows,cols){return Array.from({length:rows},(_,r)=>Array.from({length:cols},(_,c)=>[r,c])).flat()}
const COMPOSITE_TASKS={
 'G03.01':{kind:'union',rows:4,cols:4,fixed:compositeRect(2,3),piece:compositeRect(1,3),start:[0,0],context:'拼合前先排除重叠',prompt:'绿色2×3块与橙色1×3块起初重叠。实际移动橙块，拼成连通且不重叠的图形，再填写总面积。',explain:'6格与3格不重叠时覆盖9格；重叠时不能直接相加。',reason:{prompt:'什么条件下可以把两块面积直接相加？',options:['两块内部没有重叠，全部材料都保留','只要有两种颜色','看起来像长方形即可'],answer:0}},
 'G03.02':{kind:'cut',rows:4,cols:4,remove:[[2,2],[2,3],[3,2],[3,3]],context:'剪下右下角',prompt:'实际剪去4×4方格右下2×2的四格，剪下的格移入材料盘。填写保留面积。',explain:'原16格，实际剪去4格，剩12格；剪错位置不能算完成。',reason:{prompt:'为什么保留面积是12格？',options:['整块16格减去实际剪下的4格','只数剪下的4格','把剩余图形的边长相加'],answer:0}},
 'G03.03':{kind:'move',rows:4,cols:5,fixed:compositeRect(3,3).map(([r,c])=>[r,c+1]),piece:compositeRect(3,1),start:[0,4],destination:[0,0],context:'同一条方格材料实际平移',prompt:'从3×4长方形右侧剪下的橙色1×3条已单独标出。实际把它移到左侧，填写面积，并判断移动材料时必然保留的量。',explain:'同12个单位格只改变位置，面积仍12；这次重新拼成矩形周长也相同，但一般割补不保证周长不变。',reason:{prompt:'为什么移动后面积不变？',options:['原来的12格只换位置，没有增减或重叠','任何移动都保证周长不变','橙色材料不计入面积'],answer:0}},
 'G03.04':{kind:'cut',rows:4,cols:4,remove:[[1,1],[1,2]],context:'内部孔洞也按实际格定位',prompt:'只剪去第2行的两个中间格：坐标(2,2)、(3,2)。坐标先列后行；请实际剪下这两格，再填写保留面积。',explain:'内部两个格剪下后留下孔洞，面积16－2＝14；不能改剪角落的两格。',reason:{prompt:'如何确认剪下的是题目指定格？',options:['核对列、行和原格位置，再减去实际剪下的面积','只要总共剪两格就行','内部孔洞不算剪去面积'],answer:0}},
 'G03.05':{kind:'squares',rows:4,cols:4,sizes:[2],context:'移动窗口收录所有正方形',prompt:'把2×2窗口移到4×4网格的每个有效位置，逐一收录。不同正方形可以重叠；请收全后填写总个数。',explain:'左上角有3行×3列＝9个位置；重叠的窗口仍是不同正方形。',reason:{prompt:'怎样避免漏数或重复？',options:['按边长和左上角位置记录，每个位置只收一次','只能收不重叠的四块','16个单位格就是16个2×2方块'],answer:0}}
};
for(const [skillId,t] of Object.entries(COMPOSITE_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:43,mode:'compositeLab',phase:'练',hint:'实际移动或剪下原方格，核对覆盖和位置；数正方形时按边长与左上角分类。'});
if(typeof module!=='undefined')module.exports={COMPOSITE_TASKS,compositeRect};
