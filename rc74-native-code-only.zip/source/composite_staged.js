'use strict';
const compositeStageRect=typeof module!=='undefined'?require('./composite').compositeRect:compositeRect;
const compositeL=[...compositeStageRect(2,3),[2,0]];
const COMPOSITE_CASES={
 'G03.01':[
  [{kind:'union',rows:4,cols:4,context:'同一L形的两种分法',puzzles:[{rows:4,cols:4,label:'横分：6格与1格',fixed:compositeStageRect(2,3),piece:[[0,0]],start:[0,0],target:compositeL},{rows:4,cols:4,label:'竖分：3格与4格',fixed:compositeStageRect(3,1),piece:compositeStageRect(2,2),start:[0,0],target:compositeL}]},'两张盘用不同分法拼同一个L形（上两行各3格，第三行左1格）。实际移开重叠的橙块，按虚线目标拼回，各填写面积。','两种分法均覆盖同7格：6＋1＝3＋4＝7。','同图改两种实际分割，目标覆盖完全相同'],
  [{kind:'union',rows:4,cols:4,fixed:compositeStageRect(2,2),piece:compositeStageRect(1,2),start:[0,0],context:'独立拼6格'},'独立把2×2绿块与1×2橙块拼成相连且不重叠的图形，填写总面积。','4＋2＝6格。','无提示：材料尺寸与总量改变'],
  [{kind:'union',rows:4,cols:4,fixed:compositeStageRect(3,1),piece:compositeStageRect(2,2),start:[0,0],context:'隔日竖条与方块'},'隔日把3×1竖条与2×2方块拼成相连且不重叠的图形，填写覆盖面积。','3＋4＝7格。','隔日：方块与竖条拼合'],
  [{kind:'union',rows:4,cols:4,fixed:compositeStageRect(1,3),piece:compositeStageRect(2,1),start:[0,0],context:'备用横条与竖条'},'独立拼合1×3横条和2×1竖条，实际消除重叠、保持相连，填写总面积。','3＋2＝5格。','备用：不同方向的条状材料']
 ],
 'G03.02':[
  [{kind:'cut',rows:3,cols:5,remove:[[0,4],[1,4],[2,4]],context:'剪角改剪整条'},'从3×5纸板实际剪去最右列的一整条3格，填写留下的面积。','15－3＝12格。','角落方块改为整列条状缺口'],
  [{kind:'cut',rows:3,cols:4,remove:[[2,2],[2,3]],context:'独立右下缺口'},'独立从3×4方格剪去右下角同一行的两格，填写保留面积。','12－2＝10格。','无提示：长方形与非正方形剪块'],
  [{kind:'cut',rows:3,cols:3,remove:[[1,1]],context:'隔日剪内部一格'},'隔日从3×3方格只剪去正中一格，留下内部孔洞，填写面积。','9－1＝8格，孔洞也扣除。','隔日：外边缺口改内部孔洞'],
  [{kind:'cut',rows:4,cols:4,remove:[[0,0],[0,1],[1,0],[1,1]],context:'备用左上缺口'},'独立从4×4方格剪去左上2×2块，填写保留面积。','16－4＝12格。','备用：剪块改在左上角']
 ],
 'G03.03':[
  [{kind:'move',rows:5,cols:5,fixed:compositeStageRect(3,3),piece:compositeStageRect(3,1),start:[0,3],destination:[2,3],requirePerimeterChange:true,context:'面积保留而周长改变'},'实际把3×4矩形最右列的橙条下移两格，仍与绿块相连。填写面积，比较移动前后实际外边段数，并选必然保留的量。','仍12格；外边从14段变18段，面积保留而周长改变。','加入同面积不同周长的实际反例'],
  [{kind:'move',rows:4,cols:5,fixed:compositeStageRect(2,2).map(([r,c])=>[r,c+1]),piece:compositeStageRect(2,1),start:[0,3],destination:[0,0],context:'独立搬两格条'},'独立把2×3矩形右侧橙条移到左侧（左上角坐标1,1），填写面积并选移动材料必然保留的量。','6格，保留的是面积。','无提示：两格材料与两行图形'],
  [{kind:'move',rows:5,cols:4,fixed:compositeStageRect(2,3).map(([r,c])=>[r+1,c]),piece:compositeStageRect(1,3),start:[0,0],destination:[3,0],context:'隔日横条换边'},'隔日把3×3方块最上行的橙条移到最下方（左上角坐标1,4），填写面积并选必然保留的量。','9格，只移动材料不改变面积。','隔日：纵条左右移动改横条上下移动'],
  [{kind:'move',rows:5,cols:5,fixed:compositeStageRect(2,3),piece:compositeStageRect(2,1),start:[0,3],destination:[1,3],requirePerimeterChange:true,context:'备用突出一格'},'独立把2×4矩形最右两格条下移一格，填写面积并选必然保留的量。观察新外边。','8格；外边12段变14段，面积不变。','备用：另一种周长改变的实际移动']
 ],
 'G03.04':[
  [{kind:'cut',rows:4,cols:4,remove:[[1,1],[2,1]],context:'内部横孔改竖孔'},'只剪去第2列的第2、3行两格，即(2,2)、(2,3)。实际形成内部竖孔，填写保留面积。','16－2＝14格，位置必须是内部竖孔。','内部横孔转竖孔，行列角色改变'],
  [{kind:'cut',rows:5,cols:4,remove:[[2,1],[2,2]],context:'独立中间两格'},'独立从5行4列方格剪去第3行的两个中间格(2,3)、(3,3)，填写面积。','20－2＝18格。','无提示：五行长方形，定位第3行'],
  [{kind:'cut',rows:5,cols:5,remove:[[2,1],[2,2],[2,3]],context:'隔日三格内部孔'},'隔日只剪去5×5方格第3行的内部三格(2,3)、(3,3)、(4,3)，填写面积。','25－3＝22格。','隔日：内部孔长度改为3格'],
  [{kind:'cut',rows:4,cols:5,remove:[[1,2],[2,2]],context:'备用中间竖孔'},'独立从4行5列方格剪去第3列的第2、3行两格(3,2)、(3,3)，填写保留面积。','20－2＝18格。','备用：换成长方形的中间竖孔']
 ],
 'G03.05':[
  [{kind:'squares',rows:4,cols:4,sizes:[1,2,3,4],context:'所有尺寸分别收录'},'在4×4网格按边长1、2、3、4分类，实际移动每种窗口、收录全部正方形，再填写总数。总数与网格面积格数不同。','各16、9、4、1个，总30个；面积是16平方格。','同网格从单一尺寸扩展到所有尺寸，区分面积格数与图形个数'],
  [{kind:'squares',rows:3,cols:4,sizes:[2],context:'独立长方形网格'},'独立收全3行4列网格里的2×2正方形，并填写个数。','2×3＝6个。','无提示：网格不再是正方形'],
  [{kind:'squares',rows:4,cols:4,sizes:[3],context:'隔日换3×3窗口'},'隔日收全4×4网格里的3×3正方形，填写个数。允许正方形相互重叠。','2×2＝4个。','隔日：窗口尺寸改为3格'],
  [{kind:'squares',rows:3,cols:3,sizes:[1,2,3],context:'备用所有尺寸'},'独立按边长1、2、3分类收全3×3网格里的正方形，再填写总数。','9＋4＋1＝14个。','备用：另一个全部尺寸的网格']
 ]
};
const compositeStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(COMPOSITE_CASES)){
 if(cases.length!==4)throw Error('Four G03 cases required: '+skillId);compositeStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];compositeStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:67,mode:'compositeLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,context:kind==='transfer'?params.context:'剪拼与测量',hideDerivedValues:kind!=='transfer',prompt,explain,changeDimension,...(kind==='transfer'?{hint:'材料只换位置，面积要按实际覆盖核对；剪下格定位；数方块按边长和左上角分类。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={COMPOSITE_CASES};
