'use strict';
const CONSTRAINT_TASKS={
 'L02.01':{kind:'reverse',groups:3,extra:2,bag:5,context:'三袋加附加糖果',prompt:'3袋一样多，每袋里有未知数再加2颗，共21颗。先把21平均分成3份，再逐份拿掉2颗，找回每袋未知数。',explain:'21÷3＝7；每份7－2＝5，未知数5。',reason:{prompt:'为什么要先除3再减2？',options:['3倍作用于整份□＋2，先找回每份7','先从21直接减2再除3','每袋未知数就是21'],answer:0}},
 'L02.02':{kind:'verify',groups:3,extra:2,bag:5,context:'代回三袋',prompt:'假设未知数是5。给每袋逐颗摆5颗，再给每袋添2颗，核对3袋总共是否21颗。',explain:'每袋5＋2＝7；3袋共21颗，代回成立。',reason:{prompt:'代回时括号怎样处理？',options:['每袋都摆5＋2，再看三袋共21','三袋共摆5＋2','只检查一袋等于21'],answer:0}},
 'L02.03':{kind:'parity',total:7,divisor:2,context:'两两配对的棋子',prompt:'尝试把7枚棋子每2枚配成一组。逐组配对，观察剩余，判断2×一个整数能否等于7。',explain:'能配3组共6枚，余1枚；不存在整数使2×整数＝7。',reason:{prompt:'为什么7不可能是2的整数倍？',options:['两两配对后还剩1枚','有3组就说明7是偶数','把剩下1枚藏起来'],answer:0}},
 'L02.04':{kind:'stock',stock:13,per:5,context:'库存装袋',prompt:'库存13颗，每满袋要5颗。逐袋从库存移入袋中，再尝试多装一袋，观察余量够不够。',explain:'可装2个满袋，余3颗，不足以装第三袋。',reason:{prompt:'为什么三袋不可行？',options:['三袋需15颗，大于库存13','三袋只需3颗','还剩3颗所以一定可装第三袋'],answer:0}},
 'L02.05':{kind:'optimal',stock:13,per:5,context:'寻找最大可行袋数',prompt:'库存13颗，每袋要5颗。分别试1、2、3袋，观察每种方案所需量和余量，再选择最多的可行满袋数。',explain:'1袋和2袋可行，3袋需15颗超过13；最多2袋。',reason:{prompt:'为什么2袋是最优？',options:['2袋可行，3袋超库存，且比1袋多','只要1袋可行就无需比较','3袋更大所以最优'],answer:0}}
};
for(const [skillId,t] of Object.entries(CONSTRAINT_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:25,mode:'constraintLab',phase:'练',hint:'用点和分组看到每一步：先处理外层、再核对整数与库存界限。'});
if(typeof module!=='undefined')module.exports={CONSTRAINT_TASKS};
