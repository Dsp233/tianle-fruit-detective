'use strict';
const CONSTRAINT_CASES={
 'L02.01':[
  [{kind:'reverse',groups:2,extra:3,bag:4,context:'两个积木盘'},'两个一样的盘，每盘是未知袋加3块，共14块。先把整体分两盘，再逐盘拿掉3块。','14÷2＝7，每盘7－3＝4，未知袋4。','由代数式改双盘模型，组数改二'],
  [{kind:'reverse',groups:4,extra:1,bag:3,context:'四份文具'},'四份各有未知数加1支笔，共16支。独立均分后，逐份拿掉附加1支。','每份4支，未知数3。','无提示：四份与单个附加物'],
  [{kind:'reverse',groups:2,extra:2,bag:6,context:'两袋彩珠'},'两袋各有未知数加2珠，共16珠。隔日先均分，再逐袋拿掉附加部分。','每袋8，未知数6。','隔日：未知数大于附加数'],
  [{kind:'reverse',groups:3,extra:1,bag:4,context:'三盒铅笔'},'三盒各有未知数再加1支，共15支。独立逆向分组求未知数。','15÷3＝5，再减1得4。','备用：三盒，每盒一支附加']
 ],
 'L02.02':[
  [{kind:'verify',groups:2,extra:3,bag:4,context:'双盘代回'},'已知袋中4块。两个盘各摆4块袋内和3块袋外，核对总共14块。','2×(4＋3)＝14。','由三袋换双盘，附加数3'],
  [{kind:'verify',groups:4,extra:1,bag:3,context:'四盒检验'},'每盒未知数是3。四盒分别摆3块袋内和1块袋外，核对16。','4×(3＋1)＝16。','无提示：四组代回'],
  [{kind:'verify',groups:2,extra:2,bag:6,context:'两篮水果'},'每篮未知部分6个、额外2个。隔日摆出两篮，核对总数16。','2×(6＋2)＝16。','隔日：额外数2，袋内6'],
  [{kind:'verify',groups:3,extra:1,bag:4,context:'三份卡片'},'每份袋中4张再加1张，独立代回核对总量15张。','3×(4＋1)＝15。','备用：每份只加一张']
 ],
 'L02.03':[
  [{kind:'parity',total:10,divisor:3,context:'三枚一组的贴纸'},'有10张贴纸，试每3张组成一整组。逐组配好，看3×整数能否刚好等于10。','3组用9张，余1张，无整数解。','从奇偶的两两配对迁移到三枚一组'],
  [{kind:'parity',total:9,divisor:2,context:'成双的手套'},'9只手套每2只配一双。独立逐双配对，观察是否能全配完。','4双用8只，余1只，不能全部成双。','无提示：9为奇数'],
  [{kind:'parity',total:11,divisor:2,context:'双座椅'},'11人按每排2人配座。隔日逐排安排，检查整数排数可否坐满。','5排10人余1人，无法正好排成双人排。','隔日：把物品换成人数'],
  [{kind:'parity',total:13,divisor:2,context:'两颗一袋的豆子'},'13颗豆每袋2颗。逐袋分组，判断能否刚好无余数。','6袋12颗余1颗，无整数袋数可全部装满。','备用：总数13']
 ],
 'L02.04':[
  [{kind:'stock',stock:14,per:4,context:'纸花库存'},'14朵纸花，每束4朵。逐束扎好，再试图多扎一束。','可做3束，余2朵，不够第四束。','把颗数与每袋5改成花束每束4'],
  [{kind:'stock',stock:17,per:6,context:'彩纸成套'},'17张彩纸，每套6张。独立逐套取纸，再检查下一套是否够。','可配2套，余5张，不够第三套。','无提示：每套6张'],
  [{kind:'stock',stock:10,per:3,context:'饼干盒'},'10块饼干，每盒3块。隔日逐盒装满并试下一盒。','可装3盒余1块。','隔日：余数缩为1'],
  [{kind:'stock',stock:19,per:5,context:'实验材料包'},'19件材料，每包5件。逐包分装，再检查下一包。','装3包，余4件不足一包。','备用：剩余接近一整包']
 ],
 'L02.05':[
  [{kind:'optimal',stock:14,per:4,context:'最多纸花束'},'14朵花每束4朵。试1、2、3、4束，比较哪一个最大仍可行。','3束用12余2，4束需16超库存。','从袋数改成纸花束，最大可行值改3'],
  [{kind:'optimal',stock:11,per:4,context:'文具套装'},'11支笔每套4支，独立试1、2、3套，选最大可行套数。','2套用8余3；3套需12不够。','无提示：11支与每套4'],
  [{kind:'optimal',stock:17,per:6,context:'小队徽章'},'17枚徽章，每队6枚。隔日试1、2、3队，确认最大可行队数。','2队用12余5；3队需18超出。','隔日：第三队只差1枚'],
  [{kind:'optimal',stock:10,per:3,context:'饼干礼包'},'10块饼干每礼包3块。试1至4包，选最大仍可行的礼包数。','3包用9余1，4包需12超出。','备用：最大可行3包']
 ]
};
const constraintStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(CONSTRAINT_CASES)){
 if(cases.length!==4)throw Error('Four L02 cases required: '+skillId);constraintStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];constraintStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:26,mode:'constraintLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先看每份和整数边界，动手分组，再核对完整条件。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={CONSTRAINT_CASES};
