'use strict';
function constraintState(){return draft.work??(draft.work={divided:false,peeled:0,filled:0,extra:0,pairs:0,bags:0,probed:false,tried:[],trial:0,choice:'',moves:0,log:[]})}
function constraintTotal(task){return task.groups*task.bag+(task.extraOutside?task.extra:task.groups*task.extra)}
function constraintDots(n,label,ids){return `<span class="constraint-dots" role="img" aria-label="${esc(label)}${n}颗">${Array.from({length:n},(_,i)=>`<i ${ids?`data-object-id="${ids[i]}"`:''} aria-hidden="true"></i>`).join('')}</span>`}
function constraintIds(first,n){return Array.from({length:n},(_,i)=>'I'+(first+i))}
function constraintBoard(task){const w=constraintState(),undo=`<button data-action="constraintUndo" ${w.log.length?'':'disabled'}>↩ 撤回一步</button>`;
 if(task.kind==='reverse'){
  const total=constraintTotal(task),outside=!!task.extraOutside,per=task.bag+(outside?0:task.extra);
  const groups=w.divided?Array.from({length:task.groups},(_,g)=>{const remain=per-(outside?0:w.peeled);return `<section><b>第${g+1}份</b>${constraintDots(remain,'组内原点',constraintIds(g*per,remain))}${!outside?`<small>本组已移出${w.peeled}</small>${constraintDots(w.peeled,'本组移出',constraintIds(g*per+remain,w.peeled))}`:''}</section>`}).join(''):constraintDots(total-w.peeled,'尚未分组的原点',constraintIds(0,total-w.peeled));
  return `<div class="board constraint-board"><h3>${esc(task.context)} · ${outside?`${task.groups}×□＋${task.extra}`:`${task.groups}×(□＋${task.extra})`}＝${total}</h3><div class="constraint-groups">${groups}</div>${outside?`<section class="constraint-outside"><b>整体只移出一次</b>${constraintDots(w.peeled,'整批移出原点',constraintIds(total-w.peeled,w.peeled))}</section>`:''}<div class="work-buttons"><button data-action="constraintDivide" ${w.divided||outside&&w.peeled!==task.extra?'disabled':''}>把剩余原点均分成${task.groups}份</button><button data-action="constraintPeel" ${outside?w.divided||w.peeled>=task.extra?'disabled':'':!w.divided||w.peeled>=task.extra?'disabled':''}>${outside?'整体移出1颗':'每份移出1颗'}</button>${undo}</div></div>`;
 }
 if(task.kind==='verify'){
  const total=constraintTotal(task),target=task.givenTotal??total,actual=task.groups*w.filled+(task.extraOutside?w.extra:task.groups*w.extra);
  return `<div class="board constraint-board"><h3>${esc(task.context)} · ${task.extraOutside?`${task.groups}×□＋${task.extra}`:`${task.groups}×(□＋${task.extra})`}＝${target}</h3><div class="constraint-groups">${Array.from({length:task.groups},(_,g)=>`<section><b>第${g+1}袋：袋内${w.filled}${task.extraOutside?'':'，袋外'+w.extra}</b>${constraintDots(w.filled,'未知袋','')}${!task.extraOutside?constraintDots(w.extra,'本袋附加'):''}</section>`).join('')}</div>${task.extraOutside?`<section class="constraint-outside"><b>整批附加一次</b>${constraintDots(w.extra,'整批附加')}</section>`:''}<p>${assessmentFormal(task)?'核对完整原式。':'当前合计 '+actual+'，目标 '+target+'。'}</p><div class="work-buttons"><button data-action="constraintFill" ${w.filled>=task.bag+2?'disabled':''}>每袋添1颗未知部分</button><button data-action="constraintExtra" ${w.extra>=task.extra+2?'disabled':''}>${task.extraOutside?'整体':'每袋'}添1颗附加部分</button>${undo}</div>${task.correctVerdict?choiceButtons(task,[['accept','满足原式'],['reject','不满足原式']],'constraintChoose'):''}</div>`;
 }
 if(task.kind==='parity'){
  const left=task.total-task.divisor*w.pairs;
  return `<div class="board constraint-board"><h3>${esc(task.context)} · 平均分成${task.divisor}个整数组</h3><div class="constraint-groups">${Array.from({length:task.divisor},(_,g)=>`<section><b>第${g+1}组</b>${constraintDots(w.pairs,'本组原点',Array.from({length:w.pairs},(_,i)=>'I'+(i*task.divisor+g)))}</section>`).join('')}<section><b>未分 ${left} 枚</b>${constraintDots(left,'未分原点',constraintIds(task.divisor*w.pairs,left))}</section></div><div class="work-buttons"><button data-action="constraintPair" ${left<task.divisor?'disabled':''}>每组各放1颗</button>${undo}</div>${choiceButtons(task,[['impossible','没有整数解'],['possible','有整数解']],'constraintChoose')}</div>`;
 }
 if(task.kind==='stock'){
  const left=task.stock-w.bags*task.per;
  return `<div class="board constraint-board"><h3>${esc(task.context)} · 库存${task.stock}，每袋${task.per}</h3><div class="constraint-groups">${Array.from({length:w.bags},(_,g)=>`<section><b>第${g+1}满袋</b>${constraintDots(task.per,'袋内原点',constraintIds(g*task.per,task.per))}</section>`).join('')}<section><b>库存还剩 ${left}</b>${constraintDots(left,'未装原点',constraintIds(w.bags*task.per,left))}</section>${w.probed?`<section class="shortage"><b>下一袋还缺${task.per-left}个位置</b></section>`:''}</div><div class="work-buttons"><button data-action="constraintPack" ${left<task.per?'disabled':''}>装一满袋</button><button data-action="constraintProbe" ${left>=task.per||w.probed?'disabled':''}>核对下一袋的缺口</button>${undo}</div></div>`;
 }
 const candidates=Array.from({length:Math.floor(task.stock/task.per)+2},(_,i)=>i),needed=w.trial*task.per,left=task.stock-needed;
 return `<div class="board constraint-board"><h3>${esc(task.context)} · 库存${task.stock}，每袋${task.per}</h3><div class="work-buttons">${candidates.map(n=>`<button data-action="constraintTrial" data-value="${n}" aria-pressed="${w.trial===n}">试${n}袋${w.tried.includes(n)?' ✓':''}</button>`).join('')}</div>${w.tried.length?`<div class="constraint-demand" style="--demand-cols:${task.per}" role="img" aria-label="候选${w.trial}袋需要${needed}个位置，库存最多填${Math.min(task.stock,needed)}个">${Array.from({length:needed},(_,i)=>`<span class="${i<task.stock?'filled':''}">${i<task.stock?`<i data-object-id="I${i}"></i>`:''}</span>`).join('')}</div>${left>0?constraintDots(left,'剩余库存',constraintIds(needed,left)):''}<p>${left>=0?'库存足够':'空位还缺'+(-left)+'颗'}。</p>`:'<p>比较最多可行方案与紧邻的不可行方案。</p>'}${choiceButtons(task,candidates.map(n=>[String(n),'最多'+n+'袋']),'constraintChoose')}<div class="work-buttons">${undo}</div></div>`;
}
function constraintGrade(task){const w=constraintState(),max=Math.floor(task.stock/task.per);let ok=false;
 if(task.kind==='reverse')ok=w.divided&&w.peeled===task.extra;
 if(task.kind==='verify'){const total=task.groups*w.filled+(task.extraOutside?w.extra:task.groups*w.extra),fits=total===(task.givenTotal??constraintTotal(task));ok=w.filled===task.bag&&w.extra===task.extra&&(task.correctVerdict?w.choice===(fits?'accept':'reject'):fits)}
 if(task.kind==='parity')ok=w.pairs===Math.floor(task.total/task.divisor)&&w.choice===(task.total%task.divisor===0?'possible':'impossible');
 if(task.kind==='stock')ok=w.bags===max&&w.probed;
 if(task.kind==='optimal')ok=w.tried.includes(max)&&w.tried.includes(max+1)&&w.choice===String(max);
 return {ok,incomplete:w.moves===0||task.kind==='parity'&&!w.choice||!!task.correctVerdict&&!w.choice,reason:'先分清附加量属于每组还是整个整体；整数条件和库存边界须同时核对。最多方案要能装下，下一组要装不下。'};
}
function constraintAct(action,data,task){const w=constraintState(),max=Number.isInteger(task.stock)?Math.floor(task.stock/task.per):0;let key=null,old=null;
 const set=(k,v)=>{key=k;old=w[k];w[k]=v};
 if(action==='constraintDivide'&&task.kind==='reverse'&&!w.divided&&(!task.extraOutside||w.peeled===task.extra))set('divided',true);
 if(action==='constraintPeel'&&task.kind==='reverse'&&(task.extraOutside?!w.divided:w.divided)&&w.peeled<task.extra)set('peeled',w.peeled+1);
 if(action==='constraintFill'&&task.kind==='verify'&&w.filled<task.bag+2)set('filled',w.filled+1);
 if(action==='constraintExtra'&&task.kind==='verify'&&w.extra<task.extra+2)set('extra',w.extra+1);
 if(action==='constraintPair'&&task.kind==='parity'&&task.total-task.divisor*w.pairs>=task.divisor)set('pairs',w.pairs+1);
 if(action==='constraintPack'&&task.kind==='stock'&&task.stock-(w.bags+1)*task.per>=0)set('bags',w.bags+1);
 if(action==='constraintProbe'&&task.kind==='stock'&&task.stock-w.bags*task.per<task.per&&!w.probed)set('probed',true);
 if(action==='constraintTrial'&&task.kind==='optimal'){const n=Number(data.value);if(Number.isInteger(n)&&n>=0&&n<=max+1){key='trial';old=[w.trial,[...w.tried]];w.trial=n;if(!w.tried.includes(n))w.tried.push(n)}}
 if(action==='constraintChoose'&&['parity','optimal','verify'].includes(task.kind)){
  const choices=task.kind==='parity'?['impossible','possible']:task.kind==='verify'?['accept','reject']:Array.from({length:max+2},(_,i)=>String(i));if(choices.includes(data.value))set('choice',data.value);
 }
 if(action==='constraintUndo'&&w.log.length){const [k,v]=w.log.pop();if(k==='trial'){w.trial=v[0];w.tried=v[1]}else w[k]=v;w.moves++;return true}
 if(key===null)return false;w.log.push([key,old]);w.moves++;return true;
}
function constraintSpeech(task){const w=constraintState();if(task.kind==='reverse')return `${constraintTotal(task)}个原对象，${task.extraOutside?'整体只':'每组各'}移出${w.peeled}，${w.divided?'已经均分':'尚未均分'}。`;if(task.kind==='verify')return `每袋未知部分${w.filled}，${task.extraOutside?'整批只':'每袋各'}附加${w.extra}。`;if(task.kind==='parity')return `${task.divisor}组各放${w.pairs}个，剩余${task.total-task.divisor*w.pairs}。`;if(task.kind==='stock')return `已装${w.bags}袋，余${task.stock-w.bags*task.per}颗。`;return w.tried.length?`候选${w.trial}袋，库存${task.stock}。`:'还没有试装方案。'}
function constraintPage(){const task=CONSTRAINT_TASKS[microSkillId],skill=SKILL_DATA.skills.find(s=>s.id===microSkillId);if(!task||!skill)return '<div class="panel">操作任务不存在。</div>';return `<div class="page-head"><div><p class="kicker">${esc(task.skillId)}</p><h1>${esc(skill.title)}</h1></div><button class="back" data-action="micro" data-code="${esc(task.skillId)}">← 返回</button></div><div class="work"><article class="panel"><span class="phase">练 · 操作一题</span><h2 class="task-title">${esc(task.prompt)}</h2><div class="workshop-check-top"><button class="primary" data-action="${feedback?.ok?'next':'check'}">${feedback?.ok?'完成本题 →':'检查操作与理由 ✓'}</button></div>${constraintBoard(task)}${reasonBlock(task)}${actionRow(task)}</article><aside class="side-stack">${stageLinks(task.skillId)}</aside></div>`}
