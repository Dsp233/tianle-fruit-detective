'use strict';
const COORDINATE_TASKS={
 'L04.01':{kind:'machine',multiplier:2,add:1,inputs:[1,2,4],context:'输入输出机器',prompt:'机器的两张检验卡是1→3、2→5。调好“先乘、后加”的同一规则，亲手运行三张输入卡，求输入4的输出。',explain:'三张卡都按输入×2＋1运行，得到3、5、9；一个规则要同时符合多组对应。',reason:{prompt:'为什么不能只检验一张卡？',options:['同一规则必须同时符合两张检验卡','只要某一张碰巧对就行','输入4就一定输出4'],answer:0}},
 'L04.02':{kind:'pair',target:[2,3],maxX:5,maxY:5,context:'方格寻宝',prompt:'宝箱在横向2、纵向3。分别点横、纵刻度，再把宝箱落在两条定位线的交点。',explain:'数对(2,3)的第一位是横向2，第二位是纵向3。',reason:{prompt:'(2,3)第一位表示什么？',options:['横向位置2','纵向位置2','两位可以随意交换'],answer:0}},
 'L04.03':{kind:'order',targets:[[2,3],[3,2]],maxX:5,maxY:5,context:'A与B的位置',prompt:'把A(2,3)和B(3,2)分别落在网格上。每次先选要放的字母，再点横纵刻度和交点。',explain:'A横2纵3，B横3纵2；相同的两个数交换顺序会成为不同位置。',reason:{prompt:'A和B为什么不是同一个点？',options:['第一位与第二位分别控制不同方向','两个数一样就一定同点','先纵后横也没有关系'],answer:0}},
 'L04.04':{kind:'move',start:[1,2],dx:3,dy:2,maxX:5,maxY:5,context:'机器人走格',prompt:'机器人从(1,2)出发，向右3格、向上2格。用方向键逐格走到终点，不绕路。',explain:'横向1＋3＝4，纵向2＋2＝4；走5格到(4,4)。',reason:{prompt:'向右3格改变哪个数？',options:['只把横坐标加3','只把纵坐标加3','两个坐标都加3'],answer:0}},
 'L04.05':{kind:'table',pairs:[[1,3],[2,5],[3,7]],maxX:4,maxY:7,context:'表格变坐标图',prompt:'表格三行是输入1输出3、输入2输出5、输入3输出7。逐行选择横纵刻度，在图上放A、B、C三个对应点。',explain:'每一行变成一个数对：(1,3)、(2,5)、(3,7)，输入作横坐标，输出作纵坐标。',reason:{prompt:'表格的一行怎样变成图上的一点？',options:['同一行的输入和输出组成横纵数对','把第一行输入和最后一行输出随意配','输入与输出都放横轴'],answer:0}},
 'L04.06':{kind:'dynamic',startValue:1,step:2,duration:3,maxX:3,maxY:7,context:'机器人位置随时间变化',prompt:'0分钟机器人在位置1，每过1分钟向前2格。调好每分钟的变化，逐分钟运行到3分钟，同时看表格和位置图。',explain:'时间0、1、2、3对应位置1、3、5、7；起点1也要计入。',reason:{prompt:'为什么3分钟不是位置6？',options:['从原来的位置1再增加2×3格','0分钟必须在位置0','只看经过的分钟数'],answer:0}}
};
for(const [skillId,t] of Object.entries(COORDINATE_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:29,mode:'coordinateLab',phase:'练',hint:'先辨认横与纵或输入与输出，再让材料按关系实际变化。'});
if(typeof module!=='undefined')module.exports={COORDINATE_TASKS};
