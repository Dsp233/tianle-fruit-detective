'use strict';
const COORDINATE_CASES={
 'L04.01':[
  [{kind:'machine',multiplier:2,add:1,inputs:[2,3,5],reverseIndex:2,context:'找回输入卡'},'机器2→5、3→7；输出11的输入卡丢了。调好同一规则，试输入并运行三张卡，找回丢失的输入。','先乘2后加1；丢失输入5，输出11。','由给输入求输出改为给输出反求输入'],
  [{kind:'machine',multiplier:3,add:1,inputs:[1,2,3],context:'三份复制机'},'检验卡1→4、2→7。独立调同一先乘后加规则，再运行输入3。','×3＋1，三张输出4、7、10。','无提示：乘数改变，验证两组关系'],
  [{kind:'machine',multiplier:2,add:2,inputs:[1,3,4],context:'印章机器'},'检验卡1→4、3→8。隔日调规则并运行三张输入卡，求输入4的输出。','×2＋2，得到4、8、10。','隔日：检验输入不等距，加数改变'],
  [{kind:'machine',multiplier:3,add:2,inputs:[1,2,4],reverseIndex:2,context:'逆向变数卡'},'机器1→5、2→8。输出14来自什么输入？独立运行规则并找回第三张输入。','×3＋2，输入4得到14。','备用：同时变规则和未知位置']
 ],
 'L04.02':[
  [{kind:'pair',target:[4,1],givenPoint:true,maxX:5,maxY:5,context:'从图读宝箱'},'图中已经放好A。分别点横纵刻度，再把它的位置写成数对。','A横4纵1，所以(4,1)。','由描述落点改为读图写数对'],
  [{kind:'pair',target:[1,4],maxX:5,maxY:5,context:'棋子定位'},'棋子在横1纵4。独立选两轴刻度并落点。','位置(1,4)。','无提示：横纵大小对调'],
  [{kind:'pair',target:[0,3],maxX:5,maxY:5,context:'纵轴上的气球'},'气球横向为0、纵向为3。隔日把它放进图中。','(0,3)在纵轴上。','隔日：包含零坐标'],
  [{kind:'pair',target:[3,0],givenPoint:true,maxX:5,maxY:5,context:'横轴上的旗子'},'图中A在横轴上。独立读出横纵位置，记录数对。','A为(3,0)。','备用：由图读取纵坐标0']
 ],
 'L04.03':[
  [{kind:'order',targets:[[0,3],[3,0]],maxX:5,maxY:5,context:'坐标轴上的两点'},'分别放A(0,3)和B(3,0)。先选字母，再定位两轴与交点。','A在纵轴，B在横轴；0在不同位置控制不同方向。','交换非零数与0，反例落在不同坐标轴'],
  [{kind:'order',targets:[[1,4],[4,1]],maxX:5,maxY:5,context:'交换位置卡'},'独立放好A(1,4)和B(4,1)。','A横1纵4，B横4纵1。','无提示：交换不同大小的两数'],
  [{kind:'order',targets:[[2,5],[5,2]],maxX:5,maxY:5,context:'两只风筝'},'隔日分别定位A(2,5)和B(5,2)。','两点互换横纵位置。','隔日：网格边界上的点'],
  [{kind:'order',targets:[[4,0],[0,4]],maxX:5,maxY:5,context:'零位置反例'},'独立落下A(4,0)和B(0,4)，两张卡都要用上。','A在横轴，B在纵轴。','备用：再次检验零坐标顺序']
 ],
 'L04.04':[
  [{kind:'move',start:[4,4],dx:-3,dy:-2,maxX:5,maxY:5,context:'机器人返回'},'机器人从(4,4)向左3格、向下2格。逐格返回，不绕路。','终点(1,2)，两轴分别减少。','右上位移改为左下反向位移'],
  [{kind:'move',start:[1,4],dx:3,dy:-2,maxX:5,maxY:5,context:'机器人下坡'},'从(1,4)向右3、向下2，独立走最短格数到终点。','终点(4,2)，共5格。','无提示：两个方向一增一减'],
  [{kind:'move',start:[3,1],dx:-2,dy:3,maxX:5,maxY:5,context:'隔日导航'},'从(3,1)向左2、向上3，逐格走到终点。','终点(1,4)。','隔日：改变水平与竖直方向组合'],
  [{kind:'move',start:[0,0],dx:2,dy:4,maxX:5,maxY:5,context:'原点出发'},'独立从(0,0)向右2、向上4，不绕路。','终点(2,4)，共6格。','备用：初始位置为原点']
 ],
 'L04.05':[
  [{kind:'table',direction:'read',pairs:[[1,2],[2,4],[3,6]],maxX:4,maxY:7,context:'坐标图变表格'},'图中A、B、C已经给出。逐点读横纵刻度，写进对应表行。','三行是(1,2)、(2,4)、(3,6)。','由表转图改为图转表，输入输出不能跨行混配'],
  [{kind:'table',pairs:[[0,1],[1,3],[2,5]],maxX:4,maxY:7,context:'零输入表'},'表格三行输入0、1、2，输出1、3、5。独立逐行落点。','A(0,1)、B(1,3)、C(2,5)。','无提示：表格包含0输入'],
  [{kind:'table',direction:'read',pairs:[[1,6],[2,4],[3,2]],maxX:4,maxY:7,context:'下降的点图'},'隔日从下降的A、B、C三点读数，并逐行记录表格。','(1,6)、(2,4)、(3,2)。','隔日：增量图改为下降关系'],
  [{kind:'table',pairs:[[3,6],[1,2],[2,4]],maxX:4,maxY:7,context:'打乱行顺序的表'},'表格按A(3,6)、B(1,2)、C(2,4)给出。独立逐行落点，保持字母对应。','行的顺序虽乱，每个字母仍要匹配自己的一行。','备用：表格行未按横坐标排序']
 ],
 'L04.06':[
  [{kind:'dynamic',startValue:7,step:-2,duration:3,maxX:3,maxY:7,context:'返回中的机器人'},'表格说0分钟在7、1分钟在5。每分钟变化相同；设定变化，运行到3分钟。','每分钟减2；位置7、5、3、1。','增长故事改为下降表格，初始位置非零'],
  [{kind:'dynamic',startValue:0,step:2,duration:3,maxX:3,maxY:7,context:'从原点前进'},'0分钟在0，每分钟前进2格。独立运行到3分钟。','位置0、2、4、6。','无提示：起点为0'],
  [{kind:'dynamic',startValue:1,step:3,duration:2,maxX:2,maxY:7,context:'快一步的机器人'},'0分钟在1，每分钟前进3格。隔日运行到2分钟。','位置1、4、7。','隔日：速率与总时间同时改变'],
  [{kind:'dynamic',startValue:6,step:-1,duration:3,maxX:3,maxY:7,context:'逐分钟返回'},'0分钟在6，每分钟退1格。独立运行到3分钟，逐点保留记录。','位置6、5、4、3。','备用：负变化与非零起点']
 ]
};
const coordinateStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(COORDINATE_CASES)){
 if(cases.length!==4)throw Error('Four L04 cases required: '+skillId);coordinateStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];coordinateStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:30,mode:'coordinateLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先辨认已知与未知，按输入输出或横纵对应实际操作。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={COORDINATE_CASES};
