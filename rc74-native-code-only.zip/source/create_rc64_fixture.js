'use strict';
// A public synthetic fixture created by the actual pre-release production app.
const fs=require('fs'),cp=require('child_process'),{boot}=require('./test_support'),{solve}=require('./test_rc66_defects');
const baseline='d9fd431b633ec2163a0026e5f4006c61c2e86927',clock=Date.UTC(2026,9,7);
const html=cp.execFileSync('git',['show',baseline+':index.html'],{maxBuffer:20*1024*1024}).toString(),app=boot({},clock,html);
app.click('topicSelect',{code:'R01'});app.click('topicSelect',{code:'D02'});app.click('topicStart');
const first=app.value('taskNow()');app.inputCompetition('notes','RC64 合成旧记录：首题先错后对，提示事实保留');app.click('competitionHint');solve(app,first,false);solve(app,first);app.click('next');
const second=app.value('taskNow()');app.inputCompetition('notes','RC64 合成旧记录：第二题草稿保留');app.click('competitionEliminate',{index:String((second.answer+2)%5)});app.run('persist()');
const record=JSON.parse(app.storage.tianle_amc8_question_design_v1);
const fixture={synthetic:true,baselineCommit:baseline,baselineVersion:app.value('window.__AMC8_RELEASE'),record,expected:{firstTask:first.id,firstPrompt:first.prompt,firstAnswer:first.competition.answer,secondTask:second.id,secondPrompt:second.prompt,secondAnswer:second.competition.answer,notes:'RC64 合成旧记录：第二题草稿保留',excludedOption:second.options[(second.answer+2)%5],firstCorrect:false,counts:app.value('competitionProgressCounts()')}};
fs.writeFileSync('source/qa_rc64_fixture.json',JSON.stringify(fixture,null,2)+'\n');
console.log('Created synthetic RC64 fixture from frozen production',baseline);
