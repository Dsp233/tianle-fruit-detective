'use strict';
// RFC-style quoted fields, including embedded newlines and doubled quotes.
function readCsv(text){
 text=text.replace(/^\uFEFF/,'');
 const rows=[];let row=[],field='',quoted=false,closed=false;
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(quoted){if(c==='"'){if(text[i+1]==='"'){field+='"';i++;}else{quoted=false;closed=true;}}else field+=c;continue;}
  if(c==='"'){if(field||closed)throw Error('Unexpected CSV quote');quoted=true;continue;}
  if(c===','||c==='\n'||c==='\r'){
   row.push(field);field='';closed=false;
   if(c!==','){rows.push(row);row=[];if(c==='\r'&&text[i+1]==='\n')i++;}continue;
  }
  if(closed)throw Error('Text after a quoted CSV field');
  field+=c;
 }
 if(quoted)throw Error('Unterminated CSV field');
 if(row.length||field||closed)rows.push([...row,field]);
 const fields=rows.shift()||[];
 if(!fields.length||new Set(fields).size!==fields.length)throw Error('Missing or duplicate CSV columns');
 return {fields,rows:rows.map((values,i)=>{if(values.length!==fields.length)throw Error('Wrong CSV column count at row '+(i+2));return Object.fromEntries(fields.map((f,n)=>[f,values[n]]));})};
}
module.exports={readCsv};
