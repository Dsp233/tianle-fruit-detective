'use strict';
const CURRICULUM=window.__AMC8_CURRICULUM;
const LEARNING_TASKS=Object.fromEntries(Object.entries(CURRICULUM.lessons).map(([sid,n])=>[sid,{id:`K-${sid.replace('.','-')}-1`,skillId:sid,contentVersion:CURRICULUM.contentVersion,phase:'学',mode:'conceptNote',prompt:n.definition+'。'+n.why+'。'+n.use}]));
let learnTab='definition',learnCounterOpen=false;
function learningPrerequisites(sid,visited=new Set()){for(const id of CURRICULUM.lessons[sid]?.prerequisiteIds||[])if(!visited.has(id)){visited.add(id);learningPrerequisites(id,visited)}return visited}
function rememberFormalOpen(task){
 if(!['stage','joint'].includes(view)||!task||!assessmentEvidenceContext(task,{view,stageKind}).formalEligible||taskHistory(task).submissions)return;
 const key=taskVersion(task)+':'+task.id;saved.pendingFormal[key]??={taskId:task.id,contentVersion:taskVersion(task),skillId:task.skillId,stageKind,view,openedAt:Date.now()};persist();
}
function noteTeachingExposure(sid,kind,relationId=''){
 let changed=false;
 for(const [key,pending] of Object.entries(saved.pendingFormal)){
  const descriptor=RECORD_TASK_INDEX.get(key),task=descriptor?.task;
  if(!task||!assessmentEvidenceContext(task,descriptor).formalEligible)continue;
  const targets=task.joint?[...task.joint.targetNodeIds,...task.joint.supportNodeIds]:[pending.skillId];if(!targets.some(id=>id===sid||knowledgeSupportSkills(id).has(sid)))continue;
  const h=taskHistory(task);if(h.submissions>0)continue;
  h.modelViewed=true;h.teachingExposure??=[];if(!h.teachingExposure.some(e=>e.skillId===sid&&e.kind===kind&&((e.relationId||'')===relationId)))h.teachingExposure.push({skillId:sid,kind,relationId,at:Date.now()});changed=true;
 }
 if(changed)persist();
}
function learningPage(){
 const sid=microSkillId,n=CURRICULUM.lessons[sid],s=SKILL_DATA.skills.find(s=>s.id===sid),p=practiceFor(sid),labels={definition:'是什么',why:'为什么',use:'何时能用'};
 if(!n||!s||!p)return '<div class="panel">知识说明暂不可用。</div>';
 const sources=(n.sourceReferences||[]).map(r=>`<li><b>${esc(r.book)}</b> · ${r.pdfPages.length?'PDF页 '+r.pdfPages.join('、'):'未定位直接页'} · ${esc(r.coverage)}<p class="tiny-note">${esc(r.limitations)}</p></li>`).join('');
 const prerequisites=n.prerequisiteIds.map(id=>`<button class="secondary" data-action="learn" data-code="${id}">${esc(SKILL_DATA.skills.find(s=>s.id===id)?.title||id)}</button>`).join('');
 return `<div class="page-head"><div><p class="kicker">${sid} · 学</p><h1>${esc(s.title)}</h1></div><button class="back" data-action="network" data-code="${sid}">← 相关知识</button></div><div class="work learning-work"><article class="panel"><div class="learning-tabs" role="group" aria-label="知识说明">${Object.entries(labels).map(([key,label])=>`<button class="secondary" data-action="learnTab" data-value="${key}" aria-pressed="${learnTab===key}">${label}</button>`).join('')}</div><h2>${labels[learnTab]}</h2><p class="learning-copy">${esc(n[learnTab])}</p><button class="secondary" data-action="learnSpeak" data-value="${learnTab}">🔊 听这段</button><div class="learning-counter"><button class="secondary" data-action="learnCounter" aria-expanded="${learnCounterOpen}">想一想容易混淆的地方</button>${learnCounterOpen?`<p>${esc(n.counterexample)}</p><button class="secondary" data-action="learnSpeak" data-value="counterexample">🔊 听反例</button>`:''}</div><div class="learning-actions"><button class="primary" data-action="demo" data-code="${sid}">看另一道例子的示范 →</button><button class="secondary" data-action="${p.view}" data-code="${sid}">轮到我动手操作 →</button></div><section class="reason-block"><h3>试着讲清楚</h3><p>${esc(p.task.reason?.prompt||'用操作中的对象说明为什么成立。')}</p><button class="secondary" data-action="learnExplainSpeak">🔊 听解释问题</button></section><div id="speech-status" role="status">${esc(speechMessage)}</div></article><aside class="side-stack">${prerequisites?`<section class="panel"><h3>可以先联系这些知识</h3><div class="stage-buttons">${prerequisites}</div></section>`:''}<details class="panel"><summary>家长查看来源与证据</summary><ul>${sources}</ul><p class="tiny-note">概念说明为原创儿童改写；来源定位不等于原图全部核验。操作题核对对象、变化和所选理由；口述仍需家长实际听取。阅读或播放示范不记作孩子答题。</p></details><section class="panel"><h3>接着试一试</h3><button class="secondary" data-action="stage" data-code="${sid}|transfer">换情境或表示 →</button><button class="secondary" data-action="micro" data-code="${sid}">单项对象辨识 →</button></section></aside></div>`;
}
