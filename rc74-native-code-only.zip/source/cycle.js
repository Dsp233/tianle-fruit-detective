'use strict';
const CYCLE_TASKS={
 'N04.01':{mode:'groupingLab',kind:'remainder',total:17,divisor:5,context:'五颗一袋的糖',prompt:'17颗糖每5颗装一袋。点选实际糖果装尽完整袋，试下一袋，再选择余数。',explain:'3袋共15颗，余2；不能把最后两颗当完整袋。',reason:{prompt:'这里完整一袋与余数怎样区分？',options:['完整袋各5颗，最后不足5颗留作余数','最后一袋可以少装','只看完整袋的袋数就是余数'],answer:0}},
 'N04.02':{mode:'patternLab',kind:'period',base:['红','蓝','蓝'],context:'三格彩带',prompt:'彩带红蓝蓝反复排列。圈出最短的一组，并实际重复这组验证整串。',explain:'最短节是红蓝蓝三格，两格不能生成整串。',reason:{prompt:'为什么周期是3？',options:['三格能生成全串，1或2格不能','因为有两种颜色所以一定是2','只看首尾是否同色'],answer:0}},
 'N04.03':{mode:'cycleLab',kind:'position',base:['红','蓝','蓝'],target:7,context:'第7格彩灯',prompt:'红蓝蓝按三格一轮循环。环上从“还没数第1格”开始，实际走整轮和余步，定位第7格，再选它的周期位置。',explain:'7＝2×3＋1，第7格是新轮的第1位，红色。',reason:{prompt:'第7格怎样定位？',options:['先走两整轮，再数下一轮第1位','余1就从第1位再走1到第2位','第7格等于从第1格再走7步'],answer:0}},
 'N04.04':{mode:'cycleLab',kind:'weekday',base:['星期一','星期二','星期三','星期四','星期五','星期六','星期日'],start:0,target:10,context:'过10天',prompt:'今天星期一。0天就在星期一，每走一步才过1天。实际走整周和余天，选择过10天的星期。',explain:'过7天回到星期一，再过3天是星期四。',reason:{prompt:'过10天与数第10项有什么不同？',options:['今天是0天，第一步才过1天','今天要算已经过1天','完整一周要移动8天'],answer:0}},
 'N04.05':{mode:'cycleLab',kind:'power',factor:2,period:4,target:5,context:'生成2的乘方末位',prompt:'从1起每次乘2，实际去掉十棒只保留个位，直到首个末位再次出现。圈周期并带入环，再定位2⁵的末位。',explain:'末位2、4、8、6、2，最短周期4；第5项回到周期第1位，末位2。',reason:{prompt:'为什么2⁵的末位回到2？',options:['末位周期4，第5项是下一轮第1位','指数5就是末位5','看到两种个位就说明周期2'],answer:0}},
 'N04.06':{mode:'cycleLab',kind:'position',base:['1号','2号','3号','4号','5号'],target:15,context:'整轮的最后位置',prompt:'每5个座位为一轮。从还没数第1位开始，实际数到第15位，再选择周期位置；余数0也要有真实座位。',explain:'15恰好3整轮，停在第三轮第5位；余数0表示轮末位，不存在第0号。',reason:{prompt:'序号除周期余0时选哪里？',options:['当前整轮的最后一位','不存在的第0位','下一轮第1位'],answer:0}}
};
for(const [skillId,t] of Object.entries(CYCLE_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:37,phase:'练',hint:'先区分计数第1项之前与今天0天；走整轮后，实际核对剩余位置。'});
if(typeof module!=='undefined')module.exports={CYCLE_TASKS};
