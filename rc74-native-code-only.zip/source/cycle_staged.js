'use strict';
const CYCLE_CASES={
 'N04.01':[
  [{mode:'groupingLab',kind:'remainder',total:21,divisor:4,context:'四枚徽章一盒'},'21枚每4枚装一盒。实际装尽完整盒、试下一盒，再选余数。','5盒余1。','糖果换徽章且组量由5改4'],
  [{mode:'groupingLab',kind:'remainder',total:20,divisor:5,context:'正好四袋'},'独立把20颗每5颗装袋，实际试末袋并选择余数。','余0。','无提示：整除的0余数'],
  [{mode:'groupingLab',kind:'remainder',total:23,divisor:6,context:'六颗一袋'},'隔日23颗每6颗装袋，装尽完整袋并选余数。','3袋余5，余数小于6。','隔日：余数接近组量'],
  [{mode:'groupingLab',kind:'remainder',total:14,divisor:4,context:'小盒彩笔'},'独立把14枚每4枚装盒，再选择最后余数。','3盒余2。','备用：较小总量']
 ],
 'N04.02':[
  [{mode:'patternLab',kind:'period',base:['A','B','B','C'],context:'四项字母周期'},'字母A、B、B、C反复。圈最短的一组，并复制检验整串。','最短周期4，不由不同字母个数3决定。','三格双色换四格三字母，周期不是种类数'],
  [{mode:'patternLab',kind:'period',base:['苹果','梨','梨'],context:'水果边框'},'独立找苹果、梨、梨反复的最短周期，复制验证。','周期3。','无提示：有相邻相同项'],
  [{mode:'patternLab',kind:'period',base:['A','B','C'],context:'隔日字母灯'},'隔日找A、B、C反复的最短周期并复制验证。','周期3。','隔日：三项各不同'],
  [{mode:'patternLab',kind:'period',base:['绿','绿','黄','黄'],context:'成双条纹'},'独立找绿绿黄黄反复的最短周期，并复制验证。','周期4；两格绿绿不能生成整串。','备用：成双相同色']
 ],
 'N04.03':[
  [{mode:'cycleLab',kind:'position',base:['△','□','□','○'],target:10,context:'四形状环'},'三角、方、方、圆为一轮。实际数到第10项并选周期位置。','两整轮余2，第2位方形。','换周期长度与形状表示'],
  [{mode:'cycleLab',kind:'position',base:['苹果','梨','梨'],target:8,context:'水果第8项'},'独立从第1项前开始，实际定位苹果梨梨循环的第8项。','第2位梨。','无提示：同色相邻但要区分位置'],
  [{mode:'cycleLab',kind:'position',base:['A','B','C'],target:11,context:'字母第11项'},'隔日数A、B、C循环的第11项，选周期位置。','三整轮余2，第2位B。','隔日：11项'],
  [{mode:'cycleLab',kind:'position',base:['绿','黄','黄'],target:9,context:'正好三轮'},'独立定位绿黄黄循环的第9项。','整3轮，末位第3位黄。','备用：余数0的序号边界']
 ],
 'N04.04':[
  [{mode:'cycleLab',kind:'weekday',base:['星期一','星期二','星期三','星期四','星期五','星期六','星期日'],start:4,target:9,context:'星期五出发'},'今天星期五为0天。实际过9天，再选星期几。','过7天仍星期五，再过2天星期日。','改变起始星期，今天仍作0天'],
  [{mode:'cycleLab',kind:'weekday',base:['星期一','星期二','星期三','星期四','星期五','星期六','星期日'],start:6,target:8,context:'星期日之后'},'独立从今天星期日开始，实际过8天。','星期一。','无提示：起点为周期末日'],
  [{mode:'cycleLab',kind:'weekday',base:['星期一','星期二','星期三','星期四','星期五','星期六','星期日'],start:1,target:14,context:'两整周之后'},'隔日从今天星期二开始，实际过14天并选星期。','星期二；完整两周回到出发日。','隔日：经过天数余0回到起点'],
  [{mode:'cycleLab',kind:'weekday',base:['星期一','星期二','星期三','星期四','星期五','星期六','星期日'],start:2,target:5,context:'星期三过5天'},'独立从星期三0天开始，实际过5天。','星期一。','备用：不足一整周跨边界']
 ],
 'N04.05':[
  [{mode:'cycleLab',kind:'power',factor:4,period:2,target:7,context:'4的乘方末位'},'从1连续乘4，每次实际只保留个位，生成到首个末位重现。圈周期并用环定位4⁷末位。','4、6、4；周期2，第7项末位4。','底数2改4，周期长度4改2'],
  [{mode:'cycleLab',kind:'power',factor:3,period:4,target:6,context:'3的乘方末位'},'独立生成3的乘方末位循环，圈周期并定位3⁶。','3、9、7、1循环；第6项末位9。','无提示：末位序列不同'],
  [{mode:'cycleLab',kind:'power',factor:2,period:4,target:8,context:'指数整周期'},'隔日生成2的末位周期并实际定位2⁸。','整两轮，第4位末位6。','隔日：指数余0应取周期末位'],
  [{mode:'cycleLab',kind:'power',factor:5,period:1,target:9,context:'只有一项的周期'},'独立生成5的乘方末位到首项重现，圈周期并定位5⁹。','5、5，周期1，末位5。','备用：一项周期边界']
 ],
 'N04.06':[
  [{mode:'cycleLab',kind:'position',base:['1号','2号','3号','4号'],target:12,context:'四座一轮'},'每4座一轮，从还没数第1座开始实际数到第12座，再选周期位置。','第三轮第4位，余0不是第0位。','每轮5改4，整轮仍停末位'],
  [{mode:'cycleLab',kind:'position',base:['1号','2号','3号'],target:9,context:'三座一轮'},'独立定位每3座一轮的第9座。','第3位。','无提示：周期3'],
  [{mode:'cycleLab',kind:'position',base:['1号','2号','3号','4号','5号','6号'],target:12,context:'六座一轮'},'隔日每6座一轮，实际定位第12座。','第二轮第6位。','隔日：周期6，两整轮'],
  [{mode:'cycleLab',kind:'position',base:['1号','2号','3号','4号','5号'],target:10,context:'第五位边界'},'独立定位每5座一轮的第10座。','第二轮第5位。','备用：同周期不同整轮数']
 ]
};
const cycleStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(CYCLE_CASES)){
 if(cases.length!==4)throw Error('Four N04 cases required: '+skillId);cycleStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];cycleStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:38,phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'分清周期、计数起点和第几项；先生成或走出实际模型。'}:{})};
 }
}
Object.assign(cycleStageTarget['N04.02'].independent,{base:["A", "B", "A", "C", "B"],contentVersion:70,prompt:'圈出这串图案的最短重复块，再用它生成整串；字母表示不同的图形。',explain:'必须保留重复块内部的排列关系；换字母不产生新数学实例。'});
if(typeof module!=='undefined')module.exports={CYCLE_CASES};
