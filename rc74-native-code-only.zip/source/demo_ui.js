'use strict';
let demoSkillId='',demoCursor=0,demoTimer=null,demoSequence=0;
function demoStop(){demoSequence++;if(demoTimer!==null)clearTimeout(demoTimer);demoTimer=null}
function demoGroups(task){
 const groups=[];for(const step of task.demoSteps||[]){const scope=[step.action,step.data.side||'',step.data.index&&/Place|Move|Amount/.test(step.action)?step.data.index:'',step.data.key||''].join('|'),last=groups.at(-1);if(last&&last.scope===scope&&last.actions.length<6)last.actions.push(step);else groups.push({scope,actions:[step]})}return groups;
}
function demoReason(task,group,index,total){
 if(index===total-1)return task.explain;
 const action=group.actions[0].action;
 if(/Undo|Return|Unplace|Uncopy/.test(action))return '撤销时放回同一批原对象，数量和身份都可以核对。';
 if(/Bundle|Unbundle/.test(action))return '十棒里的每个一都还在，捆和拆只改变表示。';
 if(/Phase/.test(action))return '接下来换一个基准；原整体与剩余整体要分清。';
 if(/Copy|Both|Axis/.test(action))return '复制或缩放完整的一组，核对所有对应的量。';
 if(/Choice|Verdict|Proof/.test(action))return '把所选的关系与刚才的实际变化相互核对。';
 if(/Place|Move|Take|Fill|Cell|Add/.test(action))return '看清这一批原对象去了哪里，每次只按合法动作改变。';
 return '观察当前对象和前一步之间的变化，再核对题目条件。';
}
function demoAdvance(){
 const task=DEMO_TASKS[demoSkillId],groups=demoGroups(task),group=groups[demoCursor];if(!group)return false;
 for(const step of group.actions)if(!taskAdapter(task).act(step.action,step.data,task)){demoStop();feedback={ok:false,text:'这个示范动作未能恢复，请回放或返回练习。'};render();return false}
 demoCursor++;render();return true;
}
function demoPlay(){demoStop();const sequence=demoSequence;const tick=()=>{if(sequence!==demoSequence||view!=='demo')return;if(demoAdvance())demoTimer=setTimeout(tick,1100);else{demoTimer=null;render()}};demoTimer=setTimeout(tick,100);render()}
function demoReset(){demoStop();demoCursor=0;draft=freshDraft();feedback=null;render()}
function demoPage(){
 const task=DEMO_TASKS[demoSkillId];if(!task)return `<div class='panel'>示范还在补齐。<button data-action='micro' data-code='${esc(demoSkillId)}'>回练习</button></div>`;
 const groups=demoGroups(task),complete=demoCursor===groups.length,explanation=demoCursor?demoReason(task,groups[demoCursor-1],demoCursor-1,groups.length):'这是另一道例子。一起观察对象怎么改变。';
 const board=taskBoard(task).replace(/<button(?![^>]*data-action=['"](?:workSpeakChoice|speakSurface|speakControl))/g,'<button disabled');
 const practice=practiceFor(task.skillId);
 return `<div class='page-head'><div><p class='kicker'>学 · 另一道例子</p><h1>${esc(SKILL_DATA.skills.find(s=>s.id===task.skillId)?.title||'看示范')}</h1></div><button class='back' data-action='micro' data-code='${esc(task.skillId)}'>← 返回</button></div><div class='work'><article class='panel'><h2 class='task-title'>${esc(task.prompt)}</h2><div class='demo-controls'><button class='primary' data-action='demoNext' ${complete?'disabled':''}>下一步 →</button><button class='secondary' data-action='${demoTimer===null?'demoPlay':'demoPause'}' ${complete?'disabled':''}>${demoTimer===null?'▶ 连续看':'⏸ 暂停'}</button><button class='secondary' data-action='demoReset'>↩ 回放</button><span>第${demoCursor}/${groups.length}步</span></div>${board}<div class='hint' role='status'>${esc(explanation)}</div><div class='bottom-actions'><button class='secondary' data-action='speak'>🔊 听例题</button><button class='secondary' data-action='demoSpeak'>🔊 听这一步</button><button class='secondary' data-action='speakState'>🔊 听当前状态</button>${complete&&practice?`<button class='primary' data-action='${practice.view}' data-code='${esc(task.skillId)}'>轮到我动手 →</button>`:''}</div><div id='speech-status' role='status'>${esc(speechMessage)}</div></article><aside class='side-stack'><details class='panel'><summary>家长说明</summary><p>这里重放不同实例的真实合法动作；示范不计孩子作答，也不会增加独立成功。可以暂停、单步或回放。</p></details></aside></div>`;
}
