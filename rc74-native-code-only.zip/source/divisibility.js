'use strict';
// Finite reviewed cases. Reduced dots represent equal remainders, not the
// original quantity: 21 and 3 are different quantities with the same remainder.
const DIGIT_RULE_MODELS={
 practice:[[20,2],[25,2],[25,5],[26,5],[21,3],[22,3]],
 transfer:[[102,2],[105,5],[104,3]],
 independent:[[38,2],[40,5],[32,3]],
 independent2:[[45,2],[35,5],[33,3]],
 delayed:[[31,2],[30,5],[25,3]],
 independent3:[[46,2],[47,5],[45,3]],
 independent4:[[50,2],[55,5],[41,3]],
 delayed7:[[61,2],[65,5],[64,3]],
 delayed21:[[74,2],[75,5],[73,3]],
 demo:[[12,2],[15,5],[16,3]]
};
function digitRuleInstance(rows,id,phase,dimension='2/3/5判别的不同数卡'){
 const cases=rows.map(([number,divisor],i)=>({id:'DR'+i,number,divisor}));
 return {id,skillId:'N01.03',contentVersion:80,mode:'groupingLab',kind:'digitRules',phase,cases,quantitySemantic:'remainder-equivalent-representation',authorship:'原创儿童操作适配',context:'十棒与2、3、5整除',changeDimension:dimension,prompt:`检验${rows.map(([n,d])=>n+'÷'+d).join('、')}。${['测','巩固'].includes(phase)?'先保存各题余数预测，再用教具核验。':'把十棒按对应组量圈组，再选择数位贡献并实际分组，判断是否有余。'}`,explain:'每个十除以2或5都无余，所以检验个位；每个十除以3余1，各位数字之和保留除3的余数。保留的是余数关系，原数并没有变成数位和。',...(['练','学'].includes(phase)?{hint:'十棒有10个一。按题目指定的组量装完整组，剩下不足一组才停止；0也要明确选择。',reason:{prompt:'为什么2、5看个位，而3看数位和？',options:['十的倍数除2或5无余；每个十除3余1，所以保留各位数字的贡献','2、3、5都只看个位','数位和就是原来的总数量'],answer:0}}:{})};
}
if(typeof module!=='undefined')module.exports={DIGIT_RULE_MODELS,digitRuleInstance};
