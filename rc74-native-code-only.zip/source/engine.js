'use strict';
const VECTORS={R:[1,0,0],O:[0,1,0],Y:[0,0,1],A:[1,1,0],B:[0,1,1]};
function parts(counts){
 const {a,b,o}=counts;
 if(![a,b,o].every(x=>Number.isInteger(x)&&x>=0)||o>a||o>b)throw Error('组人数不一致');
 return {R:a-o,O:o,Y:b-o,A:a,B:b,total:a+b-o};
}
function checkExpression(tokens,counts,terms={min:2,max:5}){
 const n=parts(counts), min=terms.min??terms.terms??2, max=terms.max??terms.terms??5;
 if(tokens.length<2*min-1||tokens.length>2*max-1||tokens.length%2!==1)return {ok:false,reason:'按“人数卡 → 运算符 → 人数卡”组装。'};
 const coeff=[0,0,0]; let value=0;
 for(let i=0;i<tokens.length;i++){
  if(i%2){if(!['+','-'].includes(tokens[i]))return {ok:false,reason:'两个数字之间需放运算符。'};continue}
  const id=tokens[i];if(!VECTORS[id])return {ok:false,reason:'这张卡不能用于本题。'};
  const sign=i===0||tokens[i-1]==='+'?1:-1;
  value+=sign*n[id];VECTORS[id].forEach((v,k)=>coeff[k]+=sign*v);
 }
 const semantic=coeff.every(x=>x===1);
 return {ok:semantic&&value===n.total,semantic,value,coeff,expected:n.total,
  reason:semantic?'核对算式与图中人数。':value===n.total?'结果碰巧相同；再看红、橙、黄每一块是否恰好算一次。':'再看红、橙、黄三块各被算了几次。'};
}
function sameSet(selected,expected){return selected.length===expected.length&&selected.every(x=>expected.includes(x))}
if(typeof module!=='undefined')module.exports={VECTORS,parts,checkExpression,sameSet};
