'use strict';
const EQUATION_TASKS={
 'L01.01':{kind:'equal',left:[4,3],right:[3,4],context:'两边的点盘',prompt:'左边按4和3两组，右边按3和4两组。逐组放上天平，比较两边完整总量。',explain:'左边4＋3＝7，右边3＋4＝7；等号表示两个总量相等。',reason:{prompt:'为什么这道等式成立？',options:['左右总量都为7','只有左边必须先算出结果','每边第一组要相同'],answer:0}},
 'L01.02':{kind:'unknown',known:3,total:7,context:'未知袋与砝码',prompt:'未知袋加3颗与右边7颗等重。两边各拿走3颗，再逐颗放进袋子，找到袋里的数量。',explain:'两边同拿3，右边余4，所以袋子里4颗。',reason:{prompt:'怎样确定未知袋的数量？',options:['两边各拿走3，右边余4','只从右边拿3颗','把右边7颗都放进袋子'],answer:0}},
 'L01.03':{kind:'bilateral',known:3,total:7,context:'逐颗平衡天平',prompt:'左边未知袋加3颗、右边7颗。每次分别从左、右拿走1颗，直到两边各拿走3颗；再填出袋里的数。',explain:'左右各拿3，剩未知袋＝4；只在单边拿走会暂时不平衡。',reason:{prompt:'每一步如何保持等量？',options:['左右拿走相同数量','只从有7颗的一边拿走','左边拿3，右边拿2也相等'],answer:0}},
 'L01.04':{kind:'inverse',initial:9,remain:5,context:'盒子里的玻璃珠',prompt:'原来9颗，拿走一个未知数量后还剩5颗。逐颗移到“拿走”区，数出未知数量。',explain:'9－4＝5；已拿走4颗，也可用9－5找回未知数。',reason:{prompt:'为什么未知数是4？',options:['原有9减去剩余5得到拿走4','把9和5相加','剩余5就是拿走的数'],answer:0}},
 'L01.05':{kind:'substitute',bag:4,known:3,total:7,context:'代回原天平',prompt:'已知袋里4颗。把4颗逐颗放入袋内，再摆出袋外3颗，检查左盘是否与右盘7颗一样多。',explain:'将4代回□＋3＝7，左边4＋3＝7，与右边相等。',reason:{prompt:'代回原式检验什么？',options:['替换未知袋后左右总量相等','只看袋内4颗是否等于右边7颗','把两边数全加在一起'],answer:0}}
};
for(const [skillId,t] of Object.entries(EQUATION_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:23,mode:'equationLab',phase:'练',methodSpecific:['unknown','bilateral'].includes(t.kind),hint:'先看等号两边的完整数量，再按题意同时拿走、逆向找回或代回。'});
if(typeof module!=='undefined')module.exports={EQUATION_TASKS};
