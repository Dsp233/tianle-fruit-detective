'use strict';
const EQUATION_CASES={
 'L01.01':[
  [{kind:'equal',left:[5,2],right:[4,3],context:'水果盘'},'左盘按5和2两组放果子，右盘按4和3两组放；比较完整总量。','5＋2＝4＋3＝7，两侧总量相等。','换成两种不同拆分，左右第一组不相同'],
  [{kind:'equal',left:[2,4],right:[3,3],context:'积木盘'},'左边两组2和4，右边两组3和3。独立摆上两盘，看能否用等号连接。','2＋4和3＋3都为6。','无提示：含两组相同数'],
  [{kind:'equal',left:[6,1],right:[2,5],context:'游戏筹码'},'左边分成6和1，右边分成2和5；隔日重新摆盘核对。','两边各7枚，等号比较总量。','隔日：大小顺序和分组都变'],
  [{kind:'equal',left:[3,5],right:[4,4],context:'餐桌勺子'},'一侧两组3和5，另一侧两组4和4，独立摆放并核对。','两侧各8把。','备用：相等的两组放在右侧']
 ],
 'L01.02':[
  [{kind:'unknown',known:2,total:8,context:'神秘袋与棋子'},'袋子加2枚棋子与8枚等重。两边各拿走2，再逐个装出袋内数。','右侧余6，袋内是6枚。','已知量2，总量8，换棋子情境'],
  [{kind:'unknown',known:4,total:9,context:'未知盒与纽扣'},'一个未知盒加4颗纽扣等于9颗。先两边同取4，再摆出盒内颗数。','9－4＝5，盒内5颗。','无提示：已知量改4'],
  [{kind:'unknown',known:5,total:12,context:'未知罐与豆子'},'罐子加5颗豆子和12颗等重。隔日两边同取，再确定罐内数。','12－5＝7，罐内7颗。','隔日：总量超过十'],
  [{kind:'unknown',known:1,total:6,context:'密封袋与石子'},'袋子外有1颗，右盘6颗。两边同取后数袋内颗数。','6－1＝5，袋内5颗。','备用：已知量只一颗']
 ],
 'L01.03':[
  [{kind:'bilateral',known:2,total:8,context:'两边逐颗撤棋'},'左边未知盒加2枚、右边8枚。逐次从左右各撤2枚，再摆盒内数。','左右各撤2，未知盒＝6。','将一次同取改成左右逐次对应操作'],
  [{kind:'bilateral',known:4,total:9,context:'积木天平'},'左盘未知袋加4块，右盘9块。独立逐颗从两边各拿走4块，再摆出袋内数。','右边剩5块，未知袋5块。','无提示：需要四次对应动作'],
  [{kind:'bilateral',known:1,total:7,context:'水果天平'},'左盘未知篮加1个、右盘7个。隔日分别从左右拿走1个并摆篮内数。','两边各拿1，篮内6个。','隔日：只需一组对应动作'],
  [{kind:'bilateral',known:3,total:10,context:'砝码天平'},'左侧袋子外有3颗，右侧10颗；各边逐颗撤3，再摆袋内数。','右边剩7，袋内7。','备用：右侧总数十']
 ],
 'L01.04':[
  [{kind:'inverse',initial:8,remain:3,context:'铅笔盒'},'原来8支，拿走未知数后剩3支。逐支移到拿走区，找回未知数。','拿走5支，因为8－5＝3。','原数与余数均改变，换铅笔'],
  [{kind:'inverse',initial:12,remain:7,context:'贴纸簿'},'原来12张贴纸，拿走后剩7张；独立逐张移走。','拿走5张，12－7＝5。','无提示：跨过十'],
  [{kind:'inverse',initial:10,remain:4,context:'气球'},'原来10个气球，送出一些还剩4个。隔日逐个移到送出区。','送出6个，10－4＝6。','隔日：原数是十'],
  [{kind:'inverse',initial:7,remain:2,context:'卡片盒'},'7张卡片取走若干，盒内余2张。逐张移出求取走数。','取走5张，7－2＝5。','备用：小总量']
 ],
 'L01.05':[
  [{kind:'substitute',bag:5,known:2,total:7,context:'代回积木天平'},'已经求出袋内5块。逐块放进袋，再摆外面2块，核对右侧7块。','5＋2＝7，左右相等。','袋中5、袋外2，换积木'],
  [{kind:'substitute',bag:6,known:3,total:9,context:'棋子天平'},'未知盒是6枚。独立摆盒内6枚和盒外3枚，检验与右边9枚等重。','6＋3＝9，原式成立。','无提示：新未知量6'],
  [{kind:'substitute',bag:4,known:5,total:9,context:'纽扣盘'},'已求得袋内4颗，袋外5颗。隔日逐颗代回，比较右侧9颗。','4＋5＝9，代回两边相等。','隔日：袋外数量大于袋内'],
  [{kind:'substitute',bag:7,known:1,total:8,context:'彩珠盘'},'袋中7颗，外面1颗。独立摆两部分并核对右边8颗。','7＋1＝8，代回检验通过。','备用：袋外只有一颗']
 ]
};
const equationStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(EQUATION_CASES)){
 if(cases.length!==4)throw Error('Four L01 cases required: '+skillId);equationStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];equationStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:67,mode:'equationLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt:params.kind==='unknown'&&kind!=='transfer'?`一个未知盒加${params.known}个物件等于${params.total}个。自己找出盒内数量，再用天平检查。`:prompt,explain,changeDimension,methodSpecific:params.kind==='bilateral'||kind==='transfer'&&params.kind==='unknown',...(kind==='transfer'?{hint:'先看两边整体，动手找等量和未知部分。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={EQUATION_CASES};
