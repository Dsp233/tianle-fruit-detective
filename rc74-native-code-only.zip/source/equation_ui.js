'use strict';
function equationState(){const w=draft.work??(draft.work={left:[],right:[],taken:false,leftTaken:0,rightTaken:0,bag:0,removed:0,knownPlaced:0,moves:0,log:[]});w.leftAdded??=0;w.rightAdded??=0;w.returned??=0;w.wholeAnswer??=0;w.wholeSet??=false;w.choice??='';return w}
function equationDots(n,label,prefix='',offset=0){return `<span class="equation-dots" role="img" aria-label="${esc(label)}${n}颗">${Array.from({length:n},(_,i)=>`<i ${prefix?`data-object-id="${prefix}${i+offset}"`:''} aria-hidden="true"></i>`).join('')}</span>`}
function equationVerdict(task){return choiceButtons(task,[['equal','两边相等'],['unequal','两边不相等']],'equationVerdict')}
function equationCandidateVerdict(task){return choiceButtons(task,[['accept','满足原式'],['reject','不满足原式']],'equationVerdict')}
function equationBoard(task){const w=equationState(),undo=`<button data-action="equationUndo" ${w.log.length?'':'disabled'}>↩ 撤回一步</button>`;
 if(task.kind==='equal'){
  const left=w.left.reduce((sum,i)=>sum+task.left[i],0),right=w.right.reduce((sum,i)=>sum+task.right[i],0);
  return `<div class="board equation-board"><h3>${esc(task.context)} · 比较完整两盘</h3><div class="equation-pans">${[['left','左盘'],['right','右盘']].map(([side,name])=>`<section><b>${name} · 已摆 ${side==='left'?left:right}</b><div class="equation-groups">${task[side].map((n,i)=>`<button data-action="equationTerm" data-side="${side}" data-index="${i}" aria-pressed="${w[side].includes(i)}">${w[side].includes(i)?equationDots(n,`${name}第${i+1}组`,side+i+'-'):`放第${i+1}组 ${n}颗`}</button>`).join('')}</div></section>`).join('<strong class="equation-equals">?</strong>')}</div>${task.equalAnswer===false?equationVerdict(task):''}<div class="work-buttons">${undo}</div></div>`;
 }
 if(task.kind==='inverse'&&task.unknownInitial){
  return `<div class="board equation-board"><h3>${esc(task.context)} · □－${task.removedGiven}＝${task.remain}</h3><div class="equation-pans"><section><b>放回整体</b>${equationDots(task.remain,'原本剩余','R')}${equationDots(w.returned,'放回的原对象','N')}</section><strong class="equation-equals">←</strong><section><b>先前拿走的原对象</b>${Array.from({length:task.removedGiven-w.returned},(_,i)=>`<i class="equation-return-dot" data-object-id="N${w.returned+i}"></i>`).join('')}</section></div><div class="work-buttons"><button data-action="equationReturn" ${w.returned>=task.removedGiven?'disabled':''}>放回1颗原点</button>${undo}</div><p>我的原数量：${w.wholeAnswer}</p><div class="work-buttons">${[-1,0,1,5].map(d=>`<button data-action="equationWhole" data-delta="${d}">${d===0?'填0':d>0?'＋'+d:d}</button>`).join('')}</div></div>`;
 }
 if(task.kind==='inverse')return `<div class="board equation-board"><h3>${esc(task.context)} · ${task.initial}－□＝${task.remain}</h3><div class="equation-pans"><section><b>盒中 ${task.initial-w.removed} 颗</b>${Array.from({length:task.initial-w.removed},(_,i)=>`<i class="equation-return-dot" data-object-id="I${w.removed+i}"></i>`).join('')}</section><strong class="equation-equals">→</strong><section><b>已拿走 ${w.removed} 颗</b>${equationDots(w.removed,'已拿走','I')}</section></div><div class="work-buttons"><button data-action="equationRemove" ${w.removed>=task.initial?'disabled':''}>拿走1颗</button>${undo}</div></div>`;
 if(task.kind==='substitute')return `<div class="board equation-board"><h3>${esc(task.context)} · □＋${task.known}＝${task.total}</h3><div class="equation-pans"><section><b>候选未知袋 ${task.bag} 颗</b>${equationDots(w.bag,'袋内','X')}<p>袋外 ${w.knownPlaced} 颗</p>${equationDots(w.knownPlaced,'袋外','K')}</section><strong class="equation-equals">?</strong><section><b>右盘 ${task.total}颗</b>${equationDots(task.total,'右盘','T')}</section></div><div class="work-buttons"><button data-action="equationBag" ${w.bag>=task.total?'disabled':''}>候选袋中放1颗</button><button data-action="equationKnown" ${w.knownPlaced>=task.known?'disabled':''}>袋外放1颗</button>${undo}</div>${task.correctVerdict?equationCandidateVerdict(task):''}</div>`;
 const leftRemoved=task.kind==='unknown'&&w.taken?task.known:w.leftTaken,rightRemoved=task.kind==='unknown'&&w.taken?task.known:w.rightTaken,lt=task.known-leftRemoved+w.leftAdded,rt=task.total-rightRemoved+w.rightAdded;
 const unknown=`<section><b>未知盘：袋＋${lt}颗</b><div class="equation-bag">袋内已摆 ${w.bag}颗 ${equationDots(w.bag,'袋中','X')}</div>${equationDots(Math.max(0,task.known-leftRemoved),'原袋外','K',leftRemoved)}${equationDots(w.leftAdded,'添入未知盘','AL')}</section>`;
 const known=`<section><b>已知盘：${rt}颗</b>${equationDots(Math.max(0,task.total-rightRemoved),'原已知盘','T',rightRemoved)}${equationDots(w.rightAdded,'添入已知盘','AR')}</section>`;
 const pans=(task.unknownSide==='right'?[known,unknown]:[unknown,known]).join(`<strong class="equation-equals" aria-label="按已摆出的数量比较">${w.bag+lt===rt?'＝':'≠'}</strong>`);
 const removedTray=leftRemoved||rightRemoved?`<div class="equation-pans"><section><b>未知盘移出的原对象</b>${equationDots(leftRemoved,'未知盘移出','K')}</section><section><b>已知盘移出的原对象</b>${equationDots(rightRemoved,'已知盘移出','T')}</section></div>`:'';
 const addition=task.addBoth!==undefined;
 const controls=task.kind==='bilateral'?addition?`<button data-action="equationLeftAdd" ${w.leftAdded>=task.addBoth?'disabled':''}>未知盘添1颗</button><button data-action="equationRightAdd" ${w.rightAdded>=task.addBoth?'disabled':''}>已知盘添1颗</button>`:`<button data-action="equationLeftTake" ${w.leftTaken>=task.known?'disabled':''}>左边拿1颗</button><button data-action="equationRightTake" ${w.rightTaken>=task.known?'disabled':''}>右边拿1颗</button>`:`<button data-action="equationTake" ${w.taken?'disabled':''}>两边各拿走${task.known}颗</button>`;
 return `<div class="board equation-board"><h3>${esc(task.context)} · ${task.unknownSide==='right'?`${task.total}＝□＋${task.known}`:`□＋${task.known}＝${task.total}`}</h3><div class="equation-pans">${pans}</div>${removedTray}<p>${addition?'两盘同加相同数量，原来的未知袋不变。':task.kind==='bilateral'?`左边已拿${w.leftTaken}，右边已拿${w.rightTaken}。`:w.taken?'已按两边同取移出原对象。':'自己摆袋内数量，也可两边同取。'}</p><div class="work-buttons">${controls}<button data-action="equationBag" ${w.bag>=task.total?'disabled':''}>袋中放1颗</button>${undo}</div></div>`;
}
function equationGrade(task){const w=equationState();let ok=false,incomplete=w.moves===0;
 if(task.kind==='equal'){
  const equal=task.left.reduce((a,n)=>a+n,0)===task.right.reduce((a,n)=>a+n,0);
  ok=w.left.length===task.left.length&&w.right.length===task.right.length&&(task.equalAnswer===false?!equal&&w.choice==='unequal':equal);
  if(task.equalAnswer===false)incomplete=incomplete||!w.choice;
 }
 if(task.kind==='unknown')ok=w.bag+task.known===task.total&&(!task.methodSpecific||w.taken);
 if(task.kind==='bilateral')ok=task.addBoth!==undefined?w.leftAdded===task.addBoth&&w.rightAdded===task.addBoth&&w.leftTaken===0&&w.rightTaken===0&&w.bag===task.total-task.known&&w.bag+task.known+w.leftAdded===task.total+w.rightAdded:w.leftTaken===task.known&&w.rightTaken===task.known&&w.bag===task.total-task.known;
 if(task.kind==='inverse')ok=task.unknownInitial?w.returned===task.removedGiven&&w.wholeSet&&w.wholeAnswer===task.remain+task.removedGiven:w.removed===task.initial-task.remain;
 if(task.kind==='substitute'){
  const fits=w.bag+w.knownPlaced===task.total;
  ok=w.bag===task.bag&&w.knownPlaced===task.known&&(task.correctVerdict?w.choice===(fits?'accept':'reject'):fits);
  if(task.correctVerdict)incomplete=incomplete||!w.choice;
 }
 return {ok,incomplete,reason:'核对完整原式；相等必须比较两盘总量，同加同减不能只改一边，候选数也可能不满足。'};
}
function equationAct(action,data,task){const w=equationState();let key=null,value=null;
 if(action==='equationTerm'&&task.kind==='equal'&&['left','right'].includes(data.side)){const i=Number(data.index);if(Number.isInteger(i)&&i>=0&&i<task[data.side].length){key=data.side;value=i;const at=w[key].indexOf(i);if(at<0)w[key].push(i);else w[key].splice(at,1)}}
 if(action==='equationTake'&&task.kind==='unknown'&&!w.taken){key='taken';value=w.taken;w.taken=true}
 for(const [name,k] of [['equationLeftTake','leftTaken'],['equationRightTake','rightTaken']])if(action===name&&task.kind==='bilateral'&&task.addBoth===undefined&&w[k]<task.known){key=k;value=w[k];w[k]++}
 for(const [name,k] of [['equationLeftAdd','leftAdded'],['equationRightAdd','rightAdded']])if(action===name&&task.kind==='bilateral'&&task.addBoth!==undefined&&w[k]<task.addBoth){key=k;value=w[k];w[k]++}
 if(action==='equationBag'&&['unknown','bilateral','substitute'].includes(task.kind)&&w.bag<task.total){key='bag';value=w.bag;w.bag++}
 if(action==='equationKnown'&&task.kind==='substitute'&&w.knownPlaced<task.known){key='knownPlaced';value=w.knownPlaced;w.knownPlaced++}
 if(action==='equationRemove'&&task.kind==='inverse'&&!task.unknownInitial&&w.removed<task.initial){key='removed';value=w.removed;w.removed++}
 if(action==='equationReturn'&&task.kind==='inverse'&&task.unknownInitial&&w.returned<task.removedGiven){key='returned';value=w.returned;w.returned++}
 if(action==='equationWhole'&&task.unknownInitial){const d=Number(data.delta);if([-1,0,1,5].includes(d)&&w.wholeAnswer+d>=0&&w.wholeAnswer+d<=100){key='wholeAnswer';value=[w.wholeAnswer,w.wholeSet];w.wholeAnswer+=d;w.wholeSet=true}}
 if(action==='equationVerdict'&&['equal','substitute'].includes(task.kind)&&['equal','unequal','accept','reject'].includes(data.value)){key='choice';value=w.choice;w.choice=data.value}
 if(action==='equationUndo'&&w.log.length){const [previous,old]=w.log.pop();if(['left','right'].includes(previous)){const at=w[previous].indexOf(old);if(at<0)w[previous].push(old);else w[previous].splice(at,1)}else if(previous==='wholeAnswer'){w.wholeAnswer=old[0];w.wholeSet=old[1]}else w[previous]=old;w.moves++;return true}
 if(key===null)return false;w.log.push([key,value]);w.moves++;return true;
}
function equationSpeech(task){const w=equationState();if(task.kind==='equal')return `左盘已摆${w.left.reduce((a,i)=>a+task.left[i],0)}，右盘已摆${w.right.reduce((a,i)=>a+task.right[i],0)}。`;if(task.unknownInitial)return `原来剩余${task.remain}颗，已放回${w.returned}颗。我的原数量${w.wholeAnswer}。`;if(task.kind==='inverse')return `原来${task.initial}颗，已拿走${w.removed}颗。`;if(task.kind==='substitute')return `候选袋内${w.bag}颗，袋外${w.knownPlaced}颗，右盘${task.total}颗。`;return `未知袋已摆${w.bag}颗，未知盘原袋外${task.known}颗；两盘分别添${w.leftAdded}和${w.rightAdded}颗，分别拿走${w.leftTaken}和${w.rightTaken}颗。`}
function equationPage(){const task=EQUATION_TASKS[microSkillId],skill=SKILL_DATA.skills.find(s=>s.id===microSkillId);if(!task||!skill)return '<div class="panel">操作任务不存在。</div>';return `<div class="page-head"><div><p class="kicker">${esc(task.skillId)}</p><h1>${esc(skill.title)}</h1></div><button class="back" data-action="micro" data-code="${esc(task.skillId)}">← 返回</button></div><div class="work"><article class="panel"><span class="phase">练 · 操作一题</span><h2 class="task-title">${esc(task.prompt)}</h2><div class="workshop-check-top"><button class="primary" data-action="${feedback?.ok?'next':'check'}">${feedback?.ok?'完成本题 →':'检查操作与理由 ✓'}</button></div>${equationBoard(task)}${reasonBlock(task)}${actionRow(task)}</article><aside class="side-stack">${stageLinks(task.skillId)}</aside></div>`}
