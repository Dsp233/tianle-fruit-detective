'use strict';
const EvidenceRules=(()=>{
 const supported=new Set([5,6]);
 const known=version=>supported.has(version);
 const capabilities=version=>({known:known(version),exact:known(version),scoped:version===6});
 const assess=entry=>({...capabilities(entry?.evidenceVersion),independenceStatus:known(entry?.evidenceVersion)?'known':'unknown'});
 const canCountIndependent=entry=>known(entry?.evidenceVersion)&&entry.independent===true&&!entry.hinted&&!entry.priorSolutionViewed;
 return {known,exact:known,capabilities,assess,canCountIndependent};
})();
if(typeof module!=='undefined')module.exports=EvidenceRules;
