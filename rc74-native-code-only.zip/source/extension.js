/* Six additional original teaching routes; the 500-position index is not a playable exam bank. */
'use strict';
const T=(phase,mode,prompt,details)=>({phase,mode,prompt,...details});
const EXTENSION_COURSES={
 A01:{title:'十与个位',icon:'🔢',stage:'起步',steps:[
  T('学','placeValue','看十棒和圆点，点出几个十、几个一。',{tens:1,ones:6,hint:'一整条十棒是10，再数散开的点。',explain:'1个十和6个一组成16。'}),
  T('学','bundleTen','已有1根十棒和13个散点。把10个散点放进捆扎框，再捆成一根十棒。',{initialTens:1,initialOnes:13,tens:2,ones:3,hint:'点散点盘里的圆点放入捆扎框；装满10个后，点框下方按钮换出十棒。',explain:'10个一换成1个十，1十13一变成2十3一，总数仍是23。'}),
  T('学','choice','23 和 32，哪个大？',{scene:{type:'placeValue',values:[[2,3],[3,2]]},options:['左边23','右边32','一样大'],answer:1,hint:'先比较十棒的根数。',explain:'32有3个十，比23的2个十多。'}),
  T('学','number','4个十和7个一，是多少？',{scene:{type:'placeValue',values:[[4,7]]},answer:47,hint:'四条十棒是40，再添7。',explain:'40＋7＝47。'}),
  T('练','placeValue','自己看图，点出几个十、几个一。',{tens:3,ones:5,hint:'十棒3条，再数散开的点。',explain:'3个十和5个一组成35。'}),
  T('练','choice','28 拆开，哪一种对？',{scene:{type:'placeValue',values:[[2,8]]},options:['20＋8','2＋8','20＋80'],answer:0,hint:'两根十棒是20。',explain:'28＝20＋8。'}),
  T('测','placeValue','看图，点出几个十、几个一。',{tens:2,ones:7,explain:'2个十和7个一是27。'}),
  T('测','number','3个十和9个一，是多少？',{scene:{type:'placeValue',values:[[3,9]]},answer:39,explain:'30＋9＝39。'})
 ]},
 L01:{title:'等号与未知数',icon:'⚖️',stage:'起步',steps:[
  T('学','choice','天平两边：4＋3 和 3＋4。一样重吗？',{scene:{type:'equation',tokens:['4','＋','3','＝','3','＋','4']},options:['一样','左边多','右边多'],answer:0,hint:'两边都数一数。',explain:'两边都是7，等号表示一样多。'}),
  T('学','balanceUnknown','□＋3＝7。天平两边各拿走3颗，再填袋子里有几颗。',{known:3,total:7,answer:4,hint:'两边同拿3颗，等量关系仍成立。',explain:'左边□＋3，右边7；各拿走3颗，得到□＝4，代回4＋3＝7。'}),
  T('学','number','9－□＝5。拿走几个？',{scene:{type:'equation',tokens:['9','－','□','＝','5']},answer:4,hint:'从9拿到剩5，拿走了几？',explain:'9－4＝5。'}),
  T('学','multi','□＋2＝6。哪两张卡都能放进方框？',{scene:{type:'equation',tokens:['□','＋','2','＝','6']},options:['4','2＋2','6'],answer:[0,1],hint:'把每张卡算出的数再加2。',explain:'4和2＋2都表示4；放进去后两边都是6。'}),
  T('练','number','两袋糖一样多，再加3颗，共13颗。每袋几颗？',{scene:{type:'equation',tokens:['🎒','＋','🎒','＋','3','＝','13']},answer:5,hint:'先从13里拿走3，再把剩下的分两袋。',explain:'13－3＝10，每袋5颗。'}),
  T('练','choice','□＋5＝12。把12直接填进方框，哪里错了？',{scene:{type:'equation',tokens:['□','＋','5','＝','12']},options:['填12会变成17','12比5小','方框一定是5'],answer:0,hint:'代入12，左边是多少？',explain:'12＋5＝17，不等于12；方框应是7。'}),
  T('测','number','□＋8＝15。方框里是几？',{scene:{type:'equation',tokens:['□','＋','8','＝','15']},answer:7,explain:'7＋8＝15。'}),
  T('测','number','两袋一样多的糖，加4颗，共14颗。每袋几颗？',{scene:{type:'equation',tokens:['🎒','＋','🎒','＋','4','＝','14']},answer:5,explain:'先拿走4剩10，两袋各5颗。'})
 ]},
 N01:{title:'成双与整除',icon:'🔍',stage:'桥梁',steps:[
  T('学','multi','哪些数能两个一组，刚好分完？',{scene:{type:'tiles',tokens:['7','8','12','15']},options:['7','8','12','15'],answer:[1,2],hint:'试着两两配对，看看会不会剩1个。',explain:'8和12可分成完整的2人组。'}),
  T('学','number','14颗豆子，每2颗一组，能分几组？',{scene:{type:'dots',groups:[['豆子','🫘',14]]},answer:7,hint:'从左到右每两颗圈一圈。',explain:'14÷2＝7组，没有剩余。'}),
  T('学','multi','哪些数能三个一组，刚好分完？',{scene:{type:'tiles',tokens:['9','10','12','13','15']},options:['9','10','12','13','15'],answer:[0,2,4],hint:'用3、6、9、12、15往上数。',explain:'9、12、15都能被3整除。'}),
  T('学','choice','34 个点，两两配对会剩下1个吗？',{scene:{type:'placeValue',values:[[3,4]]},options:['不会','会','无法判断'],answer:0,hint:'十个十个先配，再看4个一。',explain:'34是偶数，配对不会剩1个。'}),
  T('练','multi','21、22、24、25，哪些能三个一组刚好分完？',{scene:{type:'tiles',tokens:['21','22','24','25']},options:['21','22','24','25'],answer:[0,2],hint:'用3的倍数往上数到24。',explain:'21＝3×7，24＝3×8。'}),
  T('练','number','27 个积木，每3个一堆，能分几堆？',{scene:{type:'tiles',tokens:['27','÷','3','＝','?']},answer:9,hint:'9堆每堆3个，是多少？',explain:'27÷3＝9堆。'}),
  T('测','multi','16、18、20、21，哪些能两两配对不剩下？',{scene:{type:'tiles',tokens:['16','18','20','21']},options:['16','18','20','21'],answer:[0,1,2],explain:'16、18、20是偶数；21会剩1个。'}),
  T('测','choice','个位是3的数一定能被3整除吗？',{scene:{type:'tiles',tokens:['3','13','23']},options:['不一定','一定','只有23可以'],answer:0,explain:'13不能被3整除；个位是3并不足以决定。'})
 ]},
 G03:{title:'方格剪拼面积',icon:'🧱',stage:'桥梁',steps:[
  T('学','gridSelect','4×4 方格。点出右下角剪去的2×2块。',{cols:4,rows:4,answer:[10,11,14,15],cue:true,hint:'右边最后两列、下面最后两行交会处。',explain:'剪掉4个小格。'}),
  T('学','number','4×4 剪掉右下角2×2，还剩几个小格？',{scene:{type:'grid',cols:4,rows:4,cut:[10,11,14,15]},answer:12,hint:'先数16个，再减掉4个。',explain:'16－4＝12格。'}),
  T('学','choice','这张缺角方格，用哪条路线能算剩下的格数？',{scene:{type:'grid',cols:4,rows:4,cut:[10,11,14,15]},options:['4×4－2×2','4×4＋2×2','4＋4－2'],answer:0,hint:'缺掉的部分应该加还是减？',explain:'大方格16减小方格4，还剩12。'}),
  T('学','gridSelect','3列4行。点出左上角剪去的1列2行。',{cols:3,rows:4,answer:[0,3],cue:true,hint:'左边第一列的上两格。',explain:'左上角这一小块有2格。'}),
  T('练','number','3×4 剪掉左上角1×2，还剩几个格？',{scene:{type:'grid',cols:3,rows:4,cut:[0,3]},answer:10,hint:'全部12格，少了2格。',explain:'12－2＝10格。'}),
  T('练','choice','两块不重叠的方格拼起来：2×3 和 1×3，共几格？',{scene:{type:'rectangles',values:[[2,3],[1,3]]},options:['6格','9格','12格'],answer:1,hint:'先数每块，再相加。',explain:'6＋3＝9格。'}),
  T('测','gridSelect','5列4行。点出右下角剪去的2×2块。',{cols:5,rows:4,answer:[13,14,18,19],explain:'下方两行各剪去最右边两格，共4格。'}),
  T('测','number','5×4 剪掉右下角2×2，还剩几个格？',{scene:{type:'grid',cols:5,rows:4,cut:[13,14,18,19]},answer:16,explain:'20－4＝16格。'})
 ]},
 D02:{title:'平均与中间数',icon:'📏',stage:'桥梁',steps:[
  T('学','redistribute','三盘各有2、4、6颗。动手搬一搬，让三盘一样多。',{values:[2,4,6],answer:[4,4,4],hint:'从最多的一盘，搬给最少的一盘。',explain:'6盘搬2颗给2盘后，三盘各4颗。'}),
  T('学','number','三盘2、4、6颗。平均每盘几颗？',{scene:{type:'dots',groups:[['甲','●',2],['乙','●',4],['丙','●',6]]},answer:4,hint:'三盘一共12颗，平均分三份。',explain:'(2＋4＋6)÷3＝4。'}),
  T('学','choice','按顺序摆2、4、6。中间的数是什么？',{scene:{type:'sequence',tokens:['2','4','6']},options:['2','4','6'],answer:1,hint:'已经从小到大排好。',explain:'中间数是4；它在这组数据中碰巧与平均数相同。'}),
  T('学','choice','成绩1、2、9的中间数与平均数一样吗？',{scene:{type:'sequence',tokens:['1','2','9']},options:['不一样','一样'],answer:0,hint:'中间数是2；总数12再分三份。',explain:'中间数是2，平均数是4；偏大的9会拉高平均数。'}),
  T('练','redistribute','三盘各有3、3、9颗。让三盘一样多。',{values:[3,3,9],answer:[5,5,5],hint:'大盘分别搬2颗给两只小盘。',explain:'9盘搬出4颗，两只3盘各得2颗，变成5、5、5。'}),
  T('练','number','两位同学各得4分，一位得10分。三人的平均分是多少？',{scene:{type:'table',rows:[['得分','4分','10分'],['人数','2人','1人']]},answer:6,hint:'4分要算两遍，先求三人总分。',explain:'4＋4＋10＝18，18÷3＝6；“2人”是4分的频数。',numberFeedback:{'7':'4分有两位同学，不能只把4和10各算一次。'}}),
  T('测','number','3位同学各得2分、1位得10分。平均分是多少？',{scene:{type:'table',rows:[['得分','2分','10分'],['人数','3人','1人']]},answer:4,explain:'三次2分加一次10分共16分，4人平均为4分。'}),
  T('测','choice','3、9、4从小到大排列后，中间数是几？',{scene:{type:'sequence',tokens:['3','9','4']},options:['3','4','9'],answer:1,explain:'排成3、4、9，中间数是4。'})
 ]},
 D03:{title:'可能结果与机会',icon:'🎲',stage:'桥梁',steps:[
  T('学','multi','抛硬币，只记录正面或反面。可能记下哪些？',{scene:{type:'tiles',tokens:['正面','反面']},options:['正面','反面','侧面立住'],answer:[0,1],hint:'这次活动只记录正反两面。',explain:'在这个简化模型里，记录结果有正面、反面两种。'}),
  T('学','enumerate','连续抛两次硬币。按第一次、第二次的顺序，自己列出全部结果。',{items:['正','反'],slots:2,allowRepeat:true,orderMatters:true,answer:['正|正','正|反','反|正','反|反'],hint:'先固定第一次为正，第二次可能是什么？再固定第一次为反。',explain:'正正、正反、反正、反反共4种先后结果；正反与反正不同。'}),
  T('学','multi','从红1、红2、蓝1三张卡里，哪些能算“抽到红色”？',{scene:{type:'tiles',tokens:['红1','红2','蓝1']},options:['红1','红2','蓝1'],answer:[0,1],hint:'把红色的两张卡都找出来。',explain:'符合“红色”的结果有两种，共三种等可能的卡。'}),
  T('学','choice','从2红1蓝中随机抽一张，哪种颜色更容易？',{scene:{type:'dots',groups:[['红','🔴',2],['蓝','🔵',1]]},options:['红色','蓝色','一样'],answer:0,hint:'比较红卡和蓝卡各有几张。',explain:'红卡2张、蓝卡1张，红色机会更大；不代表下一次一定红。'}),
  T('练','number','公平转盘有1到6六格，偶数有几格？',{scene:{type:'spinner',labels:['1','2','3','4','5','6']},answer:3,hint:'找2、4、6。',explain:'2、4、6三格是偶数，共3格。'}),
  T('练','choice','袋里红卡更多，下次一定抽到红吗？',{scene:{type:'dots',groups:[['红','🔴',2],['蓝','🔵',1]]},options:['不一定','一定'],answer:0,hint:'蓝卡还在袋里吗？',explain:'蓝卡仍可能被抽到；“更容易”不是“一定”。'}),
  T('测','choice','袋里2红1蓝，等可能抽一张。红色机会是多少？',{scene:{type:'dots',groups:[['红','🔴',2],['蓝','🔵',1]]},options:['2/3','1/3','2/1'],answer:0,explain:'三张卡等可能，其中两张红，所以是2/3。'}),
  T('测','number','掷一枚公平六面骰子，奇数结果有几种？',{scene:{type:'tiles',tokens:['1','2','3','4','5','6']},answer:3,explain:'1、3、5三种奇数结果。'})
 ]}
};
for(const [code,course] of Object.entries(EXTENSION_COURSES)){
 course.code=code;
 course.steps=course.steps.map((step,i)=>({...step,id:`${code}-${i+1}`}));
}
if(typeof module!=='undefined')module.exports={EXTENSION_COURSES};
