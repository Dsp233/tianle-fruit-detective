'use strict';
const FACTOR_TASKS={
 'N02.01':{kind:'pairs',numbers:[20],requiredPairs:2,context:'20块拼长方阵',prompt:'20块材料全部用上。选每行格数并实际铺成完整长方阵，记录至少两种不同的整数边长对；旋转不算新的一对。',explain:'例如2×10、4×5；1×20也可。每一种都用满20块，互换两边是同一因数对。',reason:{prompt:'2×10与10×2为什么只记一对？',options:['互换边长只是转动同一个长方阵','它们用了不同的材料总数','边长不可以互换'],answer:0}},
 'N02.02':{kind:'all',numbers:[12],context:'列全12的正因数',prompt:'用12块拼遍不同的完整整数长方阵，记录边长对，再逐个收录边长作正因数。由你判断何时列全；不漏、不重。',explain:'因数对1×12、2×6、3×4；正因数1、2、3、4、6、12。',reason:{prompt:'怎样检查有没有漏掉正因数？',options:['按小边长依次试，记录所有完整长方阵的两边','只试自己最喜欢的边长','把同一个因数再记一遍补数'],answer:0}},
 'N02.03':{kind:'prime',numbers:[2,7,9],context:'用长方阵识别质数',prompt:'分别用2、7、9块拼遍不同整数长方阵，收集不同正因数，再判断每个数是质数、合数还是都不是。',explain:'2、7只有1和自身两个正因数，是质数；9还有3，是合数。2是偶数质数，9是奇数合数。',reason:{prompt:'质数的定义是哪一条？',options:['大于1，正因数恰好是1和自身','所有奇数都是质数','只要能被1整除就是质数'],answer:0}},
 'N02.04':{kind:'unit',numbers:[1],context:'1的特殊位置',prompt:'用1块拼所有整数长方阵，收集不同正因数并数个数，再按质数、合数定义给1分类。',explain:'只有1×1，正因数只有1；它不足两个正因数，也不多于两个，所以既不是质数也不是合数。',reason:{prompt:'为什么1不是质数？',options:['它只有一个不同的正因数','它是奇数，所以应是质数','1×1里出现两次1就有两个不同因数'],answer:0}},
 'N02.05':{kind:'square',numbers:[16],context:'平方数的中间一对',prompt:'拼遍16的整数长方阵并收录不同正因数。遇到4×4时两边都是4，只保留一张4卡；最后数不同因数的个数。',explain:'1×16、2×8、4×4，正因数是1、2、4、8、16，共5个；中间4不重复计数。',reason:{prompt:'4×4对因数表贡献几张不同的卡？',options:['一张4卡','两张4卡','没有4卡'],answer:0}},
 'N02.06':{kind:'count',numbers:[36],context:'36的因数个数',prompt:'用36块拼遍不同整数长方阵，逐对收录不同边长，最后独立数正因数的个数。旋转和相同中间边长都不能重复记。',explain:'1×36、2×18、3×12、4×9、6×6，正因数1、2、3、4、6、9、12、18、36，共9个。',reason:{prompt:'为什么五对边长只得到九个不同因数？',options:['6×6中的6只收录一次','每一对都只收录一边','把1排除在正因数外'],answer:0}}
};
for(const [skillId,t] of Object.entries(FACTOR_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:33,mode:'factorLab',phase:'练',hint:'改变每行格数并用满材料；有缺格就不是完整长方阵。按小边长顺序检查，互换两边不重记。'});
if(typeof module!=='undefined')module.exports={FACTOR_TASKS};
