'use strict';
const FACTOR_CASES={
 'N02.01':[
  [{kind:'pairs',numbers:[18],requiredPairs:2,context:'18枚排座位'},'18枚排成完整整数长方阵。记录两种不同的边长对，可转方向，不能把旋转当新对。','可用1×18、2×9或3×6中的不同两对。','方块换座位并允许转方向，仍须去重'],
  [{kind:'pairs',numbers:[12],requiredPairs:2,context:'十二块材料'},'独立用12块拼出并记录两种不同整数长方阵的边长对。','1×12、2×6、3×4中选两种。','无提示：总量12'],
  [{kind:'pairs',numbers:[16],requiredPairs:2,context:'含方形的长方阵'},'隔日用16块记录两种不同完整长方阵，正方形也可以。','1×16、2×8、4×4中选两种。','隔日：允许中间平方阵'],
  [{kind:'pairs',numbers:[15],requiredPairs:2,context:'十五枚座位'},'独立排出15枚的两种不同整数长方阵并记录。','1×15、3×5。','备用：恰好两个不同因数对']
 ],
 'N02.02':[
  [{kind:'all',numbers:[18],context:'转向不新增的因数表'},'18块拼遍不同长方阵。每次可转动，但交换边长只留一对；收录全部不同正因数。','1、2、3、6、9、18。','明确允许旋转但不能重复收录，材料总量换18'],
  [{kind:'all',numbers:[20],context:'20的全部正因数'},'独立拼遍20的完整整数长方阵，收录全部不同正因数。','1、2、4、5、10、20。','无提示：不连续的中间因数'],
  [{kind:'all',numbers:[24],context:'24的因数表'},'隔日用24块列全并收录不同正因数。','1、2、3、4、6、8、12、24。','隔日：因数对数量增加'],
  [{kind:'all',numbers:[10],context:'10的因数表'},'独立用10块列全并收录所有不同正因数。','1、2、5、10。','备用：较少因数对']
 ],
 'N02.03':[
  [{kind:'prime',numbers:[2,11,15],context:'偶数质数与奇数合数'},'拼遍2、11、15的整数长方阵，收录不同正因数后分类。','2与11是质数，15有3和5，所以是合数。','保留偶数质数2，并用奇数合数否定只看奇偶'],
  [{kind:'prime',numbers:[3,4],context:'相邻两数的分类'},'独立拼遍3和4的整数长方阵，再用正因数定义分类。','3质数，4合数。','无提示：最小平方合数'],
  [{kind:'prime',numbers:[5,9],context:'隔日奇数反例'},'隔日拼遍5和9的长方阵，收录因数后分类。','5质数，9合数；两者虽然都奇数，定义不同。','隔日：两个奇数分类不同'],
  [{kind:'prime',numbers:[2,8],context:'偶数的两种定义'},'独立拼遍2和8的长方阵并分类。','2质数，8合数。','备用：两个偶数分类不同']
 ],
 'N02.04':[
  [{kind:'unit',numbers:[1,2],context:'1与2比一比'},'分别用1块、2块拼全部长方阵，收录并数不同正因数，按定义分类。','1有一个因数两者都不是；2有两个因数是质数。','从单独1改为与最小质数2并列比较'],
  [{kind:'unit',numbers:[1],context:'一颗材料'},'独立用1块拼所有长方阵，收录因数、数个数并分类。','仅1一个正因数；既非质数也非合数。','无提示：用材料核对1×1只算一个不同因数'],
  [{kind:'unit',numbers:[1,4],context:'1与合数比较'},'隔日比较1与4：拼遍、收录并数正因数，再分类。','1一个因数不属两类；4有1、2、4三个因数是合数。','隔日：1与平方合数比较'],
  [{kind:'unit',numbers:[1,3],context:'三个与一个'},'独立比较1和3，分别拼遍、数不同正因数并分类。','1一个因数，两者都不是；3两个因数是质数。','备用：1与奇数质数比较']
 ],
 'N02.05':[
  [{kind:'square',numbers:[25],context:'五乘五中间一对'},'拼遍25的完整长方阵并收录不同因数，5×5的5只保留一次，再数个数。','1、5、25，共3个。','平方根换5，平方中间因数仍只收录一次'],
  [{kind:'square',numbers:[9],context:'三乘三'},'独立拼遍9的长方阵、收录不同因数并数个数。','1、3、9，共3个。','无提示：平方根3'],
  [{kind:'square',numbers:[36],context:'六乘六与更多因数对'},'隔日拼遍36，收录不同因数并数个数；中间相同边长不能重计。','1、2、3、4、6、9、12、18、36，共9个。','隔日：平方数有更多外围因数对'],
  [{kind:'square',numbers:[4],context:'最小的非一平方数'},'独立拼遍4，收录不同因数并数个数。','1、2、4，共3个。','备用：平方根2']
 ],
 'N02.06':[
  [{kind:'count',numbers:[18],context:'非平方数的因数个数'},'拼遍18的完整长方阵，收录不同边长后数正因数的个数。','1、2、3、6、9、18，共6个，没有相同的中间边长。','由平方数改非平方数，因数对均贡献两个不同值'],
  [{kind:'count',numbers:[24],context:'24的因数个数'},'独立拼遍24并收录不同因数，数个数。','1、2、3、4、6、8、12、24，共8个。','无提示：四个非平方因数对'],
  [{kind:'count',numbers:[30],context:'30的因数个数'},'隔日拼遍30的长方阵，收录全部不同因数并数个数。','1、2、3、5、6、10、15、30，共8个。','隔日：不同因数组成但个数相同'],
  [{kind:'count',numbers:[20],context:'20的因数个数'},'独立拼遍20、收录全部不同因数并数个数。','1、2、4、5、10、20，共6个。','备用：三个因数对']
 ]
};
const factorStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(FACTOR_CASES)){
 if(cases.length!==4)throw Error('Four N02 cases required: '+skillId);factorStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];factorStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:34,mode:'factorLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'用满全部材料，排除缺格长方阵；由不同正因数的数量核对定义。'}:{})};
 }
}
for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){const t=factorStageTarget['N02.04'][kind];t.numbers=[1,[2,4,5,6][i]];t.prompt=`用1和${t.numbers[1]}个单位块分别拼出全部长方阵，比较因数个数，再判断1是否属于质数。`;t.explain='1只有一个正因数，质数恰有两个不同正因数；不能只因为分解很少就把1算成质数。';t.contentVersion=70;}
if(typeof module!=='undefined')module.exports={FACTOR_CASES};
