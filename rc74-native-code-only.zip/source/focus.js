/* Five original deeper routes; breadth.js extends these checks to all remaining routes. */
'use strict';
const FOCUS_CODES=['C01','A02','A03','L01','C04'];
const FOCUS_REVIEW={
 C01:[
  {id:'V-C01-1',phase:'巩固',mode:'formula',prompt:'绘画10人、音乐8人，两项都参加3人。用人数卡拼出至少参加一项的人数。',counts:{a:10,b:8,o:3},allowed:['A','B','O','R','Y'],minTerms:2,maxTerms:4,explain:'10＋8－3＝15；或7＋3＋5＝15。每人只算一次。'},
  {id:'V-C01-2',phase:'巩固',mode:'choice',prompt:'球类组7人、棋类组5人，共同2人。有人直接算7＋5。要检查什么？',scene:{type:'equation',tokens:['球类7','＋','棋类5','?']},options:['共同2人被算了两次','只球类的人不能数','只棋类的人不能数'],answer:0,explain:'两组直接相加会重复数共同的2人。'}
 ],
 A02:[
  {id:'V-A02-1',phase:'巩固',mode:'tenTap',prompt:'换一张十格板：已有3格。请亲手补满。',filled:3,target:10,answer:7,explain:'补7格后，3＋7＝10。'},
  {id:'V-A02-2',phase:'巩固',mode:'number',prompt:'16格去掉多出的，留下10格。去掉几格？',scene:{type:'ten',values:[16],target:20},answer:6,explain:'16－6＝10；去掉的是超过十的部分。'}
 ],
 A03:[
  {id:'V-A03-1',phase:'巩固',mode:'gridSelect',prompt:'8格中任选6格点亮，表示6/8。',cols:4,rows:2,selectionRule:'count',answer:[0,1,2,3,4,5],boardTitle:'任选6格',explain:'8格里点亮6格是6/8，也等于3/4。'},
  {id:'V-A03-2',phase:'巩固',mode:'choice',prompt:'一条巧克力分成4等份，吃掉1份。吃掉的部分写成小数是？',scene:{type:'fractions',values:[[1,4]]},options:['0.25','0.4','1.4'],answer:0,explain:'1/4＝25/100＝0.25。'}
 ],
 L01:[
  {id:'V-L01-1',phase:'巩固',mode:'number',prompt:'盒子里有一些积木，再放6块，合起来14块。盒里原有几块？',scene:{type:'equation',tokens:['□','＋','6','＝','14']},answer:8,explain:'8＋6＝14，两边相等。'},
  {id:'V-L01-2',phase:'巩固',mode:'choice',prompt:'9－□＝5。哪种代入后，两边一样多？',scene:{type:'equation',tokens:['9','－','□','＝','5']},options:['9－4＝5','9－5＝5','9－9＝5'],answer:0,explain:'代入4后，左边是5，和右边相等。'}
 ],
 C04:[
  {id:'V-C04-1',phase:'巩固',mode:'formula',prompt:'读书组11人、运动组9人，两组都参加4人。组装算式求至少参加一组的人数。',counts:{a:11,b:9,o:4},groupLabels:['读书','运动'],allowed:['A','B','O','R','Y'],minTerms:2,maxTerms:4,explain:'11＋9－4＝16；也可以7＋4＋5＝16。'},
  {id:'V-C04-2',phase:'巩固',mode:'choice',prompt:'读书组11人、运动组9人、共同4人。直接算11＋9，哪块被数重了？',options:['两组都参加的4人','只读书的7人','只运动的5人'],answer:0,explain:'共同4人在两组中各出现一次，应只保留一次。'}
 ]
};
const WORKED={
 C01:{title:'看一眼别的例子',steps:['画画组有3人，唱歌组有2人，其中1人两样都参加。','把同一个人圈出来：直接3＋2会数他两次；去掉多算的1次，得到4位不同的人。','现在回到这7张人物卡，先看每个人手里的水果。']},
 A02:{title:'先看一个补十例子',steps:['十格板已亮7格，空着3格。','点亮空的3格，7＋3＝10。','轮到你在另一张十格板上找空格。']},
 A03:{title:'先看一条分数条',steps:['一条分成5个同样大的格子。','任选2格涂色，就表示2/5；不要求一定是最左边2格。','轮到你：先看总格数，再看要点亮几格。']},
 L01:{title:'先看天平为什么平衡',steps:['2＋5 在左边，5＋2 在右边。','两边都数到7，所以可以用等号连接；等号表示两边一样多。','轮到你检查另一组左右两边。']},
 C04:{title:'先看另一组人',steps:['读书组4人、游泳组3人，其中1人两项都参加。','两组直接相加会数同一个人两次，所以4＋3－1＝6位不同的人。','轮到你用人数卡拼另一道题，不只猜最后的数字。']}
};
const SECOND_WORKED={
 C01:{index:8,title:'换一种数法',steps:['读书组6人、运动组4人，共同2人。','只读书4人、共同2人、只运动2人，三块各数一次得到8人。','试着用互不重叠的人数卡组装另一道题。']},
 A02:{index:3,title:'把一整十和多出的分开',steps:['14格先圈一整排10格，外面还剩4格。','所以14可以拆成10和4。','现在再看另一张超过10格的卡。']},
 A03:{index:3,title:'分数换成小数',steps:['10格里涂3格，是3/10。','写成小数是0.3，先让分母变成10再读。','现在尝试解释另一条分数条。']},
 L01:{index:2,title:'倒着想拿走多少',steps:['8块积木拿走一些，还剩3块。','从8数到3少了5块，所以8－5＝3。','轮到你在另一道等式里找拿走的数。']},
 C04:{index:2,title:'再看一次重叠',steps:['绘画组6人、音乐组5人，两组都参加2人。','两组直接相加会数共同的人两遍，6＋5－2＝9人。','回到另一组人数，先找共同部分。']}
};
const focusFruitTasks=typeof module!=='undefined'?require('./fruit').FRUIT_TASKS:FRUIT_TASKS;
const focusFoundation=typeof module!=='undefined'?require('./foundation').FOUNDATION_COURSES:FOUNDATION_COURSES;
const focusExtension=typeof module!=='undefined'?require('./extension').EXTENSION_COURSES:EXTENSION_COURSES;
const focusRemaining=typeof module!=='undefined'?require('./remaining').REMAINING_COURSES:REMAINING_COURSES;
for(const [code,worked] of Object.entries(WORKED)){
 const task=code==='C01'?focusFruitTasks[0]:code==='A02'?focusFoundation.A02.steps[0]:code==='L01'?focusExtension.L01.steps[0]:focusRemaining[code].steps[0];
 task.worked=worked;
}
for(const [code,{index,...worked}] of Object.entries(SECOND_WORKED)){
 (code==='C01'?focusFruitTasks:code==='A02'?focusFoundation.A02.steps:code==='L01'?focusExtension.L01.steps:focusRemaining[code].steps)[index].worked=worked;
}
focusRemaining.A03.steps[0].selectionRule='count';
focusRemaining.A04.steps[1].selectionRule='count';
const inclusion=focusRemaining.C04.steps;
Object.assign(inclusion[0],{mode:'formula',prompt:'苹果组5人、香蕉组5人、共同3人。用人数卡拼出不同的人数。',counts:{a:5,b:5,o:3},allowed:['A','B','O','R','Y'],minTerms:2,maxTerms:4});
Object.assign(inclusion[6],{mode:'formula',prompt:'喜欢苹果18人、香蕉14人、共同5人。用人数卡组装不同人数。',counts:{a:18,b:14,o:5},allowed:['A','B','O','R','Y'],minTerms:2,maxTerms:4});
focusFruitTasks[7].distractorFeedback={1:'红色只苹果的人也属于苹果整组，不能漏掉。',2:'橙色共同的人也属于苹果整组；黄色只香蕉不属于苹果整组。'};
inclusion[3].distractorFeedback={1:'只苹果的人是独立的一块，可以数；看看两张整组里哪块重叠。',2:'只香蕉的人也可以数；看看两张整组里哪块重叠。'};
focusFoundation.A02.steps[2].numberFeedback={'9':'9格是已经有的，不是空着的格数。'};
focusFoundation.A02.steps[5].numberFeedback={'13':'13格是原来的总数，题目问去掉多少才剩10。'};
focusExtension.L01.steps[1].numberFeedback={'7':'7是等号右边的总数，方框还要和3合起来才是7。'};
focusExtension.L01.steps[4].numberFeedback={'10':'先去掉外面的3颗，再把剩下的分给两袋。'};
focusRemaining.A03.steps[2].distractorFeedback={0:'第一个中间点靠近0，还不到一半；想想0和1正中间在哪里。',2:'最后一个中间点已经超过一半，回头找中点。'};
inclusion[7].numberFeedback={'27':'27包含共同喜欢两种的人；题目只问恰好喜欢一种。'};
if(typeof module!=='undefined')module.exports={FOCUS_CODES,FOCUS_REVIEW,WORKED};
