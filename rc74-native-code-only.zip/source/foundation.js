/* Six original foundation routes. Each route has 4 learn, 2 practice, 2 check tasks. */
'use strict';
const S=(phase,mode,prompt,details)=>({phase,mode,prompt,...details});
const FOUNDATION_COURSES={
 A02:{title:'凑十与拆分',icon:'🔟',steps:[
  S('学','tenTap','已有6格。点空格，把十格板补满。',{filled:6,target:10,answer:4,hint:'上排5格，下排还空几格？',explain:'又点亮4格，6＋4＝10。'}),
  S('学','tenTap','已有8格。再点几格能装满？',{filled:8,target:10,answer:2,hint:'只数最右边空着的格子。',explain:'8＋2＝10。'}),
  S('学','number','这张十格板已有9格。还差几格？',{scene:{type:'ten',values:[9],target:10},answer:1,hint:'只剩一格没有涂色。',explain:'9＋1＝10。'}),
  S('学','choice','17 可以拆成 10 和几？',{scene:{type:'ten',values:[17],target:20},options:['10 和 7','7 和 7','10 和 17'],answer:0,hint:'数完第一排10格，再数多出来的。',explain:'17＝10＋7；去掉多出的7又回到10，10＋7和17－7可以互相检查。'}),
  S('练','tenTap','已有4格。自己补到10。',{filled:4,target:10,answer:6,hint:'先补满第一排，再数第二排。',explain:'4＋6＝10。'}),
  S('练','number','13格去掉多出的，还剩10格。去掉几格？',{scene:{type:'ten',values:[13],target:20},answer:3,hint:'第二排里超过10的有几格？',explain:'13−3＝10。'}),
  S('测','tenTap','已有7格。补满10格。',{filled:7,target:10,answer:3,explain:'7＋3＝10。'}),
  S('测','number','18格去掉几格后正好剩10格？',{scene:{type:'ten',values:[18],target:20},answer:8,explain:'18−8＝10。'})
 ]},
 L03:{title:'规律密码',icon:'🧩',steps:[
  S('学','sequence','红、蓝重复。接着补两块。',{pattern:['🔴','🔵','🔴','🔵'],palette:['🔴','🔵','🟡'],answer:['🔴','🔵'],hint:'每两块为一组。',explain:'红蓝、红蓝，接着还是红蓝。'}),
  S('学','sequence','三角、方、方重复。接着补两块。',{pattern:['🔺','🟦','🟦','🔺','🟦','🟦'],palette:['🔺','🟦','⚪'],answer:['🔺','🟦'],hint:'先圈出三个一组。',explain:'三角、方、方；下一组从三角开始。'}),
  S('学','number','2、4、6、8。下一个数？',{scene:{type:'sequence',tokens:['2','4','6','8','?']},answer:10,hint:'相邻两个数差多少？',explain:'每次加2，接下来是10。'}),
  S('学','choice','1、2、3、5、8。后一个数怎样从前面的数得到？',{scene:{type:'sequence',tokens:['1','2','3','5','8']},options:['前两个数相加','每次加2','每次乘2'],answer:0,hint:'1＋2＝3，2＋3＝5；再看3＋5。',explain:'从第三项起，每项是前两项之和；这与每次加同一个数不同。'}),
  S('练','sequence','10、8、6。接着补两个数。',{pattern:['10','8','6'],palette:['2','4','5'],answer:['4','2'],hint:'每一步少2。',explain:'6−2＝4，4−2＝2。'}),
  S('练','number','2、2、4、6、10，每项由前两项相加。下一个数？',{scene:{type:'sequence',tokens:['2','2','4','6','10','?']},answer:16,hint:'把最后两个数6和10相加。',explain:'6＋10＝16；核对4＝2＋2、6＝2＋4、10＝4＋6。'}),
  S('测','sequence','2、5、8。接着补两个数。',{pattern:['2','5','8'],palette:['11','12','14','16'],answer:['11','14'],explain:'每次加3，后面是11、14。'}),
  S('测','number','1、2、4、8。下一个数？',{scene:{type:'sequence',tokens:['1','2','4','8','?']},answer:16,explain:'每次变成前一个数的2倍。'})
 ]},
 G01:{title:'长度、周长与面积',icon:'📐',steps:[
  S('学','sides','周长走哪里？点出长方形外面的边。',{rect:[4,3],answer:[0,1,2,3],hint:'沿外圈走，不走中间的小方格。',explain:'周长沿上、右、下、左四条外边。'}),
  S('学','number','长4格、宽3格。绕外面一圈走几格？',{scene:{type:'grid',cols:4,rows:3,fill:12},answer:14,hint:'上、下各4；左、右各3。',explain:'4＋3＋4＋3＝14格。'}),
  S('学','number','还是这块4×3方格。里面有多少个小格？',{scene:{type:'grid',cols:4,rows:3,fill:12},answer:12,hint:'逐行数，每行4格，共3行。',explain:'面积数里面：4×3＝12格；不是周长14。'}),
  S('学','choice','两块面积都是12格。哪块外边更长？',{scene:{type:'rectangles',values:[[2,6],[3,4]]},options:['2×6的长条','3×4的方块','一样长'],answer:0,hint:'分别沿两块的四条外边走。',explain:'2×6周长16；3×4周长14。'}),
  S('练','sides','换成2×5方格。只点外面的边。',{rect:[2,5],answer:[0,1,2,3],hint:'中间的小格不是外边。',explain:'四条外边围成周长。'}),
  S('练','number','2×5方格绕外面一圈几格？',{scene:{type:'grid',cols:2,rows:5,fill:10},answer:14,hint:'两条长5、两条短2。',explain:'5＋2＋5＋2＝14格。'}),
  S('测','number','5×5方格沿外边走一圈几格？',{scene:{type:'grid',cols:5,rows:5,fill:25},answer:20,explain:'四条边各5格，周长20格。'}),
  S('测','choice','把3×4方格转过来变成4×3，周长会变吗？',{scene:{type:'rectangles',values:[[3,4],[4,3]]},options:['不会变','变大','变小'],answer:0,explain:'只是转了方向，周长都是14格。'})
 ]},
 C02:{title:'搭配与不重数',icon:'🎒',steps:[
  S('学','pairs','两顶帽、两双鞋。按表格逐格点满，每种搭配只点一次。',{pairRows:['红帽','蓝帽'],pairCols:['黑鞋','白鞋'],options:['红帽黑鞋','红帽白鞋','蓝帽黑鞋','蓝帽白鞋','红帽黑鞋'],answer:['红帽黑鞋','红帽白鞋','蓝帽黑鞋','蓝帽白鞋'],hint:'先固定红帽换鞋，再固定蓝帽换鞋。',explain:'两行各两格，四格不重不漏；重复的红帽黑鞋不再数。'}),
  S('学','number','两顶帽，每顶配两双鞋。一共几种？',{scene:{type:'table',rows:[['','黑鞋','白鞋'],['红帽','✓','✓'],['蓝帽','✓','✓']]},answer:4,hint:'每顶帽各能配两种。',explain:'2＋2＝4种。'}),
  S('学','pairs','两顶帽、三双鞋。在表格里列全不同搭配。',{pairRows:['红帽','黄帽'],pairCols:['黑鞋','白鞋','蓝鞋'],options:['红帽黑鞋','红帽白鞋','红帽蓝鞋','黄帽黑鞋','黄帽白鞋','黄帽蓝鞋','红帽黑鞋','绿帽黑鞋'],answer:['红帽黑鞋','红帽白鞋','红帽蓝鞋','黄帽黑鞋','黄帽白鞋','黄帽蓝鞋'],hint:'红帽一行三格、黄帽一行三格；绿帽不在题目里。',explain:'两行各三格，6种不重不漏；重复卡和不存在的绿帽不算。'}),
  S('学','choice','红帽配3种鞋，黄帽也配3种鞋。总共有几种？',{scene:{type:'table',rows:[['红帽','⚫','⚪','🔵'],['黄帽','⚫','⚪','🔵']]},options:['3种','5种','6种'],answer:2,hint:'按帽子分两组相加。',explain:'3＋3＝6种。'}),
  S('练','pairs','三件衣、两条裤。自己把表格每格填满。',{pairRows:['红衣','蓝衣','绿衣'],pairCols:['短裤','长裤'],options:['红衣短裤','红衣长裤','蓝衣短裤','蓝衣长裤','绿衣短裤','绿衣长裤','红衣短裤','绿衣短裤'],answer:['红衣短裤','红衣长裤','蓝衣短裤','蓝衣长裤','绿衣短裤','绿衣长裤'],hint:'按衣服分三行，每行两条裤。',explain:'3行×2列＝6种，每格只代表一种，重复卡不多算。'}),
  S('练','number','三件衣，每件配两条裤。共有几种？',{scene:{type:'table',rows:[['红衣','短','长'],['蓝衣','短','长'],['绿衣','短','长']]},answer:6,hint:'每件衣服配两种裤子。',explain:'2＋2＋2＝6种。'}),
  S('测','pairs','两只包、三件玩具。自己逐格列出全部不同搭配。',{pairRows:['红包','蓝包'],pairCols:['小熊','皮球','积木'],options:['红包小熊','红包皮球','红包积木','蓝包小熊','蓝包皮球','蓝包积木','红包小熊'],answer:['红包小熊','红包皮球','红包积木','蓝包小熊','蓝包皮球','蓝包积木'],explain:'两行各三格，每只包都有三种玩具，共六种不同搭配。'}),
  S('测','number','两只包，每只可装三件不同玩具之一。共有几种搭配？',{scene:{type:'table',rows:[['红包','🧸','⚽','🧱'],['蓝包','🧸','⚽','🧱']]},answer:6,explain:'3＋3＝6种，每种只数一次。'})
 ]},
 D01:{title:'读图与统计',icon:'📊',steps:[
  S('学','selectIcons','一枚图标表示一个。点出所有梨，再数有几个。',{scene:{type:'dots',groups:[['苹果','🍎',2],['梨','🍐',4],['葡萄','🍇',3]]},answer:[2,3,4,5],hint:'只选梨这一排的图标。',explain:'梨这一排有4个图标，所以有4个梨。'}),
  S('学','choice','哪种最多？',{scene:{type:'dots',groups:[['苹果','🍎',2],['梨','🍐',4],['葡萄','🍇',3]]},options:['苹果','梨','葡萄'],answer:1,hint:'每一排从左边对齐，再看最右端。',explain:'梨有4个，最多。'}),
  S('学','number','梨比苹果多几个？',{scene:{type:'dots',groups:[['苹果','🍎',2],['梨','🍐',4],['葡萄','🍇',3]]},answer:2,hint:'一对一对齐，数梨多出的。',explain:'4−2＝2。'}),
  S('学','choice','柱形图每条刻度表示2个。哪种物品有6个？',{scene:{type:'barChart',labels:['苹果','梨','葡萄'],values:[4,6,2],max:8,step:2},options:['苹果','梨','葡萄'],answer:1,hint:'先读左边等距刻度0、2、4、6、8，再看柱顶。',explain:'梨的柱顶在6，不是“有3格所以有3个”。'}),
  S('练','number','新图中，书和积木一共有几个？',{scene:{type:'dots',groups:[['书','📘',3],['球','⚽',5],['积木','🧱',2]]},answer:5,hint:'只数书和积木两行。',explain:'3＋2＝5。'}),
  S('练','number','每枚苹果图标代表2个苹果。画了3枚图标，一共有几个苹果？',{scene:{type:'dots',groups:[['每枚=2个','🍎',3]]},answer:6,hint:'每枚都代表2个，数三组2。',explain:'2＋2＋2＝6；图标数不一定等于物品数。'}),
  S('测','number','蓝球6个、红球4个。蓝球多几个？',{scene:{type:'dots',groups:[['红球','🔴',4],['蓝球','🔵',6]]},answer:2,explain:'6−4＝2。'}),
  S('测','number','柱形图纵轴每格是2本。蓝色柱到第4格，表示几本？',{scene:{type:'barChart',labels:['红','蓝','绿'],values:[4,8,6],max:10,step:2},answer:8,explain:'从0到第4格是2、4、6、8；必须读刻度，不只报4格。'})
 ]},
 R01:{title:'比、倍与份数',icon:'⚖️',steps:[
  S('学','choice','蓝点3个、红点6个。红点是几份蓝点？',{scene:{type:'dots',groups:[['蓝','🔵',3],['红','🔴',6]]},options:['1份','2份','3份'],answer:1,hint:'把红点每3个圈一组。',explain:'红点是两组3个，蓝点一组3个。'}),
  S('学','number','3个蓝点对6个红点。红点是蓝点的几倍？',{scene:{type:'dots',groups:[['蓝','🔵',3],['红','🔴',6]]},answer:2,hint:'六里面有几个三？',explain:'6÷3＝2倍。'}),
  S('学','multi','哪些图表示“2比3”同样的份数关系？',{scene:{type:'dots',groups:[['红','🔴',2],['蓝','🔵',3]]},options:['红2 蓝3','红4 蓝6','红3 蓝4'],answer:[0,1],hint:'两边同时乘同一个数，关系不变。',explain:'2比3和4比6是同样的比例。'}),
  S('学','number','红2、蓝3；红增加到4，蓝按相同份数变成几？',{scene:{type:'dots',groups:[['原红','🔴',2],['原蓝','🔵',3],['新红','🔴',4]]},answer:6,hint:'红扩大两倍，蓝也扩大两倍。',explain:'蓝3×2＝6。'}),
  S('练','choice','红3、蓝2。如果红变成6，蓝应变成几？',{scene:{type:'dots',groups:[['原红','🔴',3],['原蓝','🔵',2],['新红','🔴',6]]},options:['2','4','5'],answer:1,hint:'红从3变6，是两倍。',explain:'蓝也翻倍，2×2＝4。'}),
  S('练','number','红2、蓝3。红变成6，蓝要几个才保持相同比例？',{scene:{type:'dots',groups:[['原红','🔴',2],['原蓝','🔵',3],['新红','🔴',6]]},answer:9,hint:'红变成原来的3倍。',explain:'蓝3×3＝9。'}),
  S('测','choice','哪组和“红3 蓝2”比例一样？',{scene:{type:'dots',groups:[['红','🔴',3],['蓝','🔵',2]]},options:['红6 蓝4','红6 蓝2','红3 蓝4'],answer:0,explain:'红蓝都翻倍后仍是3比2。'}),
  S('测','number','红5、蓝2。红变成10，蓝要几个？',{scene:{type:'dots',groups:[['原红','🔴',5],['原蓝','🔵',2],['新红','🔴',10]]},answer:4,explain:'红翻倍，蓝也翻倍成4。'})
 ]}
};
const FOUNDATION_STAGES={A02:'起步',L03:'起步',G01:'桥梁',C02:'起步',D01:'起步',R01:'桥梁'};
for(const [code,course] of Object.entries(FOUNDATION_COURSES)){
 course.code=code;
 course.stage=FOUNDATION_STAGES[code];
 course.steps=course.steps.map((step,i)=>({...step,id:`${code}-${i+1}`}));
}
if(typeof module!=='undefined')module.exports={FOUNDATION_COURSES};
