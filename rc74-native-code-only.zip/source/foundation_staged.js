'use strict';
// Finite authored models. A changed label alone never creates a new instance.
// Rows: transfer, independent 1/2, reserves 1/2, 24h/7d/21d, demonstration.
const FOUNDATION_MODELS={
 'A01.01':[[6,'散放'],[5,'一排'],[3,'三角'],[7,'散放'],[8,'两排'],[2,'竖排'],[9,'三排'],[10,'两排'],[6,'两排']],
 'A01.02':[[2,12],[1,14],[3,11],[1,16],[2,15],[0,17],[3,18],[2,19],[0,12]],
 'A01.03':[[5,2,'钱币'],[4,8,'十棒'],[6,1,'整包'],[7,3,'钱币'],[2,9,'整包'],[8,2,'十棒'],[3,7,'钱币'],[9,0,'整包'],[2,6,'十棒']],
 'A01.04':[[52,49],[47,49],[67,76],[35,53],[82,79],[58,51],[64,46],[93,98],[24,27]],
 'A01.05':[[3,1,2],[4,2,3],[2,5,1],[3,4,1],[5,6,3],[4,8,2],[6,1,4],[5,3,2],[3,6,2]],
 'A02.01':[[6,2,'add'],[9,4,'remove'],[11,4,'remove'],[5,3,'add'],[12,5,'remove'],[8,3,'remove'],[7,5,'add'],[13,6,'remove'],[8,2,'add']],
 'A02.02':[[8],[7],[0],[9],[5],[4],[3],[2],[1]],
 'A02.03':[[5,4],[6,3],[8,2],[4,5],[9,3],[5,6],[8,4],[7,5],[3,4]],
 'A02.04':[[4,3],[5,2],[2,6],[3,5],[4,4],[2,7],[5,3],[3,6],[2,4]],
 'A02.05':[[12,4,'groups'],[15,5,'each'],[16,4,'each'],[18,3,'groups'],[20,5,'groups'],[8,2,'each'],[21,3,'groups'],[24,6,'each'],[10,2,'groups']],
 'A02.06':[[6,-2,2],[4,1,3],[5,1,2],[2,4,3],[7,-3,3],[3,3,4],[8,-2,2],[5,2,3],[4,-1,2]]
};
const foundationWork=typeof module!=='undefined'?require('./workshop').WORKSHOP_TASKS:WORKSHOP_TASKS;
const foundationStages=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
const FOUNDATION_DEMOS={};
function foundationInstance(sid,row,id,phase,dimension){
 const t={id,skillId:sid,contentVersion:68,phase,changeDimension:dimension,authorship:'原创儿童操作适配',semanticParameters:row};
 const [a,b,c]=row;
 if(sid==='A01.01')Object.assign(t,{mode:'counterBuild',target:a,layout:b,prompt:`图卡的星星按${b}摆放。摆出同样多的圆点，逐个对应。`,explain:`不论摆成什么形状，每颗星都与一个圆点配对，共${a}对。`});
 if(sid==='A01.02')Object.assign(t,{mode:'forwardExchange',initialTens:a,initialOnes:b,prompt:`已有${a}根十棒和${b}个散点。任选10个散点放进框，换成一根十棒，再判断总数是否改变。`,explain:`被选中的10个原散点组成新十棒，余下${b-10}个没有消失，总数仍是${10*a+b}。`});
 if(sid==='A01.03')Object.assign(t,{mode:'placeCompose',tens:a,ones:b,representation:c,prompt:c==='钱币'?`有${a}张十元和${b}枚一元。用十棒和散点摆出相同金额。`:c==='整包'?`${a}包积木，每包10块，外面还有${b}块。用十棒和散点表示。`:`用十棒和散点摆出${10*a+b}。`,explain:`${a}个十与${b}个一合成${10*a+b}，两种单位要分别核对。`});
 if(sid==='A01.04')Object.assign(t,{mode:'compareBuild',initial:[a,b],target:[a,b],prompt:`左盘表示${a}，右盘表示${b}。选较大的盘；也可以调整、放回圆点核对。`,explain:`先比较十位，再比较个位，${Math.max(a,b)}较大。`});
 if(sid==='A01.05')Object.assign(t,{mode:'reverseExchange',initialTens:a,initialOnes:b,targetTens:c,targetOnes:10*(a-c)+b,prompt:`从${a}十${b}一出发，拆成${c}根十棒和散点。再判断总数有没有改变。`,explain:`拆出的每根棒都带回原来的10个一，${c}十${10*(a-c)+b}一仍是${10*a+b}。`});
 if(sid==='A02.01')Object.assign(t,{mode:c==='add'?'counterChange':'counterRemove',initial:a,remove:b,add:b,prompt:c==='add'?`盘里有${a}颗，旁边又有${b}颗。逐颗搬进盘里。`:`盘里有${a}颗，逐颗拿走${b}颗，放在旁边。`,explain:c==='add'?`${b}个原对象搬进盘里，合并为${a+b}颗。`:`${b}颗搬到旁边，盘里剩${a-b}颗；合起来仍是原来的${a}颗。`});
 if(sid==='A02.02')Object.assign(t,{mode:'tenFill',filled:a,target:10,prompt:`十格板已有${a}颗。把空位置逐个补满，可以放回重新检查。`,explain:`已有${a}，补上${10-a}，合起来正好10；每个位置只放一颗。`});
 if(sid==='A02.03')Object.assign(t,{mode:'inverseMove',initial:a,delta:b,prompt:`先给${a}颗添${b}颗，再拿走同样多。完成这两个动作，选出相符的关系。`,explain:`${a}＋${b}－${b}回到${a}，添入和拿走互相抵消。`});
 if(sid==='A02.04')Object.assign(t,{mode:'equalGroups',groups:a,each:b,total:a*b,prompt:`把待分区的圆点摆成${a}组，每组${b}颗。每颗只能放在一组里。`,explain:`${a}组各${b}颗是${a}个${b}相加，共${a*b}颗。`});
 if(sid==='A02.05')Object.assign(t,{mode:'equalGroups',groups:c==='each'?b:a/b,each:c==='each'?a/b:b,total:a,unknownKind:c,dynamicGroups:c==='groups',prompt:c==='groups'?`${a}颗圆点，每盘装${b}颗。自己开盘，逐颗装完。`:`${a}颗圆点平均放入${b}盘。把全部圆点分完，让每盘一样多。`,explain:c==='groups'?`每盘${b}颗，${a}颗能装${a/b}盘，这是求盘数。`:`${a}颗平均分${b}盘，每盘${a/b}颗，这是求每份的量。`});
 if(sid==='A02.06')Object.assign(t,{mode:'orderGroups',initial:a,add:b,copies:c,prompt:`每组先有${a}颗，${b>=0?'添入':'拿走'}${Math.abs(b)}颗，再摆成${c}个完整相同的组。`,explain:`先完成括号里的${a}${b>=0?'＋':'－'}${Math.abs(b)}，得到${a+b}，再取${c}组，共${(a+b)*c}。`});
 if(phase==='练')t.hint='先按题意操作一个对象，再核对关系；可以撤销。';
 return t;
}
for(const [sid,rows] of Object.entries(FOUNDATION_MODELS)){
 const kinds=['transfer','independent','independent2','independent3','independent4','delayed','delayed7','delayed21'];
 const suffix={transfer:1,independent:2,delayed:3,independent2:4,independent3:5,independent4:6,delayed7:7,delayed21:8};
 foundationStages[sid]={};
 rows.slice(0,8).forEach((row,i)=>{const kind=kinds[i],phase=kind==='transfer'?'迁移':kind.startsWith('delayed')?'巩固':'测';foundationStages[sid][kind]=foundationInstance(sid,row,`T-${sid.replace('.','-')}-${suffix[kind]}`,phase,i===0?({'A01.01':'改变摆放结构，逐个对应，数量不依赖排列','A01.02':'非标准十与一实际交换；追踪原散点','A01.03':'钱币/整包单位转换到位值表示','A01.04':'十位不同，不能只看个位','A01.05':'从标准表示拆开，追踪同一批单位','A02.01':'从拿走改为合并，方向与对象来源改变','A02.02':'从算式辨识改为空位实际补齐','A02.03':'先构造再反向核对，保留原对象','A02.04':'组数与组大小角色分别核对','A02.05':'未知从每份量变为份数，自己开盘','A02.06':'括号内从加法变为减法'})[sid]:'有限新参数实例；不单独宣称新的迁移维度')});
 FOUNDATION_DEMOS[sid]=foundationInstance(sid,rows[8],`D-${sid.replace('.','-')}-1`,'学','不同于练习和正式测验的真实操作示范');
}
// Retain the eight original practice models, and add the three missing ones.
const foundationMissing={
 'A01.02':foundationInstance('A01.02',[1,13],'O-A01-02-1','练','任选10个入框'),
 'A01.03':foundationInstance('A01.03',[3,4,'十棒'],'O-A01-03-1','练','位值组成'),
 'A02.02':foundationInstance('A02.02',[6],'O-A02-02-1','练','补齐十格')
};
Object.assign(foundationWork,foundationMissing);
for(const t of Object.values(foundationWork)){
 t.contentVersion=68;
 if(!t.reason)t.reason={prompt:'什么说明这次操作符合题意？',options:[t.explain,'只要外形相似，数量和单位都可以忽略','改变表示就一定改变了总数'],answer:0};
}
if(typeof module!=='undefined')module.exports={FOUNDATION_MODELS,FOUNDATION_DEMOS,foundationInstance};
