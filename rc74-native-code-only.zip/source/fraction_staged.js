'use strict';
// Fixed A03 cases: prompt, operation parameters, feedback, and the changed
// mathematical dimension. No random number substitutions or replayed IDs.
const FRACTION_CASES={
 'A03.01':[
  ['同样大的一张纸平均折6份，逐格涂4份。',{kind:'shade',denom:6,target:4},'四格占六等份，即4/6；整体仍是这张纸。','蛋糕换纸条，分母从4变6'],
  ['一个长方形等分8格，涂出5/8。',{kind:'shade',denom:8,target:5},'八个等格中取五格，表示5/8。','新的8格整体与5份'],
  ['一块相同大小的板分5格，涂出其中2/5。',{kind:'shade',denom:5,target:2},'五等份取二份，是2/5。','分成5格的新整体'],
  ['一条纸带等分6格，涂出其中5格。',{kind:'shade',denom:6,target:5},'六格整体取五格，是5/6。','另一个六等分新实例']
 ],
 'A03.02':[
  ['把一张纸折成5等份，只涂一个单位份。',{kind:'shade',denom:5,target:1},'一个等份是整体的1/5。','四等分换五等分'],
  ['一条纸带等分8格，只涂1/8。',{kind:'shade',denom:8,target:1},'八等份中只取一份。','八等份单位分数'],
  ['同样宽的纸条等分6格，涂一个单位份。',{kind:'shade',denom:6,target:1},'六等份中一份是1/6。','六等份的隔日实例'],
  ['把纸条等分3格，只涂1/3。',{kind:'shade',denom:3,target:1},'三等份中一份是1/3。','三等份新实例']
 ],
 'A03.03':[
  ['两个同样长的整体都分5格。左条涂4格，右条涂3格，比较涂色。',{kind:'compare',denomLeft:5,targetLeft:4,denomRight:5,targetRight:3,correctChoice:'left'},'同整体同分母，左边多一份。','从四格换成五格'],
  ['两条同样长的纸都六等分。左条涂2格，右条涂4格，选较多的一侧。',{kind:'compare',denomLeft:6,targetLeft:2,denomRight:6,targetRight:4,correctChoice:'right'},'右条的4/6多于左条2/6。','大小方向反转'],
  ['两条同样长的纸都八等分。左条涂5份，右条涂6份。',{kind:'compare',denomLeft:8,targetLeft:5,denomRight:8,targetRight:6,correctChoice:'right'},'相同整体的八等份中，右条多一格。','八等分新比较'],
  ['两个同长整体都五等分。左涂3格，右涂2格。',{kind:'compare',denomLeft:5,targetLeft:3,denomRight:5,targetRight:2,correctChoice:'left'},'左条3/5多于2/5。','五等分的另一新实例']
 ],
 'A03.04':[
  ['同样长的两条纸，左六等分涂3格，右八等分涂4格，判断是否等长。',{kind:'equal',denomLeft:6,targetLeft:3,denomRight:8,targetRight:4},'3/6与4/8都占各自同长整体的一半。','分母换6和8，同一半'],
  ['两条同长纸：左六等分涂2格，右三等分涂1格。',{kind:'equal',denomLeft:6,targetLeft:2,denomRight:3,targetRight:1},'2/6和1/3的涂色总长度一样。','等值改成三分之一'],
  ['两条同长纸：左八等分涂2格，右四等分涂1格。',{kind:'equal',denomLeft:8,targetLeft:2,denomRight:4,targetRight:1},'2/8与1/4相同。','等值改成四分之一'],
  ['两条同长纸：左九等分涂3格，右六等分涂2格。',{kind:'equal',denomLeft:9,targetLeft:3,denomRight:6,targetRight:2},'3/9与2/6都等于1/3。','九等分与六等分的新配对']
 ],
 'A03.05':[
  ['0到1的数轴六等分。点选1/2所在刻度。',{kind:'line',denom:6,target:3},'从0走三段，3/6＝1/2。','数轴从四段换六段'],
  ['0到1平均分八段。点选3/4所在刻度。',{kind:'line',denom:8,target:6},'六段占八段，6/8＝3/4。','目标位置换3/4'],
  ['0到1平均分十段。点选2/5所在刻度。',{kind:'line',denom:10,target:4},'四段占十段，4/10＝2/5。','十分位刻度换分数位置'],
  ['0到1平均分五段。点选2/5所在刻度。',{kind:'line',denom:5,target:2},'从0数两个等距间隔。','五等分的新数轴']
 ],
 'A03.06':[
  ['把一条纸分10格，涂4格，选择对应小数。',{kind:'decimal',denom:10,target:4,choices:['0.4','0.04','4'],correctChoice:'0.4'},'四个十分之一是0.4。','十分位由7换4，辨别百分位'],
  ['十格纸条涂9格，选出小数表示。',{kind:'decimal',denom:10,target:9,choices:['0.9','0.09','9'],correctChoice:'0.9'},'九个十分之一写作0.9。','接近整体1的新实例'],
  ['十格纸条涂2格，选择小数。',{kind:'decimal',denom:10,target:2,choices:['0.2','0.02','2'],correctChoice:'0.2'},'两个十分之一是0.2。','隔日较小份量'],
  ['十格纸条涂6格，选择小数。',{kind:'decimal',denom:10,target:6,choices:['0.6','0.06','6'],correctChoice:'0.6'},'六个十分之一是0.6。','另一个十分位实例']
 ],
 'A03.07':[
  ['一个整体16块，先拿走8块，再从剩下8块中取一半。',{kind:'remainder',total:16,first:8,second:4},'第二次拿走4/16，是原整体的1/4。','12块换16块，整体不变'],
  ['原有20块，先取一半，再取余下的一半。',{kind:'remainder',total:20,first:10,second:5},'第二次是5/20，原整体的1/4。','新20块整体'],
  ['原有8块，先取走4块，再取余下的一半。',{kind:'remainder',total:8,first:4,second:2},'第二次2/8，仍是原整体的1/4。','8块整体的隔日实例'],
  ['原有24块，先取走12块，再从余下取一半。',{kind:'remainder',total:24,first:12,second:6},'第二次6/24，是原整体的1/4。','24块整体的新实例']
 ]
};
const fractionStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(FRACTION_CASES)){
 if(cases.length!==4)throw Error('Four A03 cases required: '+skillId);
 fractionStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [prompt,params,explain,changeDimension]=cases[i];
  fractionStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:10,mode:'fractionLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,...(params.kind==='remainder'?{choices:['1/4','1/2','1/8'],correctChoice:'1/4'}:{}),prompt,explain,changeDimension,
   ...(kind==='transfer'?{hint:'先确认同一个整体、等分份数和本题要比较的量，再操作。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={FRACTION_CASES};
