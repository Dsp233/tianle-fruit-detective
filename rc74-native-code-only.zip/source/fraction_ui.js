'use strict';
function fractionState(){return draft.work??(draft.work={left:[],right:[],first:[],second:[],phase:1,marker:-1,choice:'',moves:0})}
function fractionSectorPath(index,denom){if(denom===1)return 'M150 30A120 120 0 1 1 150 270A120 120 0 1 1 150 30Z';const a=index*2*Math.PI/denom-Math.PI/2,b=(index+1)*2*Math.PI/denom-Math.PI/2;return `M150 150L${150+120*Math.cos(a)} ${150+120*Math.sin(a)}A120 120 0 ${denom===1?1:0} 1 ${150+120*Math.cos(b)} ${150+120*Math.sin(b)}Z`}
function fractionStrip(side,denom,ordered=false,task={}){const w=fractionState(),picked=new Set(w[side]),shape=task.wholeShape||'strip',rows=task['partitionRows'+(side==='left'?'Left':'Right')]||task.partitionRows||1,scale=(task['wholeScale'+(side==='left'?'Left':'Right')]||1)/Math.max(task.wholeScaleLeft||1,task.wholeScaleRight||1);const buttons=Array.from({length:denom},(_,i)=>`<button class="fraction-cell ${picked.has(i)?'lit':''}" data-action="fractionCell" data-side="${side}" data-index="${i}" ${ordered&&i!==w[side].length&&i!==w[side].length-1?'disabled':''} aria-label="第${i+1}个等份，${picked.has(i)?'已涂色':'未涂色'}" aria-pressed="${picked.has(i)}">${shape==='circle'?i+1:''}</button>`).join('');
 if(shape==='circle')return `<div class="fraction-circle"><svg viewBox="0 0 300 300" role="img" aria-label="同一个圆平均分${denom}份，涂${picked.size}份">${Array.from({length:denom},(_,i)=>`<path d="${fractionSectorPath(i,denom)}" fill="${picked.has(i)?'#f3bd63':'#fff'}" stroke="#4d8674" stroke-width="2"/>`).join('')}</svg><div class="fraction-sector-controls">${buttons}</div></div>`;
 return `<div class="fraction-strip ${rows>1?'partition-grid':''}" style="--parts:${denom/rows};--partition-rows:${rows};width:${scale*100}%;" role="group" aria-label="${side==='left'?'左':'右'}整体，平均分${denom}份，${rows>1?rows+'行方格':'纸条'}">${buttons}</div>`;
}
function fractionChoices(task){const w=fractionState(),options=task.kind==='compare'?[['left','左条较多'],['right','右条较多'],['equal','一样多'],...(task.correctChoice==='differentWhole'?[['differentWhole','每格大小不同，不能只比格数']]:[])]:task.kind==='equal'?[['equal',task.compareArea?'面积一样大':'一样长'],['left','左边较多'],['right','右边较多']]:(task.choices||['0.7','0.07','7']).map(v=>[v,v]);return choiceButtons(task,options,'fractionChoice')}
function fractionBoard(task){const w=fractionState();
 if(['shade','decimal'].includes(task.kind))return `<div class="board fraction-board"><h3>同一个${task.wholeShape==='circle'?'圆':task.partitionRows?'方格面':'纸条'} · ${task.denom} 等份</h3>${fractionStrip('left',task.denom,false,task)}<p class="tiny-note">已点亮 ${w.left.length} / ${task.denom} 份。可再点一次撤回。</p>${task.kind==='decimal'?'<p>选出涂色部分的小数：</p>'+fractionChoices(task):''}</div>`;
 if(['compare','equal'].includes(task.kind))return `<div class="board fraction-board"><h3>${task.correctChoice==='differentWhole'?'先核对两个整体':task.compareArea?'外框面积一样大':'外框一样长'}，分法可以不同</h3><p class="tiny-note">从左逐格涂色；点最后一格可撤回。</p><p>左条 · ${task.denomLeft} 等份</p>${fractionStrip('left',task.denomLeft,true,task)}<p>右条 · ${task.denomRight} 等份</p>${fractionStrip('right',task.denomRight,true,task)}<p>${task.correctChoice==='differentWhole'?'能否只按涂色格数直接比较？':task.compareArea?'比较涂色面积：':'比较涂色长度：'}</p>${fractionChoices(task)}</div>`;
 if(task.kind==='line')return `<div class="board fraction-board"><h3>${task.lineStart??0} 到 ${task.lineEnd??1} · ${task.denom} 段等距</h3><div class="fraction-line" role="group" aria-label="数轴上的${task.denom+1}个刻度">${Array.from({length:task.denom+1},(_,i)=>`<button class="fraction-tick" data-action="fractionMark" data-index="${i}" aria-pressed="${w.marker===i}" aria-label="从${task.lineStart??0}向右第${i}段的位置">${i===0?task.lineStart??0:i===task.denom?task.lineEnd??1:'●'}</button>`).join('')}</div><p class="tiny-note">从左端点数经过的段数；端点也可以点。</p></div>`;
if(task.kind==='remainder')return `<div class="board fraction-board"><h3>原来${task.total}块 · 第${w.phase}次拿走</h3>${task.requireBasisSelection?`<div class="work-buttons"><button data-action="fractionReference" data-value="original" aria-pressed="${w.reference==='original'}">原来的一盘作为整体</button><button data-action="fractionReference" data-value="remaining" aria-pressed="${w.reference==='remaining'}">第一次后的一盘作为整体</button></div>`:''}<div class="fraction-pieces">${Array.from({length:task.total},(_,i)=>`<button class="fraction-piece ${w.first.includes(i)?'first':w.second.includes(i)?'second':''} ${w.reference==='original'||w.reference==='remaining'&&!w.first.includes(i)?'in-reference':''}" data-action="fractionPiece" data-index="${i}" data-object-id="P${i+1}" ${w.phase===2&&w.first.includes(i)?'disabled':''} aria-label="第${i+1}块，${w.first.includes(i)?'第一次拿走':w.second.includes(i)?'第二次拿走':'盘里剩余'}" aria-pressed="${w.phase===1?w.first.includes(i):w.second.includes(i)}">${w.first.includes(i)?'①':w.second.includes(i)?'②':'●'}</button>`).join('')}</div><p>第一次拿${w.first.length}块，第二次拿${w.second.length}块。</p><div class="work-buttons"><button data-action="fractionPhase" ${w.first.length===task.first||w.phase===2?'':'disabled'}>完成第一次，开始第二次</button><button data-action="fractionReset" ${w.moves?'':'disabled'}>↩ 从头重摆</button></div>${task.choices?`<p>第二次占${task.answerBasis==='remaining'?'第一次后的一盘':'原整体'}的几分之几？</p>`+fractionChoices(task):''}</div>`;
 return '';
}
function fractionGrade(task){const w=fractionState();let ok=false;
 if(task.kind==='shade')ok=w.left.length===task.target;
 if(task.kind==='decimal')ok=w.left.length===task.target&&w.choice===(task.correctChoice||'0.7');
 if(task.kind==='compare')ok=w.left.length===task.targetLeft&&w.right.length===task.targetRight&&w.choice===(task.correctChoice||'left');
 if(task.kind==='equal')ok=w.left.length===task.targetLeft&&w.right.length===task.targetRight&&w.choice==='equal';
 if(task.kind==='line')ok=w.marker===task.target;
 if(task.kind==='remainder')ok=w.phase===2&&w.first.length===task.first&&w.second.length===task.second&&new Set([...w.first,...w.second]).size===task.first+task.second&&(!task.correctChoice||w.choice===task.correctChoice)&&(!task.requireBasisSelection||w.reference===(task.answerBasis||'original'));
 return {ok,incomplete:w.moves===0||['decimal','compare','equal'].includes(task.kind)&&!w.choice||task.kind==='remainder'&&(w.phase===1||task.correctChoice&&!w.choice),reason:'检查同一个整体、等分份数、涂色格数和所选关系；再调整纸条或圆点。'};
}
function fractionAct(action,data,task){const w=fractionState();let changed=false;
 if(action==='fractionReference'&&task.requireBasisSelection&&['original','remaining'].includes(data.value)){w.reference=data.value;changed=true}
 if(action==='fractionCell'&&['shade','decimal','compare','equal'].includes(task.kind)){
  const side=data.side,i=Number(data.index),denom=side==='left'?task.denom??task.denomLeft:task.denomRight;
  if(['left','right'].includes(side)&&Number.isInteger(i)&&i>=0&&i<denom){
   if(['compare','equal'].includes(task.kind)){
    if(i===w[side].length){w[side].push(i);changed=true}
    else if(i===w[side].length-1){w[side].pop();changed=true}
   }else{const at=w[side].indexOf(i);at>=0?w[side].splice(at,1):w[side].push(i);changed=true}
  }
 }
 if(action==='fractionMark'&&task.kind==='line'){const i=Number(data.index);if(Number.isInteger(i)&&i>=0&&i<=task.denom){w.marker=i;changed=true}}
 if(action==='fractionChoice'&&['decimal','compare','equal','remainder'].includes(task.kind)&&(task.kind==='decimal'||task.kind==='remainder'?(task.choices||['0.7','0.07','7']).includes(data.value):['left','right','equal',...(task.correctChoice==='differentWhole'?['differentWhole']:[])].includes(data.value))){w.choice=data.value;changed=true}
 if(action==='fractionPiece'&&task.kind==='remainder'){
  const i=Number(data.index),list=w.phase===1?w.first:w.second;
  if(Number.isInteger(i)&&i>=0&&i<task.total&&!(w.phase===2&&w.first.includes(i))){const at=list.indexOf(i);at>=0?list.splice(at,1):list.push(i);changed=true}
 }
 if(action==='fractionPhase'&&task.kind==='remainder'&&w.phase===1&&w.first.length===task.first){w.phase=2;changed=true}
 if(action==='fractionReset'&&task.kind==='remainder'&&w.moves){draft.work={left:[],right:[],first:[],second:[],phase:1,marker:-1,choice:'',moves:0};return true}
 if(changed)w.moves++;
 return changed;
}
function fractionSpeech(task){const w=fractionState();return task.kind==='line'?w.marker<0?'还未选择刻度。':`从${task.lineStart??0}起向右第${w.marker}段的刻度。`:task.kind==='remainder'?`第一次拿走${w.first.length}块，第二次拿走${w.second.length}块，原来共有${task.total}块。`:`左条涂${w.left.length}格${task.denomRight?'，右条涂'+w.right.length+'格':''}。`}
function fractionPage(){const task=FRACTION_TASKS[microSkillId],skill=SKILL_DATA.skills.find(s=>s.id===microSkillId);if(!task||!skill)return `<div class="panel">操作任务不存在。<button data-action="skillMap">回微技能目录</button></div>`;
 return `<div class="page-head"><div><p class="kicker">${esc(task.skillId)} · 分数操作</p><h1>${esc(skill.title)}</h1></div><button class="back" data-action="micro" data-code="${esc(task.skillId)}">← 微技能</button></div><div class="work"><article class="panel"><span class="phase">练 · 操作一题</span><h2 class="task-title">${esc(task.prompt)}</h2><div class="workshop-check-top"><button class="primary" data-action="${feedback?.ok?'next':'check'}">${feedback?.ok?'完成本题，回到微技能 →':'检查操作与理由 ✓'}</button></div>${fractionBoard(task)}${reasonBlock(task)}${actionRow(task)}</article><aside class="side-stack"><section class="panel"><h3>同一个整体</h3><p class="muted">先认出题目的整体，再看每个等份有多大。</p></section></aside></div>`;
}
