'use strict';
const PEOPLE=[
  {name:'小安',group:'r',fruit:'🍎'},
  {name:'小贝',group:'r',fruit:'🍎'},
  {name:'小晨',group:'o',fruit:'🍎🍌'},
  {name:'小朵',group:'o',fruit:'🍎🍌'},
  {name:'小易',group:'o',fruit:'🍎🍌'},
  {name:'小凡',group:'y',fruit:'🍌'},
  {name:'小谷',group:'y',fruit:'🍌'}
];
const F=(phase,mode,prompt,details)=>({phase,mode,prompt,...details});
const FRUIT_TASKS=[
  F('学','people','先点两位只喜欢苹果的小朋友。',{want:[0,1],hint:'找手里只有🍎的卡片。',explain:'小安和小贝只喜欢苹果。红色始终表示这一组。'}),
  F('学','people','喜欢苹果的都有谁？点出全部。',{want:[0,1,2,3,4],hint:'共同喜欢两种水果的人也喜欢苹果。',explain:'红色2人＋橙色3人＝苹果整组5人。'}),
  F('学','people','喜欢香蕉的都有谁？点出全部。',{want:[2,3,4,5,6],hint:'香蕉整组包含共同喜欢的3人。',explain:'橙色3人＋黄色2人＝香蕉整组5人。'}),
  F('学','people','只喜欢香蕉的是哪两位？',{want:[5,6],hint:'找手里只有🍌的卡片。',explain:'小凡和小谷只喜欢香蕉。黄色始终表示这一组。'}),
  F('学','people','两种都喜欢的有谁？',{want:[2,3,4],hint:'看谁同时拿着🍎和🍌。',explain:'小晨、小朵、小易是同一批共同喜欢的3人。'}),
  F('学','number','只喜欢苹果、两种都喜欢、只喜欢香蕉分别是 2、3、2。不同的小朋友共几位？',{answer:7,hint:'三块区域互不重叠，各数一次。',explain:'2＋3＋2＝7人。'}),
  F('学','choice','苹果整组是哪些颜色？',{options:['红＋橙','只有红','橙＋黄'],answer:0,hint:'共同喜欢的人也在苹果整组里。',explain:'苹果整组＝红色只苹果＋橙色两种都喜欢。'}),
  F('学','choice','把苹果整组 5 人和香蕉整组 5 人直接相加，哪里数重了？',{options:['橙色共同3人','红色只苹果2人','黄色只香蕉2人'],answer:0,hint:'同一位孩子是否会出现在两张整组卡里？',explain:'橙色3位孩子出现在两组中，各被数了一次。'}),
  F('学','formula','用三块互不重叠的区域，拼出不同人数。',{counts:{a:5,b:5,o:3},allowed:['R','O','Y'],terms:3,hint:'每种颜色各出现一次。',explain:'2＋3＋2＝7；顺序调换仍然正确。'}),
  F('学','formula','先取一整组，再补没有数过的一块。',{counts:{a:5,b:5,o:3},allowed:['A','B','R','Y'],terms:2,hint:'苹果整组里已有橙色，另一块只补黄色。',explain:'苹果整组5＋只香蕉2＝7；反过来也可以。'}),
  F('学','formula','两张整组卡都算，再去掉重复的一次。',{counts:{a:5,b:5,o:3},allowed:['A','B','O'],terms:3,hint:'两整组都含共同3人，最终每人只算一次。',explain:'5＋5−3＝7；也可以先减共同，再加另一组。'}),
  F('学','choice','为什么只减共同的 3 人一次？',{options:['原来每位被算了两次，减一次后各算一次','共同3人不属于任何组','红色和黄色也都要减'],answer:0,hint:'目标是每个人恰好被算一次。',explain:'共同的每人原先出现两次，去掉重复的一次后留下一个。'}),
  F('练','number','苹果整组 18 人，共同 5 人。只喜欢苹果有几人？',{counts:{a:18,b:14,o:5},answer:13,hint:'从苹果整组去掉共同的人。',explain:'18−5＝13。红色只苹果13人。'}),
  F('练','number','香蕉整组 14 人，共同 5 人。只喜欢香蕉有几人？',{counts:{a:18,b:14,o:5},answer:9,hint:'从香蕉整组去掉共同的人。',explain:'14−5＝9。黄色只香蕉9人。'}),
  F('练','formula','苹果 18 人、香蕉 14 人、共同 5 人。拼出不同人数。',{counts:{a:18,b:14,o:5},allowed:['A','B','O','R','Y'],minTerms:2,maxTerms:4,hint:'可用两张整组去重，也可先找两个“只喜欢”的区域。',explain:'18＋14−5＝27；13＋5＋9＝27；18＋9＝27。'}),
  F('练','choice','苹果 12 人、香蕉 9 人、共同 4 人。有人算出 21 人，问题在哪？',{counts:{a:12,b:9,o:4},options:['共同4人被算了两次','只苹果8人不能算','香蕉整组9人不能算'],answer:0,hint:'两张完整组卡里是否有同一个人？',explain:'应去掉重复的一次：12＋9−4＝17。'}),
  F('测','choice','这 7 人中，苹果整组有多少位？',{options:['2位','3位','5位'],answer:2,explain:'红色2位加橙色3位，共5位。'}),
  F('测','choice','这 7 人中，香蕉整组有多少位？',{options:['2位','5位','7位'],answer:1,explain:'橙色3位加黄色2位，共5位。'}),
  F('测','people','点出两种水果都喜欢的小朋友。',{want:[2,3,4],explain:'仍是小晨、小朵、小易这3位。'}),
  F('测','number','苹果整组 5 人、共同 3 人。只喜欢苹果有几位？',{answer:2,explain:'5−3＝2。'}),
  F('测','formula','苹果整组 6、香蕉整组 5、共同 2。用三块颜色拼出不同人数。',{counts:{a:6,b:5,o:2},allowed:['R','O','Y'],terms:3,explain:'只苹果4＋共同2＋只香蕉3＝9。'}),
  F('测','formula','苹果整组 8、香蕉整组 7、共同 3。用一整组和另一块拼人数。',{counts:{a:8,b:7,o:3},allowed:['A','B','R','Y'],terms:2,explain:'苹果整组8＋只香蕉4＝12；或香蕉整组7＋只苹果5＝12。'}),
  F('测','formula','苹果整组 9、香蕉整组 6、共同 2。两整组怎样去重？',{counts:{a:9,b:6,o:2},allowed:['A','B','O'],terms:3,explain:'9＋6−2＝13人。'}),
  F('测','number','苹果 18 人、香蕉 14 人、共同 5 人，不同的人数？',{counts:{a:18,b:14,o:5},answer:27,explain:'18＋14−5＝27。'}),
  F('测','formula','绘画 12 人、音乐 11 人、两项都参加 4 人。拼出参加至少一项的人数。',{counts:{a:12,b:11,o:4},allowed:['A','B','O','R','Y'],minTerms:2,maxTerms:4,explain:'12＋11−4＝19，也可 8＋4＋7＝19。'}),
  F('测','choice','把两个完整组的人数直接加，为什么可能偏多？',{options:['共同的人被数了两次','不同的人不能相加','人数不能用减法'],answer:0,explain:'重复的人要去掉多算的一次。'})
].map((task,index)=>({...task,id:`F${String(index+1).padStart(2,'0')}`}));
if(typeof module!=='undefined')module.exports={PEOPLE,FRUIT_TASKS};
