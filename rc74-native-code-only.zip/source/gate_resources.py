"""Admission and retry policy; pure helpers are exercised without waiting."""
import os, pathlib, random

MIB=1024**2

def snapshot(proc=pathlib.Path('/proc'),cgroup=pathlib.Path('/sys/fs/cgroup')):
    cpus=os.cpu_count() or 1
    try:
        q,p=(cgroup/'cpu.max').read_text().split()
        if q!='max':cpus=min(cpus,max(1,(int(q)+int(p)-1)//int(p)))
    except (OSError,ValueError):pass
    available=2*1024**3;capacity=available
    try:
        data={line.split(':')[0]:int(line.split()[1])*1024 for line in (proc/'meminfo').read_text().splitlines() if line.startswith(('MemAvailable:','MemTotal:'))}
        available=data.get('MemAvailable',available);capacity=data.get('MemTotal',capacity)
    except (OSError,ValueError):pass
    current=None;limit=None
    try:
        raw=(cgroup/'memory.max').read_text().strip()
        if raw!='max':
            limit=int(raw);current=int((cgroup/'memory.current').read_text());available=min(available,max(0,limit-current));capacity=min(capacity,limit)
    except (OSError,ValueError):pass
    reserve=max(256*MIB,int(capacity*.15))
    return {'cpus':cpus,'availableBytes':available,'capacityBytes':capacity,'reserveBytes':reserve,'cgroupLimit':limit,'cgroupCurrent':current}

def task_budget(kind):
    return int(os.environ.get('AMC8_BROWSER_TASK_MIB' if kind=='browser' else 'AMC8_CPU_TASK_MIB','1536' if kind=='browser' else '768'))*MIB

def worker_limit(kind='cpu',resources=None,reserved_bytes=0):
    r=resources or snapshot()
    return max(0,min(r['cpus'],(r['availableBytes']-r['reserveBytes']-reserved_bytes)//task_budget(kind)))

def retry_delay(attempt,delays,retry_after=0,jitter=None):
    if attempt<1 or attempt>len(delays):return None
    base=max(delays[attempt-1],retry_after)
    return base+base*.2*(random.random() if jitter is None else max(0,min(1,jitter)))

def oom_kills(cgroup=pathlib.Path('/sys/fs/cgroup')):
    try:return int(dict(line.split() for line in (cgroup/'memory.events').read_text().splitlines()).get('oom_kill',0))
    except (OSError,ValueError):return None
