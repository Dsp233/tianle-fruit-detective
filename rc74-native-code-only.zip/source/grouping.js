'use strict';
const GROUPING_TASKS={
 'N01.01':{kind:'bags',total:12,divisor:3,context:'每袋3颗的果篮',prompt:'12颗水果，每3颗装一袋。点选3颗再捆成一袋，继续装；最后试下一袋，判断能不能不剩余装完。',explain:'4袋各3颗，恰好12颗，没有余数，可以完整分组。',reason:{prompt:'为什么12能被3整除？',options:['每袋3颗，装4袋后没有剩余','只要能装出一袋就行','最后一袋可以少装'],answer:0}},
 'N01.02':{kind:'remainder',total:14,divisor:3,context:'剩下的散果',prompt:'14颗每3颗装一袋。实际装尽完整袋，试下一袋，再选择最后余数；每袋数量都必须一样。',explain:'完整装4袋，共12颗，余2颗；2小于每袋的3。',reason:{prompt:'余数为什么不能是3？',options:['若还剩3颗，就能再装完整一袋','余数越大越好','余数只由袋数决定'],answer:0}},
 'N01.04':{kind:'digits',pools:[[0,1,3],[0,4,7]],rule:{tens:3},context:'组成符合限制的数卡',prompt:'十位可选0、1、3，个位可选0、4、7。摆十棒与散点，记录全部“两位数且十位是3”的数卡，不漏不重。',explain:'只有30、34、37；0不能作为两位数的十位，但可以在个位。',reason:{prompt:'为什么04不满足条件？',options:['十位是0，实际数4不是两位数','个位4不能使用','凡是两张数字卡都叫两位数'],answer:0}},
 'N01.05':{kind:'parity',totals:[8,9],divisor:2,context:'结成两人小队',prompt:'分别把8和9个小朋友两两结队。每次点两人圈成一对，试下一对，再判断奇偶。',explain:'8能全部成对，是偶数；9最后剩1，是奇数。',reason:{prompt:'奇数与偶数的配对差别是什么？',options:['偶数全部成对，奇数剩1','奇数最后能剩2','看起来多的数一定是偶数'],answer:0}}
};
for(const [skillId,t] of Object.entries(GROUPING_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:31,mode:'groupingLab',phase:'练',hint:'每组必须装相同数量；最后剩下的要少于一整组。数位限制要逐个位置核对。'});
const groupingDigitRules=typeof module!=='undefined'?require('./divisibility'):{DIGIT_RULE_MODELS,digitRuleInstance};
GROUPING_TASKS['N01.03']=groupingDigitRules.digitRuleInstance(groupingDigitRules.DIGIT_RULE_MODELS.practice,'O-N01-03-1','练');
if(typeof module!=='undefined')module.exports={GROUPING_TASKS};
