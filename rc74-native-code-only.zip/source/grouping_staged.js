'use strict';
const stagedDigitRules=typeof module!=='undefined'?require('./divisibility'):{DIGIT_RULE_MODELS,digitRuleInstance};
const GROUPING_CASES={
 'N01.01':[
  [{kind:'bags',total:14,divisor:4,context:'每盒4枚的徽章'},'14枚徽章每盒4枚。实际装尽完整盒，试下一盒，判断能否没有剩余。','只能装3盒，余2，所以不能整除。','从可整除改为有余，完整盒数不能证明全装完'],
  [{kind:'bags',total:15,divisor:5,context:'五人小队'},'15人每5人一队。独立分队、试末组并判断是否全部成队。','3队恰好分完。','无提示：每组5'],
  [{kind:'bags',total:18,divisor:4,context:'四颗一串的珠子'},'18颗每4颗一串。隔日圈完整串，判断能否没有剩余。','4串余2，不能整除。','隔日：剩余不能并进不完整串'],
  [{kind:'bags',total:16,divisor:4,context:'方块装盒'},'16块每盒4块。独立装尽完整盒并检查剩余。','4盒，无剩余。','备用：总量与组量同时改变']
 ],
 'N01.02':[
  [{kind:'remainder',total:14,divisor:4,context:'四格的盒彩笔'},'14支笔每4支装盒。实际装满所有完整盒，试下一盒，再选择余数。','3盒余2；余数2小于4。','每组由3改4，不能沿用旧袋数'],
  [{kind:'remainder',total:12,divisor:4,context:'没有散点的盒子'},'12枚每4枚一盒。独立装尽完整盒，并选择最后余数。','余0；整除时余数可以为0。','无提示：余数为0的边界'],
  [{kind:'remainder',total:17,divisor:5,context:'五枚一袋'},'17枚每5枚装袋。隔日装尽完整袋，检查并选择余数。','3袋余2。','隔日：每组5'],
  [{kind:'remainder',total:11,divisor:3,context:'三枚小包'},'11枚每包3枚，独立装包并选余数。','3包余2。','备用：较小总量']
 ],
 'N01.04':[
  [{kind:'digits',pools:[[0,1,4],[2,5]],rule:{ones:2},context:'个位限制的数卡'},'十位可选0、1、4，个位可选2、5。用材料记录全部“两位数且个位是2”的数卡。','只有12、42；02实际是2。','限制由十位改个位，仍需排除前导0'],
  [{kind:'digits',pools:[[0,2,5],[0,5,8]],rule:{tens:2},context:'新的十位材料'},'独立记录全部两位数且十位为2的数卡，材料按盘中给定。','20、25、28。','无提示：个位0允许使用'],
  [{kind:'digits',pools:[[0,1,4],[0,1,4]],rule:{tens:4,different:true},context:'不重复数字限制'},'隔日组成全部两位数，要求十位4、两位数字不同；只用盘中材料。','40、41；44因重复数字不合条件。','隔日：同时增加数字不重复条件'],
  [{kind:'digits',pools:[[0,2,3],[2,3]],rule:{ones:3,different:true},context:'双重数位条件'},'独立记录全部“两位数、个位3、两位数字不同”的数卡。','只有23；03不是两位数，33重复。','备用：两项限制交叠']
 ],
 'N01.05':[
  [{kind:'parity',totals:[10,11],parts:[[4,6],[5,6]],divisor:2,context:'两班合队'},'两盘分别是4人与6人合在一起、5人与6人合在一起。跨颜色两两结队，试末对，再判断合计奇偶。','4＋6＝10全部成对；5＋6＝11剩1。','单一数量改为两部分合计，可跨颜色配对'],
  [{kind:'parity',totals:[7,10],divisor:2,context:'舞伴人数'},'分别给7人与10人找两人舞伴，独立配对并判断奇偶。','7剩1为奇，10成对为偶。','无提示：奇数放在第一盘'],
  [{kind:'parity',totals:[11,12],divisor:2,context:'隔日组队'},'隔日把11人与12人分别两两组队，再分类。','11奇、12偶。','隔日：相邻两个数量'],
  [{kind:'parity',totals:[15,16],divisor:2,context:'大一点的小队'},'独立把15和16两盘全部试着配对，判断奇偶。','15剩1、16无余。','备用：较大数量']
 ]
};
const groupingStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
GROUPING_CASES['N01.03']=['transfer','independent','delayed','independent2'].map((kind,i)=>{
 const t=stagedDigitRules.digitRuleInstance(stagedDigitRules.DIGIT_RULE_MODELS[kind],`T-N01-03-${i+1}`,kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',kind==='transfer'?'两位改含零的三位数；分别用2/3/5规则，不混淆个位与数位和':'新数卡独立判别2/3/5');
 return [t,t.prompt,t.explain,t.changeDimension];
});
for(const [skillId,cases] of Object.entries(GROUPING_CASES)){
 if(cases.length!==4)throw Error('Four N01 cases required: '+skillId);groupingStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];groupingStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:32,mode:'groupingLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'按新的组量或数位限制重做模型；余数必须少于完整一组。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={GROUPING_CASES};
