"""Import prior book page leads as unverified search hints, never as citations."""
import argparse
import csv
import re
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prior-map', required=True, type=Path)
    args = parser.parse_args()
    text = args.prior_map.read_text(encoding='utf-8')
    leads = {}
    for line in text.splitlines():
        match = re.match(r'^\| \*\*([ARLNGCDS]\d{2})\b', line)
        if not match:
            continue
        code = match.group(1)
        if code in leads:
            raise ValueError(f'Duplicate prior map entry: {code}')
        cell = line.split('|')[1]
        pages = re.findall(r'(?:M|F) p\.\s*\d+(?:[–-]\d+)?', cell)
        leads[code] = '; '.join(pages) if pages else '旧对照未列特定页'
    if len(leads) != 33:
        raise ValueError(f'Expected 33 prior rows, got {len(leads)}')
    target = Path(__file__).resolve().parent.parent / 'docs' / 'source-map.csv'
    with target.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)
        names = reader.fieldnames
    if len(rows) != 179:
        raise ValueError('Expected 179 planned skill rows')
    column = '旧版双书对照页码线索（未核原页）'
    if column in names:
        raise ValueError('Already imported; preserve subsequent manual review')
    names.append(column)
    for row in rows:
        row[column] = leads[row['单元']]
    with target.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=names, lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)
    print('Imported page leads for 33 units / 179 planned skills; all remain unverified')


if __name__ == '__main__':
    main()
