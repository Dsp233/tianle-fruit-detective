#!/usr/bin/env python3
"""Import reviewed source methods without promoting content/device acceptance."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / 'docs/evidence/2026-10-03-m3-source/book-review.json'
SUPPLEMENT = ROOT / 'docs/evidence/2026-10-04-m3-source/supplement.json'
TARGET = ROOT / 'docs/evidence/2026-10-04-m3-source/book-review.json'
EVIDENCE = TARGET.relative_to(ROOT).as_posix()

def read_json(path):
    return json.loads(path.read_text())

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        return reader.fieldnames, list(reader)

def write_csv(path, fields, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fields)
        writer.writeheader()
        writer.writerows(rows)

skills_doc = read_json(ROOT / 'source/skills.json')
skills = skills_doc['skills']
skill_ids = [s['id'] for s in skills]
old = read_json(OLD)
supplement = read_json(SUPPLEMENT)
rows = supplement['rows']
assert len(rows) == 107 and len({r['skillId'] for r in rows}) == 107
refs = {r['id']: dict(r) for r in old['references']}
assert len(refs) == 144
for row in rows:
    sid = row['skillId']
    assert sid in skill_ids
    for prefix, key, book in [('M', 'mastering', 'Mastering_AMC_8_Book.pdf'),
                              ('F', 'formulas', 'The_Book_of_Math_Formulas_and_Strategies.pdf')]:
        ref_id = 'SRC-' + prefix + '-' + sid
        assert ref_id not in refs, 'new review must not replace old evidence: ' + ref_id
        source = row[key]
        refs[ref_id] = dict(id=ref_id, skillId=sid, book=book,
            pdfPages=source['pdfPages'], coverage=source['coverage'],
            methodAndConditions=row['methodAndConditions'], limitations=row['limitations'],
            taskId='T-' + sid.replace('.', '-') + '-1',
            originalOrAdapted='原书数学方法与原创儿童适配分开登记',
            reviewStatus='2026-10-04原页文字/公式与全文索引核对；图形未视觉审核除非另行记录',
            figureReviewed=row['figureReviewed'])
for change in supplement['amendments']:
    rid = change['referenceId']
    assert rid in refs
    refs[rid].update({k: v for k, v in change.items() if k != 'referenceId'})
    refs[rid]['amendmentEvidence'] = SUPPLEMENT.relative_to(ROOT).as_posix()
assert len(refs) == 358
assert {r['skillId'] for r in refs.values()} == set(skill_ids)
for s in skills:
    pair = ['SRC-M-' + s['id'], 'SRC-F-' + s['id']]
    s['bookReferences'] = pair
    s['sourceReferenceIds'] = pair
    s['sourceStatus'] = '双书定位已记录；覆盖、原创适配与检索边界分开；完整教学/图形/设备待验'
    for rid in pair:
        assert refs[rid]['taskId'] in s['taskIds']
        assert all(isinstance(p, int) and p > 0 for p in refs[rid]['pdfPages'])
        assert refs[rid]['methodAndConditions'] and refs[rid]['limitations']
combined = dict(old)
combined.update(reviewedAt='2026-10-04', reviewedSkills=179,
    scope='179技能、358条双书来源文字/公式与全文索引定位；不等于179完整教学、原图、500真题或设备验收',
    references=[refs['SRC-' + p + '-' + sid] for sid in skill_ids for p in ('M', 'F')],
    sourceErrata=old.get('sourceErrata', []) + supplement['sourceErrata'],
    supplementEvidence=SUPPLEMENT.relative_to(ROOT).as_posix(),
    noDirectLimit='未发现直接覆盖只限已核全文文字索引和所列相关原页，未排除未读图片；空页码不代表书内绝对不存在。')
source_path = ROOT / 'docs/source-map.csv'
fields, source_rows = read_csv(source_path)
assert {r['微技能ID'] for r in source_rows} == set(skill_ids)
for row in source_rows:
    sid = row['微技能ID']
    m, f = (refs['SRC-' + p + '-' + sid] for p in ('M', 'F'))
    def page_label(ref):
        return 'PDF ' + (','.join(map(str, ref['pdfPages'])) if ref['pdfPages'] else '未确认直接页') + '；' + ref['coverage']
    row['M书页及覆盖'] = page_label(m)
    row['F书页及覆盖'] = page_label(f)
    row['参考书检索起点'] = 'M ' + page_label(m) + ' / F ' + page_label(f)
    row['对应方法与适用条件'] = '；'.join(dict.fromkeys([m['methodAndConditions'], f['methodAndConditions']]))
    row['儿童适配与局限'] = '；'.join(dict.fromkeys([m['limitations'], f['limitations']]))
    row['原页逐项核实'] = '文字/公式与检索边界已记录；原图按逐条figureReviewed实际状态'
    row['来源证据路径'] = EVIDENCE
    row['状态'] = '进行中（双书定位已记录；完整教学/真题对应/设备待验）'
matrix_path = ROOT / 'docs/unit-skill-matrix.csv'
matrix_fields, matrix_rows = read_csv(matrix_path)
preserved = {r['微技能ID']: (r.get('浏览器证据'), r.get('iPad真机证据'), r.get('真题证据')) for r in matrix_rows}
for row in matrix_rows:
    evidence = '；'.join(['SRC-M-' + row['微技能ID'], 'SRC-F-' + row['微技能ID'], EVIDENCE])
    current = row.get('教材证据', '')
    if EVIDENCE not in current:
        row['教材证据'] = (current + '；' if current else '') + evidence
assert all((r.get('浏览器证据'), r.get('iPad真机证据'), r.get('真题证据')) == preserved[r['微技能ID']] for r in matrix_rows)
write_json(TARGET, combined)
write_json(ROOT / 'source/skills.json', skills_doc)
write_csv(source_path, fields, source_rows)
write_csv(matrix_path, matrix_fields, matrix_rows)
counts = {}
for ref in combined['references']:
    counts[ref['coverage']] = counts.get(ref['coverage'], 0) + 1
print(json.dumps(dict(reviewedSkills=179, references=358, coverage=counts, deviceEvidencePreserved=True,
    evidence=EVIDENCE), ensure_ascii=False))
