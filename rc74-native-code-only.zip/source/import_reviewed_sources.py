"""Import reviewed source facts; never manufacture original-exam matches."""
import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parent
evidence = root.parent / 'docs/evidence/2026-10-03-m3-source/book-review.json'
review = json.loads(evidence.read_text())
by_skill = {}
for reference in review['references']:
    by_skill.setdefault(reference['skillId'], []).append(reference)
skills_path = root / 'skills.json'
skills = json.loads(skills_path.read_text())
for skill in skills['skills']:
    if skill['id'] in by_skill:
        skill['bookReferences'] = [r['id'] for r in by_skill[skill['id']]]
        skill['sourceReferenceIds'] = skill['bookReferences'][:]
        skill['sourceStatus'] = '定位已核；适配与未发现直接覆盖按边界记录'
skills_path.write_text(json.dumps(skills, ensure_ascii=False, indent=2) + '\n')
path = root.parent / 'docs/source-map.csv'
with path.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    fields, rows = list(reader.fieldnames), list(reader)
for field in ['M书页及覆盖', 'F书页及覆盖', '儿童适配与局限', '来源证据路径']:
    if field not in fields:
        fields.append(field)
for row in rows:
    refs = by_skill.get(row['微技能ID'])
    if not refs:
        continue
    for ref in refs:
        label = 'M' if ref['id'].startswith('SRC-M') else 'F'
        row[label + '书页及覆盖'] = f"PDF {ref['pdfPages'] or '未确认直接页'}；{ref['coverage']}"
    row['对应方法与适用条件'] = refs[0]['methodAndConditions']
    row['儿童适配与局限'] = refs[0]['limitations']
    row['原页逐项核实'] = '本批定位核对已记录；未发现直接覆盖按检索边界报告'
    row['来源证据路径'] = 'docs/evidence/2026-10-03-m3-source/book-review.json'
    row['状态'] = '进行中（来源定位已记录；完整教学/真题对应/设备仍待验）'
with path.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=fields, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
print(f"Imported {len(by_skill)} reviewed dual-book mappings; exam ledger unchanged.")
