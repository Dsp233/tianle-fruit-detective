'use strict';
const INTEGER_TASKS={
 'A05.01':{kind:'position',start:0,target:-3,context:'温度计',prompt:'以0℃为界，沿刻度向下走到零下3℃。标记实际落在哪里？',explain:'从0向下走3格到−3；负号表示在零以下。',reason:{prompt:'为什么标在−3？',options:['零下3在0的下方三格','−3在0的上方三格','0也是负数'],answer:0}},
 'A05.02':{kind:'compare',left:-4,right:2,target:2,context:'东西方向',prompt:'把−4和＋2都标在数轴上，选出较大的位置。',explain:'＋2在−4右侧，所以＋2较大。',reason:{prompt:'为什么＋2较大？',options:['数轴右边的数较大','带负号的数一定比较大','−4离0更远所以较大'],answer:0}},
 'A05.03':{kind:'walk',start:-2,target:3,context:'升降电梯',prompt:'电梯从地下2层（−2）出发，每次上升一层，逐步走到3层。',explain:'−2→−1→0→1→2→3，共走5步，经过0。',reason:{prompt:'为什么走5层？',options:['从−2到0走2层，再从0到3走3层','3－2＝1层','从−2到3向下走5层'],answer:0}},
 'A05.04':{kind:'square',side:4,target:16,context:'铺地砖',prompt:'正方形每边4块方砖。逐行添砖到4行，数一数总面积。',explain:'4行，每行4格，共4×4＝16格。',reason:{prompt:'为什么是16格？',options:['每行4格，共4行','只数四条边所以是4格','两边相加是8格'],answer:0}},
 'A05.05':{kind:'root',target:25,side:5,context:'方形花圃',prompt:'面积25格的正方形花圃，逐层扩成正方形，找正的边长。',explain:'5行，每行5格得25格；边长取正数5。',reason:{prompt:'为什么边长是5？',options:['5×5＝25，长度取正值','−5是可以量出的负长度','边长等于面积25'],answer:0}},
 'A05.06':{kind:'power',base:2,exponent:4,target:16,context:'折纸翻倍',prompt:'从1张纸起，每轮变成原来的2倍。逐轮操作4轮，读出2⁴的结果。',explain:'1→2→4→8→16；2⁴是四个2相乘。',reason:{prompt:'为什么结果是16？',options:['连续四次乘2得到16','2乘4等于8，所以指数是8','四次加2从1开始得9'],answer:0}}
};
for(const [skillId,t] of Object.entries(INTEGER_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:13,mode:'integerLab',phase:'练',hint:'用刻度或方格逐步操作，再用自己的话说数量关系。'});
if(typeof module!=='undefined')module.exports={INTEGER_TASKS};
