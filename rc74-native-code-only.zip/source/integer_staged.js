'use strict';
// Each row changes context, representation, unknown or condition; the last is a fresh fallback after a missed first answer.
const INTEGER_CASES={
 'A05.01':[
  [{kind:'position',start:0,target:-2,context:'潜水深度'},'海面为0，潜水员下潜2格，在垂直刻度标出深度。','从0向下两格到−2。','温度改水深'],
  [{kind:'position',start:0,target:4,context:'海拔'},'海拔0为起点，向上移动4格，在刻度上标高度。','从0向上四格到＋4。','负方向换正方向'],
  [{kind:'position',start:0,target:-5,context:'地下停车层'},'地面为0，向下移动5层，在垂直刻度标位置。','从0向下五格到−5。','楼层与新距离'],
  [{kind:'position',start:0,target:3,context:'气温'},'气温从0升到零上3℃，逐格移动标记。','从0向上三格到＋3。','气温正方向新实例']
 ],
 'A05.02':[
  [{kind:'compare',left:-2,right:-5,target:-2,context:'气温'},'标出−2℃与−5℃，比较哪一天温度更高。','−2在−5右侧。','两数均为负'],
  [{kind:'compare',left:0,right:-3,target:0,context:'楼层'},'把地面0层与地下3层标出，选较高楼层。','0在−3右侧。','引入0'],
  [{kind:'compare',left:4,right:-1,target:4,context:'海拔'},'在水平数轴标出＋4和−1，选较大的海拔数。','4在−1右侧。','交换左右顺序'],
  [{kind:'compare',left:-6,right:-4,target:-4,context:'气温'},'在数轴标出−6与−4，选较高气温。','−4在−6右侧。','两个负数新实例']
 ],
 'A05.03':[
  [{kind:'walk',start:-3,target:2,context:'游戏棋'},'棋子从−3向右走到2，逐格移动并数跨过0的步数。','−3到0有3步，0到2有2步，共5步。','从电梯换棋盘'],
  [{kind:'walk',start:2,target:-2,context:'温度'},'温度从＋2逐格下降到−2，数一数一共下降几格。','2到0有2格，0到−2有2格，共4格。','上升改下降'],
  [{kind:'walk',start:-4,target:1,context:'海拔'},'从海拔−4逐格上升到＋1，走过0并数步。','−4到0有4步，0到1有1步，共5步。','更远的负起点'],
  [{kind:'walk',start:3,target:-1,context:'棋盘'},'棋子从＋3逐格向左走到−1，数经过0的步数。','3到0有3步，0到−1有1步，共4步。','从正到负的新实例']
 ],
 'A05.04':[
  [{kind:'square',side:3,target:9,context:'方形窗格'},'每边3格的方窗，逐行搭好正方形再数格数。','3行每行3格，共9格。','砖换窗格与边长'],
  [{kind:'square',side:5,target:25,context:'方形棋盘'},'每边5格的棋盘，逐行铺好后求面积。','5×5＝25格。','增大边长'],
  [{kind:'square',side:2,target:4,context:'方形瓷砖'},'每边2块小砖，逐行铺正方形求面积。','2×2＝4块。','较小正方形新实例'],
  [{kind:'square',side:6,target:36,context:'方形贴纸'},'每边6张贴纸，逐行搭好并数总张数。','6×6＝36张。','六行六列新实例']
 ],
 'A05.05':[
  [{kind:'root',side:4,target:16,context:'方形桌面'},'方形桌面面积16格，从1×1逐层长大，找到正边长。','4×4＝16，边长4。','花圃换桌面'],
  [{kind:'root',side:3,target:9,context:'方形棋盘'},'面积9格的方棋盘，逐层扩正方形并读边长。','3×3＝9，边长3。','面积变小'],
  [{kind:'root',side:6,target:36,context:'方形地毯'},'面积36格的方毯，逐层扩成正方形找正边长。','6×6＝36，边长6。','面积增大'],
  [{kind:'root',side:2,target:4,context:'方形花坛'},'面积4格的方花坛，逐层扩成正方形找边长。','2×2＝4，边长2。','面积4的新实例']
 ],
 'A05.06':[
  [{kind:'power',base:3,exponent:2,target:9,context:'复制图案'},'从1个图案开始，每轮复制成原来的3倍，操作两轮。','1→3→9，是3²。','底数改3次数改2'],
  [{kind:'power',base:2,exponent:5,target:32,context:'折纸'},'从1个图案开始，每轮翻倍，操作五轮求2⁵。','1→2→4→8→16→32。','指数改5'],
  [{kind:'power',base:4,exponent:2,target:16,context:'卡片复制'},'从1张卡片开始，每轮复制成4倍，两轮后读4²。','1→4→16。','底数4与平方'],
  [{kind:'power',base:3,exponent:3,target:27,context:'种子分叉'},'每轮一变三，从1颗开始操作三轮求3³。','1→3→9→27。','底数指数都换的新实例']
 ]
};
const integerStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(INTEGER_CASES)){
 if(cases.length!==4)throw Error('Four A05 cases required: '+skillId);
 integerStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];
  integerStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:14,mode:'integerLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先画出起点或搭出第一行，再逐步改变模型。'}:{})};
 }
}
for(const tasks of Object.values(integerStageTarget))for(const t of Object.values(tasks))if(['测','巩固'].includes(t.phase)&&['square','root','power'].includes(t.kind))t.contentVersion=70;
if(typeof module!=='undefined')module.exports={INTEGER_CASES};
