'use strict';
function invariantCards(colors,rule,minOps=2,extra={}){return {coins:colors.map((color,i)=>({id:'C'+(i+1),color})),rule,minOps,...extra}}
function invariantFilter(items,conditions){return {items,conditions:conditions.map((c,i)=>({id:'K'+(i+1),...c}))}}
const INVARIANT_TASKS={
 'S02.01':{kind:'filter',...invariantFilter(['A','B','C'],[{type:'before',a:'A',b:'B',label:'A在B之前'},{type:'notSlot',a:'C',slot:1,label:'C不在中间'}]),prompt:'亲手摆三张原人卡，列全六种队列。每种分别判断保留或剔除；剔除时标出所有违反的条件，找到满足全部条件的队列。',explain:'ABC和CAB满足；只满足一个条件仍不合题意。逐候选六种审查证明列全。'},
 'S02.02':{kind:'parity',...invariantCards(['红','红','红','蓝','蓝','蓝'],'flipPair',3),prompt:'每次必须翻不同的两张红蓝卡。实际做3次合法翻转，然后把初态与终态的红卡各亲手圈成两两配对，剩1张则单列，判断两态奇偶。',explain:'红数变化只可能−2、0、＋2，原来奇数仍奇数；多少次都不能只翻一张。'},
 'S02.03':{kind:'legal',...invariantCards(['红','蓝','红','蓝'],'adjacentFlip',0,{attempts:[['C1','C2'],['C1','C3'],['C2','C3']]}),prompt:'规则是每次只翻位置相邻的两张卡。按给定顺序亲手选择C1/C2、C1/C3、C2/C3；先判断是否合法再实际试操作，观察非法选择不改变状态。',explain:'相邻二卡能翻；C1/C3隔位不合法，不能因按钮按了就算执行规则。'},
 'S02.04':{kind:'invariant',...invariantCards(['红','红','红','蓝','蓝','蓝'],'flipPair',3),prompt:'实际做3次不同双卡翻转，至少展示一次红数变化。逐次填总卡数、红数和红数奇偶；再操作三种局部颜色配对，记录变化量，选择对所有合法操作成立的不变量。',explain:'总卡数不变，红数奇偶不变；红数本身可变。两红→−2、一红一蓝→0、两蓝→＋2穷尽局部情形。'},
 'S02.05':{kind:'proof',...invariantCards(['红','蓝','蓝','蓝'],'flipPair',2,{goal:['红','红','蓝','蓝']}),prompt:'初态1红3蓝，目标位置为红红蓝蓝；每次翻两张不同卡。先实际尝试至少2次并记录状态，再判断可达否。不可达必须用覆盖全部局部情形的不变量证明，不能以一次失败作证。',explain:'初红数奇、目标偶；每次变化−2/0/＋2保留奇偶，所以不可达。尝试失败只是探索，不是证明。'}
};
for(const [skillId,t] of Object.entries(INVARIANT_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,mode:'invariantLab',contentVersion:65,phase:'练',context:'全部条件、合法状态与通用证据',hint:'只移动原卡、只执行题定规则。逐状态计数，再穷尽一次操作的颜色类型证明保存量；不可达要对所有合法步骤成立。',reason:{prompt:'怎样让筛选或不可达结论有完整依据？',options:['候选覆盖全部条件；每次合法操作的局部类型已穷尽，守恒量初态与目标矛盾才证明不可达；可达则给实际合法路径','一条条件满足即可保留，不用看其他条件','自己一次没做成就证明不可能'],answer:0}});
if(typeof module!=='undefined')module.exports={INVARIANT_TASKS,invariantCards,invariantFilter};
