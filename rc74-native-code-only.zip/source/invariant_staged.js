'use strict';
const invariantFactory=typeof module!=='undefined'?require('./invariant'):{invariantCards,invariantFilter},ic=invariantFactory.invariantCards,ifil=invariantFactory.invariantFilter;
const INVARIANT_CASES={
 'S02.01':[
  [ifil(['1','2','3'],[{type:'slotOdd',slot:0,label:'第一位为奇数'},{type:'before',a:'1',b:'3',label:'1在3之前'}]),'摆原数卡列全六个不重复三位编码，第一位奇数且1在3前；每项保留/剔除并圈全部违规条件。','123、132同时满足。','人物条件改数位奇偶与前后关系'],
  [ifil(['A','B','C'],[{type:'fixed',a:'B',slot:1,label:'B在中间'},{type:'before',a:'A',b:'C',label:'A在C前'}]),'独立列全三人队列，B中间且A在C前，逐项核查全部条件。','只有ABC。','无提示：固定位置与前后关系'],
  [ifil(['A','B','C'],[{type:'notSlot',a:'A',slot:1,label:'A不在中间'},{type:'before',a:'B',b:'C',label:'B在C前'},{type:'notSlot',a:'C',slot:0,label:'C不在首位'}]),'隔日列全并筛选三条件；剔除时所有违反条件均须标出。','ABC、BCA满足。','隔日：三条件同时作用'],
  [ifil(['A','B','C'],[{type:'adjacent',a:'A',b:'C',label:'A与C相邻'},{type:'notSlot',a:'B',slot:0,label:'B不在第一位'}]),'独立列全、逐项筛满足相邻及首位限制的队列。','ACB、CAB。','备用：相邻与否定条件']
 ],
 'S02.02':[
  [ic(['红','红','蓝','蓝'],'flipPair',2),'先实际翻双卡两次，再把初终红卡各圈成对，判断奇偶。','偶数仍偶数。','初态由奇数改偶数'],
  [ic(['红','蓝','蓝','蓝','蓝'],'flipPair',3),'独立翻不同双卡三次，再对初终红卡配对并判奇偶。','奇数仍奇数，剩1张。','无提示：五卡与单红初态'],
  [ic(['红','蓝','红','蓝'],'adjacentFlip',2),'隔日仅许翻相邻双卡，执行两次并给初终红卡配对判奇偶。','合法限制变严但仍每次翻二卡，偶数保持。','隔日：合法邻接限制变化'],
  [ic(['蓝','蓝','蓝','蓝'],'flipPair',1),'独立全蓝初态翻两卡一次，对初终红卡配对判奇偶，空红组要明确标无剩余。','初0红偶，终2红偶。','备用：零红边界']
 ],
 'S02.03':[
  [ic(['红','蓝','蓝','红'],'swapAdjacent',0,{attempts:[['C1','C2'],['C2','C4'],['C1','C3']]}),'本轮只能交换相邻位置的两张原卡，按C1/C2、C2/C4、C1/C3顺序判断并试；身份位置真的交换。','合法按当前实际位置判断，非法不动原卡。','翻色改移动交换身份'],
  [ic(['红','蓝','蓝'],'flipOne',0,{attempts:[['C1'],['C1','C2'],['C3']]}),'独立规则改为每次只翻一张，按给定单卡/双卡/单卡先判断再试。','双卡选择不符合只翻一张，状态不改变。','无提示：操作张数限制变化'],
  [ic(['红','红','蓝','蓝'],'adjacentFlip',0,{attempts:[['C1','C4'],['C2','C3'],['C1','C2']]}),'隔日按给定三组先判断再实际试，只有位置相邻的双卡能翻。','首末不相邻，中间及前两位相邻。','隔日：位置边界与不同非法对'],
  [ic(['红','蓝','红'],'swapAdjacent',0,{attempts:[['C1','C3'],['C2','C3'],['C1','C3']]}),'独立交换相邻原卡，按固定序试三组；后一次必须按已经改变的位置判断。','第一次C1/C3非法；交换C2/C3后C1/C3变相邻合法。','备用：位置改变使同编号对合法性改变']
 ],
 'S02.04':[
  [ic(['红','蓝','红','蓝'],'swapAdjacent',2),'实际交换相邻原卡两次，记录三状态，穷尽局部交换颜色类型后选择保存量。','总数、红数、红数奇偶都不变。','翻色改交换：红数也成为不变量'],
  [ic(['红','红','蓝','蓝'],'flipPair',2),'独立做双卡翻转并展示红数改变，填状态表，操作全部局部配对并选不变量。','总数与红数奇偶保存，红数不保存。','无提示：偶初态与反例见证'],
  [ic(['红','蓝','蓝'],'flipOne',3),'隔日每次只翻一张，填各状态，操作红/蓝两种局部情形后重新选择不变量。','总数保存；红数和红数奇偶都可变。','隔日：错误奇偶不变量被新规则反例推翻'],
  [ic(['红','红','蓝','蓝'],'adjacentFlip',2),'独立仅翻相邻双卡，展示红数变化，记录状态并穷尽局部颜色类型选保存量。','总数与红数奇偶保存。','备用：邻接限制下的全局守恒']
 ],
 'S02.05':[
  [ic(['红','蓝','蓝','蓝'],'flipPair',1,{goal:['蓝','红','蓝','蓝']}),'目标改为蓝红蓝蓝。亲手给合法路径并记录每步，判断可达并用实际路径作证。','翻C1/C2一步可达；同奇偶本身不是路径证据。','不可达目标改可达，必须构造路径'],
  [ic(['红','红','蓝','蓝'],'flipPair',2,{goal:['红','红','红','蓝']}),'独立尝试并记录，再用穷尽操作情形的不变量证明目标可达否。','初红偶、目标红奇，双翻保留奇偶，故不可达。','无提示：初偶目标奇'],
  [ic(['红','蓝','蓝','蓝'],'swapAdjacent',2,{goal:['红','红','红','蓝']}),'隔日规则改只交换相邻原卡，目标红红红蓝；先尝试再完整论证。','奇偶同为奇不足判断；原红数1保存、目标3，故不可达。','隔日：相同奇偶仍因更强计数不变量不可达'],
  [ic(['红','蓝','蓝','蓝'],'swapAdjacent',1,{goal:['蓝','蓝','蓝','红']}),'独立只许相邻交换，把红卡移到最右，提供实际合法路径及状态表。','连续把同一原红卡右移三次可达。','备用：移动原身份的多步可达路径']
 ]
};
const invariantSource=typeof module!=='undefined'?require('./invariant').INVARIANT_TASKS:INVARIANT_TASKS,invariantTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(INVARIANT_CASES)){invariantTarget[skillId]={};for(const [i,stage] of ['transfer','independent','delayed','independent2'].entries()){const [params,prompt,explain,changeDimension]=cases[i];invariantTarget[skillId][stage]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,mode:'invariantLab',kind:invariantSource[skillId].kind,contentVersion:66,phase:stage==='transfer'?'迁移':stage==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,context:'合法变化与不可达的完整依据',...(stage==='transfer'?{hint:'逐条件/逐状态核对，穷尽局部操作类型；可达要构造路径，不可达用真正保存量与目标矛盾。'}:{})}}}
if(typeof module!=='undefined')module.exports={INVARIANT_CASES};
