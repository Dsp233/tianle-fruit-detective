'use strict';
function jointLFamily(t){return t.joint.binding.startsWith('l-')}
function jointLQuantity(t){
 if(t.joint.binding!=='l-bag')throw Error('This logic task does not have one material quantity '+t.id);
 if(t.mode==='constraintLab')return t.bag;
 return t.kind==='inverse'?(t.unknownInitial?t.initial:t.initial-t.remain):t.total-t.known;
}
function jointLRole(t){if(t.joint.binding==='l-bag')return t.mode==='constraintLab'?'原操作实际一袋内的材料数':t.kind==='inverse'?(t.unknownInitial?'放回原对象后恢复的整体数':'原操作实际移出的材料数'):'实际未知袋中的材料数';return t.joint.quantityLabel}
const JOINT_L_OPERATORS=new Set(['pan-plan','equal-plan','stock-plan','motif-order','motif-budget','motif-stock','mosaic-bill','mosaic-budget','mosaic-offers','sequence-packs','sequence-capacity','machine-plan','grid-bill','grid-offers','travel-bill','travel-budget']);
const JOINT_L_OFFERS=new Set(['mosaic-offers','grid-offers']);
function jointLAlphabet(t){return [...new Set(t.base)]}
function jointLNewCount(t){return t.kind==='twoPrev'?t.count:2}
function jointLFields(t){const p=t.joint.params;switch(p.operator){
 case 'pan-plan':return [['left','原左盘实际总量'],['right','原右盘实际总量'],['change','指定盘计划改变量（加为正、拿走为负、不变为0）'],['cost','这次安排总金额（元）']];
 case 'equal-plan':return [['change','整批计划改变量（添入为正、取出为负）'],['perGroup','安排后每组的整数数量'],['cost','这次安排总金额（元）']];
 case 'stock-plan':return [['produce','本次最多交付的完整袋数'],['short','未完成的订单袋数'],['leftStock','交付后剩余原库存件数'],['cost','本次总金额（元）']];
 case 'motif-order':return [...jointLAlphabet(t).map((symbol,i)=>['material'+i,'新续接的'+symbol+'材料数']),['cost','新材料总金额（元）']];
 case 'motif-budget':return [['length','最多能连续续接的格数'],['left','最后剩余经费（元）']];
 case 'motif-stock':return [['length','最多能连续续接的格数'],...jointLAlphabet(t).map((symbol,i)=>['material'+i,'实际新用的'+symbol+'材料数']),['cost','实际用料金额（元）']];
 case 'mosaic-bill':case 'mosaic-budget':case 'mosaic-offers':return [['red','本次采购的红色片数'],['blue','本次采购的蓝色片数'],...(p.operator==='mosaic-offers'?[['plan','选择报价']]:[]),[p.operator==='mosaic-budget'?'left':'cost',p.operator==='mosaic-budget'?'经费剩余（元）':'总金额（元）']];
 case 'sequence-packs':return p.pool?[['boxes','合并后至少需要的箱数'],['empty','合并装箱后总空格数'],['cost','总金额（元）']]:[...Array.from({length:jointLNewCount(t)},(_,i)=>[['boxes'+i,'新第'+(i+1)+'批至少需要的箱数'],['empty'+i,'新第'+(i+1)+'批箱内空格数']]).flat(),['cost','总金额（元）']];
 case 'sequence-capacity':return [['capacity','每箱至少需要的容量'],['cost','这些箱的总金额（元）']];
 case 'machine-plan':return [['input','每轮安排的整数输入份数'],['output','全部新轮次实际产出份数'],['excess','超过需求的份数（没有时填0）'],['short','不足的份数（没有时填0）'],['cost','本次总金额（元）']];
 case 'grid-bill':case 'grid-offers':return [['horizontal','这趟路线的横向格数'],['vertical','这趟路线的纵向格数'],...(p.operator==='grid-offers'?[['plan','选择报价']]:[]),['cost','这趟总金额（元）']];
 case 'travel-bill':case 'travel-budget':return [['distance','连同题目指定返回段的实际路程格数'],[p.operator==='travel-budget'?'left':'cost',p.operator==='travel-budget'?'剩余经费（元）':'总金额（元）']];
 default:return null;
}}
function jointLText(t){const p=t.joint.params;
 if(p.operator==='pan-plan')return `用摆出的实际两盘制定新安排，不把“相等/不等”当材料数。${t.mode==='constraintLab'?'左边是实际组装出的整批，右边是原式要求的整批；':''}计划只改${p.side==='left'?'左':'右'}盘，让它${p.offset===0?'与另一盘一样多':p.offset>0?'比另一盘多'+p.offset+'颗':'比另一盘少'+(-p.offset)+'颗'}。填原两盘总量和指定盘的改变量；正数表示添入，负数表示取出，0表示不改。每处理1颗${p.unitPrice}元，另收一次${p.fee}元安排费，0颗也收安排费。总金额多少？`;
 if(p.operator==='equal-plan')return `沿用原题同一批原点和${t.divisor}组。${p.direction==='add'?'先用最少新增原点补到能够平均分完'+(p.extraEach?'，再给每组增加'+p.extraEach+'颗':''):'只取出最少原点，使留下的全部原点能平均分完'}。填整批改变量及最终每组数；添入为正、取出为负、不变填0。每处理1颗${p.unitPrice}元，另收一次${p.fee}元安排费，0颗也收；共多少元？`;
 if(p.operator==='stock-plan')return `同一库存要交付${p.demand}袋订单，每袋仍用原题${t.per}件。每交付一满袋收${p.unitPrice}元，另收一次${p.fee}元安排费${p.budget!==undefined?'，总经费上限'+p.budget+'元':''}；即使交付0袋也收安排费。只交付完整袋，数量不能超过订单、实际库存${p.budget!==undefined?'或经费上限':''}。最多交付几袋、订单还缺几袋、库存还剩几件、总额多少？`;
 if(p.operator.startsWith('motif-')){const prices=jointLAlphabet(t).map((symbol,i)=>symbol+'每格'+p.prices[i]+'元').join('、');return `沿用原串的重复规则，从整条已给原串的末尾继续，一格也不能跳过。原串用料已备好，只算新续接部分，${prices}。`+(p.operator==='motif-order'?`恰好再续${p.length}格，分别需几块各类材料，共多少元？`:p.operator==='motif-budget'?`另收一次${p.fee}元费用，含费用总共只有${p.budget}元。最多能连续续几格，剩多少元？`:`仅有${jointLAlphabet(t).map((symbol,i)=>symbol+p.stocks[i]+'块').join('、')}，不能换色或跳过下一格。最多续几格，实际各用几块，按用量计价共多少元？`)}
 if(p.operator.startsWith('mosaic-')){const scope=p.onlyAdded?'原题已给的行免费，只采购亲手补出的其他行':'包含原题已给各行的完整新图案',quote=x=>`红色每片${x.prices[0]}元、蓝色每片${x.prices[1]}元，另收一次${x.fee}元`;return `给${scope}配材料，不能改变涂出的颜色。先填本次红蓝各多少片。`+(p.operator==='mosaic-offers'?`报价A：${quote(p.plans[0])}；B：${quote(p.plans[1])}。选总额较低的报价并填总额，同价任选。`:`${quote(p)}。${p.operator==='mosaic-budget'?'从'+p.budget+'元付完剩多少？':'共多少元？'}`)}
 if(p.operator==='sequence-packs')return `把原规则亲手新生成的每项数看作一批物品，原题已给的项已经交付，不再计算。${p.pool?'把全部新批合成同一批后一次装箱':'各个新批必须分别装箱，上一批的空格不能给下一批用'}，每箱最多${p.capacity}件；要全部装下。填${p.pool?'合并后':'每个新批'}最少箱数和空格数。每箱${p.unitPrice}元，全单另收一次${p.fee}元，共多少元？`;
 if(p.operator==='sequence-capacity')return `把原规则亲手新生成的全部项各看作一批物品，只合并新批；已给的旧批不计算。要全部装进${p.containers}个相同箱，每箱至少需多少整数容量？每个箱每1格容量收${p.unitPrice}元，全部箱另收一次${p.fee}元，总金额多少？`;
 if(p.operator==='machine-plan')return `沿用实际在每张卡中检验过的同一输入输出规则。新工作每轮把输入看作原料份数、输出看作产成品份数，${p.runs}轮都用同一整数输入；规则中的附加量每轮都要计算。共需${p.demand}份产成品。${p.mode==='minimum'?'安排能满足需求的最少原料输入':'原料和经费有限，要安排可行的最多整数输入'}${p.stock!==undefined?'，新工作原料最多'+p.stock+'份':''}${p.budget!==undefined?'，新工作总经费最多'+p.budget+'元':''}。每份原料${p.unitPrice}元，全单另收一次${p.fee}元。填每轮输入、全部产出、超出/不足及总金额；没有超出或不足时分别填0。`;
 if(p.operator.startsWith('grid-')){const journey=t.kind==='move'?`先完成原移动路线，再从实际终点沿格线走到仓库(${p.depot.join(',')})`:`从仓库(${p.origin.join(',')})开始，依次按原题身份${(t.kind==='pair'?['A']:t.kind==='order'?['A','B']:t.pairs.map((_,i)=>String.fromCharCode(65+i))).join('→')}访问实际记录的点${p.return?'，最后回到同一仓库':''}`;const quote=x=>`横向每格${x.horizontalPrice}元，纵向每格${x.verticalPrice}元，另收一次${x.fee}元`;return `${journey}。每段只沿横纵格线走最短路线，横纵可先后交换；不按直线斜走，也不重排点的身份。填横向和纵向的总格数。`+(p.operator==='grid-offers'?`报价A：${quote(p.plans[0])}；B：${quote(p.plans[1])}。选择较低总额并填金额，同价任选。`:`${quote(p)}，总金额多少？`)}
 if(p.operator.startsWith('travel-'))return `原时间图记录的是位置，计费按实际走过的格数${p.returnPosition!==undefined?'，原时间段结束后还需走到位置'+p.returnPosition+'，这段也计入路程':''}，不能拿终点位置直接当路程。每走1格${p.unitPrice}元${p.minutePrice?'，原图记录的每1分钟另收'+p.minutePrice+'元；返回段不收这项时间费':''}，另收一次${p.fee}元。填总路程及${p.operator==='travel-budget'?'从'+p.budget+'元支付后剩余经费':'总金额'}。`;
 return null;
}
function jointLObserved(t,w){if(!w)return null;const p=t.joint.params,finite=n=>Number.isFinite(n),sum=a=>a.reduce((x,y)=>x+y,0);
 if(t.joint.binding==='l-pans')return t.kind==='equal'?{left:sum(w.left.map(i=>t.left[i])),right:sum(w.right.map(i=>t.right[i]))}:{left:w.bag+w.knownPlaced,right:t.total};
 if(t.joint.binding==='l-verify')return {left:t.groups*w.filled+(t.extraOutside?w.extra:t.groups*w.extra),right:t.givenTotal??constraintTotal(t)};
 if(t.joint.binding==='l-integer')return {perGroup:w.pairs,left:t.total-t.divisor*w.pairs,total:t.total};
 if(t.joint.binding==='l-stock')return {bags:t.kind==='stock'?w.bags:Number(w.choice),stock:t.stock};
 if(t.joint.binding==='l-motif'){const block=Array.from({length:3},()=>t.base).flat().slice(0,w.length);return block.length?{block,offset:t.base.length*3}:null}
 if(t.joint.binding==='l-mosaic'){const counts=[0,0];for(let r=p.onlyAdded?patternGivenRows(t):0;r<t.rows;r++)for(let c=0;c<t.cols;c++){const color=r<patternGivenRows(t)?patternColorAt(t,r,c):w.cells[r+','+c];if(color==='red')counts[0]++;if(color==='blue')counts[1]++}return {counts}}
 if(t.joint.binding==='l-sequence'){const quantities=w.terms.slice(t.initial.length);return quantities.length===jointLNewCount(t)&&quantities.every(n=>Number.isInteger(n)&&n>=0)?{quantities}:null}
 if(t.joint.binding==='l-machine'){const rule=w.rules?.at(-1);return rule&&Number.isInteger(rule.multiplier)&&rule.multiplier>0&&Number.isInteger(rule.add)&&rule.add>=0?{multiplier:rule.multiplier,add:rule.add}:null}
 if(t.joint.binding==='l-grid'||t.joint.binding==='l-trip'){let path;if(t.kind==='move')path=[...w.path,p.depot];else{const count=t.kind==='pair'?1:t.kind==='order'?2:t.pairs.length,points=Array.from({length:count},(_,i)=>w.points[i]);if(!points.every(point=>point?.length===2&&point.every(finite)))return null;path=[p.origin,...points,...(p.return?[p.origin]:[])]}return {path,horizontal:sum(path.slice(1).map((point,i)=>Math.abs(point[0]-path[i][0]))),vertical:sum(path.slice(1).map((point,i)=>Math.abs(point[1]-path[i][1])))} }
 if(t.joint.binding==='l-motion'){const values=w.trace.map(([,v])=>v),distance=sum(values.slice(1).map((v,i)=>Math.abs(v-values[i])))+(p.returnPosition!==undefined?Math.abs(values.at(-1)-p.returnPosition):0);return {distance,minutes:w.time,trace:w.trace.map(point=>[...point])}}
 return null;
}
function jointLExpected(t){const p=t.joint.params,o=jointLObserved(t,draft.work);if(!o)return null;switch(p.operator){
 case 'pan-plan':{const side=p.side==='left'?o.left:o.right,other=p.side==='left'?o.right:o.left,change=other+p.offset-side;return {...o,change,cost:Math.abs(change)*p.unitPrice+p.fee}}
 case 'equal-plan':{const perGroup=o.perGroup+(p.direction==='add'&&o.left>0?1:0)+p.extraEach,change=perGroup*t.divisor-o.total;return {change,perGroup,cost:Math.abs(change)*p.unitPrice+p.fee}}
 case 'stock-plan':{const affordable=p.budget===undefined?Infinity:Math.floor((p.budget-p.fee)/p.unitPrice),produce=Math.min(o.bags,p.demand,affordable);return {produce,short:p.demand-produce,leftStock:o.stock-produce*t.per,cost:produce*p.unitPrice+p.fee}}
 case 'motif-order':case 'motif-budget':case 'motif-stock':{const alphabet=jointLAlphabet(t),counts=alphabet.map(()=>0);let length=0,cost=0;while(length<(p.operator==='motif-order'?p.length:1000)){const index=alphabet.indexOf(o.block[(o.offset+length)%o.block.length]),price=p.prices[index];if(index<0||p.operator==='motif-budget'&&cost+price+p.fee>p.budget||p.operator==='motif-stock'&&counts[index]>=p.stocks[index])break;counts[index]++;cost+=price;length++}return {length,cost,left:p.budget-p.fee-cost,...Object.fromEntries(counts.map((n,i)=>['material'+i,n]))}}
 case 'mosaic-bill':case 'mosaic-budget':case 'mosaic-offers':{const [red,blue]=o.counts,cost=x=>red*x.prices[0]+blue*x.prices[1]+x.fee;if(p.operator==='mosaic-offers'){const values=p.plans.map(cost),min=Math.min(...values);return {red,blue,plans:p.plans.filter((_,i)=>values[i]===min).map(x=>x.id),cost:min}}return {red,blue,cost:cost(p),left:p.budget-cost(p)}}
 case 'sequence-packs':{const quantities=p.pool?[o.quantities.reduce((a,b)=>a+b,0)]:o.quantities,boxes=quantities.map(q=>Math.ceil(q/p.capacity)),empty=boxes.map((n,i)=>n*p.capacity-quantities[i]),cost=boxes.reduce((a,b)=>a+b,0)*p.unitPrice+p.fee;return p.pool?{boxes:boxes[0],empty:empty[0],cost}:{...Object.fromEntries(boxes.flatMap((n,i)=>[['boxes'+i,n],['empty'+i,empty[i]]])),cost}}
 case 'sequence-capacity':{const capacity=Math.ceil(o.quantities.reduce((a,b)=>a+b,0)/p.containers);return {capacity,cost:capacity*p.containers*p.unitPrice+p.fee}}
 case 'machine-plan':{const input=p.mode==='minimum'?Math.max(0,Math.ceil((p.demand-p.runs*o.add)/(p.runs*o.multiplier))):Math.min(Math.floor(p.stock/p.runs),Math.floor((p.budget-p.fee)/(p.runs*p.unitPrice))),output=p.runs*(input*o.multiplier+o.add);return {input,output,excess:Math.max(0,output-p.demand),short:Math.max(0,p.demand-output),cost:input*p.runs*p.unitPrice+p.fee}}
 case 'grid-bill':case 'grid-offers':{const {horizontal,vertical}=o,cost=x=>horizontal*x.horizontalPrice+vertical*x.verticalPrice+x.fee;if(p.operator==='grid-offers'){const values=p.plans.map(cost),min=Math.min(...values);return {horizontal,vertical,plans:p.plans.filter((_,i)=>values[i]===min).map(x=>x.id),cost:min}}return {horizontal,vertical,cost:cost(p)}}
 case 'travel-bill':case 'travel-budget':{const cost=o.distance*p.unitPrice+o.minutes*(p.minutePrice||0)+p.fee;return {distance:o.distance,cost,left:p.budget-cost}}
 default:throw Error('Unknown shared logic operator '+p.operator);
}}
function jointLValidate(t,base){const native=base.grade(t),expected=jointLExpected(t),answers=jointState().responses,support=!!expected&&jointReady(t)&&jointLFields(t).every(([key])=>key==='plan'?expected.plans.includes(answers.plan):jointNumber(answers[key])===expected[key]);return {ok:native.ok&&support,nativeAnchorPassed:!!native.ok,supportAnchorPassed:support,reason:!native.ok?native.reason:'核对实际两盘/分组/新批/图案身份/路线和这次安排的整数、预算、整包或费用条件。',observedErrors:[...(!native.ok?['primary-operation-condition']:[]),...(!support?['shared-condition-response']:[])]}}
function jointLGuard(t){const p=t.joint.params;if(t.joint.binding==='l-bag'){const q=jointLQuantity(t);if(!Number.isInteger(q)||q<0)throw Error('Invalid logic bag quantity '+t.id)}else if(!JOINT_L_OPERATORS.has(p.operator))throw Error('Missing logic shared operator '+t.id);if(p.operator==='machine-plan'&&(p.runs<1||p.mode==='maximum'&&(!(p.stock>=0)||!(p.budget>=p.fee))))throw Error('Invalid new machine work '+t.id)}
