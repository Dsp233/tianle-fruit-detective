'use strict';
// New goals read the child's original groups, recorded rectangles and event
// marks. Verdicts and last digits are never treated as material quantities.
function jointNFamily(t){return t.joint.binding.startsWith('n-')}
const JOINT_N_OFFERS=new Set(['frame-offers','common-pack-offers','cut-offers']);
function jointNMotif(t){return {...t,joint:{...t.joint,binding:'l-motif'}}}
function jointNRole(t){return t.joint.quantityLabel}
function jointNFields(t){const p=t.joint.params;
 if(t.joint.binding==='n-motif')return jointLFields(jointNMotif(t));
 switch(p.operator){
 case 'ship-plan':return [['bags','实际交付的满袋数'],['short','订单还缺的袋数'],['left','交付后剩余原物品数'],['cost','本次费用（元）']];
 case 'supply-plan':return [['packages','新买的完整供应包数'],['added','新增物品数'],['bags','安排后的完整组数'],['loose','安排后散点数'],['short','还缺的完整组数'],['cost','采购总金额（元）']];
 case 'digit-supply':return [...t.cases.flatMap((_,i)=>[['possible'+i,'数卡'+(i+1)+'能安排填1，不能填0'],['packages'+i,'数卡'+(i+1)+'处理的完整包数'],['change'+i,'数卡'+(i+1)+'原物品改变量（添为正，取为负）'],['cost'+i,'数卡'+(i+1)+'采购/处理费用（元）']])];
 case 'pair-plan':return [['pairs','新安排的完整二人组数'],...(p.mix?[['loose','未进入二人组的总人数']]:[['leftA','第一盘剩余人数'],['leftB','第二盘剩余人数']]),['cost','安排费用（元）']];
 case 'frame-plan':case 'frame-offers':return [...t.numbers.flatMap((_,i)=>[['possible'+i,'第'+(i+1)+'卡能做符合条件的框填1，否则0'],['width'+i,'第'+(i+1)+'卡所选框宽度'],['height'+i,'第'+(i+1)+'卡所选框高度'],['perimeter'+i,'第'+(i+1)+'卡外边总长度']]),...(JOINT_N_OFFERS.has(p.operator)?[['plan','选择报价']]:[]),['cost','所有可安排框的总金额（元）']];
 case 'event-window':return [['visits','可参加的重合次数'],['cost','这次总费用（元）']];
 case 'event-departure':return [['day','最晚出发所在日（当天0，前一天−1，次日1）'],['hour','最晚出发小时（0—23）'],['minute','最晚出发分钟（0—59）']];
 case 'common-pack-plan':case 'common-pack-offers':return [['size','本次每包相同物品数'],['red','第一盘的完整包数'],['blue','第二盘的完整包数'],...(JOINT_N_OFFERS.has(p.operator)?[['plan','选择报价']]:[]),['cost','所有包的总金额（元）']];
 case 'cut-plan':case 'cut-offers':return [['pieces','所有切出小正方形的片数'],['edge','每片的实际边长（题目长度单位）'],['border','全部分离小片外边总长度'],...(JOINT_N_OFFERS.has(p.operator)?[['plan','选择报价']]:[]),['cost','所有小片装框总金额（元）']];
 case 'paper-deadline':return [['pieces','这次要切的全部小片数'],['duration','含准备的工作分钟数'],['start','最晚开始距起点的分钟数（提前为负）']];
 case 'cycle-order':return [...[...new Set(t.base)].map((symbol,i)=>['material'+i,'新订单的'+symbol+'材料数']),['cost','新订单总金额（元）']];
 case 'calendar-plan':return [['wait','到最早可预约日还需等的天数'],['weekday','预约日编号（周一0至周日6）'],['cost','等候与安排总金额（元）']];
 case 'power-print':return [...Array.from({length:p.length},(_,i)=>['digit'+i,'新指数'+(t.target+i+1)+'的末位标签']),['labels','这次实际印出的标签张数'],['cost','标签总金额（元）']];
 default:return null;
 }}
function jointNText(t){const p=t.joint.params,quote=x=>`每1单位${x.unitPrice}元、全单另收一次${x.fee}元`;
 if(t.joint.binding==='n-motif')return jointLText(jointNMotif(t));
 switch(p.operator){
 case 'ship-plan':return `沿用实际圈出的原满袋和原散点，每袋仍是${t.divisor}个。要交付${p.demand}袋，散点不发；最多发出可完成的满袋，不超过订单${p.budget!==undefined?'和'+p.budget+'元经费':''}。每满袋${p.unitPrice}元，另收一次${p.fee}元（发0袋也收）。填交付、缺袋、交付后全部剩余原物品及总费用。`;
 case 'supply-plan':return `同一批原物品要组成${p.demand}个完整${t.divisor}人/件组，多余散点留下。只能新增，每个供应包有${p.packSize}个，不能拆包；每完整供应包${p.unitPrice}元${p.stock!==undefined?'，供应商最多提供'+p.stock+'包':''}。先尽量完成订单，能完成时只买最少包；不能完成时用全部可用包。${p.fee?'采购另收一次'+p.fee+'元，不采购不收。':'无其他费用。'}填完整供应包、新增数、最终完整组与散点、缺组及费用，不把“会剩余”的判断当数量。`;
 case 'digit-supply':return `每张数卡表示原物品的真实总数；判别小圆点只证明余数相同，不是物品总数。新安排只能${p.direction==='remove'?'取走':'添入'}完整包，每包${p.packSize}件，最多${p.stock}包，每包${p.unitPrice}元，无其他费用。分别找让原物品能按原除数分完的最少包（可以0包）。若有限范围内不能做到，明确填不能0、包数0、改变量0、费用0，表示取消该安排；能做到填1，改变量取走为负。`;
 case 'pair-plan':return `把原两盘的人安排成二人组，${p.mix?'两盘可以混合，每对任选两人':'每对必须第一盘一人、第二盘一人'}。尽量安排最多完整二人组。每组${p.unitPrice}元，另收一次${p.fee}元。填组数、${p.mix?'总剩余人数':'每个原盘各剩人数'}和费用；原盘的奇偶判断仍须用真实成对操作证明。`;
 case 'frame-plan':case 'frame-offers':return `每张原卡要给实际记录的一个整数长方阵做外框，只比较这张卡已经记录的方案（不把仅记录两个说成列出了全部）。两边至少${p.minSide}${p.squareOnly?'且必须是正方形':''}${p.maxBorder!==undefined?'，每个框另有最多'+p.maxBorder+'长度单位的边条，框之间不能合借':''}。在可行记录中选外边最短的；没有可行方案，本卡填不能0且宽、高、外边都填0，取消这张卡；有方案填1，宽高可交换。`+(p.operator==='frame-offers'?`边条报价A：${quote(p.plans[0])}；B：${quote(p.plans[1])}。比较所有可做框合计金额（有框才收一次费用；全取消费用0），选低价，同价任选。`:`边条${quote(p)}；有框才收一次费用，全取消费用0。共多少元？`);
 case 'event-window':return `沿用原表实际标出的正重合时刻，起点0不算。新工作仅能在距起点${p.after}分钟之后、${p.until}分钟及之前参加；前界不含，后界包含。每参加一次${p.unitPrice}元，另收一次${p.fee}元待命费，参加0次也收。可参加几次，共多少元？`;
 case 'event-departure':return `这次必须赶上实际标出的第一次正重合，原起点0不当下一次。起点当天为${String(Math.floor(p.origin/60)).padStart(2,'0')}:${String(p.origin%60).padStart(2,'0')}，先准备${p.prep}分钟，再走${p.walk}分钟，最晚什么时候开始准备才能准时到达？填日偏移、小时、分钟，跨午夜不可只填分钟差。`;
 case 'common-pack-plan':case 'common-pack-offers':return `原两盘物品分别全部装完，每包物品数相同，不能混盘。从你实际收录的公因数组数选择，每包${p.maxSize!==undefined?'最多'+p.maxSize+'件':'没有额外容量限制'}；先选总包数最少的方案。填每包数和两盘各包数。`+(p.operator==='common-pack-offers'?`每包报价A：${quote(p.plans[0])}；B：${quote(p.plans[1])}。比较整个订单，选低价，同价任选。`:`每包${quote(p)}，整个订单多少元？`);
 case 'cut-plan':case 'cut-offers':return `把原纸按已验证的最大正方形边长全部切开，每一小片分离后各装一个外框，所以原纸内部切线变成两个小片各自的边。实际边长按原题${t.unit||'格'}计算${t.unitSize?'，一格='+t.unitSize+t.unit:''}；不要用最后失败试铺的边长。填小片数、实际每片边长、全部小片外边总长度。`+(p.operator==='cut-offers'?`每长度单位报价A：${quote(p.plans[0])}；B：${quote(p.plans[1])}。选低价，同价任选。`:`每长度单位${quote(p)}，共多少元？`);
 case 'paper-deadline':return `这两份原材料进入同一切纸工作：按原纸已验证的最大正方形切完，每片需${p.perPiece}分钟，整次先准备${p.setup}分钟；必须在原铃声第一次正重合时刻前完成，正好完成也可以。填小片数、总分钟、最晚开始距原起点的分钟数。若要在原起点之前开始，用负数；0不当下一次铃声。`;
 case 'cycle-order':return `沿用实际走到的周期位置，${p.includeCurrent?'新订单从此位置本身':'新订单从此位置的下一格'}起，再按原顺序取${p.length}格，各格用1块同名材料。原串已备好，只买这次新订单；${[...new Set(t.base)].map((symbol,i)=>symbol+'每块'+p.prices[i]+'元').join('、')}，另收一次${p.fee}元。填各类实际新用数和总额；一整圈余0仍按原题从0/从1编号规则定位，不能换起点。`;
 case 'calendar-plan':return `先用原题实际方向走到目标星期。新预约只能从这个到达日${p.includeCurrent?'当天（等待0天可以）':'下一天（至少等1天）'}向未来找，${p.closed.map(i=>t.base[i]).join('、')}不开门，其余开门。找最早预约日。每等一天${p.unitPrice}元，另收一次${p.fee}元，等0天也收。填等待天数、星期编号（周一0到周日6）和费用；原题向过去走，不代表预约也向过去走。`;
 case 'power-print':return `原末位只作标签代码，不能当物品数量。沿用实际得出的${t.factor}的${t.target}次方末位，继续逐次乘${t.factor}，记录随后${p.length}个指数的末位；${p.onlyEven?'只给其中偶数指数':'给每个新指数'}印1张标签。标签代码0至9的每张价格依次为${p.prices.join('、')}元，全部另收一次${p.fee}元。填每个新末位、实际印的张数、金额。0次方先是1，不从正指数环的首格冒充开始。`;
 default:return null;
 }}
function jointNObserved(t,w){if(!w)return null;switch(t.joint.binding){
 case 'n-ship':case 'n-supply':return t.kind==='reconstruct'?{original:w.whole,bags:Math.floor(w.whole/t.divisor),loose:w.whole%t.divisor}:{original:t.total,bags:w.cards[0].groups.length,loose:groupingAvailable(t,0).length};
 case 'n-digitSupply':return {cards:t.cases.map((card,i)=>({original:card.number,divisor:card.divisor,remainder:w.cards[i].remainder}))};
 case 'n-pairPlan':return {originals:t.totals.map((n,i)=>({total:n,bags:w.cards[i].groups.length,loose:groupingAvailable(t,i).length}))};
 case 'n-frames':return {cards:w.cards.map(card=>({pairs:card.pairs.map(pair=>[...pair]),collected:[...card.collected],verdict:card.choice}))};
 case 'n-window':case 'n-departure':return {times:[...w.timing.selected]};
 case 'n-commonPacks':return {sizes:[...w.group.collected]};
 case 'n-cutEdges':case 'n-paperDeadline':{const paper=t.kind==='contexts'?t.paper:t,s=w.cut.selected;return Number.isInteger(s)&&s>0?{size:s,pieces:paper.dims[0]/s*paper.dims[1]/s,edge:paper.unitSize?w.cut.amount:s,times:[...w.timing.selected]}:null}
 case 'n-motif':return jointLObserved(jointNMotif(t),w);
 case 'n-cycleOrder':case 'n-calendar':return {cursor:w.cursor,base:[...t.base],choice:w.choice};
 case 'n-powerPrint':return Number.isInteger(w.choice)?{digit:w.choice,exponent:t.target,factor:t.factor}:null;
 default:return null;
 }}
function jointNExpected(t){const p=t.joint.params,o=jointNObserved(t,draft.work);if(!o)return null;const sum=a=>a.reduce((a,b)=>a+b,0),offers=(quantity,zeroFee=false)=>{const rows=p.plans.map(plan=>({plan:plan.id,cost:quantity*plan.unitPrice+(zeroFee&&quantity===0?0:plan.fee)})),cost=Math.min(...rows.map(row=>row.cost));return {plans:rows.filter(row=>row.cost===cost).map(row=>row.plan),cost}};
 if(t.joint.binding==='n-motif')return jointLExpected(jointNMotif(t));
 switch(p.operator){
 case 'ship-plan':{const affordable=p.budget===undefined?Infinity:Math.max(0,Math.floor((p.budget-p.fee)/p.unitPrice)),bags=Math.min(o.bags,p.demand,affordable);return {bags,short:p.demand-bags,left:o.original-bags*t.divisor,cost:bags*p.unitPrice+p.fee}}
 case 'supply-plan':{const needed=Math.max(0,p.demand*t.divisor-o.original),packages=Math.min(Math.ceil(needed/p.packSize),p.stock??Infinity),added=packages*p.packSize,total=o.original+added,bags=Math.floor(total/t.divisor);return {packages,added,bags,loose:total%t.divisor,short:Math.max(0,p.demand-bags),cost:packages*p.unitPrice+(packages?p.fee:0)}}
 case 'digit-supply':{const out={};for(const [i,card] of o.cards.entries()){const sign=p.direction==='remove'?-1:1;let packages=null;for(let k=0;k<=p.stock;k++){const n=card.original+sign*k*p.packSize;if(n>=0&&n%card.divisor===0){packages=k;break}}out['possible'+i]=packages===null?0:1;out['packages'+i]=packages??0;out['change'+i]=sign*(packages??0)*p.packSize;out['cost'+i]=(packages??0)*p.unitPrice}return out}
 case 'pair-plan':{const [a,b]=o.originals.map(card=>card.bags*2+card.loose),pairs=p.mix?Math.floor((a+b)/2):Math.min(a,b);return {pairs,...(p.mix?{loose:a+b-pairs*2}:{leftA:a-pairs,leftB:b-pairs}),cost:pairs*p.unitPrice+p.fee}}
 case 'frame-plan':case 'frame-offers':{const out={},alternatives=[];for(const [i,card] of o.cards.entries()){const feasible=card.pairs.filter(([a,b])=>a>=p.minSide&&b>=p.minSide&&(!p.squareOnly||a===b)&&(p.maxBorder===undefined||2*(a+b)<=p.maxBorder)),perimeter=feasible.length?Math.min(...feasible.map(([a,b])=>2*(a+b))):0,pairs=feasible.filter(([a,b])=>2*(a+b)===perimeter);alternatives.push(pairs);out['possible'+i]=pairs.length?1:0;out['width'+i]=pairs[0]?.[0]??0;out['height'+i]=pairs[0]?.[1]??0;out['perimeter'+i]=perimeter}const quantity=sum(o.cards.map((_,i)=>out['perimeter'+i]));return {...out,alternatives,...(p.operator==='frame-offers'?offers(quantity,true):{cost:quantity*p.unitPrice+(quantity?p.fee:0)})}}
 case 'event-window':{const visits=o.times.filter(time=>time>0&&time>p.after&&time<=p.until).length;return {visits,cost:visits*p.unitPrice+p.fee}}
 case 'event-departure':{const first=Math.min(...o.times.filter(time=>time>0));if(!Number.isFinite(first))return null;const absolute=p.origin+first-p.prep-p.walk,day=Math.floor(absolute/1440),clock=((absolute%1440)+1440)%1440;return {day,hour:Math.floor(clock/60),minute:clock%60}}
 case 'common-pack-plan':case 'common-pack-offers':{const sizes=o.sizes.filter(size=>p.maxSize===undefined||size<=p.maxSize);if(!sizes.length)return null;const size=Math.max(...sizes),red=t.numbers[0]/size,blue=t.numbers[1]/size,quantity=red+blue;return {size,red,blue,...(p.operator==='common-pack-offers'?offers(quantity):{cost:quantity*p.unitPrice+p.fee})}}
 case 'cut-plan':case 'cut-offers':{const border=o.pieces*4*o.edge;return {pieces:o.pieces,edge:o.edge,border,...(p.operator==='cut-offers'?offers(border):{cost:border*p.unitPrice+p.fee})}}
 case 'paper-deadline':{const first=Math.min(...o.times.filter(time=>time>0));if(!Number.isFinite(first))return null;const duration=o.pieces*p.perPiece+p.setup;return {pieces:o.pieces,duration,start:first-duration}}
 case 'cycle-order':{const alphabet=[...new Set(o.base)],counts=alphabet.map(()=>0);for(let k=0;k<p.length;k++){const index=(o.cursor+(p.includeCurrent?0:1)+k)%o.base.length;counts[alphabet.indexOf(o.base[index])]++}return {...Object.fromEntries(counts.map((n,i)=>['material'+i,n])),cost:sum(counts.map((n,i)=>n*p.prices[i]))+p.fee}}
 case 'calendar-plan':{let wait=p.includeCurrent?0:1;while(wait<=7&&p.closed.includes((o.cursor+wait)%7))wait++;if(wait>7)return null;return {wait,weekday:(o.cursor+wait)%7,cost:wait*p.unitPrice+p.fee}}
 case 'power-print':{let digit=o.digit,labels=0,cost=0;const out={};for(let i=0;i<p.length;i++){digit=digit*o.factor%10;out['digit'+i]=digit;if(!p.onlyEven||(o.exponent+i+1)%2===0){labels++;cost+=p.prices[digit]}}return {...out,labels,cost:cost+p.fee}}
 default:return null;
 }}
function jointNValidate(t,base){if(t.joint.binding==='n-motif')return jointLValidate(jointNMotif(t),base);const native=base.grade(t),expected=jointNExpected(t),answers=jointState().responses;let support=!!expected&&jointReady(t)&&jointNFields(t).every(([key])=>key==='plan'?expected.plans.includes(answers.plan):/^(width|height)\d+$/.test(key)&&pFrame(t)?true:jointNumber(answers[key])===expected[key]);if(support&&pFrame(t))support=expected.alternatives.every((pairs,i)=>{const a=jointNumber(answers['width'+i]),b=jointNumber(answers['height'+i]);return pairs.length?pairs.some(([x,y])=>a===x&&b===y||a===y&&b===x):a===0&&b===0});return {ok:native.ok&&support,nativeAnchorPassed:!!native.ok,supportAnchorPassed:!!support,reason:!native.ok?native.reason:'核对原对象、实际记录的方案、正重合、具体周期位置及这次安排条件；判断和标签代码不是物品总数。',observedErrors:[...(!native.ok?['primary-operation-condition']:[]),...(!support?['number-shared-condition']:[])]}}
function pFrame(t){return ['frame-plan','frame-offers'].includes(t.joint.params.operator)}
function jointNGuard(t){const p=t.joint.params;if(p.operator==='raffle')return;if(t.joint.binding==='n-motif'){jointLGuard(jointNMotif(t));return}if(!jointNFields(t)||!jointNText(t))throw Error('Missing number shared contract '+t.id);for(const k of ['unitPrice','fee','stock','demand','length','packSize','minSide','maxBorder'])if(p[k]!==undefined&&(!Number.isInteger(p[k])||p[k]<0))throw Error('Invalid number condition '+t.id+' '+k);if(p.packSize===0||p.length===0||p.minSide===0)throw Error('Empty number arrangement '+t.id)}
