'use strict';
function jointRFamily(t){return t.joint.binding.startsWith('r-')}
function jointRPair(t){
 if(t.mode==='ratioLab'){if(t.kind==='order')return t.order==='blueFirst'?[t.blue,t.red]:[t.red,t.blue];if(t.kind==='scale')return [t.red*(t.targetCopies?.red??t.copies),t.blue*(t.targetCopies?.blue??t.copies)];if(t.kind==='partition')return [t.unitRed,t.unitBlue];return [t.red,t.blue]}
 if(t.mode==='scaleLab'&&t.kind==='pair')return [t.red*(t.targetFactors?.red??t.factor),t.blue*(t.targetFactors?.blue??t.factor)];
 if(t.mode==='scaleLab'&&t.kind==='length')return [t.direction==='shrink'?t.short/t.factor:t.short*t.factor,t.direction==='shrink'?t.long/t.factor:t.long*t.factor];
 throw Error('Unknown R pair '+t.id);
}
function jointRQuantity(t){switch(t.joint.binding){
 case 'r-unit':return t.kind==='unit'?t.groups:t.knownUnit?t.copies:t.unitRed+t.unitBlue;
 case 'r-price':return t.total/t.units;
 case 'r-capacity':return t.total/t.units;
 case 'r-conversion':return t.direction==='forward'?t.count*t.factor:t.count;
 case 'r-journey':{const walked=t.segments?.reduce((a,b)=>a+b,0);return t.kind==='inverse'?t.count*(t.elapsedPer??1):t.kind==='remaining'?t.unknownWhole?t.whole:t.whole-walked:t.kind==='joint'?['a','b'].reduce((sum,s)=>sum+t[s]*Math.max(0,t.count-(t.starts?.[s]??0)),0):t.kind==='segment'?walked:t.per*t.count}
 case 'r-clock':return t.count*(t.elapsedPer??(t.interval.includes('小时')?60:1))+(t.kind==='inverse'?0:t.per*t.count*t.joint.params.afterUnitMinutes);
 case 'r-rectangle':{const [a,b]=jointRPair(t);return t.joint.params.measure==='area'?a*b:2*(a+b)}
 case 'r-area':return t.rows*t.cols*(t.axisFactors?.rows??t.factor)*(t.axisFactors?.cols??t.factor);
 case 'r-map':return t.per*t.count;
 case 'r-change':return t.start+t.add-t.remove;
 default:throw Error('Vector R task has no scalar quantity '+t.id);
}}
function jointRRole(t){if(t.joint.binding==='r-unit')return t.kind==='unit'?'以原蓝色数量为一份时，实际圈出的红色份数':t.knownUnit?'实际分出的完整组合袋数':'实际一个组合袋里的红蓝总件数';if(t.joint.binding==='r-conversion')return '换算后的'+(t.direction==='forward'?t.to:t.from)+'总量（每一输出单位贴一枚标记）';if(t.joint.binding==='r-journey')return t.kind==='inverse'?'实际用时'+(t.elapsedPer?'（分钟）':'（'+t.interval+'）'):t.kind==='remaining'?(t.unknownWhole?'恢复的全程':'实际剩余路程')+'（'+t.unit+'）':'实际合计量（'+t.unit+'）';if(t.joint.binding==='r-rectangle')return t.joint.params.measure==='area'?'改变后长方形实际面积，每平方格用一块材料':'改变后长方形实际周长，每一长度单位配一段边框';return t.joint.quantityLabel}
const JOINT_R_OPERATORS=new Set(['vector-bill','vector-budget','vector-offers','color-share','purchase','purchase-budget','work-plan','work-budget','pack-offers','clock-arrival','clock-departure']);
function jointRFields(t){const p=t.joint.params;switch(p.operator){case 'vector-bill':case 'purchase':return [['cost','总金额（元）']];case 'vector-budget':return [['left','经费剩余（元）']];case 'vector-offers':case 'pack-offers':return [['plan','选择报价'],['cost','所选总金额（元）'],...(p.operator==='pack-offers'?[['spare','所选整包多出的商品件数']]:[])];case 'color-share':return [['focusCost','所问颜色的实际金额（元）'],['totalCost','本题支出整体的实际金额（元）'],['numerator','支出份额的分子'],['denominator','支出份额的分母']];case 'purchase-budget':return [['count','最多买到的商品件数'],['left','剩余经费（元）']];case 'work-plan':return [['blocks','至少需要的完整工作时段数'],['excess','按这些完整时段可多完成的数量'],...(p.breakEvery?[['time','连同途中停歇的总占用时段单位']]:[])];case 'work-budget':return [['output','规定时段最多完成的量'],['short','还缺的量（足够时填0）']];case 'clock-arrival':case 'clock-departure':return [['day','相对当天的日期编号（当天为0）'],['hour','时（0至23）'],['minute','分（0至59）']];default:return null}}
function jointRVectorCost(t,prices,fee,perBagFee=0){const [a,b]=jointRPair(t),copies=t.kind==='partition'&&t.knownUnit?t.copies:1;return (a*prices[0]+b*prices[1]+perBagFee)*copies+fee}
function jointRText(t){const p=t.joint.params;if(p.operator.startsWith('vector-')){const labels=t.kind==='order'?['比的前项','比的后项']:['红色','蓝色'],scope=t.kind==='partition'?(t.knownUnit?'实际分出的所有完整袋':'实际一个组合袋'):'原操作最终得到的两种量',cost=(prices,fee)=>`${labels[0]}每件${prices[0]}元，${labels[1]}每件${prices[1]}元${p.perBagFee?'，每个组合袋还收'+p.perBagFee+'元包装费':''}，全单另收一次${fee}元`;return `给${scope}采购相应物品。`+(p.operator==='vector-offers'?`报价A：${cost(p.plans[0].prices,p.plans[0].fee)}；报价B：${cost(p.plans[1].prices,p.plans[1].fee)}。选总额较低的报价并填金额，同价可任选。`:`${cost(p.prices,p.fee)}。${p.operator==='vector-budget'?'从'+p.budget+'元经费支付后还剩多少？':'实际要付多少元？'}`)}
 if(p.operator==='color-share'){const color=(t.focusSide==='blue')!==!!p.other?'蓝':'红';return `用实际红蓝模型采购装饰，每红色件${p.prices[0]}元、每蓝色件${p.prices[1]}元${p.fee?'，全单另付一次'+p.fee+'元运费':''}。这次问${color}色装饰的金额占${p.fee?'连运费在内的全部支出':'两色材料总支出'}多少？填份额的分子与分母，可以用等价分数。`}
 if(p.operator==='purchase')return `沿用原操作对应商品的每件单价，再买${p.units}件，另付一次${p.fee}元运费，共多少元？`;
 if(p.operator==='purchase-budget')return `沿用原操作对应商品的每件单价，有${p.budget}元，先付一次${p.fee}元运费。每完整包${p.packQuantity}件，按件单价计包价，不拆包；最多买多少件，剩多少元？`;
 if(p.operator==='pack-offers')return `现在需要${p.demand}件同类商品。甲乙只按原题完整包卖，不能拆包，且单位价格保持原题条件。${p.spareLimit!==undefined?'多出的件数不得超过'+p.spareLimit+'。':'可以多买。'}${p.stockLimits?'甲最多有'+p.stockLimits[0]+'包，乙最多有'+p.stockLimits[1]+'包。':''}只向一家购买，选择足够满足需要且付款较少的可行方案，填总金额及多出的件数；同价可任选。`;
 if(p.operator.startsWith('work-'))return `按原模型实际求得的每1${t.unit}能完成的${t.amountUnit}数量安排任务。`+(p.operator==='work-budget'?`只有${p.blocks}${t.unit}，最多完成多少${t.amountUnit}，与需求${p.demand}${t.amountUnit}相比还缺多少？足够时填0。`:`需完成${p.demand}${t.amountUnit}，每次只能安排完整的1${t.unit}工作块。至少需要几块，按这些块可多完成多少${t.amountUnit}？${p.breakEvery?'连续每'+p.breakEvery+'块后，如果后面还需要工作，要停'+p.breakLength+t.unit+'；连同途中停歇总占用多少'+t.unit+'？':''}`);
 if(p.operator.startsWith('clock-')){const time=p.operator==='clock-arrival'?p.start:p.deadline,label=Math.floor(time/60)+':'+String(time%60).padStart(2,'0');return `沿用原题实际作业用时，${t.elapsedPer?'每个图格用时'+t.elapsedPer+'分钟；':''}${t.kind!=='inverse'?'原作业结束后，每完成1'+t.unit+'还需'+p.afterUnitMinutes+'分钟检查；检查时间随原题实际总量计算。':''}另加停留${p.rest}分钟。${p.operator==='clock-arrival'?'当天'+label+'开始，什么时候全部完成？':'必须当天'+label+'前全部完成，最迟什么时候开始？'}填日期编号、时和分；当天是0，翌日是1，前一天是-1。`}
 if(t.joint.binding==='r-conversion')return `按换算后的每1${t.direction==='forward'?t.to:t.from}贴一枚标记，再把同一批标记${p.operator==='cover'?'全部装入每箱最多'+p.capacity+'枚的箱；至少几箱、合计还空几格？':p.operator==='full'?'按每完整箱'+p.capacity+'枚发货；最多发几箱、剩几枚？':'装入'+p.containers+'个同样的箱；每箱至少多少容量？'}`;
 if(t.joint.binding==='r-journey'&&t.kind==='inverse'&&['bill','remaining','offers'].includes(p.operator)){const label=t.elapsedPer?'分钟':t.interval;if(p.operator==='bill')return `按原题实际用时计租金，每1${label}${p.unitPrice}元，另付一次${p.fee}元费用，共多少元？`;if(p.operator==='remaining')return `租金每1${label}${p.unitPrice}元，另付一次${p.fee}元，从${p.budget}元经费中付完还剩多少？`;return `租金报价A每1${label}${p.plans[0].unitPrice}元加一次${p.plans[0].fee}元，B每1${label}${p.plans[1].unitPrice}元加一次${p.plans[1].fee}元；选较低总额并填金额，同价任选。`}
 return null;
}
function jointRExpected(t){const p=t.joint.params;switch(p.operator){
 case 'vector-bill':return {cost:jointRVectorCost(t,p.prices,p.fee,p.perBagFee)};
 case 'vector-budget':return {left:p.budget-jointRVectorCost(t,p.prices,p.fee,p.perBagFee)};
 case 'vector-offers':{const costs=p.plans.map(x=>jointRVectorCost(t,x.prices,x.fee,p.perBagFee)),min=Math.min(...costs);return {plans:p.plans.filter((x,i)=>costs[i]===min).map(x=>x.id),cost:min}}
 case 'color-share':{const [r,b]=jointRPair(t),side=(t.focusSide==='blue')!==!!p.other?1:0,values=[r*p.prices[0],b*p.prices[1]];return {focusCost:values[side],totalCost:values[0]+values[1]+p.fee,numerator:values[side],denominator:values[0]+values[1]+p.fee}}
 case 'purchase':return {cost:jointRQuantity(t)*p.units+p.fee};
 case 'purchase-budget':{const per=jointRQuantity(t)*p.packQuantity,packages=Math.floor((p.budget-p.fee)/per);return {count:packages*p.packQuantity,left:p.budget-p.fee-packages*per}}
 case 'pack-offers':{const offers=[t.a,t.b].map((x,i)=>{const n=Math.ceil(p.demand/x.units),spare=n*x.units-p.demand;return {id:i===0?'A':'B',cost:n*x.total,spare,feasible:(p.spareLimit===undefined||spare<=p.spareLimit)&&(!p.stockLimits||n<=p.stockLimits[i])}}),min=Math.min(...offers.filter(x=>x.feasible).map(x=>x.cost));return {plans:offers.filter(x=>x.feasible&&x.cost===min).map(x=>x.id),offers}}
 case 'work-plan':{const q=jointRQuantity(t),blocks=Math.ceil(p.demand/q),time=blocks+(p.breakEvery?Math.max(0,Math.floor((blocks-1)/p.breakEvery))*p.breakLength:0);return {blocks,excess:blocks*q-p.demand,time}}
 case 'work-budget':{const output=jointRQuantity(t)*p.blocks;return {output,short:Math.max(0,p.demand-output)}}
 case 'clock-arrival':case 'clock-departure':{const minutes=jointRQuantity(t)+p.rest,total=p.operator==='clock-arrival'?p.start+minutes:p.deadline-minutes,day=Math.floor(total/1440),within=total-day*1440;return {day,hour:Math.floor(within/60),minute:within%60}}
 default:throw Error('Unknown R operator '+p.operator);
}}
function jointRValidate(t,base){const native=base.grade(t),p=t.joint.params,e=jointRExpected(t),answers=jointState().responses;let support=jointReady(t);if(p.operator==='color-share'){const n=jointNumber(answers.numerator),d=jointNumber(answers.denominator);support=support&&Number.isInteger(n)&&Number.isInteger(d)&&n>=0&&d>0&&n*e.denominator===d*e.numerator&&jointNumber(answers.focusCost)===e.focusCost&&jointNumber(answers.totalCost)===e.totalCost}
 else support=support&&jointRFields(t).every(([k])=>k==='plan'?e.plans.includes(answers.plan):jointNumber(answers[k])===(p.operator==='pack-offers'?e.offers.find(x=>x.id===answers.plan)?.[k]:e[k]));
 return {ok:native.ok&&support,nativeAnchorPassed:!!native.ok,supportAnchorPassed:!!support,reason:!native.ok?native.reason:'核对原模型实际得到的两种量、单价/整包/用时及本次预算、停歇或截止条件。',observedErrors:[...(!native.ok?['primary-operation-condition']:[]),...(!support?['shared-condition-response']:[])]};
}
function jointRGuard(t){if(t.joint.binding==='r-packs'){if(!jointRExpected(t).plans.length)throw Error('No feasible shared offer '+t.id)}else if(['r-pair','r-share'].includes(t.joint.binding)){if(!jointRPair(t).every(n=>Number.isInteger(n)&&n>=0))throw Error('Noninteger R pair '+t.id)}else{const q=jointRQuantity(t);if(!Number.isInteger(q)||q<0||t.joint.binding==='r-capacity'&&!q||t.joint.binding==='r-price'&&!q)throw Error('Invalid R quantity '+t.id)}}
