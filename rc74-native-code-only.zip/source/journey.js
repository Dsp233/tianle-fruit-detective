'use strict';
// A time slot is one equal interval. Segmented journeys use authored lengths;
// joint work requires both workers' contributions in the same interval.
const JOURNEY_TASKS={
 'R03.01':{kind:'equal',per:2,count:3,interval:'10分钟',unit:'千米',context:'骑车',prompt:'每10分钟走2千米。逐段摆出30分钟的路程，看看一共走多远。',explain:'三个相同的10分钟，每段2千米，共6千米。',reason:{prompt:'为什么要摆三段？',options:['30分钟有三个10分钟，每段同速走2千米','30分钟就是30千米','只要知道10分钟就不用看总时间'],answer:0}},
 'R03.02':{kind:'inverse',per:3,count:4,interval:'小时',unit:'千米',context:'徒步',prompt:'每小时走3千米，目标是12千米。逐小时摆路程，到达目标时数用了几小时。',explain:'3、6、9、12千米，走4个一小时，合计4小时。',reason:{prompt:'怎样从路程找时间？',options:['每添一个一小时的3千米，数到12千米用了4格','把12千米说成12小时','只看每小时3千米就说用了3小时'],answer:0}},
 'R03.03':{kind:'segment',segments:[2,3,4],interval:'段',unit:'千米',context:'公园路线',prompt:'路线分三段，依次是2、3、4千米。把每段放到路线上，读出累计路程。',explain:'各段不重叠，累计2、5、9千米。',reason:{prompt:'为什么能把三段相加？',options:['三段首尾相接、不重叠，走完整条路就是2＋3＋4','只算最长的一段','把三段的时间相加就是路程'],answer:0}},
 'R03.04':{kind:'remaining',segments:[2,3],whole:12,interval:'段',unit:'千米',context:'远足',prompt:'全程12千米，先走2千米再走3千米。把走过的路放进全程条，再选剩下多少千米。',explain:'已走2＋3＝5千米，剩12－5＝7千米。',reason:{prompt:'剩余路程怎么得到？',options:['从同一全程12千米中扣除已走的5千米','把12与5相加','把第二段3千米当成全部已走'],answer:0}},
 'R03.05':{kind:'joint',a:3,b:2,count:2,interval:'分钟',unit:'个',context:'两人装盒',prompt:'甲每分钟装3个，乙每分钟装2个。每一分钟分别给两人摆出成果，做2分钟后看总共多少个。',explain:'同一分钟甲乙合做5个，两分钟共10个。',reason:{prompt:'为什么两人的产量可以合并？',options:['同一分钟两人同时工作，先合并每分钟产量，再数两分钟','把两人的工作分钟也加成四分钟','只数甲的产量就代表两人'],answer:0}}
};
for(const [skillId,t] of Object.entries(JOURNEY_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:19,mode:'journeyLab',phase:'练',hint:'先找每个时间格或路线段代表什么，再逐格摆出来。'});
if(typeof module!=='undefined')module.exports={JOURNEY_TASKS};
