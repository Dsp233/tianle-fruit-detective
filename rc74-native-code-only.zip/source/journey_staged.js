'use strict';
// Each item is a distinct authored situation: transfer, two independent
// instances, and a delayed new instance. No random substitution is used.
const JOURNEY_CASES={
 'R03.01':[
  [{kind:'equal',per:1,count:4,interval:'10分钟',unit:'千米',context:'轮滑'},'每10分钟滑1千米。逐段摆出40分钟的路程。','四个10分钟，每段1千米，共4千米。','骑车改轮滑，路程率和时间段数均变化'],
  [{kind:'equal',per:4,count:3,interval:'小时',unit:'千米',context:'步行'},'每小时走4千米，连续走3小时。逐小时摆出路程。','4＋4＋4＝12千米。','无提示：分钟段换为整小时'],
  [{kind:'inverse',per:2,count:5,interval:'分钟',unit:'页',context:'打印机'},'每分钟打2页。逐分钟摆到10页，数出用时。','到10页需5个一分钟格。','备用：由总量反求相同时间段数'],
  [{kind:'equal',per:5,count:2,interval:'小时',unit:'千米',context:'晨跑'},'每小时跑5千米，逐小时摆出2小时的路程。','两小时共10千米。','隔日：新运动与新路程']
 ],
 'R03.02':[
  [{kind:'equal',per:6,count:3,interval:'分钟',unit:'张',context:'贴标签'},'每分钟贴6张。逐分钟摆3分钟的总数。','6×3＝18张。','由求时间换成给定时间求总量'],
  [{kind:'inverse',per:4,count:3,interval:'小时',unit:'千米',context:'徒步'},'每小时4千米，逐小时摆到12千米，数出时间。','12÷4＝3小时。','无提示：速度变化'],
  [{kind:'inverse',per:5,count:4,interval:'分钟',unit:'页',context:'扫描'},'每分钟扫5页，逐分钟摆到20页。','四分钟共20页。','备用：路程换成文件页数'],
  [{kind:'equal',per:7,count:2,interval:'小时',unit:'千米',context:'骑行'},'每小时骑7千米，摆出两小时的路程。','7×2＝14千米。','隔日：未知量从时间换为路程']
 ],
 'R03.03':[
  [{kind:'segment',segments:[3,1,4],interval:'段',unit:'千米',context:'三段步道'},'依次走3、1、4千米。逐段放进路线上，读累计路程。','3、4、8千米。','中段较短，检查是否漏加'],
  [{kind:'segment',segments:[2,5],interval:'段',unit:'千米',context:'河边骑行'},'第一段2千米，第二段5千米。摆出两段并读全程。','2＋5＝7千米。','无提示：路程段数改为两段'],
  [{kind:'segment',segments:[4,3,2],interval:'段',unit:'千米',context:'郊游'},'三段各4、3、2千米，逐段放在路线条上。','累计4、7、9千米。','备用：三段顺序与累计变化'],
  [{kind:'segment',segments:[1,6,2],interval:'段',unit:'千米',context:'湖边环线'},'从入口依次走1、6、2千米。摆出路段读全程。','1＋6＋2＝9千米。','隔日：新路径，非等长路段']
 ],
 'R03.04':[
  [{kind:'remaining',segments:[4,3],whole:15,interval:'段',unit:'千米',context:'登山'},'全程15千米，已走4千米又走3千米，摆进全程条并选剩余。','15－(4＋3)＝8千米。','全程与已走段同时改变'],
  [{kind:'remaining',segments:[3,2],whole:11,interval:'段',unit:'千米',context:'骑行计划'},'全程11千米，先走3再走2。摆出已走路程并选剩余。','已走5，剩6千米。','无提示：新全程与剩余'],
  [{kind:'remaining',segments:[1,5],whole:14,interval:'段',unit:'千米',context:'森林路线'},'全程14千米，前两段走1和5千米。摆进全程条并选剩余。','14－6＝8千米。','备用：第一段较短'],
  [{kind:'remaining',segments:[6,2],whole:17,interval:'段',unit:'千米',context:'河堤步道'},'全程17千米，已经走6千米和2千米，摆已走并选剩余。','17－8＝9千米。','隔日：新全程与分段']
 ],
 'R03.05':[
  [{kind:'joint',a:2,b:4,count:3,interval:'分钟',unit:'个',context:'两人叠纸盒'},'甲每分钟2个，乙每分钟4个，同时做3分钟。逐分钟分别摆出两人的成果。','每分钟合做6个，三分钟共18个。','两人速度交换且时间延长'],
  [{kind:'joint',a:4,b:1,count:2,interval:'分钟',unit:'张',context:'两人剪卡'},'甲每分钟剪4张，乙每分钟剪1张，同时剪2分钟。逐分钟给两人分别摆卡。','每分钟合剪5张，两分钟共10张。','无提示：成果单位从盒子换卡片'],
  [{kind:'joint',a:3,b:3,count:3,interval:'分钟',unit:'枚',context:'两人分棋子'},'两人每分钟各分3枚，同时做3分钟。每分钟各自摆出产量。','每分钟两人共6枚，三分钟18枚。','备用：两人速度相同'],
  [{kind:'joint',a:1,b:5,count:2,interval:'分钟',unit:'个',context:'两人装书签'},'甲每分钟装1个，乙每分钟装5个，同时做2分钟。逐分钟分别摆出成果。','每分钟6个，两分钟12个。','隔日：两人贡献悬殊，仍按相同时间合并']
 ]
};
const journeyStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(JOURNEY_CASES)){
 if(cases.length!==4)throw Error('Four R03 cases required: '+skillId);journeyStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];journeyStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:20,mode:'journeyLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先看相同时间格或各路段代表什么，再逐格累计。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={JOURNEY_CASES};
