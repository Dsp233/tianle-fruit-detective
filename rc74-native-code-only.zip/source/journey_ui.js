'use strict';
function journeyState(task){const w=draft.work??(draft.work={steps:[],rounds:[],log:[],choice:'',moves:0});w.elapsed??=0;w.elapsedSet??=false;w.whole??=0;w.wholeSet??=false;return w}
function journeyEligible(task,i,side){return i>=(task.starts?.[side]||0)}
function journeyRoundComplete(task,r,i){return ['a','b'].every(side=>journeyEligible(task,i,side)?r[side]:!r[side])}
function journeyTotal(task,w){return task.kind==='joint'?w.rounds.reduce((n,r)=>n+(r.a?task.a:0)+(r.b?task.b:0),0):w.steps.reduce((n,v)=>n+v,0)}
function journeyLimit(task){return task.kind==='equal'?task.count:task.kind==='inverse'?task.count+2:task.kind==='joint'?task.count:task.segments.length}
function journeyDots(n){return `<span class="journey-dots" role="img" aria-label="${n}个单位量">${Array.from({length:n},()=>'<i aria-hidden="true"></i>').join('')}</span>`}
function journeyInput(action,label,value){return `<section><b>${label}：${value}</b><div class="work-buttons">${[-10,-1,0,1,5,10].map(d=>`<button data-action="${action}" data-delta="${d}">${d===0?'填0':d>0?'＋'+d:d}</button>`).join('')}</div></section>`}
function journeyBoard(task){const w=journeyState(task),n=task.kind==='joint'?w.rounds.length:w.steps.length,limit=journeyLimit(task),total=journeyTotal(task,w);
 const slots=Array.from({length:limit},(_,i)=>{const active=i<n,round=w.rounds[i],part=active?(task.kind==='joint'?(round.a?task.a:0)+(round.b?task.b:0):w.steps[i]):0;return `<div class="journey-slot ${active?'filled':''}"><b>${['segment','remaining'].includes(task.kind)?'第'+(i+1)+'时段':'第'+(i+1)+task.interval}</b>${task.kind==='joint'?`<span>甲：${!journeyEligible(task,i,'a')?'未开工':round?.a?task.a:'待摆'}</span><span>乙：${!journeyEligible(task,i,'b')?'未开工':round?.b?task.b:'待摆'}</span>`:''}${journeyDots(part)}<small>${active?part+' '+task.unit:'待摆'}</small></div>`}).join('');
 let actions='';
 if(task.kind==='joint'){
  const last=w.rounds.at(-1),needsNew=!last||journeyRoundComplete(task,last,n-1),i=needsNew?n:n-1;
  actions=['a','b'].map(side=>`<button data-action="journeyWorker" data-side="${side}" ${i>=limit||!journeyEligible(task,i,side)||!needsNew&&last[side]?'disabled':''}>${side==='a'?'甲':'乙'}做 ${task[side]} ${esc(task.unit)}</button>`).join('');
 }else actions=`<button data-action="journeyStep" ${n>=limit?'disabled':''}>${['segment','remaining'].includes(task.kind)?'放下一段 '+(task.segments[n]??''):'走下一'+task.interval+' '+task.per} ${esc(task.unit)}</button>`;
 const choices=task.kind==='remaining'&&!task.unknownWhole?`<p>剩多少？</p>${choiceButtons(task,[...new Set([task.whole-task.segments.reduce((a,b)=>a+b,0),task.segments.reduce((a,b)=>a+b,0),task.whole])].map(v=>[String(v),v+' '+task.unit]),'journeyChoice')}`:'';
 const route=task.unknownWhole?`${journeyInput('journeyWhole','我拼出的全程（'+task.unit+'）',w.whole)}<div class="journey-route-track" style="--route-cols:${Math.max(1,Math.min(12,w.whole))}" role="img" aria-label="全程候选${w.whole}格，已走${total}格，剩下${Math.max(0,w.whole-total)}格">${Array.from({length:w.whole},(_,i)=>`<i data-object-id="J${i}" class="${i<total?'walked':''}"></i>`).join('')}</div><p>已知剩余 ${task.givenRemaining} ${esc(task.unit)}。核对末段是否正好放入外框。</p>`:'';
 return `<div class="board journey-board"><h3>${esc(task.context)} · ${task.kind==='joint'?task.starts?'两人起步时间不同':'同一分钟，两人分别做':task.kind==='remaining'?task.unknownWhole?'用已走和剩余拼全程':'全程 '+task.whole+' '+task.unit:task.kind==='segment'?'每个时段都要记录':'每'+task.interval+' '+task.per+' '+task.unit}</h3><div class="journey-slots">${slots}</div><p>已摆 ${total} ${esc(task.unit)}，记录 ${n} 个${['segment','remaining'].includes(task.kind)?'时段':task.interval}。</p>${route}<div class="work-buttons">${actions}<button data-action="journeyUndo" ${!w.steps.length&&!w.rounds.length?'disabled':''}>↩ 撤回一步</button></div>${task.elapsedPer?journeyInput('journeyElapsed','我的用时（分钟）',w.elapsed):''}${choices}</div>`;
}
function journeyGrade(task){const w=journeyState(task),total=journeyTotal(task,w),n=task.kind==='joint'?w.rounds.length:w.steps.length;let ok=false,incomplete=n===0;
 if(['equal','inverse'].includes(task.kind))ok=n===task.count&&w.steps.every(v=>v===task.per)&&total===task.per*task.count&&(!task.elapsedPer||w.elapsedSet&&w.elapsed===n*task.elapsedPer);
 if(task.kind==='segment')ok=n===task.segments.length&&w.steps.every((v,i)=>v===task.segments[i])&&total===task.segments.reduce((a,b)=>a+b,0);
 if(task.kind==='remaining'){
  ok=n===task.segments.length&&w.steps.every((v,i)=>v===task.segments[i])&&(task.unknownWhole?w.wholeSet&&w.whole===task.whole&&w.whole-total===task.givenRemaining:w.choice===String(task.whole-total));
  incomplete=n===0||(task.unknownWhole?!w.wholeSet:!w.choice);
 }
 if(task.kind==='joint'){
  const expected=['a','b'].reduce((sum,side)=>sum+task[side]*Math.max(0,task.count-(task.starts?.[side]||0)),0);
  ok=n===task.count&&w.rounds.every((r,i)=>journeyRoundComplete(task,r,i))&&total===expected;
  incomplete=n===0||w.rounds.some((r,i)=>!journeyRoundComplete(task,r,i));
 }
 return {ok,incomplete,reason:'逐时段核对量和时间；停留也要记录。两人只在各自实际开工的时间格内计成果。'};
}
function journeyAct(action,data,task){const w=journeyState(task),n=w.steps.length,limit=journeyLimit(task);let changed=false;
 if(action==='journeyStep'&&task.kind!=='joint'&&n<limit){w.steps.push(['segment','remaining'].includes(task.kind)?task.segments[n]:task.per);changed=true}
 if(action==='journeyWorker'&&task.kind==='joint'&&['a','b'].includes(data.side)){
  let round=w.rounds.at(-1),i=w.rounds.length-1;const needsNew=!round||journeyRoundComplete(task,round,i);if(needsNew)i++;
  if(i<limit&&journeyEligible(task,i,data.side)&&(needsNew||!round[data.side])){
   if(needsNew){round={a:false,b:false};w.rounds.push(round)}round[data.side]=true;w.log.push([i,data.side]);changed=true;
  }
 }
 if(action==='journeyUndo'){
  if(task.kind==='joint'){const last=w.log.pop();if(last){const [i,side]=Array.isArray(last)?last:[w.rounds.length-1,last],r=w.rounds[i];if(r){r[side]=false;if(!r.a&&!r.b)w.rounds.pop();changed=true}}}
  else if(n){w.steps.pop();w.choice='';changed=true}
 }
 if(action==='journeyChoice'&&task.kind==='remaining'&&!task.unknownWhole&&/^\d+$/.test(data.value||'')){w.choice=data.value;changed=true}
 if(action==='journeyElapsed'&&task.elapsedPer||action==='journeyWhole'&&task.unknownWhole){
  const key=action==='journeyElapsed'?'elapsed':'whole',d=Number(data.delta),value=w[key]+d;
  if([-10,-1,0,1,5,10].includes(d)&&value>=0&&value<=100){w[key]=value;w[key+'Set']=true;changed=true}
 }
 if(changed)w.moves++;return changed;
}
function journeySpeech(task){const w=journeyState(task);return task.kind==='joint'?w.rounds.map((r,i)=>`第${i+1}分钟，甲${r.a?task.a:0}个、乙${r.b?task.b:0}个`).join('；'):`已记录${w.steps.length}个时间格，各格${w.steps.join('、')||'尚未摆出'}${task.unit}。`+(task.unknownWhole?`我的全程候选${w.whole}${task.unit}。`:'')+(task.elapsedPer?`我的用时${w.elapsed}分钟。`:'')}
function journeyPage(){const task=JOURNEY_TASKS[microSkillId],skill=SKILL_DATA.skills.find(s=>s.id===microSkillId);if(!task||!skill)return '<div class="panel">操作任务不存在。</div>';return `<div class="page-head"><div><p class="kicker">${esc(task.skillId)}</p><h1>${esc(skill.title)}</h1></div><button class="back" data-action="micro" data-code="${esc(task.skillId)}">← 返回</button></div><div class="work"><article class="panel"><span class="phase">练 · 操作一题</span><h2 class="task-title">${esc(task.prompt)}</h2><div class="workshop-check-top"><button class="primary" data-action="${feedback?.ok?'next':'check'}">${feedback?.ok?'完成本题 →':'检查操作与理由 ✓'}</button></div>${journeyBoard(task)}${reasonBlock(task)}${actionRow(task)}</article><aside class="side-stack">${stageLinks(task.skillId)}</aside></div>`}
