'use strict';
// A drawing acquires meaning only through explicit student quantity bindings and
// checked directed relations. Saved verification labels are never authoritative.
const LearnerSketchSemantics=((Model,P)=>{
 const countedKinds=new Set(['bar','group','balance','set','area','stack']);
 const unit=x=>String(x||'').trim().replace(/m²|m2|㎡/g,'平方米').replace(/^m$/,'米');
 const refs=ast=>ast?.op==='quantity'?[ast.value]:(ast?.items||[]).flatMap(refs);
 const fingerprint=n=>JSON.stringify([n.id,n.label,n.quantityId,n.scopeId,n.role,unit(n.unit),n.value,n.kind,n.count,n.representation||'schematic',n.scale||'1']);
 function contract(task,scopeId='main'){
  const model=Model.contract(task,scopeId);if(!model)return null;
  const m=task.competition.math,k=task.competition.configurationId,quantities={};
  const put=(name,u,role='derived',value)=>quantities[name]={id:name,unit:u,role,...(value===undefined?{}:{value:String(value)})};
  const known=(name,u,value)=>put(name,u,'known',value);
  if(k==='mean-admission'||k==='score-training'){
   known('总人数','人',m.N);known('蓝队均分','分',m.high);
   for(const q of ['红队人数','蓝队人数'])put(q,'人');
   if(k==='mean-admission'){
    known('红队均分','分',m.low);known('新增均分','分',m.score);known('目标均分','分',m.target);
    put('原总分','分');put('新均分','分');put('新增人数','人','conjecture');put('活动人数','人');put('材料份数','份');put('包数','包','conjecture');put('整包条件','');put('最少整包','');
   }else{
    known('全体均分','分',m.mean);known('目标均分','分',m.target);known('个人班目标分','分',m.high);known('小组班目标分','分',m.high-10);
    for(const q of ['红队原分','所需增分','个人增分','小组增分'])put(q,'分');
    put('小组数','组','conjecture');put('个人数','人','conjecture');
   }
  }else if(k==='length-border'){
   known('周长','米',m.perimeter);known('边框宽','米',m.border);known('每包价格','元',m.price);
   for(const q of ['长宽和','宽','长','内长','内宽'])put(q,'米');
   put('边框面积','平方米');put('砖块数','块');put('包数','包','conjecture');put('整包条件','');put('最少整包','');
  }else{
   known('宽','米',m.W);known('门洞宽','米',m.gate);
   for(const q of ['长','周长','围栏长度','板材长度'])put(q,'米');
   put('板数','块','conjecture');put('整包数','包','conjecture');put('单块数','块','conjecture');put('板材费用','元');put('最少整板','');put('整板条件','');
  }
  put('总费用','元','target');return {...model,quantities};
 }
 function nodeIssue(n,definition,scopeId){
  const q=definition.quantities[n.quantityId];
  if(!q)return '这个量名尚未与本题的数量对应，草图仍保留。';
  if(n.scopeId!==scopeId)return '这个量属于另一题或另一作答范围，请重新放入当前草图。';
  if(n.role!==q.role)return '请核对“'+n.label+'”是题给条件、推导量、待比较的候选，还是最终目标。';
  if(unit(n.unit)!==q.unit)return '请核对“'+n.label+'”的单位与题中所指的量是否一致。';
  if(q.role==='known'&&!P.equal(n.value,q.value))return '“'+n.label+'”与题给数值还不一致。';
  if(n.representation==='counted'){
   if(!countedKinds.has(n.kind))return '这种图形保留为示意；按数量表示可使用份数条、分组、集合、天平盘、面积格或立体块。';
   const scale=P.arithmetic(n.scale||'1');
   if(!scale||scale[0]<=0n||!P.equal(String(n.count)+'*('+String(n.scale||'1')+')',n.value))return '实际图形个数乘每个代表的量，与填写的数量还不一致。';
  }
  return null;
 }
 function mappedAst(ast,byAlias){
  if(ast.op==='quantity'){const n=byAlias.get(ast.value);return n?{op:'quantity',value:n.quantityId}:null}
  if(ast.value!==undefined)return ast;
  const items=ast.items.map(x=>mappedAst(x,byAlias));return items.every(Boolean)?{op:ast.op,items}:null;
 }
 function numeric(ast,byQuantity){
  if(ast.op==='number')return ast.value;
  if(ast.op==='quantity'){const v=byQuantity.get(ast.value)?.value;return P.arithmetic(v)?'('+v+')':null}
  const a=ast.items.map(x=>numeric(x,byQuantity));if(a.some(x=>x===null))return null;
  if(ast.op==='neg')return '-('+a[0]+')';
  if(['<','>','<=','>='].includes(ast.op)){
   const x=P.arithmetic(a[0]),y=P.arithmetic(a[1]);if(!x||!y)return null;
   let left=x[0]*y[1],right=y[0]*x[1];if(x[1]*y[1]<0n){left=-left;right=-right}
   return ({'<':left<right,'>':left>right,'<=':left<=right,'>=':left>=right}[ast.op])?'是':'否';
  }
  return '('+a[0]+ast.op+a[1]+')';
 }
 function assess(task,sketch,scopeId='main',manualFacts={}){
  const definition=contract(task,scopeId),facts={},rows=[];
  if(!definition||!sketch||sketch.readOnly===true||sketch.signature!==task.competition.signature+(scopeId==='main'?'':':'+scopeId))return {supported:!!definition,facts,rows};
  const nodes=sketch.nodes||[],byId=new Map(nodes.map(n=>[n.id,n])),byQuantity=new Map(),byAlias=new Map(),duplicates=new Set();
  for(const n of nodes.filter(n=>n.quantityId)){
   if(byQuantity.has(n.quantityId))duplicates.add(n.quantityId);byQuantity.set(n.quantityId,n);
   for(const alias of new Set([n.label,n.quantityId])){if(byAlias.has(alias)&&byAlias.get(alias)!==n)byAlias.set(alias,null);else if(!byAlias.has(alias))byAlias.set(alias,n)}
  }
  for(const saved of (sketch.semanticRelations||[]).slice(0,40)){
   const output=byId.get(saved.outputNodeId),ast=Model.parse(saved.expression),mapped=ast&&mappedAst(ast,byAlias),rule=output&&definition.rules.find(r=>r.left===output.quantityId&&mapped&&r.forms.some(f=>Model.canonical(Model.parse(f))===Model.canonical(mapped))),inputs=mapped?[...new Set(refs(mapped))].map(q=>byQuantity.get(q)):[],involved=[output,...inputs];
   let issue=!output?'对应的输出量已移除。':ast&&refs(ast).some(name=>byAlias.has(name)&&byAlias.get(name)===null)?'同一个量对应了多个图或重名标签，请先明确使用哪个。':!rule?'这条关系暂未核验，草稿已保留；数值相同不能代替数量关系。':null;
   if(!issue)issue=involved.map(n=>!n?'关系里有尚未放入图中的量。':duplicates.has(n.quantityId)?'同一个题中量对应了多个图，请先明确使用哪个。':nodeIssue(n,definition,scopeId)).find(Boolean)||null;
   if(!issue&&(!saved.checked||saved.stale||involved.some(n=>saved.nodeFingerprints?.[n.id]!==fingerprint(n))))issue='使用的量已改变，请重新核对这条关系。';
   if(!issue&&output.value.trim()){
    const value=numeric(mapped,byQuantity);
    if(value===null||(['是','否'].includes(value)?value!==output.value.trim():!P.equal(value,output.value)))issue='这条关系与输出量填写的值还不一致，请核对计算或暂时留空。';
   }
   rows.push({id:saved.id,ruleId:rule?.id,outputNodeId:saved.outputNodeId,inputNodeIds:inputs.map(n=>n?.id).filter(Boolean),status:issue?(saved.stale?'stale':'unverified'):'pending',issue,rule,ast:mapped,saved});
  }
  // Fixed point supports any order of student entry without accepting a cycle.
  for(let pass=0;pass<=rows.length;pass++){let changed=false;for(const row of rows){if(row.status!=='pending')continue;if(row.rule.deps.some(id=>facts[id]?.status!=='verified'&&manualFacts[id]?.status!=='verified'))continue;row.status='verified';facts[row.rule.id]={status:'verified',providedBy:'student',origin:'sketch',quantityId:row.rule.left,ruleId:row.rule.id,semanticDigest:Model.canonical(row.ast),usedSkillIds:row.rule.skills,input:row.rule.left+'='+row.saved.expression,sketchRelationId:row.id};changed=true}if(!changed)break}
  for(const row of rows)if(row.status==='pending'){row.status='unverified';row.issue='关系使用的前置量还没有核验。'}
  return {supported:true,facts,rows,nodeIssues:Object.fromEntries(nodes.filter(n=>n.quantityId).map(n=>[n.id,nodeIssue(n,definition,scopeId)]))};
 }
 function check(task,sketch,scopeId='main',manualFacts={}){
  if(sketch.readOnly===true)return false;
  const output=sketch.nodes.find(n=>n.id===sketch.selected),definition=contract(task,scopeId);
  if(!definition){sketch.feedback='这道题的自由草图已保留，数量关系暂未自动核验。';return false}
  if(!output?.quantityId){sketch.feedback='先选择输出量，并填写它代表题目中的哪个量。';return false}
  const ast=Model.parse(sketch.semanticExpressionInput),byAlias=new Map();for(const n of sketch.nodes)for(const alias of [n.label,n.quantityId].filter(Boolean))if(!byAlias.has(alias))byAlias.set(alias,n);else if(byAlias.get(alias)!==n)byAlias.set(alias,null);
  const mapped=ast&&mappedAst(ast,byAlias),inputIds=mapped?[...new Set(refs(mapped))].map(q=>sketch.nodes.find(n=>n.quantityId===q)?.id).filter(Boolean):[];
  const previous=(sketch.semanticRelations||[]).find(r=>r.outputNodeId===output.id);
  sketch.semanticModelChanged=!!previous&&(previous.expression!==sketch.semanticExpressionInput||previous.stale||[output.id,...inputIds].some(id=>previous.nodeFingerprints?.[id]!==fingerprint(sketch.nodes.find(n=>n.id===id))));
  if(sketch.semanticModelChanged)invalidate(sketch,output.id);
  const rule=definition.rules.find(r=>r.left===output.quantityId&&mapped&&r.forms.some(f=>Model.canonical(Model.parse(f))===Model.canonical(mapped))),dependencyNodeIds=(rule?.deps||[]).map(id=>definition.rules.find(r=>r.id===id)?.left).map(q=>sketch.nodes.find(n=>n.quantityId===q)?.id).filter(Boolean);
  const relation={id:previous?.id||'relation-'+output.id,outputNodeId:output.id,inputNodeIds:inputIds,dependencyNodeIds,expression:String(sketch.semanticExpressionInput).slice(0,160),checked:true,stale:false,providedBy:'student',nodeFingerprints:Object.fromEntries([output.id,...inputIds].map(id=>sketch.nodes.find(n=>n.id===id)).filter(Boolean).map(n=>[n.id,fingerprint(n)]))};
  sketch.semanticRelations=(sketch.semanticRelations||[]).filter(r=>r.outputNodeId!==output.id);sketch.semanticRelations.push(relation);
  const result=assess(task,sketch,scopeId,manualFacts),row=result.rows.find(r=>r.id===relation.id),ok=row?.status==='verified';
  sketch.edges=sketch.edges.filter(e=>e.semanticRelationId!==relation.id);
  if(ok)for(const from of row.inputNodeIds)sketch.edges.push({from,to:output.id,label:'→',semanticRelationId:relation.id,relationRuleId:row.ruleId,inputNodeId:from,outputNodeId:output.id,verification:'student-draft'});
  sketch.feedback=ok?'图中的量、单位和这条有向关系已核验。最终还需核对工具、条件及最优性。':row?.issue||'这条关系暂未核验，草稿已保留。';
  sketch.events.push({type:'sketch-relation-check',at:Date.now(),relationId:relation.id,ruleId:row?.ruleId||null,verified:!!ok,help:false});return !!ok;
 }
 function invalidate(sketch,nodeId){
  const affected=new Set([nodeId]);let changed=true;
  while(changed){changed=false;for(const r of sketch.semanticRelations||[])if(!r.stale&&(affected.has(r.outputNodeId)||[...(r.inputNodeIds||[]),...(r.dependencyNodeIds||[])].some(id=>affected.has(id)))){r.stale=true;affected.add(r.outputNodeId);changed=true}}
 }
 return {contract,assess,check,invalidate,nodeIssue,fingerprint,countedKinds};
})(typeof module!=='undefined'?require('./competition_model_workspace'):CompetitionModelWorkspace,typeof module!=='undefined'?require('./problem_state'):ProblemState);
if(typeof module!=='undefined')module.exports=LearnerSketchSemantics;
