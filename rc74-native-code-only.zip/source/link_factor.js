'use strict';
const fs=require('fs'),path=require('path'),{readCsv}=require('./csv'),{FACTOR_TASKS}=require('./factor');
const check=process.argv.includes('--check'),root=path.join(__dirname,'..');
function output(file,text){if(check){if(fs.readFileSync(file,'utf8')!==text)throw Error('Stale: '+file)}else fs.writeFileSync(file,text)}
const skillsFile=path.join(__dirname,'skills.json'),skills=JSON.parse(fs.readFileSync(skillsFile,'utf8'));
for(const skill of skills.skills){const task=FACTOR_TASKS[skill.id];if(!task)continue;skill.taskIds=[...new Set([...skill.taskIds,task.id])];skill.coverageStatus='有部分操作任务及阶段新实例；完整六阶段和资料来源未验收'}
output(skillsFile,JSON.stringify(skills,null,2)+'\n');
function update(name,cb){const file=path.join(root,'docs',name),{fields,rows}=readCsv(fs.readFileSync(file,'utf8'));for(const row of rows){const task=FACTOR_TASKS[row['微技能ID']];if(task)cb(row,task)}
 const q=s=>{const v=String(s??'');return /[,"\r\n]/.test(v)?'"'+v.replaceAll('"','""')+'"':v};
 output(file,'\ufeff'+fields.map(q).join(',')+'\n'+rows.map(row=>fields.map(f=>q(row[f])).join(',')).join('\n')+'\n')}
const append=(v,id)=>[...new Set([...String(v||'').split(';').filter(Boolean),id])].join(';');
update('unit-skill-matrix.csv',(row,t)=>{row['操作任务ID']=append(row['操作任务ID'],t.id);row['解释任务ID']=append(row['解释任务ID'],t.id);row['状态']='进行中（因数与质数操作和阶段实例已写定；完整六阶段与设备未验收）'});
update('source-map.csv',(row,t)=>{row['网页任务ID']=append(row['网页任务ID'],t.id);row['状态']='进行中（因数与质数操作和阶段实例已关联；原页、真题与六阶段待核）'});
console.log(`${check?'Checked':'Updated'} ${Object.keys(FACTOR_TASKS).length} N02 operations and reason cards.`);
