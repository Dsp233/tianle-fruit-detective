"""Add one narrowly scoped, authored object-sorting task to each micro-skill.

Preserve existing reviewed links and manual evidence. Running twice is harmless.
This never declares mastery, textbook corroboration, or device acceptance.
"""
import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parent
catalog_path = root / 'skills.json'
catalog = json.loads(catalog_path.read_text(encoding='utf-8'))
skills = catalog['skills']
assert len(skills) == 179 and len({s['id'] for s in skills}) == 179
assert all(s['unitId'] == s['id'].split('.')[0] for s in skills)
task_ids = {s['id']: f"M-{s['id'].replace('.', '-')}-1" for s in skills}
assert len(set(task_ids.values())) == 179

for skill in skills:
    sid = skill['id']
    task = task_ids[sid]
    skill['taskIds'] = list(dict.fromkeys([*skill['taskIds'], task]))
    skill['observableSuccess'] = list(dict.fromkeys([
        *skill.get('observableSuccess', []),
        '在单次对象分类任务中，将符合限定条件的数量、图形或表示放入托盘，移出不符对象并检查；仅证明本题的局部辨识。',
    ]))
    skill['coverageStatus'] = '有部分操作任务，六阶段及资料来源未验收'
    assert skill.get('releaseStatus') != 'published'

def update_csv(name, task_column, status):
    path = root.parent / 'docs' / name
    with path.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        fields, rows = reader.fieldnames, list(reader)
    assert len(rows) == 179 and {r['微技能ID'] for r in rows} == set(task_ids)
    if name == 'unit-skill-matrix.csv' and '对象辨识任务ID' not in fields:
        fields.insert(fields.index('操作任务ID') + 1, '对象辨识任务ID')
    for row in rows:
        task = task_ids[row['微技能ID']]
        if name == 'unit-skill-matrix.csv':
            row['操作任务ID'] = ';'.join(id for id in row['操作任务ID'].split(';') if id and id != task)
            row['对象辨识任务ID'] = task
        else:
            row[task_column] = ';'.join(dict.fromkeys([*filter(None, row[task_column].split(';')), task]))
        row['状态'] = status
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)

catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
update_csv('unit-skill-matrix.csv', '操作任务ID', '进行中（有单次对象分类；六阶段未验收）')
update_csv('source-map.csv', '网页任务ID', '进行中（单次对象分类已关联；原页、真题及六阶段待核）')
print('179 unique object-sorting task links; previous task links preserved; 0 published skills')
