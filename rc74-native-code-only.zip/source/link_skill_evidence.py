"""Manually curated partial links to *actual* operations; no mastery claim."""
import csv
import json
from pathlib import Path

LINKS = {
    'A01.02': ('A01-2', '选择10个散点入框，捆成十棒并判断总数不变'),
    'A03.01': ('A03-1', '在明确同一方格整体内点选指定份数'),
    'A05.03': ('A05-2', '从负数起点逐格跨过零并到达目标'),
    'R02.01': ('R02-1', '把钱币从总钱箱逐枚分给四个苹果'),
    'L01.03': ('L01-2', '天平左右同取、可撤销，并代回核等量'),
    'N03.02': ('N03-1', '在两个周期的可见时刻中找首个正重合'),
    'G07.01': ('G07-1', '从展开纸面逐面折起，连中心数出六个面'),
    'C01.02': ('F02', '从同一批人物中指认完整苹果组'),
    'C02.02': ('C02-1', '用搭配格逐格点选不同配对'),
    'C03.04': ('C03-2', '摆卡并逐条筛选A在B左边的所有顺序'),
    'D02.01': ('D02-1', '从多盘移物到少盘，保持总数并均分'),
    'D03.02': ('D03-2', '依顺序列出两次投掷的全部四种结果'),
    'S02.02': ('S02-3', '反复加减一对，观察奇偶不变'),
}

root = Path(__file__).resolve().parent
catalog_path = root / 'skills.json'
catalog = json.loads(catalog_path.read_text(encoding='utf-8'))
by_id = {skill['id']: skill for skill in catalog['skills']}
if set(LINKS) - set(by_id):
    raise ValueError('Unknown micro-skill ID')
if any(by_id[sid]['taskIds'] for sid in LINKS):
    raise ValueError('Refusing to overwrite reviewed links')
for sid, (task_id, observation) in LINKS.items():
    by_id[sid]['taskIds'] = [task_id]
    by_id[sid]['observableSuccess'] = [observation]
    by_id[sid]['coverageStatus'] = '有部分操作任务，六阶段及资料来源未验收'
catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

matrix = root.parent / 'docs' / 'unit-skill-matrix.csv'
with matrix.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    names, rows = reader.fieldnames, list(reader)
if len(rows) != 179:
    raise ValueError('Unexpected matrix size')
for row in rows:
    sid = row['微技能ID']
    if sid in LINKS:
        row['操作任务ID'] = LINKS[sid][0]
        row['状态'] = '进行中'
with matrix.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=names, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)

source = root.parent / 'docs' / 'source-map.csv'
with source.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    names, rows = reader.fieldnames, list(reader)
if len(rows) != 179:
    raise ValueError('Unexpected source map size')
for row in rows:
    sid = row['微技能ID']
    if sid in LINKS:
        row['网页任务ID'] = LINKS[sid][0]
        row['状态'] = '进行中（操作已关联；原页和真题待核）'
with source.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=names, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
print(f'{len(LINKS)} partial operation links curated; {len(by_id)-len(LINKS)} skills remain without reviewed task links')
