/* Link authored stage instances to the skill, evidence, and source matrices. */
'use strict';
const fs=require('fs');
const path=require('path');
const {readCsv}=require('./csv');
const {STAGED_TASKS}=require('./staged');
require('./fraction_staged');
require('./percent_staged');
require('./integer_staged');
require('./ratio_staged');
require('./rate_staged');
require('./journey_staged');
require('./scale_staged');
require('./equation_staged');
require('./constraint_staged');
require('./pattern_staged');
require('./coordinate_staged');
require('./grouping_staged');
require('./factor_staged');
require('./common_staged');
require('./cycle_staged');
require('./measure_staged');
require('./angle_staged');
require('./composite_staged');
require('./circle_staged');
require('./similar_staged');
require('./right_staged');
require('./solid_staged');
require('./sets_staged');
require('./invariant_staged');
require('./motion_staged');
require('./chance_staged');
require('./stats_staged');
require('./chart_staged');
require('./combin_staged');
const base=path.join(__dirname,'..');
const check=process.argv.includes('--check');
function output(file,body){
 if(check){if(fs.readFileSync(file,'utf8')!==body)throw Error('Stale: '+file)}
 else fs.writeFileSync(file,body);
}
function append(current,ids){return [...new Set([...String(current||'').split(';').filter(Boolean),...ids])].join(';')}
const skillFile=path.join(__dirname,'skills.json');
const skills=JSON.parse(fs.readFileSync(skillFile,'utf8'));
for(const skill of skills.skills){
 const tasks=STAGED_TASKS[skill.id];if(!tasks)continue;
 skill.taskIds=[...new Set([...skill.taskIds,...Object.values(tasks).map(t=>t.id)])];
 skill.coverageStatus=['A03.','A04.','A05.','R01.','R02.','R03.','R04.','L01.','L02.','L03.','L04.','N01.','N02.','N03.','N04.','G01.','G02.','G03.','G04.','G05.','G06.','G07.','C01.','C04.','S02.','S01.','D03.','D02.','D01.','C02.','C03.'].some(prefix=>skill.id.startsWith(prefix))?'有部分操作任务及阶段新实例；完整六阶段和资料来源未验收':'有部分操作任务及阶段新实例，六阶段和资料来源未验收';
}
output(skillFile,JSON.stringify(skills,null,2)+'\n');
function updateCsv(name,cb){
 const file=path.join(base,'docs',name),{fields,rows}=readCsv(fs.readFileSync(file,'utf8'));
 for(const row of rows){const tasks=STAGED_TASKS[row['微技能ID']];if(tasks)cb(row,tasks)}
 const q=s=>{const v=String(s??'');return /[,"\r\n]/.test(v)?'"'+v.replaceAll('"','""')+'"':v};
 output(file,'\ufeff'+fields.map(q).join(',')+'\n'+rows.map(row=>fields.map(f=>q(row[f])).join(',')).join('\n')+'\n');
}
updateCsv('unit-skill-matrix.csv',(row,tasks)=>{
 row['迁移任务ID']=append(row['迁移任务ID'],[tasks.transfer.id]);
 row['独立测验ID']=append(row['独立测验ID'],[tasks.independent.id,tasks.independent2.id]);
 row['隔日任务ID']=append(row['隔日任务ID'],[tasks.delayed.id]);
 row['状态']=['S02'].includes(row['单元'])?'进行中（条件与不变量操作和阶段实例已写定；完整六阶段与设备未验收）':['S01'].includes(row['单元'])?'进行中（空间变换与折剪操作和阶段实例已写定；完整六阶段与设备未验收）':['D03'].includes(row['单元'])?'进行中（概率与结果树操作和阶段实例已写定；完整六阶段与设备未验收）':['D02'].includes(row['单元'])?'进行中（统计与频数操作和阶段实例已写定；完整六阶段与设备未验收）':['D01'].includes(row['单元'])?'进行中（图表与刻度操作和阶段实例已写定；完整六阶段与设备未验收）':['C02', 'C03'].includes(row['单元'])?'进行中（搭配与排列操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='A03'?'进行中（分数操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='A04'?'进行中（百分数操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='A05'?'进行中（数轴与方格操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='R01'?'进行中（比与份数操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='R02'?'进行中（单位率操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='R03'?'进行中（行程操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='R04'?'进行中（比例缩放操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='L01'?'进行中（等量与未知数操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='L02'?'进行中（多步方程与整数约束操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='L03'?'进行中（模式与递推操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='L04'?'进行中（表格与坐标操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='N01'?'进行中（整除与数位操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='N02'?'进行中（因数与质数操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='N03'?'进行中（公因数与公倍数操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='N04'?'进行中（余数与循环操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='G01'?'进行中（长度周长与面积操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='G02'?'进行中（角与多边形操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='G03'?'进行中（剪拼与方块计数操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='G04'?'进行中（圆与弧操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='G05'?'进行中（相似与缩放操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='G06'?'进行中（直角平方与距离操作和阶段实例已写定；完整六阶段与设备未验收）':row['单元']==='G07'?'进行中（立体与展开操作和阶段实例已写定；完整六阶段与设备未验收）':['C01','C04'].includes(row['单元'])?'进行中（集合与补集操作和阶段实例已写定；完整六阶段与设备未验收）':'进行中（阶段新实例已写定；完整操作、六阶段及设备未验收）';
});
updateCsv('source-map.csv',(row,tasks)=>{
 row['网页任务ID']=append(row['网页任务ID'],Object.values(tasks).map(t=>t.id));
 row['状态']=['S02'].includes(row['单元'])?'进行中（条件与不变量操作和阶段实例已关联；原页、真题与六阶段待核）':['S01'].includes(row['单元'])?'进行中（空间变换与折剪操作和阶段实例已关联；原页、真题与六阶段待核）':['D03'].includes(row['单元'])?'进行中（概率与结果树操作和阶段实例已关联；原页、真题与六阶段待核）':['D02'].includes(row['单元'])?'进行中（统计与频数操作和阶段实例已关联；原页、真题与六阶段待核）':['D01'].includes(row['单元'])?'进行中（图表与刻度操作和阶段实例已关联；原页、真题与六阶段待核）':['C02', 'C03'].includes(row['单元'])?'进行中（搭配与排列操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='A03'?'进行中（分数操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='A04'?'进行中（百分数操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='A05'?'进行中（数轴与方格操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='R01'?'进行中（比与份数操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='R02'?'进行中（单位率操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='R03'?'进行中（行程操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='R04'?'进行中（比例缩放操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='L01'?'进行中（等量与未知数操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='L02'?'进行中（多步方程与整数约束操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='L03'?'进行中（模式与递推操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='L04'?'进行中（表格与坐标操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='N01'?'进行中（整除与数位操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='N02'?'进行中（因数与质数操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='N03'?'进行中（公因数与公倍数操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='N04'?'进行中（余数与循环操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='G01'?'进行中（长度周长与面积操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='G02'?'进行中（角与多边形操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='G03'?'进行中（剪拼与方块计数操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='G04'?'进行中（圆与弧操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='G05'?'进行中（相似与缩放操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='G06'?'进行中（直角平方与距离操作和阶段实例已关联；原页、真题与六阶段待核）':row['单元']==='G07'?'进行中（立体与展开操作和阶段实例已关联；原页、真题与六阶段待核）':['C01','C04'].includes(row['单元'])?'进行中（集合与补集操作和阶段实例已关联；原页、真题与六阶段待核）':'进行中（阶段新实例已关联；原页、真题与六阶段仍待核）';
});
console.log(`${check?'Checked':'Updated'} ${Object.keys(STAGED_TASKS).length} authored skill families across three ledgers.`);
