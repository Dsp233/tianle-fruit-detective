"""Bind authored A01/A02 operations and individually audited old-route actions.

This links concrete task instances only; it never promotes a micro-skill to mastery.
"""
import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parent
links = {
    'A01.01': (['O-A01-01-1'], '逐颗摆出与图卡一一对应的四颗圆点，可放回'),
    'A01.02': (['A01-2'], '任选十个散点放框并捆成十棒，总数不变'),
    'A01.03': (['A01-1'], '分别点出十棒与个位圆点，形成两位数'),
    'A01.04': (['O-A01-04-1'], '在相同十棒的两盘中添一个一，比较个位大小'),
    'A01.05': (['A01-2', 'O-A01-05-1'], '将2十3一逆向拆为1十13一并能重新捆回'),
    'A02.01': (['O-A02-01-1'], '从七颗中逐颗拿走三颗，能逐颗放回'),
    'A02.02': (['A02-1'], '逐格补满十格板，能撤销补点'),
    'A02.03': (['O-A02-03-1'], '先逐颗加三再逐颗减三，记录返回起点'),
    'A02.04': (['O-A02-04-1'], '将十二颗逐颗摆入三盘，形成三组相同的四颗'),
    'A02.05': (['O-A02-05-1'], '将十二颗逐颗平均分到三盘，每盘四颗'),
    'A02.06': (['O-A02-06-1'], '先给第一组添二，再复制整组，区分运算顺序'),
}
route_links = {
    'A03.03': (['A03-7'], '把同整体分数卡按数值从小到大排放'),
    'A04.01': (['A04-2'], '在明确二十格整体内点亮五格'),
    'L03.01': (['L03-1'], '用红蓝卡补完重复节的后续位置'),
    'L03.02': (['L03-5'], '依据相同差值续摆两张数卡'),
    'N03.01': (['N03-1'], '观察两条周期亮灯线并点正公倍数重合时刻'),
    'G01.02': (['G01-1'], '沿长方形外边逐段点选周长边'),
    'G03.02': (['G03-1'], '在四乘四格上点出右下两乘二被剪区'),
    'G07.04': (['G07-4'], '在纸盒展开六面图上点出与中心相对的一面'),
    'C01.03': (['F09'], '选三块互斥区域拼不同人数式'),
    'C01.04': (['F10'], '选一整组再补未数过区域，拼另一等值式'),
    'C01.05': (['F11'], '两整组相加后在式中扣去一次交集'),
    'C02.01': (['C02-1'], '固定帽子行、逐格生成鞋子的不同组合'),
    'C02.03': (['C02-3'], '逐格填满两帽三鞋的全部搭配'),
    'C02.04': (['C02-1'], '格表中同一组合只记一次，重复选项不得新增'),
    'C03.01': (['C03-1'], '逐次交换卡位并记录不同队列'),
    'C03.02': (['C03-1'], '把三张卡摆出六种不同顺序并逐一记录'),
    'C03.03': (['C03-3'], '从三种水果中无序取二并去掉反序重复'),
    'C03.05': (['C03-1'], '逐次摆出并登记三人全排列，核对遗漏'),
    'D02.02': (['D02-1'], '移动2、4、6三盘的点使每盘均为4'),
    'S02.03': (['S02-4'], '从12起每步合法拿走2个并记录各步'),
    'S02.04': (['S02-3'], '从3起反复加一对并观察数量变化与奇偶不变'),
}
assert not set(route_links) & set(links)
links.update(route_links)
catalog_path = root / 'skills.json'
catalog = json.loads(catalog_path.read_text(encoding='utf-8'))
by_id = {s['id']: s for s in catalog['skills']}
assert set(links) <= set(by_id) and len(links) == 32
for sid, (ids, observation) in links.items():
    skill = by_id[sid]
    skill['taskIds'] = list(dict.fromkeys([*skill['taskIds'], *ids]))
    skill['observableSuccess'] = list(dict.fromkeys([*skill.get('observableSuccess', []), observation]))
    assert skill.get('releaseStatus') != 'published'

def update(name, field):
    path = root.parent / 'docs' / name
    with path.open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        fields, rows = reader.fieldnames, list(reader)
    assert len(rows) == 179
    for row in rows:
        sid = row['微技能ID']
        if sid in links:
            row[field] = ';'.join(dict.fromkeys([*filter(None, row[field].split(';')), *links[sid][0]]))
            if name == 'unit-skill-matrix.csv' and sid in {'A01.01','A01.04','A01.05','A02.01','A02.03','A02.04','A02.05','A02.06'}:
                task_id = f"O-{sid.replace('.', '-')}-1"
                row['解释任务ID'] = ';'.join(dict.fromkeys([*filter(None, row['解释任务ID'].split(';')), task_id]))
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields, lineterminator='\n')
        writer.writeheader();writer.writerows(rows)

catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
update('unit-skill-matrix.csv', '操作任务ID')
update('source-map.csv', '网页任务ID')
print('11 A01/A02 skills and 21 further skills linked to specific operations; old partial links retained')
