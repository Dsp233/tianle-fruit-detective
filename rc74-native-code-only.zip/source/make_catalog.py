"""Turn the reviewed working ledger into compact, original metadata for the parent index."""
import argparse
import csv
import json
import re
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--ledger', type=Path, required=True)
parser.add_argument('--architecture', type=Path, required=True)
parser.add_argument('--output', type=Path, default=Path(__file__).with_name('catalog.json'))
args = parser.parse_args()

architecture = args.architecture.read_text(encoding='utf-8')
topics = [{'code': code, 'title': title.strip()} for code, title in re.findall(
    r'^\| ([ARLNGCDS]\d\d) ([^|]+?) \|', architecture, re.M)]
assert len(topics) == 33 and len({x['code'] for x in topics}) == 33
with args.ledger.open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.DictReader(f))
assert len(rows) == 500
entries = [{
    'year': int(row['年份']),
    'no': int(row['题号']),
    'code': row['主要单元'],
    'summary': row['题意结构摘要（非原题）'],
    'reviewed': row['答案核验'] == '已独立求解并与授权答案表一致',
} for row in rows]
assert len({(e['year'], e['no']) for e in entries}) == 500
assert all(e['code'] in {t['code'] for t in topics} for e in entries)
assert sum(e['reviewed'] for e in entries) == 36
args.output.write_text(json.dumps({'topics': topics, 'entries': entries}, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
print('Wrote', len(topics), 'units and', len(entries), 'question positions')
