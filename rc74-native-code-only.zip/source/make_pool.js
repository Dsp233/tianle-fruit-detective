'use strict';
const fs=require('fs'),path=require('path'),{boot}=require('./test_support'),{solveStage}=require('./test_solutions'),{modelAR}=require('./pool_spec'),{modelLN}=require('./pool_spec_ln'),{modelG}=require('./pool_spec_g'),{modelCDS}=require('./pool_spec_cds');
const root=__dirname,b=boot(),all=b.value('Object.fromEntries(SKILL_DATA.skills.map(s=>[s.id,{practice:practiceFor(s.id).task,stages:STAGED_TASKS[s.id]}]))'),foundation=b.value('FOUNDATION_DEMOS');
const pools={},demos={...foundation},blocked=[],coverage=[],contentVersion=require('./version.json').contentRevision;
function traceTask(t){
 b.ctx.__case=t;b.run('draft=freshDraft();delete saved.taskHistory[taskVersion(__case)+":"+__case.id];');const trace=[];
 const actor={last:null,click(action,data={}){
  if(action==='check'){const result=b.value('taskAdapter(__case).grade(__case)');this.last={gradingResult:result.ok?'correct':'incorrect',operationSummary:b.value('draft.work')};return}
  b.ctx.__action=action;b.ctx.__data=data;const changed=b.run('taskAdapter(__case).act(__action,__data,__case)');if(changed)trace.push({action,data});
 }};
 solveStage(actor,t);if(!trace.length)throw Error('empty manipulation trace');return trace;
}
for(const [sid,m] of Object.entries(all)){
 if(foundation[sid]){demos[sid].demoSteps=traceTask(demos[sid]);coverage.push({skillId:sid,pool:8,demo:true,semanticValidation:true});continue}

 const used=new Set([m.practice,...['transfer','independent','independent2','delayed'].map(k=>m.stages[k])].map(t=>{b.ctx.__finger=t;return b.value('taskFingerprint(__finger)')}));
 const made=[];
 for(let k=1;k<=120&&made.length<5;k++){
  const params=(/^[AR]/.test(sid)?modelAR:/^[LN]/.test(sid)?modelLN:/^G/.test(sid)?modelG:modelCDS)({...m.stages.independent,skillId:sid},k),i=made.length,kind=['independent3','independent4','delayed7','delayed21','demo'][i];
  const t={...params,id:`${kind==='demo'?'D':'T'}-${sid.replace('.','-')}-${kind==='demo'?1:5+i}`,skillId:sid,contentVersion,phase:kind==='demo'?'学':kind.startsWith('delayed')?'巩固':'测',authorship:'原创儿童操作适配',changeDimension:'有限参数新实例；不凭换数宣称迁移',generation:{profile:('AR'.includes(sid[0])?'AR':'LN'.includes(sid[0])?'LN':sid[0]==='G'?'G':'CDS')+'-v1',seed:k,parameters:params}};
  b.ctx.__case=t;b.run('normaliseFormalPercent(__case);normaliseFormalMotion(__case)');Object.assign(t,b.value('__case'));b.ctx.__finger=t;const fp=b.value('taskFingerprint(__finger)');if(used.has(fp))continue;
  try{const trace=traceTask(t);used.add(fp);if(kind==='demo'){t.demoSteps=trace;t.demoNarration=t.prompt+' '+t.explain;demos[sid]=t}else{pools[sid]??={};pools[sid][kind]=t}made.push(t)}catch(error){if(k===120)blocked.push({skillId:sid,reason:String(error.message).slice(0,600)});}
 }
 if(made.length<5)blocked.push({skillId:sid,reason:`仅生成${made.length}/5个不同且可解的模型`});
 coverage.push({skillId:sid,pool:4+Object.keys(pools[sid]||{}).length,demo:!!demos[sid],semanticValidation:made.length===5});
}
const payload="'use strict';\n// Generated finite cases. Rebuild with make_pool.js; all emitted cases have a verified legal solution trace.\nconst GENERATED_POOLS="+JSON.stringify(pools,null,1)+";\nconst DEMO_TASKS="+JSON.stringify(demos,null,1)+";\nconst generatedTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;\nfor(const [sid,tasks] of Object.entries(GENERATED_POOLS))Object.assign(generatedTarget[sid],tasks);\nconst normaliseGeneratedPercent=typeof module!=='undefined'?require('./transfer_enrichment').normaliseFormalPercent:normaliseFormalPercent;\nfor(const tasks of Object.values(generatedTarget))for(const t of Object.values(tasks))normaliseGeneratedPercent(t);\nconst normaliseGeneratedMotion=typeof module!=='undefined'?require('./motion_ui').normaliseFormalMotion:normaliseFormalMotion;\nfor(const tasks of Object.values(generatedTarget))for(const t of Object.values(tasks))normaliseGeneratedMotion(t);\nif(typeof module!=='undefined')module.exports={GENERATED_POOLS,DEMO_TASKS};\n";
fs.writeFileSync(path.join(root,'pool_tasks.js'),payload);
fs.mkdirSync(path.join(root,'../docs/evidence/2026-10-03-m3-pools'),{recursive:true});
fs.writeFileSync(path.join(root,'../docs/evidence/2026-10-03-m3-pools/generation.json'),JSON.stringify({contentVersion,generatedSkills:Object.keys(pools).length,demonstrations:Object.keys(demos).length,coverage,remaining:blocked,claim:'State/goal verification only; no browser/iPad or complete transfer/source claim'},null,2)+'\n');
console.log(`Generated ${Object.keys(pools).length} expanded pools and ${Object.keys(demos).length} real demonstration traces; ${blocked.length} skills remain.`);
