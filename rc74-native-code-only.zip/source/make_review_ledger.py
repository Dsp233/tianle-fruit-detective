"""Initialize a per-problem review ledger without upgrading answer lookup to review."""
import argparse
import csv
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ledger', required=True, type=Path)
    args = parser.parse_args()
    with args.ledger.open(encoding='utf-8-sig', newline='') as stream:
        original = list(csv.DictReader(stream))
    if len(original) != 500 or len({(row['年份'], row['题号']) for row in original}) != 500:
        raise ValueError('Expected 500 distinct year-number positions')
    columns = ['examId', 'year', 'problemNumber', 'sourceFile', 'sourcePage',
               'originalConditionsSummary', 'referenceAnswer', 'answerSource',
               'derivedAnswer', 'independentSolution', 'figureChecked',
               'comparison', 'primaryUnit', 'auxiliaryUnits', 'microSkillIds',
               'reasoningActions', 'alternativeValidMethods',
               'childAdaptationStatus', 'reviewStatus', 'reviewerMethod',
               'reviewedAt', 'unresolvedIssues']
    target = Path(__file__).resolve().parent.parent / 'docs' / 'exam-review-ledger.csv'
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise FileExistsError('Review ledger already exists; never overwrite accumulated evidence')
    reviewed = 0
    with target.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, lineterminator='\n')
        writer.writeheader()
        for old in original:
            evidence = old['独立复核说明'].strip()
            independently_solved = old['答案核验'] == '已独立求解并与授权答案表一致' and bool(evidence)
            if independently_solved:
                reviewed += 1
            writer.writerow({
                'examId': f"AMC8-{old['年份']}-{int(old['题号']):02d}",
                'year': old['年份'], 'problemNumber': old['题号'],
                'sourceFile': old['来源文件'], 'sourcePage': old['附件PDF起始页'],
                'originalConditionsSummary': old['题意结构摘要（非原题）'],
                'referenceAnswer': old['参考答案（选项）'],
                'answerSource': old['参考答案来源'],
                'derivedAnswer': '',
                'independentSolution': evidence if independently_solved else '',
                'figureChecked': '待逐题确认', 'comparison': old['答案核验'],
                'primaryUnit': old['主要单元'],
                'auxiliaryUnits': old['辅助单元'],
                'microSkillIds': '', 'reasoningActions': old['思维动作'],
                'alternativeValidMethods': '', 'childAdaptationStatus': '待审校',
                'reviewStatus': '旧记录有独立求解线索，待核对原题与证据' if independently_solved else '待独立复核',
                'reviewerMethod': '', 'reviewedAt': '', 'unresolvedIssues': ''
            })
    if reviewed != 36:
        raise ValueError('Old independent-solution count changed; inspect it before claiming a count')
    print(f'500 positions; {reviewed} historical solution notes pending evidence check; {500-reviewed} pending independent review')


if __name__ == '__main__':
    main()
