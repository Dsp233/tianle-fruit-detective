"""Create a traceable starting micro-skill inventory from the approved V12 plan.

The plan is an input to this audit command. Runtime builds consume skills.json,
so the published site never relies on files outside the repository.
"""
import argparse
import csv
import json
import re
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--force', action='store_true', help='replace existing catalog and audit matrices')
    args = parser.parse_args()
    text = args.plan.read_text(encoding='utf-8')
    matrix = text.split('## 8. 33 单元全量实施矩阵', 1)[1].split('## 9.', 1)[0]
    root = Path(__file__).resolve().parent
    existing = json.loads((root / 'catalog.json').read_text(encoding='utf-8'))
    title_by_code = {t['code']: t['title'] for t in existing['topics']}
    units = []
    skills = []
    for raw in matrix.splitlines():
        match = re.match(r'^\| ([ARLNGCDS]\d{2}) ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \|$', raw)
        if not match:
            continue
        code, title, skill_list, operation, transfer, book = (x.strip() for x in match.groups())
        if code not in title_by_code:
            raise ValueError('Unknown unit: ' + code)
        names = [n.strip() for n in skill_list.split('；')]
        if not all(names) or len(names) < 3:
            raise ValueError('Empty or insufficient micro-skills: ' + code)
        ids = []
        for i, name in enumerate(names, 1):
            sid = f'{code}.{i:02d}'
            ids.append(sid)
            skills.append({'id': sid, 'unitId': code, 'title': name,
                           'prerequisiteIds': [], 'taskIds': [],
                           'bookReferences': [], 'examReferences': [],
                           'coverageStatus': '待逐项设计和验收'})
        units.append({'id': code, 'title': title_by_code[code], 'skillIds': ids,
                      'operationGoal': operation, 'transferGoal': transfer,
                      'bookEntryPoint': book})
    if len(units) != 33 or {u['id'] for u in units} != set(title_by_code):
        raise ValueError('The approved plan must have exactly the same 33 units as the site')
    targets = [root / 'skills.json', root.parent / 'docs' / 'unit-skill-matrix.csv',
               root.parent / 'docs' / 'source-map.csv']
    if not args.force and any(path.exists() for path in targets):
        raise FileExistsError('Catalog/matrix exists; preserve review edits, or pass --force intentionally')
    links = {
        'A01.02': ['A01.01'], 'A01.03': ['A01.02'],
        'A02.01': ['A01.01'], 'A02.02': ['A01.02'],
        'A03.02': ['A03.01'], 'A03.03': ['A03.02'],
        'A03.04': ['A03.03'], 'A03.05': ['A03.04'],
        'A04.01': ['A03.01'], 'A05.02': ['A05.01'],
        'R01.01': ['A01.01'], 'R02.01': ['R01.01'],
        'R03.01': ['R02.01'], 'L01.01': ['A02.01'],
        'L02.01': ['L01.01'], 'N01.01': ['A02.01'],
        'N02.01': ['N01.01'], 'N03.01': ['N01.01'],
        'G03.01': ['G01.03'], 'G04.02': ['G04.01'],
        'G05.03': ['G01.03'], 'G06.02': ['G06.01'],
        'G07.03': ['G07.01'], 'C02.01': ['C01.01'],
        'C03.01': ['C02.01'], 'C04.01': ['C01.01'],
        'D02.02': ['D02.01'], 'D03.02': ['C02.03'],
        'S01.02': ['S01.01'], 'S02.03': ['S02.02'],
    }
    by_id = {s['id']: s for s in skills}
    if len(by_id) != len(skills):
        raise ValueError('Duplicate micro-skill ID')
    for sid, prerequisites in links.items():
        if sid not in by_id or any(p not in by_id for p in prerequisites):
            raise ValueError('Invalid prerequisite ID: ' + sid)
        by_id[sid]['prerequisiteIds'] = prerequisites
    def visit(sid, active, done):
        if sid in active:
            raise ValueError('Prerequisite cycle at ' + sid)
        if sid not in done:
            for dep in by_id[sid]['prerequisiteIds']:
                visit(dep, active | {sid}, done)
            done.add(sid)
    done = set()
    for sid in by_id:
        visit(sid, set(), done)
    result = {'schemaVersion': 1, 'units': units, 'skills': skills,
              'meaning': 'An inventory and design backlog; listing a skill does not mean it is taught or mastered.'}
    (root / 'skills.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    target = root.parent / 'docs' / 'unit-skill-matrix.csv'
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('w', encoding='utf-8-sig', newline='') as file:
        writer = csv.writer(file, lineterminator='\n')
        writer.writerow(['单元', '微技能ID', '微技能', '先修ID', '示范任务ID', '操作任务ID',
                         '解释任务ID', '迁移任务ID', '独立测验ID', '隔日任务ID', '教材证据', '真题证据', '状态'])
        for skill in skills:
            writer.writerow([skill['unitId'], skill['id'], skill['title'],
                             ';'.join(skill['prerequisiteIds']), '', '', '', '', '', '', '', '', '未开始'])
    unit_by_id = {unit['id']: unit for unit in units}
    source_map = root.parent / 'docs' / 'source-map.csv'
    with source_map.open('w', encoding='utf-8-sig', newline='') as file:
        writer = csv.writer(file, lineterminator='\n')
        writer.writerow(['单元', '微技能ID', '参考书检索起点', '对应方法与适用条件',
                         '原页逐项核实', '网页任务ID', 'AMC真题题位ID', '真题独立复核', '状态'])
        for skill in skills:
            writer.writerow([skill['unitId'], skill['id'], unit_by_id[skill['unitId']]['bookEntryPoint'],
                             '', '待核对', '', '', '待核对', '未开始'])
    print(f'{len(units)} units; {len(skills)} planned micro-skills; {len(links)} prerequisite links')


if __name__ == '__main__':
    main()
