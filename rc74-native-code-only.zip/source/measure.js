'use strict';
function measureRectangle(rows,cols){return Array.from({length:rows},(_,r)=>Array.from({length:cols},(_,c)=>[r,c])).flat()}
const MEASURE_TASKS={
 'G01.01':{kind:'length',unitSize:1,unit:'cm',start:0,end:4,max:6,context:'用单位段量线',prompt:'红线从0厘米到4厘米。每个单位段长1厘米；把单位段首尾接在红线下的刻度槽中，不能留空或超出。',explain:'用4个连续的1厘米段，长度4厘米。',reason:{prompt:'为什么不能只数段数而不看位置？',options:['单位段要连续覆盖目标线，空隙不能算长度','段摆在哪里都能量同一根线','小格内部面积就是线长'],answer:0}},
 'G01.02':{kind:'perimeter',rows:2,cols:3,cells:measureRectangle(2,3),unitSize:1,unit:'cm',context:'沿外边描一圈',prompt:'沿2×3方格图真正的外边逐段描一圈，内部格子分界线不能算进去。每小段1厘米。',explain:'外边3＋2＋3＋2＝10厘米；内部线不属于周长。',reason:{prompt:'周长描的是哪一部分？',options:['目标图形的全部外围边','所有可见分格线','涂色小格的个数'],answer:0}},
 'G01.03':{kind:'area',rows:2,cols:3,cells:measureRectangle(2,3),unitSize:1,unit:'cm',context:'铺满目标面积',prompt:'用单位方格逐格铺满2行3列的目标图。每格边长1厘米，不能漏铺或铺到目标外。',explain:'6个单位方格覆盖6平方厘米。',reason:{prompt:'面积为什么用平方厘米？',options:['每个单位方格是1厘米乘1厘米的一片覆盖','因为外边有6条','线段也要用平方厘米'],answer:0}},
 'G01.04':{kind:'units',rows:2,cols:3,cells:measureRectangle(2,3),unitSize:1,unit:'cm',context:'同一图的两种测量',prompt:'同一2×3图，每格边长1厘米。实际描全部外边并铺满内部，再分别为长度和面积选单位。',explain:'外边共10厘米；内部6平方厘米，长度单位和面积单位不同。',reason:{prompt:'同一张图为什么要用两个单位？',options:['外边量一维长度，内部量二维覆盖','只要同一图就必须同单位','面积与周长都只数外边'],answer:0}},
 'G01.05':{kind:'rearrange',rows:4,cols:4,total:12,reference:measureRectangle(3,4),goal:'sameAreaDifferentPerimeter',unitSize:1,unit:'cm',context:'重排同一批单位格',prompt:'参考图是3×4共12格。把同一批12格实际重排成连通、没有封闭空洞的新图，再描新图外边，使面积相同、周长不同。',explain:'仍用12格，面积保持12平方厘米；新外边长度可改变，例如每行4、4、2、2格的新图周长16厘米。',reason:{prompt:'为什么重排后面积相同但周长可变？',options:['单位格数量不变，但相邻关系和暴露外边改变','面积只由外边决定','转动3×4就一定改变周长'],answer:0}}
};
for(const [skillId,t] of Object.entries(MEASURE_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:71,mode:'measureLab',phase:'练',hint:'长度连续接单位段；周长只描外边；面积铺内部格。重排时保留单位格数量并重新描边。'});
if(typeof module!=='undefined')module.exports={MEASURE_TASKS,measureRectangle};
