'use strict';
const measureStageRectangle=typeof module!=='undefined'?require('./measure').measureRectangle:measureRectangle;
const MEASURE_CASES={
 'G01.01':[
  [{kind:'length',unitSize:2,unit:'cm',start:1,end:4,max:5,context:'二厘米单位段'},'红线从2到8厘米，每段2厘米。实际把单位段接在红线下，核对连续覆盖。','3段共6厘米；长度不等于段数3。','单位段变2厘米且起点不为0'],
  [{kind:'length',unitSize:1,unit:'cm',start:2,end:5,max:6,context:'非零起点尺子'},'独立用1厘米段连续覆盖从2到5厘米的红线。','3厘米，不是终点刻度5厘米。','无提示：非零起点'],
  [{kind:'length',unitSize:2,unit:'cm',start:0,end:4,max:5,context:'隔日八厘米线'},'隔日用2厘米段连续覆盖从0到8厘米红线。','4段，长度8厘米。','隔日：2厘米单位段'],
  [{kind:'length',unitSize:1,unit:'cm',start:1,end:6,max:7,context:'一到六厘米'},'独立把单位段连续接在1到6厘米的红线下。','5厘米。','备用：两个端点都不为0']
 ],
 'G01.02':[
  [{kind:'perimeter',rows:3,cols:3,cells:[[0,0],[1,0],[2,0],[2,1]],unitSize:1,unit:'cm',context:'L形外边'},'沿L形目标的外边实际逐段描一圈；凹进去的边也属于外围，内部格线不算。','4格L形的外围10厘米。','长方形换缺角L形，包含凹边'],
  [{kind:'perimeter',rows:2,cols:2,cells:measureStageRectangle(2,2),unitSize:1,unit:'cm',context:'方形外边'},'独立描2×2目标的全部外边。','周长8厘米。','无提示：正方形'],
  [{kind:'perimeter',rows:2,cols:4,cells:measureStageRectangle(2,4),unitSize:1,unit:'cm',context:'较长的图'},'隔日描2×4目标的全部外边，不计内部格线。','周长12厘米。','隔日：长边4格'],
  [{kind:'perimeter',rows:3,cols:2,cells:[[0,0],[0,1],[1,0],[2,0],[2,1]],unitSize:1,unit:'cm',context:'侧面缺格图'},'独立描侧面缺一格目标的完整外边，沿凹口绕行。','5格目标的外围12厘米。','备用：侧面凹口']
 ],
 'G01.03':[
  [{kind:'area',rows:3,cols:3,cells:measureStageRectangle(3,3).filter(([r,c])=>r!==2||c!==2),unitSize:1,unit:'cm',context:'缺一角的覆盖'},'逐格铺满灰色目标；右下缺角不是目标，不能铺进去。','8单位格，8平方厘米。','完整长方形换缺角形，外面空格不可算面积'],
  [{kind:'area',rows:3,cols:2,cells:measureStageRectangle(3,2),unitSize:1,unit:'cm',context:'三行两列'},'独立用单位格铺满3行2列目标。','6平方厘米。','无提示：交换行列'],
  [{kind:'area',rows:3,cols:3,cells:[[0,0],[1,0],[2,0],[2,1]],unitSize:1,unit:'cm',context:'L形铺格'},'隔日用单位格铺满L形灰色目标，不铺轮廓外。','4平方厘米。','隔日：不规则覆盖'],
  [{kind:'area',rows:3,cols:3,cells:[[0,0],[0,1],[1,0],[1,1],[2,0]],unitSize:1,unit:'cm',context:'五格目标'},'独立逐格铺满五格灰色目标。','5平方厘米。','备用：末行只有一格']
 ],
 'G01.04':[
  [{kind:'units',rows:2,cols:2,cells:measureStageRectangle(2,2),unitSize:1,unit:'m',context:'米格花园'},'每格边长1米。实际描外边、铺内部，再为两种量分别选单位。','外边8米，内部4平方米。','厘米格换米格，两个单位要同步换'],
  [{kind:'units',rows:2,cols:2,cells:measureStageRectangle(2,2),unitSize:2,unit:'cm',context:'二厘米格'},'独立描边并铺满每格边长2厘米的2×2图，再选长度与面积单位。','外边16厘米，面积16平方厘米；两个16也用不同单位。','无提示：数值相同但量纲不同'],
  [{kind:'units',rows:3,cols:3,cells:[[0,0],[1,0],[2,0],[2,1]],unitSize:1,unit:'cm',context:'隔日L形单位'},'隔日对1厘米格L形目标实际描边、铺满内部，并分别选单位。','外边10厘米，内部4平方厘米。','隔日：不规则形仍区分单位'],
  [{kind:'units',rows:2,cols:3,cells:measureStageRectangle(2,3),unitSize:3,unit:'m',context:'三米格庭院'},'独立在每格边长3米的2×3图描外边、铺内部并选单位。','外边30米，内部54平方米。','备用：米格边长3，平方单位不能用米']
 ],
 'G01.05':[
  [{kind:'rearrange',rows:3,cols:4,total:8,reference:measureStageRectangle(3,3),goal:'samePerimeterDifferentArea',unitSize:1,unit:'cm',context:'反过来同周长'},'参考图3×3共9格、周长12。现在用8格实际摆成连通无洞的新图并描边，要求周长相同、面积不同。','例如2×4图用8格，周长12，与9格参考图同周长不同面积。','把同面积异周长反过来改成同周长异面积'],
  [{kind:'rearrange',rows:3,cols:4,total:6,reference:measureStageRectangle(2,3),goal:'sameAreaDifferentPerimeter',unitSize:1,unit:'cm',context:'六格自由重排'},'独立重排参考2×3的同一批6格，保持连通无洞，描新边使面积相同但周长不同。','例如两行4格、2格，面积6，周长12不同于参考10。','无提示：较少原材料'],
  [{kind:'rearrange',rows:4,cols:4,total:8,reference:measureStageRectangle(2,4),goal:'sameAreaDifferentPerimeter',unitSize:1,unit:'cm',context:'八格隔日重排'},'隔日把参考2×4的同一批8格实际重排成连通无洞图，再描边使周长改变。','单位格仍8；连通新图可以暴露更多外边。','隔日：八格材料与不同参考周长'],
  [{kind:'rearrange',rows:4,cols:4,total:12,reference:measureStageRectangle(2,6),goal:'sameAreaDifferentPerimeter',unitSize:1,unit:'cm',context:'十二格备用布局'},'独立重排参考2×6的12格，保持连通无洞并描边，使面积同但周长不同；旋转原矩形不够。','例如3×4矩形用12格，周长14不同于参考16。','备用：原材料与旋转反例']
 ]
};
const measureStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(MEASURE_CASES)){
 if(cases.length!==4)throw Error('Four G01 cases required: '+skillId);measureStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];measureStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:71,mode:'measureLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'用单位材料实际覆盖、描边或重排，分别检查数量与外边关系。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={MEASURE_CASES};
