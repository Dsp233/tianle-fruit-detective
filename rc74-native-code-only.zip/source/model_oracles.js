'use strict';
// Independent exact/discrete mathematics for parameter-model review.
// No imports of UI graders, expected-answer functions or production geometry.
const assert=require('assert');
const eq=(a,b,msg)=>assert.deepStrictEqual(a,b,msg),near=(a,b,msg)=>assert(Math.abs(a-b)<1e-8,msg+': '+a+' vs '+b);
function netValid(cells){const vec=(a,s)=>a.map(x=>x*s),add=(...a)=>a[0].map((_,i)=>a.reduce((n,v)=>n+v[i],0)),same=(a,b)=>JSON.stringify(a)===JSON.stringify(b),frames=new Map([[cells[0].join(','),{c:[0,0,0],u:[1,0,0],v:[0,1,0],n:[0,0,1]}]]),queue=[cells[0]];while(queue.length){const p=queue.shift(),f=frames.get(p.join(','));for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const q=[p[0]+dx,p[1]+dy],key=q.join(',');if(!cells.some(c=>same(c,q)))continue;const u=dx?vec(f.n,dx):f.u,v=dy?vec(f.n,dy):f.v,n=dx?vec(f.u,-dx):vec(f.v,-dy),c=add(f.c,vec(dx?f.u:f.v,dx||dy),vec(dx?u:v,dx||dy)),nf={c,u,v,n};if(frames.has(key)){if(!same(frames.get(key),nf))return false}else{frames.set(key,nf);queue.push(q)}}}return cells.length===6&&frames.size===6&&new Set([...frames.values()].map(f=>f.n.join(','))).size===6&&new Set([...frames.values()].map(f=>f.c.join(','))).size===6}
function surfaceCount(cells){let pairs=0;for(let i=0;i<cells.length;i++)for(let j=i+1;j<cells.length;j++)if(cells[i].reduce((n,x,k)=>n+Math.abs(x-cells[j][k]),0)===1)pairs++;return 6*cells.length-2*pairs}
function enumerate(m){const size=m.type==='pair'?2:m.size,choices=m.type==='pair'?[m.first,m.second]:Array(size).fill(m.items),out=new Map();function walk(tuple){if(tuple.length<size){for(const p of choices[tuple.length])walk([...tuple,p.id]);return}if(m.type==='pair'){if((m.forbidden||[]).some(f=>f.every((x,i)=>x===tuple[i])))return}else{if(!m.repeat&&new Set(tuple).size!==size)return;if(m.noLeading&&tuple[0]===m.noLeading||m.include&&!tuple.includes(m.include))return;for(const [i,id] of Object.entries(m.fixed||{}))if(tuple[+i]!==id)return;for(const [kind,allowed] of [['adjacent',true],['separate',false]])if(m[kind]){const pos=m[kind].map(id=>tuple.indexOf(id));if(pos.some(i=>i<0)||(Math.abs(pos[0]-pos[1])===1)!==allowed)return}}const canonical=m.type==='order'&&!m.ordered?[...tuple].sort((a,b)=>m.items.findIndex(p=>p.id===a)-m.items.findIndex(p=>p.id===b)):tuple;out.set(JSON.stringify(canonical),canonical)}walk([]);return [...out.values()]}
function event(m,tuple){const v=tuple.map((id,i)=>(i?m.second:m).atoms.find(p=>p.id===id)),e=m.event;switch(e.type){case 'all':return true;case 'color':return v[0].color===e.color;case 'even':return +v[0].color%2===0;case 'atLeast':return +v[0].color>=e.value;case 'exact':return v.filter(p=>p.color===e.color).length===e.count;case 'atLeastCount':return v.filter(p=>p.color===e.color).length>=e.count;case 'both':return v.every(p=>p.color===e.color);case 'same':return v.every(p=>p.color===v[0].color);case 'firstEvenSecond':return +v[0].color%2===0&&v[1].color===e.color;default:throw Error('Unsupported event '+e.type)}}
function chanceSpace(m){const tuples=[];for(const a of m.atoms)if(!m.second)tuples.push([a.id]);else for(const b of m.second.atoms)if(m.replacement!==false||a.id!==b.id)tuples.push([a.id,b.id]);return tuples}
function measuredOuter(cells){const keys=new Set(cells.map(c=>c.join(',')));return cells.reduce((n,[r,c])=>n+[[r-1,c],[r+1,c],[r,c-1],[r,c+1]].filter(p=>!keys.has(p.join(','))).length,0)}
function verify(t,w){const msg=t.id+' independent mathematical check';
 if(t.mode==='measureLab'){const cells=t.kind==='rearrange'?Object.keys(w.tiles).map(s=>s.split(',').map(Number)):t.cells||[];const P=t.kind==='length'?(t.end-t.start)*t.unitSize:measuredOuter(cells)*t.unitSize,A=cells.length*t.unitSize**2;if(t.kind!=='area')near(w.amounts.length,P,msg+' length');if(t.kind!=='length'&&t.kind!=='perimeter')near(w.amounts.area,A,msg+' area')}
 if(t.mode==='solidLab'){if(t.nets){for(const [i,net] of t.nets.entries()){const valid=netValid(net);if(t.kind==='valid')eq(w.nets[i].choice,valid?'valid':'invalid',msg);else assert(valid,msg+' valid cube');if(t.kind==='counts')eq(w.nets[i].counts,{faces:6,edges:12,vertices:8},msg)}}else t.solids.forEach((m,i)=>near(w.stacks[i].answer,t.kind==='volume'?m.cells.length*t.unit**3:surfaceCount(m.cells)*t.unit**2,msg))}
 if(t.mode==='combinLab')t.models.forEach((m,i)=>{const all=enumerate(m);eq(w.models[i].answer,all.length,msg+' enumeration count');eq(w.models[i].records.map(r=>(m.type==='order'&&!m.ordered?[...r.tuple].sort((a,b)=>m.items.findIndex(p=>p.id===a)-m.items.findIndex(p=>p.id===b)):r.tuple).join('|')).sort(),all.map(r=>r.join('|')).sort(),msg+' complete concrete results')});
 if(t.mode==='chanceLab')t.models.forEach((m,i)=>{const space=chanceSpace(m),f=space.filter(tuple=>event(m,tuple)),s=w.models[i];eq(s.records.map(r=>r.tuple.join('|')).sort(),space.map(r=>r.join('|')).sort(),msg+' space');if(['favorable','two','weighted'].includes(t.kind))near(s.numerator/s.denominator,f.length/space.length,msg+' probability');if(t.kind==='certainty')eq(s.certainty,!f.length?'impossible':f.length===space.length?'certain':'possible',msg)});
 if(t.mode==='statsLab'){const raw=t.kind==='weighted'?t.rows.flatMap(r=>Array(r.frequency).fill(r.value)):t.values,n=raw.length,sum=raw.reduce((a,b)=>a+b,0),sorted=[...raw].sort((a,b)=>a-b);if(['balance','mean','weighted'].includes(t.kind)){near(w.total,sum,msg+' conserved sum');near(w.denominator,n,msg+' denominator');near(w.answer,sum/n,msg+' weighted mean')}if(t.kind==='median')near(w.answer,(sorted[Math.floor((n-1)/2)]+sorted[Math.ceil((n-1)/2)])/2,msg+' median');if(t.kind==='modeRange')near(w.range,sorted.at(-1)-sorted[0],msg+' range')}
 if(t.mode==='chartLab'){if(t.kind==='legend')eq(w.values,t.icons.map(n=>n*t.legend),msg+' legend');else if(t.kind==='interval'){let total=0;const ids=[];for(let x=t.points[0][0],i=0;x<t.points.at(-1)[0];x+=t.timeStep,i++){const end=Math.min(x+t.timeStep,t.points.at(-1)[0]),mid=(x+end)/2;let y;for(let j=1;j<t.points.length;j++)if(mid>=t.points[j-1][0]&&mid<t.points[j][0]){const [a,b]=t.points[j-1],[c,d]=t.points[j];y=(b*(c-mid)+d*(mid-a))/(c-a)}if(t.relation==='below'?y<t.threshold:y>t.threshold){total+=end-x;ids.push('I'+i)}}near(w.answer,total,msg+' threshold-duration');eq([...w.intervals].sort(),ids.sort(),msg+' intervals')}else if(t.kind==='ticks')eq(w.scale,t.ticks,msg);else eq(w.values,t.values,msg)}
 if(t.mode==='constraintLab'&&['reverse','verify'].includes(t.kind)){assert(t.groups>0&&Number.isInteger(t.bag)&&t.bag>=0,msg);if(t.generation){const total=t.groups*(t.bag+t.extra);assert(t.prompt.includes(String(total)),msg+' question matches per-group extra, not one global extra')}}
 if(t.mode==='integerLab'&&t.kind==='power')eq(t.target,Array(t.exponent).fill(t.base).reduce((a,b)=>a*b,1),msg+' exponent');
 if(t.mode==='fractionLab'&&t.kind==='compare'){if(t.correctChoice==='differentWhole'){assert(t.wholeScaleLeft/t.denomLeft!==t.wholeScaleRight/t.denomRight,msg+' unequal physical unit lengths');eq(w.choice,'differentWhole',msg+' boundary condition')}else{const delta=t.targetLeft*t.denomRight-t.targetRight*t.denomLeft;eq(w.choice,delta>0?'left':delta<0?'right':'equal',msg+' cross product')}}
 if(t.mode==='fractionLab'&&t.kind==='remainder'){assert(new Set([...w.first,...w.second]).size===w.first.length+w.second.length,msg+' original identities disjoint');eq(w.second.length,t.second,msg+' second original subset');if(t.correctChoice){const [n,d]=t.correctChoice.split('/').map(Number);eq(n*(t.answerBasis==='remaining'?t.total-t.first:t.total),d*t.second,msg+' ratio to chosen reference whole')}if(t.requireBasisSelection)eq(w.reference,t.answerBasis,msg+' reference set')}
 if(t.mode==='fractionLab'&&t.kind==='line')eq((t.lineStart||0)+((t.lineEnd??1)-(t.lineStart||0))*w.marker/t.denom,t.coordinate??t.target/t.denom,msg+' absolute coordinate');
 if(t.mode==='placeCompose'&&t.sourceMoney)eq(t.sourceMoney.reduce((a,b)=>a+b,0),w.tens*10+w.ones,msg+' denomination conversion');
 if(t.mode==='percentLab'&&t.knownShares){eq(w.bins.flat().length,t.knownCount,msg+' known original count');eq(t.knownCount*100/t.givenPercent,w.copies*t.part,msg+' inverse nonunit percent')}
 if(t.mode==='percentLab'&&t.bounds){assert(w.boundRecords.lower.a*w.boundRecords.lower.b<t.a*t.b&&t.a*t.b<w.boundRecords.upper.a*w.boundRecords.upper.b,msg+' strict positive factor bounds')}
 if((t.mode==='percentLab'||t.mode==='scaleLab')&&t.kind==='change')eq(w.choice,String(t.start+t.add-t.remove),msg+' successive baselines');
if(t.mode==='ratioLab'&&t.kind==='partition'){
  const red=[...w.redPool,...w.bagIds.flatMap(g=>g.red)],blue=[...w.bluePool,...w.bagIds.flatMap(g=>g.blue)];
  eq(new Set(red).size,t.red,msg+' red identities');eq(new Set(blue).size,t.blue,msg+' blue identities');
  eq(w.bagIds.map(g=>[g.red.length,g.blue.length]),Array(t.copies).fill([t.unitRed,t.unitBlue]),msg+' equal bags');
  eq(t.red,w.bags*t.unitRed,msg+' red conservation');eq(t.blue,w.bags*t.unitBlue,msg+' blue conservation');
 }
 if(t.mode==='ratioLab'&&t.kind==='whole'){
  const n=t.focusSide==='blue'?t.blue:t.red,[a,d]=w.choice.split('/').map(Number);eq(a*(t.red+t.blue),d*n,msg+' part-to-whole');
 }
 if(t.mode==='ratioLab'&&t.kind==='scale'&&t.targetCopies){
  const preserved=w.copiesRed*t.red*t.blue===w.copiesBlue*t.blue*t.red;eq(w.choice,preserved?'same':'changed',msg+' unilateral ratio verdict');
 }
 if(t.mode==='rateLab'&&t.kind==='compare'){
  const a=w.a.reduce((s,n)=>s+n,0)/w.a.length,b=w.b.reduce((s,n)=>s+n,0)/w.b.length;eq(w.choice,a<b?'a':a>b?'b':'equal',msg+' compare unit rates');
 }
 if(t.mode==='journeyLab'){
  if(t.kind==='joint'){
   let total=0;for(let i=0;i<t.count;i++)for(const side of ['a','b']){const active=i>=(t.starts?.[side]||0);eq(w.rounds[i][side],active,msg+' valid working interval');if(active)total+=t[side]}
   eq(w.rounds.reduce((n,r)=>n+(r.a?t.a:0)+(r.b?t.b:0),0),total,msg+' worker-specific duration');
  }else{
   const expected=['segment','remaining'].includes(t.kind)?t.segments:Array(t.count).fill(t.per);eq(w.steps,expected,msg+' every elapsed interval including zero');
   if(t.elapsedPer)eq(w.elapsed,w.steps.length*t.elapsedPer,msg+' elapsed unit conversion');
   if(t.unknownWhole)eq(w.whole,w.steps.reduce((a,b)=>a+b,0)+t.givenRemaining,msg+' reconstruct whole');
  }
 }
 if(t.mode==='scaleLab'&&t.kind==='length'&&t.direction==='shrink'){
  near((t.short/w.short)/(t.long/w.long),t.short/t.long,msg+' shrink proportion');eq([t.short/w.short,t.long/w.long],[3,5],msg+' concrete inverse lengths');
 }
 if(t.mode==='scaleLab'&&t.targetFactors)eq(w.choice,w.red===w.blue?'same':'changed',msg+' asymmetric copy');
 if(t.mode==='scaleLab'&&t.axisFactors){eq(w.rows*w.cols,3,msg+' nonuniform area multiplier');eq(w.choice,w.rows===w.cols?'same':'changed',msg+' shape condition')}
 if(t.mode==='scaleLab'&&t.inputUnitSize){eq(w.cards*t.inputUnitSize,6,msg+' actual input units');eq(w.cards*t.per,9,msg+' proportional output')}
 if(t.mode==='integerLab'&&['square','root'].includes(t.kind)&&t.unitSize){eq(t.target,t.side*t.side*t.unitSize*t.unitSize,msg+' physical area');eq(w.amount,t.kind==='root'?t.side*t.unitSize:t.target,msg+' length or square unit')}
if(t.mode==='equationLab'){
  if(t.kind==='equal'){const same=t.left.reduce((a,n)=>a+n,0)===t.right.reduce((a,n)=>a+n,0);eq(same,t.equalAnswer??true,msg+' equality condition');if(!same)eq(w.choice,'unequal',msg+' equality verdict')}
  if(['unknown','bilateral'].includes(t.kind)){eq(w.bag+t.known,t.total,msg+' original equation');if(t.addBoth!==undefined)eq(w.bag+t.known+w.leftAdded,t.total+w.rightAdded,msg+' adding same quantity')}
  if(t.unknownInitial){eq(w.returned,t.removedGiven,msg+' returned originals');eq(w.wholeAnswer,t.remain+t.removedGiven,msg+' inverse original total')}
  if(t.kind==='substitute'&&t.correctVerdict)eq(w.choice,w.bag+w.knownPlaced===t.total?'accept':'reject',msg+' reject wrong candidate');
 }
 if(t.mode==='constraintLab'){
  if(t.extraOutside&&t.kind==='reverse'){eq(w.peeled,t.extra,msg+' single global extra');eq((t.groups*t.bag+t.extra-w.peeled)/t.groups,t.bag,msg+' inverse order')}
  if(t.kind==='verify'&&t.correctVerdict){const sum=t.groups*w.filled+(t.extraOutside?w.extra:t.groups*w.extra);eq(w.choice,sum===t.givenTotal?'accept':'reject',msg+' complete substitution')}
  if(t.kind==='parity')eq(w.choice,t.total%t.divisor===0?'possible':'impossible',msg+' integer possibility');
  if(['stock','optimal'].includes(t.kind)){const k=t.kind==='stock'?w.bags:Number(w.choice);assert(k*t.per<=t.stock&&(k+1)*t.per>t.stock,msg+' maximum feasible and adjacent infeasible')}
 }
 if(t.mode==='patternLab'&&t.kind==='explicit'){
  let value=t.initial.at(-1);const tail=[];for(let i=0;i<2;i++){value=t.operationOrder==='addThenMultiply'?(value+t.add)*t.multiplier:value*t.multiplier+t.add;tail.push(value)}eq(w.terms.slice(t.initial.length),tail,msg+' recurrence operation order');
 }
 if(t.mode==='patternLab'&&t.tile)for(let r=t.tile.length;r<t.rows;r++)for(let c=0;c<t.cols;c++)eq(w.cells[r+','+c],t.tile[r%t.tile.length][c%t.tile[0].length],msg+' two-dimensional tile');
 if(t.mode==='coordinateLab'&&t.kind==='machine')eq(w.values,t.inputs.map(n=>n*t.multiplier+t.add),msg+' common input-output rule');
 if(t.mode==='coordinateLab'&&t.kind==='dynamic')eq(w.trace,Array.from({length:t.duration+1},(_,i)=>[i,t.startValue+i*t.step]),msg+' signed time evolution');
if(t.mode==='measureLab'&&t.kind==='rearrange'){
  const cells=Object.keys(w.tiles).map(s=>s.split(',').map(Number)),ids=Object.values(w.tiles),perimeter=measuredOuter(cells),reference=measuredOuter(t.reference);
  eq(ids.length,t.total,msg+' conserved original tile count');assert(ids.every(n=>Number.isInteger(n)&&n>=0&&n<t.total)&&new Set(ids).size===t.total,msg+' each original tile once');
  assert(t.goal==='samePerimeterDifferentArea'?perimeter===reference&&cells.length!==t.reference.length:perimeter!==reference&&cells.length===t.reference.length,msg+' actual area/perimeter counterexample');
 }
 if(t.mode==='angleLab'){
  if(t.kind==='arms'){eq(w.angle,t.target,msg+' opening');eq([...w.selected].sort(),['AB','AC'],msg+' common vertex');if(t.mustResize)assert(w.resized&&w.lengths.some((n,i)=>n!==t.lengths[i]),msg+' actual arm resized')}
  if(t.kind==='turn')w.turns.forEach((s,i)=>{eq(s.angle,t.targets[i],msg+' swept turn');eq(s.path,Array.from({length:t.targets[i]/30},(_,j)=>(j+1)*30),msg+' full path including complete revolution')});
  if(['triangle','conditions'].includes(t.kind)){eq(t.angles.reduce((a,n)=>a+n,0),180,msg+' valid triangle');eq(w.answer,180-t.angles.reduce((a,n,i)=>a+(i===t.unknown?0:n),0),msg+' unknown angle');eq([...w.pieces].sort(),[0,1,2],msg+' all original angle pieces');if(t.kind==='conditions')eq([...w.conditions].sort(),[0,1,2].filter(i=>i!==t.unknown).map(String),msg+' given angle conditions')}
  if(t.kind==='polygon'){eq(w.triangles,t.sides-2,msg+' triangulation');eq(w.total,180*(t.sides-2),msg+' interior sum');eq(w.diagonals.length,t.sides-3,msg+' fan diagonal count');assert(new Set(w.diagonals.map(p=>p.join(','))).size===w.diagonals.length&&w.diagonals.every(pair=>pair.includes(t.anchor)&&pair.length===2&&pair.every(v=>v>=0&&v<t.sides)&&![1,t.sides-1].includes(Math.abs(pair[1]-pair[0]))),msg+' distinct internal fan diagonals')}
 }
 if(t.mode==='compositeLab'){
  if(['union','move'].includes(t.kind))(t.puzzles||[t]).forEach((p,i)=>{
   const s=w.cards[i],cells=[...s.fixed,...s.piece],positions=cells.map(v=>v.r+','+v.c),ids=cells.map(v=>v.id);
   eq(cells.length,p.fixed.length+p.piece.length,msg+' all material count');eq(new Set(ids).size,cells.length,msg+' distinct original identities');eq(new Set(positions).size,cells.length,msg+' no overlapped cells');
   eq([...s.piece.map(v=>v.id)].sort(),p.piece.map((_,j)=>i+'M'+j).sort(),msg+' original movable piece ids');
   assert(cells.every(v=>v.r>=0&&v.r<p.rows&&v.c>=0&&v.c<p.cols),msg+' inside board');eq(s.answer,cells.length,msg+' exact area');
   if(p.target)eq([...positions].sort(),p.target.map(v=>v.join(',')).sort(),msg+' exact target coverage');
   if(p.requirePerimeterChange){const original=[...p.fixed,...p.piece.map(([r,c])=>[r+p.start[0],c+p.start[1]])];assert(measuredOuter(cells.map(v=>[v.r,v.c]))!==measuredOuter(original),msg+' area preserved while perimeter changes')}
  });
  if(t.kind==='cut'){eq([...w.removed].sort(),t.remove.map(v=>v.join(',')).sort(),msg+' exact cut positions');eq(w.answer,t.rows*t.cols-new Set(w.removed).size,msg+' retained original area')}
  if(t.kind==='squares'){const expected=[];for(const k of t.sizes)for(let r=0;r+k<=t.rows;r++)for(let c=0;c+k<=t.cols;c++)expected.push(k+':'+r+','+c);eq(w.entries.map(e=>e.key).sort(),expected.sort(),msg+' all square positions and sizes');eq(w.answer,expected.length,msg+' total squares')}
 }
 if(t.mode==='circleLab'){
  const targets=Array.from({length:t.count||0},(_,i)=>(t.start+i)%t.parts);
  if(t.kind==='center'){
   const origins=t.origins||{O:[180,180],P:[235,180]},o=origins[w.origin];assert(o,msg+' actual candidate');near(o[0],180,msg+' center x');near(o[1],180,msg+' center y');
   eq([...w.rays].sort((a,b)=>a-b),t.points.map((_,i)=>i),msg+' every measured radius');
   for(const deg of t.points){const a=(deg+(t.rotation||0))*Math.PI/180;near(Math.hypot(180+105*Math.cos(a)-o[0],180+105*Math.sin(a)-o[1]),105,msg+' actual equidistance')}
  }
  if(t.kind==='radii'){near(w.answer,t.answerTarget==='radius'?t.radius:2*t.radius,msg+' radius diameter');eq(w.unit,'cm',msg+' length unit')}
  if(t.kind==='walk')(t.routes||[t]).forEach((r,i)=>{const s=w.routes[i];eq(s.path,Array.from({length:r.targetSteps},(_,j)=>j+1),msg+' original arc path');near(s.coeff,2*r.radius*r.targetSteps/r.parts,msg+' arc pi coefficient');near(s.constant,r.includeDiameter?2*r.radius:0,msg+' closure diameter');eq(s.diameter,!!r.includeDiameter,msg+' boundary condition');eq(s.unit,'cm',msg+' length unit')});
  if(t.kind==='area'){w.areas.forEach((s,i)=>{eq([...s.pieces].sort((a,b)=>a-b),Array.from({length:t.parts},(_,j)=>j),msg+' each original sector once');near(s.coeff,t.radii[i]**2,msg+' area pi coefficient');eq(s.unit,'cm2',msg+' squared unit')});if(t.compare)near(w.ratio,(t.radii[1]/t.radii[0])**2,msg+' area scale squared')}
  if(t.kind==='arc'){eq([...w.arcs].sort((a,b)=>a-b),[...targets].sort((a,b)=>a-b),msg+' contiguous cyclic arc');near(w.numerator/w.denominator,t.count/t.parts,msg+' fraction of circle');near(w.answer,t.totalCirc*t.count/t.parts,msg+' arc length');eq(w.unit,'cm',msg+' arc unit')}
  if(t.kind==='objects'){const arc=w.objects[0],sector=w.objects[1];eq([...arc.arcs].sort((a,b)=>a-b),[...targets].sort((a,b)=>a-b),msg+' selected arc');eq([...sector.sectors].sort((a,b)=>a-b),[...targets].sort((a,b)=>a-b),msg+' selected sector');eq(arc.sectors.length+sector.arcs.length,0,msg+' objects not exchanged');near(arc.coeff,2*t.radius*t.count/t.parts,msg+' arc coefficient');near(sector.coeff,t.radius**2*t.count/t.parts,msg+' sector coefficient');eq([arc.unit,sector.unit],['cm','cm2'],msg+' different dimensions despite equal coefficients')}
 }
 if(t.mode==='similarLab'){
  if(t.kind==='correspond'){eq(w.links.map(p=>p.join(',')).sort(),t.points.map((_,i)=>i+','+i).sort(),msg+' original correspondence');eq(w.marks,{sourceEdge:t.edgeIndex,targetEdge:t.edgeIndex,sourceAngle:t.angleIndex,targetAngle:t.angleIndex},msg+' corresponding edge angle')}
  else{
   const x=t.kind==='inverse'?t.newWidth/t.width:t.goalX,y=t.kind==='inverse'?x:t.goalY;near(w.scaleX,x,msg+' width factor');near(w.scaleY,y,msg+' height factor');
   if(t.kind==='resize')eq(w.choice,x===y?'similar':'different',msg+' equal scale condition');
   if(t.kind==='inverse')near(w.answer,t.newWidth/t.width,msg+' inverse direction');
   if(t.kind==='perimeter'){near(w.trace.source.length,2*(t.width+t.height),msg+' actual original perimeter');near(w.trace.target.length,2*(t.width*x+t.height*y),msg+' actual new perimeter');near(w.answer,w.trace.target.length/w.trace.source.length,msg+' perimeter ratio')}
   if(t.kind==='area'){near(w.covered.source.length,t.width*t.height,msg+' original area');near(w.covered.target.length,t.width*x*t.height*y-(t.remove||[]).length,msg+' retained area after cut');assert(new Set(w.covered.source).size===w.covered.source.length&&new Set(w.covered.target).size===w.covered.target.length,msg+' no repeated area cell');near(w.answer,w.covered.target.length/w.covered.source.length,msg+' retained area ratio')}
  }
 }
 if(t.mode==='rightLab'){
  near(t.kind==='condition'||t.kind==='axis'?0:t.a*t.a+t.b*t.b-t.c*t.c,0,msg+' right-triangle relation');
  if(t.kind==='condition')t.cards.forEach((card,i)=>{const p=card.points[card.corner],q=card.points[(card.corner+1)%3],r=card.points[(card.corner+2)%3],dot=(q[0]-p[0])*(r[0]-p[0])+(q[1]-p[1])*(r[1]-p[1]);eq(w.cards[i].choice,Math.abs(dot)<1e-8?'yes':'no',msg+' actual perpendicular condition')});
  if(['squares','solve','diagonal'].includes(t.kind)){
   const unknown=t.kind==='squares'?'c':t.unknown,keys=unknown==='c'?['a','b']:['c'],ids=keys.flatMap(k=>Array.from({length:t[k]/t.unit},(_,r)=>Array.from({length:t[k]/t.unit},(_,c)=>k+'-'+r+'-'+c)).flat());
   eq(Object.keys(w.placed).sort(),ids.sort(),msg+' all original square materials once');const locations=Object.values(w.placed);eq(new Set(locations.map(p=>p.zone+':'+p.r+','+p.c)).size,locations.length,msg+' no duplicate slot');
   const deduct=unknown==='c'?0:t[unknown==='a'?'b':'a']**2;near(locations.filter(p=>p.zone==='deduct').length*t.unit**2,deduct,msg+' deducted known square');near(locations.filter(p=>p.zone==='target').length*t.unit**2,t[unknown]**2,msg+' unknown square area');
   if(t.kind==='squares')for(const k of ['a','b','c'])near(w.areas[k],t[k]**2,msg+' physical area '+k);else near(w.answer,Math.sqrt(unknown==='c'?t.a*t.a+t.b*t.b:t.c*t.c-t[unknown==='a'?'b':'a']**2),msg+' positive unknown length');
  }
  if(t.kind==='axis'){near(w.answer,Math.hypot(t.B[0]-t.A[0],t.B[1]-t.A[1]),msg+' nonnegative endpoint distance');eq(w.path.length-1,w.answer,msg+' full unit path')}
  if(t.kind==='diagonal')near(w.answer,Math.hypot(t.B[0]-t.A[0],t.B[1]-t.A[1])*t.unit,msg+' independent Euclidean distance');
 }
if(t.mode==='setsLab'){
  const includes=(p,key)=>key==='U'||key===p.group||key==='A'&&['R','O'].includes(p.group)||key==='B'&&['Y','O'].includes(p.group)||key==='I'&&p.group!=='N'||key==='exact1'&&['R','Y'].includes(p.group)||key==='notA'&&['Y','N'].includes(p.group)||key==='notB'&&['R','N'].includes(p.group);
  const ids=t.people.map(p=>p.id);eq(new Set(ids).size,ids.length,msg+' distinct original identities');assert([...Object.keys(w.registry),...Object.keys(w.zones)].every(id=>ids.includes(id)),msg+' universe excludes outside identities');
  for(const p of t.people){const flags=p.group==='N'?['N']:[...(['R','O'].includes(p.group)?['A']:[]),...(['Y','O'].includes(p.group)?['B']:[])];eq([...(w.registry[p.id]||[])].sort(),flags.sort(),msg+' complete original memberships');eq(w.zones[p.id],p.group,msg+' exactly one physical region')}
  for(const key of t.queries||[]){const expected=t.people.filter(p=>includes(p,key)).map(p=>p.id).sort();eq([...(w.marks[key]||[])].sort(),expected,msg+' queried original identity set');eq(!!w.empty[key],!expected.length,msg+' explicit empty boundary')}
  const target=t.target||'U',members=t.people.filter(p=>includes(p,target));if(['identity','universe','partition'].includes(t.kind))eq(w.answer,members.length,msg+' target cardinality');
  if(t.kind==='partition')for(const key of t.countKeys)eq(w.counts[key],t.people.filter(p=>includes(p,key)).length,msg+' partition count');
  if(['formula','complement','twoWays'].includes(t.kind))for(const row of w.rows.slice(0,t.kind==='complement'?1:2)){for(const p of t.people){const multiplicity=row.ops.reduce((n,op)=>n+(includes(p,op.key)?op.sign:0),0);eq(multiplicity,includes(p,target)?1:0,msg+' object-wise formula equality')}eq(row.answer,members.length,msg+' formula cardinality')}
  if(t.kind==='dedup'){eq([...w.added].sort(),['A','B'],msg+' actual full lists');for(const p of t.people)eq(w.correction[p.id]||0,includes(p,target)?1:0,msg+' corrected original multiplicity');eq(w.answer,members.length,msg+' corrected cardinality')}
 }
if(t.mode==='chartLab'&&t.kind==='legend'){
  const symbols=[],dots=[];t.icons.forEach((count,row)=>{for(let i=0;i<Math.ceil(count);i++){const units=t.legend*Math.min(1,count-i);assert(Number.isInteger(units)&&units>0,msg+' represented icon units');symbols.push(row+':'+i);for(let k=0;k<units;k++)dots.push(row+':'+i+':'+k)}});
  eq([...w.expanded].sort(),symbols.sort(),msg+' all full and partial icons expanded once');eq(Object.keys(w.dots).sort(),dots.sort(),msg+' exact original partial-icon units');assert(Object.entries(w.dots).every(([id,row])=>row===+id.split(':')[0]),msg+' original categories preserved');
 }
 if(t.mode==='statsLab'){
  const observations=t.kind==='weighted'?t.rows.flatMap((r,i)=>Array.from({length:r.frequency},(_,j)=>({id:'P'+(i+1)+'-'+(j+1),value:r.value}))):t.values.map((value,i)=>({id:'D'+(i+1),value}));
  if(['balance','mean','weighted'].includes(t.kind)){const ids=observations.flatMap(p=>Array.from({length:p.value/t.quantum},(_,k)=>p.id+':U'+k));eq(Object.keys(w.dots).sort(),ids.sort(),msg+' conserved original quantity units');const mean=observations.reduce((s,p)=>s+p.value,0)/observations.length;for(let row=0;row<observations.length;row++)near(Object.values(w.dots).filter(v=>v===row).length*t.quantum,mean,msg+' actual redistribution');assert(Object.values(w.dots).every(row=>Number.isInteger(row)&&row>=0&&row<observations.length),msg+' no nonexistent recipient');if(t.kind==='weighted'){eq([...w.expanded].sort((a,b)=>a-b),t.rows.map((_,i)=>i),msg+' zero-frequency row observed');assert(t.rows.every(r=>Number.isInteger(r.frequency)&&r.frequency>=0)&&observations.length>0,msg+' valid nonempty frequency population')}}
  if(['sort','median'].includes(t.kind)){eq([...w.order].sort(),observations.map(p=>p.id).sort(),msg+' all observations, repeated values retained');const ordered=w.order.map(id=>observations.find(p=>p.id===id).value);assert(ordered.every((v,i)=>i===0||(t.direction==='desc'?v<=ordered[i-1]:v>=ordered[i-1])),msg+' declared sorting direction')}
  if(t.kind==='modeRange'){const frequencies=new Map();for(const p of observations){frequencies.set(p.value,(frequencies.get(p.value)||0)+1);eq(w.groups[p.id],p.value,msg+' original observed data group')}const highest=Math.max(...frequencies.values()),modes=highest===1?[]:[...frequencies].filter(([,n])=>n===highest).map(([v])=>v).sort((a,b)=>a-b);eq([...w.modes].sort((a,b)=>a-b),modes,msg+' all highest frequency modes under declared school convention');eq(w.noMode,modes.length===0,msg+' explicit no-mode convention')}
 }
 if(t.mode==='chanceLab')t.models.forEach((m,i)=>{const s=w.models[i],freq=new Map();for(const p of m.atoms)freq.set(p.color,(freq.get(p.color)||0)+1);if(t.kind==='equal'){eq(s.basic,'yes',msg+' specified uniform original atoms');eq(s.labels,new Set(freq.values()).size===1?'yes':'no',msg+' label multiplicities determine equal probability')}if(t.kind==='weighted'){const [a,b]=m.compare.map(c=>freq.get(c)||0);eq(s.compare,a===b?'equal':a>b?'first':'second',msg+' compare actual label weight')}});
 if(t.mode==='motionLab'){
  if(t.kind==='fold'){
   const original={};for(let y=0;y<t.size;y++)for(let x=0;x<t.size;x++)original['C'+x+'-'+y]=[x,y];let current=original;
   for(const [i,f] of t.folds.entries()){const frame=w.foldHistory[i];eq(frame.before,current,msg+' fold starts at previous original layers');const after={};for(const [id,[x,y]] of Object.entries(current)){const v=f.axis==='vertical'?x:y,move=f.from==='low'?v<f.value:v>f.value;after[id]=f.axis==='vertical'&&move?[2*f.value-x,y]:f.axis==='horizontal'&&move?[x,2*f.value-y]:[x,y]}eq(frame.after,after,msg+' exact reflected layer positions');current=after}
   const holes=Object.keys(current).filter(id=>t.cuts.some(([x,y])=>current[id][0]===x&&current[id][1]===y));eq([...w.removed].sort(),holes.sort(),msg+' every original layer cut');eq([...w.holes].sort(),holes.sort(),msg+' original-hole prediction');eq(w.positions,original,msg+' full unfolding restores all original cell identities');eq(w.unfolded,t.folds.length,msg+' unfolded each fold');
  }else{
   const transform=(ps,op)=>ps.map(p=>{let x=p.x,y=p.y;if(op.type==='translate'){x+=op.dx;y+=op.dy}else if(op.type==='reflect'){if(op.axis==='vertical')x=2*op.value-x;else if(op.axis==='horizontal')y=2*op.value-y;else if(op.axis==='diagonal')[x,y]=[y,x];else [x,y]=[-y,-x]}else{let turns=(op.direction==='cw'?-1:1)*op.angle/90;[x,y]=[x-op.cx,y-op.cy];for(let k=0;k<((turns%4)+4)%4;k++)[x,y]=[-y,x];x+=op.cx;y+=op.cy}return {id:p.id,x:x+0,y:y+0}});
   let current=t.points.map(p=>({id:p.id,x:p.x,y:p.y}));eq(w.history.length,t.steps.length,msg+' actual operation count');for(const [i,op] of t.steps.entries()){eq(w.history[i].before,current,msg+' continuous point trace');current=transform(current,op);eq(w.history[i].after,current,msg+' exact coordinate transformation')}
   eq(w.live,current,msg+' same original identities at final coordinates');eq(Object.keys(w.predicted).sort(),t.points.map(p=>p.id).sort(),msg+' all original point predictions');for(const p of current)eq(w.predicted[p.id],[p.x,p.y],msg+' fixed first coordinate prediction');
   for(let i=0;i<t.points.length;i++)for(let j=0;j<i;j++)near(Math.hypot(current[i].x-current[j].x,current[i].y-current[j].y),Math.hypot(t.points[i].x-t.points[j].x,t.points[i].y-t.points[j].y),msg+' preserved pair distance');
  }
 }
 if(t.mode==='invariantLab'){
  if(t.kind==='filter'){
   const permutations=items=>items.length?items.flatMap(id=>permutations(items.filter(x=>x!==id)).map(p=>[id,...p])):[[]],all=permutations(t.items),accept=(c,p)=>c.type==='before'?p.indexOf(c.a)<p.indexOf(c.b):c.type==='notSlot'?p[c.slot]!==c.a:c.type==='fixed'?p[c.slot]===c.a:c.type==='slotOdd'?+p[c.slot]%2===1:c.type==='adjacent'?Math.abs(p.indexOf(c.a)-p.indexOf(c.b))===1:false;
   eq(w.records.map(r=>r.tuple.join('|')).sort(),all.map(p=>p.join('|')).sort(),msg+' every original permutation once');for(const r of w.records){const failed=t.conditions.filter(c=>!accept(c,r.tuple)).map(c=>c.id);eq([...r.failed].sort(),failed.sort(),msg+' every violated condition');eq(r.status,failed.length?'reject':'keep',msg+' full condition conjunction')}
  }else{
   const initial={order:t.coins.map(p=>p.id),colors:Object.fromEntries(t.coins.map(p=>[p.id,p.color]))},legal=(s,ids)=>ids.length===(t.rule==='flipOne'?1:2)&&new Set(ids).size===ids.length&&ids.every(id=>s.order.includes(id))&&(!['adjacentFlip','swapAdjacent'].includes(t.rule)||Math.abs(s.order.indexOf(ids[0])-s.order.indexOf(ids[1]))===1),advance=(s,ids)=>{const a={order:[...s.order],colors:{...s.colors}};if(!legal(s,ids))return a;if(t.rule==='swapAdjacent'){const [i,j]=ids.map(id=>a.order.indexOf(id));[a.order[i],a.order[j]]=[a.order[j],a.order[i]]}else for(const id of ids)a.colors[id]=a.colors[id]==='红'?'蓝':'红';return a},red=s=>s.order.filter(id=>s.colors[id]==='红'),states=[initial];let current=initial;
   for(const h of w.history){eq(h.before,current,msg+' continuous original state trace');assert(legal(current,h.ids),msg+' actual legal operation');current=advance(current,h.ids);eq(h.after,current,msg+' exact legal transition');states.push(current)}eq(w.state,current,msg+' final original state');
   if(t.kind==='legal'){let previous=initial;eq(w.trials.length,t.attempts.length,msg+' all specified trials');for(const [i,tr] of w.trials.entries()){eq(tr.before,previous,msg+' trials continue from actual state');eq([...tr.ids].sort(),[...t.attempts[i]].sort(),msg+' tested requested original identities');eq(tr.predicted,legal(previous,tr.ids)?'legal':'illegal',msg+' predicted legality');previous=advance(previous,tr.ids);eq(tr.after,previous,msg+' illegal attempt has no state change')}}
   if(t.kind==='parity')for(const [side,s] of [['initial',initial],['current',current]]){const ids=[...w.pairs[side].flat(),...w.left[side]];eq(ids.sort(),red(s).sort(),msg+' each original red identity once');eq(w.left[side].length,red(s).length%2,msg+' unmatched parity');eq(w.parity[side],red(s).length%2?'odd':'even',msg+' actual parity')}
   if(['invariant','proof'].includes(t.kind))states.forEach((s,i)=>{eq(w.ledger[i],{total:s.order.length,red:red(s).length,parity:red(s).length%2?'odd':'even'},msg+' observed state counts')});
   if(t.kind==='invariant'||t.kind==='proof'&&w.verdict==='unreachable'){eq(w.probes.length,t.rule==='flipOne'?2:3,msg+' local color types exhausted');for(const p of w.probes){assert(p.done,msg+' local type actually tested');const after=advance(p.before,p.before.order);eq(p.after,after,msg+' local transition');eq(p.delta,red(after).length-red(p.before).length,msg+' all local red-count deltas')}eq([...w.quantities].sort(),(t.rule==='swapAdjacent'?['total','red','redParity']:t.rule==='flipOne'?['total']:['total','redParity']).sort(),msg+' justified preserved quantities')}
   if(t.kind==='proof'){
    const key=p=>p.join('|'),start=initial.order.map(id=>initial.colors[id]),queue=[start],seen=new Set([key(start)]);for(let h=0;h<queue.length;h++){const p=queue[h];for(let i=0;i<p.length;i++)for(let j=t.rule==='flipOne'?i:i+1;j<(t.rule==='flipOne'?i+1:p.length);j++){if(['adjacentFlip','swapAdjacent'].includes(t.rule)&&j-i!==1)continue;const next=[...p];if(t.rule==='swapAdjacent')[next[i],next[j]]=[next[j],next[i]];else for(const k of t.rule==='flipOne'?[i]:[i,j])next[k]=next[k]==='红'?'蓝':'红';const k=key(next);if(!seen.has(k)){seen.add(k);queue.push(next)}}}
    const reachable=seen.has(key(t.goal));eq(w.verdict,reachable?'reachable':'unreachable',msg+' independently enumerated reachability');if(reachable){eq(w.proof,'path',msg+' constructed witness');eq(current.order.map(id=>current.colors[id]),t.goal,msg+' actual path reaches target')}else assert(t.rule==='swapAdjacent'?red(initial).length!==t.goal.filter(c=>c==='红').length:red(initial).length%2!==t.goal.filter(c=>c==='红').length%2,msg+' invariant contradicts target');
   }
  }
 }
 if(t.mode==='groupingLab'){
  if(t.kind==='reconstruct'){
   eq(w.whole,t.knownGroups*t.divisor+t.remainder,msg+' inverse dividend');eq([...w.unwrapped].sort((a,b)=>a-b),Array.from({length:t.knownGroups},(_,i)=>i),msg+' original groups opened once');assert(t.remainder>=0&&t.remainder<t.divisor,msg+' canonical remainder');
  }else if(t.kind==='digits'){
   const expected=[];for(let tens=1;tens<=9;tens++)for(let ones=0;ones<=9;ones++)if(t.pools[0].includes(tens)&&t.pools[1].includes(ones)&&(t.rule.tens===undefined||t.rule.tens===tens)&&(t.rule.ones===undefined||t.rule.ones===ones)&&(!t.rule.different||tens!==ones))expected.push(String(10*tens+ones));
   eq([...w.entries].sort(),expected.sort(),msg+' all valid two-digit integers');
  }else if(t.kind==='digitRules'){
   eq(w.cards.length,t.cases.length,msg+' all declared number/rule cases');
   for(const d of [...new Set(t.cases.map(c=>c.divisor))]){const p=w.proofs[d],ids=p.groups.flat();assert([2,3,5].includes(d)&&p.probed&&p.selected.length===0,msg+' legal ten-proof divisor');eq(p.groups.length,Math.floor(10/d),msg+' ten quotient');assert(p.groups.every(g=>g.length===d)&&ids.every(n=>Number.isInteger(n)&&n>=0&&n<10)&&new Set(ids).size===ids.length,msg+' exact ten original identities');eq(10-ids.length,10%d,msg+' ten remainder')}
   t.cases.forEach((c,i)=>{
    assert(Number.isInteger(c.number)&&c.number>=0,msg+' nonnegative decimal integer');const s=w.cards[i],digits=[];let n=c.number;do{digits.unshift(n%10);n=Math.floor(n/10)}while(n);
    const include=digits.map((_,j)=>c.divisor===3||j===digits.length-1),reduced=digits.reduce((sum,v,j)=>sum+(include[j]?v:0),0),pool=digits.flatMap((v,j)=>include[j]?Array.from({length:v},(_,k)=>c.id+':P'+j+':U'+k):[]),ids=s.groups.flat(),q=Math.floor(c.number/c.divisor),remainder=c.number-q*c.divisor;
    eq(s.positions,include.map(b=>b?'add':'skip'),msg+' explicit position decisions including zero');eq(reduced%c.divisor,remainder,msg+' reduced representation preserves remainder');eq(s.groups.length,Math.floor(reduced/c.divisor),msg+' contribution quotient');assert(s.probed&&s.selected.length===0&&s.groups.every(g=>g.length===c.divisor)&&ids.every(id=>pool.includes(id))&&new Set(ids).size===ids.length,msg+' original contribution identities grouped once');eq(pool.length-ids.length,remainder,msg+' exact contribution remainder');eq(s.remainder,remainder,msg+' declared original remainder');eq(s.choice,remainder===0?'complete':'remain',msg+' original number divisibility');
   });
  }else{
   const totals=t.kind==='digitSum'?t.numbers.map(n=>{let sum=0;for(const d of String(n))sum+=Number(d);return sum}):t.totals||[t.total];
   w.cards.forEach((c,i)=>{const q=Math.floor(totals[i]/t.divisor),rem=totals[i]-q*t.divisor,ids=c.groups.flat();eq(c.groups.length,q,msg+' quotient');assert(ids.every(id=>Number.isInteger(id)&&id>=0&&id<totals[i])&&new Set(ids).size===ids.length,msg+' legal original identities');eq(ids.length,q*t.divisor,msg+' grouped original count');eq(c.choice,t.kind==='remainder'?String(rem):t.kind==='parity'?rem?'odd':'even':rem?'remain':'complete',msg+' remainder judgment')});
  }
 }
 if(t.mode==='factorLab')t.numbers.forEach((n,i)=>{
  const c=w.cards[i],values=[];for(let d=1;d<=n;d++)if(n%d===0)values.push(d);
  const expectedPairs=values.filter(d=>d<=n/d).map(d=>[d,n/d]);
  assert(c.pairs.every(([a,b])=>a<=b&&Number.isInteger(a)&&Number.isInteger(b)&&a*b===n),msg+' exact factor rectangles');
  eq(new Set(c.pairs.map(p=>p.join(','))).size,c.pairs.length,msg+' rotation deduplicated');
  if(t.kind==='pairs'){assert(c.pairs.length>=t.requiredPairs&&c.pairs.every(([a])=>a>=(t.minimumSide||1)),msg+' side constraint');return}
  eq(c.pairs.map(p=>p.join(',')).sort(),expectedPairs.map(p=>p.join(',')).sort(),msg+' all unordered factor pairs');
  eq([...c.collected].sort((a,b)=>a-b),values,msg+' all distinct positive divisors');
  if(['unit','square','count'].includes(t.kind))eq(c.count,values.length,msg+' factor cardinality');
  if(['prime','unit'].includes(t.kind))eq(c.choice,n===1?'neither':values.length===2?'prime':'composite',msg+' prime definition');
  if(t.classifySquare)eq(c.choice,expectedPairs.some(([a,b])=>a===b)?'square':'nonsquare',msg+' perfect-square condition');
 });
 if(t.mode==='commonLab'){
  const timing=params=>{const overlaps=[];for(let time=1;time<=params.horizon;time++)if(time>(params.after??0)&&params.periods.every((period,i)=>time>=(params.starts?.[i]??0)&&(time-(params.starts?.[i]??0))%period===0))overlaps.push(time);const selected=t.kind==='multiples'?overlaps:overlaps.slice(0,1);eq([...w.timing.selected].sort((a,b)=>a-b),selected,msg+' offset event congruences');for(const time of selected)assert(w.timing.marks.every(line=>line.includes(time)),msg+' selected actual events')};
  const cut=params=>{const feasible=[];for(let side=1;side<=Math.min(...params.dims);side++)if(params.dims.every(n=>n%side===0))feasible.push(side);const best=feasible.at(-1);eq(w.cut.selected,best,msg+' greatest feasible square');if(params.unitSize)eq(w.cut.amount,best*params.unitSize,msg+' physical edge unit')};
  if(['multiples','least'].includes(t.kind))timing(t);
  if(t.kind==='divisors'){const expected=[];for(let size=1;size<=Math.min(...t.numbers);size++)if(t.numbers.every(n=>n%size===0))expected.push(size);eq([...w.group.collected].sort((a,b)=>a-b),expected,msg+' shared divisors')}
  if(t.kind==='greatest')cut(t);
  if(t.kind==='contexts'){timing(t.bells);cut(t.paper);eq(w.goals,['least','greatest'],msg+' contextual goals')}
 }
 if(t.mode==='cycleLab'){
  if(t.kind==='power'&&t.target===0){eq(w.choice,1,msg+' nonzero base power zero');assert(w.zeroConfirmed&&w.products.length===0&&w.generated.length===0,msg+' no multiplication applied')}
  else{
   const n=t.kind==='power'?t.period:t.base.length,origin=t.kind==='weekday'?t.start:t.indexBase===0?0:-1,direction=t.kind==='weekday'?(t.direction||1):1,mod=x=>(x%n+n)%n,expected=mod(origin+direction*t.target);
   eq(w.walk,Array.from({length:t.target},(_,i)=>mod(origin+direction*(i+1))),msg+' signed path and origin');eq(w.cursor,expected,msg+' final residue');
   eq(w.choice,t.kind==='weekday'||t.indexBase===0?expected:expected+1,msg+' index convention');
   if(t.kind==='power'){let digit=1;const digits=Array.from({length:t.period+1},()=>digit=digit*t.factor%10);eq(w.generated,digits,msg+' modular products');eq(digits[0],digits.at(-1),msg+' observed repeat');eq(w.period,t.period,msg+' digit period')}
  }
 }
 if(t.mode==='patternLab'&&t.kind==='period'){
  const observed=[...t.base,...t.base,...t.base],primitive=Array.from({length:t.base.length},(_,i)=>i+1).find(p=>observed.every((v,i)=>v===observed[i%p]));
  eq(w.length,primitive,msg+' shortest primitive block');assert(w.copied,msg+' actually replicated');
 }
}
module.exports={verify,netValid,surfaceCount,enumerate,chanceSpace,event};
