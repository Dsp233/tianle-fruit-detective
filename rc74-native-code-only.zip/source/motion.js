'use strict';
function motionPolygon(points,steps,extra={}){return {points:points.map(([x,y],i)=>({id:String.fromCharCode(65+i),x,y})),steps,...extra}}
function motionFoldPaper(folds,cuts,extra={}){return {size:4,folds,cuts,...extra}}
const MV={type:'reflect',axis:'vertical',value:0},MH={type:'reflect',axis:'horizontal',value:0},MD={type:'reflect',axis:'diagonal',value:0},FX={axis:'vertical',value:1.5,from:'low'},FY={axis:'horizontal',value:1.5,from:'low'};
const MOTION_TASKS={
 'S01.01':{kind:'axis',...motionPolygon([[-2,0],[0,2],[2,0],[0,-1]],[MV]),prompt:'找出这只风筝的对称轴。先选择原点编号，在网格标每个点镜映后的预测位置，再锁定预测；选择轴实际镜映，核验各点对应与原图是否重合。',explain:'竖轴x＝0；A与C互换，B和D在轴上对应自己，整个图保持相同。'},
 'S01.02':{kind:'mirror',...motionPolygon([[1,0],[3,0],[1,2]],[MV]),prompt:'先预测三点关于竖线x＝0镜映后的对应位置；锁定后选择这根轴，实际镜映原三角形并检验朝向。',explain:'A(−1,0)、B(−3,0)、C(−1,2)；离轴距离相同，镜映改变朝向。'},
 'S01.03':{kind:'rotate',...motionPolygon([[2,1],[3,1],[2,2]],[{type:'rotate',cx:1,cy:1,angle:90,direction:'cw'}]),prompt:'三角形绕(1,1)顺时针旋转90°。先在网格预测各点，再锁定；点旋转中心、设方向角度并真正转动原图。',explain:'相对中心转四分之一圈，得到A(1,0)、B(1,−1)、C(2,0)。中心不应默认原点。'},
 'S01.04':{kind:'translate',...motionPolygon([[-2,-1],[0,-1],[-2,1]],[{type:'translate',dx:2,dy:1}]),prompt:'把三角形向右2格、向上1格平移。先预测每点位置，再锁定；设置同一位移，让原点整体实际移动。',explain:'每点都加(2,1)，朝向和大小不变：A(0,0)、B(2,0)、C(0,2)。'},
 'S01.05':{kind:'fold',...motionFoldPaper([FX,FY],[[3,3]]),prompt:'4×4方格纸，先把左半沿x＝1.5折向右，再把下半沿y＝1.5折向上；在叠层格(3,3)剪一个方孔。先圈完全展开的预测孔格，再锁定，亲手折、剪、逐次展开核验。',explain:'叠层(3,3)来自原格(0,0)、(0,3)、(3,0)、(3,3)。剪一次穿四层，完全展开有四孔。'}
};
for(const [skillId,t] of Object.entries(MOTION_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,mode:'motionLab',contentVersion:63,phase:'练',context:'先预测、再变换、逐帧检验',hint:'镜映看轴的等距对应，旋转看指定中心与方向角，平移每点同向同距；折纸保留每层原身份，剪孔穿过当前叠层。',reason:{prompt:'什么能证明预测与实际变换一致？',options:['原身份逐点对应，轴/中心/方向/位移正确；折纸剪到的是同一叠层中所有原格，展开逐层保留孔','只要最后外形相像，不用核对点的原编号','旋转总围绕原点，剪一次总只有一个孔'],answer:0}});
if(typeof module!=='undefined')module.exports={MOTION_TASKS,motionPolygon,motionFoldPaper,MV,MH,MD,FX,FY};
