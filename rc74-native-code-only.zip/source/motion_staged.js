'use strict';
const motionFactory=typeof module!=='undefined'?require('./motion'):{motionPolygon,motionFoldPaper,MV,MH,MD,FX,FY},mp=motionFactory.motionPolygon,mf=motionFactory.motionFoldPaper,mv=motionFactory.MV,mh=motionFactory.MH,md=motionFactory.MD,fx=motionFactory.FX,fy=motionFactory.FY;
const MOTION_CASES={
 'S01.01':[
  [mp([[0,-2],[2,0],[0,2],[-1,0]],[mh]),'找横向风筝的轴，先标预测对应点，再锁定实际镜映。','横轴y＝0，A/C对应，B/D自对应。','竖轴改横轴'],
  [mp([[0,3],[2,2],[3,0],[-1,-1]],[md]),'独立从候选轴找本图对称轴，预测每点再实际镜映。','轴y＝x；A/C互换，B/D自对应。','无提示：斜轴'],
  [mp([[-1,0],[1,2],[3,0],[1,-1]],[{type:'reflect',axis:'vertical',value:1}]),'隔日找到偏离原点的竖对称轴，预测并镜映核验。','轴x＝1。','隔日：轴平移不再经过原点'],
  [mp([[0,-1],[2,1],[0,3],[-1,1]],[{type:'reflect',axis:'horizontal',value:1}]),'独立找偏移横轴，逐点预测并镜映。','轴y＝1。','备用：偏移横轴']
 ],
 'S01.02':[
  [mp([[0,1],[2,1],[0,3]],[mh]),'先预测关于y＝0的镜像，再锁定实际镜映。','各点y取相反数，朝向反转。','竖镜改横镜'],
  [mp([[0,0],[2,0],[0,1]],[{type:'reflect',axis:'vertical',value:1}]),'独立预测关于x＝1的镜像，再用正确轴变换。','A(2,0)、B(0,0)、C(2,1)。','无提示：偏移轴和轴两侧点'],
  [mp([[1,0],[2,0],[1,1]],[mv,{type:'translate',dx:1,dy:0}]),'隔日先关于x＝0镜映，再向右1格。预测最后每点，按规定顺序实际操作并回放。','先镜后移，A(0,0)、B(−1,0)、C(0,1)。','隔日：复合变换顺序明确'],
  [mp([[1,0],[3,0],[1,2]],[md]),'独立预测关于y＝x的镜像，实际变换后核验编号。','坐标互换：A(0,1)、B(0,3)、C(2,1)。','备用：斜轴镜像']
 ],
 'S01.03':[
  [mp([[1,0],[3,0],[1,2]],[{type:'rotate',cx:0,cy:0,angle:90,direction:'ccw'}]),'绕原点逆时针90°，先预测再设中心方向角实际旋转。','(x,y)变(−y,x)。','换中心并顺时针改逆时针'],
  [mp([[2,1],[3,1],[2,2]],[{type:'rotate',cx:1,cy:1,angle:180,direction:'cw'}]),'独立绕(1,1)旋转180°，预测并真正转图。','A(0,1)、B(−1,1)、C(0,0)。','无提示：半圈与非原点中心'],
  [mp([[0,1],[1,1],[0,2]],[{type:'rotate',cx:-1,cy:1,angle:90,direction:'cw'}]),'隔日绕(−1,1)顺时针90°，先预测再实际旋转。','相对新中心转动，中心不变。','隔日：负坐标中心'],
  [mp([[1,0],[2,0],[1,1]],[{type:'rotate',cx:0,cy:0,angle:270,direction:'ccw'}]),'独立绕原点逆时针270°，先预测再实际旋转并回放。','与顺时针90°终态相同，仍按指定方向角执行。','备用：等终态但不同指定转向角']
 ],
 'S01.04':[
  [mp([[0,0],[2,0],[0,1]],[{type:'translate',dx:-2,dy:2}]),'向左2、向上2，逐点预测后锁定实际平移。','所有点同加(−2,2)。','向右改向左并同时上移'],
  [mp([[-1,1],[1,1],[-1,3]],[{type:'translate',dx:1,dy:-2}]),'独立向右1、向下2，预测并实际移动全图。','所有点加(1,−2)，保留朝向。','无提示：向下与负坐标'],
  [mp([[1,0],[2,0],[1,1]],[{type:'translate',dx:1,dy:0},mv]),'隔日先向右1，再关于x＝0镜映。先预测最终点，按指定顺序操作并回放；与先镜后移比较位置。','先移后镜，A(−2,0)、B(−3,0)、C(−2,1)，不同于先镜后移。','隔日：与S01.02对照复合顺序'],
  [mp([[1,-1],[3,-1],[1,1]],[{type:'translate',dx:-1,dy:0}]),'独立只向左1，逐点预测和实际移动；竖坐标保持不变。','每点只减横坐标1。','备用：零纵向位移边界']
 ],
 'S01.05':[
  [mf([fx],[[3,1]]),'只把左半折向右，剪叠层格(3,1)。先预测展开孔，再实际折剪并逐层展开。','原(0,1)、(3,1)两孔。','两折改一折、四层改两层'],
  [mf([fy,fx],[[2,3]]),'独立先下半折上，再左半折右，剪(2,3)。先预测完全展开孔，再实操。','原(1,0)、(1,3)、(2,0)、(2,3)。','无提示：折序与切口换位置'],
  [mf([fx,fy],[[2,2],[3,3]]),'隔日两折后剪(2,2)与(3,3)两个方孔。先预测展开所有孔，再操作折剪展开。','两个叠层孔各穿4原格，共8孔。','隔日：两个切口与叠层原身份'],
  [mf([fy],[[1,2]]),'独立只把下半折上，剪(1,2)并展开；先预测各原孔格。','原(1,1)、(1,2)两孔。','备用：横折与相邻孔']
 ]
};
const motionSource=typeof module!=='undefined'?require('./motion').MOTION_TASKS:MOTION_TASKS,motionTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(MOTION_CASES)){motionTarget[skillId]={};for(const [i,stage] of ['transfer','independent','delayed','independent2'].entries()){const [params,prompt,explain,changeDimension]=cases[i];motionTarget[skillId][stage]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,mode:'motionLab',kind:motionSource[skillId].kind,contentVersion:64,phase:stage==='transfer'?'迁移':stage==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,context:'原身份变换与叠层展开',...(stage==='transfer'?{hint:'先预测并锁定；按指定轴、中心、方向或位移操作；每折保留全部原纸层身份。'}:{})}}}
if(typeof module!=='undefined')module.exports={MOTION_CASES};
