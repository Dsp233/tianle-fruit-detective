"""Package the exported Muse registry with exact source and acceptance evidence."""
import hashlib, json, pathlib, subprocess, zipfile
root = pathlib.Path(__file__).resolve().parent.parent
out = root / 'muse'
meta = json.loads((out/'families.json').read_text())
gate = json.loads((root/'docs/evidence/2026-10-08-rc67-production/production-gates.json').read_text())
assert gate['result']=='passed'
assert gate['productionSha256']==meta['productionSha256']
assert gate['qaSha256']==meta['qaSha256']
(out/'production-gates.json').write_text(json.dumps(gate, ensure_ascii=False, indent=2)+'\n')
(out/'legacy-record-fixture.json').write_bytes((root/'source/qa_rc64_fixture.json').read_bytes())
bundle = root/'artifacts/rc67-muse-source.bundle'
subprocess.run(['git','bundle','create',str(bundle),'experiment/rc67-full-local'],cwd=root,check=True)
boundaries = pathlib.Path(subprocess.check_output(['git','rev-parse','--git-path','shallow'],cwd=root,text=True).strip())
if not boundaries.is_absolute(): boundaries = root/boundaries
shallow = boundaries.read_bytes() if boundaries.exists() else b''
archive = out/'rc67-muse-handoff.zip'
files = []
for folder in ['source','docs/evidence/2026-10-08-rc67-full','docs/evidence/2026-10-08-rc67-preview','docs/evidence/2026-10-08-rc67-production']:
    files.extend(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for name in ['docs/rc67-progress.json','docs/rc67-implementation-report.md','docs/rc67-full-optimization-plan.md','docs/deployment-2026-10-08-rc67-preview.md','docs/rc67-production-handoff.md','docs/exam-review-ledger.csv','index.html','amc8/index.html','qa/index.html','qa/history/index.html']:
    files.append(root/name)
files.extend(p for p in out.iterdir() if p.is_file() and p.suffix!='.zip' and p.name!='package-manifest.json')
files=sorted(set(files))
manifest={'sourceCommit':meta['sourceCommit'],'productionSha256':meta['productionSha256'],'qaSha256':meta['qaSha256'],'files':[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],'limits':['Synthetic records only; no private user data','Source history preserves the original shallow boundary; restore with restore-source.py','Browser full matrix not completed']}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for file in files:z.write(file,file.relative_to(root).as_posix())
    z.write(bundle,'rc67-source.bundle')
    z.writestr('rc67-source.shallow',shallow)
    z.write(root/'source/restore_rc67_source.py','restore-source.py')
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest['files']:
        data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
package={**{k:manifest[k] for k in ['sourceCommit','productionSha256','qaSha256']},'package':'rc67-muse-handoff.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'fileCount':len(files)+4,'verified':'all individual file hashes and ZIP integrity passed'}
(out/'package-manifest.json').write_text(json.dumps(package,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(package,ensure_ascii=False))
