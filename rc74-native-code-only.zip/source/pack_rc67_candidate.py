"""Package the committed, program-verified RC67 candidate without deployment."""
import hashlib
import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ARTIFACTS = ROOT / 'artifacts'
DEST = ARTIFACTS / 'rc67-local-candidate'
EVIDENCE = ROOT / 'docs/evidence/2026-10-08-rc67-full'
BRANCH = 'experiment/rc67-full-local'
BASELINES = [
    '6d5627938a575792a9ca6f9e99b562ed1c6e191d',
    'e987c946c017c4ad42a8bc34c09ad4d075bef6a2',
    '2b7c7e82685e85729fb37bbc65935ee5ac16d23d',
]


def run(*command, cwd=ROOT):
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(' '.join(command) + '\n' + result.stdout + result.stderr)
    return (result.stdout + result.stderr).strip()


def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def main():
    assert run('git', 'branch', '--show-current') == BRANCH
    assert not run('git', 'status', '--porcelain'), 'Commit the candidate before packaging'
    head = run('git', 'rev-parse', 'HEAD')
    progress = json.loads((ROOT / 'docs/rc67-progress.json').read_text())
    assert progress['completed'] == 17 and progress['total'] == 20
    assert {p['id'] for p in progress['packages'] if p['status'] == 'blocked'} == {'02', '19', '20'}
    normal_hash = digest(ROOT / 'index.html')
    local_hash = digest(ROOT / 'local-preview/index.html')
    for name in ['automated-gates', 'normal-entry', 'default-start-reachability']:
        data = json.loads((EVIDENCE / (name + '.json')).read_text())
        assert data['result'] == 'passed' and data['testedBuildSha256'] == normal_hash, name
    summary = json.loads((EVIDENCE / 'verification-summary.json').read_text())
    assert summary['builds']['normal']['sha256'] == normal_hash
    assert summary['builds']['isolated']['sha256'] == local_hash
    for section in ['sourceFiles', 'evidenceFiles']:
        for row in summary[section]:
            assert digest(ROOT / row['path']) == row['sha256'], row['path'] + ' changed after summary'
    print(run('python3', 'source/build.py', '--check'))
    print(run('python3', 'source/build.py', '--local-prototype', '--check'))
    ARTIFACTS.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='rc67-package-') as temporary:
        staging = Path(temporary) / 'rc67-local-candidate'
        staging.mkdir()
        shutil.copyfile(ROOT / 'local-preview/index.html', staging / 'index.html')
        shutil.copyfile(EVIDENCE / 'diagram-gallery.html', staging / 'diagram-gallery.html')
        documents = staging / 'docs'
        documents.mkdir()
        for name in ['rc67-full-optimization-plan.md', 'rc67-implementation-report.md',
                     'rc67-progress.json', 'rc67-baseline-inventory.json']:
            shutil.copyfile(ROOT / 'docs' / name, documents / name)
        shutil.copytree(EVIDENCE, documents / 'evidence/2026-10-08-rc67-full')
        bundle = staging / 'rc67-source.bundle'
        print(run('git', 'bundle', 'create', str(bundle), BRANCH))
        print(run('git', 'bundle', 'verify', str(bundle)))
        shallow_path = Path(run('git', 'rev-parse', '--git-path', 'shallow'))
        boundaries = shallow_path.read_text() if shallow_path.exists() else ''
        (staging / 'rc67-source.shallow').write_text(boundaries)
        shutil.copyfile(ROOT / 'source/restore_rc67_source.py', staging / 'restore-source.py')
        restored = Path(temporary) / 'restored-source'
        print(run('python3', str(staging / 'restore-source.py'), str(restored)))
        assert run('git', 'rev-parse', 'HEAD', cwd=restored) == head
        for commit in BASELINES:
            run('git', 'cat-file', '-e', commit + '^{commit}', cwd=restored)
        run('python3', 'source/build.py', cwd=restored)
        run('python3', 'source/build.py', '--check', cwd=restored)
        run('python3', 'source/build.py', '--local-prototype', '--check', cwd=restored)
        assert digest(restored / 'index.html') == normal_hash
        assert digest(restored / 'local-preview/index.html') == local_hash
        (staging / 'README.md').write_text(
            '# RC67 本地程序候选\n\n'
            '**17/20（85%）**。数学与模拟状态验证通过；真实浏览器验收未完成。\n\n'
            '## 使用\n\n解压后打开 `index.html`，选择主题，开始默认 10 题。'
            '推荐在此目录运行 `python3 -m http.server 8768`，'
            '再访问 `http://127.0.0.1:8768`。提示、解法、语音和变式均可选。\n\n'
            '本候选使用独立学习记录；没有公网部署，也不需要真人审核签字。'
            '打开页面不调用收费的题目生成接口。\n\n'
            '## 文件\n\n'
            '- `diagram-gallery.html`：140 族主问题和变式的渲染图册，不是截图证据。\n'
            '- `docs/rc67-implementation-report.md`：变化、验证、限制及回退。\n'
            '- `docs/evidence/2026-10-08-rc67-full/`：本轮证据和历史失败尝试。\n'
            '- `manifest.json`：逐文件哈希、源码提交、构建标识。\n'
            '- `rc67-source.bundle`：当前源码及本机已保留历史，含兼容测试依赖的提交。\n'
            '- `rc67-source.shallow`、`restore-source.py`：保留原浅克隆边界并恢复源码。\n\n'
            '## 恢复源码\n\n'
            '```sh\npython3 restore-source.py rc67-source\n'
            'cd rc67-source\npython3 source/build.py\n'
            'python3 source/build.py --local-prototype\n'
            'python3 source/build.py --check\n'
            'python3 source/build.py --local-prototype --check\n```\n\n'
            '具体测试脚本见报告；历史门禁入口为 `python3 source/run_rc67_checks.py`。'
            '浏览器自动脚本需要已安装的 Playwright/Chromium，尚未执行；'
            '运行页面本身无需这些开发工具。\n\n'
            '源码历史继承原仓库的浅克隆边界。更早的远端历史未下载，'
            '不能直接用普通 `git clone` 恢复该 bundle；请使用上述脚本。\n\n'
            '## 回退\n\n在恢复目录检出 RC66 基线 '
            '`2b7c7e82685e85729fb37bbc65935ee5ac16d23d` 并重新构建。'
            '原 RC66 工作目录和公网网站未改动。\n', encoding='utf-8')
        rows = [{'path': p.relative_to(staging).as_posix(), 'bytes': p.stat().st_size,
                 'sha256': digest(p)} for p in sorted(staging.rglob('*')) if p.is_file()]
        manifest = {
            'release': 'V12.0-rc.67-local', 'sourceBranch': BRANCH, 'sourceCommit': head,
            'completion': {'completed': 17, 'total': 20, 'percent': 85},
            'browserAcceptance': 'blocked', 'publicDeployment': False,
            'humanReviewRequired': False, 'builds': summary['builds'],
            'sourceHistory': {'originalShallowBoundaries': boundaries.splitlines(),
                              'olderRemoteHistoryIncluded': False if boundaries else True},
            'restorationVerified': {'sameCommit': True, 'gitFsckPassed': True,
                                    'baselineCommitsPresent': BASELINES,
                                    'normalBuildMatches': True, 'isolatedBuildMatches': True},
            'files': rows,
            'manifestSelfHash': 'Excluded to avoid a recursive hash; ZIP hash is supplied separately',
        }
        (staging / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        archive = ARTIFACTS / 'rc67-local-candidate.zip'
        temporary_zip = Path(temporary) / archive.name
        with zipfile.ZipFile(temporary_zip, 'w', compression=zipfile.ZIP_DEFLATED) as output:
            for file in sorted(staging.rglob('*')):
                if file.is_file():
                    output.write(file, 'rc67-local-candidate/' + file.relative_to(staging).as_posix())
        with zipfile.ZipFile(temporary_zip) as packaged:
            assert packaged.testzip() is None
            assert len(packaged.namelist()) == len(rows) + 1
            for row in rows:
                data = packaged.read('rc67-local-candidate/' + row['path'])
                assert len(data) == row['bytes']
                assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
            assert hashlib.sha256(packaged.read('rc67-local-candidate/index.html')).hexdigest() == local_hash
        if DEST.exists():
            shutil.rmtree(DEST)
        shutil.copytree(staging, DEST)
        shutil.copyfile(temporary_zip, archive)
        checksum = archive.with_suffix('.zip.sha256')
        checksum.write_text(digest(archive) + '  ' + archive.name + '\n')
        print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                          'sha256': digest(archive), 'sourceCommit': head,
                          'packagedFiles': len(rows) + 1, 'result': 'verified_candidate',
                          'progress': '17/20', 'browser': 'blocked'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
