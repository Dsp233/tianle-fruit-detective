"""Package a frozen, code-only RC70 candidate for isolated CI; never deploy."""
import argparse, hashlib, json, pathlib, zipfile

def package(candidate,out):
    contract=json.loads((candidate/'release-contract.json').read_text())
    assert all(hashlib.sha256((candidate/name).read_bytes()).hexdigest()==h for name,h in contract['files'].items())
    rows=[]
    for p in sorted(candidate.rglob('*')):
        if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
        name=p.relative_to(candidate).as_posix()
        maintenance='muse/rc'+contract['release']['siteVersion'].split('rc.')[1]+'/maintenance.html'
        allowed=name.startswith(('source/','qa/','amc8/','academy/','docs/')) or name in ['index.html','release-contract.json','scope.json','frozen-identity.json',maintenance]
        if not allowed:raise RuntimeError('Unregistered export path: '+name)
        if p.suffix not in ['.js','.py','.json','.html','.css','.csv']:raise RuntimeError('Unregistered export type: '+name)
        rows.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
    transfer={'schema':1,'buildId':contract['buildId'],'sourceTreeHash':contract['sourceTreeHash'],'files':rows,'exportScope':'code, generated pages and synthetic compatibility fixtures only','realLearningRecordsIncluded':False}
    out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for row in rows:
            info=zipfile.ZipInfo(row['path'],(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,(candidate/row['path']).read_bytes())
        info=zipfile.ZipInfo('transfer-manifest.json',(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,json.dumps(transfer,ensure_ascii=False,separators=(',',':')).encode())
    receipt={'buildId':contract['buildId'],'zipSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'files':len(rows)}
    out.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--candidate',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--dry-run',action='store_true');a=p.parse_args()
    if a.dry_run:print(json.dumps({'candidate':str(a.candidate),'out':str(a.out)}))
    else:print(json.dumps(package(a.candidate.resolve(),a.out.resolve()),indent=2))
