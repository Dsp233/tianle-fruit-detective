'use strict';
const PATTERN_TASKS={
 'L03.01':{kind:'period',base:['🔴','🔵'],context:'彩灯',prompt:'彩灯显示红蓝红蓝红蓝。圈出最短重复块，再让这块连续复制，看看是否和原串一致。',explain:'最短重复块是红蓝两格；红蓝红蓝虽也能重复，却不是最短。',reason:{prompt:'为什么要选两格？',options:['红蓝两格能生成全串，且一格不能','四格也能重复，所以四格一定最短','只看末尾两格'],answer:0}},
 'L03.02':{kind:'arithmetic',initial:[2,5,8,11],step:3,context:'楼梯编号',prompt:'2、5、8、11 每次跳相同的数。调好跳数，在数轴式序列上连续添两项。',explain:'每步加3，接下来14、17。',reason:{prompt:'为什么接下来是14、17？',options:['相邻两项的差都是3','每步乘3','只看最后一个11加1'],answer:0}},
 'L03.03':{kind:'geometric',initial:[2,4,8,16],factor:2,context:'翻倍贴纸',prompt:'2、4、8、16，每一轮按相同倍数增加。选倍数，连续复制两轮。',explain:'每轮乘2，得到32、64；差不是固定的数。',reason:{prompt:'为什么下一项是32？',options:['16乘2，倍数保持相同','16加2','把前两项相加'],answer:0}},
 'L03.04':{kind:'explicit',initial:[2],multiplier:2,add:1,context:'变数机器',prompt:'机器规定“把前项乘2，再加1”。从2开始，每轮亲手先乘后加，完成两轮。',explain:'2→5→11；每轮都重新对上一项乘2再加1。',reason:{prompt:'第二轮从哪个数开始？',options:['从第一轮的5重新乘2再加1','每次都回到最初的2','把两个结果相加'],answer:0}},
 'L03.05':{kind:'twoPrev',initial:[1,2],count:2,context:'接力数字卡',prompt:'前两项1、2，从第三项起每项等于前两项之和。每轮选两张前项卡合成下一张，连续做两轮。',explain:'1＋2＝3，再用2＋3＝5。',reason:{prompt:'第四项为什么是5？',options:['取刚得到的3与它前一项2相加','始终把最初1和2相加','只把上一步的3翻倍'],answer:0}},
 'L03.06':{kind:'grid',rows:3,cols:4,start:'red',context:'红蓝座位方格',prompt:'第一行已交替红蓝；相邻行的起色对调。逐格涂出下面两行，核对横向和纵向都交替。',explain:'行列每移动一格就换色；第2行蓝红蓝红，第3行红蓝红蓝。',reason:{prompt:'第2行第1格为什么是蓝？',options:['与正上方红格相邻，颜色要对调','每行都必须从红开始','只看本行最后一格'],answer:0}}
};
for(const [skillId,t] of Object.entries(PATTERN_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:27,mode:'patternLab',phase:'练',hint:'先读每一步的规则，再用材料实际生成后续项或格子。'});
if(typeof module!=='undefined')module.exports={PATTERN_TASKS};
