'use strict';
const PATTERN_CASES={
 'L03.01':[
  [{kind:'period',base:['🔺','🟦','🟦'],context:'形状腰带'},'腰带重复三角、方、方。圈出最短的一组，再复制验证整条腰带。','最短一组是三角、方、方三格。','由双色两格换成有重复相邻方块的三格节'],
  [{kind:'period',base:['🍎','🍐'],context:'水果卡边框'},'苹果梨交替排成一圈。独立找最短重复块并复制验证。','苹果梨两格最短。','无提示：图案换水果'],
  [{kind:'period',base:['A','B','C'],context:'字母灯'},'字母A、B、C按序反复亮起。隔日找最短节并重复。','A、B、C三格是最短节。','隔日：三种字母无相邻同色'],
  [{kind:'period',base:['红','红','蓝'],context:'织物条纹'},'条纹红、红、蓝循环。独立确定最短节并复制。','红红蓝三格最短。','备用：同色连续两格在开头']
 ],
 'L03.02':[
  [{kind:'arithmetic',initial:[5,9,13],step:4,context:'编号台阶'},'台阶编号5、9、13。设定每步跳几格，继续添加两级。','差为4，后面17、21。','原来加3，改为加4且起点不同'],
  [{kind:'arithmetic',initial:[20,17,14],step:-3,context:'倒计数刻度'},'刻度20、17、14依次下降。独立调步长，再添两格。','每步减3，接着11、8。','无提示：增长改为下降'],
  [{kind:'arithmetic',initial:[1,6,11],step:5,context:'公交站号'},'站号1、6、11按固定间隔排列。隔日调好跳数并接两项。','间隔5，接着16、21。','隔日：初值1、步长5'],
  [{kind:'arithmetic',initial:[12,10,8],step:-2,context:'剩余贴纸'},'数量12、10、8每轮相同变化。独立续写两项。','每步少2，接着6、4。','备用：减少型等差']
 ],
 'L03.03':[
  [{kind:'geometric',initial:[3,6,12],factor:2,context:'分裂的纸片'},'纸片从3、6、12依次变化。调倍数，再实际复制后两轮。','每轮翻倍，接着24、48。','同倍数但起点改三，并与加3区分'],
  [{kind:'geometric',initial:[1,3,9],factor:3,context:'树枝分叉'},'树枝段数1、3、9。独立选相同倍数并续两轮。','每轮乘3，接着27、81。','无提示：倍数改3'],
  [{kind:'geometric',initial:[4,8,16],factor:2,context:'豆苗数量'},'豆苗4、8、16逐轮同倍。隔日接两轮。','再得32、64。','隔日：起点4'],
  [{kind:'geometric',initial:[2,6],factor:3,context:'三倍奖励卡'},'奖励卡从2变6，之后每轮相同倍数。独立续两轮。','6→18→54，每轮乘3。','备用：只给两项作为线索']
 ],
 'L03.04':[
  [{kind:'explicit',initial:[1],multiplier:3,add:2,context:'新变数机器'},'新机器规定每轮先乘3再加2。从1开始按顺序做两轮。','1→5→17。','同时改变乘数和加数'],
  [{kind:'explicit',initial:[3],multiplier:2,add:2,context:'能量机'},'能量3起，每轮先翻倍再添2。独立做两轮。','3→8→18。','无提示：起点改3，加数改2'],
  [{kind:'explicit',initial:[2],multiplier:3,add:1,context:'彩珠机'},'彩珠2起，每轮乘3再加1。隔日依规则做两轮。','2→7→22。','隔日：先乘3后添1'],
  [{kind:'explicit',initial:[4],multiplier:2,add:1,context:'积分机'},'积分4起，每轮先乘2再加1，做两轮。','4→9→19。','备用：起点4']
 ],
 'L03.05':[
  [{kind:'twoPrev',initial:[2,3],count:2,context:'双色接力卡'},'从2、3出发，每张新卡等于紧邻的前两张之和。逐次挑卡合成两项。','2＋3＝5，3＋5＝8。','种子从1、2换成2、3'],
  [{kind:'twoPrev',initial:[2,2],count:2,context:'接力分数牌'},'前两张是2、2。独立选相邻前两项，生成后两张。','2＋2＝4，2＋4＝6。','无提示：初始两项相同'],
  [{kind:'twoPrev',initial:[3,4],count:2,context:'树苗接力'},'数列3、4，之后每项取紧邻前两项的和。隔日生成两项。','3＋4＝7，4＋7＝11。','隔日：初始3、4'],
  [{kind:'twoPrev',initial:[1,3],count:2,context:'记分板'},'初始1、3。每轮选紧邻两项相加。独立生成两项。','1＋3＝4，3＋4＝7。','备用：初始不同差距']
 ],
 'L03.06':[
  [{kind:'grid',rows:3,cols:3,start:'blue',context:'蓝起点地砖'},'第一行从蓝开始交替。纵向也相邻换色；逐格补完其余两行。','蓝红蓝／红蓝红／蓝红蓝。','起色由红改蓝，四列改三列'],
  [{kind:'grid',rows:2,cols:5,start:'red',context:'剧院座位'},'座位第一行红蓝交替。第二行每座要与上方反色，独立补齐。','第二行蓝红蓝红蓝。','无提示：两行五列'],
  [{kind:'grid',rows:4,cols:3,start:'blue',context:'棋盘方格'},'棋盘第一行蓝红蓝，行列相邻均换色。隔日补完下面三行。','第二行红蓝红，第三行蓝红蓝，第四行红蓝红。','隔日：四行三列'],
  [{kind:'grid',rows:3,cols:5,start:'red',context:'彩纸地毯'},'红起点五列的第一行已给出。逐格涂完其余两行，使行列都交替。','第二行蓝红蓝红蓝，第三行红蓝红蓝红。','备用：三行五列']
 ]
};
const patternStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(PATTERN_CASES)){
 if(cases.length!==4)throw Error('Four L03 cases required: '+skillId);patternStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];patternStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:28,mode:'patternLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先对照生成规则，再动手续上两步或补齐整行。'}:{})};
 }
}
for(const tasks of Object.values(patternStageTarget))for(const t of Object.values(tasks))if(['测','巩固'].includes(t.phase)&&['arithmetic','geometric','explicit','twoPrev'].includes(t.kind))t.contentVersion=70;
Object.assign(patternStageTarget['L03.01'].independent,{base:["A", "B", "A", "C"],contentVersion:70,prompt:'圈出这串图案的最短重复块，再用它生成整串；字母表示不同的图形。',explain:'必须保留重复块内部的排列关系；换字母不产生新数学实例。'});
if(typeof module!=='undefined')module.exports={PATTERN_CASES};
