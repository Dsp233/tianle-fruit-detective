'use strict';
const PERCENT_CASES={
 'A04.01':[
  ['12张贴纸组成整体。逐张点亮3张，判断它们占整体的百分数。',{kind:'shade',total:12,target:3,choices:['25%','3%','75%'],correctChoice:'25%'},'3/12＝1/4＝25%。','20格换12张贴纸'],
  ['整体是16格，涂出4格，选所占百分数。',{kind:'shade',total:16,target:4,choices:['25%','4%','75%'],correctChoice:'25%'},'4/16＝25%。','16格新整体'],
  ['一板8格取2格，选出占原整体的百分数。',{kind:'shade',total:8,target:2,choices:['25%','2%','50%'],correctChoice:'25%'},'2/8＝25%。','8格隔日实例'],
  ['24块积木作为整体，点亮其中6块，选百分数。',{kind:'shade',total:24,target:6,choices:['25%','6%','75%'],correctChoice:'25%'},'6/24＝25%。','24块新整体']
 ],
 'A04.02':[
  ['20格条涂出一半，再选与50%等值的分数。',{kind:'shade',total:20,target:10,choices:['1/2','1/5','50'],correctChoice:'1/2'},'10/20＝1/2＝50%。','75%换50%'],
  ['20格条涂出20%，选择相等的分数。',{kind:'shade',total:20,target:4,choices:['1/5','1/4','20'],correctChoice:'1/5'},'4/20＝1/5＝20%。','百分数换20%'],
  ['20格条涂出60%，选出等值分数。',{kind:'shade',total:20,target:12,choices:['3/5','3/4','60'],correctChoice:'3/5'},'12/20＝3/5＝60%。','60%隔日实例'],
  ['20格条涂40%，选出等值分数。',{kind:'shade',total:20,target:8,choices:['2/5','2/3','40'],correctChoice:'2/5'},'8/20＝2/5＝40%。','40%新实例']
 ],
 'A04.03':[
  ['16颗星的25%是多少颗？逐格点出部分量，再选颗数。',{kind:'shade',total:16,target:4,choices:['4','16','25'],correctChoice:'4'},'16的一半再一半是4。','整体由20换16'],
  ['30颗星的20%是多少？逐格点亮并选颗数。',{kind:'shade',total:30,target:6,choices:['6','20','30'],correctChoice:'6'},'30的五分之一是6。','目标百分比变20%'],
  ['24颗星的50%是多少？逐格点亮并选颗数。',{kind:'shade',total:24,target:12,choices:['12','24','50'],correctChoice:'12'},'24的一半是12。','50%新整体'],
  ['40颗星的75%是多少？点亮所求部分并选择数量。',{kind:'shade',total:40,target:30,choices:['30','40','75'],correctChoice:'30'},'40的四分之三是30。','75%与40颗新实例']
 ],
 'A04.04':[
  ['整体的20%是8颗。把8颗当一份，逐份复制到完整整体，再选总数。',{kind:'whole',part:8,copies:5,choices:['40','8','20'],correctChoice:'40'},'20%是一份五分之一，五份8颗合成40。','25%改20%，四份改五份'],
  ['一个整体的25%是6颗，复制相同份直到得到完整整体。',{kind:'whole',part:6,copies:4,choices:['24','6','25'],correctChoice:'24'},'四份各6颗合成24。','一份改6颗'],
  ['一个整体的50%是12颗，复制成完整整体。',{kind:'whole',part:12,copies:2,choices:['24','12','50'],correctChoice:'24'},'两半各12颗，整体24颗。','基准百分比改一半'],
  ['一个整体的20%是5颗，复制到完整整体。',{kind:'whole',part:5,copies:5,choices:['25','5','20'],correctChoice:'25'},'五份各5颗，完整整体25颗。','五等份的新实例']
 ],
 'A04.05':[
  ['从200先涨10%，再从新数降10%。逐个添20并从220逐个拿走22，选最终量。',{kind:'change',start:200,add:20,remove:22,choices:['198','200','180'],correctChoice:'198'},'200＋20＝220，220－22＝198。','起点由100换200'],
  ['从50先涨20%，再按新数降20%。逐个添10，再从60拿走12。',{kind:'change',start:50,add:10,remove:12,choices:['48','50','40'],correctChoice:'48'},'50＋10＝60，60－12＝48。','比例换20%和较小基准'],
  ['从80先涨25%，再按新数降25%。添20后从100拿走25。',{kind:'change',start:80,add:20,remove:25,choices:['75','80','60'],correctChoice:'75'},'80＋20＝100，100－25＝75。','比例换四分之一'],
  ['从150先涨20%，再按新数降20%。添30后从180拿走36。',{kind:'change',start:150,add:30,remove:36,choices:['144','150','120'],correctChoice:'144'},'150＋30＝180，180－36＝144。','150作原基准的新实例']
 ],
 'A04.06':[
  ['估算29×41。把两数调到30和40，观察百格块并选合理量级。',{kind:'estimate',a:29,b:41,targetA:30,targetB:40,choices:['约1200','约120','约12000'],correctChoice:'约1200'},'30×40＝1200，29×41接近这个量级。','因数换29与41'],
  ['估算39×19，调到邻近整十后选量级。',{kind:'estimate',a:39,b:19,targetA:40,targetB:20,choices:['约800','约80','约8000'],correctChoice:'约800'},'40×20＝800。','两个因数都向上取整十'],
  ['估算58×31，调整到60与30并选量级。',{kind:'estimate',a:58,b:31,targetA:60,targetB:30,choices:['约1800','约180','约18000'],correctChoice:'约1800'},'60×30＝1800。','58向上调两格'],
  ['估算69×29，调整到70与30并选量级。',{kind:'estimate',a:69,b:29,targetA:70,targetB:30,choices:['约2100','约210','约21000'],correctChoice:'约2100'},'70×30＝2100。','两个因数的新实例']
 ]
};
const percentStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(PERCENT_CASES)){
 if(cases.length!==4)throw Error('Four A04 cases required: '+skillId);
 percentStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [prompt,params,explain,changeDimension]=cases[i];
  percentStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:12,mode:'percentLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,
   ...(kind==='transfer'?{hint:'先确定哪一个量是本题的整体或第二次变化的基准，再逐步操作。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={PERCENT_CASES};
