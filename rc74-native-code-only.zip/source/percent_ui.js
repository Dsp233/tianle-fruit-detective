'use strict';
function percentState(t){
 if(draft.work){
  const w=draft.work;
  if(t.kind==='change'&&!w.activeIds){
   w.activeIds=Array.from({length:t.start},(_,i)=>'I'+(i+1));w.removedIds=[];
   const add=()=>w.activeIds.push(...Array.from({length:w.added},(_,i)=>'A'+(i+1))),remove=()=>{if(w.removed)w.removedIds.push(...w.activeIds.splice(-w.removed))};
   if(t.changeOrder==='removeFirst'){remove();add()}else{add();remove()}
  }
  return w;
 }
 const w={selected:[],copies:0,phase:1,added:0,removed:0,a:t.a,b:t.b,choice:'',reference:'',moves:0};
 if(t.kind==='change')Object.assign(w,{activeIds:Array.from({length:t.start},(_,i)=>'I'+(i+1)),removedIds:[]});
 if(t.kind==='whole'&&t.knownShares)Object.assign(w,{copies:t.knownShares,pool:Array.from({length:t.knownCount},(_,i)=>'K'+(i+1)),bins:Array.from({length:t.knownShares},()=>[]),copiedGroups:[]});
 if(t.kind==='estimate'&&t.bounds)Object.assign(w,{boundStage:'lower',boundRecords:{}});
 return draft.work=w;
}
function percentChoices(t){return choiceButtons(t,t.choices.map(v=>[v,v]),'percentChoice')}
function percentMarks(ids){return ids.map(id=>`<i data-object-id="${esc(id)}" aria-hidden="true"></i>`).join('')}
function percentChangeVisual(t,w){return `<div class="percent-visual"><section><b>当前盘</b><div class="percent-dots" role="img" aria-label="当前盘中的点">${percentMarks(w.activeIds)}</div></section><section><b>拿走的原点</b><div class="percent-dots removed">${percentMarks(w.removedIds)}</div></section></div>`}
function percentBoundArea(r,label){return `<section><h4>${label}：${r.a}×${r.b}</h4><div class="percent-hundreds" style="display:grid;grid-template-columns:repeat(${r.a/10},1fr)">${Array.from({length:r.a*r.b/100},()=>'<span>100</span>').join('')}</div></section>`}
function percentBoard(t){
 const w=percentState(t),formal=assessmentFormal(t);
 if(t.kind==='shade'){
  const cell=i=>`<button data-action="percentCell" data-index="${i}" class="percent-cell ${w.selected.includes(i)?'lit':''}" aria-label="第${i+1}个等份" aria-pressed="${w.selected.includes(i)}">${t.wholeShape==='circle'?i+1:''}</button>`;
  const content=t.wholeShape==='circle'?`<div class="fraction-circle"><svg viewBox="0 0 300 300" role="img" aria-label="同一个圆平均分${t.total}份">${Array.from({length:t.total},(_,i)=>`<path d="${fractionSectorPath(i,t.total)}" fill="${w.selected.includes(i)?'#f3bd63':'#fff'}" stroke="#4d8674" stroke-width="2"/>`).join('')}</svg><div class="fraction-sector-controls">${Array.from({length:t.total},(_,i)=>cell(i)).join('')}</div></div>`:t.wholeIndices?`<div class="reference-material ${w.reference==='table'?'reference-selected':''}"><section class="reference-group ${w.reference==='frame'?'reference-selected':''}"><h4>框内</h4><div class="percent-grid">${t.wholeIndices.map(cell).join('')}</div></section><section><h4>框外</h4><div class="percent-grid">${Array.from({length:t.total},(_,i)=>i).filter(i=>!t.wholeIndices.includes(i)).map(cell).join('')}</div></section></div>`:`<div class="percent-grid">${Array.from({length:t.total},(_,i)=>cell(i)).join('')}</div>`;
  return `<div class="board percent-board"><h3>先确认同一个整体</h3>${t.requireWholeSelection?`<div class="work-buttons"><button data-action="percentReference" data-value="frame" aria-pressed="${w.reference==='frame'}">框内作为整体</button><button data-action="percentReference" data-value="table" aria-pressed="${w.reference==='table'}">全桌作为整体</button></div>`:''}${content}<p>已涂 ${w.selected.length} 份。选择对应的量：</p>${percentChoices(t)}</div>`;
 }
 if(t.kind==='whole'){
  const split=t.knownShares,ready=split&&!w.pool.length&&w.bins.every(ids=>ids.length===t.part);
  const known=split?`<h3>已知部分 ${t.knownCount} 颗</h3><div class="percent-dots">${percentMarks(w.pool)}</div><div class="percent-groups">${w.bins.map((ids,i)=>`<section class="percent-group"><p>单位份${i+1}</p><div class="percent-dots">${percentMarks(ids)}</div><button data-action="percentSplit" data-index="${i}" ${!w.pool.length?'disabled':''}>放入1颗</button><button data-action="percentUnsplit" data-index="${i}" ${!ids.length||w.copiedGroups.length?'disabled':''}>放回1颗</button></section>`).join('')}</div>`:`<h3>一份 ${t.part} 颗</h3>`;
  const groups=split?w.copiedGroups:Array.from({length:w.copies},(_,i)=>Array.from({length:t.part},(_,j)=>`C${i+1}-${j+1}`));
  return `<div class="board percent-board">${known}<div class="percent-groups">${groups.map(ids=>`<div class="percent-group"><div class="percent-dots">${percentMarks(ids)}</div></div>`).join('')}</div><div class="work-buttons"><button data-action="percentCopy" ${w.copies>=8||split&&!ready?'disabled':''}>＋ 补出一个单位份</button><button data-action="percentUncopy" ${w.copies>(split?t.knownShares:0)?'':'disabled'}>↩ 拿回一份</button></div>${formal?'':`<p>当前共 ${w.copies*t.part} 颗</p>`}<p>原整体是多少？</p>${percentChoices(t)}</div>`;
 }
 if(t.kind==='change'){
  const reverse=t.changeOrder==='removeFirst',adding=reverse?w.phase===2:w.phase===1,n=adding?w.added:w.removed,target=adding?t.add:t.remove;
  return `<div class="board percent-board"><h3>原量 ${t.start} · 第${w.phase}次变化</h3>${percentChangeVisual(t,w)}<div class="percent-change"><span>已添 ${w.added}</span><span>已拿走 ${w.removed}</span>${formal?'':`<b>现在 ${w.activeIds.length}</b>`}</div><div class="work-buttons"><button data-action="${adding?'percentAdd':'percentRemove'}" ${n>=target?'disabled':''}>${adding?'＋ 添1颗':'－ 拿走1颗'}</button><button data-action="percentUndo" ${n?'':'disabled'}>↩ 撤销上一步</button>${w.phase===1?`<button data-action="percentPhase" ${n===target?'':'disabled'}>以当前盘为基准，开始第二步</button>`:''}<button data-action="percentReset" ${w.moves?'':'disabled'}>从头重摆</button></div><p>两次变化后的量：</p>${percentChoices(t)}</div>`;
 }
 if(t.kind==='estimate'){
  return `<div class="board percent-board"><h3>${t.bounds?w.boundStage==='lower'?'先构造整十下界':w.boundStage==='upper'?'再构造整十上界':'比较两个边界':'调到邻近整十'}</h3><div class="percent-factors">${[['a','第一个因数'],['b','第二个因数']].map(([side,label])=>`<div><b>${label} ${w[side]}</b><button data-action="percentAdjust" data-side="${side}" data-delta="-1">－1</button><button data-action="percentAdjust" data-side="${side}" data-delta="1">＋1</button></div>`).join('')}</div>${w.a%10===0&&w.b%10===0&&w.a*w.b/100<=24?percentBoundArea(w,'当前模型'):'<p>调到整十后，每块表示100。</p>'}${t.bounds?`<button data-action="percentBoundRecord" ${w.boundStage==='complete'?'disabled':''}>保存当前边界</button>${Object.entries(w.boundRecords).map(([kind,r])=>percentBoundArea(r,kind==='lower'?'保存的下界':'保存的上界')).join('')}<button data-action="percentReset">重新构造边界</button>`:''}<p>选择积的${t.bounds?'区间':'估算量级'}：</p>${percentChoices(t)}</div>`;
 }
 return '';
}
function percentGrade(t){
 const w=percentState(t);let ok=false;
 if(t.kind==='shade')ok=new Set(w.selected).size===t.target&&w.selected.length===t.target&&w.selected.every(i=>i>=0&&i<t.total&&(!t.wholeIndices||t.wholeIndices.includes(i)))&&(!t.requireWholeSelection||w.reference==='frame')&&w.choice===t.correctChoice;
 if(t.kind==='whole')ok=w.copies===t.copies&&w.choice===t.correctChoice&&(!t.knownShares||!w.pool.length&&w.bins.every(ids=>ids.length===t.part)&&w.bins.flat().length===t.knownCount&&new Set(w.bins.flat()).size===t.knownCount&&w.copiedGroups.length===t.copies-t.knownShares&&w.copiedGroups.every(ids=>ids.length===t.part));
 if(t.kind==='change')ok=w.phase===2&&w.added===t.add&&w.removed===t.remove&&w.activeIds.length===t.start+t.add-t.remove&&new Set([...w.activeIds,...w.removedIds]).size===t.start+t.add&&w.choice===t.correctChoice;
 if(t.kind==='estimate')ok=w.choice===t.correctChoice&&(t.bounds?['lower','upper'].every(k=>w.boundRecords[k]?.a===t.bounds[k][0]&&w.boundRecords[k]?.b===t.bounds[k][1]):w.a===t.targetA&&w.b===t.targetB);
 return {ok,incomplete:!w.moves||!w.choice||t.kind==='change'&&w.phase===1,reason:'核对整体、每步基准和原对象。'};
}
function percentAct(action,data,t){
 const w=percentState(t),reverse=t.changeOrder==='removeFirst';let changed=false;
 if(action==='percentReference'&&t.requireWholeSelection&&['frame','table'].includes(data.value)){w.reference=data.value;changed=true}
 if(action==='percentCell'&&t.kind==='shade'){const i=Number(data.index);if(Number.isInteger(i)&&i>=0&&i<t.total){const at=w.selected.indexOf(i);at>=0?w.selected.splice(at,1):w.selected.push(i);changed=true}}
 if(action==='percentSplit'&&t.knownShares&&!w.copiedGroups.length){const i=Number(data.index);if(Number.isInteger(i)&&w.bins[i]&&w.pool.length){w.bins[i].push(w.pool.shift());changed=true}}
 if(action==='percentUnsplit'&&t.knownShares&&!w.copiedGroups.length){const i=Number(data.index);if(Number.isInteger(i)&&w.bins[i]?.length){w.pool.push(w.bins[i].pop());changed=true}}
 if(action==='percentCopy'&&t.kind==='whole'&&w.copies<8&&(!t.knownShares||!w.pool.length&&w.bins.every(ids=>ids.length===t.part))){if(t.knownShares)w.copiedGroups.push(Array.from({length:t.part},(_,i)=>`C${w.copies-t.knownShares+1}-${i+1}`));w.copies++;changed=true}
 if(action==='percentUncopy'&&t.kind==='whole'&&w.copies>(t.knownShares||0)){if(t.knownShares)w.copiedGroups.pop();w.copies--;changed=true}
 if(action==='percentAdd'&&t.kind==='change'&&w.phase===(reverse?2:1)&&w.added<t.add){w.activeIds.push('A'+(++w.added));changed=true}
 if(action==='percentRemove'&&t.kind==='change'&&w.phase===(reverse?1:2)&&w.removed<t.remove){const id=w.activeIds.pop();if(id){w.removedIds.push(id);w.removed++;changed=true}}
 if(action==='percentPhase'&&t.kind==='change'&&w.phase===1&&(reverse?w.removed===t.remove:w.added===t.add)){w.phase=2;changed=true}
 if(action==='percentUndo'&&t.kind==='change'){const adding=reverse?w.phase===2:w.phase===1;if(adding&&w.added){const at=w.activeIds.indexOf('A'+w.added);if(at>=0){w.activeIds.splice(at,1);w.added--;changed=true}}else if(!adding&&w.removed){w.activeIds.push(w.removedIds.pop());w.removed--;changed=true}}
 if(action==='percentReset'&&['change','estimate'].includes(t.kind)&&w.moves){draft.work=null;percentState(t);return true}
 if(action==='percentAdjust'&&t.kind==='estimate'&&['a','b'].includes(data.side)&&[-1,1].includes(Number(data.delta))){const n=w[data.side]+Number(data.delta);if(n>=1&&n<=150){w[data.side]=n;changed=true}}
 if(action==='percentBoundRecord'&&t.bounds&&w.boundStage!=='complete'&&w.a%10===0&&w.b%10===0){const lower=w.boundStage==='lower';if(lower?w.a<t.a&&w.b<t.b:w.a>t.a&&w.b>t.b){w.boundRecords[w.boundStage]={a:w.a,b:w.b};w.boundStage=lower?'upper':'complete';if(lower){w.a=t.a;w.b=t.b}changed=true}}
 if(action==='percentChoice'&&t.choices.includes(data.value)){w.choice=data.value;changed=true}
 if(changed)w.moves++;return changed;
}
function percentSpeech(t){
 const w=percentState(t),formal=assessmentFormal(t);
 if(t.kind==='shade')return `涂了${w.selected.length}份。${t.requireWholeSelection?w.reference==='frame'?'选框内为整体。':w.reference==='table'?'选全桌为整体。':'尚未选择整体。':`同一整体有${t.total}份。`}`;
 if(t.kind==='whole')return `摆了${w.copies}个单位份。${t.knownShares?`还有${w.pool.length}个原点待分。`:''}${formal?'':`当前共${w.copies*t.part}颗。`}`;
 if(t.kind==='change')return `第${w.phase}次变化，已添${w.added}、已拿走${w.removed}。${formal?'':`现在${w.activeIds.length}。`}`;
 return `两个因数${w.a}与${w.b}。${t.bounds?`已保存${Object.keys(w.boundRecords).length}个边界。`:''}`;
}
function percentPage(){const task=PERCENT_TASKS[microSkillId],skill=SKILL_DATA.skills.find(s=>s.id===microSkillId);if(!task||!skill)return `<div class="panel">操作任务不存在。<button data-action="skillMap">回目录</button></div>`;return `<div class="page-head"><div><p class="kicker">${esc(task.skillId)}</p><h1>${esc(skill.title)}</h1></div><button class="back" data-action="micro" data-code="${esc(task.skillId)}">← 返回</button></div><div class="work"><article class="panel"><span class="phase">练 · 操作一题</span><h2 class="task-title">${esc(task.prompt)}</h2><div class="workshop-check-top"><button class="primary" data-action="${feedback?.ok?'next':'check'}">${feedback?.ok?'完成本题 →':'检查操作与理由 ✓'}</button></div>${percentBoard(task)}${reasonBlock(task)}${actionRow(task)}</article><aside class="side-stack">${stageLinks(task.skillId)}</aside></div>`}
