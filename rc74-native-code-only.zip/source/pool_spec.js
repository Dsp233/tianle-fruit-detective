'use strict';
// Restricted deterministic model generation; these are reserve/review instances,
// not claimed as substantive transfer merely because quantities changed.
const gcd=(a,b)=>b?gcd(b,a%b):a;
const fractionText=(a,b)=>{const g=gcd(a,b);return `${a/g}/${b/g}`};
const commonChoices=(correct,other)=>[String(correct),...other.map(String).filter(x=>x!==String(correct))].slice(0,3);
function modelAR(t,k){
 const p={mode:t.mode,kind:t.kind};
 if(t.mode==='fractionLab'){
  if(['shade','decimal','line'].includes(t.kind)){
   const denom=t.kind==='decimal'?10:[2,3,4,5,6,7,8,9,10,11,12][k%11],target=t.skillId==='A03.02'?1:k%(denom-1)+1;
   Object.assign(p,{denom,target});if(t.kind==='decimal'){p.target=1+k%10;p.correctChoice=String(p.target/10);p.choices=commonChoices(p.correctChoice,[p.target/100,p.target||1])}
   p.prompt=t.kind==='line'?`在0到1的等距数轴上，标出${fractionText(target,denom)}。`:t.kind==='decimal'?`在十格纸带表示${p.target}/10，再选它的小数。`:`同一条纸带平均分${denom}份，表示${target}/${denom}。`;
  }
  if(['compare','equal'].includes(t.kind)){
   if(t.kind==='equal'){const d=[3,4,5,6,7,8][k%6],n=1+k%(d-1);Object.assign(p,{denomLeft:d,targetLeft:n,denomRight:2*d,targetRight:2*n,correctChoice:'equal'});p.prompt=`两条纸带一样长。左条表示${n}/${d}，右条表示${2*n}/${2*d}，比较涂色长度。`}
   else{const a=3+k%5,b=4+(k*3)%7,x=1+k%(a-1),y=1+(k*2)%(b-1);Object.assign(p,{denomLeft:a,targetLeft:x,denomRight:b,targetRight:y,correctChoice:x/a===y/b?'equal':x/a>y/b?'left':'right'});p.prompt=`两条一样长的纸带，左条表示${x}/${a}，右条表示${y}/${b}。涂出份量并比较。`}
  }
  if(t.kind==='remainder'){const total=[8,12,16,18,20,24][k%6],first=total%3===0?total/3:total/4,second=(total-first)/2;Object.assign(p,{total,first,second,correctChoice:fractionText(second,total)});p.choices=commonChoices(p.correctChoice,['1/2','1/4','3/4','1/3']);p.prompt=`原整体有${total}块，先取走${first}块，再取剩下的一半。第二次拿走多少，占原整体多少？`}
 }
 if(t.mode==='percentLab'||t.mode==='scaleLab'&&t.kind==='change'){
  if(t.kind==='shade'){const total=[12,16,20,24,28,32,36,40][k%8],parts=[1,2,3][k%3],target=total*parts/4;Object.assign(p,{total,target});p.correctChoice=t.skillId==='A04.03'?String(target):t.skillId==='A04.02'?fractionText(target,total):`${parts*25}%`;p.choices=commonChoices(p.correctChoice,t.skillId==='A04.03'?[total,parts*25]:t.skillId==='A04.02'?['1/5','3/5','1/4','3/4']:['5%','100%','50%','75%']);p.prompt=t.skillId==='A04.03'?`整体${total}格，表示${parts*25}%并选出格数。`:`整体${total}格，涂${target}格，再选出${t.skillId==='A04.02'?'对应分数':'所占百分数'}。`}
  if(t.kind==='whole'){const part=2+k%9,copies=2+k%6;Object.assign(p,{part,copies,correctChoice:String(part*copies)});p.choices=commonChoices(p.correctChoice,[part,part+copies]);p.prompt=`原整体的1/${copies}是${part}颗。用完整份量重建整体，再选原总数。`}
  if(t.kind==='change'){const [start,add,remove]=[[50,10,12],[100,20,24],[150,30,36],[200,40,48],[100,10,11],[200,20,22],[300,30,33],[40,20,30],[80,40,60],[120,60,90],[160,80,120],[100,30,39],[200,60,78],[100,40,56],[200,80,112]][k%15];Object.assign(p,{start,add,remove,correctChoice:String(start+add-remove)});p.choices=commonChoices(p.correctChoice,[start,start-remove]);p.prompt=`从${start}开始，先增加${100*add/start}%，再按新整体减少${100*remove/(start+add)}%。动手表示，选最终量。`}
  if(t.kind==='estimate'){const targetA=10*(2+k%5),targetB=10*(2+(k*3)%5),a=targetA+(k%2?1:-1),b=targetB+(k%2?-2:2);Object.assign(p,{a,b,targetA,targetB,correctChoice:`约${targetA*targetB}`});p.choices=commonChoices(p.correctChoice,[`约${targetA*targetB/10}`,`约${targetA*targetB*10}`]);p.prompt=`估算${a}×${b}，把两个因数调整到邻近整十，再选合理的量级。`}
 }
 if(t.mode==='integerLab'){
  p.context='数轴与方格';
  if(t.kind==='position'){p.start=1+Math.floor(k/6)%5;p.target=-1-k%6;p.prompt=`以零为参照，把标记从${p.start}移到${p.target}。`}
  if(t.kind==='compare'){p.left=-6+k%13;p.right=-6+(k*3+2)%13;if(p.left===p.right)p.right=p.right===6?5:p.right+1;p.target=Math.max(p.left,p.right);p.prompt=`把甲${p.left}、乙${p.right}放到数轴上，比较哪个较大。`}
  if(t.kind==='walk'){p.start=-1-k%6;p.target=1+Math.floor(k/6)%6;p.prompt=`从${p.start}沿数轴逐格走到${p.target}，记录经过的刻度。`}
  if(['square','root'].includes(t.kind)){p.side=2+k%4;p.unitSize=2+Math.floor(k/4)%2;p.target=(p.side*p.unitSize)**2;p.prompt=t.kind==='square'?`每块方砖边长${p.unitSize}米。摆成每边${p.side}块的正方形，再输入面积。`:`每块方砖边长${p.unitSize}米。铺成面积${p.target}平方米的正方形，再输入边长。`}
  if(t.kind==='power'){p.base=2+k%3;p.exponent=1+Math.floor(k/3)%4;if(p.base**p.exponent>100)p.exponent=2;p.target=p.base**p.exponent;p.context='逐轮复制';p.prompt=`从1个开始，每一轮变成${p.base}倍，操作${p.exponent}轮。`}
 }
 if(t.mode==='ratioLab'){
  const red=1+k%4,blue=2+(k*2)%5,copies=2+Math.floor(k/4)%3;
  Object.assign(p,{red,blue});
  if(t.kind==='unit'){p.unit=blue;p.groups=2+k%4;p.red=p.unit*p.groups;p.prompt=`蓝点${blue}个作为一份。红点${p.red}个，圈出红点有几份。`}
  if(t.kind==='order'){p.order=k%2?'blueFirst':'redFirst';p.prompt=`红${red}、蓝${blue}。摆出两种量，选择“${p.order==='blueFirst'?'蓝:红':'红:蓝'}”。`}
  if(t.kind==='whole')p.prompt=`红${red}、蓝${blue}，摆出全部，选择红占整体的份量。`;
  if(t.kind==='scale'){p.copies=copies;p.prompt=`从红${red}蓝${blue}的一组出发，保持关系扩大${copies}倍。`}
  if(t.kind==='partition'){p.unitRed=red;p.unitBlue=blue;p.copies=copies;p.red=red*copies;p.blue=blue*copies;p.prompt=`红${p.red}、蓝${p.blue}分成${copies}个相同组合，分别摆出每组合的两种数量。`}
 }
 if(t.mode==='rateLab'){
  const units=2+k%4,per=2+(k*2)%5;
  Object.assign(p,{amountUnit:t.amountUnit||'元',unit:t.unit||'个'});
  if(['divide','compose'].includes(t.kind)){Object.assign(p,{units,per,total:units*per});p.prompt=t.kind==='divide'?`${p.total}${p.amountUnit}平均对应${units}${p.unit}，逐件摆出每1${p.unit}的量。`:`每1${p.unit}对应${per}${p.amountUnit}，摆出${units}${p.unit}的总量。`}
  if(t.kind==='compare'){p.a={units,per,total:units*per};p.b={units:2+(k*3)%4,per:per+(k%2?1:-1)};p.b.total=p.b.units*p.b.per;p.prompt=`甲${p.a.total}${p.amountUnit}/${p.a.units}${p.unit}，乙${p.b.total}${p.amountUnit}/${p.b.units}${p.unit}。统一到每1个，选较小的单位率。`}
  if(t.kind==='convert'){p.count=1+k%6;p.factor=k%2?60:100;p.from=p.factor===60?'小时':'米';p.to=p.factor===60?'分钟':'厘米';p.direction=Math.floor(k/2)%2?'reverse':'forward';p.prompt=p.direction==='forward'?`用单位卡把${p.count}${p.from}换成${p.to}。`:`用单位卡把${p.count*p.factor}${p.to}换回${p.from}。`}
 }
 if(t.mode==='journeyLab'){
  const per=1+k%5,count=2+Math.floor(k/5)%4;p.interval=t.interval||'小时';p.unit=t.unit||'千米';
  if(['equal','inverse'].includes(t.kind)){Object.assign(p,{per,count});p.prompt=t.kind==='equal'?`每${p.interval}完成${per}${p.unit}，在时间线上表示${count}个等长时段的总量。`:`每${p.interval}完成${per}${p.unit}，在时间线上表示完成${per*count}${p.unit}需要的时段。`}
  if(['segment','remaining'].includes(t.kind)){p.segments=[1+k%5,2+(k*3)%5,1+Math.floor(k/5)%4];if(t.kind==='remaining'){p.whole=p.segments.reduce((a,b)=>a+b,0)+2+k%5;p.choices=commonChoices(p.whole-p.segments.reduce((a,b)=>a+b,0),[p.whole,p.segments[0]])}p.prompt=`逐段表示${p.segments.join('、')}${p.unit}${t.kind==='remaining'?`，全程${p.whole}${p.unit}，选剩余量`:'，记录累计量'}。`}
  if(t.kind==='joint'){p.a=1+k%4;p.b=2+(k*2)%4;p.count=count;p.prompt=`甲每${p.interval}做${p.a}${p.unit}，乙做${p.b}${p.unit}。两人同时做${count}个时段，表示各自与合计产出。`}
 }
 if(t.mode==='scaleLab'&&t.kind!=='change'){
  p.factor=2+Math.floor(k/6)%2;
  if(t.kind==='pair'){p.red=1+k%4;p.blue=1+(k*2)%5;p.prompt=`红${p.red}蓝${p.blue}同时扩大${p.factor}倍，保持对应关系。`}
  if(t.kind==='length'){p.short=1+k%4;p.long=p.short+1+k%3;p.prompt=`长方形两种边长为${p.short}、${p.long}，同时扩大${p.factor}倍。`}
  if(t.kind==='area'){p.factor=2;p.rows=1+k%3;p.cols=1+Math.floor(k/3)%3;p.prompt=`${p.rows}×${p.cols}的方格板，长和宽都扩大${p.factor}倍。动手铺新板。`}
  if(t.kind==='map'){delete p.factor;p.per=2+k%6;p.count=1+Math.floor(k/6)%5;p.from='1厘米图上长度';p.to='千米';p.prompt=`每1厘米地图线对应${p.per}千米。用${p.count}张单位卡表示总实路。`}
 }
 if(!p.prompt)throw Error('No AR model: '+t.skillId);
 p.explain=modelExplanation(p);
 return p;
}
function modelExplanation(p){
 if(p.mode==='fractionLab'){
  if(p.kind==='shade')return `${p.target}个等份各是1/${p.denom}，合成${fractionText(p.target,p.denom)}。`;
  if(p.kind==='decimal')return `${p.target}个十分之一是${p.correctChoice}；十分位与百分位不同。`;
  if(p.kind==='line')return `从0经过${p.target}段，占${p.denom}个等段中的${p.target}段，即${fractionText(p.target,p.denom)}。`;
  if(p.kind==='equal')return `分子分母同时加倍，${p.targetLeft}/${p.denomLeft}与${p.targetRight}/${p.denomRight}是同长整体的同一份量。`;
  if(p.kind==='compare')return `比较的是同长整体的${p.targetLeft}/${p.denomLeft}和${p.targetRight}/${p.denomRight}，需要同时考虑等份大小与份数。`;
  return `先剩${p.total-p.first}块，再取其中一半${p.second}块；第二次占原${p.total}块的${p.correctChoice}。`;
 }
 if(p.mode==='percentLab'||p.kind==='change'){
  if(p.kind==='shade')return `${p.target}除以整体${p.total}，对应${p.target/p.total*100}%，而不是把格数直接当百分数。`;
  if(p.kind==='whole')return `每份${p.part}，整体有${p.copies}份，所以整体${p.part*p.copies}。`;
  if(p.kind==='change')return `先添${p.add}，新的整体为${p.start+p.add}；再从这个新基准拿走${p.remove}，最后${p.start+p.add-p.remove}。`;
  return `两个邻近整十是${p.targetA}与${p.targetB}，估算积约${p.targetA*p.targetB}，只说明量级。`;
 }
 if(p.mode==='integerLab'){
  if(p.kind==='position')return `${p.target}在0左边，负号表示与正方向相反的位置。`;
  if(p.kind==='walk')return `从${p.start}经过0到${p.target}，移动${p.target-p.start}个单位距离。`;
  if(p.kind==='compare')return `${p.target}在另一个数右边，所以较大。`;
  if(p.kind==='square')return `每边${p.side}块，每块边长${p.unitSize}，整边${p.side*p.unitSize}米，面积是两边长度相乘，${p.target}平方米。`;
  if(p.kind==='root')return `每边${p.side}块形成${p.target}平方米，整边是${p.side*p.unitSize}米；长度取正值。`;
  return `${p.exponent}轮，每轮乘${p.base}，是重复乘法，共${p.target}。`;
 }
 if(p.mode==='ratioLab')return p.kind==='unit'?`一份${p.unit}，红${p.red}是${p.groups}份。`:p.kind==='whole'?`整体包括红蓝两类，共${p.red+p.blue}，红占${fractionText(p.red,p.red+p.blue)}。`:p.kind==='order'?`比的前后项必须与题目要求的对象顺序一致。`:p.kind==='scale'?`两种量都复制${p.copies}次，份数关系保持不变。`:`每袋红${p.unitRed}蓝${p.unitBlue}，${p.copies}袋用完两种原对象。`;
 if(p.mode==='rateLab')return p.kind==='compare'?`甲单位率${p.a.per}、乙${p.b.per}，统一到每1个后才可以比较。`:p.kind==='convert'?`每${p.from}对应${p.factor}${p.to}，换算前后长度或时长不变。`:`${p.units}份各${p.per}${p.amountUnit}，总量${p.total}${p.amountUnit}；每1份是单位率。`;
 if(p.mode==='journeyLab')return p.kind==='joint'?`两人使用同一时段，每段合做${p.a+p.b}，${p.count}段合做${(p.a+p.b)*p.count}。`:p.kind==='remaining'?`已做${p.segments.reduce((a,b)=>a+b,0)}，从全程${p.whole}中扣去，剩${p.whole-p.segments.reduce((a,b)=>a+b,0)}。`:p.kind==='segment'?`不重叠的各段合并，累计${p.segments.reduce((a,b)=>a+b,0)}。`:`每段${p.per}，${p.count}段对应${p.per*p.count}。`;
 if(p.mode==='scaleLab')return p.kind==='area'?`两种边长都变${p.factor}倍，格数变为${p.factor*p.factor}倍；不能只乘一次。`:p.kind==='map'?`每张单位卡对应${p.per}${p.to}，${p.count}张合成${p.count*p.per}${p.to}。`:`对应的两种量同时乘${p.factor}，关系保持不变。`;
 return '核对题目条件和原对象之间的对应关系。';
}
module.exports={modelAR,modelExplanation};
