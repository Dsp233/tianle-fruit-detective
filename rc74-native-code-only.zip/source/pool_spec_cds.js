'use strict';
const cards=(n,prefix)=>Array.from({length:n},(_,i)=>({id:prefix+(i+1),label:prefix+(i+1)}));
const people=(counts)=>['R','O','Y','N'].flatMap((group,g)=>Array.from({length:counts[g]},(_,i)=>({id:`P${counts.slice(0,g).reduce((a,b)=>a+b,0)+i+1}`,name:`学员${counts.slice(0,g).reduce((a,b)=>a+b,0)+i+1}`,group})));
function spinner(a,b,c=0){const sectors=[{color:'红',size:a},{color:'蓝',size:b},...(c?[{color:'绿',size:c}]:[])];return {type:'spinner',name:'均匀转盘的等角原片',sectors,atoms:sectors.flatMap((s,i)=>Array.from({length:s.size},(_,j)=>({id:`S${i+1}-${j+1}`,label:s.color+'原片'+(j+1),color:s.color,sector:i})))}}
function die(n){return {type:'die',name:'混匀等可能编号卡',atoms:Array.from({length:n},(_,i)=>({id:'F'+(i+1),label:String(i+1),color:String(i+1)}))}}
function bag(a,b){return {type:'bag',name:'混匀每个原球身份等可能',atoms:Array.from({length:a+b},(_,i)=>({id:'B'+(i+1),label:(i<a?'红':'蓝')+'球'+(i+1),color:i<a?'红':'蓝'}))}}
function modelCDS(t,k){
 const p={mode:t.mode,kind:t.kind};
 if(t.mode==='setsLab'){
  const counts=[1+k%3,Math.floor(k/3)%4,1+Math.floor(k/12)%3,Math.floor(k/36)%3];p.people=people(counts);p.labels=['航模','棋类'];
  if(t.kind==='identity'&&p.people.length>1)p.people[0].name=p.people[1].name='同名学员';
  if(t.kind==='members')p.queries=k%2?['A','R','O']:['B','Y','O'];
  if(t.kind==='partition'){p.countKeys=['R','O','Y','N'];p.target='I'}
  if(['formula','dedup','twoWays'].includes(t.kind))p.target='I';
  if(t.kind==='universe')p.queries=['U'];
  if(t.kind==='complement'){p.target=k%2?'notA':'notB';p.queries=[p.target]}
  if(t.kind==='intersection')p.queries=['I','O','exact1'];
  const goal={identity:'按不同编号统计全名册',members:'分别点出所问的整组、只参加一项、两项都参加',partition:'填写四个互斥分区与至少参加一项的人数',formula:'用两种不同的实际组式计算至少一项',dedup:'叠加两个名册后逐个去掉重复副本',universe:'圈全明确全集，再填人数',complement:'在同一全集内圈所问补集，实际拼组式求人数',intersection:'分别圈至少一项、同时两项、恰好一项',twoWays:'用直接覆盖及全集排除两个不同结构求同一组人数'}[t.kind];
  p.prompt=`全部学员按原编号登记归位。${goal}；两项都不参加的学员也在全名册内。`;p.explain=`同一编号始终是同一人；整组含重叠，互斥分区各只计一次；补集必须先定全集。人数和颜色标签数不同。`;
 }
 if(t.mode==='combinLab'){
  if(['group','pair','complete','dedup','rule'].includes(t.kind)){
   const first=cards(2+k%3,'甲'),second=cards(1+Math.floor(k/3)%3,'乙');const m={type:'pair',name:'从两盘各取一张的编号组合',first,second};
   if(k%3!==0)m.forbidden=[[first[k%first.length].id,second[Math.floor(k/3)%second.length].id]];
   const all=first.flatMap(a=>second.map(b=>[a.id,b.id])).filter(tuple=>!(m.forbidden||[]).some(f=>f.every((id,i)=>tuple[i]===id)));
   if(t.kind==='complete')m.seed=all.filter((_,i)=>i%2===0);
   if(t.kind==='dedup'){m.seed=[...all,...all.slice(0,1+k%2)];delete m.forbidden}
   p.models=[m];p.prompt=`从甲盘和乙盘各取一张${m.forbidden?'，不允许'+m.forbidden.map(f=>f.join('＋')).join('、'):''}。${t.kind==='complete'?'补全缺失结果':t.kind==='dedup'?'修正实际重复，保留全部合法结果':t.kind==='rule'?'按第一张分类列全，判断相乘的条件是否满足':'按第一张有序分类，逐一列全合法组合'}，填结果数。`;
   p.explain=`按第一张分类，每类逐一核对第二张的全部合法选项；各类不重叠，不能因为有${first.length}与${second.length}张就忽略禁配条件。`;
  }else{
   const n=2+k%5,size=Math.min(n,2+Math.floor(k/5)%2),items=cards(n,'卡');
   if(t.kind==='orderMeaning')p.models=[{type:'order',name:'不同位置',items,size,ordered:true,repeat:Math.floor(k/10)%2===1},{type:'order',name:'不计位置的组',items,size,ordered:false,repeat:Math.floor(k/10)%2===1}];
   else{const m={type:'order',name:'编号位置表',items,size,ordered:t.kind!=='choose',repeat:['queue','system'].includes(t.kind)&&Math.floor(k/6)%2===1};if(t.kind==='limit')m.fixed={[Math.floor(k/3)%size]:items[k%n].id};p.models=[m]}
   p.prompt=`从${n}张原编号卡取${size}张。${t.kind==='orderMeaning'?'分别列全有位置与无位置两种结果，'+(p.models[0].repeat?'允许编号重复':'原卡不重复'):t.kind==='choose'?'组内换顺序不算新组':p.models[0].repeat?'允许同一编号重复出现在不同位置':'每张原卡最多用一次'}${t.kind==='limit'?'，固定位置条件：'+Object.entries(p.models[0].fixed).map(([i,id])=>`第${+i+1}位为${id}`).join('、'):''}。系统收录全部合法结果，再计数。`;
   p.explain=`先确定位置是否有意义、原卡能否重复和固定限制。无序组合将同一组的不同排列去重；有序位置不同才是不同结果。`;
  }
 }
 if(t.mode==='chartLab'){
  p.labels=['甲','乙','丙'].slice(0,2+k%2);p.unit='件';p.gap=1+k%4;p.ticks=Array.from({length:6},(_,i)=>i*p.gap);p.values=p.labels.map((_,i)=>((k+i*2)%5)*p.gap);
  if(t.kind==='legend'){p.legend=1+Math.floor(k/4)%4;p.icons=p.labels.map((_,i)=>(k+i)%4);p.values=p.icons.map(n=>n*p.legend);p.prompt=`图例一枚完整图标为${p.legend}件。拆成原单位点并归到各类，填实际数量与单位，保留零类。`;p.explain=`实际数量＝图标枚数×每枚代表量；同图标不是1件，零类也不能从数据中删掉。`}
  else if(t.kind==='interval'){const d=2+k%3,h=2*d;p.values=[];p.points=[[0,h],[d,0],[2*d,h]];p.threshold=1+Math.floor(k/3)%(h-1);p.relation=k%2?'below':'above';p.timeStep=.5;p.unit='分钟';p.valueUnit='厘米';p.prompt=`根据原折线圈水位${p.relation==='below'?'低于':'高于'}${p.threshold}厘米的小时间段，每段0.5分钟，累计时间。`;p.explain=`两点间是直线；应读条件对应的时间区间长度，不能把水位值相加当时间。相等端点不贡献正长度。`}
  else{if(t.kind==='convert')p.direction=k%2?'build':'read';p.prompt=t.kind==='ticks'?`等距量尺两端${p.ticks[0]}与${p.ticks.at(-1)}，实际把缺失刻度卡放到对应位置。`:`每格${p.gap}件，${t.kind==='build'||p.direction==='build'?'按原数据表建柱':'从原柱图读量并标柱顶'}，填各类实际数量与单位。`;p.explain=`刻度差是${p.gap}，单位与原类别逐一对应；每一格不是默认1，零柱仍是一个类别。`}
 }
 if(t.mode==='statsLab'){
  p.quantum=1;p.unit='本';
  if(['balance','mean'].includes(t.kind)){const m=2+k%5;p.values=k%2?[m-1,m+1]:[m-2,m,m+2];p.quantum=k%3===0?.5:1;p.prompt=`原记录${p.values.join('、')}本。用同一批单位教具点实际均分，填写总量、记录数和平均。`;p.explain=`原总量守恒，平均＝总量÷记录数；不是选中间看起来合适的一个原数。`}
  if(['sort','median','modeRange'].includes(t.kind)){const a=k%5;p.values=k%2?[a,a+3,a+1,a+1]:[a+4,a,a+2];if(t.kind==='modeRange'&&k%3===0)p.values=[a,a+2,a,a+2,a+4];p.prompt=`原记录${p.values.join('、')}本，${t.kind==='sort'?'按从小到大摆所有原编号卡':t.kind==='median'?'排序原卡，圈真正中间卡，求中位数':'按原值归组，找众数或明确无众数，再标两端求极差'}；重复数的记录是不同原卡。`;p.explain=t.kind==='median'?`先按数值排序，奇数条取中间；偶数条取中间两条的平均。原顺序中央不一定是中位数。`:t.kind==='modeRange'?`众数按最高频数判，可多于一个；本题所有值仅出现一次时约定无众数。极差＝最大值－最小值。`:`排序比较数值但保留每条原记录的身份；相同值仍要放入各自原卡。`}
  if(t.kind==='weighted'){const a=1+k%5;p.rows=[{value:a,frequency:k%2?1:2,label:'第一组'},{value:a+3,frequency:k%2?2:1,label:'第二组'}];p.prompt=`频数表${p.rows.map(r=>`${r.value}本有${r.frequency}人`).join('，')}。展开全部原记录，实际均分并填总人数与平均。`;p.explain=`总量为每行数值×频数再相加，分母是总人数，不是表格行数。`}
 }
 if(t.mode==='chanceLab'){
  if(['equal','weighted'].includes(t.kind)){const m=spinner(1+k%3,1+Math.floor(k/3)%3,t.kind==='weighted'?1+Math.floor(k/9)%2:0);m.event={type:'color',color:k%2?'红':'蓝'};m.eventLabel=m.event.color+'色';if(t.kind==='weighted')m.compare=['红','蓝'];p.models=[m];p.prompt=`均匀转盘用等角原片表示，逐片列全${t.kind==='equal'?'并判断原片与颜色是否等可能':'、圈指定色，求概率并比较红蓝'}。`;p.explain=`等角原片是等可能基本结果；合并为颜色后概率由该颜色占的原片数决定，颜色名字不同不意味着等可能。`}
  else if(t.kind==='two'){const a=1+k%3,b=1+Math.floor(k/3)%2,m=bag(a,b);m.second=bag(a,b);m.replacement=k%2===0;m.event=k%3===0?{type:'same'}:{type:'both',color:'红'};m.eventLabel=k%3===0?'两次同色':'两次都是红色';p.models=[m];p.prompt=`同一混匀袋两次取原球${m.replacement?'放回并重新混匀':'不放回'}，列全具体编号树，圈“${m.eventLabel}”，求概率。`;p.explain=`每条叶代表具体原身份；不放回时同一球不可重复，放回时可以。空间分母与事件有利叶要使用同一条件。`}
  else{const n=3+k%5,m=t.kind==='space'?bag(1+k%3,1+Math.floor(k/3)%3):die(n);m.event=t.kind==='space'?{type:'all'}:t.kind==='certainty'?k%3===0?{type:'all'}:k%3===1?{type:'color',color:String(n+1)}:{type:'even'}:{type:'atLeast',value:1+Math.floor(k/5)%n};m.eventLabel=m.event.type==='all'?'全部原身份':m.event.type==='even'?'编号为偶数':m.event.type==='color'?'编号为'+m.event.color:'编号至少'+m.event.value;p.models=[m];p.prompt=`一次抽取等可能原身份，列全空间${t.kind==='space'?'':`并圈“${m.eventLabel}”`}${t.kind==='certainty'?'，判一定/不可能/可能':t.kind==='favorable'?'，填概率':''}。`;p.explain=`先列齐每个具体身份；不可能事件无有利结果，一定事件包含全部，其他事件概率为有利身份数÷全空间身份数。`}
 }
 if(t.mode==='motionLab'){
  if(t.kind==='fold'){p.size=4;const order=k%2?['vertical','horizontal']:['horizontal','vertical'],from=Math.floor(k/2)%2?'high':'low';p.folds=order.map(axis=>({axis,value:1.5,from}));const x=from==='low'?2+k%2:k%2,y=from==='low'?2+Math.floor(k/2)%2:Math.floor(k/2)%2;p.cuts=[[x,y]];if(k%5===0)p.cuts.push([from==='low'?3:0,from==='low'?3:0]);p.cuts=[...new Map(p.cuts.map(p=>[p.join(','),p])).values()];p.prompt=`4×4原纸按${p.folds.map(f=>(f.axis==='vertical'?'左右':'上下')+'中线，从'+(from==='low'?'小坐标侧':'大坐标侧')+'折向另一侧').join('，再')}。在叠层格${p.cuts.map(p=>p.join(',')).join('、')}剪孔；先预测所有原孔，再操作及逐层展开。`;p.explain=`每个叠层格含多个原纸身份，剪孔穿透全部原层；完整展开后每个被剪原格才形成孔，折序与剪的位置都要保留。`}
  else{const a=1+k%2,b=1+Math.floor(k/2)%2;p.points=[{id:'A',x:0,y:0},{id:'B',x:a,y:0},{id:'C',x:0,y:b}];if(t.kind==='axis'){const n=1+k%3;const axis=['vertical','horizontal','diagonal','antidiagonal'][k%4];p.points=axis==='vertical'?[{id:'A',x:-n,y:0},{id:'B',x:n,y:0},{id:'C',x:0,y:2}]:axis==='horizontal'?[{id:'A',x:0,y:-n},{id:'B',x:2,y:0},{id:'C',x:0,y:n}]:axis==='diagonal'?[{id:'A',x:n,y:0},{id:'B',x:0,y:n},{id:'C',x:-1,y:-1}]:[{id:'A',x:n,y:0},{id:'B',x:0,y:-n},{id:'C',x:-1,y:1}];p.steps=[{type:'reflect',axis,value:0}];p.prompt=`从候选镜轴选择这个原图的一条对称轴，预测每个编号终位，再实际镜映。`}
   if(t.kind==='mirror'){const axis=k%2?'vertical':'horizontal',value=Math.floor(k/4)%3-1;p.steps=[{type:'reflect',axis,value}];p.prompt=`原图按${axis==='vertical'?'x':'y'}＝${value}镜映。先预测每个原编号终位，再沿正确轴变换。`}
   if(t.kind==='rotate'){p.steps=[{type:'rotate',cx:0,cy:0,angle:[90,180,270][Math.floor(k/4)%3],direction:k%2?'cw':'ccw'}];p.prompt=`绕(0,0)${k%2?'顺':'逆'}时针旋转${p.steps[0].angle}°，先预测每个编号终位，再实际旋转。`}
   if(t.kind==='translate'){const dx=k%2?1:-1,dy=Math.floor(k/4)%2?2:-1;p.steps=[{type:'translate',dx,dy}];p.prompt=`原图横向移动${dx}、纵向移动${dy}格，先预测原编号终位，再整图平移。`}
   p.explain=`每个原编号保持身份；镜映保持到轴的距离并反转朝向，旋转保持到中心的距离，平移给所有点相同位移。图形看起来相似不能代替逐点定位。`}
 }
 if(t.mode==='invariantLab'){
  if(t.kind==='filter'){p.items=['A','B','C'];const slot=k%3,a=p.items[Math.floor(k/3)%3],remaining=p.items.filter(v=>v!==a);p.conditions=[{id:'K1',type:'fixed',a,slot,label:`${a}在第${slot+1}位`},{id:'K2',type:'before',a:remaining[k%2],b:remaining[(k+1)%2],label:`${remaining[k%2]}在${remaining[(k+1)%2]}前`}];p.prompt=`列全三张原卡队列，逐项核对${p.conditions.map(c=>c.label).join('且')}，保留或排除并指出失效条件。`;p.explain=`满足一个条件还不够，全部条件要同时满足；按全部排列逐个分类，不能仅凭尝试一次找到一个结果就声称找全。`}
  else{const n=3+k%3,red=k%n;p.coins=Array.from({length:n},(_,i)=>({id:'C'+(i+1),color:i<red?'红':'蓝'}));p.rule=t.kind==='parity'?'flipPair':['flipPair','swapAdjacent'][Math.floor(k/3)%2];p.minOps=2+k%2;
   if(t.kind==='legal'){p.rule=['flipOne','flipPair','swapAdjacent'][k%3];p.minOps=0;p.attempts=[['C1'],['C1','C2'],['C1','C3']];p.prompt=`规则${p.rule==='flipOne'?'每次翻一张':p.rule==='flipPair'?'每次翻两张不同卡':'只能交换相邻两张'}，对指定操作先判断合法性，再实际执行，非法操作保持原状。`}
   else if(t.kind==='proof'){p.goal=p.coins.map(c=>c.color);p.goal[0]=p.goal[0]==='红'?'蓝':'红';p.prompt=`在${p.rule==='flipPair'?'每次翻两张不同卡':'只交换相邻两张'}的规则下，原状态${p.coins.map(c=>c.color).join('、')}，目标${p.goal.join('、')}。记录合法变化，用完整的不变量证据判能否到达。`}
   else p.prompt=`在${p.rule==='flipPair'?'每次翻两张不同卡':'只交换相邻两张'}下实际操作至少${p.minOps}次，${t.kind==='parity'?'对初始和当前红卡配对、保留单卡，核对奇偶':'记录原数量与红数，检查完整局部变化，再判断真正保持的量'}。`;
   p.explain=`每次变化必须合法；双卡翻转的红数变化只能为－2、0、2，所以奇偶保持，红数本身可变；相邻交换保持红数。一次失败不是不可达证明。`}
 }
 if(!p.prompt)throw Error('No CDS model '+t.skillId);return p;
}
module.exports={modelCDS};
