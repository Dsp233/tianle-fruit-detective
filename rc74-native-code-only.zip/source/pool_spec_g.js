'use strict';
const {solidAnalysis,solidFullAngles}=require('./solid_geometry');
const rectangle=(r,c)=>Array.from({length:r},(_,y)=>Array.from({length:c},(_,x)=>[y,x])).flat();
function canonical(cells){return Array.from({length:8},(_,i)=>{const p=cells.map(([x,y])=>{if(i&1)x=-x;if(i&2)y=-y;return i&4?[y,x]:[x,y]}),mx=Math.min(...p.map(p=>p[0])),my=Math.min(...p.map(p=>p[1]));return p.map(([x,y])=>[x-mx,y-my]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]).map(p=>p.join(',')).join(';')}).sort()[0]}
let nets=[[[0,0]]];for(let size=2;size<=6;size++){const expanded=new Map();for(const cells of nets)for(const [x,y] of cells)for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const n=[x+dx,y+dy];if(cells.some(p=>p[0]===n[0]&&p[1]===n[1]))continue;const key=canonical([...cells,n]);expanded.set(key,key.split(';').map(s=>s.split(',').map(Number)))}nets=[...expanded.values()]}
const validNets=nets.filter(n=>solidAnalysis(n,solidFullAngles(n)).valid),invalidNets=nets.filter(n=>!solidAnalysis(n,solidFullAngles(n)).valid);
if(nets.length!==35||validNets.length!==11)throw Error('Free hexomino/cube-net classification changed: '+nets.length+'/'+validNets.length);
function modelG(t,k){
 const p={mode:t.mode,kind:t.kind};
 if(t.mode==='measureLab'){
  p.unitSize=1+Math.floor(k/9)%3;p.unit=k%4===0?'m':'cm';
  if(t.kind==='length'){p.unit='cm';p.start=1+k%3;p.end=p.start+1+Math.floor(k/3)%4;p.max=p.end+1;p.prompt=`红线从${p.start*p.unitSize}到${p.end*p.unitSize}厘米。接上每段${p.unitSize}厘米的原单位段，并写下线段长度。`;p.explain=`长度是端点之差${(p.end-p.start)*p.unitSize}厘米，也等于${p.end-p.start}段乘每段${p.unitSize}厘米。`}
  else if(t.kind==='rearrange'){const width=3+k%3;p.unitSize=2+Math.floor(k/3)%2;p.unit='cm';p.rows=4;p.cols=4;p.total=2*width;p.reference=rectangle(2,width);p.goal='sameAreaDifferentPerimeter';p.prompt=`用参考图的同一批${p.total}块重排，保持连通无洞，面积相同而周长不同；每格边${p.unitSize}厘米。描新外边验证。`;p.explain=`同一批原方块保证面积不变；排列改变贴合边的数量，外围长度可以改变。只旋转参考矩形不会改变周长。`}
  else{p.rows=2+k%3;p.cols=2+Math.floor(k/3)%3;p.cells=rectangle(p.rows,p.cols);if(k%2)p.cells=p.cells.filter(([r,c])=>r!==p.rows-1||c!==p.cols-1);p.prompt=`图中每格边${p.unitSize}${p.unit==='m'?'米':'厘米'}。${t.kind==='perimeter'?'只描外围并写出周长':t.kind==='area'?'铺满目标内部并写出面积':'描外边、铺内部，分别写量并选对应单位'}，不要计目标外的空格。`;p.explain=`长度按单位边相加；面积按原方格数乘${p.unitSize}的平方。凹口属于外围，内部贴合边不属于周长。`}
 }
 if(t.mode==='angleLab'){
  if(t.kind==='arms'){p.target=30+15*(k%9);p.lengths=[90+k%3*5,105+k%4*5];p.mustResize=true;p.prompt=`把同顶点的两条射线张开到${p.target}°，选角边，再改变边长核对张角。`;p.explain=`角度由张开的幅度决定；同顶点的两条射线是角边，连接末端的线段不是角边，改变长度不改变张角。`}
  if(t.kind==='turn'){p.targets=[30*(1+k%12),30*(1+Math.floor(k/12)%12)];p.prompt=`实际把两个指针分别转过${p.targets.join('°、')}°，每一步30°。`;p.explain=`累计转过的量由整段转动相加得到，180°是半周，360°是一周；回到起点也可能转过了一整周。`}
  if(['triangle','conditions'].includes(t.kind)){const a=20+5*(k%8),b=30+5*(Math.floor(k/8)%8);p.angles=[a,b,180-a-b];p.unknown=k%3;if(t.kind==='conditions'){p.angles=[a,90,90-a];p.unknown=k%2?2:0}p.prompt=`根据三角形图上的已知角${t.kind==='conditions'?'及标记':''}，先填写未知角，再移动原角片验证。`;p.explain=`三个内角合成平角180°，未知角为180°减另外两个已知角。不能用图中边看起来长短作角度条件。`}
  if(t.kind==='polygon'){p.sides=4+k%4;p.anchor=Math.floor(k/4)%p.sides;p.rotation=15*(k%12);p.prompt=`从凸${p.sides}边形指定顶点${String.fromCharCode(65+p.anchor)}画有效对角线，数三角形并求内角和。`;p.explain=`从一个顶点分成${p.sides-2}个三角形，内角和${(p.sides-2)*180}°；相邻顶点连线是边而不是对角线。`}
 }
 if(t.mode==='compositeLab'){
  if(t.kind==='union'){p.rows=4;p.cols=5;const h=1+k%3,w=1+Math.floor(k/3)%3;p.fixed=rectangle(h,w);p.piece=k%2?[[0,0],[0,1]]:[[0,0],[1,0]];p.start=[0,0];p.prompt=`移动原小图块，与固定图拼成没有重叠的整图，记录面积。`;p.explain=`原单位格各只计一次；当前重叠部分不能当成两个格，移动到无重叠后总面积是两块原面积之和。`}
  if(t.kind==='move'){p.rows=4;p.cols=8;const h=1+k%3;p.fixed=rectangle(h,1+Math.floor(k/3)%3).map(([r,c])=>[r,c+2]);p.piece=[[0,0],[1,0]];p.start=[0,7];p.destination=[k%3,1];p.prompt=`把同一块材料移到标示位置，填写总面积并判断哪一种量必然保持。`;p.explain=`平移保留原单位格身份和数量；无重叠拼接时面积保持，外围暴露的边可能改变。`}
  if(t.kind==='cut'){p.rows=3+k%2;p.cols=3+Math.floor(k/2)%3;p.remove=[[p.rows-1,k%p.cols]];if(k%3===0)p.remove.push([p.rows-2,k%p.cols]);p.prompt=`从原长方形中实际取走标记格，写下保留区域面积。`;p.explain=`原面积${p.rows*p.cols}减去真正取走的${p.remove.length}格，剩${p.rows*p.cols-p.remove.length}；取走区域不能再计入保留面积。`}
  if(t.kind==='squares'){p.rows=2+k%4;p.cols=2+Math.floor(k/4)%4;p.sizes=k%2?[1,2]:[2];p.prompt=`在${p.rows}行${p.cols}列方格中逐一记录边长${p.sizes.join('或')}格的正方形，禁止重复记录。`;p.explain=`每种边长s的左上角有(行数－s＋1)×(列数－s＋1)种位置；不同边长分开计，再相加。`}
 }
 if(t.mode==='circleLab'){
  p.rotation=30*(k%12);
  if(t.kind==='center'){p.radius=2+k%4;p.points=Array.from({length:3+k%3},(_,i)=>i*360/(3+k%3));p.prompt=`先定位圆心，再从同一圆心连到各个圆周点，核对原半径。`;p.explain=`圆心到任意圆周点都是半径，彼此长度相同；圆周点之间的连线是弦。`}
  if(t.kind==='radii'){p.radius=1+k%6;p.answerTarget=k%2?'diameter':'radius';p.given=p.answerTarget==='radius'?'diameter':'radius';p.prompt=`已知${p.given==='radius'?'半径'+p.radius:'直径'+2*p.radius}厘米，连接反向半径，填写${p.answerTarget==='radius'?'半径':'直径'}。`;p.explain=`通过圆心的直径由两条相反方向半径组成，d＝2r；反过来r＝d÷2。`}
  if(t.kind==='walk'){p.radius=1+k%4;p.parts=k%2?4:8;p.targetSteps=1+Math.floor(k/4)%p.parts;p.prompt=`圆周均分${p.parts}段，半径${p.radius}厘米。实际走${p.targetSteps}段，用π表示路程。`;p.explain=`路程是整圈2πr的${p.targetSteps}/${p.parts}，${2*p.radius*p.targetSteps/p.parts}π厘米；圆内直线不能当圆弧。`}
  if(t.kind==='area'){const r=1+k%3;p.radii=k%2?[r,2*r]:[r];p.compare=k%2===1;p.parts=8+8*(Math.floor(k/3)%2);p.prompt=`把半径${p.radii.join('、')}厘米的圆的原扇片交错搬排，用π表示面积${p.compare?'并比较面积倍数':''}。`;p.explain=`扇片保留原面积；有限片条带仍有弯边，精确公式A＝πr²${p.compare?'，半径2倍时面积4倍':''}。`}
  if(t.kind==='arc'){p.parts=k%2?4:8;p.count=1+Math.floor(k/2)%(p.parts-1);p.start=k%p.parts;p.totalCirc=p.parts*(2+Math.floor(k/6)%4);p.prompt=`整圈长度${p.totalCirc}厘米，均分${p.parts}段，标出连续${p.count}段，填整圈比例与弧长。`;p.explain=`弧长为整圈长度乘${p.count}/${p.parts}，即${p.totalCirc*p.count/p.parts}厘米；跨过起点也不能少计一段。`}
  if(t.kind==='objects'){p.radius=k%2?2:4;p.parts=4+4*(Math.floor(k/2)%2);p.count=1+Math.floor(k/4)%(p.parts-1);p.start=k%p.parts;p.prompt=`半径${p.radius}厘米的圆均分${p.parts}段，分别选择${p.count}段弧和${p.count}份扇面，写长度与面积。`;p.explain=`弧取2πr的${p.count}/${p.parts}，扇面取πr²的${p.count}/${p.parts}；两种对象和单位不同。`}
 }
 if(t.mode==='similarLab'){
  if(t.kind==='correspond'){p.points=[[0,0],[2+k%3,0],[0,2+Math.floor(k/3)%3]];p.factor=[1.5,2,3][k%3];p.rotation=90*(k%4);p.targetLabels=['P','R','Q'];p.edgeIndex=k%3;p.angleIndex=Math.floor(k/3)%3;p.prompt=`把旋转后图形与原图的对应点、指定边和角匹配。`;p.explain=`对应关系随原点身份保留，不能仅按左右位置或字母顺序；对应边成相同比例、对应角相同。`}
  else{p.width=2+2*(k%2);p.height=2+2*(Math.floor(k/2)%2);const factor=[.5,1.5,2,2.5,3][k%5];if(t.kind==='inverse'){p.newWidth=p.width*factor;p.prompt=`原对应边长${p.width}厘米，新边${p.newWidth}厘米，实际调整整体倍数并填写比例。`;p.explain=`新旧对应边之比为${factor}；两方向采用同一倍数，倒过来不能用原÷新作为放大倍数。`}
  else{p.goalX=factor;p.goalY=t.kind==='resize'&&k%3===0?[.5,1.5,2,2.5,3][(k+1)%5]:factor;p.prompt=`把${p.width}×${p.height}的原图横向变${p.goalX}倍、纵向变${p.goalY}倍，${t.kind==='resize'?'判断是否保持相似':t.kind==='perimeter'?'描两图外边并写周长倍数':'铺两图原单位格并写面积倍数'}。`;p.explain=t.kind==='resize'?`只有各方向使用同一倍数才保持相似，单独拉伸会改变形状。`:t.kind==='perimeter'?`各边等比例变化，外围总长也变${factor}倍。`:`面积变横向${factor}倍乘纵向${factor}倍，即${factor**2}倍。`}}
 }
 if(t.mode==='rightLab'){
  if(t.kind==='condition'){const a=2+k%4,b=2+Math.floor(k/4)%4;p.cards=[{points:[[0,0],[a,0],[0,b]],corner:0,givenAngle:90,rotation:45*(k%8)},{points:[[0,0],[a,0],[b*.5,b*Math.sqrt(3)/2]],corner:0,givenAngle:60,rotation:30*(k%12)}];p.prompt=`逐图读取角标记，选指定顶点和相邻边，判断能否使用直角三角形平方关系。`;p.explain=`a²＋b²＝c²要求两条边夹角确为90°；画得像直角不能代替题目条件。`}
  if(['squares','solve'].includes(t.kind)){const u=[.5,1,1.5,2][k%4];p.unit=u;p.a=(k%2?3:4)*u;p.b=(k%2?4:3)*u;p.c=5*u;p.rotation=45*(k%8);if(t.kind==='solve')p.unknown=['a','b','c'][Math.floor(k/4)%3];p.prompt=t.kind==='squares'?`用每格边${u}的原平方材料验证两直角边${p.a}、${p.b}与斜边的平方面积关系，填写三个面积。`:`已知直角三角形另外两边，保留原方块，${p.unknown==='c'?'合并两直角边平方':'从斜边平方扣掉已知直角边平方'}，求${p.unknown}。`;p.explain=`直角边平方相加等于斜边平方，${p.a**2}＋${p.b**2}＝${p.c**2}；平方单位格的边长与面积单位不同。`}
  if(t.kind==='axis'){const x=1+k%3,y=1+Math.floor(k/3)%3,n=1+Math.floor(k/9)%4;p.A=[x,y];p.B=k%2?[x+n,y]:[x,y+n];p.minX=0;p.minY=0;p.maxX=8;p.maxY=8;p.prompt=`在网格放点A(${p.A})、B(${p.B})，用原单位步沿轴测距离。`;p.explain=`两点只有一个坐标不同，距离是该坐标之差的绝对值${n}，不是坐标相加。`}
  if(t.kind==='diagonal'){const x=k%3,y=Math.floor(k/3)%3;p.A=[x,y];p.B=[x+3,y+4];p.minX=0;p.minY=0;p.maxX=6;p.maxY=7;p.a=3;p.b=4;p.c=5;p.unit=1;p.unknown='c';p.prompt=`网格中A(${p.A})、B(${p.B})不在同轴。补一个实际直角拐点，量两段，再用原平方材料求直线距离。`;p.explain=`直角两段长3、4，平方和25，所以直线距离5；折线路程7不是两点直线距离。`}
 }
 if(t.mode==='solidLab'){
  if(['counts','match','valid','opposite'].includes(t.kind)){p.nets=t.kind==='valid'?[validNets[k%11],invalidNets[k%invalidNets.length]]:[validNets[k%11]];if(t.kind==='opposite')p.asked=['A',String.fromCharCode(66+k%5)];p.prompt=`沿原编号面逐条铰链试折、转动和翻面，${t.kind==='counts'?'标记实际面、共用边和顶点，分别计数':t.kind==='match'?'匹配纸面和立体上的同一原面':t.kind==='valid'?'自行判断两张原纸片能否成为立方体':'配出指定面的真正相对面'}。`;p.explain=`一个立方体有6面、12条共用边、8个顶点；相对面朝向相反，邻接不是相对。六张方片并不自动保证能折成立方体，要排除面重叠和原连接冲突。`}
  else{p.unit=k%2?1:2;const height=1+Math.floor(k/2)%3,width=2+k%2;const cells=Array.from({length:width},(_,x)=>[x,0,0]);for(let z=1;z<=height;z++)cells.push([0,0,z]);if(k%3===0)cells.push([0,1,0]);p.solids=[{title:'目标原方块',cells}];p.prompt=`按层用原单位块建目标，转动查看${t.kind==='surface'?'并逐块选真正外露方片':''}。每块边${p.unit}厘米，填写${t.kind==='volume'?'体积':'表面积'}与单位。`;p.explain=t.kind==='volume'?`每块体积是边长的立方，原块不重叠时体积可相加；隐藏层也要计入。`:`内部相贴两张方片都不计外表面，每张外露片面积是边长的平方。`}
 }
 if(!p.prompt)throw Error('No G model '+t.skillId);return p;
}
module.exports={modelG,validNets,invalidNets,canonical};
