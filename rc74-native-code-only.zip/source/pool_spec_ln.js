'use strict';
const gcd=(a,b)=>b?gcd(b,a%b):a,lcm=(a,b)=>a*b/gcd(a,b);
const periods=[['●','■'],['●','●','■'],['●','■','■'],['●','■','▲'],['●','■','▲','■'],['●','●','■','▲'],['●','■','■','▲'],['●','■','▲','◆','■'],['●','■','■','●'],['●','■','▲','●','■'],['●','■','●','▲','◆'],['●','■','▲','◆','●']];
function modelLN(t,k){
 if(t.kind==='digitRules'){
  const {DIGIT_RULE_MODELS,digitRuleInstance}=require('./divisibility'),kinds=['independent3','independent4','delayed7','delayed21','demo'];
  if(k<1||k>kinds.length)throw Error('digit rules finite pool exhausted');
  return digitRuleInstance(DIGIT_RULE_MODELS[kinds[k-1]],'DIGIT-RULE-PARAMETERS','测');
 }
 const p={mode:t.mode,kind:t.kind};
 if(t.mode==='equationLab'){
  p.methodSpecific=t.kind==='bilateral';
  if(t.kind==='equal'){const total=5+k%10,a=1+k%(total-1),b=1+(k*3)%(total-1);p.left=[a,total-a];p.right=[b,total-b];p.prompt=`把两边的${p.left.join('＋')}与${p.right.join('＋')}摆上天平，判断等号是否成立。`;p.explain=`左右都是${total}，等号连接的是两个相等的量。`}
  if(['unknown','bilateral'].includes(t.kind)){p.known=1+k%6;p.total=p.known+1+Math.floor(k/6)%9;p.prompt=t.kind==='unknown'?`未知盒加${p.known}等于${p.total}。自己确定盒内数量，再检查两边。`:`未知盒加${p.known}等于${p.total}。两边同取原对象，保留相等关系，再确定盒内数。`;p.explain=`${p.total}减去已知${p.known}，剩${p.total-p.known}；代回后两边相同。`}
  if(t.kind==='inverse'){p.initial=6+k%12;p.remain=1+Math.floor(k/12)%(p.initial-1);p.prompt=`原有${p.initial}，拿走未知部分后剩${p.remain}。移动原对象，找回被拿走的量。`;p.explain=`整体${p.initial}扣去剩余${p.remain}，拿走${p.initial-p.remain}；两部分可重新合并。`}
  if(t.kind==='substitute'){p.bag=1+k%8;p.known=1+Math.floor(k/8)%6;p.total=p.bag+p.known;p.prompt=`试把未知盒当作${p.bag}，放回“盒＋${p.known}＝${p.total}”，验证是否满足。`;p.explain=`试值代回时必须核对完整原式，两边都为${p.total}。`}
 }
 if(t.mode==='constraintLab'){
  if(['reverse','verify'].includes(t.kind)){p.groups=2+k%4;p.extra=1+Math.floor(k/4)%4;p.bag=1+Math.floor(k/16)%5;p.prompt=t.kind==='reverse'?`${p.groups}组，每组一个相同未知盒加${p.extra}个散点，合计${p.groups*(p.bag+p.extra)}。按组与组内两层关系找每盒的量。`:`每盒试放${p.bag}，${p.groups}组各有盒和${p.extra}个散点，检验总数${p.groups*(p.bag+p.extra)}。`;p.explain=`先将总量${p.groups*(p.bag+p.extra)}平均分${p.groups}组，再从每组扣掉${p.extra}个散点，每盒${p.bag}；不能把组内散点只扣一次。`}
  if(t.kind==='parity'){p.divisor=2+k%4;p.total=p.divisor*(2+Math.floor(k/4)%4)+1+k%(p.divisor-1);p.prompt=`${p.total}个原圆点分成${p.divisor}个同样多的整数组，能否全部分完？用原对象说明。`;p.explain=`每组必须是整数，分组后还有余数，不能把剩余圆点忽略。`}
  if(['stock','optimal'].includes(t.kind)){p.per=2+k%5;p.stock=p.per*(2+Math.floor(k/5)%4)+1+k%(p.per-1);p.prompt=`库存${p.stock}件，每个完整组合用${p.per}件。${t.kind==='optimal'?'装出最多的完整组合，再检验能否多装一组':'尝试装完整组合，标出库存不足的情况'}。`;p.explain=`最多${Math.floor(p.stock/p.per)}组，余下${p.stock%p.per}件不足以再装${p.per}件的一组；可行和最多不同。`}
 }
 if(t.mode==='patternLab'){
  if(t.kind==='period'){p.base=periods[k%periods.length];p.prompt=`观察重复图案，圈出能从头生成整个图案的最短一组，再续接。`;p.explain=`最短周期是${p.base.join('、')}，周期长${p.base.length}；只圈一部分不能生成整串。`}
  if(t.kind==='arithmetic'){const start=10+k%12,step=(k%2?1:-1)*(1+Math.floor(k/12)%4);p.initial=[start,start+step,start+2*step];p.step=step;p.prompt=`明确规则为每次${step>0?'加':'减'}${Math.abs(step)}。从${p.initial.join('、')}继续两项。`;p.explain=`相邻差固定${step}，用同一个增量接着走；规则已经给定，不由有限前缀猜唯一规则。`}
  if(t.kind==='geometric'){const start=1+k%5;p.factor=2+Math.floor(k/5)%2;p.initial=[start,start*p.factor,start*p.factor*p.factor];p.prompt=`明确规则为每次乘${p.factor}。从${p.initial.join('、')}继续两项。`;p.explain=`每次复制为${p.factor}倍，后两项是${p.initial[2]*p.factor}、${p.initial[2]*p.factor*p.factor}。`}
  if(t.kind==='explicit'){p.initial=[1+k%5];p.multiplier=2+Math.floor(k/5)%2;p.add=1+Math.floor(k/10)%4;p.prompt=`从${p.initial[0]}开始，每次先乘${p.multiplier}再加${p.add}。操作并记录接下来两项。`;p.explain=`每一轮都按同样的两步规则，不能把先乘后加交换。`}
  if(t.kind==='twoPrev'){p.initial=[1+k%6,1+Math.floor(k/6)%6];p.count=2;p.prompt=`从${p.initial.join('、')}开始，明确规则为后一项等于前两项之和。接出两项。`;p.explain=`下一项${p.initial[0]+p.initial[1]}，再下一项${p.initial[0]+2*p.initial[1]}；第二轮用的是最新两项。`}
  if(t.kind==='grid'){p.rows=2+k%3;p.cols=3+Math.floor(k/3)%4;p.start=k%2?'red':'blue';p.prompt=`${p.rows}行${p.cols}列方格，左上从${p.start==='red'?'红':'蓝'}开始，相邻格颜色相反，填满规则图。`;p.explain=`横向和纵向都交替，下一行起点必须与上方颜色相反。`}
 }
 if(t.mode==='coordinateLab'){
  if(t.kind==='machine'){p.multiplier=2+k%3;p.add=1+Math.floor(k/3)%5;p.inputs=[1,2,3];if(k%2)p.reverseIndex=2;p.prompt=`机器规则是先乘${p.multiplier}再加${p.add}。完成三个输入输出${p.reverseIndex===2?'，第三行从结果反求输入':''}。`;p.explain=`每一行使用同一规则；逆向时先撤销加${p.add}，再除以${p.multiplier}。`}
  if(t.kind==='pair'){p.maxX=5;p.maxY=5;p.target=[k%6,Math.floor(k/6)%6];p.prompt=`在网格上放点(${p.target.join('，')})，横坐标在前。`;p.explain=`先沿横轴定位${p.target[0]}，再沿纵轴定位${p.target[1]}，两个分量各有方向。`}
  if(t.kind==='order'){p.maxX=5;p.maxY=5;let x=1+k%4,y=1+Math.floor(k/4)%4;if(x===y)y=y%4+1;p.targets=[[x,y],[y,x]];p.prompt=`分别放点(${x}，${y})和(${y}，${x})，检查位置能否互换。`;p.explain=`横纵次序换了，位置也换了；它们是两个不同点。`}
  if(t.kind==='move'){p.maxX=5;p.maxY=5;p.start=[1+k%3,1+Math.floor(k/3)%3];p.dx=k%2?1:-1;p.dy=Math.floor(k/6)%2?2:-1;p.prompt=`从(${p.start.join('，')})出发，横向${p.dx}、纵向${p.dy}，逐格移动并记录。`;p.explain=`位移分别作用于横、纵坐标，终点(${p.start[0]+p.dx}，${p.start[1]+p.dy})。`}
  if(t.kind==='table'){const start=k%3,step=1+Math.floor(k/3)%3;p.pairs=[[0,start],[1,start+step],[2,start+2*step]];p.maxX=4;p.maxY=9;p.prompt=`把表格中的三组(${p.pairs.map(p=>p.join('，')).join(')、(')})转到网格，核对每个对应点。`;p.explain=`一行数据对应一个点，不能把不同两行的横纵坐标混配。`}
  if(t.kind==='dynamic'){p.startValue=k%3;p.step=1+Math.floor(k/3)%2;p.duration=2+Math.floor(k/6)%3;p.maxX=p.duration;p.maxY=11;p.prompt=`从${p.startValue}开始，每时段增加${p.step}，推进${p.duration}段，把时间与当前量配成点。`;p.explain=`每段后记录一个新点，终量${p.startValue+p.step*p.duration}；时间与量是不同坐标。`}
 }
 if(t.mode==='groupingLab'){
  if(['bags','remainder'].includes(t.kind)){p.divisor=2+k%5;p.total=p.divisor*(2+Math.floor(k/5)%4)+(t.kind==='bags'?0:k%p.divisor);p.prompt=`${p.total}个原圆点，每袋装${p.divisor}个。装完整袋并核对${t.kind==='bags'?'能否整除':'剩余数量'}。`;p.explain=`${p.total}＝${p.divisor}×${Math.floor(p.total/p.divisor)}＋${p.total%p.divisor}，余数要小于每袋量。`}
  if(t.kind==='digitSum'){p.divisor=3;p.numbers=[10+k%25,11+k%25];p.prompt=`把${p.numbers.join('和')}的数位拆开，合并数位和，再按3分组检验。`;p.explain=`按3分组数位和；一个数的位数与数位上的数字之和不同。`}
  if(t.kind==='digits'){const a=1+k%7,b=1+Math.floor(k/7)%8;p.pools=[[0,a,(a+2)%10],[0,b,(b+3)%10]];p.pools=p.pools.map(x=>[...new Set(x)]);p.rule=k%2?{tens:a}:{ones:b};p.prompt=`从两盘数字卡组成合法两位数，保留${p.rule.tens!==undefined?'十位为'+a:'个位为'+b}的全部表示。`;p.explain=`十位不能是0；先核对数位身份，再应用筛选条件，不能只数卡片。`}
  if(t.kind==='parity'){p.totals=[3+k%10,4+Math.floor(k/10)%9];p.divisor=2;p.prompt=`把两组${p.totals.join('、')}个原圆点分别配对，判断奇偶。`;p.explain=`能全部两两配对的是偶数，恰剩一个的是奇数；保留原对象，不能丢掉单个。`}
 }
 if(t.mode==='factorLab'){
  if(t.kind==='pairs'){p.numbers=[[6,8,10,12,14,15,16,18,20,21,22,24,26,28,30,32,33,34,35,36][k%20]];p.requiredPairs=2}
  if(['all','count'].includes(t.kind))p.numbers=[[6,8,10,12,14,15,16,18,20,21,22,24,26,28,30,32,33,34,35,36][k%20]];
  if(t.kind==='prime')p.numbers=[[2,3,5,7,11,13,17,19][k%8],[4,6,8,9,10,12,14,15][Math.floor(k/8)%8]];
  if(t.kind==='unit')p.numbers=[1,2+k%9];
  if(t.kind==='square'){const squares=[1,4,9,16,25,36],a=k%6,b=(a+1+Math.floor(k/6)%5)%6;p.numbers=[squares[a],squares[b]].sort((a,b)=>a-b)}
  p.prompt=`用${p.numbers.join('、')}个单位块各自拼完整长方阵，${t.kind==='pairs'?'记录至少两种不同因数对':t.kind==='prime'?'判断质数与合数':t.kind==='unit'?'比较1与其他数的因数，判断1是否为质数':t.kind==='square'?'核对平方数的中间因数对只计一次':'找全因数并去重'}。`;p.explain=`只有整行整列用完原块才是因数对；${t.kind==='unit'?'1只有一个正因数，不符合质数的两个因数条件':t.kind==='square'?'平方中间对两个数相同，因数只收录一次':'相同因数不重复记录，未试到的因数不能据此排除'}。`;
 }
 if(t.mode==='commonLab'){
  const a=2+k%4,b=2+Math.floor(k/4)%5,horizon=2*lcm(a,b),dims=[[4,8],[4,6],[6,9],[8,12],[9,12],[10,15],[12,16],[6,8],[8,10]][k%9];
  if(['multiples','least'].includes(t.kind))Object.assign(p,{periods:[a,b],horizon});
  if(t.kind==='divisors')p.numbers=dims;
  if(t.kind==='greatest')p.dims=dims;
  if(t.kind==='contexts'){p.bells={periods:[a,b],horizon};p.paper={dims}}
  p.prompt=t.kind==='divisors'?`把${dims.join('和')}分别等分，找出两者都能使用的组单位。`:t.kind==='greatest'?`用相同正方块完整铺${dims[0]}×${dims[1]}的纸，找最大的整边长。`:t.kind==='contexts'?`两个提醒间隔${a}、${b}，同时从0开始；另用同样方块铺${dims[0]}×${dims[1]}的纸。分别判断共同时间与共同分割单位。`:`两个活动每${a}和${b}分钟一次，从0同时开始。${t.kind==='least'?'找首次正时刻同时发生':'在时间线上找共同发生的正时刻'}。`;
  p.explain=`共同时间使用公倍数，首次正重合排除0；共同分割使用公因数，最大的单位才对应最大公因数。`;
 }
 if(t.mode==='cycleLab'){
  if(t.kind==='power'){p.factor=[2,3,4,5][k%4];p.period=p.factor===5?1:p.factor===4?2:4;p.target=1+Math.floor(k/4)%14;p.prompt=`从指数1开始，逐次生成${p.factor}的幂的末位，找第${p.target}次的末位。`;p.explain=`末位周期长度${p.period}，整周期余数0对应周期的最后一位，不能对应第0位。`}
  else{p.base=t.kind==='weekday'?['星期一','星期二','星期三','星期四','星期五','星期六','星期日']:periods[k%periods.length];p.target=1+Math.floor(k/periods.length)%18;if(t.kind==='weekday'){p.start=k%7;p.target=1+Math.floor(k/7)%18;p.prompt=`从${p.base[p.start]}作为第0天，经过${p.target}天，到哪一天？`}
  else p.prompt=`按${p.base.join('、')}重复，第1个从周期起点开始，找第${p.target}个位置。`;p.explain=t.kind==='weekday'?`“经过天数”从第0天计，不把起点算成已过1天。`:`每组${p.base.length}个，从第1个计位置；整周期落在最后一个位置。`}
 }
 if(!p.prompt)throw Error('No LN model '+t.skillId);return p;
}
module.exports={modelLN};
