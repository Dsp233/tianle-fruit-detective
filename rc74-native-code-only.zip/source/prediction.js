'use strict';
function predictionTarget(t){
 if(t.mode==='patternLab'&&['arithmetic','geometric','explicit','twoPrev'].includes(t.kind))return patternExpected(t);
 if(t.mode==='integerLab'&&['square','root','power'].includes(t.kind))return [t.kind==='root'?t.side*(t.unitSize??1):t.target];
 if(t.mode==='measureLab'&&t.kind!=='rearrange'){const per=measureEdges(t.cells||[],true).length*t.unitSize,area=(t.cells||[]).length*t.unitSize**2;return t.kind==='length'?[(t.end-t.start)*t.unitSize]:t.kind==='perimeter'?[per]:t.kind==='area'?[area]:[per,area]}
 if(t.mode==='angleLab'&&['triangle','conditions'].includes(t.kind))return [t.angles[t.unknown]];
 if(['percentLab','scaleLab'].includes(t.mode)){if(t.kind==='whole')return [t.part*t.copies];if(t.kind==='change')return [t.start+t.add-t.remove];if(t.kind==='estimate'&&t.bounds)return ['lower','upper'].map(k=>t.bounds[k][0]*t.bounds[k][1])}
if(t.mode==='ratioLab'){
  if(t.kind==='unit')return [t.groups];
  if(t.kind==='partition')return t.knownUnit?[t.copies]:[t.unitRed,t.unitBlue];
  if(t.kind==='scale')return [t.red*(t.targetCopies?.red||t.copies),t.blue*(t.targetCopies?.blue||t.copies)];
 }
 if(t.mode==='rateLab'){
  if(t.kind==='divide')return [t.per];if(t.kind==='compose')return [t.total];
  if(t.kind==='compare')return [t.a.total/t.a.units,t.b.total/t.b.units];
  if(t.kind==='convert')return [t.direction==='forward'?t.count*t.factor:t.count];
 }
 if(t.mode==='journeyLab'){
  const walked=t.segments?.reduce((a,b)=>a+b,0);
  return t.kind==='inverse'?[t.count*(t.elapsedPer||1)]:t.kind==='remaining'?[t.unknownWhole?t.whole:t.whole-walked]:t.kind==='joint'?[['a','b'].reduce((n,s)=>n+t[s]*Math.max(0,t.count-(t.starts?.[s]||0)),0)]:[t.kind==='segment'?walked:t.count*t.per];
 }
 if(t.mode==='scaleLab'){
  if(t.kind==='pair')return [t.red*(t.targetFactors?.red||t.factor),t.blue*(t.targetFactors?.blue||t.factor)];
  if(t.kind==='length')return ['short','long'].map(s=>t.direction==='shrink'?t[s]/t.factor:t[s]*t.factor);
  if(t.kind==='area')return [t.rows*t.cols*(t.axisFactors?.rows||t.factor)*(t.axisFactors?.cols||t.factor)];
  if(t.kind==='map')return [t.count*t.per];
 }
if(t.mode==='equationLab'){
  if(t.kind==='equal')return [Number(t.left.reduce((a,n)=>a+n,0)===t.right.reduce((a,n)=>a+n,0))];
  if(['unknown','bilateral'].includes(t.kind))return [t.total-t.known];
  if(t.kind==='inverse')return [t.unknownInitial?t.remain+t.removedGiven:t.initial-t.remain];
  if(t.kind==='substitute')return [Number(t.bag+t.known===t.total)];
 }
 if(t.mode==='constraintLab'){
  if(t.kind==='reverse')return [t.bag];
  if(t.kind==='verify')return [Number(t.groups*t.bag+(t.extraOutside?t.extra:t.groups*t.extra)===(t.givenTotal??t.groups*(t.bag+t.extra)))];
  if(t.kind==='parity')return [Number(t.total%t.divisor===0)];
  if(['stock','optimal'].includes(t.kind))return [Math.floor(t.stock/t.per)];
 }
 if(t.mode==='coordinateLab'){
  if(t.kind==='machine')return [t.reverseIndex===2?t.inputs[2]:t.inputs[2]*t.multiplier+t.add];
  if(t.kind==='dynamic')return [t.startValue+t.step*t.duration];
 }
if(t.mode==='groupingLab'&&t.kind==='digitRules')return t.cases.map(c=>c.number%c.divisor);
 if(t.mode==='groupingLab'&&t.kind!=='digits')return t.kind==='reconstruct'?[t.knownGroups*t.divisor+t.remainder]:(t.kind==='digitSum'?t.numbers.map(n=>String(n).split('').reduce((a,b)=>a+Number(b),0)):t.totals||[t.total]).map(n=>n%t.divisor);
 if(t.mode==='cycleLab'){
  if(t.kind==='power'){let digit=1;for(let i=0;i<t.target;i++)digit=digit*t.factor%10;return [digit]}
  const n=t.base.length,pos=(((t.kind==='weekday'?t.start:t.indexBase===0?0:-1)+(t.direction||1)*t.target)%n+n)%n;
  return [t.kind==='weekday'||t.indexBase===0?pos:pos+1];
 }
 return null;
}
function predictionNeeded(t){return assessmentFormal(t)&&predictionTarget(t)!==null}
function predictionApply(t,w,p){if(t.mode==='integerLab'&&t.unitSize){w.amount=p.firstValues[0];w.amountSet=true}if(t.mode==='measureLab'){const keys=t.kind==='length'||t.kind==='perimeter'?['length']:t.kind==='area'?['area']:['length','area'];keys.forEach((key,i)=>{w.amounts[key]=p.firstValues[i];w.amountSet[key]=true})}if(t.mode==='angleLab')w.answer=p.firstValues[0]}
function predictionState(t,w){
 if(w.prediction)return w.prediction;
 const count=predictionTarget(t)?.length||0,prior=taskHistory(t).firstPrediction;
 if(prior?.values?.length===count&&prior.values.every(Number.isInteger)){w.prediction={values:[...prior.values],set:Array(count).fill(true),locked:true,firstValues:[...prior.values]};predictionApply(t,w,w.prediction)}
 else w.prediction={values:Array(count).fill(0),set:Array(count).fill(false),locked:false,firstValues:null};
 return w.prediction;
}
function predictionVerdicts(t){if(t.mode==='cycleLab'&&t.kind==='weekday')return t.base;return t.mode==='equationLab'&&t.kind==='equal'?['两边不相等','两边相等']:t.mode==='equationLab'&&t.kind==='substitute'||t.mode==='constraintLab'&&t.kind==='verify'?['不满足原式','满足原式']:t.mode==='constraintLab'&&t.kind==='parity'?['没有整数解','有整数解']:null}
function predictionLabel(t,i,count){
 if(t.mode==='groupingLab'&&t.kind==='digitRules')return t.cases[i].number+'除以'+t.cases[i].divisor+'的余数';
 if(t.mode==='groupingLab')return t.kind==='reconstruct'?'原总数':(t.kind==='digitSum'?'数卡'+t.numbers[i]:'第'+(i+1)+'盘')+'的余数';
 if(t.mode==='cycleLab')return t.kind==='power'?'幂的个位':t.indexBase===0?'轮内编号':'周期第几位';
 if(t.mode==='ratioLab')return t.kind==='partition'?t.knownUnit?'完整袋数':i===0?'每份红色数量':'每份蓝色数量':t.kind==='scale'?i===0?'最后红色数量':'最后蓝色数量':'有几份';
 if(t.mode==='rateLab')return t.kind==='compare'?i===0?'甲的单位价格':'乙的单位价格':t.kind==='divide'?'每单位的量':t.kind==='convert'?t.direction==='forward'?t.to:t.from:'总量';
 if(t.mode==='journeyLab')return t.kind==='inverse'?t.elapsedPer?'用时（分钟）':'用时（'+t.interval+'）':t.kind==='remaining'?t.unknownWhole?'全程':'剩余路程':'总量';
 if(t.mode==='scaleLab')return t.kind==='pair'?i===0?'红色数量':'蓝色数量':t.kind==='length'?i===0?'短边长度':'长边长度':t.kind==='area'?'面积':'对应输出量';
 if(t.mode==='equationLab')return t.kind==='inverse'?t.unknownInitial?'原来的数量':'拿走的数量':'未知袋内数量';
 if(t.mode==='constraintLab')return t.kind==='reverse'?'每袋未知量':'最多完整袋数';
 if(t.mode==='coordinateLab')return t.kind==='machine'?t.reverseIndex===2?'找回的输入':'第三行输出':'最终量';
 return t.bounds?i===0?'下界':'上界':count>1?'第'+(i+1)+'个新值':t.kind==='root'?'边长':t.kind==='square'||t.mode==='measureLab'&&t.kind==='area'?'面积':t.mode==='measureLab'?t.kind==='length'?'长度':i===0?'周长':'面积':t.mode==='angleLab'?'未知角':'最终数量';
}
function predictionDisplay(t,values){const labels=predictionVerdicts(t);return labels?labels[values[0]]||'尚未判断':values.join('、')}
function predictionBoard(t,w,base){
 const p=predictionState(t,w),original=Array.isArray(t.initial)?t.initial.join('、'):null,verdicts=predictionVerdicts(t);
 const input=verdicts?`${choiceButtons(t,verdicts.map((label,value)=>[String(value),label]),'predictionPick','prediction',p.set[0]?String(p.values[0]):null)}<p>我的判断：${p.set[0]?esc(predictionDisplay(t,p.values)):'尚未选择'}</p>`:`<div class="prediction-values">${p.values.map((n,i)=>`<section><b>${esc(predictionLabel(t,i,p.values.length))}：${n}</b><div class="work-buttons">${[-10,-1,0,1,5,10,50].map(d=>`<button data-action="predictionAmount" data-index="${i}" data-delta="${d}">${d===0?'填0':d>0?'＋'+d:String(d)}</button>`).join('')}</div></section>`).join('')}</div>`;
 return `<div class="board prediction-board"><h3>先写下我的预测</h3>${original?`<p>已知数列：${esc(original)}</p>`:''}${input}${['measureLab','angleLab'].includes(t.mode)?base.board(t).replace(/<button\b/g,'<button disabled aria-disabled="true"'):''}<button class="primary" data-action="predictionLock" ${p.set.every(Boolean)?'':'disabled'}>保存预测，再操作验证 →</button></div>`;
}
function predictionAdapter(base){return {
 state:base.state,
 board(t){const w=base.state(t),p=predictionState(t,w);return p.locked?`<div class='prediction-summary'>我的预测：${esc(predictionDisplay(t,p.firstValues))}</div>`+base.board(t):predictionBoard(t,w,base)},
 act(action,data,t){const w=base.state(t),p=predictionState(t,w);
  if(action==='predictionPick'&&!p.locked&&predictionVerdicts(t)&&predictionVerdicts(t).some((_,i)=>String(i)===data.value)){p.values[0]=Number(data.value);p.set[0]=true;return true}
  if(action==='predictionAmount'&&!p.locked&&!predictionVerdicts(t)){const i=Number(data.index),d=Number(data.delta);if(Number.isInteger(i)&&i>=0&&i<p.values.length&&[-10,-1,0,1,5,10,50].includes(d)&&p.values[i]+d>=-100&&p.values[i]+d<=10000){p.values[i]+=d;p.set[i]=true;return true}return false}
  if(action==='predictionLock'&&!p.locked&&p.set.every(Boolean)){p.firstValues=[...p.values];p.locked=true;predictionApply(t,w,p);taskHistory(t).firstPrediction={values:[...p.firstValues],lockedAt:Date.now()};persist();return true}
  if(!p.locked)return false;const changed=base.act(action,data,t);if(draft.work!==w){const next=base.state(t);next.prediction=p;predictionApply(t,next,p)}return changed;
 },
 grade(t){const w=base.state(t),p=predictionState(t,w),result=base.grade(t),expected=predictionTarget(t);return {...result,ok:result.ok&&p.locked&&p.firstValues.every((n,i)=>n===expected[i]),incomplete:!p.locked||result.incomplete,reason:p.locked&&!p.firstValues.every((n,i)=>n===expected[i])?'预测与数学关系不符。回到例子，再用新题验证。':result.reason}},
 speech(t){const w=base.state(t),p=predictionState(t,w);return p.locked?`我的预测为${predictionDisplay(t,p.firstValues)}。`+base.speech(t):`还未保存预测。当前输入${predictionDisplay(t,p.values)}。`+(['measureLab','angleLab'].includes(t.mode)?base.speech(t):'')}
}}
