'use strict';
const RATE_TASKS={
 'R02.01':{kind:'divide',total:8,units:4,per:2,amountUnit:'元',unit:'个苹果',context:'买苹果',prompt:'8枚一元钱对应4个苹果。把钱币逐枚分到每个苹果下，求每个苹果的价钱。',explain:'8元平均分给4个苹果，每个2元/个。',reason:{prompt:'为什么是2元/个？',options:['每个苹果分到同样的2枚一元钱','8元买4个，所以每个8元','只看苹果数就是4元/个'],answer:0}},
 'R02.02':{kind:'divide',total:12,units:3,per:4,amountUnit:'升',unit:'分钟',context:'接水',prompt:'3分钟接12升水。把12升逐升分到3个一分钟格，求每分钟流量。',explain:'12÷3＝4升/分钟。',reason:{prompt:'为什么单位是升/分钟？',options:['每个一分钟格分到4升','4分钟才能接1升','12升是每一分钟的量'],answer:0}},
 'R02.03':{kind:'compare',a:{total:6,units:3,per:2},b:{total:8,units:2,per:4},amountUnit:'元',unit:'支',context:'笔的单价',prompt:'甲6元买3支，乙8元买2支。分别把钱币逐枚分到每支笔下，选更便宜的一包。',explain:'甲每支2元，乙每支4元；同为每支，甲便宜。',reason:{prompt:'为什么甲便宜？',options:['甲2元/支，小于乙4元/支','甲总价6小于8就一定便宜','甲有3支、乙有2支，支数多就一定便宜'],answer:0}},
 'R02.04':{kind:'convert',count:2,factor:100,from:'米',to:'厘米',direction:'forward',context:'长度尺',prompt:'一米卡对应100厘米。逐张换出两张一米卡的厘米量。',explain:'2张一米卡换成2组100厘米，共200厘米。',reason:{prompt:'为什么是200厘米？',options:['每米100厘米，两张相同卡合成200厘米','2米就是20厘米','单位不同但数字总保持2'],answer:0}},
 'R02.05':{kind:'divide',total:10,units:2,per:5,amountUnit:'千米',unit:'小时',context:'行程',prompt:'2小时共走10千米。逐千米分到两个一小时格，求平均速度。',explain:'每小时5千米，即5千米/小时。',reason:{prompt:'为什么是5千米/小时？',options:['10千米平均分给2个一小时格','2小时走10千米就每小时走10千米','把时间除以路程得到5千米/小时'],answer:0}}
};
for(const [skillId,t] of Object.entries(RATE_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:17,mode:'rateLab',phase:'练',hint:'先把每一个的时间或物品摆出来，再逐个分配量，检查单位。'});
if(typeof module!=='undefined')module.exports={RATE_TASKS};
