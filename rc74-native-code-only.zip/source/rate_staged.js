'use strict';
const RATE_CASES={
 'R02.01':[
  [{kind:'compose',units:3,per:4,total:12,amountUnit:'元',unit:'盒彩笔',context:'购物'},'每盒彩笔4元，逐枚给3盒彩笔各放4元，找总价。','3盒各4元，共12元。','从已知总价求单价改为已知单价求总价'],
  [{kind:'divide',total:15,units:5,per:3,amountUnit:'元',unit:'瓶水',context:'买水'},'15枚一元钱对应5瓶水，逐枚均分，求每瓶价格。','15÷5＝3元/瓶。','换水瓶与五个单位'],
  [{kind:'compose',units:4,per:2,total:8,amountUnit:'元',unit:'支笔',context:'文具'},'每支笔2元，给4支笔逐枚摆钱币，读出总价。','4×2＝8元。','隔日从单位率反求总价'],
  [{kind:'divide',total:12,units:4,per:3,amountUnit:'元',unit:'个面包',context:'面包店'},'12元买4个面包，逐枚均分，求每个价格。','12÷4＝3元/个。','新价格与商品']
 ],
 'R02.02':[
  [{kind:'compose',units:4,per:3,total:12,amountUnit:'升',unit:'分钟',context:'水龙头'},'每分钟接3升，给4个一分钟格各添3升，求总量。','3×4＝12升。','流量已知，未知变总量'],
  [{kind:'divide',total:20,units:4,per:5,amountUnit:'页',unit:'分钟',context:'打印机'},'打印机4分钟打20页，逐页分给4分钟，求每分钟页数。','20÷4＝5页/分钟。','水流换打印速度'],
  [{kind:'divide',total:18,units:3,per:6,amountUnit:'升',unit:'分钟',context:'水桶'},'3分钟注水18升，逐升平分到3分钟。','18÷3＝6升/分钟。','隔日水量新实例'],
  [{kind:'compose',units:5,per:2,total:10,amountUnit:'页',unit:'分钟',context:'传输'},'每分钟传2页，给5分钟格各放2页。','5×2＝10页。','新传输情境与反向未知']
 ],
 'R02.03':[
  [{kind:'compare',a:{total:8,units:2,per:4},b:{total:9,units:3,per:3},amountUnit:'元',unit:'本',context:'笔记本'},'甲8元2本、乙9元3本；分别逐枚分到每本，选便宜的一边。','甲4元/本，乙3元/本，乙便宜。','比较对象换本且较便宜者改乙'],
  [{kind:'compare',a:{total:12,units:4,per:3},b:{total:10,units:2,per:5},amountUnit:'元',unit:'个',context:'面包'},'甲12元4个、乙10元2个，分别均分后选单价更低者。','甲3元/个，乙5元/个。','包价大小反转'],
  [{kind:'compare',a:{total:6,units:2,per:3},b:{total:8,units:4,per:2},amountUnit:'元',unit:'支',context:'铅笔'},'甲6元2支、乙8元4支，均分后选更便宜的每支。','甲3元/支，乙2元/支。','隔日乙总价更高但单价更低'],
  [{kind:'compare',a:{total:9,units:3,per:3},b:{total:8,units:2,per:4},amountUnit:'元',unit:'瓶',context:'果汁'},'甲9元3瓶、乙8元2瓶，均分并选每瓶更便宜的。','甲3元/瓶，乙4元/瓶。','新果汁包装']
 ],
 'R02.04':[
  [{kind:'convert',count:2,factor:60,from:'小时',to:'分钟',direction:'forward',context:'时钟'},'每1小时换成60分钟，逐张换2张小时卡，读出分钟总数。','2小时＝120分钟。','长度单位换时间单位'],
  [{kind:'convert',count:3,factor:100,from:'米',to:'厘米',direction:'reverse',context:'卷尺'},'已有300厘米，逐组捆100厘米换成1米，读出米数。','300厘米＝3米。','从小单位反向换大单位'],
  [{kind:'convert',count:4,factor:60,from:'小时',to:'分钟',direction:'reverse',context:'日程'},'240分钟每60分钟换一张小时卡，读出小时数。','240分钟＝4小时。','隔日时间反向换算'],
  [{kind:'convert',count:5,factor:100,from:'米',to:'厘米',direction:'forward',context:'绳长'},'每米100厘米，逐张换5张米卡的厘米数。','5米＝500厘米。','五米新实例']
 ],
 'R02.05':[
  [{kind:'compose',units:3,per:4,total:12,amountUnit:'千米',unit:'小时',context:'步行'},'每小时走4千米，给3个一小时格各添4千米，求路程。','4×3＝12千米。','已知速度与时间反求路程'],
  [{kind:'divide',total:18,units:3,per:6,amountUnit:'千米',unit:'小时',context:'骑行'},'骑行3小时走18千米，逐千米分到小时格求速度。','18÷3＝6千米/小时。','交通方式变骑行'],
  [{kind:'compose',units:4,per:5,total:20,amountUnit:'千米',unit:'小时',context:'跑步'},'每小时5千米，给4个一小时格各放5千米求总路程。','5×4＝20千米。','隔日速度已知求路程'],
  [{kind:'divide',total:12,units:4,per:3,amountUnit:'千米',unit:'小时',context:'徒步'},'徒步4小时走12千米，逐千米分到4个小时格。','12÷4＝3千米/小时。','新时长与徒步']
 ]
};
const rateStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(RATE_CASES)){
 if(cases.length!==4)throw Error('Four R02 cases required: '+skillId);rateStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];rateStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:18,mode:'rateLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先统一单位，再把量逐个分给每一格；若已知每格的量就逐格合成。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={RATE_CASES};
