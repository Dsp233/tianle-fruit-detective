'use strict';
const RATIO_TASKS={
 'R01.01':{kind:'unit',red:6,blue:3,unit:3,groups:2,context:'红蓝玻璃珠',prompt:'蓝珠3颗是一份。把6颗红珠每3颗圈成一组，数出红珠有几份蓝珠。',explain:'红珠6颗可分成两组3颗，所以是蓝珠的2份。',reason:{prompt:'为什么红珠是两份？',options:['以蓝珠3颗为一份，6颗红珠可圈两组','红珠6颗就是6份','红蓝合起来9颗，所以是9份'],answer:0}},
 'R01.02':{kind:'order',red:2,blue:3,context:'绘画颜料',prompt:'逐颗摆出2颗红和3颗蓝；先说红，后说蓝，写出红:蓝的顺序。',explain:'红在前为2，蓝在后为3，红:蓝是2:3。',reason:{prompt:'为什么是2:3？',options:['前项对应红2，后项对应蓝3','蓝在后就写成3:2','红蓝两色合起来是2:5'],answer:0}},
 'R01.03':{kind:'whole',red:2,blue:3,context:'棋子盒',prompt:'摆2红3蓝，合在同一个盒里。红色占整个盒子几分之几？',explain:'红2，整体2＋3＝5，红占2/5，区别于红:蓝＝2:3。',reason:{prompt:'为什么红占2/5？',options:['分子是红2，分母是整个盒子的5','分母只用蓝3，得到2/3','只看红色2颗，所以是2/2'],answer:0}},
 'R01.04':{kind:'scale',red:2,blue:3,copies:3,context:'饮料配方',prompt:'每份配方用2红3蓝；同时复制到3份，观察红蓝数量如何一起变化。',explain:'复制三份，红6蓝9，两边同乘3，比仍为2:3。',reason:{prompt:'为什么新比相同？',options:['两边都乘3，得到6:9','只复制红色也保持2:3','红蓝相加为15，比例就是15:1'],answer:0}},
 'R01.05':{kind:'partition',red:6,blue:9,unitRed:2,unitBlue:3,copies:3,context:'食材袋',prompt:'袋里红6蓝9，逐份分成相同的小袋，找回每袋红蓝数量。',explain:'红6分成3份每份2，蓝9分成3份每份3；一袋红2蓝3。',reason:{prompt:'为什么每份是红2蓝3？',options:['两色都分成同样的3份','只把红除以3，蓝不变','把红蓝数互换成3:2'],answer:0}}
};
for(const [skillId,t] of Object.entries(RATIO_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:15,mode:'ratioLab',phase:'练',hint:'先确定谁是一份、哪个是整体，再在两种颜色上同时操作。'});
if(typeof module!=='undefined')module.exports={RATIO_TASKS};
