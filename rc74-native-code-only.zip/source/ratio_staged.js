'use strict';
const RATIO_CASES={
 'R01.01':[
  [{kind:'unit',red:8,blue:2,unit:2,groups:4,context:'积木'},'蓝积木2个是一份，逐组圈出8个红积木有几份。','8÷2＝4份。','珠子换积木、单位一份改为2'],
  [{kind:'unit',red:9,blue:3,unit:3,groups:3,context:'纸花'},'蓝纸花3朵是一份，逐组圈出红纸花9朵有几份。','9÷3＝3份。','纸花与三份新实例'],
  [{kind:'unit',red:12,blue:4,unit:4,groups:3,context:'果盘'},'蓝果4个是一份，逐组圈出红果12个有几份。','12÷4＝3份。','隔日改为四个一份'],
  [{kind:'unit',red:10,blue:5,unit:5,groups:2,context:'彩灯'},'蓝灯5盏是一份，逐组圈出10盏红灯。','10÷5＝2份。','新单位五盏与彩灯']
 ],
 'R01.02':[
  [{kind:'order',red:3,blue:2,context:'队伍',order:'blueFirst'},'摆出3个红队员、2个蓝队员，按照蓝:红顺序选比。','蓝:红是2:3。','已知次序换为蓝:红'],
  [{kind:'order',red:4,blue:1,context:'花束',order:'redFirst'},'摆4朵红花、1朵蓝花，选红:蓝的比。','红:蓝是4:1。','换花束与单位一'],
  [{kind:'order',red:2,blue:5,context:'棋子',order:'blueFirst'},'摆红2蓝5，选蓝:红的比。','蓝:红是5:2。','隔日先蓝后红'],
  [{kind:'order',red:5,blue:3,context:'卡片',order:'redFirst'},'摆红5蓝3，选红:蓝的比。','红:蓝是5:3。','新卡片实例']
 ],
 'R01.03':[
  [{kind:'whole',red:3,blue:2,context:'果盘'},'摆红果3蓝果2，红果占全部的几分之几？','3/(3＋2)＝3/5。','红色份量变3，区别于红蓝之比'],
  [{kind:'whole',red:1,blue:4,context:'扣子盒'},'摆红扣1蓝扣4，红扣占整个盒子的几分之几？','1/(1＋4)＝1/5。','分子改1、整体仍为5'],
  [{kind:'whole',red:2,blue:4,context:'队伍'},'摆红队员2蓝队员4，红队员占全部的几分之几？','2/(2＋4)＝2/6＝1/3。','整体6并需约分'],
  [{kind:'whole',red:3,blue:5,context:'颜料'},'摆红3蓝5，红色占这8份的几分之几？','3/(3＋5)＝3/8。','整体8的新实例']
 ],
 'R01.04':[
  [{kind:'scale',red:3,blue:1,copies:2,context:'舞台灯'},'每组红3蓝1，同时复制成两组；观察新数量与原比。','两组红6蓝2，与3:1相同。','饮料换灯、两份'],
  [{kind:'scale',red:1,blue:2,copies:4,context:'花束'},'每束红1蓝2，同时复制四束。','红4蓝8，比仍是1:2。','单份红1与四份'],
  [{kind:'scale',red:2,blue:1,copies:3,context:'拼图'},'每组红2蓝1，同时复制三组。','红6蓝3，比仍是2:1。','隔日拼图两色新比'],
  [{kind:'scale',red:1,blue:3,copies:2,context:'彩旗'},'每组红1蓝3，同时复制两组。','红2蓝6，比仍是1:3。','新彩旗实例']
 ],
 'R01.05':[
  [{kind:'partition',red:8,blue:4,unitRed:2,unitBlue:1,copies:4,context:'拼图袋'},'红8蓝4分成相同的四份，逐袋分配找每份。','每份红2蓝1。','总数与份数均改'],
  [{kind:'partition',red:9,blue:6,unitRed:3,unitBlue:2,copies:3,context:'花束'},'红9蓝6分成三束相同花束，逐束分配。','每束红3蓝2。','红蓝单份交换大小'],
  [{kind:'partition',red:4,blue:8,unitRed:1,unitBlue:2,copies:4,context:'卡片袋'},'红4蓝8分成四袋相同卡片，逐袋分配。','每袋红1蓝2。','隔日红少于蓝'],
  [{kind:'partition',red:6,blue:4,unitRed:3,unitBlue:2,copies:2,context:'彩灯串'},'红6蓝4分成两串相同彩灯，逐串分配。','每串红3蓝2。','新两份实例']
 ]
};
const ratioStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(RATIO_CASES)){
 if(cases.length!==4)throw Error('Four R01 cases required: '+skillId);
 ratioStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];ratioStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:16,mode:'ratioLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先分清单份、前后项和整体，再实际摆出两种颜色。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={RATIO_CASES};
