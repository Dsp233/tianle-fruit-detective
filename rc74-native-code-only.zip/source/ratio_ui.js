'use strict';
function ratioState(task){
 const w=draft.work??(draft.work={red:0,blue:0,groups:0,copiesRed:1,copiesBlue:1,perRed:task.knownUnit?task.unitRed:0,perBlue:task.knownUnit?task.unitBlue:0,bags:0,leftRed:task.red,leftBlue:task.blue,choice:'',moves:0,log:[]});
 w.log??=[];w.bagIds??=Array.from({length:w.bags},(_,i)=>({red:Array.from({length:w.perRed},(_,j)=>'R'+(i*w.perRed+j)),blue:Array.from({length:w.perBlue},(_,j)=>'B'+(i*w.perBlue+j))}));
 w.redPool??=Array.from({length:w.leftRed},(_,i)=>'R'+(w.bags*w.perRed+i));w.bluePool??=Array.from({length:w.leftBlue},(_,i)=>'B'+(w.bags*w.perBlue+i));
 return w;
}
function ratioDots(n,color,ids){return `<div class="ratio-dots" role="img" aria-label="${color==='red'?'红':'蓝'}色${n}颗">${Array.from({length:n},(_,i)=>`<i class="${color}" ${ids?`data-object-id="${ids[i]}"`:''} aria-hidden="true"></i>`).join('')}</div>`}
function ratioButtons(...items){return `<div class="work-buttons ratio-actions">${items.join('')}</div>`}
function ratioCorrectChoice(task){
 if(task.kind==='order')return task.order==='blueFirst'?`${task.blue}:${task.red}`:`${task.red}:${task.blue}`;
 const n=task.focusSide==='blue'?task.blue:task.red,d=task.red+task.blue,gcd=(a,b)=>b?gcd(b,a%b):a,g=gcd(n,d);return `${n/g}/${d/g}`;
}
function ratioChoice(task,w){
 const correct=ratioCorrectChoice(task),n=task.focusSide==='blue'?task.blue:task.red,other=task.focusSide==='blue'?task.red:task.blue;
 const alternatives=task.kind==='order'?[task.order==='blueFirst'?`${task.red}:${task.blue}`:`${task.blue}:${task.red}`,`${task.red}:${task.red+task.blue}`]:[`${n}/${other}`,`${other}/${task.red+task.blue}`];
 return `<p>${task.kind==='order'?'按规定的先后选择比：':`选择${task.focusSide==='blue'?'蓝':'红'}色占整个盒子的份量：`}</p>${choiceButtons(task,[...new Set([correct,...alternatives])].map(c=>[c,c]),'ratioChoice')}`;
}
function ratioTargets(task){return task.targetCopies||{red:task.copies,blue:task.copies}}
function ratioScaleChoice(task){const w=ratioState(task);return task.targetCopies?`<p>和原配比相比，现在的比：</p>${choiceButtons(task,[['same','保持相同'],['changed','已经改变']],'ratioChoice')}`:''}
function ratioBoard(task){const w=ratioState(task);
 if(task.kind==='unit')return `<div class="board ratio-board"><h3>${esc(task.context)} · 蓝色 ${task.blue} 颗是一份</h3>${ratioDots(task.blue,'blue')}<div class="ratio-group-list">${Array.from({length:task.groups},(_,i)=>`<div class="ratio-group ${i<w.groups?'circled':''}" aria-label="红珠第${i+1}份${i<w.groups?'已圈出':'未圈出'}">${ratioDots(task.unit,'red')}</div>`).join('')}</div><p>已圈出红色 ${w.groups} 份。</p>${ratioButtons(`<button data-action="ratioGroup" data-delta="1" ${w.groups>=task.groups?'disabled':''}>圈下一份 ${task.unit} 颗</button>`,`<button data-action="ratioGroup" data-delta="-1" ${!w.groups?'disabled':''}>↩ 撤回一份</button>`)}</div>`;
 if(['order','whole'].includes(task.kind))return `<div class="board ratio-board"><h3>${esc(task.context)} · 两种量分别摆出</h3><div class="ratio-pair">${['red','blue'].map(side=>`<section><b>${side==='red'?'红':'蓝'}色 ${w[side]} / ${task[side]}</b>${ratioDots(w[side],side)}${ratioButtons(`<button data-action="ratioAdd" data-side="${side}" data-delta="1" ${w[side]>=task[side]?'disabled':''}>＋${side==='red'?'红':'蓝'}1</button>`,`<button data-action="ratioAdd" data-side="${side}" data-delta="-1" ${!w[side]?'disabled':''}>↩${side==='red'?'红':'蓝'}1</button>`)}</section>`).join('')}</div><p>两色合起来 ${w.red+w.blue} 颗。</p>${ratioChoice(task,w)}</div>`;
 if(task.kind==='scale'){const limit=Math.max(...Object.values(ratioTargets(task)));return `<div class="board ratio-board"><h3>${esc(task.context)} · 原来红${task.red}、蓝${task.blue}</h3><div class="ratio-pair">${['red','blue'].map(side=>`<section><b>${side==='red'?'红':'蓝'} ${w['copies'+(side==='red'?'Red':'Blue')]} 份</b>${ratioDots(w['copies'+(side==='red'?'Red':'Blue')]*task[side],side)}</section>`).join('')}</div>${ratioButtons(...['both','red','blue'].map(side=>`<button data-action="ratioCopy" data-side="${side}" ${(side==='both'?Math.max(w.copiesRed,w.copiesBlue):w['copies'+(side==='red'?'Red':'Blue')])>=limit?'disabled':''}>${side==='both'?'同时复制红蓝一份':side==='red'?'只复制红一份':'只复制蓝一份'}</button>`),`<button data-action="ratioUndo" ${!w.log.length?'disabled':''}>↩ 撤回一次复制</button>`)}${ratioScaleChoice(task)}</div>`}
 const controls=task.knownUnit?'':ratioButtons(...['red','blue'].flatMap(side=>[1,-1].map(d=>`<button data-action="ratioPer" data-side="${side}" data-delta="${d}" ${w.bags?'disabled':''}>每袋${side==='red'?'红':'蓝'}${d>0?'＋':'－'}1</button>`)));
 return `<div class="board ratio-board"><h3>${esc(task.context)} · 原来红${task.red}、蓝${task.blue}</h3><p>每袋红 ${w.perRed}、蓝 ${w.perBlue}；已经分 ${w.bags}${task.knownUnit?'':' / '+task.copies} 袋。</p><div class="ratio-pair"><section><b>剩余红 ${w.leftRed}</b>${ratioDots(w.leftRed,'red',w.redPool)}</section><section><b>剩余蓝 ${w.leftBlue}</b>${ratioDots(w.leftBlue,'blue',w.bluePool)}</section></div><div class="ratio-group-list">${w.bagIds.map((ids,i)=>`<div class="ratio-group circled"><b>第${i+1}袋</b>${ratioDots(ids.red.length,'red',ids.red)}${ratioDots(ids.blue.length,'blue',ids.blue)}</div>`).join('')}</div>${controls}${ratioButtons(`<button data-action="ratioBag" ${!w.perRed||!w.perBlue||w.leftRed<w.perRed||w.leftBlue<w.perBlue||!task.knownUnit&&w.bags>=task.copies?'disabled':''}>分出一袋</button>`,`<button data-action="ratioUndo" ${!w.bags?'disabled':''}>↩ 同一袋放回</button>`,`<button data-action="ratioReset" ${w.moves?'':'disabled'}>从头重摆</button>`)}</div>`;
}
function ratioGrade(task){const w=ratioState(task);let ok=false,incomplete=w.moves===0;
 if(task.kind==='unit')ok=w.groups===task.groups&&w.groups*task.unit===task.red&&task.unit===task.blue;
 if(['order','whole'].includes(task.kind)){ok=w.red===task.red&&w.blue===task.blue&&w.choice===ratioCorrectChoice(task);incomplete=w.red===0&&w.blue===0||!w.choice}
 if(task.kind==='scale'){const target=ratioTargets(task);ok=w.copiesRed===target.red&&w.copiesBlue===target.blue&&(!task.targetCopies||w.choice===(target.red===target.blue?'same':'changed'));incomplete=w.moves===0||!!task.targetCopies&&!w.choice}
 if(task.kind==='partition'){
  const reds=[...w.redPool,...w.bagIds.flatMap(ids=>ids.red)],blues=[...w.bluePool,...w.bagIds.flatMap(ids=>ids.blue)];
  ok=w.bags===task.copies&&w.leftRed===0&&w.leftBlue===0&&w.perRed===task.unitRed&&w.perBlue===task.unitBlue&&w.bagIds.length===w.bags&&w.bagIds.every(ids=>ids.red.length===w.perRed&&ids.blue.length===w.perBlue)&&reds.length===task.red&&blues.length===task.blue&&new Set(reds).size===task.red&&new Set(blues).size===task.blue;
 }
 return {ok,incomplete,reason:'分别核对两种量。占整体的分母包括两色；只有两色按同一倍数改变，原配比才保持。'};
}
function ratioAct(action,data,task){const w=ratioState(task);let changed=false,d=Number(data.delta),side=data.side;
 if(action==='ratioGroup'&&task.kind==='unit'&&[-1,1].includes(d)&&w.groups+d>=0&&w.groups+d<=task.groups){w.groups+=d;changed=true}
 if(action==='ratioAdd'&&['order','whole'].includes(task.kind)&&['red','blue'].includes(side)&&[-1,1].includes(d)&&w[side]+d>=0&&w[side]+d<=task[side]){w[side]+=d;changed=true}
 if(action==='ratioChoice'&&['order','whole','scale'].includes(task.kind)&&typeof data.value==='string'){w.choice=data.value;changed=true}
 if(action==='ratioCopy'&&task.kind==='scale'&&['red','blue','both'].includes(side)){
  const keys=side==='both'?['copiesRed','copiesBlue']:[side==='red'?'copiesRed':'copiesBlue'],limit=Math.max(...Object.values(ratioTargets(task)));
  if(keys.every(k=>w[k]<limit)){for(const k of keys)w[k]++;w.log.push(keys);changed=true}
 }
 if(action==='ratioPer'&&task.kind==='partition'&&!task.knownUnit&&w.bags===0&&['red','blue'].includes(side)&&[-1,1].includes(d)&&w['per'+(side==='red'?'Red':'Blue')]+d>=0&&w['per'+(side==='red'?'Red':'Blue')]+d<=task[side]){w['per'+(side==='red'?'Red':'Blue')]+=d;changed=true}
 if(action==='ratioBag'&&task.kind==='partition'&&w.perRed>0&&w.perBlue>0&&(task.knownUnit||w.bags<task.copies)&&w.leftRed>=w.perRed&&w.leftBlue>=w.perBlue){
  w.bagIds.push({red:w.redPool.splice(0,w.perRed),blue:w.bluePool.splice(0,w.perBlue)});w.bags++;w.leftRed=w.redPool.length;w.leftBlue=w.bluePool.length;changed=true;
 }
 if(action==='ratioUndo'&&task.kind==='partition'&&w.bags){const ids=w.bagIds.pop();w.redPool.unshift(...ids.red);w.bluePool.unshift(...ids.blue);w.bags--;w.leftRed=w.redPool.length;w.leftBlue=w.bluePool.length;changed=true}
 if(action==='ratioUndo'&&task.kind==='scale'&&w.log.length){for(const k of w.log.pop())w[k]--;changed=true}
 if(action==='ratioReset'&&['scale','partition'].includes(task.kind)&&w.moves){draft.work=null;return true}
 if(changed)w.moves++;return changed;
}
function ratioSpeech(task){const w=ratioState(task);return task.kind==='unit'?`红已圈${w.groups}份，蓝色每份${task.blue}颗。`:task.kind==='scale'?`红${w.copiesRed*task.red}颗，蓝${w.copiesBlue*task.blue}颗。`:task.kind==='partition'?`每袋红${w.perRed}蓝${w.perBlue}，分了${w.bags}袋，还剩红${w.leftRed}蓝${w.leftBlue}。`:`红已摆${w.red}，蓝已摆${w.blue}。`}
function ratioPage(){const task=RATIO_TASKS[microSkillId],skill=SKILL_DATA.skills.find(s=>s.id===microSkillId);if(!task||!skill)return '<div class="panel">操作任务不存在。</div>';return `<div class="page-head"><div><p class="kicker">${esc(task.skillId)}</p><h1>${esc(skill.title)}</h1></div><button class="back" data-action="micro" data-code="${esc(task.skillId)}">← 返回</button></div><div class="work"><article class="panel"><span class="phase">练 · 操作一题</span><h2 class="task-title">${esc(task.prompt)}</h2><div class="workshop-check-top"><button class="primary" data-action="${feedback?.ok?'next':'check'}">${feedback?.ok?'完成本题 →':'检查操作与理由 ✓'}</button></div>${ratioBoard(task)}${reasonBlock(task)}${actionRow(task)}</article><aside class="side-stack">${stageLinks(task.skillId)}</aside></div>`}
