"""Update the fixed twenty-package ledger without counting unverified work."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('id')
parser.add_argument('status', choices=['not_started', 'in_progress', 'completed', 'blocked'])
parser.add_argument('--evidence', action='append', default=[])
parser.add_argument('--blocker', action='append', default=[])
args = parser.parse_args()
path = root / 'docs/rc67-progress.json'
ledger = json.loads(path.read_text())
package = next(p for p in ledger['packages'] if p['id'] == args.id)
for evidence in args.evidence:
    if not (root / evidence).is_file():
        parser.error('Missing evidence: ' + evidence)
if args.status == 'completed':
    if not args.evidence:
        parser.error('Completion requires acceptance evidence')
    incomplete = [i for i in package['dependsOn'] if next(p for p in ledger['packages'] if p['id'] == i)['status'] != 'completed']
    if incomplete:
        parser.error('Incomplete dependencies: ' + ', '.join(incomplete))
package.update(status=args.status, evidence=args.evidence, blockers=args.blocker,
               completedAt=datetime.now(timezone.utc).isoformat() if args.status == 'completed' else None)
ledger['implementationState'] = 'completed' if all(p['status'] == 'completed' for p in ledger['packages']) else 'in_progress'
ledger['completed'] = sum(p['status'] == 'completed' for p in ledger['packages'])
assert ledger['total'] == len(ledger['packages']) == 20
ledger['percent'] = 100 * ledger['completed'] // 20
ledger['implementationEvents'].append({'at': datetime.now(timezone.utc).isoformat(), 'id': args.id, 'status': args.status, 'evidence': args.evidence, 'blockers': args.blocker})
path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n')
print(f"RC67 {ledger['completed']}/20 ({ledger['percent']}%): {package['title']} — {args.status}")
