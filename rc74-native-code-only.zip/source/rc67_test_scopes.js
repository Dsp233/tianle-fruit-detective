'use strict';
const {COMPETITION_TOPIC_IDS:ids,competitionCanonicalIds}=require('./competition');
const {COMPETITION_REVIEWED:families}=require('./competition_reviewed');
const minimal=[...new Set(families.filter(f=>f.topicIds.length>1).map(f=>competitionCanonicalIds(f.topicIds).join(',')))].map(s=>s.split(','));
const tenOne=['A02','A03','A05','R01','R02','G01','G02','D01','D02','C01'];
const tenTwo=['C02','C03','C04','D03','G03','G07','N01','N04','S01','S02'];
const scopes=ids.map(id=>({kind:'single',ids:[id]})).concat(minimal.map(scope=>({kind:'minimal-integrated',ids:scope})),[{kind:'ten-topics-1',ids:competitionCanonicalIds(tenOne)},{kind:'ten-topics-2',ids:competitionCanonicalIds(tenTwo)},{kind:'all-topics',ids:[...ids]}]);
module.exports={scopes,minimal,tenOne,tenTwo};
