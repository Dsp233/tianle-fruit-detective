"""Read-only Actions runner for a hash-checked, isolated RC68 candidate.

No Pages writes, real records, browser downloads, or repository credentials.
"""
import hashlib, json, os, pathlib, shutil, subprocess, sys, time, urllib.request
root=pathlib.Path(__file__).resolve().parent.parent
evidence=pathlib.Path(os.environ['RUNNER_TEMP'])/'rc68-browser'/'evidence'
evidence.mkdir(parents=True,exist_ok=True)
chrome=shutil.which('google-chrome') or shutil.which('chromium')
if not chrome: raise RuntimeError('Preinstalled Chrome unavailable; no browser installation attempted')
env={**os.environ,'AMC8_BROWSER_EXECUTABLE':chrome,'AMC8_RC68_EVIDENCE':str(evidence),'AMC8_RC68_FROZEN_IDENTITY':str(root/'frozen-identity.json'),'AMC8_LOCAL_URL':'http://127.0.0.1:8768'}
identity=json.loads((root/'frozen-identity.json').read_text())
metadata={**identity,'environment':'GitHub Actions ubuntu-24.04','runId':os.environ.get('GITHUB_RUN_ID'),'executionCommit':os.environ.get('GITHUB_SHA'),'browserExecutable':chrome,'browserVersion':subprocess.check_output([chrome,'--version'],text=True).strip(),'productionRecordsAccessed':False,'browserDownloaded':False,'publicDeployment':False}
for command in [[sys.executable,'source/build.py','--check'],[sys.executable,'source/build_qa.py','--check']]:
    subprocess.run(command,cwd=root,env=env,check=True)
actual=json.loads(subprocess.check_output(['node','-e',"process.stdout.write(JSON.stringify(require('./source/rc68_evidence').identity()))"],cwd=root,env=env,text=True))
assert all(actual[k]==identity[k] for k in ['sourceCommit','sourceTreeHash','buildSha256'])
server=None
try:
    with (evidence/'http.log').open('w') as log:
        server=subprocess.Popen([sys.executable,'-u','-m','http.server','8768','--bind','127.0.0.1','--directory',str(root)],stdout=log,stderr=subprocess.STDOUT)
        for attempt in range(30):
            try:
                with urllib.request.urlopen('http://127.0.0.1:8768/qa/',timeout=1) as r: assert r.read()==(root/'qa/index.html').read_bytes()
                break
            except OSError: time.sleep(.1)
        else: raise RuntimeError('Isolated QA server unavailable')
        result=subprocess.run(['node','source/test_rc68_browser.js'],cwd=root,env=env)
        metadata['exitCode']=result.returncode
        metadata['result']='passed' if result.returncode==0 else 'failed'
finally:
    if server: server.terminate();server.wait(timeout=5)
    (evidence/'environment.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
    files=[{'path':str(p.relative_to(evidence)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(evidence.rglob('*')) if p.is_file()]
    (evidence/'file-manifest.json').write_text(json.dumps(files,ensure_ascii=False,indent=2)+'\n')
    resultFile=evidence/'browser/results.json'
    report=json.loads(resultFile.read_text()) if resultFile.exists() else {'result':'failed','errors':['Browser report missing']}
    compact={k:v for k,v in report.items() if k not in ['screenshots','domFiles','layouts','journeys']}
    compact.update(environment=metadata,layoutCount=len(report.get('layouts',[])),routeJourneyCount=len(report.get('journeys',[])),screenshotCount=len(report.get('screenshots',[])),domFileCount=len(report.get('domFiles',[])),fullReportSha256=hashlib.sha256(resultFile.read_bytes()).hexdigest() if resultFile.exists() else None,fileManifestSha256=hashlib.sha256((evidence/'file-manifest.json').read_bytes()).hexdigest())
    with open(os.environ['GITHUB_STEP_SUMMARY'],'a') as summary:
        fence=chr(96)*3
        summary.write('## RC68 genuine browser result\n\n')
        summary.write('Result: **'+report['result']+'**. Production deployment: **false**.\n\n')
        summary.write('Basic scenes: '+str(report.get('executedBasicScenes',0))+'/846. Route nodes: '+str(report.get('executedRouteNodes',0))+'. Hint stages: '+str(report.get('executedHintStages',0))+'.\n\n')
        summary.write('<details><summary>RC68_BROWSER_OBSERVATION_JSON</summary>\n\n'+fence+'json\n'+json.dumps(compact,ensure_ascii=False,indent=2)+'\n'+fence+'\n\n</details>\n')
if metadata.get('exitCode',1): sys.exit(1)
