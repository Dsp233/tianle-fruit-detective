'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),cp=require('child_process');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
function identity(){
 const measured={sourceTreeHash:hash(fs.readdirSync(__dirname).filter(x=>/\.(js|json|py|css|html)$/.test(x)&&x!=='index.html').sort().map(x=>x+':'+hash(fs.readFileSync(path.join(__dirname,x)))).join('\n')),buildSha256:hash(fs.readFileSync(path.join(__dirname,'../index.html')))};
 if(process.env.AMC8_RC68_FROZEN_IDENTITY){const frozen=JSON.parse(fs.readFileSync(process.env.AMC8_RC68_FROZEN_IDENTITY,'utf8'));if(measured.sourceTreeHash!==frozen.sourceTreeHash||measured.buildSha256!==frozen.buildSha256||!/^[a-f0-9]{40}$/.test(frozen.sourceCommit))throw Error('Frozen transfer identity mismatch');return {...measured,sourceCommit:frozen.sourceCommit,sourceCommitOrigin:'hash-validated-transfer-manifest',executionCommit:process.env.GITHUB_SHA,runId:process.env.GITHUB_RUN_ID};}
 return {...measured,sourceCommit:cp.execFileSync('git',['rev-parse','HEAD']).toString().trim()};
}
function save(name,report){const directory=process.env.AMC8_RC68_EVIDENCE||'docs/evidence/rc68';fs.mkdirSync(path.join(directory,path.dirname(name)),{recursive:true});const result={schemaVersion:1,observedAt:new Date().toISOString(),...identity(),...report};fs.writeFileSync(path.join(directory,name+'.json'),JSON.stringify(result,null,2)+'\n');console.log(name+': '+result.result+(result.cases!==undefined?' ('+result.cases+' cases)':''));return result}
module.exports={identity,save,hash};
