'use strict';
// Independent algorithms: combination enumeration, integer search and unit cells.
// Never reads c.answer, methods or diagram coordinates as the expected answer.
const {designOracle}=require('./competition_design_oracles');
const rational=s=>String(s).replace(/−/g,'-').split('/').map(Number).reduce((a,b)=>a/b);
// UI entry preserves the independent numeric oracle's small rational value.
// Bounded continued fractions avoid typing a rounded repeating decimal into
// an exact grader. No published answer or normalized answer field is read.
function exactInput(value){
 if(typeof value==='string')return value;
 if(!Number.isFinite(value))throw Error('Non-finite oracle input');
 if(Number.isSafeInteger(value))return String(value);
 const sign=value<0?'-':'',target=Math.abs(value);let x=target,h0=0,h1=1,k0=1,k1=0;
 for(let i=0;i<40;i++){
  const a=Math.floor(x),h=a*h1+h0,k=a*k1+k0;
  if(!Number.isSafeInteger(h)||!Number.isSafeInteger(k)||k>1000000000)break;
  if(Math.abs(h/k-target)<=1e-12*Math.max(1,target))return sign+h+'/'+k;
  [h0,h1,k0,k1]=[h1,h,k1,k];const rest=x-a;if(!rest)break;x=1/rest;
 }
 throw Error('Independent oracle cannot provide a bounded exact UI input');
}
function combos(cards,count){let products=[];for(let mask=0;mask<2**cards.length;mask++){const pick=cards.filter((_,i)=>mask&(1<<i));if(pick.length===count)products.push(pick.reduce((a,b)=>a*b,1))}return Math.min(...products)}
function groups(p){const found=[];for(let B=1;B<=p.T;B++)for(let A=1;A<=p.T-B;A++){const C=p.T-A-B;if(C>0&&A-B===p.direction*p.d&&C===p.k*(p.ref==='A'?A:B))found.push({A,B,C})}if(found.length!==1)throw Error('Expected one discrete group solution; got '+found.length);return found[0][p.goal]}
function range(p){let n=0;for(let x=p.lo+1;x<p.hi;x++){let digits=String(x),unit=Number(digits.at(-1));if(unit!==0&&x/unit===Math.floor(x/unit)&&(!p.evenOnly||x%2===0))n++}return n}
function lArea(p){let n=0;const side=p.inner+p.border;for(let y=0;y<side;y++)for(let x=0;x<side;x++)if(x<p.border||y<p.border)n++;return n}
const parityCache=new Map();
function parityEnumeration(n){
 if(parityCache.has(n))return parityCache.get(n);let answer=0,extension=0;
 function walk(values){if(values.length===n){answer++;if(values[0]%2)extension++;return}
  for(let next=1;next<=n;next++)if(!values.includes(next)&&!(next%2===0&&values.length&&values.at(-1)%2===0))walk([...values,next]);
 }
 walk([]);const result={answer,extension};parityCache.set(n,result);return result;
}
function oracle(task,f){const c=task.competition,p=c.math,v=c.extension.math;
 if(c.integrated)return require('./rc70_oracles').integrated(task);
 if(f.id==='natural-weighted'&&c.recipe.generatorRevision===5){const q=c.extension.problemState.math;let k=0;const values=[];for(let n=0;n<=q.highCount;n++)if(q.count>n&&(q.total-q.score*n)/(q.count-n)<=q.target+1e-12)values.push(n);k=Math.min(...values);return {answer:(p.red*p.redScore+p.blue*p.blueScore)/((p.red+p.blue)*(p.den||1)),extension:k};}

 if(f.id==='threeGroupBalance')return {answer:groups(p),extension:groups(v)};
 if(c.configurationId){
  if(f.id==='signedProduct')return {answer:combos(p.cards,3),extension:combos(v.cards,2)};
  if(f.id==='digitDivisor')return {answer:range(p),extension:range(v)};
  if(f.id==='lShapeArea')return {answer:lArea(p),extension:4*(p.inner+p.border)};
  if(f.id==='overlapAverages')return {answer:p.values[3],extension:v.values[4]};
  if(f.id==='parityPermutations'&&c.configurationId==='first-odd-transfer')return parityEnumeration(p.n);
 }
 return designOracle(task,f);
}
module.exports={oracle,rational,exactInput,groups,range,lArea,combos,parityEnumeration};
