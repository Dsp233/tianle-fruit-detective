'use strict';
// Derive conclusions from evidence; missing mandatory records are never PASS.
const required=['caseId','familyId','configurationId','seed','sourceCommit','buildSha256','steps','expected','actual','status','evidencePaths','observedAt','runner'];
const states=new Set(['PASS','FAIL','BLOCKED','NOT_RUN','NOT_APPLICABLE']);
function validate(row){
 const issues=required.filter(k=>row[k]===undefined||row[k]===null).map(k=>'Missing '+k);
 if(!states.has(row.status))issues.push('Unknown status');
 if(row.status==='PASS'&&(!Array.isArray(row.evidencePaths)||!row.evidencePaths.length))issues.push('PASS requires raw evidence');
 if(row.status==='NOT_APPLICABLE'&&(!row.reason||row.mandatory!==false))issues.push('Mandatory or unexplained NOT_APPLICABLE');
 if(row.sourceCommit&&!/^[a-f0-9]{40}$/.test(row.sourceCommit))issues.push('Invalid source Git SHA');
 if(row.buildSha256&&!/^[a-f0-9]{64}$/.test(row.buildSha256))issues.push('Invalid build SHA256');
 return issues;
}
function aggregate(expectedCaseIds,rows,identity){
 const ids=new Map(),errors=[];
 for(const row of rows){if(ids.has(row.caseId))errors.push('Duplicate case '+row.caseId);ids.set(row.caseId,row);for(const e of validate(row))errors.push(row.caseId+': '+e);if(identity&&(row.sourceCommit!==identity.sourceCommit||row.buildSha256!==identity.buildSha256))errors.push(row.caseId+': tested identity mismatch')}
 const missing=expectedCaseIds.filter(id=>!ids.has(id)),requiredRows=expectedCaseIds.map(id=>ids.get(id)).filter(Boolean),counts={PASS:0,FAIL:0,BLOCKED:0,NOT_RUN:missing.length,NOT_APPLICABLE:0};
 for(const row of requiredRows)if(states.has(row.status))counts[row.status]++;
 const status=counts.FAIL?'FAIL':errors.length||counts.BLOCKED?'BLOCKED':counts.NOT_RUN?'NOT_RUN':'PASS';
 return {status,expected:expectedCaseIds.length,actual:requiredRows.length,counts,missing,errors};
}
module.exports={validate,aggregate};
