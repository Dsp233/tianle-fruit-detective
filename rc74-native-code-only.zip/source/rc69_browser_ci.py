"""Read-only native browser runner for an immutable RC69 transfer package."""
import hashlib,json,os,pathlib,shutil,subprocess,sys,time,urllib.request
root=pathlib.Path(__file__).resolve().parent.parent
mode=os.environ.get('AMC8_RC69_BROWSER_MODE','native')
shard=os.environ.get('AMC8_RC69_SHARD','0')
evidence=pathlib.Path(os.environ['RUNNER_TEMP'])/'rc69-browser'/('legacy' if mode=='legacy' else 'shard-'+shard)/'evidence'
evidence.mkdir(parents=True,exist_ok=True)
chrome=shutil.which('google-chrome') or shutil.which('chromium')
if not chrome: raise RuntimeError('Preinstalled Chrome unavailable; no browser download attempted')
env={**os.environ,'AMC8_BROWSER_EXECUTABLE':chrome,'AMC8_RC68_EVIDENCE':str(evidence),'AMC8_RC69_EVIDENCE':str(evidence),'AMC8_RC68_FROZEN_IDENTITY':str(root/'frozen-identity.json'),'AMC8_LOCAL_URL':'http://127.0.0.1:8769'}
identity=json.loads((root/'frozen-identity.json').read_text())
metadata={**identity,'mode':mode,'shard':shard,'environment':'GitHub Actions ubuntu-24.04','runId':os.environ.get('GITHUB_RUN_ID'),'executionCommit':os.environ.get('GITHUB_SHA'),'browserVersion':subprocess.check_output([chrome,'--version'],text=True).strip(),'productionRecordsAccessed':False,'browserDownloaded':False,'publicDeployment':False,'result':'blocked','exitCode':2}
for cmd in [[sys.executable,'source/build.py','--check'],[sys.executable,'source/build_qa.py','--check']]: subprocess.run(cmd,cwd=root,env=env,check=True)
actual=json.loads(subprocess.check_output(['node','-e',"process.stdout.write(JSON.stringify(require('./source/rc69_evidence').identity()))"],cwd=root,env=env,text=True))
assert all(actual[k]==identity[k] for k in ['sourceCommit','sourceTreeHash','buildSha256'])
server=None
try:
 with (evidence/'http.log').open('w') as log:
  server=subprocess.Popen([sys.executable,'-u','-m','http.server','8769','--bind','127.0.0.1','--directory',str(root)],stdout=log,stderr=subprocess.STDOUT)
  for _ in range(30):
   try:
    with urllib.request.urlopen('http://127.0.0.1:8769/qa/',timeout=1) as r:assert r.read()==(root/'qa/index.html').read_bytes()
    break
   except OSError:time.sleep(.1)
  else:raise RuntimeError('Isolated candidate server unavailable')
  result=subprocess.run(['node','source/test_rc68_browser.js' if mode=='legacy' else 'source/test_rc69_browser.js'],cwd=root,env=env)
  metadata.update(exitCode=result.returncode,result='passed' if result.returncode==0 else 'blocked' if result.returncode==2 else 'failed')
finally:
 if server:server.terminate();server.wait(timeout=5)
 (evidence/'environment.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
 result_file=evidence/('browser/results.json' if mode=='legacy' else 'browser/shard-'+shard+'.json')
 report=json.loads(result_file.read_text()) if result_file.exists() else {'result':'blocked','errors':['Native report missing']}
 files=[{'path':str(p.relative_to(evidence)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(evidence.rglob('*')) if p.is_file()]
 (evidence/'file-manifest.json').write_text(json.dumps(files,ensure_ascii=False,indent=2)+'\n')
 compact={k:v for k,v in report.items() if k not in ['rows','screenshots','domFiles','layouts','journeys']}
 compact.update(environment=metadata,rowCount=len(report.get('rows',[])),screenshotCount=len(report.get('screenshots',[])),domFileCount=len(report.get('domFiles',[])),reportSha256=hashlib.sha256(result_file.read_bytes()).hexdigest() if result_file.exists() else None,manifestSha256=hashlib.sha256((evidence/'file-manifest.json').read_bytes()).hexdigest())
 with open(os.environ['GITHUB_STEP_SUMMARY'],'a') as summary:
  fence=chr(96)*3
  summary.write('## RC69 native candidate '+mode+' '+shard+'\n\nResult: **'+report['result']+'**. Formal deployment: **false**.\n\n')
  summary.write('<details><summary>RC69_NATIVE_RECEIPT_JSON</summary>\n\n'+fence+'json\n'+json.dumps(compact,ensure_ascii=False,indent=2)+'\n'+fence+'\n\n</details>\n')
sys.exit(metadata['exitCode'])
