'use strict';
const fs=require('fs'),path=require('path'),cp=require('child_process');
const base=require('./rc68_evidence');
function identity(){
 const value=base.identity();if(process.env.AMC8_RC68_FROZEN_IDENTITY)return {...value,workingTreeDirty:false,workingDiffSha256:base.hash('')};
 const dirty=cp.execFileSync('git',['status','--porcelain','--untracked-files=no']).toString();
 return {...value,workingTreeDirty:!!dirty,workingDiffSha256:base.hash(cp.execFileSync('git',['diff','HEAD','--','source'],{maxBuffer:16*1024*1024})),workingDiffScope:'tracked source; generated builds identified separately'};
}
function save(name,report){
 const dir=process.env.AMC8_RC69_EVIDENCE||'docs/evidence/rc69',file=path.join(dir,name+'.json');fs.mkdirSync(path.dirname(file),{recursive:true});
 const result={schemaVersion:1,observedAt:new Date().toISOString(),...identity(),...report};fs.writeFileSync(file,JSON.stringify(result,null,2)+'\n');console.log(name+': '+result.result+' ('+(result.cases||0)+' checks)');return result;
}
module.exports={identity,save,hash:base.hash};
