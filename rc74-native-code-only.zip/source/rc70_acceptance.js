'use strict';
const fs=require('fs'),crypto=require('crypto'),path=require('path');
function aggregate(manifest,plan,results,gate='development',artifactRoot='.'){
 const errors=[],cases=[];if(plan.buildId!==manifest.buildId)errors.push('PLAN_BUILD_MISMATCH');
 for(const definition of plan.tasks.filter(t=>t.gate===gate)){
  const attempts=results.filter(r=>r.caseId===definition.caseId).sort((a,b)=>a.attempt-b.attempt),ids=new Set();
  for(const r of attempts){if(ids.has(r.attempt))errors.push('DUPLICATE_ATTEMPT:'+r.caseId);ids.add(r.attempt);if(r.buildId!==manifest.buildId||r.testDefinitionHash!==plan.testDefinitionHash)errors.push('RESULT_IDENTITY_MISMATCH:'+r.caseId);if(r.schema!==1||!Number.isInteger(r.attempt)||r.attempt<1||!Array.isArray(r.artifacts)||!r.artifacts.length)errors.push('RESULT_SCHEMA_OR_EVIDENCE_MISSING:'+r.caseId);for(const a of r.artifacts||[]){const target=path.resolve(artifactRoot,a.path||''),relative=path.relative(path.resolve(artifactRoot),target);if(relative.startsWith('..')||path.isAbsolute(relative)||!fs.existsSync(target)||!fs.statSync(target).isFile()||crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex')!==a.sha256)errors.push('ARTIFACT_MISMATCH:'+r.caseId)}}
  const failed=attempts.find(r=>r.status==='FAIL'&&r.failureClass==='PRODUCT'),latest=attempts.at(-1);
  cases.push({caseId:definition.caseId,status:failed?'FAIL':latest?.status||'NOT_RUN',attempts:attempts.length,failureClass:failed?.failureClass||latest?.failureClass||null});
 }
 const unknown=results.filter(r=>!plan.tasks.some(t=>t.caseId===r.caseId));if(unknown.length)errors.push('UNKNOWN_CASES');
 const result=errors.length?'INVALID':cases.some(c=>c.status==='FAIL')?'FAIL':cases.some(c=>!['PASS','POLICY_PASS','NOT_APPLICABLE'].includes(c.status))?'BLOCKED':'PASS';
 return {schema:1,buildId:manifest.buildId,gate,result,errors,cases,independentAcceptance:'INDEPENDENT_PENDING'};
}
if(require.main===module){const args=Object.fromEntries(process.argv.slice(2).reduce((a,v,i,s)=>v.startsWith('--')?[...a,[v.slice(2),s[i+1]]]:a,[])),run=args['run-dir'],manifest=JSON.parse(fs.readFileSync(args.manifest)),plan=JSON.parse(fs.readFileSync(path.join(run,'plan.json'))),results=[];
 function walk(dir){for(const d of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,d.name);if(d.isDirectory())walk(p);else if(d.name==='result.json')results.push(JSON.parse(fs.readFileSync(p)))}}walk(path.join(run,'cases'));
 const result=aggregate(manifest,plan,results,args.gate||'development',run);fs.writeFileSync(args.out,JSON.stringify(result,null,2)+'\n');console.log(result.result,result.cases.length,'logical tasks');process.exitCode=result.result==='PASS'?0:result.result==='FAIL'?1:2;
}
module.exports={aggregate};
