"""Execute and collect read-only RC70 candidate CI jobs."""
import hashlib,json,os,pathlib,shutil,subprocess,sys

ROOT=pathlib.Path(__file__).resolve().parent.parent
TEMP=pathlib.Path(os.environ.get('RUNNER_TEMP',str(ROOT/'tmp/rc70/ci')))
RUN=TEMP/'rc70-run'

def load(p):return json.loads(p.read_text())
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

def execute(kind,shard=None):
    plan=TEMP/'rc70-plan.json'
    subprocess.run([sys.executable,str(ROOT/'source/run_rc70_gates.py'),'plan','--manifest',str(ROOT/'release-contract.json'),'--out',str(plan)],check=True)
    cmd=[sys.executable,str(ROOT/'source/run_rc70_gates.py'),'run','--plan',str(plan),'--run-dir',str(RUN),'--only',kind,'--workers','auto-max']
    if kind=='browser':cmd+=['--case-id','browser/shard-'+str(shard)]
    return subprocess.run(cmd).returncode

def collect(raw):
    merged=TEMP/'rc70-merged';merged.mkdir(parents=True,exist_ok=True);seen=set();plan=None
    for p in sorted(raw.rglob('plan.json')):
        folder=p.parent
        if not (folder/'cases').is_dir():continue
        current=load(p)
        if plan is None:plan=current
        else:assert current['testDefinitionHash']==plan['testDefinitionHash'],'Mixed test definitions'
        for result in (folder/'cases').rglob('result.json'):
            row=load(result);key=(row['caseId'],row['attempt']);assert key not in seen,'Duplicate logical case attempt';seen.add(key)
        shutil.copytree(folder/'cases',merged/'cases',dirs_exist_ok=True)
    assert plan,'No raw CI plans received';write(merged/'plan.json',plan)
    result_path=merged/'acceptance.json'
    code=subprocess.run(['node',str(ROOT/'source/rc70_acceptance.js'),'--manifest',str(ROOT/'release-contract.json'),'--run-dir',str(merged),'--gate','development','--out',str(result_path)]).returncode
    acceptance=load(result_path);manifest=load(ROOT/'release-contract.json');scope=load(ROOT/'scope.json')
    expected={(c['familyId'],c['configurationId'],seed) for c in scope['configurations'] for seed in manifest['seeds']}
    populations={};population_errors=[];self_checks={}
    for group,name in [('matrix','matrix'),('browser','browser')]:
        rows=[]
        for shard in range(4):
            attempts=sorted((merged/'cases'/group/('shard-'+str(shard))).glob('attempt-*'),key=lambda p:int(p.name.split('-')[-1]))
            if attempts:
                p=attempts[-1]/'evidence'/(name+'-'+str(shard)+'.json')
                if p.exists():rows+=load(p)['rows']
        keys=[(r['familyId'],r['configurationId'],r['seed']) for r in rows]
        valid=len(keys)==len(expected) and len(set(keys))==len(keys) and set(keys)==expected
        if not valid:population_errors.append(group+': incomplete or duplicate instance population')
        if any(r['status'] not in ['PASS','POLICY_PASS'] for r in rows):population_errors.append(group+': failed or unrun instance')
        counts={s:sum(r['status']==s for r in rows) for s in ['PASS','POLICY_PASS','FAIL','NOT_RUN']};populations[group]={**counts,'instances':len(rows),'completeIdentitySet':valid}
        write(merged/(group+'-instance-pairs.json'),rows)
        if group=='browser':
            normal=[r for item in rows for r in item.get('rc74NormalJourney',{}).get('rows',[])]
            courses=[r for item in rows for r in item.get('rc74CurriculumJourney',{}).get('rows',[])]
            normal_keys=[(r['profile'],r['slot']) for r in normal]
            course_ids=[r['skillId'] for r in courses]
            expected_courses={r['id'] for r in load(ROOT/'source/skills.json')['skills']}
            normal_ok=len(normal_keys)==40 and set(normal_keys)=={(p,s) for p in range(4) for s in range(1,11)} and all(r['status']=='PASS' for r in normal)
            courses_ok=len(course_ids)==179 and len(set(course_ids))==179 and set(course_ids)==expected_courses and all(r['status']=='PASS' for r in courses)
            if not normal_ok:population_errors.append('normal journeys: missing, duplicate or failed real browser slots')
            if not courses_ok:population_errors.append('curriculum: missing, duplicate or failed real browser skill entries')
            self_checks['normalBrowserJourneys']={'status':'PASS' if normal_ok else 'FAIL','profiles':4,'slots':len(normal),'allSolvedExcludedInNextSession':normal_ok}
            self_checks['nativeCurriculum']={'status':'PASS' if courses_ok else 'FAIL','skills':len(courses),'completeIdentitySet':courses_ok,'scope':'concept text, narration requests and real operation entry; no mastery awarded'}
            write(merged/'normal-browser-journeys.json',normal);write(merged/'curriculum-native.json',courses)
    math_attempts=sorted((merged/'cases/core/test_rc74_math_review').glob('attempt-*'),key=lambda p:int(p.name.split('-')[-1]))
    math_path=math_attempts[-1]/'evidence/math-review.json' if math_attempts else None
    math_review=load(math_path) if math_path and math_path.exists() else {}
    math_ok=math_review.get('result')=='PASS' and math_review.get('cases')==25 and math_review.get('answerComparisons')==50 and math_review.get('projectOracleUsed') is False
    if not math_ok:population_errors.append('independent exact math review: incomplete or failed')
    self_checks['exactMathReview']={'status':'PASS' if math_ok else 'FAIL','recipes':math_review.get('cases',0),'answerComparisons':math_review.get('answerComparisons',0),'projectOracleUsed':False}
    receipt={'schema':1,'buildId':manifest['buildId'],'sourceCommit':manifest['sourceCommit'],'sourceTreeHash':manifest['sourceTreeHash'],'buildSha256':manifest['buildSha256'],
             'developmentResult':acceptance['result'] if not population_errors else 'FAIL','populationErrors':population_errors,'populations':populations,
             'logicalTasks':len(acceptance['cases']),'failedTasks':[x for x in acceptance['cases'] if x['status'] not in ['PASS','POLICY_PASS']],
             'selfVerification':self_checks,
             'independentEngineering':'INDEPENDENT_PENDING','independentTeaching':'INDEPENDENT_PENDING','publicDeployment':False,
             'runId':os.environ.get('GITHUB_RUN_ID'),'executionCommit':os.environ.get('GITHUB_SHA')}
    write(merged/'ci-receipt.json',receipt)
    if os.environ.get('GITHUB_STEP_SUMMARY'):
        with open(os.environ['GITHUB_STEP_SUMMARY'],'a')as f:f.write('## RC70 candidate verification\n\n'+receipt['developmentResult']+'\n\n<details><summary>RC70_CI_RECEIPT_JSON</summary>\n\n```json\n'+json.dumps(receipt,ensure_ascii=False,indent=2)+'\n```\n\n</details>\n')
    print(json.dumps(receipt,ensure_ascii=False,indent=2))
    return code or (1 if population_errors else 0)

if __name__=='__main__':
    if sys.argv[1]=='collect':raise SystemExit(collect(pathlib.Path(sys.argv[2])))
    raise SystemExit(execute(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else None))
