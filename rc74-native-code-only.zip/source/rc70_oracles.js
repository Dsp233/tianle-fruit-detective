'use strict';
// Independent enumerations use givens, never the production answer or steps.
function integrated(task){
 const c=task.competition,m=c.math,v=c.extension.problemState.math,id=c.configurationId;
 if(id==='mean-admission'){
  const red=m.N*2/5,blue=m.N-red,total=red*m.low+blue*m.high,valid=[];
  for(let x=0;x<=m.cap;x++)if((total+x*m.score)/(m.N+x)>=m.target){let packages=0;while(packages*8<(m.N+x)*4)packages++;valid.push({x,cost:packages*18})}
  const variants=valid.filter(x=>x.x<=v.cap);return {answer:Math.min(...valid.map(x=>x.cost)),extension:variants.length?Math.min(...variants.map(x=>x.cost)):0};
 }
 if(id==='score-training'){
  const red=m.N*2/5,blue=m.N-red,score=(m.N*m.mean-blue*m.high)/red,needed=m.N*m.target-m.N*m.mean,rows=[];
  for(let g=0;g<=2;g++)for(let y=0;y+3*g<=red;y++){const gain=g*3*(70+(m.mean-72)-score)+y*(80+(m.mean-72)-score),cost=g*16+y*12;if(gain>=needed)rows.push({cost,people:g*3+y})}
  return {answer:Math.min(...rows.map(x=>x.cost)),extension:Math.min(...rows.filter(x=>x.cost<=v.budget).map(x=>x.people))};
 }
 if(id==='length-border'){
  const width=m.perimeter/5,length=m.perimeter*3/10;
  function cost(b){let cells=0;for(let y=0;y<width*2;y++)for(let x=0;x<length*2;x++)if(x<b*2||y<b*2||x>=length*2-b*2||y>=width*2-b*2)cells++;let packages=0;while(packages*10<cells)packages++;return packages*m.price}
  const possible=[];for(let b=1;2*b<width;b++)if(cost(b)<=v.budget)possible.push(b);
  return {answer:cost(m.border),extension:Math.max(...possible)};
 }
 const length=m.W*3/2,perimeter=2*(length+m.W),plans=[];
 for(let b=0;b<=Math.ceil(perimeter/10)+1;b++)for(let s=0;s<=Math.ceil(perimeter/2);s++)if((b*5+s)*2>=perimeter-m.gate)plans.push({cost:70*b+15*s,bought:5*b+s});
 const extra=[];for(let b=0;b<=Math.ceil(perimeter/10)+1;b++)for(let s=0;s<=Math.ceil(perimeter/2);s++)if((v.stock+b*5+s)*2>=perimeter)extra.push(70*b+15*s);
 return {answer:Math.min(...plans.map(x=>x.cost))+24,extension:Math.min(...extra)};
}
module.exports={integrated};
