'use strict';
const assert=require('assert'),fs=require('fs'),path=require('path'),{boot}=require('./test_support'),M=require('./competition_reviewed');
function load(familyId,configuration,seed=1,revision){
 const app=boot({},2000000000000,fs.readFileSync(path.join(__dirname,'../qa/index.html'),'utf8')),recipe=M.competitionReviewedRecipe(familyId,seed),row=app.value('window.AMC8_QA.families.find(r=>r.familyId==='+JSON.stringify(familyId)+')');
 const config=configuration||row.configuration,values={familyId,configuration:config,seed,generatorRevision:revision||(config!==row.configuration?4:recipe.generatorRevision)};
 app.run('window.AMC8_QA.loadCase('+JSON.stringify(values)+',true)');app.caseValues=values;return app;
}
function install(app,task,id='selection-fixture'){
 const item={view:'competition',code:task.id,taskId:task.id,contentVersion:task.contentVersion,recipe:task.competition.recipe,openedAt:2000000000000,passed:false,draft:null,feedback:null};
 app.run('saved.topicPractice.sourceIds=["original"];saved.topicPractice.selectedTopicIds=SKILL_DATA.units.map(u=>u.id);saved.topicPractice.session={mode:"competition-v2",id:'+JSON.stringify(id)+',topicIds:SKILL_DATA.units.map(u=>u.id),sourceIds:["original"],planSeed:1,total:10,cursor:0,items:['+JSON.stringify(item)+'],exhausted:false};topicOpenCurrent()');return item;
}
function solve(app){const t=app.value('taskNow()');if(t.competition.integrated||t.competition.family==='threeGroupBalance')app.inputCompetition('final',t.competition.answer);else app.click('competitionPick',{index:String(t.answer)});app.click('check');assert.equal(app.value('feedback.ok'),true)}
function report(name,rows,extra={}){
 const out=process.env.AMC8_RC70_EVIDENCE||path.join(__dirname,'../tmp/rc73/checks');fs.mkdirSync(out,{recursive:true});
 const value={schema:1,result:rows.some(r=>r.status!=='PASS')?'FAIL':'PASS',cases:rows.length,environment:'Node VM contracts; native browser and independent acceptance are separate',rows,...extra};
 fs.writeFileSync(path.join(out,name+'.json'),JSON.stringify(value,null,2)+'\n');console.log(value.result,name,rows.length,'cases');if(value.result!=='PASS')process.exitCode=1;return value;
}
function suite(){const rows=[];return {rows,test(id,fn){try{const actual=fn();rows.push({caseId:id,status:'PASS',actual})}catch(error){rows.push({caseId:id,status:'FAIL',error:error.stack});console.error(id,error.stack)}}}}
function configurations(){const rows=require('../docs/rc69-execution-manifest.json').configurations.map(c=>({familyId:c.familyId,configurationId:c.configurationId,recipe:{...c.rc68Recipe,...(c.familyId==='natural-weighted'?{generatorRevision:5}:{})}}));for(const f of M.COMPETITION_REVIEWED.filter(f=>f.integrated))for(const configurationId of f.configurations)rows.push({familyId:f.id,configurationId,recipe:{engine:3,familyId:f.id,configurationId,generatorRevision:5}});return rows}
module.exports={boot,M,assert,fs,path,load,install,solve,report,suite,configurations};
