'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),M=require('./competition_reviewed'),O=require('./rc68_oracles'),P=require('./problem_state'),Identity=require('./competition_identity'),C=require('./competition_content_contracts'),Skills=require('./skills.json'),Lessons=require('./curriculum.json');

async function feedbackVisible(page,selector,status){
 const message=page.locator(selector+'[data-answer-status="'+status+'"]');await message.waitFor({state:'visible'});
 const actual=await message.evaluate(el=>{const r=el.getBoundingClientRect();return {text:el.textContent,focused:document.activeElement===el,top:r.top,bottom:r.bottom,height:innerHeight,live:el.getAttribute('aria-live')}});
 assert(actual.focused,'Submission feedback receives focus');assert(actual.top>=-1&&actual.bottom<=actual.height+1,'Submission feedback is inside the viewport');assert.equal(actual.live,'polite');
 if(status==='needs_revision')assert(actual.text.includes('这次还没答对。'));
 return actual;
}

async function presentation(page,task,variation=false){
 const contract=C.resolve(task,variation?'variation':'main'),prompt=page.locator(variation?'[data-variation-prompt]':'.task-title');assert((await prompt.innerText()).includes(contract.promptText));
 const mainGivens=page.locator('.topic-question-work > [data-question-givens]'),variationGivens=page.locator('.competition-extension > [data-question-givens]');
 if(contract.givenText)assert.equal(await (variation?variationGivens:mainGivens).innerText(),contract.givenText);
 if(!['oppositeScale','chartAverage','natural-coordinateDistance'].includes(task.competition.recipe.familyId))return {prompt:contract.promptText,givens:contract.givenText};
 await page.locator('[data-action="'+(variation?'competitionReadExtension':'competitionRead')+'"]').click();
 const spoken=await page.evaluate(()=>window.__spoken.at(-1));assert(spoken&&spoken.length);
 const m=task.competition.math,family=task.competition.recipe.familyId;
 if(variation&&family==='oppositeScale')assert(spoken.includes(m.a+'分之'+m.b),'Variation speaks the actual scale before any hint');
 if(family==='chartAverage')m.counts.forEach((n,i)=>assert(spoken.includes('得 '+(2*(i+1))+' 分的有 '+n+' 人'),'Chart counts are included in narration'));
 if(variation&&family==='natural-coordinateDistance'){assert(spoken.includes('A等于左括号'));assert(spoken.includes('B等于左括号'));}
 return {prompt:contract.promptText,givens:contract.givenText,spoken};
}

async function saveFailure(page,out,name,error){
 await page.screenshot({path:path.join(out,name+'-failure.png'),fullPage:true}).catch(()=>{});
 fs.writeFileSync(path.join(out,name+'-failure.html'),await page.locator('#app').evaluate(el=>el.outerHTML).catch(()=>''));
 fs.writeFileSync(path.join(out,name+'-failure.json'),JSON.stringify({error:error.stack,url:page.url()},null,2)+'\n');
}

async function submit(page,task,expected,wrong=false){
 const free=task.competition.family==='threeGroupBalance'||task.competition.integrated;
 if(free)await page.locator('[data-competition-input="final"]').fill(wrong?'('+expected+')+1':expected);
 else{const index=task.options.findIndex(v=>P.equal(v,expected));assert(index>=0);await page.locator('[data-action="competitionPick"][data-index="'+(wrong?(index+1)%5:index)+'"]').click();}
 await page.locator('form[data-competition-form="main"] [data-action="check"]').click();
 return feedbackVisible(page,'.feedback',wrong?'needs_revision':'correct');
}

async function normalSelectionJourney(context,base,out,profile){
 const page=await context.newPage(),rows=[],seen=new Set();page.setDefaultTimeout(10000);
 try{
  await page.goto(base+'/qa/normal/',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>progressStore.getStatus()==='ready');
  const amc=page.locator('[data-action="sourceToggle"][data-code="AMC8"]'),original=page.locator('[data-action="sourceToggle"][data-code="original"]');
  if(await amc.getAttribute('aria-pressed')==='true')await amc.click();if(await original.getAttribute('aria-pressed')!=='true')await original.click();
  for(const unit of Skills.units)await page.locator('[data-action="topicSelect"][data-code="'+unit.id+'"]').click();
  await page.locator('.topic-start-actions [data-action="topicStart"]').click();
  for(let slot=0;slot<10;slot++){
   await page.locator('.competition-question').waitFor();let task=await page.evaluate(()=>taskNow());const key=Identity.key(task);assert(!seen.has(key),'Solved problem does not reappear inside a normal session');
   const expected=O.exactInput(O.oracle(task,M.COMPETITION_REVIEWED.find(f=>f.id===task.competition.recipe.familyId)).answer);
   if(profile===1)await page.locator('.competition-hints[data-scope-id="main"] > [data-action="competitionHint"]').click();
   if(profile===2)await submit(page,task,expected,true);
   if(profile===3){
    await page.locator('.competition-notes > summary').click();await page.locator('[data-competition-input="notes"]').fill('保留正常练习草稿-'+slot);
    if(slot===3){await page.locator('[data-action="topicSkip"]').click();await page.locator('[data-action="topicPrevious"]').click();assert.equal(await page.evaluate(()=>taskNow().id),task.id);}
    if(slot===2){await page.reload({waitUntil:'domcontentloaded'});await page.waitForFunction(()=>progressStore.getStatus()==='ready');await page.locator('[data-action="topicResume"]').click();assert.equal(await page.evaluate(()=>taskNow().id),task.id);assert.equal(await page.evaluate(()=>draft.work.notes),'保留正常练习草稿-'+slot);}
   }
   await submit(page,task,expected);seen.add(key);const record=await page.evaluate(()=>saved.competition.attempts.at(-1));assert.equal(record.correct,true);if(profile===1)assert.equal(record.hinted,true);
   rows.push({profile,slot:slot+1,recipe:task.competition.recipe,problemKey:key,status:'PASS',assisted:record.hinted,corrected:profile===2,notesAndRefresh:profile===3});
   if(slot===0){await page.screenshot({path:path.join(out,'rc74-normal-'+profile+'.png'),fullPage:true});fs.writeFileSync(path.join(out,'rc74-normal-'+profile+'.html'),await page.locator('#app').evaluate(el=>el.outerHTML));}
   await page.locator('.competition-actions [data-action="next"]').click();
  }
  await page.locator('.topic-summary').waitFor();await page.locator('.topic-summary [data-action="topicStart"]').click();const first=await page.evaluate(()=>taskNow());assert(!seen.has(Identity.key(first)),'A new normal session excludes every solved original');
  await page.reload({waitUntil:'domcontentloaded'});await page.waitForFunction(()=>progressStore.getStatus()==='ready');await page.locator('[data-action="topicResume"]').click();const restored=await page.evaluate(()=>taskNow());assert.equal(restored.id,first.id);assert(!seen.has(Identity.key(restored)));
  const result={profile,status:'PASS',rows,nextRoundFirst:restored.competition.recipe,solvedExclusionAfterReload:true};fs.writeFileSync(path.join(out,'normal-journey-'+profile+'.json'),JSON.stringify(result,null,2)+'\n');return result;
 }catch(error){await saveFailure(page,out,'rc74-normal-'+profile,error);throw error}finally{await page.close();}
}

async function curriculumJourney(browser,base,out,shard,shards){
 const context=await browser.newContext({viewport:{width:1280,height:800},locale:'zh-CN'});await context.addInitScript(()=>{window.__spoken=[];Object.defineProperty(window,'speechSynthesis',{value:{speak:u=>window.__spoken.push(u.text),cancel(){},pause(){},resume(){}},configurable:true});window.SpeechSynthesisUtterance=class{constructor(text){this.text=text}}});
 const page=await context.newPage();page.setDefaultTimeout(10000);const rows=[];let region=null;
 async function openRegion(unit){await page.locator('.brand[data-action="home"]').click();await page.locator('[data-action="knowledge"]').click();await page.locator('.forest [data-action="network"][data-code="'+unit+'"]').click();region=unit;}
 try{
  await page.goto(base+'/qa/normal/',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>progressStore.getStatus()==='ready');
  for(const skill of Skills.skills.filter((_,i)=>i%shards===shard)){
   if(region!==skill.unitId)await openRegion(skill.unitId);
   await page.locator('[data-action="networkSkill"][data-code="'+skill.id+'"]').click();await page.locator('[data-action="learn"][data-code="'+skill.id+'"]').click();
   for(const tab of ['definition','why','use']){await page.locator('[data-action="learnTab"][data-value="'+tab+'"]').click();assert.equal(await page.locator('.learning-copy').textContent(),Lessons.lessons[skill.id][tab]);await page.locator('[data-action="learnSpeak"][data-value="'+tab+'"]').click();assert.equal(await page.evaluate(()=>window.__spoken.at(-1)),Lessons.lessons[skill.id][tab]);}
   await page.locator('[data-action="learnCounter"]').click();assert((await page.locator('.learning-counter').innerText()).includes(Lessons.lessons[skill.id].counterexample));
   const practice=await page.evaluate(id=>({view:practiceFor(id).view,taskId:practiceFor(id).task.id}),skill.id);
   await page.locator('.learning-actions [data-action="'+practice.view+'"][data-code="'+skill.id+'"]').click();assert.equal(await page.evaluate(()=>view),practice.view);assert.equal(await page.evaluate(()=>playerTask().id),practice.taskId);assert(await page.locator('#app .task-title').first().isVisible());
   assert.equal(await page.evaluate(()=>saved.attempts.length),0,'Opening lessons and operations does not award mastery');
   rows.push({skillId:skill.id,unitId:skill.unitId,status:'PASS',definition:true,why:true,use:true,counterexample:true,narrationRequests:3,operationView:practice.view,operationTaskId:practice.taskId,masteryNotAwarded:true});
   if(skill.id.endsWith('.01')){await page.screenshot({path:path.join(out,'rc74-course-'+skill.id+'.png'),fullPage:true});fs.writeFileSync(path.join(out,'rc74-course-'+skill.id+'.html'),await page.locator('#app').evaluate(el=>el.outerHTML));}
   await openRegion(skill.unitId);
  }
  const result={shard,shards,status:'PASS',rows,limits:['Checks real browser course access, text, narration requests and operation entry; does not measure real-child understanding or speaker output']};fs.writeFileSync(path.join(out,'curriculum-native-'+shard+'.json'),JSON.stringify(result,null,2)+'\n');return result;
 }catch(error){await saveFailure(page,out,'rc74-curriculum-'+shard,error);throw error}finally{await context.close();}
}

module.exports={feedbackVisible,presentation,normalSelectionJourney,curriculumJourney};
