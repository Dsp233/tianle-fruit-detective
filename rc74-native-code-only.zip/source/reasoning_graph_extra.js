'use strict';
// Family-specific intermediate quantities; no published answer/solution parsing.
const ReasoningGraphExtra=((h)=>{
 const {competitionFraction:F}=h,sum=a=>a.reduce((s,v)=>s+v,0),fact=n=>n<2?1:n*fact(n-1),choose=(n,k)=>{let v=1;for(let i=1;i<=k;i++)v=v*(n-i+1)/i;return v},gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return a},num=s=>String(s).split('/').map(Number).reduce((a,b)=>a/b);
 const seq=(a,b,n)=>{const s=[a,b];while(s.length<n)s.push(s.at(-1)+s.at(-2));return s};
 function make(c,N,R){const m=c.math,id=c.problemState.familyId||c.family,p=m.params||m;let nodes,decisionIndex=0;const alternatives=[];
  const n=(id,q,a,u='',more={})=>N(id,q,a,u,more),target=(q,a,u='')=>n('target',q,a,u),D=(q,choices,correct)=>n('decision-'+(++decisionIndex),q,correct,'',{choices,hints:['题目限制了哪些条件？分别检查每一种说法。','用一个小例子检验你的选择，看看是否满足全部条件。']});
  switch(id){
  case 'fractionBackwards':nodes=[n('second-remainder','最后的数量占第一天余量几分之几？','2/3'),n('after-first','第一天结束还剩多少枚？',F(3*m.left,2),'枚'),target('再还原最初数量。',3*m.left,'枚')];break;
  case 'percentRoundTrip':{const up=m.start*(100+m.percent)/100,down=up*(100-m.percent)/100;nodes=[n('raised','第一次变化后，价格是多少？',up,'元'),D('第二次百分比作用于哪个价格？',['最初原价','第一次变化后的价格'],'第一次变化后的价格'),n('final-price','第二次变化后的价格是多少？',down,'元'),target('回到题目所求，与原价比较差多少？',m.start-down,'元')];break}
  case 'squareBorder':nodes=[n('outer-side','新增一圈后，外方阵边长增加到多少块？',m.n+2,'块'),n('all-cells','外方阵共多少块？',(m.n+2)**2,'块'),n('old-cells','原方阵共多少块？',m.n**2,'块'),target('移除原有部分，新增多少块？',4*m.n+4,'块')];break;
  case 'ratioEqualize':nodes=[n('difference-parts','两种原来相差几份？',m.b-m.a,'份'),n('one-part','用实际差额确定一份的数量。',m.unit,'个'),target('回到原来蓝球对应的份数，原有多少个蓝球？',m.b*m.unit,'个')];break;
  case 'packPrice':case 'mixedPacks':{let costs=[];if(id==='packPrice')for(let k=0;k<=Math.floor(m.count/3);k++)costs.push({label:k+'包，其余单买',cost:k*m.pack+(m.count-3*k)*m.single});else for(let a=0;4*a<=m.count;a++)for(let b=0;4*a+6*b<=m.count;b++)if(4*a+6*b===m.count)costs.push({label:a+'个4支装、'+b+'个6支装',cost:a*m.p+b*m.q});nodes=[D('这题对购买数量有什么要求？',['至少买够','必须恰好'],'必须恰好'),...costs.map((x,i)=>n('cost-'+i,`检查合法方案：${x.label}，费用多少？`,x.cost,'元')),target('完整比较合法方案，最少费用是多少？',Math.min(...costs.map(x=>x.cost)),'元')];break}
  case 'equalDistanceSpeed':{const d=2*m.speed;nodes=[D('往返的平均速度，需要用哪个总量作分母？',['两个速度相加','总时间'],'总时间'),n('out-time',`取单程 ${d} 千米作代表，去程需几小时？`,2,'小时'),n('back-time',`同样 ${d} 千米，回程需几小时？`,1,'小时'),target('两程总路程除以总时间，平均速度是多少？',F(4*m.speed,3),'千米/时')];break}
  case 'oppositeScale':nodes=[n('length-ratio','长度变化后的倍率是多少？',F(m.b,m.a)),D('面积保持不变时，宽的倍率应怎样改变？',['同向同倍率','使用倒数倍率'],'使用倒数倍率'),target('用宽的倍率求新的宽。',F(m.old*m.a,m.b))];break;
  case 'balanceCancel':nodes=[D('水平天平两边有相同盒子，可以怎样做？',['只移去一边的相同盒子','两边同时移去相同盒子'],'两边同时移去相同盒子'),n('extra-boxes','移除相同部分后，两边相差几个盒子？',1,'个'),target('留下的重量差对应单盒重量，是多少？',m.x,'克')];break;
  case 'tickets':{const total=m.adults*m.adult+(m.people-m.adults)*m.child;nodes=[n('baseline','若全部按儿童票计算，总价是多少？',m.people*m.child,'元'),n('difference','实际总价比这个基准多多少？',total-m.people*m.child,'元'),n('per-change','把一张儿童票换为成人票，增加多少钱？',m.adult-m.child,'元'),target('用差额确定成人票数量。',m.adults,'张')];break}
  case 'linearTable':nodes=[n('input-gap','两个已知输入相差多少？',2),n('output-gap','对应输出相差多少？',2*m.k),n('multiplier','固定乘数是多少？',m.k),n('addition','扣掉乘法部分，固定加数是多少？',m.b),target('将目标输入送入原规则。',m.k*m.target+m.b)];break;
  case 'divisibleDigits':{let candidates=[];for(let b=0;b<10;b++)for(let d of [0,5]){const x=1000*m.a+100*b+10*m.b+d;if(x%9===0)candidates.push(x)}nodes=[D('被5整除对个位有什么限制？',['只能0或5','只要数字和是5的倍数'],'只能0或5'),n('candidate-count','同时检查被9整除条件，合法四位数共有几个？',candidates.length),target('比较合法候选，最大的数是多少？',Math.max(...candidates))];break}
  case 'factorBalance':{const ds=[];for(let a=1;a*a<=m.product;a++)if(m.product%a===0)ds.push([a,m.product/a]);nodes=[n('pairs','交换顺序不算新对，合法正整数因数对有几对？',ds.length),...ds.map((x,i)=>n('sum-'+i,`检查因数对 ${x[0]} 与 ${x[1]}，和是多少？`,sum(x))),target('完整比较因数对，最小和是多少？',Math.min(...ds.map(sum)))];break}
  case 'bells':{const period=m.a*m.b/gcd(m.a,m.b);nodes=[n('joint-period','两铃的共同周期是多少分钟？',period,'分钟'),D('题目是否计入开始时刻？',['计入','不计入'],'不计入'),target('按题目结束边界，共同时响几次？',Math.floor(m.duration/period),'次')];break}
  case 'lastDigit':{const cycle=[],seen=new Set();let x=m.base%10;while(!seen.has(x)){cycle.push(x);seen.add(x);x=x*m.base%10}nodes=[n('cycle-size','从一次方开始，个位循环有几个位置？',cycle.length),n('position','将指数对齐到循环，从1计的位置是多少？',(m.exponent-1)%cycle.length+1),target('该位置对应的个位数字是多少？',cycle[(m.exponent-1)%cycle.length])];break}
  case 'outsideAngle':nodes=[n('other-sum','两底角合计多少度？',180-m.apex,'度'),n('base-angle','等腰使一个底角是多少度？',(180-m.apex)/2,'度'),target('沿外角与内角关系，所求外角是多少？',90+m.apex/2,'度')];break;
  case 'overlapSquares':case 'overlapProbability':{const area=(m.n-m.dx)*(m.n-m.dy),union=2*m.n*m.n-area;nodes=[n('overlap-width','交叠区域的宽是多少？',m.n-m.dx),n('overlap-height','交叠区域的高是多少？',m.n-m.dy),n('intersection','交叠面积是多少？',area),n('union','至少一张覆盖的不同面积是多少？',union),target(id==='overlapSquares'?'回到题目所求的覆盖面积。':'目标区域占等可能样本区域几分之几？',id==='overlapSquares'?union:F(area,union))];break}
  case 'circleRoute':nodes=[n('other-arc','另一方向的补弧有几个小段？',m.sectors-m.steps),target('比较两条弧，较短路程是多少？',Math.min(m.steps,m.sectors-m.steps)*m.unit,'米')];break;
  case 'similarAreaPerimeter':nodes=[n('area-ratio','题干给的对应面积倍率是多少？',F(m.b*m.b,m.a*m.a)),n('length-ratio','把面积比还原成对应长度比的倍率。',F(m.b,m.a)),target('对应周长也用这个倍率，所求周长是多少？',m.b*m.unit)];break;
  case 'ladderShift':nodes=[n('initial-height','原来的直角三角形高度是多少？',4*m.k,'米'),n('new-height','底端变化后，高度是多少？',3*m.k,'米'),target('梯顶高度减少多少？',m.k,'米')];break;
  case 'paintedCube':case 'cubeProbability':{const one=6*(m.n-2)**2,two=12*(m.n-2),all=m.n**3;nodes=[D('恰好两面涂色的小块位于哪里？',['棱上但不是角','整张面的所有小块'],'棱上但不是角'),n('one-edge','每条棱除去两角，还剩多少块？',m.n-2),n('all-edges','有多少条棱？',12),n('two-painted','恰好两面涂色共有多少块？',two),target(id==='paintedCube'?'回到所求小块数量。':'恰好两面涂色占全体小块的概率是多少？',id==='paintedCube'?two:F(two,all))];break}
  case 'adjacentLine':nodes=[D('必须相邻时，怎样先处理两位朋友？',['先作为一个对象','把两人视为固定顺序的一个对象'],'先作为一个对象'),n('outer-arrange','捆绑后共有几个对象排列？',m.n-1),n('order-count','两人内部有几种顺序？',2),target('外部排列与内部顺序组合，共有多少种？',2*fact(m.n-1),'种')];break;
  case 'restrictedTeam':nodes=[n('all-teams','先不加限制，选3人共有多少种？',choose(m.n,3)),n('invalid','同时选中两位指定朋友时，第三人有几种选法？',m.n-2),target('剔除违规小队，合法选法有多少？',choose(m.n,3)-(m.n-2))];break;
  case 'digitComplement':nodes=[n('all-strings','先不要求特殊数字，所有密码有多少个？',10**m.length),n('avoid','所有位置都避开目标数字，有多少个密码？',9**m.length),target('至少出现一次的数量是多少？',10**m.length-9**m.length)];break;
  case 'chartScale':nodes=[n('unit','已知人数与柱高对应，每格多少人？',m.unit,'人'),n('B-count','乙柱对应的实际人数是多少？',m.b*m.unit,'人'),target('所求两柱人数合计是多少？',(m.b+m.c)*m.unit,'人')];break;
  case 'missingAverage':nodes=[n('whole-total','原来所有数的总和是多少？',m.count*m.mean),n('remaining-total','删去后余下数的总和是多少？',(m.count-1)*m.other),target('比较两种总和，被删掉的数是多少？',m.count*m.mean-(m.count-1)*m.other)];break;
  case 'diceSum':{let good=0;for(let a=1;a<=m.faces;a++)for(let b=1;b<=m.faces;b++)if(a+b===m.target)good++;nodes=[D('等可能的结果是什么？',['有序点数对','点数和'],'有序点数对'),n('all-pairs','所有有序点数对有多少个？',m.faces**2),n('good-pairs','点数和符合目标的有序对有多少个？',good),target('符合条件的概率是多少？',F(good,m.faces**2))];break}
  case 'foldHoles':nodes=[n('inside-copies','每个内部孔展开后对应几个位置？',4),n('edge-copies','每个单折痕上的孔对应几个位置？',2),n('center-copies','双折痕交点上的孔对应几个位置？',1),target('按位置分类合计总孔数。',4*m.interior+2*m.edge+m.center)];break;
  case 'checkerDomino':nodes=[n('remaining','去掉两格后剩几格？',m.w*m.h-2),D('一块骨牌会覆盖怎样的颜色？',['一个黑格和一个白格','任意两个同色格'],'一个黑格和一个白格'),n('limiting-color','去掉两个同色角后，较少的颜色还有几格？',m.w*m.h/2-2),target('用颜色上界并构造摆法，最多放几块？',m.w*m.h/2-2)];break;
  case 'natural-weighted':case 'natural-fractionWeighted':{const red=m.red*m.redScore,blue=m.blue*m.blueScore;nodes=[n('people-parts','代表组共有多少人数份？',m.red+m.blue,'份'),n('red-total','红队代表部分共得多少分？',F(red,m.den),'分'),n('blue-total','蓝队代表部分共得多少分？',F(blue,m.den),'分'),target('合计总分再按人数均分，平均是多少？',F(red+blue,m.den*(m.red+m.blue)),'分')];break}
  case 'natural-tiles':nodes=[n('largest-side','最大正方形规格需同时整除两边，边长是多少？',gcd(m.w,m.h)),n('along-width','一边有几块？',m.w/gcd(m.w,m.h)),n('along-height','另一边有几块？',m.h/gcd(m.w,m.h)),target('合计铺多少块？',m.w*m.h/gcd(m.w,m.h)**2)];break;
  case 'natural-pairChance':nodes=[n('all-pairs','所有具体球对共有多少？',choose(m.red+m.blue,2)),n('red-pairs','两球都是红色有多少对？',choose(m.red,2)),target('两球都是红色的概率是多少？',F(choose(m.red,2),choose(m.red+m.blue,2)))];break;
  case 'natural-unionChance':case 'natural-complementChance':{const union=m.red+m.blue-m.both;nodes=[n('attendance','两组人数直接相加，得到的参加次数是多少？',m.red+m.blue,'人次'),n('union','移除重复部分，至少参加一组的不同人数是多少？',union,'人'),...(id==='natural-complementChance'?[n('outside','都没参加的人数是多少？',m.total-union,'人')]:[]),target('目标人数占全体几分之几？',F(id==='natural-unionChance'?union:m.total-union,m.total))];break}
  case 'natural-offers':nodes=[n('shop-A','甲店整单费用是多少？',F(3*m.price*m.count,4)+'','元',{acceptedExpressions:[String(3*m.price*m.count/4+m.fee)],answer:String(3*m.price*m.count/4+m.fee)}),n('shop-B','乙店整单费用是多少？',(m.price-1)*m.count,'元'),target('比较两店整单费用之差。',Math.abs(3*m.price*m.count/4+m.fee-(m.price-1)*m.count),'元')];break;
  case 'natural-angleRatio':nodes=[n('parts','三角形内角比例共几份？',sum(m.ratios)),n('one-angle-part','一份多少度？',F(180,sum(m.ratios)),'度'),target('最大的内角是多少？',F(180*Math.max(...m.ratios),sum(m.ratios)),'度')];break;
  case 'natural-digitCount':case 'natural-distinctDigitCount':{const countA=m.digits.map(a=>m.digits.filter(b=>(!m.distinct||a!==b)&&(a+b)%3===0).length);nodes=[D('十位和个位是否有顺序？',['有顺序，交换可能产生新数','交换一律合为同一数'],'有顺序，交换可能产生新数'),...countA.map((v,i)=>n('first-'+i,`十位为 ${m.digits[i]} 时，符合全部限制的个位有几个？`,v)),target('按十位分组不重不漏，总共有几个？',sum(countA))];break}
  case 'natural-coordinateDistance':nodes=[n('x-gap','横坐标相差多少？',Math.abs(m.dx)),n('y-gap','纵坐标相差多少？',Math.abs(m.dy)),D('题目允许的距离是哪个？',['直线距离','只沿水平竖直网格'],'直线距离'),target('用直角边求直线距离。',Math.hypot(m.dx,m.dy))];break;
  case 'routeProbability':{const all=choose(m.w+m.h,m.w),through=choose(m.x+m.y,m.x)*choose(m.w+m.h-m.x-m.y,m.w-m.x);nodes=[D('题目怎样随机选路线？',['完整路线等可能','每个岔口单独等可能'],'完整路线等可能'),n('all-routes','所有最短路线有多少条？',all),n('allowed-routes','避开P的最短路线有多少条？',all-through),target('合法路线占全体路线的概率是多少？',F(all-through,all))];break}
  case 'ratioUnion':{const total=(m.a+m.b)*m.unit-m.both;nodes=[n('attendance','把不同人数还原成两组参加次数，合计多少？',total+m.both),n('parts','组人数比例共有几份？',m.a+m.b),n('part-value','每份实际对应多少人？',m.unit),n('B-total','球类组全部有多少人？',m.b*m.unit,'人'),target('从球类组移除同时参加棋类组的人，只参加球类组的有多少人？',m.b*m.unit-m.both,'人')];break}
  case 'chartAverage':{const count=sum(m.counts),total=m.counts[0]*2+m.counts[1]*4+m.counts[2]*6;nodes=[n('count','图中所有人数合计是多少？',count,'人'),n('score-total','每档分数乘人数后，总分是多少？',total,'分'),target('按全体人数平均，结果是多少？',F(total,count),'分')];break}
  case 'parityPermutations':{const even=Math.floor(m.n/2),odd=m.n-even;nodes=[n('odd-count','奇数有几个？',odd),n('gaps','安排奇数后，可放偶数的空隙有几个？',odd+1),n('gap-selection','从这些空隙选位置，有几种？',choose(odd+1,even)),target('再安排不同数字的顺序，共有多少种？',choose(odd+1,even)*fact(odd)*fact(even))];break}
  case 'recurrenceRemainders':{nodes=[D('要验证余数递推的周期，应该追踪什么状态？',['单个余数','相邻两个余数'],'相邻两个余数'),n('pair-period','从初始余数对返回同一对，周期有几项？',8),n('whole-cycles','目标项数中有几个完整周期？',Math.floor(m.n/8)),n('tail-size','周期后还有几项？',m.n%8),target('按完整周期与尾段累加余数，合计是多少？',(()=>{let x=1,y=1,s=2;for(let i=2;i<m.n;i++){[x,y]=[y,(x+y)%3];s+=y}return s})())];break}
  case 'digitInsert':{const values=[100*m.d+10*m.a+m.b,100*m.a+10*m.d+m.b,100*m.a+10*m.b+m.d];nodes=[n('positions','保留原数字顺序，可以插入几个位置？',3),target('按位值比较合法数，最大是多少？',Math.max(...values))];break}
  case 'numberAppend':nodes=[n('coefficient','末尾添一位后，原数被放大几倍？',10),n('net-factor','与原数比较差额，原数还剩几倍？',9),target('从已知差额移除末位数字，再反求原数。',m.n)];break;
  case 'pairedSum':nodes=[n('pair-total','首尾一对的和是多少？',m.n+1),target('两份数列配对后再还原一份，总和是多少？',m.n*(m.n+1)/2)];break;
  case 'telescopingDifferences':nodes=[D('相邻差合计时，中间项怎样出现？',['各出现一次相加','一正一负可以抵消'],'一正一负可以抵消'),n('first','保留下来的起点是多少？',m.start),n('last','保留下来的终点是多少？',m.start+m.n*m.step),target('由两个端点确定差的总和。',m.n*m.step)];break;
  case 'neighborProducts':nodes=[n('square','中间数的平方是多少？',m.n**2),n('neighbors','两个相邻数的乘积是多少？',(m.n-1)*(m.n+1)),target('比较这两种乘积，差是多少？',1)];break;
  case 'fractionDifferentWholes':nodes=[n('first-part','甲盒取出的量是多少？',m.a/4),n('second-part','乙盒取出的量是多少？',m.b/3),target('各自整体下的取出量合计是多少？',m.a/4+m.b/3)];break;
  case 'fractionSharedRemainder':{const remaining=5*m.unit+5*m.add/8,afterSecond=remaining*8/5,afterFirst=afterSecond-m.add;nodes=[n('after-second','由最后余量还原第二次操作前的量。',afterSecond),n('before-return','把放回的数量移除，第一次操作后剩多少？',afterFirst),target('再按第一次所用整体还原最初数量。',afterFirst*3/2)];break}
  case 'discountOrder':nodes=[D('题目指定的操作顺序是什么？',['先折扣，再用券','先用券，再折扣'],'先折扣，再用券'),n('discounted','第一步后价格是多少？',m.price*(100-m.p)/100,'元'),target('执行第二步后，实际价格是多少？',m.price*(100-m.p)/100-m.q,'元')];break;
  case 'percentRestore':nodes=[n('new-base','取原价100，变化后价格是多少？',100+m.p),n('difference','需要减少多少价格份？',m.p),target('这个差占当前基准的百分之几？填写精确百分数前的数。',F(100*m.p,100+m.p))];break;
  case 'squareBounds':nodes=[n('lower-square','找到不超过被开方数的最近平方，是多少？',m.k**2),n('upper-square','紧接着的下一个整数平方是多少？',(m.k+1)**2),target('回到目标，左侧最近整数是多少？',m.k)];break;
  case 'ratioTotal':nodes=[n('parts','总量对应几份？',m.a+m.b),n('one-part','一份的实际数量是多少？',m.u),target('所求颜色对应的实际数量是多少？',m.a*m.u)];break;
  case 'linkedRatios':{const green=m.b*m.d*m.u,blue=m.b*m.c*m.u,red=m.a*m.c*m.u;nodes=[n('green','题干给定的绿色实际数量是多少？',green),n('blue','从蓝绿比例还原同一个蓝色数量。',blue),n('red','再从红蓝比例还原红色数量。',red),target('三色总量是多少？',red+blue+green)];break}
  case 'unitConversion':nodes=[n('millilitres','把总容量写成毫升，是多少？',1000*m.liters,'毫升'),target('用相同单位求完整杯数。',1000*m.liters/m.cup,'杯')];break;
  case 'jointWork':nodes=[n('rate-total','两人同时做，每分钟共完成多少？',m.a+m.b),n('work-total','题目要求的工作总量是多少？',(m.a+m.b)*m.t),target('工作总量除以共同速度，需要几分钟？',m.t,'分钟')];break;
  case 'mapScale':nodes=[n('same-length-factor','两地图表示同一实际长度，图上长度倍率是多少？',m.k),target('目标地图上的长度是多少？',m.a*m.k,'厘米')];break;
  case 'scaleAreaReverse':nodes=[n('net-length','两次长度变化合在一起，净倍率是多少？',F(m.k,m.s)),n('net-area','对应的面积净倍率是多少？',F(m.k**2,m.s**2)),target('用最后面积与净倍率反求原面积。',m.old)];break;
  case 'ageDifference':nodes=[n('gap','题干给出或能得到的年龄差是多少？',m.parent-m.child,'岁'),n('past-child','过去孩子的年龄是多少？',(m.parent-m.child)/2,'岁'),target('沿时间线得到现在孩子年龄。',m.child,'岁')];break;
  case 'repeatedMachine':{const after=m.x*m.a+m.b;nodes=[n('undo-final-add','最终输出先移除最后的固定加数，剩多少？',after*m.a),n('undo-second','从最终输出逆推第二次操作前的数。',after),target('再逆推第一次操作前，原输入是多少？',m.x)];break}
  case 'twoCoins':nodes=[n('baseline','如果所有硬币都是1元，合计多少元？',m.n,'元'),n('excess','实际钱数比基准多多少元？',m.twos,'元'),target('每换一枚2元币多1元，2元币有多少枚？',m.twos,'枚')];break;
  case 'stampConstraint':{const plans=[];for(let a=1;3*a<m.total;a++)if((m.total-3*a)%5===0&&(m.total-3*a)/5>=1)plans.push([a,(m.total-3*a)/5]);nodes=[D('每种邮票的数量有什么边界？',['每种至少一张','每种允许零张'],'每种至少一张'),n('possible-three','3元邮票最多有几张仍能留够一张5元？',Math.floor((m.total-5)/3)),target('固定3元张数，检查余款能否买整数张5元邮票，合法方案有几种？',plans.length)];break}
  case 'recurrenceForward':case 'recurrenceTotal':{const a=seq(m.a,m.b,m.n);if(id==='recurrenceForward'){nodes=[D('每个新项由哪两个数决定？',['紧邻的前两项','最初的固定两项'],'紧邻的前两项'),target('追踪项号，题目问的第 '+m.n+' 项是多少？',a.at(-1))];break}nodes=a.slice(2).map((v,i)=>n('term-'+(i+3),`按照相邻两项规则求第 ${i+3} 项。`,v));nodes.push(target(id==='recurrenceForward'?'回到题目问的项，是多少？':'将实际项按目标区间累加，是多少？',id==='recurrenceForward'?a.at(-1):sum(a)));break}
  case 'machineMeeting':nodes=[n('rate-gap','同一输入每增加1，两机输出差增加多少？',m.c-m.a),n('constant-gap','两机固定加数相差多少？',m.d-m.b),target('让输出相等，输入应是多少？',m.x)];break;
  case 'machineOrder':{const ab=(m.x*m.a+m.b)*m.c+m.d,ba=(m.x*m.c+m.d)*m.a+m.b;nodes=[n('AB','先甲后乙，完整输出是多少？',ab),n('BA','先乙后甲，完整输出是多少？',ba),target('两种顺序的输出差是多少？',Math.abs(ab-ba))];break}
  case 'digitDivisor':{const counts=[];for(let u=1;u<=9;u++)if((10*m.tens+u)%u===0)counts.push(u);nodes=[D('个位为0可以作除数吗？',['可以','不可以'],'不可以'),...Array.from({length:9},(_,i)=>n('divisible-'+(i+1),`个位为 ${i+1} 的两位数符合吗？填1表示符合，0表示不符合。`,Number((10*m.tens+i+1)%(i+1)===0))),target('合计有几个合法数？',counts.length)];break}
  case 'divisibleEleven':{const valid=[];for(let b=0;b<10;b++)for(let d of [0,5]){const x=1000*m.a+100*b+10*m.c+d;if(x%11===0)valid.push(x)}nodes=[D('被5整除的个位只能是什么？',['0或5','2或5'],'0或5'),n('candidate-count','同时核对11整除条件，合法数有几个？',valid.length),target('合法列表中最大四位数是多少？',Math.max(...valid))];break}
  case 'threeDivisors':{const squares=[];for(let p=2;p*p<=m.limit;p++){let prime=true;for(let d=2;d*d<=p;d++)if(p%d===0)prime=false;if(prime)squares.push(p*p)}nodes=[D('恰好三个正因数，应该是哪种结构？',['一个质数的平方','任意完全平方数'],'一个质数的平方'),n('prime-limit','质数底数可以检查到哪个整数？',Math.floor(Math.sqrt(m.limit))),target('在目标区间逐个检查，符合的数有几个？',squares.length)];break}
  case 'divisorPowers':nodes=[n('two-exponents','2的指数有几种合法取值？',m.a+1),n('three-exponents','3的指数有几种合法取值？',m.b+1),target('每个因数由两个指数确定，合计有几个？',(m.a+1)*(m.b+1))];break;
  case 'equalBags':nodes=[D('要让两色都用完且每袋规格相同，袋数必须满足什么？',['只要是其中一种数量的因数','同时整除两种数量'],'同时整除两种数量'),n('common-divisor','两种数量的最大公因数是多少？',gcd(m.a,m.b)),target('回到目标，最多能分几袋？',gcd(m.a,m.b),'袋')];break;
  case 'offsetBells':{let t=1;while(t%m.a||(t<m.offset||(t-m.offset)%m.b))t++;nodes=[D('两铃开始时刻不同，直接取共同周期就是第一次吗？',['是','不是，需要保留偏移'],'不是，需要保留偏移'),n('offset','两铃的起点偏移是多少分钟？',m.offset,'分钟'),target('检查两条时间线，第一次同时响在第几分钟？',t,'分钟')];break}
  case 'cyclicPosition':nodes=[n('remainder','走完完整圈后，还剩几步？',m.steps%m.size),target('从实际起点按指定方向数余步，停在哪个位置？',(m.start-1+m.steps)%m.size+1)];break;
  case 'repeatedOnes':{let v=0;nodes=[];for(let i=1;i<=Math.min(m.n,6);i++){v=(10*v+1)%7;nodes.push(n('remainder-'+i,`末尾再添1后，第 ${i} 个全1数除以7的余数是多少？`,v))}nodes.push(target('用余数转换或周期继续到目标位数，最终余数是多少？',Number(BigInt('1'.repeat(m.n))%7n)));break}
  case 'rectangleDiagonalArea':nodes=[n('rectangle-area','整个长方形的面积是多少？',m.w*m.h),target('对角线分成相等两部分，所求三角形面积是多少？',m.w*m.h/2)];break;
  case 'angleMarks':nodes=[n('one-angle','完整一圈被等分后，每段多少度？',F(360,m.marks),'度'),target('目标跨过这些等角段，角度是多少？',F(360*m.step,m.marks),'度')];break;
  case 'polygonTurn':nodes=[D('这里追踪的是绕一周的转角，还是各个内角？',['绕一周的转角','各个内角'],'绕一周的转角'),n('turn-total','绕多边形走一整圈，外转角合计多少度？',360,'度'),target('等分到每个顶点，单个外转角多少度？',F(360,m.n),'度')];break;
  case 'lShapeArea':nodes=[n('outer-area','补成大长方形，面积是多少？',m.w*m.h),n('missing-area','需要移除的缺口面积是多少？',m.a*m.b),target('阴影L形面积是多少？',m.w*m.h-m.a*m.b)];break;
  case 'crossArea':nodes=[n('vertical','竖条面积是多少？',m.a*m.h),n('horizontal','横条面积是多少？',m.b*m.w),n('intersection','两条重叠面积是多少？',m.a*m.b),target('两条合并后不同覆盖面积是多少？',m.a*m.h+m.b*m.w-m.a*m.b)];break;
  case 'semicircleBoundary':nodes=[n('half-arc','半圆弧长是多少？',m.circumference/2),n('diameter','属于外周的直线直径多长？',2*m.radius),target('弧与直边合计，周长是多少？',m.circumference/2+2*m.radius)];break;
  case 'circleRingRatio':nodes=[n('inner-squared','小圆面积中的半径平方是多少？',m.r1**2),n('outer-squared','大圆面积中的半径平方是多少？',m.r2**2),target('扣掉小圆后，圆环占大圆面积几分之几？',F(m.r2**2-m.r1**2,m.r2**2))];break;
  case 'shadowSimilarity':nodes=[n('small-ratio','已知杆的杆高与影长之比是多少？','1/2'),target('同一时刻同一倍率，未知杆高是多少？',m.b*m.unit)];break;
  case 'parallelTriangle':nodes=[n('small-area-ratio','对应长度比平方后，小三角形占整体面积几分之几？',F(m.k**2,m.n**2)),n('small-area','小三角形面积是多少？',F(m.area*m.k**2,m.n**2)),target('整体扣掉小三角形，剩下面积是多少？',F(m.area*(m.n**2-m.k**2),m.n**2))];break;
  case 'coordinateHorizontal':nodes=[D('两点纵坐标相同，距离由什么决定？',['横坐标的差的绝对值','横坐标相加'],'横坐标的差的绝对值'),target('两点距离是多少？',Math.abs(m.b-m.a))];break;
  case 'hypotenuseMidpoint':nodes=[n('hypotenuse','直角三角形斜边长是多少？',5*m.k),D('M在哪条边的中点？',['斜边','较长直角边'],'斜边'),target('利用斜边中点关系，目标长度是多少？',F(5*m.k,2))];break;
  case 'cubeSteps':nodes=[n('first-last','第一列与最后一列合计多少块？',m.n+1),target('按列高1到目标列数合计，小块共多少？',m.n*(m.n+1)/2)];break;
  case 'setOutside':nodes=[n('attendance','先相加两组人数，共记录多少次参加？',m.a+m.b,'人次'),n('union','至少参加一组的不同人数是多少？',m.a+m.b-m.both,'人'),target('从全体移除这些人，都没参加的人数是多少？',m.total-m.a-m.b+m.both,'人')];break;
  case 'menuBranches':nodes=[D('米饭配菜与面是怎样的分支？',['两种都必须选','互斥二选一'],'互斥二选一'),n('rice-meals','米饭与菜能搭配多少种午餐？',m.rice*m.dish),n('noodle-meals','面这一分支有多少种？',m.noodle),target('合并互斥分支，共多少种午餐？',m.rice*m.dish+m.noodle)];break;
  case 'binaryNoNeighbors':{const ways=[1,2];for(let i=2;i<=m.n;i++)ways[i]=ways[i-1]+ways[i-2];nodes=[D('最后一盏亮时，倒数第二盏必须怎样？',['亮','灭'],'灭'),n('shorter','最后一盏灭时，前面还有多少种合法安排？',ways[m.n-1]),n('two-shorter','最后一盏亮且前一盏灭时，前面还有多少种？',ways[m.n-2]),target('两个互斥分支合计，合法安排多少种？',ways[m.n])];break}
  case 'unorderedPairs':nodes=[n('ordered','先临时区分第一人与第二人，安排有多少种？',m.n*(m.n-1)),n('multiplicity','交换一对的顺序重复计了几次？',2),target('不分角色的不同搭档有多少对？',m.n*(m.n-1)/2)];break;
  case 'circularSeating':nodes=[D('圆桌旋转后相同，应如何确定参照？',['固定一人作参照','把旋转位置全算不同'],'固定一人作参照'),n('neighbor','固定一位朋友后，另一位可坐哪几种相邻位置？',2),n('remaining','剩余其他朋友有几种排列？',fact(m.n-2)),target('合并合法位置与其余安排，共多少种？',2*fact(m.n-2))];break;
  case 'differentDigits':nodes=[n('first','第一位有几种选择？',m.digits),n('second','不能重复，第二位剩几种选择？',m.digits-1),target('顺序不同算不同，合法组合多少种？',m.digits*(m.digits-1))];break;
  case 'allThreeColors':nodes=[n('all-colorings','先不限制三色出现，所有安排有多少种？',3**m.n),n('avoid-one','缺少一种指定颜色有多少种安排？',2**m.n),n('pure-colorings','只用一种颜色的安排有多少种？',3),target('用容斥修正重复排除，三色全出现有多少种？',3**m.n-3*2**m.n+3)];break;
  case 'truncatedBars':nodes=[n('A','把轴起点与刻度算入，甲实际多少人？',m.base+m.step*m.a,'人'),n('B','乙实际多少人？',m.base+m.step*m.b,'人'),target('回到题目所求总人数。',2*m.base+m.step*(m.a+m.b),'人')];break;
  case 'cumulativeChart':nodes=[D('累计柱表示什么？',['包含当前档和此前所有档','只表示当前档'],'包含当前档和此前所有档'),n('up-to-one','截至1分共有多少人？',m.a,'人'),n('up-to-three','截至3分共有多少人？',m.a+m.b+m.c,'人'),target('差额对应所求两档，共多少人？',m.b+m.c,'人')];break;
  case 'medianSort':nodes=[n('middle-position','5个数排序后，中间在第几个位置？',3),target('按大小排序，该位置的数是多少？',m.start+2*m.gap)];break;
  case 'spinnerLabels':nodes=[n('sample-size','所有等面积扇区共有几个？',m.a+m.b+m.c),n('target-size','符合目标标签的扇区共有几个？',m.a+m.b),target('符合条件的概率是多少？',F(m.a+m.b,m.a+m.b+m.c))];break;
  case 'conditionalBalls':{const all=choose(m.red+m.blue,2),rr=choose(m.red,2),bb=choose(m.blue,2);nodes=[n('all-pairs','不放回取两个球，具体球对共有多少？',all),n('exclude-blue','不满足“至少一个红球”的全蓝球对有多少？',bb),n('conditional-space','条件筛选后样本空间剩多少球对？',all-bb),n('both-red','两球全红的具体球对有多少？',rr),target('在新的样本空间中，所求概率是多少？',F(rr,all-bb))];break}
  case 'quarterTurn':nodes=[n('full-cycle','转多少次90度回到原方向？',4),n('remaining','扣去完整圈后还需转几次？',m.turns%4),target('从原方向按指定方向转，最终方向编号是多少？',(m.start+m.turns)%4)];break;
  case 'transformOrder':nodes=[D('题干的先后顺序是什么？',['先旋转再镜像','先镜像再旋转'],'先旋转再镜像'),n('after-rotation','先完成旋转，方向编号是多少？',(m.start+m.rot)%4),target('再完成镜像，最终编号是多少？',(4-(m.start+m.rot)%4)%4)];break;
  case 'lightSwitchParity':nodes=[n('presses','一共按了几次？',m.groups*m.per+m.extra),n('parity','按压次数是偶数还是奇数？填0偶数、1奇数。',(m.groups*m.per+m.extra)%2),target('按初始状态追踪，最后状态编号是多少？',(m.on+(m.groups*m.per+m.extra)%2)%2)];break;
  case 'ballReplacement':nodes=[D('每次替换后，白球数量的奇偶性怎样变化？',['保持','每次翻转'],'保持'),n('parity','最初白球数量的奇偶性，填0偶数、1奇数。',m.white%2),target('最后只剩一球，白球数是多少？',m.white%2)];break;
  case 'transferBetweenBoxes':nodes=[n('gap-parts','原来数量差对应几份？',m.b-m.a),n('gap-count','内部转移后相等，原差额多少块？',2*m.moved),n('one-part','一份对应多少块？',F(2*m.moved,m.b-m.a)),target('原来甲盒数量是多少？',F(2*m.a*m.moved,m.b-m.a))];break;
  case 'rectanglePointAreas':nodes=[n('opposite-total','左右相对三角形面积合计是多少？',m.left+m.right),D('同一长方形中，上下相对三角形的总面积怎样？',['等于左右合计','等于其中任意单个面积'],'等于左右合计'),target('扣去已知顶部，底部面积是多少？',m.left+m.right-m.top)];break;
  case 'worstCaseColors':{const maximum=sum(m.caps.map(v=>Math.min(v,m.k-1)));nodes=[...m.caps.map((v,i)=>n('avoid-'+i,`第 ${i+1} 种颜色最多取几个，仍没达到目标同色数量？`,Math.min(v,m.k-1))),n('maximum-failure','仍可能失败的最多抽取总数是多少？',maximum),target('再多取一个才能保证，最少取多少？',maximum+1)];break}
  case 'stagedClimb':nodes=[n('net-day','未到终点的一天一夜，净上升多少？',m.up-m.down),D('白天已经达到终点，还需要夜晚回退吗？',['需要','不需要'],'不需要'),n('before-final','最后白天之前，至少需要净上升到多高？',Math.max(0,m.height-m.up)),target('计算完整天夜后，再加最后白天，是第几天？',Math.ceil((m.height-m.up)/(m.up-m.down))+1)];break;
  case 'consecutiveRepresentations':{
   const maximum=Math.floor((Math.sqrt(8*m.total+1)-1)/2),checks=[];let found=0;
   for(let length=2;length<=maximum;length++){
    const start=(m.total-length*(length-1)/2)/length,valid=Number.isInteger(start)&&start>=1;if(valid)found++;
    checks.push(n('length-'+length,`检查 ${length} 项：若能写成连续正整数之和，填首项；否则填“不成立”。`,valid?start:'不成立','',{
     dependsOn:['maximum-length'],candidateLength:length,
     acceptedExpressions:valid?[String(start)]:['不成立','无解','不能'],recognizedExpressions:['不成立','无解','不能'],
     hints:['把首项暂记为一个未知数，连接项数、相邻差和总量。','还原首项后，分别检查它是否为整数、是否至少为1。'],
     errorCheck:'用你的首项列出这些连续数，核对总和；首项还须是正整数。'}));
   }
   nodes=[D('同一个总量的连续表示，哪两个量需要一起受约束？',['首项与项数','只看首项'],'首项与项数'),
    n('maximum-length','至少从1开始，连续项数最多检查到多少？',maximum),...checks,
    n('target','检查全部候选项数后，不同的正整数表示共有几种？',found,'',{dependsOn:checks.map(x=>x.id)})];break}
  case 'remainderProbability':{const cycles=Math.floor(m.count/m.mod),tail=m.count%m.mod,extra=m.wanted>0&&m.wanted<=tail?1:0,good=cycles+extra;nodes=[n('whole-cycles','从1开始的卡片中，有几个完整余数循环？',cycles),n('tail','完整循环后剩几张卡？',tail),n('tail-good','剩余卡片中符合目标余数的有几张？',extra),n('good','全体符合条件的卡片有几张？',good),target('每张等可能，符合目标的概率是多少？',F(good,m.count))];break}
  case 'rotatingColors':{const classes=new Set();for(let mask=0;mask<2**m.n;mask++){let bits=Array.from({length:m.n},(_,i)=>mask>>i&1);if(sum(bits)!==m.red)continue;classes.add(bits.map((_,i)=>[...bits.slice(i),...bits.slice(0,i)].join('')).sort()[0])}nodes=[D('旋转后相同的涂法如何计数？',['合为同一种','每个旋转位置都算新种'],'合为同一种'),n('fixed-count','暂时给每个位置编号，固定位置涂法有几种？',choose(m.n,m.red)),target('按实际旋转等价归类，不同涂法有几种？',classes.size)];break}
  case 'stepwiseRoute':{
   const paths=[];function walk(x,y,p,hit){hit=hit||x===m.x&&y===m.y;if(x===m.w&&y===m.h){paths.push({p,hit});return}const exits=Number(x<m.w)+Number(y<m.h);if(x<m.w)walk(x+1,y,p/exits,hit);if(y<m.h)walk(x,y+1,p/exits,hit)}walk(0,0,1,false);
   const count=paths.filter(x=>x.hit).length,prob=sum(paths.filter(x=>x.hit).map(x=>x.p));
   nodes=[D('题目随机的是哪个对象？',['每个岔口的合法方向','完整路线'],'每个岔口的合法方向'),n('route-count','经过指定点的完整路线有几条？',count),D('边界只剩一个方向时，概率应怎样分配？',['继续乘1/2','沿唯一方向的概率为1'],'沿唯一方向的概率为1'),target('逐条相乘再合并经过指定点的事件，概率是多少？',prob)];
   const values=Array.from({length:m.y+1},()=>Array(m.x+1).fill(0)),arrivalId=(x,y)=>'arrival-'+x+'-'+y;
   const dp=[n('sampling-rule','本题在哪一步作等概率选择？','每个岔口的合法方向','',{dependsOn:[],choices:['每个岔口的合法方向','完整路线']}),
    n('boundary-rule','只有一个合法出口的点，沿它前进的概率是多少？',1,'',{dependsOn:[]})];
   for(let y=0;y<=m.y;y++)for(let x=0;x<=m.x;x++){
    const deps=['sampling-rule','boundary-rule'];let value=x+y===0?1:0;
    if(x){value+=values[y][x-1]/(Number(x-1<m.w)+Number(y<m.h));deps.push(arrivalId(x-1,y))}
    if(y){value+=values[y-1][x]/(Number(x<m.w)+Number(y-1<m.h));deps.push(arrivalId(x,y-1))}
    values[y][x]=value;
    dp.push(n(arrivalId(x,y),`到达点 (${x},${y}) 的概率是多少？`,value,'',{dependsOn:deps,
     hints:['哪些相邻点能走到这里？从各点传来的概率要按它的合法出口分配。','到达这里的不同最后一步互斥；合并左边和下边传来的概率。'],
     errorCheck:'逐个检查入口：概率由前一个点的出口数决定；不要把路线条数当等可能概率。'}));
   }
   dp.push(n('target','读出到达P的概率，回到题目所求。',values[m.y][m.x],'',{dependsOn:[arrivalId(m.x,m.y)]}));
   alternatives.push(R('probability-flow','把到达概率沿合法方向传递',dp));break}
  case 'rule-join-open':case 'rule-join-closed':case 'rule-join-piece':{const joins=id==='rule-join-closed'?p.n:p.n-1;nodes=[n('joins','根据是否首尾相接，共有几个连接处？',joins),n('overlap-total','这些连接处合计扣去多少长度？',joins*p.lap,'厘米'),target(id==='rule-join-piece'?'补回总重叠后，反求每段长度。':'从各段总长扣去重叠，连接后总长是多少？',id==='rule-join-piece'?(p.total+joins*p.lap)/p.n:p.n*p.piece-joins*p.lap,'厘米')];break}
  case 'rule-posts-both':case 'rule-posts-neither':nodes=[n('intervals','总距离能分成多少个完整间隔？',p.distance/p.gap),D('题目的两个端点如何计入？',['两端都计入','两端都不计入'],id==='rule-posts-both'?'两端都计入':'两端都不计入'),target('把间隔与标记对应，所求标记有几个？',p.distance/p.gap+(id==='rule-posts-both'?1:-1))];break;
  case 'rule-weighted-mean':nodes=[n('count-parts','总人数对应几份？',p.a+p.b),n('A-score','甲代表组的总分是多少？',p.a*p.low,'分'),n('B-score','乙代表组的总分是多少？',p.b*p.high,'分'),target('按人数平均，结果是多少？',F(p.a*p.low+p.b*p.high,p.a+p.b),'分')];break;
  case 'rule-weighted-score':{const [a,d=1]=String(p.mean).split('/').map(Number),total=a*(p.a+p.b),left=total-p.b*p.high*d;nodes=[n('total-score','用人数份与平均数还原代表组总分。',F(total,d),'分'),n('B-score','乙代表组总分是多少？',p.b*p.high,'分'),n('A-total','扣去乙，甲代表组总分是多少？',F(left,d),'分'),target('均分到甲的人数份，每人分数是多少？',F(left,d*p.a),'分')];break}
  case 'rule-ratio-length':nodes=[n('half','一长加一宽对应多少米？',p.perimeter/2,'米'),n('parts','长加宽共有几份？',p.a+p.b),n('one','一份是多少米？',p.perimeter/2/(p.a+p.b),'米'),target('所求长是多少米？',p.perimeter/2/(p.a+p.b)*p.b,'米')];break;
  case 'rule-ratio-perimeter':nodes=[n('one','已知宽对应的单位份是多少米？',p.width/p.a,'米'),n('length','长是多少米？',p.width/p.a*p.b,'米'),target('按两长两宽合计一周，周长是多少？',2*p.width/p.a*(p.a+p.b),'米')];break;
  case 'rule-fraction-reverse':{const afterFirst=F(p.left*p.d2,p.d2-1),start=F(p.left*p.d1*p.d2,(p.d1-1)*(p.d2-1));nodes=[D('第二次分数以什么为整体？',['原量','第一次余量'],'第一次余量'),n('after-first','由最后余量还原第一次余量。',afterFirst),target('再按第一次比例还原原量。',start)];break}
  case 'rule-fraction-original':{const first=F(p.start,p.d1),second=F(p.start,p.d2);nodes=[D('两次分数所用的整体是否相同？',['相同原量','第二次用余量'],'相同原量'),n('first-use','第一次用掉多少？',first),n('second-use','第二次用掉多少？',second),target('原量移除两次用量，最后剩多少？',F(p.start*(p.d1*p.d2-p.d1-p.d2),p.d1*p.d2))];break}
  case 'rule-packs-exact':{const costs=[];for(let k=0;k<=Math.floor(p.count/p.size);k++)costs.push(k*p.pack+(p.count-k*p.size)*p.single);nodes=[D('包装能否拆开？',['能拆','整包不能拆'],'整包不能拆'),...costs.map((v,k)=>n('cost-'+k,`买 ${k} 包，其余单买恰好满足数量，费用多少？`,v,'元')),target('在全部合法方案中比较最低费用。',Math.min(...costs),'元')];break}
  // Held-out content adapters added after functional interface freeze f0f013a.
  case 'reverseDigits':{const total=m.a+m.b,gap=m.a-m.b;nodes=[n('digit-gap','交换后的位值差由每份9产生，十位与个位数字相差多少？',gap),n('smaller-digit','结合数字和与数字差，较小的个位数字是多少？',(total-gap)/2),n('larger-digit','较大的十位数字是多少？',(total+gap)/2),target('按原来的位值合成两位数。',10*m.a+m.b)];break}
  case 'riverTravel':nodes=[n('down-speed','顺流时船与水同向，实际速度是多少？',m.v+m.c,'千米/时'),n('up-speed','逆流时船与水反向，实际速度是多少？',m.v-m.c,'千米/时'),n('down-time','顺流这段需要多少小时？',F(m.distance,m.v+m.c),'小时'),n('up-time','逆流这段需要多少小时？',F(m.distance,m.v-m.c),'小时'),target('两段实际时间合计多少小时？',F(2*m.v*m.distance,m.v*m.v-m.c*m.c),'小时')];break;
  case 'threeSetExactlyTwo':nodes=[n('only-AB','甲乙交集移除三组全参加的人，恰好甲乙多少人？',m.ab-m.triple,'人'),n('only-AC','甲丙交集移除三组全参加的人，恰好甲丙多少人？',m.ac-m.triple,'人'),n('only-BC','乙丙交集移除三组全参加的人，恰好乙丙多少人？',m.bc-m.triple,'人'),target('这三部分互不重叠，恰好参加两组共多少人？',m.ab+m.ac+m.bc-3*m.triple,'人')];break;
  case 'openBox':{const upper=Math.floor((m.side-1)/2),volumes=[];for(let x=1;x<=upper;x++)volumes.push({x,side:m.side-2*x,v:x*(m.side-2*x)**2});nodes=[n('largest-cut','底边必须为正，合法正整数剪角最多取多少？',upper),D('剪去四角后，一条底边相对原边减少多少？',['x','2x'],'2x'),...volumes.flatMap(q=>[n('base-'+q.x,`剪角 ${q.x} 时，底边长度是多少？`,q.side),n('volume-'+q.x,`底边与盒高共同决定体积，剪角 ${q.x} 时体积是多少？`,q.v)]),target('完整比较所有合法体积，最大是多少？',Math.max(...volumes.map(q=>q.v)))];break}
  default:return null;
  }
  if(id==='natural-unionChance'||id==='natural-complementChance'){
   const red=m.red-m.both,blue=m.blue-m.both,union=red+blue+m.both,outside=m.total-union;
   const parts=[n('only-red','只参加红组的人数是多少？',red,'人',{dependsOn:[]}),n('only-blue','只参加蓝组的人数是多少？',blue,'人',{dependsOn:[]}),
    n('region-total','合并互不重叠区域，至少参加一组的不同人数是多少？',union,'人',{dependsOn:['only-red','only-blue']})];
   if(id==='natural-complementChance')parts.push(n('neither','从全体移除这些区域，都不参加的有多少人？',outside,'人',{dependsOn:['region-total']}));
   parts.push(n('target','按题目规定的全体人数，求目标概率。',F(id==='natural-unionChance'?union:outside,m.total),'',{dependsOn:[id==='natural-unionChance'?'region-total':'neither']}));
   alternatives.push(R('disjoint-regions','按互不重叠区域直接计数',parts));
  }
  if(id==='routeProbability'){
   const counts=Array.from({length:m.h+1},()=>Array(m.w+1).fill(0)),cellId=(x,y)=>'ways-'+x+'-'+y;
   const dp=[n('sampling-rule','本题哪个对象等可能？','完整路线等可能','',{dependsOn:[],choices:['完整路线等可能','每个岔口单独等可能']}),
    n('all-routes','没有限制点时，全部最短路线共有多少条？',choose(m.w+m.h,m.w),'条',{dependsOn:['sampling-rule']})];
   for(let y=0;y<=m.h;y++)for(let x=0;x<=m.w;x++){
    const blocked=x===m.x&&y===m.y,deps=['sampling-rule'];let value=blocked?0:x+y===0?1:0;
    if(!blocked&&x){value+=counts[y][x-1];deps.push(cellId(x-1,y))}
    if(!blocked&&y){value+=counts[y-1][x];deps.push(cellId(x,y-1))}
    counts[y][x]=value;
    dp.push(n(cellId(x,y),`避开P，到达 (${x},${y}) 的最短路线有几条？`,value,'条',{dependsOn:deps,
     hints:['被排除的P能传出合法路线吗？其余点分别检查左边和下边。','到达一个点的不同最后一步不会重叠，把合法入口路线数合并。']}));
   }
   dp.push(n('target','避开P的完整路线占全部路线的概率是多少？',F(counts[m.h][m.w],choose(m.w+m.h,m.w)),'',{dependsOn:['all-routes',cellId(m.w,m.h)]}));
   alternatives.push(R('direct-route-count','直接逐点累加可行路线',dp));
  }
  if(c.skillContractKey){
   if(id==='squareBorder')alternatives.push(R('boundary-strips','按不重叠的四条边数新增格',[
    n('outer-side','新增后，上下两条边各有多少格？',m.n+2,'格',{dependsOn:[]}),n('top-bottom','上边和下边合计新增多少格？',2*(m.n+2),'格',{dependsOn:['outer-side']}),
    n('left-right','去掉已经计过的角格，左右两边合计多少格？',2*m.n,'格',{dependsOn:[]}),n('target','合并四条互不重叠的边，新增多少格？',4*m.n+4,'格',{dependsOn:['top-bottom','left-right']})]));
   if(id==='paintedCube'||id==='cubeProbability'){
    const faceNodes=[n('one-face','一个面去掉角格后，边缘共有多少小块？',4*(m.n-2),'块',{dependsOn:[]}),n('six-faces','先分别数六个面，共记录多少次？',24*(m.n-2),'次',{dependsOn:['one-face']}),
     n('multiplicity','每个恰好两面涂色的小块被记录几次？',2,'次',{dependsOn:[]})];
    faceNodes.push(n(id==='paintedCube'?'target':'two-painted','除去重复计数，恰好两面涂色的小块是多少？',12*(m.n-2),'块',{dependsOn:['six-faces','multiplicity']}));
    if(id==='cubeProbability')faceNodes.push(n('all-cubes','全部小块共有多少？',m.n**3,'块',{dependsOn:[]}),n('target','符合条件的块数占全部小块几分之几？',F(12*(m.n-2),m.n**3),'',{dependsOn:['two-painted','all-cubes']}));
    alternatives.push(R('face-deduplication','按六个面计数后修正重复',faceNodes));
   }
   if(id==='chartScale')alternatives.push(R('proportional-heights','按柱高的对应倍率求人数',[
    n('combined-height','乙丙的柱高合计多少格？',m.b+m.c,'格',{dependsOn:[]}),n('height-ratio','合并柱高是甲柱高的几倍？',F(m.b+m.c,m.a),'倍',{dependsOn:['combined-height']}),n('target','甲人数乘这个倍率，乙丙合计多少人？',(m.b+m.c)*m.unit,'人',{dependsOn:['height-ratio']})]));
   if(id==='missingAverage')alternatives.push(R('deviation-balance','用平均数的总偏差保持平衡',[
    n('mean-gap','余下平均数比原平均少多少？',m.mean-m.other,'',{dependsOn:[]}),n('remaining-deviation','余下所有数相对原平均合计少多少？',(m.count-1)*(m.mean-m.other),'',{dependsOn:['mean-gap']}),n('target','被删数高出原平均同样的量，它是多少？',m.mean+(m.count-1)*(m.mean-m.other),'',{dependsOn:['remaining-deviation']})]));
   if(id==='natural-weighted'||id==='natural-fractionWeighted')alternatives.push(R('baseline-difference','以红队分数作共同基准再均分差额',[
    n('score-gap','蓝队每人比红队每人多多少分？',F(m.blueScore-m.redScore,m.den),'分',{dependsOn:[]}),n('extra-total','蓝队人数份合计多出多少分？',F(m.blue*(m.blueScore-m.redScore),m.den),'分',{dependsOn:['score-gap']}),
    n('people-parts','代表组共多少人数份？',m.red+m.blue,'份',{dependsOn:[]}),n('extra-average','把差额均分到所有人数份，每份多多少分？',F(m.blue*(m.blueScore-m.redScore),m.den*(m.red+m.blue)),'分',{dependsOn:['extra-total','people-parts']}),n('target','在红队基准分上加每份差额，平均分是多少？',F(m.red*m.redScore+m.blue*m.blueScore,m.den*(m.red+m.blue)),'分',{dependsOn:['extra-average']})]));
   if(id==='telescopingDifferences')alternatives.push(R('equal-differences','按等大的相邻差计算',[
    n('gap','每个括号的差是多少？',m.step,'',{dependsOn:[]}),n('terms','从题目两个端点之间，共有几个这样的差？',m.n,'',{dependsOn:['gap']}),n('target','每个差乘括号数量，合计多少？',m.n*m.step,'',{dependsOn:['gap','terms']})]));
  }
  return [R('family-quantities','连接本题的数量关系',nodes),...alternatives];
 }
 function reviewedRoutes(c,N,R){
  if(!c.skillContractKey)return [];
  const m=c.math,id=c.problemState.familyId||c.family,n=(id,prompt,answer,unit='',dependsOn=[])=>N(id,prompt,answer,unit,{dependsOn}),out=[];
  if(id==='reverseDigits'){
   const candidates=[];for(let a=1;a<=9;a++)for(let b=1;b<a;b++)if(a+b===m.a+m.b)candidates.push(10*a+b);
   out.push(R('digit-pairs','先列数字对再核对交换差',[n('candidate-count','数字和满足题目且十位大于个位的两位数有几个？',candidates.length),n('target','逐一交换核对原来的差，符合的是哪个两位数？',10*m.a+m.b,'',['candidate-count'])]));
  }
  if(id==='natural-digitCount'||id==='natural-distinctDigitCount'){
   const sizes=[0,1,2].map(r=>m.digits.filter(d=>d%3===r).length);
   out.push(R('remainder-groups','按余数分类后配对',[...sizes.map((v,i)=>n('group-'+i,`允许数字中，除以3余${i}的有几个？`,v)),
    n('pairs-00','两位都取余数0的数字，考虑本题能否重复，有几种？',sizes[0]*(sizes[0]-Number(m.distinct)),'',['group-0']),
    n('pairs-12','十位余1、个位余2的有序对有几种？',sizes[1]*sizes[2],'',['group-1','group-2']),n('pairs-21','十位余2、个位余1的有序对有几种？',sizes[1]*sizes[2],'',['group-1','group-2']),
    n('target','合并三个互不重叠的有序分支，总共有几个合法两位数？',sizes[0]*(sizes[0]-Number(m.distinct))+2*sizes[1]*sizes[2],'',['pairs-00','pairs-12','pairs-21'])]));
  }
  if(id==='machineOrder')out.push(R('input-cancellation','先移除两条路径相同的输入部分',[
   n('AB-extra','先甲后乙时，原输入的共同倍数之外增加多少？',m.b*m.c+m.d),n('BA-extra','先乙后甲时，原输入的共同倍数之外增加多少？',m.d*m.a+m.b),n('target','相同输入部分抵消，两种最终结果的差是多少？',Math.abs(m.b*m.c+m.d-m.d*m.a-m.b),'',['AB-extra','BA-extra'])]));
  if(id==='digitDivisor'){
   const ds=Array.from({length:9},(_,i)=>i+1).filter(d=>(10*m.tens)%d===0);
   out.push(R('tens-divisors','找十位部分的一位正因数',[n('tens-part','十位部分的实际数量是多少？',10*m.tens),n('divisor-count','十位部分有几个1到9的正因数？',ds.length,'',['tens-part']),n('target','每个这样的因数对应一个个位，合法两位数共有几个？',ds.length,'',['divisor-count'])]));
  }
  if(id==='boundaryNotch')out.push(R('full-contour','沿新轮廓分水平和竖直边计数',[
   n('horizontal','沿全部新边界，水平段合计多长？',2*m.w),n('vertical','两侧和两条凹口深度边，竖直段合计多长？',2*m.h+2*m.depth),n('target','全部水平段与竖直段合计，周长是多少？',2*(m.w+m.h+m.depth),'',['horizontal','vertical'])]));
  if(id==='polygonTurn')out.push(R('interior-supplement','先拆三角形求内角再求相邻转角',[
   n('triangles','从一个顶点拆分，n边形共有几个三角形？',m.n-2),n('interior-total','这些三角形的角总量是多少度？',180*(m.n-2),'度',['triangles']),n('one-interior','正多边形一个内角是多少度？',F(180*(m.n-2),m.n),'度',['interior-total']),n('target','内角旁的转角与它合成平角，转角多少度？',F(360,m.n),'度',['one-interior'])]));
  if(id==='lShapeArea')out.push(R('disjoint-rectangles','把L形分成两块不重叠长方形',[
   n('bottom-area','下面完整一条长方形的面积是多少？',m.w*(m.h-m.b)),n('upper-left-area','左上角保留的长方形面积是多少？',(m.w-m.a)*m.b),n('target','合并两块没有重叠的面积，L形面积是多少？',m.w*m.h-m.a*m.b,'',['bottom-area','upper-left-area'])]));
  if(id==='crossArea')out.push(R('uncovered-corners','重排未覆盖角块后从整张移除',[
   n('unused-width','整张宽度扣掉竖条宽度后还剩多少？',m.w-m.a),n('unused-height','整张高度扣掉横条高度后还剩多少？',m.h-m.b),n('uncovered-area','四个未覆盖角块拼成的长方形面积是多少？',(m.w-m.a)*(m.h-m.b),'',['unused-width','unused-height']),n('whole-area','整张长方形的面积是多少？',m.w*m.h),n('target','整张扣去未覆盖区域，覆盖面积是多少？',m.a*m.h+m.b*m.w-m.a*m.b,'',['uncovered-area','whole-area'])]));
  if(id==='oppositeScale')out.push(R('representative-area','取方便的原长后保持实际面积',[
   n('original-area','取原长为比例分母，原长方形面积是多少？',m.a*m.old),n('new-length','这个代表长方形变化后的长是多少？',m.b),n('target','面积不变，新面积除以新长，新宽是多少？',F(m.a*m.old,m.b),'',['original-area','new-length'])]));
  if(id==='similarAreaPerimeter')out.push(R('integer-length-parts','从面积比的整数部分还原长度份数',[
   n('small-length-part','较小面积比部分的正平方根是多少？',m.a),n('large-length-part','较大面积比部分的正平方根是多少？',m.b),n('perimeter-one-part','较小周长除以它的对应长度份数，一份是多少？',m.unit,'',['small-length-part']),n('target','同一周长份量乘较大长度份数，周长是多少？',m.b*m.unit,'',['perimeter-one-part','large-length-part'])]));
  if(id==='scaleAreaReverse')out.push(R('reverse-area-stages','按两次面积倍率分别逆推',[
   n('before-second','把最后一次长度缩放对应的面积变化逆推，之前面积是多少？',m.old*m.k*m.k),n('target','再逆推第一次长度放大对应的面积倍率，原面积是多少？',m.old,'',['before-second'])]));
  if(id==='shadowSimilarity')out.push(R('shadow-factor','先求影长是杆高的整数倍数',[
   n('shadow-factor','题目中小杆的影长是它高度的几倍？',2),n('big-shadow','大杆影子的实际长度是多少？',2*m.b*m.unit),n('target','同一时刻用这个影长倍数还原大杆高度，是多少？',m.b*m.unit,'',['shadow-factor','big-shadow'])]));
  if(id==='natural-offers'){
   const a=F(3*m.price,4),gap=m.price-1-3*m.price/4;
   out.push(R('per-item-gap','先累计每件价差再处理整单费用',[
    n('A-unit','甲每本折后价格是多少？',a,'元/本'),n('unit-gap','乙每本比甲折后价多多少？',gap,'元/本',['A-unit']),n('before-fee-gap','这些本子的价差合计多少？',gap*m.count,'元',['unit-gap']),n('target','再算只属于甲的配送费，两店整单差额是多少？',Math.abs(gap*m.count-m.fee),'元',['before-fee-gap'])]));
  }
  return out;
 }
 return {make,reviewedRoutes};
})(typeof module!=='undefined'?require('./competition'):{competitionFraction});
if(typeof module!=='undefined')module.exports=ReasoningGraphExtra;
