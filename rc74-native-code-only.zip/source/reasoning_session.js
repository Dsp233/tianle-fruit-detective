'use strict';
const ReasoningSession=((ReasoningGraph,ProblemState)=>{
 function fresh(signature,graphRevision=2){return {schemaVersion:2,graphRevision,archivedGraphs:[],signature,open:false,routeId:null,activeNodeId:null,planningGoalId:null,completed:{},nodeDrafts:{},input:'',feedback:null,hintLevels:{},events:[],goalChoice:null,finalInput:'',draftText:'',builder:{parts:0,extra:0},processVerified:false}}
 const routeOf=(s,g)=>g.routes.find(r=>r.id===s.routeId);
 const ready=(s,n)=>n.prerequisiteIds.every(id=>s.completed[id]);
 function refreshVerified(s,g){const r=routeOf(s,g);s.processVerified=!!r&&r.nodes.every(n=>s.completed[n.id]);return s.processVerified}
 function restore(value,signature,graph){
  const s=fresh(signature,graph.graphRevision||1);if(value?.signature!==signature)return s;
  // Changed process contracts keep old work as evidence; only matching nodes
  // whose new dependencies are satisfied count towards the current route.
  s.archivedGraphs=Array.isArray(value.archivedGraphs)?JSON.parse(JSON.stringify(value.archivedGraphs)):[];
  if((value.graphRevision||1)!==s.graphRevision&&(Object.keys(value.completed||{}).length||Object.keys(value.nodeDrafts||{}).length)){
   s.archivedGraphs.push({graphRevision:value.graphRevision||1,routeId:value.routeId,completed:JSON.parse(JSON.stringify(value.completed||{})),nodeDrafts:JSON.parse(JSON.stringify(value.nodeDrafts||{})),events:JSON.parse(JSON.stringify(value.events||[]))});
  }
  s.open=value.open===true;s.routeId=graph.routes.some(r=>r.id===value.routeId)?value.routeId:null;s.goalChoice=['A','B','C'].includes(value.goalChoice)?value.goalChoice:null;
  s.finalInput=String(value.finalInput||'').slice(0,40);s.draftText=String(value.draftText||'').slice(0,1200);s.input=String(value.input||'').slice(0,160);
  if(Number.isInteger(value.builder?.parts))s.builder.parts=Math.max(0,Math.min(12,value.builder.parts));if(Number.isSafeInteger(value.builder?.extra))s.builder.extra=Math.max(-500,Math.min(500,value.builder.extra));
  const route=routeOf(s,graph);
  // Independent roots can be completed in either order. An absent root must
  // not discard a valid sibling during refresh.
  if(route)for(const n of route.nodes){const v=value.completed?.[n.id];if(v&&ready(s,n)&&ReasoningGraph.accepts(n,v.input))s.completed[n.id]={input:String(v.input).slice(0,160),providedBy:v.providedBy==='system'?'system':'student',at:Number.isFinite(v.at)?v.at:0}}
  if(route?.nodes.some(n=>n.id===value.activeNodeId&&!s.completed[n.id]))s.activeNodeId=value.activeNodeId;
  if(route?.nodes.some(n=>n.id===value.planningGoalId&&!s.completed[n.id]))s.planningGoalId=value.planningGoalId;
  for(const [id,v]of Object.entries(value.nodeDrafts||{}))if(route?.nodes.some(n=>n.id===id)&&typeof v==='string')s.nodeDrafts[id]=v.slice(0,160);
  for(const [id,n]of Object.entries(value.hintLevels||{}))if(route?.nodes.some(x=>x.id===id)&&Number.isInteger(n))s.hintLevels[id]=Math.max(0,Math.min(4,n));
  s.events=(Array.isArray(value.events)?value.events:[]).filter(x=>x&&typeof x.type==='string'&&Number.isFinite(x.at)).map(x=>({...x,input:String(x.input||'').slice(0,160)}));
  refreshVerified(s,graph);return s;
 }
 function current(s,graph){
  const route=routeOf(s,graph),active=route?.nodes.find(n=>n.id===s.activeNodeId&&!s.completed[n.id]);if(active)return active;
  const goal=route?.nodes.find(n=>n.id===s.planningGoalId&&!s.completed[n.id]);if(goal){const ancestors=new Set();const visit=n=>{ancestors.add(n.id);for(const id of n.prerequisiteIds)visit(route.nodes.find(x=>x.id===id))};visit(goal);return route.nodes.find(n=>ancestors.has(n.id)&&!s.completed[n.id]&&ready(s,n))||goal}
  return route?.nodes.find(n=>!s.completed[n.id]&&ready(s,n))||null;
 }
 function missing(s,graph,node=current(s,graph)){const route=routeOf(s,graph);return (node?.prerequisiteIds||[]).filter(id=>!s.completed[id]).map(id=>route.nodes.find(n=>n.id===id))}
 function event(s,type,values={}){s.events.push({type,at:Date.now(),...values})}
 function select(s,graph,routeId){if(!graph.routes.some(r=>r.id===routeId))return false;
  if(s.routeId&&(Object.keys(s.completed).length||Object.keys(s.nodeDrafts).length||s.input)){s.archivedGraphs||=[];s.archivedGraphs.push({graphRevision:s.graphRevision,routeId:s.routeId,completed:JSON.parse(JSON.stringify(s.completed)),nodeDrafts:JSON.parse(JSON.stringify(s.nodeDrafts)),input:s.input,events:JSON.parse(JSON.stringify(s.events)),reason:'route-change'})}
  s.routeId=routeId;s.activeNodeId=null;s.planningGoalId=null;s.completed={};s.nodeDrafts={};s.input='';s.feedback=null;s.builder={parts:0,extra:0};s.processVerified=false;event(s,'route-choice',{routeId});return true}
 function focus(s,graph,nodeId,dependency=false){
  const n=routeOf(s,graph)?.nodes.find(n=>n.id===nodeId);if(!n||s.completed[nodeId])return false;
  const prior=current(s,graph);if(prior)s.nodeDrafts[prior.id]=s.input.slice(0,160);
  s.activeNodeId=nodeId;if(!dependency)s.planningGoalId=nodeId;s.input=s.nodeDrafts[nodeId]||'';s.builder={parts:0,extra:0};s.feedback=null;event(s,'subgoal-choice',{nodeId,dependency});return true;
 }
 function revise(s,graph,nodeId){
  const route=routeOf(s,graph),node=route?.nodes.find(n=>n.id===nodeId);if(!node||!s.completed[nodeId])return false;
  const invalid=new Set([nodeId]);for(const n of route.nodes)if(n.prerequisiteIds.some(id=>invalid.has(id)))invalid.add(n.id);
  for(const id of invalid){if(s.completed[id])s.nodeDrafts[id]=s.completed[id].input;delete s.completed[id]}
  s.activeNodeId=nodeId;s.input=s.nodeDrafts[nodeId]||'';s.builder={parts:0,extra:0};s.feedback={ok:true,text:'已保留草稿。使用这个条件的后续结论需要重新确认。',help:false};refreshVerified(s,graph);event(s,'node-revision',{nodeId,invalidatedNodeIds:[...invalid]});return true;
 }
 function submit(s,graph){const n=current(s,graph);if(!n)return false;if(!ready(s,n)){s.feedback={ok:false,text:'这个目标还需要先确认下面的条件。你可以选择要先补齐的量。',help:true};event(s,'missing-prerequisite',{nodeId:n.id,help:true});return false}
  const input=s.input.trim();if(!input){s.feedback={ok:false,text:'先写出你的关系或结果。',help:false};return false}
  if(!ReasoningGraph.accepts(n,input)){
   const recognized=ProblemState.arithmetic(input)!==null||n.choices?.includes(input)||ReasoningGraph.recognizes(n,input);
   s.feedback={ok:false,text:recognized?n.errorCheck:'这段表达已保留，过程暂未自动核验。可以改用选择或填数，也可直接提交终答。',help:recognized,unverified:!recognized};event(s,recognized?'error-feedback':'unverified-draft',{nodeId:n.id,input,help:recognized});return false;
  }
  s.completed[n.id]={input,providedBy:'student',at:Date.now()};delete s.nodeDrafts[n.id];event(s,'node-answer',{nodeId:n.id,input,help:false});s.activeNodeId=null;s.input='';s.builder={parts:0,extra:0};s.feedback={ok:true,text:'这一步与条件一致。',help:false};refreshVerified(s,graph);return true;
 }
 function help(s,graph){const n=current(s,graph);if(!n||!ready(s,n))return null;const level=Math.min(n.hints.length,(s.hintLevels[n.id]||0)+1);s.hintLevels[n.id]=level;event(s,'hint',{nodeId:n.id,level,help:true});return {node:n,level,text:n.hints[level-1],exhausted:level===n.hints.length}}
 return {fresh,restore,current,missing,ready,event,select,focus,revise,submit,help,refreshVerified};
})(typeof module!=='undefined'?require('./reasoning_graph'):ReasoningGraph,typeof module!=='undefined'?require('./problem_state'):ProblemState);
if(typeof module!=='undefined')module.exports=ReasoningSession;
