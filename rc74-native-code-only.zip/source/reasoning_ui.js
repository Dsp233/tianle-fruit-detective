'use strict';
function reasoningState(task=playerTask()){
 const work=competitionState(),graph=ReasoningGraph.create(task.competition);
 if(work.reasoning?.needsValidation)work.reasoning=ReasoningSession.restore(work.reasoning,task.competition.signature,graph);
 if(!work.reasoning||work.reasoning.signature!==task.competition.signature)work.reasoning=ReasoningSession.fresh(task.competition.signature,graph.graphRevision);
 return {state:work.reasoning,graph};
}
function reasoningMarkHelp(task,type,details={}){
 const h=competitionHistory(task);if(!h.hinted){h.hintedAt=Date.now();h.hintOrder=++saved.competition.sequence}h.hinted=true;
 const s=reasoningState(task).state;ReasoningSession.event(s,type,{...details,help:true});
 saved.competition.events||=[];saved.competition.events.push({type,signature:task.competition.signature,recipe:task.competition.recipe,at:Date.now(),...details,help:true});CompetitionIdentity.invalidate(saved.competition);
 CompetitionIdentity.noteMethodExposure(saved.competition,task,type);
}
function historySolutionExposure(task,kind){
 saved.competition.events||=[];saved.competition.events.push({type:'solution-'+kind,signature:task.competition.signature,variationSignature:task.competition.extension.signature,recipe:task.competition.recipe,at:Date.now(),help:true});
 if(kind==='main'){competitionHistory(task).solutionViewed=true;competitionHistory(task).solutionViewedAt=Date.now()}CompetitionIdentity.noteMethodExposure(saved.competition,task,'solution-'+kind);CompetitionIdentity.invalidate(saved.competition);
}
function competitionDirectedFeedback(task,input){
 const c=task.competition,m=c.math;
 if(c.family==='threeGroupBalance'){
  if(ProblemState.equal(input,m.T/2))return '把这个人数代回原条件，核对所求'+({A:'甲',B:'乙',C:'丙'}[m.goal]||'目标')+'组，能同时满足总人数与组间关系吗？';
  if(ProblemState.equal(input,m.T/3*m.k))return '题目中三组人数一样多吗？你的三组模型能表示人数差吗？';
  if(ProblemState.equal(input,m.B))return '这个数在你的图中代表哪一组？最后问的是哪一组？';
  return '这个数代表哪一组？请选择使用的两条条件，先检查它们能否同时成立。';
 }
 // Also used while stored records are restored, before live draft initialization.
 // This feedback depends only on the supplied task and actual input.
 return CompetitionFeedback.diagnose({task,input,scopeId:'main'}).text;
}
function reasoningDiagram(task,s){
 const c=task.competition,m=c.math;
 if(c.family==='threeGroupBalance'){
  let body=['甲','乙','丙'].map((name,i)=>{const known=i===0?s.completed['model-A']:i===2?s.completed['model-C']:null;
   const ref=i===2&&m.ref==='A'?'甲':'乙',parts=i===2?m.k:1,extra=i===0?m.direction*m.d:0;
   return `<div class="reasoning-bar-row"><b>${name}组</b>${known?`<div class="reasoning-bar">${Array.from({length:parts},()=>`<span class="reasoning-unit">一份${ref}</span>`).join('')}${extra?`<span class="reasoning-extra">${extra>0?'+':''}${extra}人</span>`:''}<span class="reasoning-equation">${esc(known.input)+(known.providedBy==='system'?'（示范）':'')}</span></div>`:'<div class="reasoning-blank">未建立关系</div>'}</div>`}).join('');
  return `<figure class="reasoning-figure" aria-label="孩子已确认的三组关系">${body}${s.completed['pair-relation']?'<p>甲加乙：'+esc(s.completed['pair-relation'].input)+'</p>':''}${s.completed['total-model']?'<p>总量关系：'+esc(s.completed['total-model'].input)+'</p>':''}${s.completed.net?'<p>可分配总量：'+esc(s.completed.net.input)+' 人</p>':''}${s.completed['unit-B']?'<p>乙组：'+esc(s.completed['unit-B'].input)+' 人</p>':''}${s.completed.target?'<p>当前目标：'+esc(s.completed.target.input)+' 人</p>':''}<figcaption>由已确认关系逐步建立；示范步骤单独标明，未确认的量保留为空。</figcaption></figure>`;
 }
 const graph=ReasoningGraph.create(c),route=graph.routes.find(r=>r.id===s.routeId);
 const quantities=(route?.nodes||[]).filter(n=>s.completed[n.id]).map(n=>({id:n.id,prerequisiteIds:n.prerequisiteIds,providedBy:s.completed[n.id].providedBy,label:n.prompt+'（'+(s.completed[n.id].providedBy==='system'?'示范':'你的确认')+'）',value:s.completed[n.id].providedBy==='system'?SourceCatalog.presentationValue(task,s.completed[n.id].input,topicSessionSettings()):s.completed[n.id].input,unit:n.unit}));
 return quantities.length?competitionDiagram({kind:'scene-quantities',dependencyGraph:true,quantities,caption:'已确认的量与条件依赖；尚未确认的量留空'}):'<p>先保留原题图，再添加你确认的数量关系。</p>';
}
function reasoningPanel(task){
 const {state:s,graph}=reasoningState(task);if(!graph.routes.length)return '';
 if(!s.open)return '<button class="secondary" data-action="reasoningOpen">整理条件 / 画一画</button>';
 const n=ReasoningSession.current(s,graph),route=graph.routes.find(r=>r.id===s.routeId),level=n?s.hintLevels[n.id]||0:0,blocked=ReasoningSession.missing(s,graph,n);
 const permitted=new Set(SourceCatalog.taskAllowed(task,topicSessionSettings()).map(r=>r.id)),allowed=graph.routes.filter(r=>permitted.has(r.id));
 if(route&&!permitted.has(route.id))return `<section class="reasoning-panel"><h2>我的数量关系</h2><p role="status">这条保存的路线超出这组声明的知识范围。原有草稿仍保留，可以换一条可用路线或继续自行作答。</p><div class="stage-buttons">${allowed.map(r=>`<button class="secondary" data-action="reasoningRoute" data-code="${esc(r.id)}">${esc(r.name)}</button>`).join('')}</div><button class="secondary" data-action="reasoningClose">收起，保留草稿</button></section>`;
 const choice=task.competition.family==='threeGroupBalance'&&!s.goalChoice?`<p>你想先确定哪一组？得到它后，怎样帮助最终目标？</p>${['A','B','C'].map((x,i)=>`<button class="secondary" data-action="reasoningGoal" data-code="${x}">${['甲','乙','丙'][i]}组</button>`).join('')}`:'';
 const builder=task.competition.family==='threeGroupBalance'&&n&&ReasoningSession.ready(s,n)&&['model-A','model-C','total-model'].includes(n.id)?reasoningBuilder(task,s,n):'';
 return `<section class="reasoning-panel" data-reasoning-stage="${n?.id||'route'}"><h2>我的数量关系</h2>${choice}${!choice&&!route?`<p>选择你要尝试的表示方法。也可以继续直接作答。</p><div class="stage-buttons">${allowed.map(r=>`<button class="secondary" data-action="reasoningRoute" data-code="${esc(r.id)}">${esc(r.name)}</button>`).join('')}</div>`:''}${reasoningDiagram(task,s)}${reasoningGoalNavigation(task,s,graph)}${n&&!choice&&!blocked.length?`<label><b>${esc(n.prompt)}</b><input data-competition-input="reasoning" value="${esc(s.input)}" autocomplete="off" placeholder="你的关系、算式或结果" aria-label="当前步骤作答"></label>${builder}${n.choices?`<div class="stage-buttons">${n.choices.map(v=>`<button class="secondary" data-action="reasoningChoice" data-code="${esc(v)}">${esc(v)}</button>`).join('')}</div>`:''}<div class="stage-buttons"><button class="primary" data-action="reasoningCheck">确认这一步</button><button class="secondary" data-action="reasoningHint">${level>=n.hints.length?'提示已用完':'给当前步骤一点提示'}</button><button class="read-mini" data-action="reasoningRead">🔊 听当前目标</button><button class="secondary" data-action="competitionPauseSpeech">暂停 / 继续朗读</button><button class="secondary" data-action="competitionStopSpeech">停止</button></div>${level?`<p class="reasoning-hint" role="status">${esc(n.hints[level-1])}</p>`:''}${level>=n.hints.length?'<p>可以看这一步示范、保留草稿，或跳过。</p><button class="secondary" data-action="reasoningExample">看这一步示范</button>':''}`:''}${s.feedback?`<p role="status">${esc(s.feedback.text)}</p>`:''}${s.processVerified?'<p role="status">数量关系已核验。请回到题目提交最终答案。</p>':''}<button class="secondary" data-action="reasoningReset">重新建图</button><button class="secondary" data-action="reasoningClose">收起，保留草稿</button></section>`;
}
function reasoningGoalNavigation(task,s,graph){
 const route=graph.routes.find(r=>r.id===s.routeId);if(!route)return '';
 const n=ReasoningSession.current(s,graph),missing=ReasoningSession.missing(s,graph,n);
 const button=(node,action)=>'<button class="secondary" data-action="'+action+'" data-code="'+esc(node.id)+'">'+esc(node.prompt)+'</button>';
 const blocked=missing.length?'<section class="reasoning-dependencies" aria-label="当前目标尚缺的条件"><p><b>想得到：'+esc(n.prompt)+'</b></p><p>还需要哪些量？选择一个先补齐。</p><div class="stage-buttons">'+missing.map(x=>button(x,'reasoningPrerequisite')).join('')+'</div></section>':'';
 const complete=route.nodes.filter(x=>s.completed[x.id]);
 return blocked+'<details class="reasoning-goals"><summary>选择另一个目标 / 修改已确认关系</summary><p>可以从最终目标倒着找条件，也可以先确认你能求出的量。</p><div class="stage-buttons">'+route.nodes.filter(x=>!s.completed[x.id]).map(x=>button(x,'reasoningFocus')).join('')+'</div>'+ (complete.length?'<p>修改一个条件后，使用它的结论会保留为草稿，需要重新核对。</p><div class="stage-buttons">'+complete.map(x=>'<button class="secondary" data-action="reasoningRevise" data-code="'+esc(x.id)+'">修改：'+esc(x.prompt)+' · '+esc(s.completed[x.id].providedBy==='system'?SourceCatalog.presentationValue(task,s.completed[x.id].input,topicSessionSettings()):s.completed[x.id].input)+'</button>').join('')+'</div>':'')+'</details>';
}
function reasoningBuilder(task,s,n){
 const m=task.competition.math,ref=n.id==='model-C'&&m.ref==='A'?'甲':s.routeId==='direct-C'?'丙':'乙';
 return `<div class="reasoning-builder" aria-label="自己搭建份数条"><div class="reasoning-bar-row">${Array.from({length:s.builder.parts},()=>`<span class="reasoning-unit">一份${ref}</span>`).join('')||'<span>还没有放份数条</span>'}${s.builder.extra?`<span class="reasoning-extra">${s.builder.extra>0?'+':''}${s.builder.extra} 人</span>`:''}</div><div class="stage-buttons"><button class="secondary" data-action="reasoningBuild" data-code="add">添加一份${ref}</button><button class="secondary" data-action="reasoningBuild" data-code="remove">拿走一份</button>${n.id!=='model-C'?`<button class="secondary" data-action="reasoningBuild" data-code="plus">加 ${m.d} 人</button><button class="secondary" data-action="reasoningBuild" data-code="minus">减 ${m.d} 人</button>`:''}<button class="secondary" data-action="reasoningBuild" data-code="clear">清空草稿条</button></div></div>`;
}
function reasoningHandleAction(action,data){
 if(!action.startsWith('reasoning'))return false;const task=playerTask();if(!task?.competition||view!=='competition')return true;
 if(!SourceCatalog.taskAllowed(task,topicSessionSettings()).length){feedback={ok:false,status:'unsupported_scope',text:competitionScopedContent(task).variationScopeMessage};render();return true;}
 const {state:s,graph}=reasoningState(task);competitionStopCurrentSpeech();
 if(action==='reasoningOpen'){s.open=true;reasoningMarkHelp(task,'scaffold-open',{reason:'系统提供子目标与候选路线，计为过程引导'})}
 if(action==='reasoningClose')s.open=false;
 if(action==='reasoningGoal'){if(['A','B','C'].includes(data.code)){s.goalChoice=data.code;ReasoningSession.event(s,'goal-choice',{goal:data.code});s.feedback=data.code==='A'?{text:'先求甲也可以。当前可自动核验乙或丙作参照的路线；你的其他过程可保留在草稿。',ok:true}:null}}
 const allowed=new Set(SourceCatalog.taskAllowed(task,topicSessionSettings()).map(r=>r.id));
 if(s.routeId&&!allowed.has(s.routeId)&&!['reasoningOpen','reasoningClose','reasoningGoal','reasoningRoute','reasoningReset'].includes(action)){s.feedback={ok:false,text:'这条路线超出这组声明的知识范围，原有草稿已保留。',help:false};persist();render();return true}
 if(action==='reasoningRoute'){const r=graph.routes.find(r=>r.id===data.code);if(r&&allowed.has(r.id))ReasoningSession.select(s,graph,data.code);else s.feedback={ok:false,text:'这组声明的知识范围不包含这条路线的必要知识，可以保留自己的思路并直接作答。'}}
 if(action==='reasoningFocus'||action==='reasoningPrerequisite')ReasoningSession.focus(s,graph,data.code,action==='reasoningPrerequisite');
 if(action==='reasoningRevise')ReasoningSession.revise(s,graph,data.code);
 if(action==='reasoningChoice')s.input=data.code;
 if(action==='reasoningBuild'){
  const n=ReasoningSession.current(s,graph),m=task.competition.math;if(n&&['model-A','model-C','total-model'].includes(n.id)){
   if(data.code==='add')s.builder.parts=Math.min(12,s.builder.parts+1);if(data.code==='remove')s.builder.parts=Math.max(0,s.builder.parts-1);if(data.code==='plus')s.builder.extra+=m.d;if(data.code==='minus')s.builder.extra-=m.d;if(data.code==='clear')s.builder={parts:0,extra:0};
   const ref=n.id==='model-C'&&m.ref==='A'?'甲':s.routeId==='direct-C'?'丙':'乙';s.input=(s.builder.parts===1?ref:s.builder.parts+'*'+ref)+(s.builder.extra===0?'':(s.builder.extra>0?'+':'')+s.builder.extra)+(n.id==='total-model'?'='+m.T:'');ReasoningSession.event(s,'diagram-draft',{nodeId:n.id,input:s.input});
  }
 }
 if(action==='reasoningCheck'){ReasoningSession.submit(s,graph);if(s.feedback?.help)reasoningMarkHelp(task,'directed-feedback',{nodeId:ReasoningSession.current(s,graph)?.id})}
 if(action==='reasoningHint'){const h=ReasoningSession.help(s,graph);if(h)reasoningMarkHelp(task,'node-hint',{nodeId:h.node.id,level:h.level})}
 if(action==='reasoningExample'){const n=ReasoningSession.current(s,graph);if(n&&ReasoningSession.ready(s,n)){reasoningMarkHelp(task,'node-example',{nodeId:n.id});s.completed[n.id]={input:SourceCatalog.presentationValue(task,n.answer,topicSessionSettings()),providedBy:'system',at:Date.now()};s.input='';s.feedback={ok:true,text:'这一步由示范提供。下一步由你继续。'};s.activeNodeId=null;ReasoningSession.refreshVerified(s,graph)}}
 if(action==='reasoningReset'){ReasoningSession.event(s,'model-reset');s.completed={};s.nodeDrafts={};s.activeNodeId=null;s.planningGoalId=null;s.input='';s.feedback=null;s.processVerified=false}
 if(action==='reasoningRead'){const n=ReasoningSession.current(s,graph);if(n)speak('surface',-1,competitionSpeechText(n.prompt+(s.hintLevels[n.id]?' '+n.hints[s.hintLevels[n.id]-1]:'')))}
 persist();render();return true;
}
