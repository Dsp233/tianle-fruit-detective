"""Record a validated shared-problem batch without claiming device or deployment acceptance."""
import argparse
import csv
import datetime
import hashlib
import json
import re
import subprocess
from pathlib import Path
from zoneinfo import ZoneInfo

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--rc', type=int, required=True)
parser.add_argument('--module', required=True)
parser.add_argument('--prefix', required=True)
parser.add_argument('--details', type=Path, required=True)
parser.add_argument('--next', required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
docs = root / 'docs'
release = json.loads((root / 'source/version.json').read_text())
assert release['siteVersion'] == f'V12.0-rc.{args.rc}'
content = json.loads((root / 'source/joint_families.json').read_text())
families = content['families']
graph = json.loads((root / 'source/knowledge_graph.json').read_text())
at = datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
payload = (root / 'index.html').read_bytes()
assert payload == (root / 'source/index.html').read_bytes() == (root / 'amc8/index.html').read_bytes()
sha = hashlib.sha256(payload).hexdigest()
count = len(families)
regions = len({f['regionId'] for f in families})
proofs = {}
for file in (docs / 'evidence/2026-10-04-m4-joint').glob('validation*.json'):
    report = json.loads(file.read_text())
    if report.get('result') == 'passed':
        for row in report.get('coverage', []):
            if row.get('result') == 'passed':
                proofs[(row['id'], row.get('contentVersion'))] = str(file.relative_to(root))
for f in families:
    for i in f['instances']:
        assert (i['id'], i.get('contentVersion', f['contentVersion'])) in proofs, i['id']
scope = (f'33区域179节点{len(graph["relations"])}关系；{count}/179共享族、{count*4}/716实例完成代码和数学/状态模拟，'
         f'{regions}/33区域有共同题入口。剩余{179-count}族、{716-count*4}实例继续。')
checks = (f'三入口{len(payload):,}字节，SHA256 `{sha}`；{release["siteVersion"]}、内容{release["contentRevision"]}/存储2/规则4。'
          '当前共享实例数学/状态证据逐个匹配合同版本；完整旧流程、记录分域、历史候选迁移、知识网选择/分页/缩放和交付检查通过模拟。'
          '浏览器/iPad、新部署无新增验收。358双书分层、107原图未全目视、原题87/412/1及三批答案口径保持。完整教学和M4–M8继续。')
detail = args.details.read_text().strip()
report_name = f'delivery-review-rc{args.rc}.md'
report = (f'# rc{args.rc} 共享题批次验收记录\n\n时间：{at}。起点 `{head}`；本批提交见 `git log -1 -- docs/{report_name}`。\n\n'
          f'{detail}\n\n{scope}\n\n{checks}\n\n下一步：{args.next}\n')
(docs / report_name).write_text(report)
for name in ['implementation-status.md', 'acceptance-report.md', 'release-notes.md']:
    p = docs / name
    old = p.read_text()
    history = old.split('\n---\n', 1)[1] if '\n---\n' in old else old
    p.write_text(f'# 当前候选验收状态：{release["siteVersion"]}\n\n更新：{at}；当前事实以本段、{report_name}与requirements-traceability.csv为准。历史保留当时记录。\n\n{scope}\n\n{checks}\n\n---\n' + history)
for name in ['implementation-status-knowledge-network.md', 'continuity-checkpoint-2026-10-04.md']:
    p = docs / name
    marker = f'\n## rc{args.rc} '
    old = p.read_text()
    if marker not in old:
        p.write_text(old + marker + at + '\n\n' + detail + '\n\n' + scope + '\n\n' + checks + '\n')
checkpoint = f'''# 最新连续实施检查点

更新：{at}。

- workspace: `{root}`
- branch: `implement/v12-knowledge-network`
- head_before_batch_commit: `{head}`；本批提交见 `git log -1 -- docs/{report_name}`。
- release: {release['label']}；content_revision:{release['contentRevision']}；storage_version:2；evidence_rule_version:4。
- milestone: M4共享{count}/179族{count*4}/716实例，{regions}/33区域已有共同题；剩余{179-count}族{716-count*4}实例。
- coverage: 33区域179节点{len(graph['relations'])}关系；179概念/操作/示范/迁移及1432阶段继承；358来源、107原图未全目视、原题87/412/1、三批答案500题位。
- tests: 全部当前共同实例、旧流程/记录/历史合同迁移/知识网/交付模拟通过；非浏览器/设备。
- build: {len(payload)}字节，SHA256 `{sha}`，三入口一致。
- deployment: 未集中发布；历史2026-09-29 main c8e4d3b/rc10不代表当前线上。M7核查认证GitHub网页编辑器和Pages来源，安全整合完整源码。
- blockers: iPad真机不可用；本地浏览器URL既有拒绝不得换接口绕过；GitHub认证待M7核对。来源待原图目视和412原题。上次执行通道无响应后已恢复，此批按实际文件核对收口。
- next_action: {args.next}；随后M5–M8。已见完整数学不能靠换版本重计，未见替补联合题池待M5。
'''
(docs / 'continuity-checkpoint.md').write_text(checkpoint)
p = root / 'source/README.md'
s = p.read_text()
s = re.sub(r'V12\.0-rc\.\d+', release['siteVersion'], s)
s = re.sub(r'内容\d+、存储2', f'内容{release["contentRevision"]}、存储2', s)
s = re.sub(r'与\d+真实共享', f'与{count}真实共享', s)
s = re.sub(r'共享题\d+/179族、\d+/716实例', f'共享题{count}/179族、{count*4}/716实例', s)
s = re.sub(r'剩余\d+族\d+实例', f'剩余{179-count}族{716-count*4}实例', s)
s = re.sub(r'当前各[\d,]+字节', f'当前各{len(payload):,}字节', s)
s = re.sub(r'SHA256 `[0-9a-f]{64}`', f'SHA256 `{sha}`', s)
s = re.sub(r'delivery-review-rc\d+\.md', report_name, s)
command = f'node source/test_joint_{args.module}.js'
if command not in s:
    s = s.replace('node source/test_joint_logic.js', 'node source/test_joint_logic.js\n' + command)
p.write_text(s)
p = docs / 'requirements-traceability.csv'
with p.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    fields, rows = reader.fieldnames, list(reader)
for row in rows:
    status = row['codeStatus']
    status = re.sub(r'\d+共享族\d+实例', f'{count}共享族{count*4}实例', status)
    status = re.sub(r'剩余\d+族\d+实例', f'剩余{179-count}族{716-count*4}实例', status)
    status = re.sub(r'\d+族两独立', f'{count}族两独立', status)
    status = re.sub(r'与\d+族关系', f'与{count}族关系', status)
    row['codeStatus'] = status
known = {row['requirementId'] for row in rows}
for f in families:
    rid = 'REL-APPLICATION-' + f['id']
    if not f['binding'].startswith(args.prefix) or rid in known:
        continue
    row = dict.fromkeys(fields, '')
    row.update(requirementId=rid, baselineSource='docs/AMC8_知识网学练测通_全量实施与部署_GPT61Sol_执行方案.md#8', unitId=f['regionId'], skillId=f['primarySkillId'], relationId=rid,
               implementationPaths=f'source/joint_families.json;source/joint_{args.module}.js;source/joint_ui.js', taskIds=';'.join(i['id'] for i in f['instances']), acceptanceCaseIds=f'source/test_joint_{args.module}.js',
               codeStatus='原身份/实际记录进入共同安排，四实例数学状态模拟通过；完整教学待验', browserStatus='待真实浏览器', ipadStatus='待iPad横屏真机', evidencePaths=';'.join(sorted({proofs[(i['id'], i.get('contentVersion', f['contentVersion']))] for i in f['instances']})), blockerId='DEVICE-IPAD;BROWSER-LOCAL')
    rows.append(row)
with p.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fields, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
tests = list(dict.fromkeys([f'test_joint_{args.module}.js', 'test_joint_role_migration.js', 'test_joint.js', 'test_joint_rates.js', 'test_joint_logic.js', 'test_joint_raffle.js', 'test_joint_numbers.js', 'test_knowledge_graph_ui.js', 'test_knowledge.js', 'test_record_scope.js', 'test.js', 'test_delivery.py']))
verification = dict(release=release, at=at, baseCommit=head, buildBytes=len(payload), sha256=sha, tests=tests, result='passed', environment='Node VM simulated DOM / actual historical rc55 Git HTML / local build', families=count, instances=count*4, regionsWithJoint=regions, remainingFamilies=179-count, remainingInstances=716-count*4, browser='not tested', ipad='not tested', deployed=False)
(docs / f'evidence/2026-10-04-m4-joint/verification-rc{args.rc}.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
print(scope)
print(f'Requirements: {len(rows)}; report: docs/{report_name}; {sha}')
