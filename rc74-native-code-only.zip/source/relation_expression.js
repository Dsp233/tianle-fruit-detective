'use strict';
// Bounded linear algebra only. Expressions are parsed, never executed.
const RelationExpression=(()=>{
 const q=(n,d=1n)=>{if(!d)throw Error('zero divisor');return [n,d]},add=(a,b)=>q(a[0]*b[1]+b[0]*a[1],a[1]*b[1]),mul=(a,b)=>q(a[0]*b[0],a[1]*b[1]),neg=a=>q(-a[0],a[1]),zero=a=>a[0]===0n,equal=(a,b)=>a[0]*b[1]===b[0]*a[1],scalar=n=>({constant:n,terms:{}}),scale=(a,b)=>({constant:mul(a.constant,b),terms:Object.fromEntries(Object.entries(a.terms).map(([k,v])=>[k,mul(v,b)]))});
 function combine(a,b,sign=1){const x={constant:add(a.constant,sign<0?neg(b.constant):b.constant),terms:{...a.terms}};for(const [k,v]of Object.entries(b.terms))x.terms[k]=add(x.terms[k]||q(0n),sign<0?neg(v):v);return x}
 const isScalar=a=>Object.values(a.terms).every(zero);
 function parse(value){
  const s=String(value).replace(/\s/g,'').replace(/组/g,'').replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/([0-9)])([甲乙丙(])/g,'$1*$2');
  if(!s||s.length>160||!/^[\d.+\-*/()甲乙丙]+$/.test(s))return null;
  const tokens=s.match(/\d+(?:\.\d*)?|\.\d+|[+\-*/()甲乙丙]/g)||[];if(tokens.join('')!==s)return null;let at=0;
  function atom(){const t=tokens[at++];if(t==='+'||t==='-')return scale(atom(),q(t==='-'?-1n:1n));if(t==='('){const x=expr();if(tokens[at++]!==')')throw Error('unclosed');return x}if(['甲','乙','丙'].includes(t))return {constant:q(0n),terms:{[t]:q(1n)}};if(!/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(t||''))throw Error('invalid');const [n,f='']=t.split('.');return scalar(q(BigInt((n||'0')+f),10n**BigInt(f.length)))}
  function product(){let a=atom();while(['*','/'].includes(tokens[at])){const op=tokens[at++],b=atom();if(op==='/'){if(!isScalar(b)||zero(b.constant))throw Error('nonlinear');a=scale(a,q(b.constant[1],b.constant[0]))}else{if(!isScalar(a)&&!isScalar(b))throw Error('nonlinear');a=isScalar(b)?scale(a,b.constant):scale(b,a.constant)}}return a}
  function expr(){let a=product();while(['+','-'].includes(tokens[at])){const op=tokens[at++];a=combine(a,product(),op==='+'?1:-1)}return a}
  try{const x=expr();return at===tokens.length?x:null}catch{return null}
 }
 function substituted(a,aliases){let out=scalar(a.constant);for(const [k,v]of Object.entries(a.terms)){const replacement=aliases?.[k]?parse(aliases[k]):{constant:q(0n),terms:{[k]:q(1n)}};if(!replacement)throw Error('alias');out=combine(out,scale(replacement,v))}return out}
 function form(text,aliases){const parts=String(text).split('=');if(parts.length>2)return null;const a=parse(parts[0]),b=parts.length===2?parse(parts[1]):scalar(q(0n));if(!a||!b)return null;try{return {equation:parts.length===2,value:substituted(parts.length===2?combine(a,b,-1):a,aliases)}}catch{return null}}
 function equivalent(input,expected,aliases){
  const a=form(input,aliases),b=form(expected,aliases);if(!a||!b||a.equation!==b.equation)return false;
  const keys=['constant',...new Set([...Object.keys(a.value.terms),...Object.keys(b.value.terms)])],get=(v,k)=>k==='constant'?v.constant:v.terms[k]||q(0n);
  if(!a.equation)return keys.every(k=>equal(get(a.value,k),get(b.value,k)));
  const pivot=keys.find(k=>!zero(get(b.value,k)));if(!pivot||zero(get(a.value,pivot)))return false;
  const ap=get(a.value,pivot),bp=get(b.value,pivot);return keys.every(k=>equal(mul(get(a.value,k),bp),mul(get(b.value,k),ap)));
 }
 function accepts(node,input){return !!node.linearContract&&node.linearContract.expected.some(e=>equivalent(input,e,node.linearContract.aliases))}
 function recognizes(node,input){return !!node.linearContract&&!!form(input,node.linearContract.aliases)}
 return {parse,equivalent,accepts,recognizes};
})();
if(typeof module!=='undefined')module.exports=RelationExpression;
