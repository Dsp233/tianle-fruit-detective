/* Twenty complete teaching routes that replace the remaining one-question previews. */
'use strict';
const Q=(phase,mode,prompt,details)=>({phase,mode,prompt,...details});
const REMAINING_COURSES={
 A03:{title:'分数、小数与数轴',icon:'🍫',stage:'桥梁',steps:[
  Q('学','gridSelect','把4格中的3格点亮，表示 3/4。',{cols:4,rows:1,answer:[0,1,2],cue:true,boardTitle:'点亮分数条',hint:'分母4表示一共4格；分子3表示点亮3格。',explain:'一共4格，点亮3格，就是3/4。'}),
  Q('学','choice','同样大的两块巧克力，哪份更多？',{scene:{type:'fractions',values:[[3,4],[2,4]]},options:['3/4','2/4','一样多'],answer:0,hint:'每块都分成4份，只比较涂色份数。',explain:'分母相同，3份比2份多，所以3/4更大。'}),
  Q('学','choice','数轴从0到1平均分成4段。1/2在哪个点？',{scene:{type:'line',labels:['0','1/4','1/2','3/4','1']},options:['第1个中间点','正中间','最后一个中间点'],answer:1,hint:'一半在0和1的正中间。',explain:'1/2就在0和1的正中间。'}),
  Q('学','choice','哪一个小数和 1/2 一样大？',{scene:{type:'fractions',values:[[1,2],[2,4]]},options:['0.2','0.5','1.2'],answer:1,hint:'把1平均分成10份，一半是其中5份。',explain:'1/2＝5/10＝0.5。'}),
  Q('练','choice','哪一个分数和 0.6 一样大？',{scene:{type:'grid',cols:10,rows:1,fill:6},options:['3/5','2/5','3/10'],answer:0,hint:'0.6是6/10，把分子分母同时除以2。',explain:'6/10＝3/5，所以0.6和3/5一样大。'}),
  Q('练','choice','2/3 和 3/5，哪一个更大？',{scene:{type:'fractions',values:[[2,3],[3,5]]},options:['2/3','3/5','一样大'],answer:0,hint:'把两条分数条想成同样长，再比较涂色终点。',explain:'2/3约是0.67，3/5是0.6，所以2/3更大。'}),
  Q('测','sequence','从小到大排好：3/4、1/4、1/2。',{pattern:[],palette:['3/4','1/4','1/2'],answer:['1/4','1/2','3/4'],boardTitle:'依次点选三个分数',explain:'四分之一、二分之一、四分之三依次变大。'}),
  Q('测','number','3/4 写成小数是多少？',{scene:{type:'fractions',values:[[3,4]]},answer:.75,explain:'3÷4＝0.75。'})
 ]},
 A04:{title:'百分数与估算',icon:'💯',stage:'桥梁',steps:[
  Q('学','number','20格中涂了10格，占百分之几？',{scene:{type:'grid',cols:10,rows:2,fill:10},answer:50,hint:'涂色刚好占一半。',explain:'一半就是50%。'}),
  Q('学','gridSelect','20格中点亮5格，表示25%。',{cols:5,rows:4,answer:[0,1,2,3,4],cue:true,boardTitle:'点亮四分之一',hint:'20的四分之一是5。',explain:'5÷20＝1/4＝25%。'}),
  Q('学','number','20颗星的75%是多少颗？',{scene:{type:'grid',cols:10,rows:2,fill:15},answer:15,hint:'75%是四分之三；20分成4份，每份5。',explain:'20的3/4是15。'}),
  Q('学','choice','49×21 大约是多少？',{scene:{type:'equation',tokens:['49','×','21','≈','?']},options:['100','1000','10000'],answer:1,hint:'把49看成50，把21看成20。',explain:'50×20＝1000，所以49×21约为1000。'}),
  Q('练','number','80的10%是多少？',{scene:{type:'equation',tokens:['80','×','10%','=','?']},answer:8,hint:'10%就是十分之一。',explain:'80÷10＝8。'}),
  Q('练','number','12的25%是多少？',{scene:{type:'dots',groups:[['全部','●',12]]},answer:3,hint:'25%就是四分之一。',explain:'12÷4＝3。'}),
  Q('测','number','10个方格的60%是多少格？',{scene:{type:'grid',cols:10,rows:1,fill:6},answer:6,explain:'60%＝6/10，所以是6格。'}),
  Q('测','choice','198＋301 最接近多少？',{scene:{type:'equation',tokens:['198','＋','301','≈','?']},options:['50','500','5000'],answer:1,explain:'198约200，301约300，合起来约500。'})
 ]},
 A05:{title:'负数、平方与平方根',icon:'🪜',stage:'桥梁',steps:[
  Q('学','choice','数轴上谁更大？',{scene:{type:'line',labels:['−5','−4','−3','−2','−1','0']},options:['−5','−2','一样大'],answer:1,hint:'数轴上越靠右越大。',explain:'−2在−5右边，所以−2更大。'}),
  Q('学','lineWalk','从 −2 出发，每次向右走1格，亲手走5格。',{start:-2,target:3,min:-4,max:5,hint:'向右每走一格加1。',explain:'−2→−1→0→1→2→3，共走5格。'}),
  Q('学','number','边长4格的正方形有多少小格？',{scene:{type:'grid',cols:4,rows:4,fill:16},answer:16,hint:'4行，每行4格。',explain:'4×4＝4²＝16。'}),
  Q('学','choice','哪个数自己乘自己等于16？',{scene:{type:'equation',tokens:['□','×','□','=','16']},options:['2','4','8'],answer:1,hint:'试一试4×4。',explain:'4×4＝16，所以16的正平方根是4。'}),
  Q('练','choice','−3 和 1，谁更大？',{scene:{type:'line',labels:['−3','−2','−1','0','1']},options:['−3','1','一样大'],answer:1,hint:'1在0右边，−3在0左边。',explain:'1比−3大。'}),
  Q('练','number','−4＋7 等于几？',{scene:{type:'line',labels:['−4','−3','−2','−1','0','1','2','3']},answer:3,hint:'从−4向右走7格。',explain:'走到3，所以−4＋7＝3。'}),
  Q('测','number','5² 等于几？',{scene:{type:'grid',cols:5,rows:5,fill:25},answer:25,explain:'5²＝5×5＝25。'}),
  Q('测','number','哪个正数自己乘自己等于49？',{scene:{type:'equation',tokens:['□','×','□','=','49']},answer:7,explain:'7×7＝49。'})
 ]},
 R02:{title:'单位率与单位换算',icon:'🪙',stage:'桥梁',steps:[
  Q('学','redistribute','8枚钱币对应4个苹果。把钱币平均分到每个苹果下。',{values:[8,0,0,0,0],pileLabels:['钱箱','苹果1','苹果2','苹果3','苹果4'],answer:[0,2,2,2,2],hint:'钱箱里的8枚钱币要分给4个苹果，每个一样多。',explain:'四个苹果各分得2枚钱币；每个苹果2元。'}),
  Q('学','number','3包共有12支笔。每包几支？',{scene:{type:'equation',tokens:['12支','÷','3包','=','?']},answer:4,hint:'平均分成3份。',explain:'12÷3＝4支/包。'}),
  Q('学','number','2米等于多少厘米？',{scene:{type:'table',rows:[['1米','100厘米'],['2米','?厘米']]},answer:200,hint:'每1米是100厘米。',explain:'2×100＝200厘米。'}),
  Q('学','choice','90分钟等于多久？',{scene:{type:'table',rows:[['60分钟','1小时'],['再30分钟','半小时']]},options:['1小时30分','90小时','30分钟'],answer:0,hint:'先拿出60分钟。',explain:'90分钟＝60分钟＋30分钟＝1小时30分。'}),
  Q('练','number','2小时走10千米。平均每小时走几千米？',{scene:{type:'equation',tokens:['10千米','÷','2小时','=','?']},answer:5,hint:'求每1小时的路程。',explain:'10÷2＝5千米/小时。'}),
  Q('练','number','3杯面粉做12张饼。每杯做几张？',{scene:{type:'dots',groups:[['面粉','🥣',3],['饼','🥞',12]]},answer:4,hint:'把12张平均分给3杯。',explain:'12÷3＝4张/杯。'}),
  Q('测','number','240厘米等于多少米？',{scene:{type:'table',rows:[['100厘米','1米'],['240厘米','?米']]},answer:2.4,explain:'240÷100＝2.4米。'}),
  Q('测','number','6瓶水共18元。每瓶几元？',{scene:{type:'equation',tokens:['18元','÷','6瓶','=','?']},answer:3,explain:'18÷6＝3元/瓶。'})
 ]},
 R03:{title:'行程、时间与共同工作',icon:'🚶',stage:'进阶',steps:[
  Q('学','number','骑车10分钟走2千米。同速骑30分钟，走几千米？',{scene:{type:'strips',groups:[['第1段','🚴',2],['第2段','🚴',2],['第3段','🚴',2]]},answer:6,hint:'30分钟里有3个10分钟。',explain:'2＋2＋2＝6千米。'}),
  Q('学','number','每小时走4千米，2小时走几千米？',{scene:{type:'table',rows:[['同样的时间','第1小时','第2小时'],['各走路程','4千米','4千米'],['累计','4千米','?千米']]},answer:8,hint:'每小时4千米，按相同时间段重复2次。',explain:'同样一小时各走4千米，4＋4＝8千米。'}),
  Q('学','number','12千米，每小时3千米，要走几小时？',{scene:{type:'table',rows:[['每小时','1','2','3','4'],['累计千米','3','6','9','12']]},answer:4,hint:'逐列找到累计12千米的位置，单位是小时。',explain:'每小时走3千米，走到12千米共4小时。'}),
  Q('学','number','机器每分钟贴6张标签，3分钟贴几张？',{scene:{type:'strips',groups:[['第1分钟','🏷️',6],['第2分钟','🏷️',6],['第3分钟','🏷️',6]]},answer:18,hint:'三个6相加。',explain:'6×3＝18张。'}),
  Q('练','number','速度30千米/时，走2小时，路程多少？',{scene:{type:'equation',tokens:['30','×','2','=','?']},answer:60,hint:'速度乘时间。',explain:'30×2＝60千米。'}),
  Q('练','number','甲每分钟做3个，乙每分钟做2个。一起每分钟做几个？',{scene:{type:'table',rows:[['同一分钟','甲','乙','一起'],['完成个数','3','2','?']]},answer:5,hint:'先确认两人都工作同一分钟，再合并成果。',explain:'同一分钟的产量相加，3＋2＝5个/分钟。'}),
  Q('测','number','两人合做每分钟5个。做15个要几分钟？',{scene:{type:'equation',tokens:['15','÷','5','=','?']},answer:3,explain:'15÷5＝3分钟。'}),
  Q('测','number','4个人每人做2个盒子，共做几个？',{scene:{type:'dots',groups:[['工人','👷',4],['每人盒子','📦',2]]},answer:8,explain:'4×2＝8个盒子。'})
 ]},
 R04:{title:'比例缩放与变化',icon:'🔎',stage:'进阶',steps:[
  Q('学','number','2×3方格，长宽都放大2倍，新面积多少？',{scene:{type:'rectangles',values:[[2,3],[4,6]]},answer:24,hint:'新长4、新宽6。',explain:'4×6＝24；面积变成原来的4倍。'}),
  Q('学','number','2杯面粉做3个蛋糕。4杯做几个？',{scene:{type:'table',rows:[['面粉','2杯','4杯'],['蛋糕','3个','?']]},answer:6,hint:'面粉变2倍，蛋糕数也变2倍。',explain:'3×2＝6个。'}),
  Q('学','number','地图1厘米代表5千米。3厘米代表几千米？',{scene:{type:'table',rows:[['地图','1厘米','3厘米'],['实际','5千米','?']]},answer:15,hint:'3个5千米。',explain:'5×3＝15千米。'}),
  Q('学','choice','2×3长方形放大3倍，边长变成哪组？',{scene:{type:'rectangles',values:[[2,3],[6,9]]},options:['6和9','4和6','5和6'],answer:0,hint:'两条边都乘3。',explain:'2×3＝6，3×3＝9。'}),
  Q('练','number','红2蓝3。红放大到6，蓝要变成几？',{scene:{type:'dots',groups:[['原红','🔴',2],['原蓝','🔵',3],['新红','🔴',6]]},answer:9,hint:'红变成3倍，蓝也乘3。',explain:'3×3＝9。'}),
  Q('练','choice','正方形边长放大2倍，面积变成几倍？',{scene:{type:'rectangles',values:[[2,2],[4,4]]},options:['2倍','4倍','8倍'],answer:1,hint:'比较4×4和2×2。',explain:'面积从4变16，是4倍。'}),
  Q('测','number','三角形一边5厘米，整体放大2倍，这条边多长？',{scene:{type:'triangle',labels:['5','×2','?']},answer:10,explain:'所有长度都乘2，5×2＝10。'}),
  Q('测','number','4杯果汁配10块冰。6杯按同样比例配几块冰？',{scene:{type:'table',rows:[['果汁','4杯','6杯'],['冰','10块','?']]},answer:15,explain:'每杯2.5块，6杯需要15块；也可把4:10约成2:5。'})
 ]},
 L02:{title:'多步方程与整数约束',icon:'🎒',stage:'进阶',steps:[
  Q('学','number','两袋一样多，再加3个，共13个。每袋几个？',{scene:{type:'equation',tokens:['□','＋','□','＋','3','=','13']},answer:5,hint:'先去掉3，再把10平分两份。',explain:'(13－3)÷2＝5。'}),
  Q('学','number','3袋一样多，再加2个，共17个。每袋几个？',{scene:{type:'equation',tokens:['3×□','＋','2','=','17']},answer:5,hint:'先减2，剩15；再分3袋。',explain:'(17－2)÷3＝5。'}),
  Q('学','number','一个数先除以3，再加2，得到6。这个数是几？',{scene:{type:'equation',tokens:['□','÷','3','＋','2','=','6']},answer:12,hint:'倒着做：先6减2，再乘3。',explain:'(6－2)×3＝12。'}),
  Q('学','choice','2×一个整数，可能得到奇数吗？',{scene:{type:'tiles',tokens:['2×1=2','2×2=4','2×3=6']},options:['不可能','一定可能','只有乘3可能'],answer:0,hint:'两个一组，总会刚好配对。',explain:'2乘任何整数都是偶数，不会得到奇数。'}),
  Q('练','number','4×□－3＝17。□是多少？',{scene:{type:'equation',tokens:['4×□','－','3','=','17']},answer:5,hint:'先给17加回3，再除以4。',explain:'(17＋3)÷4＝5。'}),
  Q('练','number','3×(□＋2)＝21。□是多少？',{scene:{type:'equation',tokens:['3×','(','□＋2',')','=','21']},answer:5,hint:'先21÷3＝7，再7－2。',explain:'□＋2＝7，所以□＝5。'}),
  Q('测','number','5×□＋4＝29。□是多少？',{scene:{type:'equation',tokens:['5×□','＋','4','=','29']},answer:5,explain:'先29－4＝25，再25÷5＝5。'}),
  Q('测','number','两个连续整数相加是11，较小的是几？',{scene:{type:'equation',tokens:['□','＋','下一个数','=','11']},answer:5,explain:'5和6连续，5＋6＝11。'})
 ]},
 L04:{title:'表格、坐标与函数',icon:'📈',stage:'进阶',steps:[
  Q('学','number','表格按“乘2再加1”。输入4，输出多少？',{scene:{type:'table',rows:[['输入','1','2','3','4'],['输出','3','5','7','?']]},answer:9,hint:'4×2＋1。',explain:'4×2＋1＝9。'}),
  Q('学','choice','点(2,1)表示什么？',{scene:{type:'coordinate',points:[[2,1,'A']]},options:['先向右2，再向上1','先向右1，再向上2','停在原点'],answer:0,hint:'坐标先横后竖。',explain:'(2,1)先读横坐标2，再读纵坐标1。'}),
  Q('学','number','规则是“输入＋3”。输入5，输出多少？',{scene:{type:'table',rows:[['输入','2','4','5'],['输出','5','7','?']]},answer:8,hint:'把5加3。',explain:'5＋3＝8。'}),
  Q('学','choice','哪条规则符合表格？',{scene:{type:'table',rows:[['输入','1','2','3'],['输出','4','5','6']]},options:['加3','乘3','减3'],answer:0,hint:'逐列比较输入和输出。',explain:'每个输出都比输入大3。'}),
  Q('练','number','输入1、2、3对应输出4、7、10。输入4输出多少？',{scene:{type:'table',rows:[['输入','1','2','3','4'],['输出','4','7','10','?']]},answer:13,hint:'输出每次增加3。',explain:'10再加3是13；规则也可写成3×输入＋1。'}),
  Q('练','choice','点(1,2)向右移动3格，会到哪里？',{scene:{type:'coordinate',points:[[1,2,'起点'],[4,2,'?']]},options:['(4,2)','(1,5)','(3,2)'],answer:0,hint:'向右只改变第一个数。',explain:'横坐标1＋3＝4，纵坐标仍是2。'}),
  Q('测','number','规则是3×输入＋1。输入3，输出多少？',{scene:{type:'equation',tokens:['3×3','＋','1','=','?']},answer:10,explain:'9＋1＝10。'}),
  Q('测','choice','表格输入2、4、6，输出1、2、3。规则是什么？',{scene:{type:'table',rows:[['输入','2','4','6'],['输出','1','2','3']]},options:['除以2','加2','乘2'],answer:0,explain:'每个输入除以2得到输出。'})
 ]},
 N02:{title:'质数、因数与因数个数',icon:'🧱',stage:'进阶',steps:[
  Q('学','multi','点出12的所有正因数。',{scene:{type:'equation',tokens:['1×12','2×6','3×4']},options:['1','2','3','4','5','6','12'],answer:[0,1,2,3,5,6],hint:'把每一对乘数都收集起来。',explain:'12的正因数是1、2、3、4、6、12。'}),
  Q('学','choice','7是质数吗？',{scene:{type:'equation',tokens:['1×7']},options:['是','不是'],answer:0,hint:'除了1和7，还能整除吗？',explain:'7只有1和7两个正因数，所以是质数。'}),
  Q('学','number','12有几个正因数？',{scene:{type:'equation',tokens:['1×12','2×6','3×4']},answer:6,hint:'三对中共有六个不同的数。',explain:'1、2、3、4、6、12，共6个。'}),
  Q('学','choice','哪一个不是质数？',{scene:{type:'tiles',tokens:['2','3','4','5']},options:['2','3','4','5'],answer:2,hint:'试试能否排成不止一种长方形。',explain:'4除了1和4，还有因数2，所以不是质数。'}),
  Q('练','multi','点出18的所有正因数。',{scene:{type:'equation',tokens:['1×18','2×9','3×6']},options:['1','2','3','6','9','12','18'],answer:[0,1,2,3,4,6],hint:'三对乘数全部收集，不要选12。',explain:'18的正因数是1、2、3、6、9、18。'}),
  Q('练','number','20有几个正因数？',{scene:{type:'equation',tokens:['1×20','2×10','4×5']},answer:6,hint:'数三对不同的乘数。',explain:'1、2、4、5、10、20，共6个。'}),
  Q('测','choice','29是质数吗？',{scene:{type:'tiles',tokens:['29']},options:['是','不是'],answer:0,explain:'29不能被2、3或5整除，只有1和29两个正因数。'}),
  Q('测','number','36有几个正因数？',{scene:{type:'equation',tokens:['1×36','2×18','3×12','4×9','6×6']},answer:9,explain:'因数是1、2、3、4、6、9、12、18、36，共9个；6只数一次。'})
 ]},
 N03:{title:'公因数与公倍数',icon:'🔔',stage:'进阶',steps:[
  Q('学','cycleOverlap','红灯每6分钟亮，蓝灯每8分钟亮。点出下一次两灯同时亮的时刻。',{periods:[6,8],max:32,answer:24,hint:'观察每个时刻的红灯、蓝灯；两盏同亮要找第一次。',explain:'第24分钟两种周期首次重合；第0分钟是出发时，不算下一次。'}),
  Q('学','number','12和18的最大公因数是多少？',{scene:{type:'table',rows:[['12的因数','1','2','3','4','6','12'],['18的因数','1','2','3','6','9','18']]},answer:6,hint:'找两行共有的最大数。',explain:'共有因数1、2、3、6，最大是6。'}),
  Q('学','number','两个动作每4拍、每6拍重复。几拍后一起回到起点？',{scene:{type:'table',rows:[['4拍','4','8','12'],['6拍','6','12','18']]},answer:12,hint:'找第一个共同倍数。',explain:'4和6的最小公倍数是12。'}),
  Q('学','choice','求“下一次同时发生”，通常找什么？',{scene:{type:'tiles',tokens:['共同周期','第一次重合']},options:['最小公倍数','最大公因数','两个数相加'],answer:0,hint:'要找两个周期都能整除的最早时间。',explain:'最早共同时间对应最小公倍数。'}),
  Q('练','number','24和36的最大公因数是多少？',{scene:{type:'equation',tokens:['24＝2×12','36＝3×12']},answer:12,hint:'找能同时整除两数的最大数。',explain:'24÷12＝2，36÷12＝3，所以最大公因数是12。'}),
  Q('练','number','每5分钟和每8分钟响一次，几分钟后再一起响？',{scene:{type:'table',rows:[['5分','5','10','15','20','25','30','35','40'],['8分','8','16','24','32','40']]},answer:40,hint:'找第一个共同出现的时间。',explain:'5和8的最小公倍数是40。'}),
  Q('测','number','两铃每6分钟、9分钟响一次。多久后再同响？',{scene:{type:'table',rows:[['6分','6','12','18'],['9分','9','18','27']]},answer:18,explain:'6和9的最小公倍数是18。'}),
  Q('测','number','12×18长方形铺最大正方形砖，砖边长多少？',{scene:{type:'equation',tokens:['12÷□','18÷□','都整除']},answer:6,explain:'最大边长要同时整除12和18，即最大公因数6。'})
 ]},
 N04:{title:'余数、末位与循环',icon:'🔄',stage:'桥梁',steps:[
  Q('学','choice','今天星期五。再过两天是星期几？',{scene:{type:'sequence',tokens:['周五','→','周六','→','?']},options:['星期日','星期一','星期三'],answer:0,hint:'一天后周六，再一天。',explain:'周五后两天是星期日。'}),
  Q('学','number','17颗糖，每5颗一袋，最后剩几颗？',{scene:{type:'equation',tokens:['17','÷','5','=','3袋','余?']},answer:2,hint:'3袋装15颗。',explain:'17＝5×3＋2，余2颗。'}),
  Q('学','choice','2的乘方末位按2、4、8、6循环。2⁵末位是几？',{scene:{type:'sequence',tokens:['2','4','8','6','2','?']},options:['2','4','6'],answer:0,hint:'四个一组，2⁵回到第一项。',explain:'2⁵＝32，末位是2。'}),
  Q('学','number','100除以3，余数是多少？',{scene:{type:'equation',tokens:['100','=','3×33','＋','?']},answer:1,hint:'3×33＝99。',explain:'100＝99＋1，所以余1。'}),
  Q('练','choice','今天星期一。10天后星期几？',{scene:{type:'sequence',tokens:['7天后仍周一','再3天','?']},options:['星期四','星期三','星期五'],answer:0,hint:'10除以7余3。',explain:'周一往后3天是周四。'}),
  Q('练','number','29除以4，余数是多少？',{scene:{type:'equation',tokens:['29','=','4×7','＋','?']},answer:1,hint:'4×7＝28。',explain:'29＝28＋1，所以余1。'}),
  Q('测','number','3的乘方末位按3、9、7、1循环。3⁵末位是几？',{scene:{type:'sequence',tokens:['3','9','7','1','?']},answer:3,explain:'每4次循环，3⁵回到末位3。'}),
  Q('测','choice','一个数加2后，奇偶性怎样？',{scene:{type:'tiles',tokens:['奇＋2＝奇','偶＋2＝偶']},options:['不变','一定变奇','一定变偶'],answer:0,explain:'加上一个偶数不会改变奇偶性。'})
 ]},
 G02:{title:'角、三角形与多边形',icon:'📐',stage:'进阶',steps:[
  Q('学','number','三角形两个角是50°和60°，第三个角几度？',{scene:{type:'triangle',labels:['50°','60°','?']},answer:70,hint:'三个角一共180°。',explain:'180－50－60＝70°。'}),
  Q('学','choice','哪个角是直角？',{scene:{type:'tiles',tokens:['45°','90°','120°']},options:['45°','90°','120°'],answer:1,hint:'正方形的角就是直角。',explain:'直角是90°。'}),
  Q('学','number','四边形四个内角一共多少度？',{scene:{type:'tiles',tokens:['△＋△','两个三角形']},answer:360,hint:'从一个顶点画对角线，分成两个三角形。',explain:'2×180°＝360°。'}),
  Q('学','number','一条直线上的两个邻角，一个70°，另一个几度？',{scene:{type:'equation',tokens:['70°','＋','?','＝','180°']},answer:110,hint:'平角是180°。',explain:'180－70＝110°。'}),
  Q('练','number','三角形两个角是35°和65°，第三个角几度？',{scene:{type:'triangle',labels:['35°','65°','?']},answer:80,hint:'用180减去两个已知角。',explain:'180－35－65＝80°。'}),
  Q('练','choice','正方形的每个内角是多少度？',{scene:{type:'grid',cols:2,rows:2,fill:4},options:['45°','90°','120°'],answer:1,hint:'四个角合计360°，且一样大。',explain:'360÷4＝90°。'}),
  Q('测','number','等腰三角形两个底角都是55°，顶角几度？',{scene:{type:'triangle',labels:['55°','55°','?']},answer:70,explain:'180－55－55＝70°。'}),
  Q('测','number','五边形从一个顶点可分成3个三角形，内角和多少度？',{scene:{type:'equation',tokens:['3','×','180°','=','?']},answer:540,explain:'3×180°＝540°。'})
 ]},
 G04:{title:'圆与弧',icon:'⭕',stage:'桥梁',steps:[
  Q('学','number','半径3格。直径长几格？',{scene:{type:'circle',radius:3,label:'半径3'},answer:6,hint:'直径由两段半径组成。',explain:'3＋3＝6。'}),
  Q('学','choice','沿圆边把整圈平均分四段。高亮的一段叫弧，占整圈多少？',{scene:{type:'circleArc',segments:4,active:1},options:['1/4','1/2','4倍'],answer:0,hint:'只看圆边，高亮一段；四段一样长。',explain:'这段弧占整个圆周的1/4；弧指圆边的一部分，不是扇形面积。'}),
  Q('学','choice','圆周长用哪条式子？',{scene:{type:'circle',radius:3,label:'直径 d'},options:['π×直径','π＋直径','直径×直径'],answer:0,hint:'圆周长约是直径的3.14倍。',explain:'圆周长C＝πd。'}),
  Q('学','choice','圆面积用哪条式子？',{scene:{type:'circle',radius:3,label:'半径 r'},options:['πr²','2πr','π＋r'],answer:0,hint:'面积与半径的平方有关。',explain:'圆面积A＝πr²。'}),
  Q('练','number','直径6，取π≈3.14，周长是多少？',{scene:{type:'equation',tokens:['3.14','×','6','=','?']},answer:18.84,hint:'周长＝π×直径。',explain:'3.14×6＝18.84。'}),
  Q('练','choice','沿圆边走四分之一圈，走的是哪段弧？',{scene:{type:'circleArc',segments:4,active:1},options:['整圈的1/4','整圈的1/2','整圈'],answer:0,hint:'圆周平均分四段，高亮了其中一段。',explain:'弧是圆边的一段；这一段占整圈周长的1/4。'}),
  Q('测','number','圆的整圈周长是20厘米，沿四分之一圆弧走几厘米？',{scene:{type:'circleArc',segments:4,active:1,label:'整圈 20 厘米'},answer:5,explain:'圆周四等分，四分之一圆弧长20÷4＝5厘米。'}),
  Q('测','number','直径10，取π≈3.14，周长是多少？',{scene:{type:'equation',tokens:['3.14','×','10','=','?']},answer:31.4,explain:'3.14×10＝31.4。'})
 ]},
 G05:{title:'相似与缩放',icon:'🔬',stage:'进阶',steps:[
  Q('学','choice','正方形边长放大2倍，面积变成几倍？',{scene:{type:'rectangles',values:[[2,2],[4,4]]},options:['2倍','4倍','8倍'],answer:1,hint:'比较4×4和2×2。',explain:'面积从4变16，是4倍。'}),
  Q('学','choice','2×3长方形按3倍放大，变成哪一个？',{scene:{type:'rectangles',values:[[2,3],[6,9]]},options:['6×9','5×6','4×6'],answer:0,hint:'两条边都乘3。',explain:'2×3＝6，3×3＝9。'}),
  Q('学','number','三角形一边5，整体放大2倍，这条边变成几？',{scene:{type:'triangle',labels:['5','×2','?']},answer:10,hint:'相似图形对应边用同一倍数。',explain:'5×2＝10。'}),
  Q('学','choice','哪两组边长比例相同？',{scene:{type:'table',rows:[['图A','2','3'],['图B','4','6'],['图C','4','5']]},options:['A和B','A和C','B和C'],answer:0,hint:'A的两条边都乘2。',explain:'2:3＝4:6，所以A和B相似。'}),
  Q('练','number','4×6图形放大1.5倍，长边变成几？',{scene:{type:'rectangles',values:[[4,6],[6,9]]},answer:9,hint:'6×1.5。',explain:'6×1.5＝9。'}),
  Q('练','choice','图形放大3倍，周长变成几倍？',{scene:{type:'tiles',tokens:['每条边×3']},options:['3倍','6倍','9倍'],answer:0,hint:'周长是所有边长的和。',explain:'每条边都乘3，周长也乘3。'}),
  Q('测','choice','图形放大3倍，面积变成几倍？',{scene:{type:'rectangles',values:[[1,1],[3,3]]},options:['3倍','6倍','9倍'],answer:2,explain:'长和宽都乘3，面积乘3×3＝9。'}),
  Q('测','number','3/4＝6/□。方框填几？',{scene:{type:'equation',tokens:['3','/','4','=','6','/','□']},answer:8,explain:'3变6是乘2，4也乘2得到8。'})
 ]},
 G06:{title:'直角、勾股与坐标',icon:'📍',stage:'进阶',steps:[
  Q('学','number','这是直角三角形。在两条直角边上各画正方形，面积9格和16格，一共几格？',{scene:{type:'pythagoras',legs:[3,4]},answer:25,hint:'分别数3×3和4×4方格，再相加。',explain:'9＋16＝25格；斜边对应的正方形也是25格，所以斜边长5格。'}),
  Q('学','choice','两点(1,2)和(1,6)的连线是什么方向？',{scene:{type:'coordinate',points:[[1,2,'A'],[1,6,'B']]},options:['竖直','水平','斜着'],answer:0,hint:'两个点的横坐标相同。',explain:'横坐标都为1，所以连线竖直。'}),
  Q('学','number','(1,1)到(1,6)相距几格？',{scene:{type:'coordinate',points:[[1,1,'A'],[1,6,'B']]},answer:5,hint:'纵坐标相减。',explain:'6－1＝5格。'}),
  Q('学','choice','哪组边能组成直角三角形？',{scene:{type:'tiles',tokens:['3,4,5','4,4,5','2,3,4']},options:['3,4,5','4,4,5','2,3,4'],answer:0,hint:'检查两短边平方和是否等于长边平方。',explain:'3²＋4²＝5²。'}),
  Q('练','number','直角边6和8，斜边长几？',{scene:{type:'rightTriangle',legs:[6,8]},answer:10,hint:'6²＋8²＝100。',explain:'斜边是10。'}),
  Q('练','number','从一点向右3格、向上4格，直线距离几格？',{scene:{type:'coordinate',points:[[0,0,'起点'],[3,4,'终点']]},answer:5,hint:'横3、竖4组成3-4-5直角三角形。',explain:'3²＋4²＝25，距离5格。'}),
  Q('测','number','直角边5和12，斜边长几？',{scene:{type:'rightTriangle',legs:[5,12]},answer:13,explain:'5²＋12²＝169＝13²。'}),
  Q('测','choice','哪组是直角三角形边长？',{scene:{type:'tiles',tokens:['6,8,10','6,8,9','5,5,8']},options:['6,8,10','6,8,9','5,5,8'],answer:0,explain:'6²＋8²＝10²。'})
 ]},
 G07:{title:'立体与展开',icon:'🎁',stage:'桥梁',steps:[
  Q('学','netFold','把展开图的五个外围面沿边折起。连同中间的 C，纸盒共有几个面？',{scene:{type:'net'},answer:6,hint:'先点 A、B、D、F 四个面；E 与 D 相连，要在 D 折起后再折。',explain:'C 是底面，A、B、D、F 折成四个侧面，E 合在背面，共六面。'}),
  Q('学','number','一个立方体有几个顶点？',{scene:{type:'cube'},answer:8,hint:'上面4个角，下面4个角。',explain:'4＋4＝8个顶点。'}),
  Q('学','number','一个立方体有几条棱？',{scene:{type:'cube'},answer:12,hint:'上面4条、下面4条、竖着4条。',explain:'4＋4＋4＝12条棱。'}),
  Q('学','netSelect','看有字母的纸盒展开图。折起来后，点出中心 C 对面的那一面。',{answer:[4],hint:'把 C 的上下左右邻面向上折，剩下的 E 会合到背面。',explain:'C 的对面是 E；A 与 F、B 与 D 也各成一对，六面不能叠在同一面。'}),
  Q('练','number','长2、宽3、高4的长方体，体积多少？',{scene:{type:'cuboid',dims:[2,3,4]},answer:24,hint:'长×宽×高。',explain:'2×3×4＝24立方单位。'}),
  Q('练','number','边长2的立方体，表面积多少？',{scene:{type:'cube',edge:2},answer:24,hint:'每个面面积4，共6面。',explain:'2×2×6＝24平方单位。'}),
  Q('测','number','长3、宽4、高5的长方体，体积多少？',{scene:{type:'cuboid',dims:[3,4,5]},answer:60,explain:'3×4×5＝60。'}),
  Q('测','number','3×3×3小方块组成大立方体。内部只有1块，外层有几块？',{scene:{type:'cuboid',dims:[3,3,3]},answer:26,explain:'总共27块，减去中心1块，外层26块。'})
 ]},
 C03:{title:'排列、组合与限制',icon:'🧩',stage:'进阶',steps:[
  Q('学','enumerate','把 A、B、C 排成一排。逐个摆出全部不同顺序并记录。',{items:['A','B','C'],slots:3,orderMatters:true,answer:['A|B|C','A|C|B','B|A|C','B|C|A','C|A|B','C|B|A'],hint:'先固定第一位为A，列完后再换B、C；同一个人不能站两个位置。',explain:'固定首位逐个列全，有3×2×1＝6种；交换两人的位置会产生新顺序。'}),
  Q('学','enumerate','A必须在B左边。摆出 A、B、C 的全部合法顺序。',{items:['A','B','C'],slots:3,orderMatters:true,answer:['A|B|C','A|C|B','C|A|B'],hint:'先摆出顺序，再逐个检查A是否在B左边；左边不要求紧挨。',explain:'ABC、ACB、CAB，共3种；每种都有A在B左边。'}),
  Q('学','enumerate','草莓、猕猴桃、香蕉中选两种。摆出全部不同搭配并记录；前后互换算同一组。',{items:['🍓','🥝','🍌'],slots:2,orderMatters:false,answer:['🍓|🥝','🍓|🍌','🥝|🍌'],hint:'固定草莓找两组，再换猕猴桃；草莓猕猴桃和猕猴桃草莓只记一次。',explain:'三种不同的两两组合；选人/选料不分前后。'}),
  Q('学','number','A固定在第一位，B、C、D排后面，有几种？',{scene:{type:'tiles',tokens:['A','□','□','□']},answer:6,hint:'后三个位置排B、C、D。',explain:'3×2×1＝6种。'}),
  Q('练','number','用1、2、3各一次组成三位数，有几个？',{scene:{type:'tiles',tokens:['1','2','3']},answer:6,hint:'第一位3种，第二位2种，最后1种。',explain:'3×2×1＝6个。'}),
  Q('练','number','4位同学中选2位做搭档，有几组？',{scene:{type:'tiles',tokens:['甲','乙','丙','丁']},answer:6,hint:'甲可配3人，乙再配2人，丙再配1人。',explain:'3＋2＋1＝6组。'}),
  Q('测','number','A固定第一位，B、C、D排列，有几种顺序？',{scene:{type:'tiles',tokens:['A','B','C','D']},answer:6,explain:'固定A后，剩3人有3×2×1＝6种。'}),
  Q('测','number','A和B必须相邻，A、B、C、D排成一排，有几种？',{scene:{type:'tiles',tokens:['AB当一块','C','D']},answer:12,explain:'AB可看成一块，与C、D共3块排6种；AB内部有2种，6×2＝12。'})
 ]},
 C04:{title:'补集、容斥与计数论证',icon:'🧮',stage:'桥梁',steps:[
  Q('学','number','苹果组5人、香蕉组5人、共同3人。不同的人共几人？',{scene:{type:'fruit'},answer:7,hint:'共同3人被两组都数过，要减一次。',explain:'5＋5－3＝7人。'}),
  Q('学','number','全班10人，参加A或B的有6人。两项都没参加的几人？',{scene:{type:'equation',tokens:['全部10','－','参加6','=','?']},answer:4,hint:'补集是从全部里拿掉已参加的人。',explain:'10－6＝4人。'}),
  Q('学','number','A组12人、B组9人、共同4人。至少参加一组的几人？',{scene:{type:'equation',tokens:['12','＋','9','－','4','=','?']},answer:17,hint:'共同的人重复数了一次。',explain:'12＋9－4＝17人。'}),
  Q('学','choice','直接算5＋5＝10，错误在哪里？',{scene:{type:'fruit'},options:['共同3人算了两次','只苹果2人不能算','只香蕉2人不能算'],answer:0,hint:'橙色小朋友在哪两组里？',explain:'共同3人同时在两组里，直接相加会重复。'}),
  Q('练','number','20天中有7天下雨。不下雨有几天？',{scene:{type:'equation',tokens:['20','－','7','=','?']},answer:13,hint:'从全部天数中减去雨天。',explain:'20－7＝13天。'}),
  Q('练','number','美术15人、音乐11人、共同6人。至少参加一项的几人？',{scene:{type:'equation',tokens:['15','＋','11','－','6','=','?']},answer:20,hint:'共同6人只保留一次。',explain:'15＋11－6＝20人。'}),
  Q('测','number','喜欢苹果18人、香蕉14人、两种都喜欢5人。不同的人几人？',{scene:{type:'equation',tokens:['18','＋','14','－','5','=','?']},answer:27,explain:'18＋14－5＝27人。'}),
  Q('测','number','苹果18人、香蕉14人、共同5人。只喜欢一种的共几人？',{scene:{type:'equation',tokens:['18－5','＋','14－5','=','?']},answer:22,explain:'只苹果13人，只香蕉9人，共22人。'})
 ]},
 S01:{title:'对称、旋转、翻折与剪纸',icon:'🦋',stage:'桥梁',steps:[
  Q('学','choice','沿中间竖线对折，左上角的点到哪里？',{scene:{type:'mirror'},options:['右上角','左下角','右下角'],answer:0,hint:'左右交换，高度不变。',explain:'点落在右上角。'}),
  Q('学','number','正方形有几条对称轴？',{scene:{type:'grid',cols:2,rows:2,fill:4},answer:4,hint:'竖、横和两条对角线。',explain:'正方形有4条对称轴。'}),
  Q('学','choice','箭头↑顺时针转90°，指向哪里？',{scene:{type:'tiles',tokens:['↑','顺时针90°','?']},options:['→','←','↓'],answer:0,hint:'像钟表指针从12走到3。',explain:'向上顺时针转90°后向右。'}),
  Q('学','gridSelect','4列2行的纸沿中间竖线对折，左上格打孔。展开后点出右侧对应孔的位置。',{cols:4,rows:2,marked:[0],answer:[3],boardTitle:'折线两边的孔',hint:'左上格离折线两格，另一边也离折线两格，且仍在上面。',explain:'展开后右上格也有孔；沿竖线翻折时左右互换，高度不变。'}),
  Q('练','gridSelect','折好的纸在左下格剪一个小角。展开后右侧哪格会出现同样的切口？',{cols:4,rows:2,marked:[4],answer:[7],boardTitle:'剪开再展开',hint:'翻折只换左右，左下格的镜像在右下格。',explain:'剪口穿过两层纸，展开后左右对称；右下格有相同切口。'}),
  Q('练','choice','箭头→旋转180°，指向哪里？',{scene:{type:'tiles',tokens:['→','转半圈','?']},options:['←','↑','→'],answer:0,hint:'半圈会指向相反方向。',explain:'向右转180°后向左。'}),
  Q('测','number','正六边形有几条对称轴？',{scene:{type:'tiles',tokens:['⬡']},answer:6,explain:'三条穿过相对顶点，三条穿过相对边中点，共6条。'}),
  Q('测','choice','图形只平移，不旋转，方向会改变吗？',{scene:{type:'tiles',tokens:['➡️','平移','➡️']},options:['不会','一定会','只上下移动会'],answer:0,explain:'平移只改变位置，不改变朝向和大小。'})
 ]},
 S02:{title:'约束、奇偶与不变量',icon:'🧭',stage:'进阶',steps:[
  Q('学','choice','A紧挨B左边，C不在中间。哪种顺序符合？',{scene:{type:'tiles',tokens:['①','②','③']},options:['A—B—C','C—B—A','B—A—C'],answer:0,hint:'先把AB看成一块，A必须在左。',explain:'A—B—C满足两条条件。'}),
  Q('学','choice','奇数＋奇数是什么数？',{scene:{type:'dots',groups:[['奇数','●',3],['奇数','●',5]]},options:['偶数','奇数','不确定'],answer:0,hint:'每组各剩一个，两个剩下的可以配成一对。',explain:'奇数＋奇数＝偶数。'}),
  Q('学','parityMoves','从3开始，每次加2。自己操作3次，选每一步始终保持的奇偶性。',{start:3,delta:2,moves:3,answer:'奇',hint:'每次多出一对，原来未配对的那个点还在。',explain:'3→5→7→9始终是奇数；反复加2不会改变奇偶性。'}),
  Q('学','parityMoves','从12个点开始，每次拿走2个。操作5次，选每一步始终保持的奇偶性。能只剩1个吗？',{start:12,delta:-2,moves:5,answer:'偶',hint:'每拿走一对，剩下的点仍能两两配对。',explain:'12→10→8→6→4→2，都为偶数；再拿一对到0，也不能剩1。'}),
  Q('练','choice','A在B左边，D必须最后。哪种排列符合？',{scene:{type:'tiles',tokens:['A','B','C','D']},options:['C—A—B—D','B—A—C—D','A—D—B—C'],answer:0,hint:'先检查D，再检查A和B。',explain:'第一项中D最后，且A在B左边。'}),
  Q('练','choice','奇数＋偶数是什么数？',{scene:{type:'dots',groups:[['奇数','●',5],['偶数','●',4]]},options:['奇数','偶数','不确定'],answer:0,hint:'偶数能全部配对，奇数仍剩一个。',explain:'奇数＋偶数＝奇数。'}),
  Q('测','choice','棋子每次移动3格。走奇数次后，总步数是奇数还是偶数？',{scene:{type:'equation',tokens:['3','×','奇数次']},options:['奇数','偶数','不一定'],answer:0,explain:'奇数乘奇数仍是奇数。'}),
  Q('测','choice','从偶数开始，每次加4，可能到奇数吗？',{scene:{type:'sequence',tokens:['2','6','10','14']},options:['不可能','一定可以','第二次可以'],answer:0,explain:'每次加偶数，奇偶性保持不变。'})
 ]}
};
for(const [code,course] of Object.entries(REMAINING_COURSES)){
 course.code=code;
 course.steps=course.steps.map((step,i)=>({...step,id:`${code}-${i+1}`}));
}
if(typeof module!=='undefined')module.exports={REMAINING_COURSES};
