"""Restore bundled RC67 source while preserving the original shallow boundary."""
import argparse
import re
import subprocess
from pathlib import Path


def run(*command, cwd=None):
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result.stdout.strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path, help='new, non-existing source directory')
    parser.add_argument('--bundle', type=Path, default=Path(__file__).with_name('rc67-source.bundle'))
    parser.add_argument('--boundaries', type=Path, default=Path(__file__).with_name('rc67-source.shallow'))
    args = parser.parse_args()
    destination = args.directory.resolve()
    if destination.exists():
        parser.error('Destination already exists; choose a new directory')
    bundle = args.bundle.resolve()
    boundaries = args.boundaries.read_text().splitlines()
    if not all(re.fullmatch(r'[0-9a-f]{40}', value) for value in boundaries):
        parser.error('Invalid original shallow boundary metadata')
    branch = 'refs/heads/experiment/rc67-full-local'
    heads = [line.split() for line in run('git', 'bundle', 'list-heads', str(bundle)).splitlines()]
    head = next((oid for oid, ref in heads if ref == branch), None)
    if head is None:
        parser.error('The RC67 source branch is missing from this bundle')
    destination.mkdir(parents=True)
    run('git', 'init', '--quiet', str(destination))
    if boundaries:
        (destination / '.git/shallow').write_text('\n'.join(boundaries) + '\n')
    run('git', 'bundle', 'unbundle', str(bundle), cwd=destination)
    run('git', 'update-ref', branch, head, cwd=destination)
    run('git', 'symbolic-ref', 'HEAD', branch, cwd=destination)
    run('git', 'reset', '--hard', 'HEAD', cwd=destination)
    run('git', 'fsck', '--no-reflogs', cwd=destination)
    print('Restored ' + head + ' to ' + str(destination))
    print('Original shallow boundaries preserved: ' + str(len(boundaries)))


if __name__ == '__main__':
    main()
