"""Record five visually checked 2000 AMC 8 problems after manual solution.

This command only updates the five exact positions and refuses a second overwrite.
The independent reasoning and page references below were checked against the
user supplied scanned PDF on 2026-09-28.
"""
import csv
from pathlib import Path

CASES = {
    'AMC8-2000-01': ('16 (B)', 'Anna 42岁，Brianna是21岁，Caitlin再小5岁，得到16岁。', '第1页原题文字，选项B为16。', '无题图'),
    'AMC8-2000-02': ('−2 (A)', '−2的倒数是−1/2，且−2<−1/2。−1与1等于自己的倒数，0没有倒数，2大于1/2。', '第1页原题及五个选项，选项A为−2。', '无题图'),
    'AMC8-2000-03': ('5 (D)', '5/3介于1与2之间，2π介于6与7之间，严格位于其间的整数是2、3、4、5、6，共5个。', '第1页原题的两个端点及选项D为5。', '无题图'),
    'AMC8-2000-04': ('E', '四个年代对应约5%、8%、15%、30%；逐张读图，第2页E图的折线在四年点对应这些高度。', '题干在第1页，五幅图在第2页；逐图核对横轴与纵轴。', '已核第2页五幅图'),
    'AMC8-2000-05': ('4 (C)', '八年窗口可从某任期末尾开始，接触该任及接下来的三个三年任期，共4任；若接触5任，跨度必须超过9年，因此不可能。', '第2页原题和选项C为4。', '无题图'),
}

target = Path(__file__).resolve().parent.parent / 'docs' / 'exam-review-ledger.csv'
with target.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    fieldnames = reader.fieldnames
    rows = list(reader)
if len(rows) != 500:
    raise ValueError('Full 500 row ledger required')
by_id = {row['examId']: row for row in rows}
if set(CASES) - set(by_id):
    raise ValueError('Missing planned exam position')
for exam_id, (answer, solution, comparison, figure) in CASES.items():
    row = by_id[exam_id]
    if row['reviewStatus'] != '旧记录有独立求解线索，待核对原题与证据':
        raise ValueError(f'Existing review must be preserved: {exam_id}')
    if row['referenceAnswer'] != answer.split('(')[-1].rstrip(')') and row['referenceAnswer'] != answer:
        raise ValueError(f'Reference answer mismatch: {exam_id}')
    row.update(derivedAnswer=answer, independentSolution=solution, figureChecked=figure,
               comparison='独立结果与登记的参考选项一致；' + comparison,
               reviewStatus='已核原题、独立求解、答案一致', reviewerMethod='人工目视原扫描PDF；独立手算/逐图核对',
               reviewedAt='2026-09-28')
with target.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
print('Five original questions visually checked and independently solved; 495 remain without this new review')
