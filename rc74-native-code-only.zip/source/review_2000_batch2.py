"""Record independent visual review of 2000 problems 6–10 (PDF pages 2–4)."""
import csv
from pathlib import Path

CASES = {
    'AMC8-2000-06': ('7 (A)', '外边长1＋3＋1＝5。阴影为边长4的左下区域，去掉边长3的内方格，4²－3²＝7。', '题干第2页，图和选项第3页，L形不重不漏。', '已核第3页尺寸与阴影'),
    'AMC8-2000-07': ('−280 (B)', '三负数乘积−8×−6×−4＝−192；一负两正可取−8×7×5＝−280，更小；含0为0。', '第3页原题，三个数须不同。', '无题图'),
    'AMC8-2000-08': ('41 (D)', '每骰1至6共21点，三颗共63点；图中可见顶1、前2/4/5、右3/6/1，共22点，未见点数63－22＝41。', '第3页原题和三骰图；按可见的七个面逐一数点。', '已核第3页三个骰子七个可见面'),
    'AMC8-2000-09': ('6 (D)', '三位5的幂只有125、625；竖列首位需与三位2的幂的百位相同，125可行而625不行。交叉位是2，横列必须256，末位6。', '第4页交叉格的横、竖位置和三位条件。', '已核第4页交叉格布局'),
    'AMC8-2000-10': ('55 (E)', 'Shea原身高60÷1.2＝50，增长10英寸；Ara同原高50，长了其一半即5英寸，现在55。', '第4页原题百分增长与“增长英寸数的一半”措辞。', '无题图'),
}

target = Path(__file__).resolve().parent.parent / 'docs' / 'exam-review-ledger.csv'
with target.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    names, rows = reader.fieldnames, list(reader)
if len(rows) != 500:
    raise ValueError('Expected the full review ledger')
by_id = {row['examId']: row for row in rows}
for exam_id, (answer, solution, comparison, figure) in CASES.items():
    row = by_id[exam_id]
    if row['reviewStatus'] != '旧记录有独立求解线索，待核对原题与证据':
        raise ValueError('Refusing to replace an existing review: '+exam_id)
    if row['referenceAnswer'] != answer.split('(')[-1].rstrip(')'):
        raise ValueError('Reference answer mismatch: '+exam_id)
    row.update(derivedAnswer=answer, independentSolution=solution, figureChecked=figure,
               comparison='独立结果与登记的参考选项一致；'+comparison,
               reviewStatus='已核原题、独立求解、答案一致', reviewerMethod='人工目视原扫描PDF；独立手算/逐图核对',
               reviewedAt='2026-09-28')
with target.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=names, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
print('Original AMC8 2000 problems 6–10 audited; 10/500 now independently rechecked this round')
