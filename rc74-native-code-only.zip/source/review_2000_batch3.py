"""Independent original-PDF review of 2000 problems 11–16 (pages 4–6)."""
import csv
from pathlib import Path

CASES = {
    'AMC8-2000-11': ('17 (C)', '逐十位列可被其非零个位整除的数：11,12,15；21,22,24,25；31,32,33,35,36；41,42,44,45,48，共3＋4＋5＋5＝17。', '第4页题干，第5页选项C为17。', '无题图'),
    'AMC8-2000-12': ('353 (D)', '一行50块2英尺长砖；相邻行用两端各1块1英尺砖加49块2英尺砖，合51块，竖缝交错。七行交替有4行50、3行51，共353；每行100英尺且再少就不能错缝。', '第5页题干、错缝示意图和选项D。', '已核第5页错缝与两端齐平图'),
    'AMC8-2000-13': ('72° (C)', '顶角36°，C和T底角同为(180°－36°)/2＝72°。TR平分T角，∠CTR＝36°，在三角形CRT内∠CRT＝180°－72°－36°＝72°。', '第5页三角形的R在CA上，角平分线从T出发；C为72°。', '已核第5页R、T位置图'),
    'AMC8-2000-14': ('8 (D)', '19与99的个位都为9，9的奇次幂个位为9；指数19、99均奇，两个个位相加9＋9＝18，个位8。', '第6页两项指数均为奇数，选项D为8。', '无题图'),
    'AMC8-2000-15': ('15 (C)', '大等边三角形边4；D为AC中点使CD＝2，ADE等边使DE＝AE＝2；G为AE中点使AG＝GE＝1，EFG等边使EF＝FG＝1。外轮廓AB＋BC＋CD＋DE＋EF＋FG＋GA＝4＋4＋2＋2＋1＋1＋1＝15。', '第6页原图外轮廓按A-B-C-D-E-F-G-A逐段核对。', '已核第6页三个等边三角形和中点'),
    'AMC8-2000-16': ('400 (C)', '走长边25次得1000米，长40米；绕周长10次得1000米，周长100米，所以2(40＋宽)＝100，宽10米，面积40×10＝400平方米。', '第6页长度与周长次数均是走1公里，选项C为400。', '无题图'),
}

target = Path(__file__).resolve().parent.parent / 'docs' / 'exam-review-ledger.csv'
with target.open(encoding='utf-8-sig', newline='') as stream:
    reader=csv.DictReader(stream)
    names, rows=reader.fieldnames, list(reader)
if len(rows)!=500:
    raise ValueError('Expected 500 positions')
by_id={row['examId']:row for row in rows}
for exam_id,(answer,solution,comparison,figure) in CASES.items():
    row=by_id[exam_id]
    if row['reviewStatus']!='旧记录有独立求解线索，待核对原题与证据':
        raise ValueError('Refusing to overwrite a checked position: '+exam_id)
    if row['referenceAnswer']!=answer.split('(')[-1].rstrip(')'):
        raise ValueError('Reference mismatch: '+exam_id)
    row.update(derivedAnswer=answer,independentSolution=solution,figureChecked=figure,
               comparison='独立结果与登记的参考选项一致；'+comparison,
               reviewStatus='已核原题、独立求解、答案一致',reviewerMethod='人工目视原扫描PDF；独立手算/列举/逐图核对',
               reviewedAt='2026-09-28')
with target.open('w',encoding='utf-8-sig',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=names,lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
print('2000 questions 11–16 reviewed; cumulative current review 16/500')
