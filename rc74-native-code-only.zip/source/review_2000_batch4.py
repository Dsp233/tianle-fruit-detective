"""Independent original-PDF review of 2000 problems 17–25 (pages 7–11)."""
import csv
from pathlib import Path

CASES = {
    'AMC8-2000-17': ('−2/3 (A)', '1⊗2＝1/2，(1⊗2)⊗3＝(1/2)²÷3＝1/12；2⊗3＝4/3，1⊗(2⊗3)＝3/4。差为1/12－3/4＝−2/3。', '第7页自定义运算a²/b，括号次序已逐一核对。', '无题图'),
    'AMC8-2000-18': ('同面积、I周长较短 (E)', '按点阵单位坐标：I顶点(0,0),(1,1),(1,2),(0,1)，面积1、周长2＋2√2；II顶点(2,3),(4,2),(3,3),(3,4)，面积1、周长1＋√5＋2√2。因此两者面积同为1，I周长少√5－1。', '第7页两四边形顶点和边按图追踪。', '已核第7页点阵与四条边'),
    'AMC8-2000-19': ('50 (C)', '令BD为宽10的直径，上部半圆面积25π/2；下方10×5矩形中两个半径5的四分之一圆总面积也为25π/2，恰相抵，留下矩形面积50。', '第8页AB、AD是四分之一圆弧，BCD是半圆弧，半径均5。', '已核第8页三条弧对应的区域'),
    'AMC8-2000-20': ('1 (A)', '设p、n、d、q为四类硬币枚数，均≥1。p+n+d+q=9，p+5n+10d+25q=102。模5得p=2或7，7无法给其余三类各留1枚，故p=2；n+d+q=7且n+2d+5q=20，得d+4q=13，正整数且总枚数限制给q=3、d=1、n=3。', '第8页九枚与102美分、四种币各至少一枚。', '无题图'),
    'AMC8-2000-21': ('3/8 (B)', '三枚独立公平硬币共有8个等可能先后结果。Keiko反时Ephraim两枚均反有1种；Keiko正时Ephraim正反或反正有2种，合3/8。', '题干第8页，五个分数选项在第9页。', '无题图'),
    'AMC8-2000-22': ('约17% (C)', '原边长2立方体表面积6×2²＝24；加边长1小立方体多6个单位面，但接触的两面各隐藏1，净增4。4/24＝1/6≈16.7%，最接近17%。', '第9页小立方体完整底面与大立方体顶面接合，选项C为17。', '已核第9页粘合关系图'),
    'AMC8-2000-23': ('6 (B)', '前四项总和4×5＝20；后四项总和4×8＝32；七项总和7×(6＋4/7)＝46。两组各含第四项一次，相加时第四项被重复一次，故20＋32－46＝6。', '题干第9页、补充题干及选项第10页。', '无题图'),
    'AMC8-2000-24': ('80° (D)', '三角形AFG中∠GAF＝20°，∠AFG＝∠AGF，各为80°。图上A-F-D共线、G-F-B共线，∠BFD与80°互补为100°；三角形BFD中∠B＋∠D＝80°。', '第10页标记A、F、G和B、D的交线均逐一对齐。', '已核第10页星形交线与字母'),
    'AMC8-2000-25': ('27 (B)', '设矩形宽w高h，令A=(0,h)、BC中点=(w,h/2)、CD中点=(w/2,0)。三角形面积由两向量行列式得3wh/8；wh＝72，所以是27。', '题干第10页，图与选项在第11页。', '已核第11页两个中点和矩形位置'),
}

target=Path(__file__).resolve().parent.parent/'docs'/'exam-review-ledger.csv'
with target.open(encoding='utf-8-sig',newline='') as stream:
    reader=csv.DictReader(stream);names,rows=reader.fieldnames,list(reader)
if len(rows)!=500:
    raise ValueError('Expected 500 positions')
by_id={row['examId']:row for row in rows}
for exam_id,(answer,solution,comparison,figure) in CASES.items():
    row=by_id[exam_id]
    if row['reviewStatus']!='旧记录有独立求解线索，待核对原题与证据':
        raise ValueError('Refusing to overwrite: '+exam_id)
    if row['referenceAnswer']!=answer.split('(')[-1].rstrip(')'):
        raise ValueError('Reference mismatch: '+exam_id)
    row.update(derivedAnswer=answer,independentSolution=solution,figureChecked=figure,
               comparison='独立结果与登记的参考选项一致；'+comparison,
               reviewStatus='已核原题、独立求解、答案一致',reviewerMethod='人工目视原扫描PDF；独立计算/枚举/逐图核对',reviewedAt='2026-09-28')
with target.open('w',encoding='utf-8-sig',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=names,lineterminator='\n');writer.writeheader();writer.writerows(rows)
print('2000 year original questions 1–25 independently reviewed; cumulative 25/500')
