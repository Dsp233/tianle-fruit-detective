"""Independent review of all 25 questions in the 2001 scanned PDF."""
import csv
from itertools import combinations, permutations
from pathlib import Path

digits = sorted(int(''.join(p)) for p in permutations('2457'))
assert [(n, m) for n in digits for m in digits if n > m and n % m == 0] == [(7425, 2475)]
# Lattice basis vectors form a 60-degree angle. Side length of the big triangle is 2.
points = ((0, 0), (2, 0), (0, 2), (1, 0), (1, 1), (0, 1))
def square_distance(p, q):
    x, y = p[0]-q[0], p[1]-q[1]
    return x*x+x*y+y*y
triangle_types = set()
for a, b, c in combinations(points, 3):
    if (b[0]-a[0])*(c[1]-a[1]) == (b[1]-a[1])*(c[0]-a[0]):
        continue
    triangle_types.add(tuple(sorted((square_distance(a,b),square_distance(a,c),square_distance(b,c)))))
assert triangle_types == {(1,1,1), (1,1,3), (1,3,4), (4,4,4)}

# The entry records an independent computation and observed condition/diagram.
CASES = {
  1: ('10分钟 (D)', '300个凹坑各2秒，共600秒＝10分钟。', '第1页英文总数、单个时间及选项D。', '无题图'),
  2: ('8 (D)', '24的正整数因数对为(1,24)、(2,12)、(3,8)、(4,6)，仅3＋8＝11，较大者8。', '第1页“whole numbers”、积24与和11及选项D。', '无题图'),
  3: ('23 (E)', 'Anjou有63÷3＝21美元，Elberta比她多2美元为23。', '第1页两次先后关系及选项E。', '无题图'),
  4: ('9 (E)', '偶数末位可取2或4。末位4时前四位最小为1239，得到12394；末位2时前四位最小为1349，得到13492。较小12394的十位为9。', '第1–2页五个数位各一次、偶数条件和选项E。', '无题图'),
  5: ('2英里 (C)', '雷声走10秒为1088×10＝10880英尺；10880÷5280≈2.06英里，最接近半英里刻度是2。', '第2页声音速度、英尺英里换算及五个半英里选项。', '无题图'),
  6: ('100英尺 (B)', '第1至第4棵跨3段，段长60÷3＝20英尺；第1至第6棵跨5段，总长100。', '第2页六棵树及第4棵距离选项B。', '无题图'),
  7: ('21平方英寸 (A)', '点阵坐标取左右顶点(0,2),(6,2)，上下顶点(3,0),(3,7)。两条垂直对角线长6与7，面积6×7÷2＝21。', '题干第2页，风筝点阵和选项第3页；大风筝的放大条件不用于小风筝面积。', '已核第3页风筝四顶点与每格1英寸'),
  8: ('39英寸 (E)', '原图横对角线长6格，竖对角线长7格。高和宽均放大3倍后，两根十字支架分别18与21英寸，总39。', '题干第3页、图和选项第4页；支架连接两组相对顶点。', '已核第3–4页风筝点阵和十字交线'),
  9: ('189平方英寸 (D)', '原网格宽6高7，矩形面积42；风筝面积21。两维各放大3倍，面积各乘9；四角废料(42－21)×9＝189。', '题干第4页、选项第5页；长方形恰覆盖全部网格。', '已核第4页风筝占矩形一半'),
 10: ('20美元 (A)', '四枚25美分总面值1美元；2000%即20倍，收到20美元。', '第5页面值百分率和选项A。', '无题图'),
 11: ('18平方单位 (C)', 'AB与CD为竖直平行边，长度4和2；两边横向距离6，梯形面积(4＋2)×6÷2＝18。', '坐标题干第5页、坐标图及选项第6页。', '已核第6页坐标四轴及顶点所在位置'),
 12: ('4 (A)', '6⊗4＝(6＋4)/(6－4)＝5；5⊗3＝(5＋3)/(5－3)＝4。', '第6页定义、括号和选项A。', '无题图'),
 13: ('50° (D)', '其余三种已占12＋8＋6＝26人，剩10人，樱桃5人。扇形角为5/36×360°＝50°。', '第6页36人、三类人数、余者平分及选项D。', '无题图'),
 14: ('72 (C)', '三肉选一有3种，四种蔬菜选不同两种有组合数6，四甜点选一有4种，3×6×4＝72。', '食物清单第6–7页，选项C；顺序不重要。', '无题图'),
 15: ('20 (A)', 'Homer先独做4分钟剥12个，余32个由二人每分钟3＋5＝8个合剥4分钟，Christen剥5×4＝20个。', '第7页44个、速度、4分钟错开及选项A。', '无题图'),
 16: ('5/6 (E)', '4×4正方形对折成2×4双层，沿与折痕平行的中线切开并展开，得到中间2×4和两侧各1×4。小周长10、大周长12，比5/6。', '第7–8页对折剪开后的三块长方形与选项E。', '已核第8页对折方向和切线'),
 17: ('第2至第3题 (B)', '逐项按“新值－旧值”除以旧值：1→2为100%，2→3为50%，3→4为2/3，11→12为61/64，14→15为100%；最小50%。', '第8页金额表与五组相邻题选项B。', '已核第8页表格中200、300、500、64K、125K'),
 18: ('11/36 (D)', '两骰积是5的倍数须至少一颗掷5；36个有序结果中第一颗5有6种、第二颗5有6种，(5,5)重复1种，得11/36。', '第8页两骰题和选项D。', '无题图'),
  19: ('图D (D)', '相同路程且N速度为M两倍，N时间应为M一半；速度时间图应在约双倍高度画实线，长度约虚线一半，第9页D吻合。', '题干第8–9页，第9页五幅速度时间图；A的时长不为一半。', '已核第9页五幅速度时间图纵横关系'),
  20: ('S,Q,M (A)', 'Kaleana给三人看自己的分数，其他人只知道自己的分数。若各判断均可由已知分数确定，则Quay能断言至少两人同分，说明他和Kaleana同分；Marty能断言自己不是最低，说明他高于Kaleana；Shana能断言自己不是最高，说明她低于Kaleana。因此S<Q<M。', '题干第9–10页，三人只见Kaleana分数这一信息条件、各自陈述和选项A共同决定顺序。', '无题图'),
 21: ('35 (D)', '五数和为5×15＝75，中间数18。为使最大项大，最小两正整数取1、2；第四项须比18大且最小为19，故最大75－1－2－18－19＝35。', '第10页不同正整数、中位数与选项D。', '无题图'),
 22: ('97 (E)', '设正确c、空题u，分数5c＋u且c＋u≤20。90可取(18,0)，91取(18,1)，92取(18,2)，95取(19,0)；97需c=19、u=2共21题，c≤18时最高不超过92，故不可能。', '第10页20道题、5/1/0分及选项E。', '无题图'),
 23: ('4 (D)', '把大等边三角形边长定为2，其顶点及三边中点形成6点。列出所有非共线三点并按三条边长平方排序，只有(1,1,1)、(1,1,3)、(1,3,4)、(4,4,4)四型；脚本有枚举断言。', '题干第10页、六点图和选项第11页。', '已核第11页R/S/T与X/Y/Z中点位置'),
 24: ('5 (B)', '每半16个小三角形，因此重合16对。同色红红2对、蓝蓝3对；红白2对耗尽两半剩余红色。蓝色每半还余2个，形成蓝白4对；白白＝16－2－3－2－4＝5对。', '第11页每半3红、5蓝、8白及折叠配对条件和选项B。', '已核第11页中心线与两半同形小三角形'),
 25: ('7425 (D)', '枚举2、4、5、7排列成的24个四位数，唯一一对相互整除的不同数为7425＝3×2475，因此所求倍数7425。脚本有穷举断言。', '第11–12页整数排列条件与选项D。', '无题图'),
}

target=Path(__file__).resolve().parent.parent/'docs'/'exam-review-ledger.csv'
with target.open(encoding='utf-8-sig',newline='') as stream:
    reader=csv.DictReader(stream)
    columns,rows=reader.fieldnames,list(reader)
if len(rows)!=500 or len(CASES)!=25:
    raise ValueError('Expected 500 positions and 25 resolved 2001 problems')
by_id={row['examId']:row for row in rows}
for number,(answer,solution,comparison,figure) in CASES.items():
    exam_id=f'AMC8-2001-{number:02d}'
    row=by_id[exam_id]
    if row['reviewStatus']!='待独立复核' or row['referenceAnswer']!=answer.split('(')[-1].rstrip(')'):
        raise ValueError('Unexpected original status or answer: '+exam_id)
    row.update(derivedAnswer=answer,independentSolution=solution,figureChecked=figure,
               comparison='独立结果与登记的参考选项一致；'+comparison,
               reviewStatus='已核原题、独立求解、答案一致',
               reviewerMethod='人工目视原扫描PDF；独立计算/枚举/逐图核对',reviewedAt='2026-09-28')

with target.open('w',encoding='utf-8-sig',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=columns,lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
print('2001 positions checked: 25 independently verified; cumulative 60/500')
