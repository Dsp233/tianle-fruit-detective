"""Independently resolve three positions found while auditing uploaded answer PDFs."""
import csv
from pathlib import Path

CASES={
 'AMC8-2002-12': ('B','1/6 (B)','三个区域总概率为1，因此C区域＝1－1/3－1/2＝1/6。','题干和选项见上传答案PDF第6页，参考答案B排到第7页首行；不是空答案。'),
 'AMC8-2003-09': ('C','40美分 (C)','Art梯形饼干面积(3＋5)×3÷2＝12平方英寸，12块共144平方英寸面团。Roger每块4×2＝8平方英寸，可做18块；等于Art收入12×60＝720美分，单块应售720÷18＝40美分。','题干和图见上传答案PDF第5页，参考答案C排到第6页首行；不是空答案。'),
 'AMC8-2023-10': ('C','1/4 (C)','Harold吃1/4，余3/4；驼鹿吃掉余量的一半，剩3/4×1/2；豪猪吃掉其后余量的1/3，最终剩3/4×1/2×2/3＝1/4。','原题在2023 AMC8.pdf第5–6页；上传答案PDF第6页明确标C。旧登记D错误，按原题独立计算纠正。'),
}
target=Path(__file__).resolve().parent.parent/'docs'/'exam-review-ledger.csv'
with target.open(encoding='utf-8-sig',newline='') as stream:
 reader=csv.DictReader(stream);columns,rows=reader.fieldnames,list(reader)
by_id={row['examId']:row for row in rows}
assert len(rows)==500
for exam_id,(letter,answer,solution,comparison) in CASES.items():
 row=by_id[exam_id]
 if row['reviewStatus']!='待独立复核':
  raise ValueError('Unexpected review status: '+exam_id)
 if exam_id=='AMC8-2023-10':
  if row['referenceAnswer']!='D':
   raise ValueError('Expected original erroneous D before correction')
  row['answerSource']='上传附件 2023 AMC8 (答案).pdf，第6页；旧登记URL对应的D未核实'
  row['referenceAnswer']='C'
 elif row['referenceAnswer']!=letter:
  raise ValueError('Reference mismatch: '+exam_id)
 row.update(derivedAnswer=answer,independentSolution=solution,figureChecked='已核原题相关图形' if exam_id.endswith('2003-09') else '无题图',
            comparison='独立结果与上传答案卷一致；'+comparison,
            reviewStatus='已核原题、独立求解、答案一致',
            reviewerMethod='人工目视原题及上传答案PDF；独立计算',reviewedAt='2026-09-28')
with target.open('w',encoding='utf-8-sig',newline='') as stream:
 writer=csv.DictWriter(stream,fieldnames=columns,lineterminator='\n');writer.writeheader();writer.writerows(rows)
print('Resolved 2002-12, 2003-09 and corrected 2023-10 D→C; cumulative 63/500')
