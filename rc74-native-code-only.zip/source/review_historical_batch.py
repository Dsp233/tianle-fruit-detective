"""Resolve eleven historical solution notes against the supplied scanned pages.

Ten questions have complete conditions and independent derivations. The 2012
translation mismatch stays open and must never be counted as reviewed.
"""
import csv
from itertools import product
from pathlib import Path

LINES = ((0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6),
         (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6))
both_lines = sum(
    any(all(bits[i] == 0 for i in line) for line in LINES)
    and any(all(bits[i] == 1 for i in line) for line in LINES)
    for bits in product((0, 1), repeat=9)
)
assert both_lines == 84
stamp_solutions = [(a, b, c, a+b+c) for a in range(21) for b in range(21)
                   for c in range(21) if a + 2*b + 5*c == 142]
assert max(stamp_solutions, key=lambda x: x[3]) == (19, 19, 17, 55)

# id: result, derivation, comparison, diagram
CASES = {
    'AMC8-2022-02': ('100 (D)', '按原题定义，5♦3＝5²－3²＝16，再算16★6＝(16－6)²＝100。', '第1页两种自定义运算的定义和选项D。', '无题图'),
    'AMC8-2022-10': ('图E (E)', '去程8:00至10:00以45英里/小时行2小时，最远90英里；10:00至13:00停留；回程90÷60＝1.5小时，于14:30到起点。', '题干第4页，图A、B在第4页、图C、D、E在第5页；E的折点与斜率吻合。', '已核第4–5页五幅距离时间图'),
    'AMC8-2022-15': ('3盎司 (C)', '按散点图读出各重量的最低价格约为1盎司1.2、2盎司2.0、3盎司2.5、4盎司4.0、5盎司4.5美元。相应最低单位价约1.2、1.0、0.83、1.0、0.9美元/盎司，3盎司最小。', '题干第6页、散点图及选项第7页，逐列比较最低点除以盎司数。', '已核第7页散点坐标和五列最低点'),
    'AMC8-2022-21': ('9 (C)', 'Steph共进15＋10＝25球，30次出手；Candace也是30次且总命中率相同，故共25球。设她上半场命中x，x/12<15/20使x≤8；下半场(25－x)/18<10/10使x≥8；故为8和17，相差9。', '第9页条件和第10页分半场表格、选项C。', '已核第10页分半场表格'),
    'AMC8-2022-23': ('84 (D)', '九格各有两种取值，逐一枚举2^9＝512种。对每种逐条检查3行、3列及2条对角线，要求某线全△且某线全○，共有84种。枚举断言写在本脚本。', '题干及图在第10–11页，选项D为84；计入两种线均出现而非任选其一。', '已核第11页九格示例和八条三连线'),
    'AMC8-2023-03': ('23 (B)', '按题干给的近似式：36－0.7×18＝36－12.6＝23.4华氏度，五个选项中23最近。', '第2页公式、数值与选项B。', '无题图'),
    'AMC8-2023-06': ('9 (C)', '四位2、0、2、3各用一次，分别填入两个一位数的底与指数。3²×2⁰＝9；若3作指数，另一个非零底至多2，剩余幂乘积最多2³×2⁰＝8；3作底配指数0或2，最大3²×2⁰＝9。', '第3页两个幂相乘的四个框及选项C。', '已核第3页指数框与乘号位置'),
    'AMC8-2023-14': ('55 (E)', '以5美分为单位设5、10、25美分邮票数为a、b、c，各在0至20之间，a＋2b＋5c＝142。穷举21³组满足等式者，最大a＋b＋c＝55，唯一最优为(19,19,17)；枚举断言写在本脚本。', '第7页每种恰有20张、总价710美分和选项E。', '无题图'),
    'AMC8-2023-18': ('411 (D)', '设向右a次向左b次，则5a－3b＝2023、a≥405。模3得a≡2 (mod 3)，至少a＝407，b＝(5×407－2023)/3＝4，总411次；更大的a使a＋b增加。', '第9页“从任意叶可跳”保证允许先后次序，选项D为411。', '无题图'),
    'AMC8-2023-23': ('1/64 (C)', '3×3有4个相邻2×2位置。某指定位置形成灰菱形要求4块各取唯一方向，概率(1/4)^4＝1/256；任意两个位置重叠时共用块所需的灰角方向冲突，事件互斥，故4/256＝1/64。', '第11页四种方块、3×3网格、示例及选项C；逐一比较相邻/对角重叠。', '已核第11页三角灰白方块朝向与示例菱形'),
}

target = Path(__file__).resolve().parent.parent/'docs'/'exam-review-ledger.csv'
with target.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    names, rows = reader.fieldnames, list(reader)
if len(rows) != 500:
    raise ValueError('Expected 500 positions')
by_id = {row['examId']: row for row in rows}
for exam_id, (answer, solution, comparison, figure) in CASES.items():
    row = by_id[exam_id]
    if row['reviewStatus'] != '旧记录有独立求解线索，待核对原题与证据':
        raise ValueError('Refusing to overwrite: '+exam_id)
    if row['referenceAnswer'] != answer.split('(')[-1].rstrip(')'):
        raise ValueError('Reference mismatch: '+exam_id)
    row.update(derivedAnswer=answer, independentSolution=solution, figureChecked=figure,
               comparison='独立结果与登记的参考选项一致；'+comparison,
               reviewStatus='已核原题、独立求解、答案一致',
               reviewerMethod='人工目视原扫描PDF；独立计算/枚举/逐图核对', reviewedAt='2026-09-28')

row = by_id['AMC8-2012-01']
if row['reviewStatus'] != '旧记录有独立求解线索，待核对原题与证据':
    raise ValueError('Refusing to overwrite: AMC8-2012-01')
row.update(derivedAnswer='', figureChecked='无题图',
           independentSolution='若按附件中文译文补入8个汉堡，则3×24÷8＝9，选项E；附件英文原题无首批汉堡个数，无法由该英文题干唯一求解。',
           comparison='条件不一致，不能将参考选项E视为已从完整英文原题独立验证。',
           reviewStatus='原卷条件缺失，待权威原题核验',
           reviewerMethod='人工目视附件2012 AMC8.pdf第1页英中题干', reviewedAt='2026-09-28',
           unresolvedIssues='英文行遗漏“8个汉堡”，中文译文有8；需核对权威原卷并纠正文源后重算。')

with target.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=names, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
print('Ten historical notes independently checked; cumulative 35/500, one source discrepancy open')
