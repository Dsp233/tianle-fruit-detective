'use strict';
const fs=require('fs'),assert=require('assert');
const {competitionCreate:create}=require('./competition'),{competitionReviewedRecipe:recipe}=require('./competition_reviewed');
const {rulesOracle}=require('./competition_rules_oracle');
const root='docs/evidence/2026-10-08-rc66-local',registration=JSON.parse(fs.readFileSync('docs/rc66-content-registration.json')),coverage=JSON.parse(fs.readFileSync(root+'/rc66-generator-coverage.json'));
const notes={
 S01:['比较整包与补齐余数的费用；多买不一定多花钱。','至少改成恰好，最低费用由20改为22元，必须排除超买方案。','接受；折扣较大但数量、价格明确，计算规模小。'],
 S02:['最少费用与最优买法的数量是两件事。','限制变为恰好时费用仍40元；原来并列的超买方案被排除。','接受；问费用允许并列买法，不能改成唯一方案选择题。'],
 S03:['便宜整包也要比较最后一包与所需单买件数。','改为恰好仍27元，孩子应说明为什么超买没有优势。','接受；答案不变仍有约束判断价值。'],
 S04:['第二次的整体已经改变，逆推时先恢复后一次。','第二次改用最初整体的四分之一，剩余变为14张。','接受；全部为整数张，分数除数带括号且步骤含单位。'],
 S05:['两次比例都对应最初总量，应分别扣除。','改问两次按剩余使用后的原量，答案112/3升；适合已能处理分数的进阶练习。','接受；水量可分，保留精确分数。后续试用观察计算负担。'],
 S06:['长条已扣除两处重叠，先加回再等分。','改为闭环，需要三处重叠；材料同步换成可弯曲的软塑料条。','修改后接受；已修正材料变化说明，不能让刚性展示板直接弯成环。'],
 S07:['间隔数不等于标记数，检查两个端点。','两端不放改为都放，5个变为7个。','接受为起步题；重在边界识别，不称挑战题。'],
 S08:['人数比决定权重，不能把两种得分等权平均。','改目标为甲每人得分，并调整全体平均为14，反求8分。','接受；平均55/4分有分数运算，知识范围R01+D02明确。'],
 S09:['从全体平均还原总分，再扣乙队、分到甲队。','给定甲8分后改求全体平均14分。','接受；与S08使用同组数据检验目标变化，不计为另一独立策略。'],
 S10:['长与宽的份数和对应半周长。','给定量变为宽16米，求周长128米；同时改变大小与目标。','接受；自然综合同一围栏，不以多一步计算作为新策略。'],
 S11:['平均与人数先转换为总和，再比较删去前后。','数放回两次，人数和总和一起变化，平均43/3。','接受；旧题参数和数学身份保留，计算值适中。'],
 S12:['转移同时减少乙、增加甲，差缩小两倍转移量。','外部只向甲加入，差只缩小一次；答案仍14块但理由改变。','接受；答案相同不能替代对两边变化的判断。']
};
const rows=registration.rules.map(r=>{
 const p=r.selector?coverage.representatives[r.id==='S01'?'overbuy':r.id==='S02'?'tie':'exact'].recipe:recipe(r.family,r.seed),t=create(p),c=t.competition;
 if(c.math.variant){const n=s=>String(s).split('/').map(Number).reduce((a,b)=>a/b);assert(Math.abs(n(c.answer)-rulesOracle(c.math))<1e-9);assert(Math.abs(n(c.extension.answer)-rulesOracle(c.extension.math))<1e-9)}
 const content=JSON.stringify([t.prompt,c.methods,c.diagram,c.extension]);assert(!content.includes('单支/棵'));
 return {id:r.id,recipe:c.recipe,topicIds:c.topicIds,prompt:t.prompt,answer:c.answer,methods:c.methods,hints:c.hints,diagram:c.diagram,variation:c.extension,reasoning:notes[r.id][0],change:notes[r.id][1],decision:notes[r.id][2],initialDiagram:'only givens; formulas and solved quantities are in the optional answer steps'};
});
fs.writeFileSync(root+'/rc66-content-samples.json',JSON.stringify(rows,null,2)+'\n');
let md='# RC66 正常生成样本审稿\n\n2026-10-08。12道主问题及对应变式，按预登记规则从正常生成接口取样。由本轮实施者阅读审查，不是外部盲测，也不是12种新策略。正常主题入口另完成7轮R02及原33主题回归。\n\n';
md+='审查重点：范围、关键关系、自然性、计算负担、条件变化、初始图是否泄露、提示与解法。原题族的独立主答/变式求解在全库回归中核验。\n\n';
for(const x of rows){md+='## '+x.id+' · '+x.recipe.familyId+'\n\n';md+='配方：\`'+JSON.stringify(x.recipe)+'\`。主要主题：'+x.topicIds.join('＋')+'。\n\n';md+=x.prompt+'\n\n**答案：'+x.answer+'。**\n\n'+x.methods.map(m=>m.name+'：\n\n'+m.steps.map(s=>'- '+s).join('\n')).join('\n\n')+'\n\n';md+='变式：'+x.variation.prompt+'\n\n答案：'+x.variation.answer+'。'+x.variation.solution+'\n\n';md+='关键思考：'+x.reasoning+'\n\n变化价值：'+x.change+'\n\n审稿结论：'+x.decision+'\n\n'}
md+='## 审稿引发的公共修正\n\n分数步骤与图注补齐张/升单位。展示板转闭环明确先换成软材料，数学配方和答案保持原合同。修正覆盖相应生成配置，并重新运行数学、显示与兼容回归。\n\nS08/S09的共同数值、S02/S03/S12的同答案变式均已说明用途；不把换目标或答案不变自动当作题目缺陷，也不把它们计成未验证的新策略。真实浏览器排版、设备发音和孩子理解仍待实测。\n';
fs.writeFileSync('docs/rc66-content-review.md',md);console.log('Reviewed',rows.length,'normal-generated main/variation samples');
