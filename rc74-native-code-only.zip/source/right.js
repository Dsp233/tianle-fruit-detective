'use strict';
const RIGHT_TASKS={
 'G06.01':{kind:'condition',cards:[{points:[[0,0],[3,0],[0,4]],corner:0,givenAngle:90,rotation:0},{points:[[0,0],[3,0],[1.5,2.598076211353316]],corner:0,givenAngle:60,rotation:0}],context:'先检查已给角条件',prompt:'分别点图中给定角的实际顶点，并描它的两条角边。依据角度条件判断哪张卡能使用直角三角形的平方关系；60°卡也要检查。',explain:'90°卡满足直角条件；60°卡不满足。不能只凭三条边或图画外观套用。',reason:{prompt:'使用三边平方关系前先核对什么？',options:['已知条件中有直角，两条直角边交在该顶点','三角形看起来像直角即可','只要有三条边即可'],answer:0}},
 'G06.02':{kind:'squares',a:3,b:4,c:5,unit:1,rotation:0,context:'搬原单位格作一次面积检验',prompt:'先标实际直角和两条直角边。把两块直角边正方形的每个原单位格移入斜边正方形空槽，再填三块面积。这里只检验这个3、4、5实例。',explain:'9与16个原单位格共25格，恰好铺满5×5正方形；9＋16＝25。这次具体拼合不冒称一般证明。',reason:{prompt:'这次移动怎样检验面积？',options:['原方格身份和面积保留，9格与16格不重叠铺满25格','把3和4相加就是斜边','只填9＋16＝25，不必移动材料'],answer:0}},
 'G06.03':{kind:'solve',a:3,b:4,c:5,unit:1,unknown:'c',rotation:0,context:'由两块已知平方拼未知正方形',prompt:'直角边3、4，斜边未知。标直角和角边，再调试未知正方形边长，把两块已知平方的原方格移进去。全部材料恰好铺满后填写未知边长。',explain:'9＋16＝25，25格正方形每边5格，所以斜边5；不是3＋4＝7。',reason:{prompt:'为什么最后要找正方形边长？',options:['先得到未知边的平方面积，再找对应边长','面积25就说明边长25','两条直角边相加就是斜边'],answer:0}},
 'G06.04':{kind:'axis',A:[1,2],B:[1,6],minX:0,maxX:6,minY:0,maxY:6,context:'从两个实际端点逐单位量距离',prompt:'点实际端点A(1,2)与B(1,6)，从A逐格向上量到B，再填写直线距离。不要把B的纵坐标6当作距离。',explain:'同列距离是6−2＝4格；从A到B实际经过4个单位段。',reason:{prompt:'为什么答案不是6？',options:['距离是两个端点间单位段数，不是终点刻度','纵坐标总是距离','把两个纵坐标相加'],answer:0}},
 'G06.05':{kind:'diagonal',A:[0,0],B:[3,4],minX:0,maxX:6,minY:0,maxY:6,a:3,b:4,c:5,unit:1,unknown:'c',rotation:0,context:'在网格构造直角再求直线距离',prompt:'点A(0,0)、B(3,4)，再选一个网格直角拐点，连接三点。逐格量两条直角边，再用原平方格拼斜边正方形，填写AB直线距离；沿格线绕路的长度另算。',explain:'两条直角边3和4，直线AB为5；沿格线绕路是7，两种长度不同。',reason:{prompt:'直线距离与沿格线绕路有什么区别？',options:['直线是斜边，用两条垂直位移的平方求；绕路才相加','两种长度都为3＋4','把两个坐标直接拼成34'],answer:0}}
};
for(const [skillId,t] of Object.entries(RIGHT_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:49,mode:'rightLab',phase:'练',hint:'先核对直角条件。面积用原材料拼合，边长与面积分开；坐标距离从实际端点逐单位量。'});
if(typeof module!=='undefined')module.exports={RIGHT_TASKS};
