'use strict';
const RIGHT_CASES={
 'G06.01':[
  [{kind:'condition',cards:[{points:[[4,0],[0,0],[0,3]],corner:1,givenAngle:90,rotation:90},{points:[[0,0],[3,0],[-1.5,2.598076211353316]],corner:0,givenAngle:120,rotation:30}],context:'旋转和钝角反例'},'分别标给定角顶点与两条实际角边；一图旋转后给90°，另一图给120°。判断各图能否用直角三角形平方关系。','旋转90°卡仍满足；120°卡不满足。','方向和直角顶点改变，并加入钝角反例'],
  [{kind:'condition',cards:[{points:[[0,0],[3,0],[0,4]],corner:0,givenAngle:90,rotation:45}],context:'独立斜向直角图'},'独立在转45°的图中标给定90°角及两条角边，再判断平方关系能否使用。','直角条件明确，斜向不改变直角。','无提示：坐标轴不再与角边平行'],
  [{kind:'condition',cards:[{points:[[0,0],[3,0],[1.5,2.598076211353316]],corner:0,givenAngle:60,rotation:90},{points:[[3,0],[0,4],[0,0]],corner:2,givenAngle:90,rotation:180}],context:'隔日非直角与另一个直角顶点'},'隔日分别点给定60°和90°角的顶点、描两条实际角边，再判断各自的适用条件。','60°不满足；90°满足，不按上下位置猜。','隔日：先出现反例，直角换到C'],
  [{kind:'condition',cards:[{points:[[0,0],[3,0],[0,4]],corner:0,givenAngle:90,rotation:180},{points:[[4,0],[0,0],[0,3]],corner:1,givenAngle:90,rotation:270}],context:'备用两张转向图'},'独立检查两张转向后的90°图，分别标给定角顶点与两条角边，再判断是否满足。','两图都满足，顶点和方向可不同。','备用：两种直角顶点与转向']
 ],
 'G06.02':[
  [{kind:'squares',a:1.5,b:2,c:2.5,unit:.5,rotation:0,context:'单位格边长换成半厘米'},'直角边1.5、2厘米，每个原方格边长0.5厘米。标直角与角边，把两块平方原格移入斜边平方，再填三块实际面积。','9格×0.25＝2.25；16格×0.25＝4；25格×0.25＝6.25平方厘米。','单位格变0.5厘米，格数与实际面积分开'],
  [{kind:'squares',a:4,b:3,c:5,unit:1,rotation:180,context:'独立交换两边并转向'},'独立标直角和角边，将4边与3边正方形的原方格拼入5边正方形，再填三块面积。','16＋9＝25平方单位。','无提示：长短边和方向交换'],
  [{kind:'squares',a:3,b:4,c:5,unit:1,rotation:90,context:'隔日旋转拼合'},'隔日标旋转图的直角与角边，实际搬3边和4边正方形原格铺满5边正方形，填三块面积。','9＋16＝25；这里只检验具体拼合。','隔日：另一个图向，原格身份继续保留'],
  [{kind:'squares',a:6,b:8,c:10,unit:2,rotation:0,context:'备用2厘米方格'},'独立用边长2厘米的原格操作6、8、10厘米三边平方：标直角、描角边、搬格并填实际面积。','每格4平方厘米，36＋64＝100平方厘米。','备用：单位格变2厘米，不能直接把格数当面积']
 ],
 'G06.03':[
  [{kind:'solve',a:6,b:8,c:10,unit:2,unknown:'c',rotation:0,context:'梯子、墙与地面'},'墙与地面垂直；梯脚距墙6米，梯顶高8米，每格边2米。标直角和角边，用两块已知平方的原格试拼未知平方，填写梯长。','梯长10米，6²＋8²＝10²。','三角形边长题改梯子情境，先核对墙地垂直'],
  [{kind:'solve',a:3,b:4,c:5,unit:1,unknown:'a',rotation:90,context:'独立由斜边求短直角边'},'独立求一条未知直角边，另一条4、斜边5。标直角角边，将斜边平方原格先铺已知直角边平方，剩下原格拼未知平方并填边长。','25−16＝9，未知边3。','无提示：求斜边改求直角边，先扣已知平方'],
  [{kind:'solve',a:3,b:4,c:5,unit:1,unknown:'b',rotation:180,context:'隔日另一条直角边'},'隔日给斜边5、一条直角边3。标直角角边，把斜边平方原格先铺已知平方，再用剩余格拼未知平方，填另一条边。','25−9＝16，未知边4。','隔日：未知边换另一边，面积由加改减'],
  [{kind:'solve',a:1.5,b:2,c:2.5,unit:.5,unknown:'c',rotation:270,context:'备用半单位材料'},'独立给直角边1.5、2，每个方格边0.5。标直角角边，用原格拼未知平方，填实际斜边长度。','未知平方6.25，边长2.5；不是25格就边25。','备用：非整数实际边长与半单位格']
 ],
 'G06.04':[
  [{kind:'axis',A:[2,3],B:[6,3],minX:0,maxX:6,minY:0,maxY:5,context:'同一横排的站点'},'一条横向路线，站点A(2,3)、B(6,3)。点实际端点并从A逐格量到B，填写距离。','同排距离6−2＝4格。','同列改同行，变化坐标轴改变'],
  [{kind:'axis',A:[6,1],B:[2,1],minX:0,maxX:6,minY:0,maxY:5,context:'独立反向测量'},'独立点A(6,1)、B(2,1)，从A向左逐格量到B，填写距离。','距离为4格，是正长度。','无提示：终点坐标较小，方向反转'],
  [{kind:'axis',A:[-2,2],B:[3,2],minX:-3,maxX:4,minY:0,maxY:4,context:'隔日跨零点'},'隔日点A(-2,2)、B(3,2)，实际跨0逐格量到B，再填写距离。','3−(-2)＝5格。','隔日：跨过坐标零点'],
  [{kind:'axis',A:[3,5],B:[3,2],minX:0,maxX:6,minY:0,maxY:6,context:'备用向下测量'},'独立点A(3,5)、B(3,2)，从A逐格向下量到B，填写距离。','同列距离3格。','备用：向下量且两端都非零']
 ],
 'G06.05':[
  [{kind:'diagonal',A:[1,1],B:[4,5],minX:0,maxX:6,minY:0,maxY:6,a:3,b:4,c:5,unit:1,unknown:'c',rotation:0,context:'近路与沿街路线'},'两站A(1,1)、B(4,5)。点实际端点、选垂直拐点并连接；量两条沿街边，再拼未知平方，填写两站直线近路长度。','沿街3＋4＝7，直线近路5。','非零起点与路线情境，区分直线和沿街'],
  [{kind:'diagonal',A:[4,1],B:[1,5],minX:0,maxX:6,minY:0,maxY:6,a:3,b:4,c:5,unit:1,unknown:'c',rotation:0,context:'独立向左上方'},'独立点A(4,1)、B(1,5)，选一个实际垂直拐点连接并量两边，用原格拼未知平方，填写AB直线距离。','水平位移长3、竖直长4，直线距离5。','无提示：水平位移为负，长度仍正'],
  [{kind:'diagonal',A:[-2,-1],B:[1,3],minX:-3,maxX:4,minY:-2,maxY:4,a:3,b:4,c:5,unit:1,unknown:'c',rotation:0,context:'隔日跨两轴'},'隔日点A(-2,-1)、B(1,3)，选网格直角拐点并连接，量两条直角边，再拼未知平方填写直线距离。','跨轴位移长度3与4，直线距离5。','隔日：两个坐标从负到正'],
  [{kind:'diagonal',A:[1,4],B:[5,1],minX:0,maxX:6,minY:0,maxY:6,a:4,b:3,c:5,unit:1,unknown:'c',rotation:0,context:'备用向右下方'},'独立点A(1,4)、B(5,1)，选实际直角拐点连接并量两边，搬原格拼未知平方填写直线距离。','水平长4、竖直长3，直线距离5。','备用：长短边交换，纵向反转']
 ]
};
const rightStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(RIGHT_CASES)){
 if(cases.length!==4)throw Error('Four G06 cases required: '+skillId);rightStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];rightStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:50,mode:'rightLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,contentVersion:skillId==='G06.03'&&i===0?71:50,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'核对直角；保留原格拼平方，先比较面积再找边长。网格从实际端点量，不把绕路当直线。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={RIGHT_CASES};
