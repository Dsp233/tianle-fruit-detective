#!/usr/bin/env python3
"""Collect current automated gates without overwriting historical evidence."""
import concurrent.futures, datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parent.parent
EVIDENCE = ROOT / 'docs/evidence/2026-10-08-rc67-full'
LOGS = EVIDENCE / 'gate-logs'
LOGS.mkdir(parents=True, exist_ok=True)
TESTS = [
    'test_rc67_compatibility.js', 'test_rc66_compatibility.js',
    'test_competition_reviewed.js', 'test_competition.js',
    'test_rc64.js', 'test_rc65.js', 'test_rc66.js', 'test_rc66_defects.js',
    'test_competition_adaptive.js', 'test_topic_session.js',
    'test_rc67_policies.js', 'test_rc67_components.js',
]

def run(test):
    env = dict(os.environ)
    if not test.startswith('test_rc67_'):
        env['AMC8_EVIDENCE_DIR'] = str(EVIDENCE / 'legacy-regression')
        command = ['node', '-r', './source/test_evidence_sink.js', 'source/' + test]
    else:
        env.pop('AMC8_EVIDENCE_DIR', None)
        command = ['node', 'source/' + test]
    started = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (LOGS / (test + '.log')).write_text(result.stdout)
    row = {'test': test, 'command': command, 'exitCode': result.returncode,
           'seconds': round(time.monotonic()-started, 3),
           'scriptSha256': hashlib.sha256((ROOT/'source'/test).read_bytes()).hexdigest(),
           'log': str((LOGS/(test+'.log')).relative_to(ROOT))}
    print(('PASS ' if result.returncode == 0 else 'FAIL ') + test + ' (' + str(row['seconds']) + 's)', flush=True)
    if result.returncode:
        print(result.stdout[-2500:], flush=True)
    return row

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
build_hash = hashlib.sha256((ROOT/'source/index.html').read_bytes()).hexdigest()
rows = []
prior = None
if '--retry-failed' in sys.argv:
    prior = json.loads((EVIDENCE/'automated-gates.json').read_text())
    assert prior['testedBuildSha256'] == build_hash, 'Changed build requires a new complete gate run'
    archive = EVIDENCE/'gate-attempts'/('attempt-'+str(len(list((EVIDENCE/'gate-attempts').glob('attempt-*')))+1))
    archive.mkdir(parents=True, exist_ok=True)
    shutil.copy2(EVIDENCE/'automated-gates.json', archive/'automated-gates.json')
    shutil.copytree(LOGS, archive/'logs')
    existing = {r['test']:r for r in prior['tests']}
    retry = [test for test in TESTS if test not in existing or existing[test]['exitCode'] != 0 or existing[test]['scriptSha256'] != hashlib.sha256((ROOT/'source'/test).read_bytes()).hexdigest()]
    rows = [existing[test] for test in TESTS if test not in retry]
else:
    retry = TESTS
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for future in concurrent.futures.as_completed([pool.submit(run, test) for test in retry]):
        rows.append(future.result())
checks = []
for flag in [[], ['--local-prototype']]:
    command = ['python3', 'source/build.py', *flag, '--check']
    result = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    checks.append({'command': command, 'exitCode': result.returncode, 'output': result.stdout.strip()})
assert build_hash == hashlib.sha256((ROOT/'source/index.html').read_bytes()).hexdigest(), 'Build changed during gates'
report = {'result': 'passed' if all(r['exitCode'] == 0 for r in rows+checks) else 'failed',
          'startedAt': started, 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'testedBuildSha256': build_hash, 'tests': sorted(rows,key=lambda r:r['test']),
          'buildChecks': checks, 'retriedTests': retry if prior else [],
          'priorAttemptArchived': str(archive.relative_to(ROOT)) if prior else None,
          'limits': ['Automated math and simulated handler gates; actual browser status is separate']}
(EVIDENCE/'automated-gates.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('RC67 automated gates: ' + report['result'], flush=True)
raise SystemExit(0 if report['result'] == 'passed' else 1)
