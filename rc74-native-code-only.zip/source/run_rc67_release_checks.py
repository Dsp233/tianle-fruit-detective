"""Recheck a production candidate while preserving all earlier evidence."""
import concurrent.futures, datetime, hashlib, json, os, pathlib, subprocess, time, sys, shutil
root = pathlib.Path(__file__).resolve().parent.parent
out = root / 'docs/evidence/2026-10-08-rc67-production'
sink = out / 'rerun'
logs = out / 'logs'
logs.mkdir(parents=True, exist_ok=True)
original = root / 'docs/evidence'
for directory in list(original.rglob('*')):
    if directory.is_dir() and out not in directory.parents and directory != out:
        (sink / directory.relative_to(original)).mkdir(parents=True, exist_ok=True)
tests = ['test_rc67_compatibility.js', 'test_rc66_compatibility.js', 'test_competition_reviewed.js', 'test_competition.js', 'test_rc64.js', 'test_rc65.js', 'test_rc66.js', 'test_rc66_defects.js', 'test_competition_adaptive.js', 'test_topic_session.js', 'test_rc67_policies.js', 'test_rc67_components.js', 'test_rc67_content.js', 'test_rc67_workflow.js', 'test_rc67_release_qa.js']
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
build_sha = hashlib.sha256((root / 'index.html').read_bytes()).hexdigest()
def check(test):
    env = dict(os.environ, AMC8_EVIDENCE_DIR=str(sink), AMC8_RELEASE_OUTPUT=str(out))
    command = ['node', '-r', './source/test_evidence_sink.js', 'source/' + test]
    at = time.monotonic()
    result = subprocess.run(command, cwd=root, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (logs / (test + '.log')).write_text(result.stdout)
    row = {'test': test, 'exitCode': result.returncode, 'seconds': round(time.monotonic()-at, 2), 'scriptSha256': hashlib.sha256((root/'source'/test).read_bytes()).hexdigest(), 'log': str((logs/(test+'.log')).relative_to(root))}
    print(('PASS ' if result.returncode == 0 else 'FAIL ') + test, flush=True)
    if result.returncode: print(result.stdout[-2400:], flush=True)
    return row
previous = None
targets = tests
if '--retry-failed' in sys.argv:
    previous = json.loads((out / 'production-gates.json').read_text())
    assert previous['productionSha256'] == build_sha
    assert previous['qaSha256'] == hashlib.sha256((root/'qa/index.html').read_bytes()).hexdigest()
    archive = out / 'attempts' / ('attempt-' + str(len(list((out/'attempts').glob('attempt-*')))+1))
    archive.mkdir(parents=True)
    shutil.copy2(out/'production-gates.json', archive/'production-gates.json')
    shutil.copytree(logs, archive/'logs')
    targets = [x['test'] for x in previous['tests'] if x['exitCode'] or x['scriptSha256'] != hashlib.sha256((root/'source'/x['test']).read_bytes()).hexdigest()]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    rows = list(pool.map(check, targets))
if previous:
    rows += [x for x in previous['tests'] if x['test'] not in targets]
    rows.sort(key=lambda x:tests.index(x['test']))
builds = []
for command in [['python3', 'source/build.py', '--check'], ['python3', 'source/build_qa.py', '--check']]:
    result = subprocess.run(command, cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    builds.append({'command': command, 'exitCode': result.returncode, 'output': result.stdout.strip()})
assert build_sha == hashlib.sha256((root / 'index.html').read_bytes()).hexdigest()
report = {'result': 'passed' if all(x['exitCode']==0 for x in rows+builds) else 'failed', 'startedAt': started, 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'productionSha256': build_sha, 'qaSha256': hashlib.sha256((root/'qa/index.html').read_bytes()).hexdigest(), 'tests': rows, 'buildChecks': builds, 'retriedTests': targets if previous else [], 'priorAttemptArchived': str(archive.relative_to(root)) if previous else None, 'limits': ['Program gates and Node VM UI simulation; real public browser verification is separate']}
(out / 'production-gates.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print('RC67 production release gates: ' + report['result'], flush=True)
raise SystemExit(0 if report['result']=='passed' else 1)
