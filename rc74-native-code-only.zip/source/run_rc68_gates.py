#!/usr/bin/env python3
"""Build first, run real checks, and refuse an incomplete RC68 release."""
import argparse, datetime, hashlib, json, os, pathlib, subprocess, sys, time, shutil
ROOT=pathlib.Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--stage',choices=['local','release'],default='local');p.add_argument('--evidence',default='docs/evidence/rc68');p.add_argument('--browser-evidence',help='Actual same-build browser result retrieved from the read-only CI run');a=p.parse_args()
E=(ROOT/a.evidence).resolve();E.mkdir(parents=True,exist_ok=True);logs=E/'gate-logs';logs.mkdir(exist_ok=True)
env=dict(os.environ,AMC8_RC68_EVIDENCE=str(E),AMC8_MUSE_AUDIT_OUTPUT=str(E/'regression'))
commands=[('build',[sys.executable,'source/build.py']),('qa-build',[sys.executable,'source/build_qa.py']),('build-check',[sys.executable,'source/build.py','--check']),('qa-check',[sys.executable,'source/build_qa.py','--check'])]
results=[];imported=None
if a.browser_evidence:
    source=pathlib.Path(a.browser_evidence).resolve();imported=json.loads(source.read_text())
    current=json.loads(subprocess.check_output(['node','-e',"process.stdout.write(JSON.stringify(require('./source/rc68_evidence').identity()))"],cwd=ROOT))
    assert all(imported.get(k)==current[k] for k in ['sourceTreeHash','buildSha256']), 'Browser evidence belongs to a different candidate'
    assert imported.get('result')=='passed' and imported.get('executedBasicScenes')==846 and imported.get('engine'), 'Incomplete actual browser acceptance'
    assert imported.get('executedRouteNodes',0)>=imported.get('declarations',{}).get('routeNodeCount',10**9), 'Route stages missing'
    assert imported.get('declarations',{}).get('productionConfigurations')==148 and imported.get('executedHintStages',0)>0, 'Configuration or hint stages missing'
    assert len(imported.get('normalJourneys',[]))==4 and imported.get('historyReplay',{}).get('result')=='passed', 'Normal/history browser journeys missing'
    assert imported.get('speechLifecycle',{}).get('stop') and not imported.get('errors'), 'Speech lifecycle or browser failures remain'
    target=E/'browser/results.json';target.parent.mkdir(exist_ok=True)
    if target.resolve()!=source:
        if target.exists():shutil.copyfile(target,E/'browser/before-ci-import.json')
        shutil.copyfile(source,target)
    results.append({'name':'actual-browser-ci-import','result':'passed','exitCode':0,'source':str(source),'localBrowserRun':False})
commands += [(x,['node','source/'+x+'.js']) for x in ['test_rc68_state','test_rc68_sources','test_rc68_reasoning','test_rc68_history','test_rc68_holdout','test_rc68_coverage','test_rc68_normal_entry','audit_rc67_muse_v2','test_rc68_muse']]
if not imported:commands.append(('test_rc68_browser',['node','source/test_rc68_browser.js']))
for name,cmd in commands:
    print('RC68 gate: '+name,flush=True)
    with (logs/(name+'.log')).open('w') as log:
        proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        start=time.monotonic()
        while proc.poll() is None:
            try:proc.wait(timeout=20)
            except subprocess.TimeoutExpired:print(name+' still running ('+str(int(time.monotonic()-start))+'s)',flush=True)
        code=proc.returncode
    state='passed' if code==0 else 'blocked' if code==2 else 'failed'
    results.append({'name':name,'exitCode':code,'result':state,'log':str((logs/(name+'.log')).relative_to(ROOT))})
    if name in ['build','qa-build','build-check','qa-check'] and code:break
required=['contracts/state','sources/acceptance','prototype/reasoning','history/compatibility','holdout/migration','coverage/reasoning','prototype/normal-entry','regression/semantic-audit','regression/muse-issues','browser/results']
reports={};blockers=[]
for name in required:
    f=E/(name+'.json')
    try:reports[name]=json.loads(f.read_text())
    except (OSError,json.JSONDecodeError):blockers.append(name+': evidence missing');continue
    if reports[name]['result']!='passed':blockers.append(name+': '+reports[name]['result'])
identity=json.loads(subprocess.check_output(['node','-e',"process.stdout.write(JSON.stringify(require('./source/rc68_evidence').identity()))"],cwd=ROOT))
for name,report in reports.items():
    if report.get('buildSha256')!=identity['buildSha256'] or report.get('sourceTreeHash')!=identity['sourceTreeHash']:blockers.append(name+': stale identity')
coverage=reports.get('coverage/reasoning',{})
if coverage.get('adaptedMultiStep')!=120 or coverage.get('adaptedCompact')!=21:blockers.append('120/21 reasoning coverage incomplete')
partial=[r['familyId'] for r in coverage.get('rows',[]) if r.get('normalization')!='explicit']
if partial:blockers.append(str(len(partial))+' legacy variation states need explicit normalization')
browser=reports.get('browser/results',{})
if browser.get('executedBasicScenes')!=846:blockers.append('846 real-browser basic scenes not executed')
if browser.get('executedRouteNodes',0)<browser.get('declarations',{}).get('routeNodeCount',10**9):blockers.append('All enabled route stages not executed in browser')
if len(browser.get('normalJourneys',[]))!=4:blockers.append('Four normal-entry browser journeys not executed')
if not browser.get('speechLifecycle',{}).get('stop'):blockers.append('Browser speech lifecycle not verified')
if a.stage=='release':
    progress=json.loads((ROOT/'docs/rc68-progress.json').read_text())
    for work in progress['packages']:
        if work['id']!='20' and work['status']!='completed':blockers.append('package '+work['id']+' not accepted')
failed=any(r['result']=='failed' for r in results)
report={'schemaVersion':1,'stage':a.stage,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),**identity,'result':'failed' if failed else 'blocked' if blockers else 'passed','checks':results,'releaseBlockers':blockers,'releaseEligible':not failed and not blockers,'publicDeployment':False,'partialVariationStates':partial,'limits':['No HTTP success or Node VM result substitutes for real browser acceptance','Pages permission, remote updates and public verification are required after these gates; no force push']}
(E/'release').mkdir(exist_ok=True);(E/'release'/('gates-'+a.stage+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'stage':a.stage,'result':report['result'],'releaseEligible':report['releaseEligible'],'blockers':blockers},ensure_ascii=False,indent=2),flush=True)
sys.exit(1 if failed else 2 if a.stage=='release' and blockers else 0)
