/* 33 original, single-question previews. A preview is never marked as unit mastery. */
'use strict';
const SAMPLE_TASKS = {
  A01:{level:'起步',mode:'choice',prompt:'哪张卡表示 16？',scene:{type:'ten',values:[14,16]},options:['左边','右边'],answer:1,hint:'先看十个，再数多出的格子。',explain:'右边一整排十格，再加六格，是16。'},
  A02:{level:'起步',mode:'number',prompt:'7 个圆点，还差几个到 10？',scene:{type:'ten',values:[7],target:10},answer:3,hint:'只数空着的格子。',explain:'十格板空三格，7＋3＝10。'},
  A03:{level:'桥梁',mode:'choice',prompt:'同样大的两块巧克力，哪份更多？',scene:{type:'fractions',values:[[3,4],[2,4]]},options:['左边 3/4','右边 2/4'],answer:0,hint:'每块都分成4份，只数涂色格。',explain:'整块一样大，3份比2份多。'},
  A04:{level:'桥梁',mode:'number',prompt:'20 格中涂了 10 格，占百分之几？',scene:{type:'grid',cols:10,rows:2,fill:10},answer:50,hint:'涂色刚好占一半。',explain:'一半就是50%。'},
  A05:{level:'桥梁',mode:'choice',prompt:'数轴上谁更大？',scene:{type:'line',labels:['−5','−4','−3','−2','−1','0']},options:['−5','−2'],answer:1,hint:'数轴上越靠右的数越大。',explain:'−2 在 −5 右边，所以 −2 更大。'},
  R01:{level:'起步',mode:'number',prompt:'每 3 个蓝点配 6 个红点。红点是蓝点的几倍？',scene:{type:'dots',groups:[['蓝点','🔵',3],['红点','🔴',6]]},answer:2,hint:'把红点每3个圈成一组。',explain:'红点可分两组，每组3个，所以是2倍。'},
  R02:{level:'桥梁',mode:'number',prompt:'4 个苹果卖 8 元，1 个多少钱？',scene:{type:'dots',groups:[['苹果','🍎',4],['价格','🪙',8]]},answer:2,hint:'把8元平均分给4个苹果。',explain:'8÷4＝2元/个。'},
  R03:{level:'进阶',mode:'number',prompt:'10 分钟走 2 千米，同样速度走 30 分钟呢？',scene:{type:'strips',groups:[['第1段10分','🚶',2],['第2段10分','🚶',2],['第3段10分','🚶',2]]},answer:6,hint:'30分钟里有几个10分钟？',explain:'三个10分钟，各走2千米，共6千米。'},
  R04:{level:'进阶',mode:'number',prompt:'长和宽都放大2倍，原来 2×3 的面积变成多少？',scene:{type:'rectangles',values:[[2,3],[4,6]]},answer:24,hint:'新图的长4、宽6；算新面积。',explain:'4×6＝24，面积是原来6的4倍。'},
  L01:{level:'桥梁',mode:'number',prompt:'□＋5＝12，□里填几？',scene:{type:'equation',tokens:['□','＋','5','=','12']},answer:7,hint:'从12里拿走5。',explain:'12−5＝7，7＋5＝12。'},
  L02:{level:'进阶',mode:'number',prompt:'两袋一样多，再加 3 个共 13 个。每袋几个？',scene:{type:'equation',tokens:['□','＋','□','＋','3','=','13']},answer:5,hint:'先去掉多出的3个，再平分两袋。',explain:'13−3＝10，两袋各5个。'},
  L03:{level:'起步',mode:'number',prompt:'2、5、8、11，接下来是几？',scene:{type:'sequence',tokens:['2','5','8','11','?']},answer:14,hint:'比较每次增加的数量。',explain:'每次加3，11＋3＝14。'},
  L04:{level:'进阶',mode:'number',prompt:'表中每往下一行，右边多 2。第 4 行是多少？',scene:{type:'table',rows:[['第1行','3'],['第2行','5'],['第3行','7'],['第4行','?']]},answer:9,hint:'从7接着加2。',explain:'3、5、7、9，对应第4行是9。'},
  N01:{level:'桥梁',mode:'multi',prompt:'点出能被 3 整除的数。',scene:{type:'tiles',tokens:['12','14','18']},options:['12','14','18'],answer:[0,2],hint:'可以把每个数每3个分一组。',explain:'12＝3×4，18＝3×6；14剩2。'},
  N02:{level:'进阶',mode:'number',prompt:'12 一共有几个正因数？',scene:{type:'equation',tokens:['1×12','2×6','3×4']},answer:6,hint:'三对数，每对有几个不同的数？',explain:'1、2、3、4、6、12，共6个。'},
  N03:{level:'进阶',mode:'number',prompt:'红灯每 6 分钟亮，蓝灯每 8 分钟亮。一起亮后，几分钟再一起亮？',scene:{type:'table',rows:[['红灯','6','12','18','?'],['蓝灯','8','16','?','32']]},answer:24,hint:'两行数字继续写，找第一个共同时间。',explain:'6和8的最小公倍数是24。'},
  N04:{level:'桥梁',mode:'choice',prompt:'今天星期五。再过两天是星期几？',scene:{type:'sequence',tokens:['周五','→','周六','→','?']},options:['星期日','星期一','星期三'],answer:0,hint:'一天后是周六，再往后一天。',explain:'周五过两天是周日。'},
  G01:{level:'桥梁',mode:'number',prompt:'长 4 格、宽 3 格，沿外边走一圈几格？',scene:{type:'grid',cols:4,rows:3,fill:12},answer:14,hint:'周长沿外边，不数里面的小格。',explain:'4＋3＋4＋3＝14格。'},
  G02:{level:'进阶',mode:'number',prompt:'三角形里两个角是 50° 和 60°，第三个角几度？',scene:{type:'triangle',labels:['50°','60°','?']},answer:70,hint:'三角形三个内角一共180°。',explain:'180−50−60＝70°。'},
  G03:{level:'桥梁',mode:'number',prompt:'4×4 方格剪去右上角 2×2，一共剩几格？',scene:{type:'grid',cols:4,rows:4,fill:12,cut:[2,3,6,7]},answer:12,hint:'先数整块，再减掉被剪去的4格。',explain:'16−4＝12格。'},
  G04:{level:'桥梁',mode:'number',prompt:'圆心到圆边长 3 格。穿过圆心的整条线长几格？',scene:{type:'circle',radius:3},answer:6,hint:'整条线由两段半径组成。',explain:'直径＝3＋3＝6格。'},
  G05:{level:'进阶',mode:'number',prompt:'边长 2 的正方形，每边放大 2 倍，新面积是多少？',scene:{type:'rectangles',values:[[2,2],[4,4]]},answer:16,hint:'新边长是4，算4×4。',explain:'放大后面积16，原来面积4。'},
  G06:{level:'进阶',mode:'number',prompt:'直角两边分别长 3、4，斜边长几？',scene:{type:'rightTriangle'},answer:5,hint:'试比较3²＋4²与一个平方数。',explain:'3²＋4²＝25，斜边长5。'},
  G07:{level:'桥梁',mode:'number',prompt:'一个立方体一共有几个面？',scene:{type:'cube'},answer:6,hint:'看见的面以外，还有背后和底下。',explain:'前后、左右、上下，共6个面。'},
  C01:{level:'起步',mode:'number',prompt:'只苹果 2 人、两种都喜欢 3 人、只香蕉 2 人。喜欢苹果的有几人？',scene:{type:'fruit'},answer:5,hint:'苹果整组包括红色和橙色。',explain:'只苹果2人＋两种都喜欢3人＝5人。'},
  C02:{level:'起步',mode:'number',prompt:'2 顶帽子，每顶都能配 3 双鞋。共有几种搭配？',scene:{type:'table',rows:[['红帽','黑鞋','白鞋','蓝鞋'],['黄帽','黑鞋','白鞋','蓝鞋']]},answer:6,hint:'每顶帽子各能配3双鞋。',explain:'3＋3＝6种，且没有重复。'},
  C03:{level:'进阶',mode:'number',prompt:'A、B、C 排成一排，有多少种顺序？',scene:{type:'tiles',tokens:['A','B','C']},answer:6,hint:'先选第1个，有3种；再选第2个，有2种。',explain:'3×2×1＝6种，每个顺序只数一次。'},
  C04:{level:'桥梁',mode:'number',prompt:'苹果组 5 人、香蕉组 5 人，共同 3 人。不同的小朋友有几人？',scene:{type:'fruit'},answer:7,hint:'共同的3人被两张整组表各数了一次。',explain:'5＋5−3＝7人。'},
  D01:{level:'起步',mode:'number',prompt:'图上蓝球比红球多几个？',scene:{type:'dots',groups:[['红球','🔴',3],['蓝球','🔵',5]]},answer:2,hint:'把两排一对一对齐。',explain:'5−3＝2。'},
  D02:{level:'桥梁',mode:'number',prompt:'三个数 2、4、6，平均是多少？',scene:{type:'dots',groups:[['第1组','🔵',2],['第2组','🔵',4],['第3组','🔵',6]]},answer:4,hint:'三组合起来，再平均分三份。',explain:'(2＋4＋6)÷3＝4。'},
  D03:{level:'进阶',mode:'choice',prompt:'掷一枚公平骰子，出奇数的机会是多少？',scene:{type:'tiles',tokens:['1','2','3','4','5','6']},options:['1/2','1/3','2/3'],answer:0,hint:'六面中，奇数有1、3、5。',explain:'6种等可能结果中有3种奇数，3/6＝1/2。'},
  S01:{level:'桥梁',mode:'choice',prompt:'对折后，左上角的点会到哪里？',scene:{type:'mirror'},options:['右上角','左下角','右下角'],answer:0,hint:'沿中间竖线对折，高度不变。',explain:'左右互换、上下不变，落在右上角。'},
  S02:{level:'进阶',mode:'choice',prompt:'A 紧挨着 B 的左边，C 不在中间。哪种顺序符合？',scene:{type:'tiles',tokens:['①','②','③']},options:['A—B—C','C—B—A','B—A—C'],answer:0,hint:'先把 A、B 当成一组，A 必须在左。',explain:'A—B—C 满足两条条件。'}
};
Object.entries(SAMPLE_TASKS).forEach(([code,task])=>{task.id='SAMPLE-'+code});
if(typeof module!=='undefined')module.exports={SAMPLE_TASKS};
