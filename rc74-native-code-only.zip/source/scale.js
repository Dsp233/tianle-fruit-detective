'use strict';
const SCALE_TASKS={
 'R04.01':{kind:'pair',red:2,blue:3,factor:3,context:'花束配色',prompt:'每束红2朵、蓝3朵。把两色一起复制到3束，比较红蓝关系；也可以试单独复制一色后撤回。',explain:'红6蓝9，两色都乘3，仍是2:3。',reason:{prompt:'为什么新旧花束的红蓝关系一样？',options:['红与蓝都复制3份','只复制红花也保持原关系','看红蓝合计15就能判断关系'],answer:0}},
 'R04.02':{kind:'length',short:2,long:4,factor:3,context:'长方形边框',prompt:'短边2格、长边4格。把每条边都放大到原来的3倍，观察新边长。',explain:'短边6格、长边12格；两条长度都乘3。',reason:{prompt:'哪种操作保留原形状？',options:['短边与长边同时乘3','只把长边乘3','把两边都加3就一定同形'],answer:0}},
 'R04.03':{kind:'area',rows:2,cols:3,factor:2,context:'方格地毯',prompt:'原来2行3列。将行数和列数分别放大2倍，实际铺出新方格，比较面积。',explain:'新图4行6列共24格；原图6格，面积变4倍。',reason:{prompt:'边长都变2倍，为什么面积变4倍？',options:['行数乘2且列数乘2，格数乘2×2','只看一条边就说面积2倍','把行列数相加就得面积'],answer:0}},
 'R04.04':{kind:'map',per:5,count:3,from:'1厘米地图线',to:'千米实路',context:'地图距离',prompt:'地图每1厘米代表实际5千米。逐张放3张一厘米卡，读出实际路程。',explain:'三张卡各代表5千米，合计15千米。',reason:{prompt:'为什么3厘米对应15千米？',options:['每1厘米都是5千米，三份相加','地图有3厘米，实际就只有3千米','只取第一厘米的5千米'],answer:0}},
 'R04.05':{kind:'change',start:100,add:20,remove:24,choices:['96','100','76'],correctChoice:'96',context:'连续价格变化',prompt:'价格从100元先涨20%。逐元添到120；再按新价120元降20%，逐元拿走24，选最后价格。',explain:'原价100涨20到120，新价120的20%是24，最后96元。',reason:{prompt:'为什么没有回到100元？',options:['第二次20%以120为基准，减少24元','两次20%一定互相抵消','第二次仍按原价100减少20元'],answer:0}}
};
for(const [skillId,t] of Object.entries(SCALE_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:21,mode:'scaleLab',phase:'练',hint:'找准单位份、两条边或新的百分比基准，再动手改变模型。'});
if(typeof module!=='undefined')module.exports={SCALE_TASKS};
