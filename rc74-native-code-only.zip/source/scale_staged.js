'use strict';
const SCALE_CASES={
 'R04.01':[
  [{kind:'pair',red:3,blue:1,factor:2,context:'舞台灯'},'每组红3盏、蓝1盏，同时复制成两组。','红6蓝2，仍为3:1。','花束换灯光，份数改二'],
  [{kind:'pair',red:1,blue:2,factor:4,context:'彩旗'},'每组红1蓝2，做四组相同比例的彩旗。','红4蓝8，比仍1:2。','无提示：一色只有一面'],
  [{kind:'pair',red:2,blue:5,factor:2,context:'棋子袋'},'原来每袋红2蓝5，做两袋相同配方。','红4蓝10。','隔日：两色总数不同'],
  [{kind:'pair',red:4,blue:2,factor:3,context:'手工贴纸'},'每份红4蓝2，复制成三份同样配方。','红12蓝6。','备用：大份和较多红色']
 ],
 'R04.02':[
  [{kind:'length',short:3,long:5,factor:2,context:'模型边框'},'短边3格、长边5格。两边分别放大2倍。','短边6、长边10，均是原长2倍。','原边不成整倍数，保持同形'],
  [{kind:'length',short:2,long:5,factor:4,context:'照片外框'},'短边2格、长边5格。把两边都变成原来的4倍。','新边长8格与20格。','无提示：放大倍数改四'],
  [{kind:'length',short:4,long:6,factor:2,context:'海报'},'短边4格、长边6格。两边都按2倍画新海报。','新边8格和12格。','隔日：原边长均为偶数'],
  [{kind:'length',short:1,long:3,factor:3,context:'长方形卡'},'短边1格、长边3格，都放大3倍。','新边长3格和9格。','备用：短边为一单位']
 ],
 'R04.03':[
  [{kind:'area',rows:2,cols:2,factor:3,context:'方形花坛'},'原图2行2列，分别把行、列扩成3倍，观察新面积。','新图6行6列共36格，是原4格的9倍。','长方形换正方形，线性三倍'],
  [{kind:'area',rows:1,cols:4,factor:2,context:'地砖条'},'原图1行4列，分别将行列变2倍，数新格数。','2行8列共16格，原4格，面积4倍。','无提示：原图仅一行'],
  [{kind:'area',rows:3,cols:2,factor:2,context:'纸片'},'原来3行2列，两条方向都翻倍。','6行4列共24格；原6格，面积四倍。','隔日：原行列交换'],
  [{kind:'area',rows:2,cols:3,factor:3,context:'长方形地毯'},'2行3列的图，行列分别变3倍。','新图6行9列共54格，原6格的9倍。','备用：两条方向都三倍']
 ],
 'R04.04':[
  [{kind:'map',per:3,count:2,from:'2杯面粉卡',to:'个蛋糕',context:'蛋糕配方'},'每2杯面粉可做3个蛋糕。逐张放两张2杯卡，找4杯做几个。','两份配方可做6个蛋糕。','地图换配方，输入单位由厘米换杯'],
  [{kind:'map',per:4,count:3,from:'1厘米地图线',to:'千米实路',context:'徒步地图'},'每1厘米代表4千米，摆3张地图线卡。','实际12千米。','无提示：每厘米代表路程改4'],
  [{kind:'map',per:2,count:4,from:'1袋种子',to:'盆花',context:'园艺配方'},'每袋种子能种2盆花，逐张放四袋卡。','四袋种8盆花。','隔日：比例单位换花盆'],
  [{kind:'map',per:6,count:2,from:'1厘米地图线',to:'千米实路',context:'山路地图'},'每1厘米代表6千米，放2厘米地图线卡。','实际12千米。','备用：地图线长度缩成两厘米']
 ],
 'R04.05':[
  [{kind:'change',start:50,add:10,remove:12,choices:['48','50','40'],correctChoice:'48',context:'玩具价格'},'从50元先涨20%，逐元添10到60；再按60元降20%，逐元拿走12。','50→60→48元，第二次20%以60为基准。','原价换50，增长和降低仍同为20%'],
  [{kind:'change',start:200,add:20,remove:22,choices:['198','200','180'],correctChoice:'198',context:'储蓄积分'},'积分200先涨10%，再按新量降10%。先添20到220，再拿走22。','最后198点。','无提示：基数200，百分点10'],
  [{kind:'change',start:100,add:30,remove:39,choices:['91','100','70'],correctChoice:'91',context:'游戏分数'},'分数100先涨30%到130，再按130降30%，逐个拿走39。','最后91分。','隔日：百分比改30'],
  [{kind:'change',start:80,add:20,remove:25,choices:['75','80','55'],correctChoice:'75',context:'图书数量'},'图书80本先增25%到100本，再按100本减25%，逐本拿走25。','最后75本。','备用：基数80，百分比改25']
 ]
};
const scaleStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(SCALE_CASES)){
 if(cases.length!==4)throw Error('Four R04 cases required: '+skillId);scaleStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];scaleStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:22,mode:'scaleLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'先认清单位份、对应边或变化后的新基准。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={SCALE_CASES};
