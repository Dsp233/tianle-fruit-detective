'use strict';
const setsFixtures=typeof module!=='undefined'?require('./sets').SETS_FIXTURES:SETS_FIXTURES;
const SETS_CASES={
 'C01.01':[
  [{people:setsFixtures.sports,labels:['体育','艺术']},'登记体育、艺术、两项都不的三个名册，再按身份归位，填写全部不同身份数。','全体8个身份；共同成员2人虽在两册出现，仍各一人。','水果换活动，增加两项都不的人'],
  [{people:setsFixtures.twins,labels:['绘画','音乐']},'独立登记归位全部名册。两个都叫“小同”的人物有不同编号；填写不同身份总数。','不同编号的小同是两个身份，共7人。','无提示：同名不同身份反例'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类']},'隔日登记两个不重叠活动名册及未参加名册，归位并填全部不同身份数。','全体6人，没有共同成员也要保留未参加者。','隔日：交集为空，含未参加者'],
  [{people:setsFixtures.clubs,labels:['科学','戏剧']},'独立登记归位三册，核对同编号不复制，再填全体不同身份数。','全体10人；共同1人只算一次。','备用：不等组与更多未参加者']
 ],
 'C01.02':[
  [{people:setsFixtures.sports,labels:['体育','艺术'],queries:['A','R','O']},'登记归位体育/艺术人物，分别点体育整组、只体育、两项都参加的全部身份。','体育整组含交集；只体育排除交集。','活动情境与不等完整组'],
  [{people:setsFixtures.clubs,labels:['科学','戏剧'],queries:['B','Y','O']},'独立登记归位，再分别点戏剧整组、只戏剧、两项都参加。','戏剧整组是只戏剧加共同成员。','无提示：换指定整组与仅有区'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类'],queries:['A','R','O']},'隔日登记归位，分别点游泳整组、只游泳、两项都参加；无成员须点“这个集合为空”。','游泳整组与只游泳相同；交集为空。','隔日：空交集，整组与仅有组可能相同'],
  [{people:setsFixtures.twins,labels:['绘画','音乐'],queries:['R','O','B']},'独立按编号登记同名人物后，分别点只绘画、两项都参加、音乐整组。','按稳定身份归组，不按同名合并。','备用：同名身份与另一组完整范围']
 ],
 'C01.03':[
  [{people:setsFixtures.sports,labels:['体育','艺术'],countKeys:['R','O','Y','N'],target:'U'},'登记归位并填四个分区人数，最后填写全体人数，包含两项都不的区域。','3＋2＋1＋2＝8人。','三分区并集改为四分区全集'],
  [{people:setsFixtures.clubs,labels:['科学','戏剧'],countKeys:['R','O','Y','N'],target:'I'},'独立登记归位、填四分区人数，再填至少一项人数；两项都不在全集内但不在目标内。','2＋1＋4＝7，未参加3人不计并集。','无提示：四分区中筛目标三块'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类'],countKeys:['R','O','Y','N'],target:'I'},'隔日登记归位并填四分区人数，再求至少一项不同人数；空区域也填0。','2＋0＋3＝5，不是全体6。','隔日：空分区与全集外补充对象'],
  [{people:setsFixtures.classroom,labels:['绘画','音乐'],countKeys:['R','O','Y'],target:'I'},'独立登记全班归位，填三个报名分区人数，填至少报名一项人数。','2＋3＋2＝7。','备用：全班包含未报名，目标仍并集']
 ],
 'C01.04':[
  [{people:setsFixtures.large,labels:['体育','艺术'],target:'I'},'体育整组18、艺术14、共同5。登记归位原身份，用两种不同表示实际拼组式求至少一项人数。','18＋14−5＝27；13＋5＋9＝27等。','大量人数与完整组/分区两种表示'],
  [{people:setsFixtures.sports,labels:['体育','艺术'],target:'I'},'独立登记归位，再用两种不同表示的实际计数组式求至少一项，不只交换加数。','5＋3−2＝6；3＋2＋1＝6等。','无提示：不等完整组'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类'],target:'I'},'隔日登记归位，用两种不同区域表示的实际组式求至少一项；空交集卡可以有0成员。','2＋3−0＝5；2＋0＋3＝5等。','隔日：空交集下仍核对逐身份一次'],
  [{people:setsFixtures.clubs,labels:['科学','戏剧'],target:'I'},'独立登记归位，用两种实际区域表示的有效组式求至少一项，填两次人数。','3＋5−1＝7；2＋1＋4＝7等。','备用：交集1与较大仅有区']
 ],
 'C01.05':[
  [{people:setsFixtures.sports,labels:['体育','艺术'],target:'I'},'登记归位，叠两个完整活动名册，逐人去掉实际多算的一次，填至少一项人数。','5＋3−2＝6。','活动情境与两完整组不等'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类'],target:'I'},'独立登记归位并叠两个不重叠名册；只移去实际多算的一次，没有重复时不要移人，填不同人数。','2＋3＝5，无需去掉任何人。','无提示：没有重复的反例'],
  [{people:setsFixtures.clubs,labels:['科学','戏剧'],target:'I'},'隔日登记归位，叠完整名册并逐人修正重复，未参加者不算至少一项，填人数。','3＋5−1＝7。','隔日：共同1与全体额外3'],
  [{people:setsFixtures.large,labels:['体育','艺术'],target:'I'},'独立登记18/14/共同5名册，归位后叠加，逐个移去共同身份多算的一次，填不同人数。','18＋14−5＝27。','备用：较大名册真实去重']
 ],
 'C04.01':[
  [{people:setsFixtures.clubs,labels:['科学','戏剧'],queries:['U']},'全集指定全班。登记三册并归位，点出全班全集所有身份，再填人数，未参加者也属于全班。','全班10，报名至少一项7。','全集与报名范围不同的活动情境'],
  [{people:setsFixtures.sports,labels:['体育','艺术'],queries:['U']},'独立登记归位全班，再实际点全集成员并填人数。','全班8，报名6。','无提示：全体与并集区别'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类'],queries:['U']},'隔日登记两个无交集活动及未参加册，归位后点全班全集并填人数。','全班6，不因无交集而丢未参加1人。','隔日：空交集且未参加者仍在全集'],
  [{people:setsFixtures.classroom,labels:['阅读','乐器'],queries:['U']},'独立登记阅读/乐器/两项都不三册，按指定全班全集点全部原身份，填人数。','9人，包括未参加2人。','备用：活动标签改变']
 ],
 'C04.02':[
  [{people:setsFixtures.classroom,labels:['绘画','音乐'],queries:['notB'],target:'notB'},'全班是全集。登记归位，点“不参加音乐”的所有原人物，再实际拼同一集合的计数卡，填人数。','只绘画2与未参加2，共4；9−5＝4。','补集从不A改不B'],
  [{people:setsFixtures.sports,labels:['体育','艺术'],queries:['notA'],target:'notA'},'独立登记归位全班，点不参加体育的成员，再实际拼同一集合并填人数。','只艺术1与两项都不2，共3。','无提示：补集包含两类原人物'],
  [{people:setsFixtures.clubs,labels:['科学','戏剧'],queries:['N'],target:'N'},'隔日全班作全集，登记归位，点“两项都不”的成员，再用实际计数卡得到同一集合并填人数。','未参加3；10＋1−3−5＝3，或直接N区3。','隔日：不参加一项改两项都不'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类'],queries:['N'],target:'N'},'独立登记归位全班，点两项都不的实际成员，再拼同一集合计数并填人数。','全班6−游泳2−棋类3＝1。','备用：无交集时的两项都不']
 ],
 'C04.03':[
  [{people:setsFixtures.sports,labels:['体育','艺术'],queries:['O','I','exact1']},'登记归位后，分别点体育艺术都参加、至少一项、恰好一项的全部实际成员。','交集2，并集6，恰好一项4。','活动情境与三个目标分别核对'],
  [{people:setsFixtures.clubs,labels:['科学','戏剧'],queries:['I','O','exact1']},'独立登记归位，再分别点至少一项、都参加、恰好一项，勿把未参加者添入。','并集7，交集1，恰好一项6。','无提示：目标顺序交换'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类'],queries:['O','I','exact1']},'隔日登记归位再点三类目标；空集合须明确标空。','交集空；并集与恰好一项都为同样5个原身份。','隔日：不同定义可能给相同集合'],
  [{people:setsFixtures.classroom,labels:['阅读','乐器'],queries:['exact1','I','O']},'独立登记归位，分别点恰好一项、至少一项、都参加的实际成员。','恰好一项4，至少一项7，共同3。','备用：先问恰好一项']
 ],
 'C04.04':[
  [{people:setsFixtures.large,labels:['体育','艺术'],target:'I'},'登记18/14/共同5名册归位，实际叠完整名单，逐身份修正多计的一次，填至少一项人数。','18＋14−5＝27。','较大名册的实际重复项修正'],
  [{people:setsFixtures.clubs,labels:['科学','戏剧'],target:'I'},'独立登记归位全班，叠两个完整活动名单，逐人修正重复，填至少一项人数。','3＋5−1＝7，全班10不等于报名7。','无提示：全班外的目标范围'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类'],target:'I'},'隔日叠无交集完整名册，按实际重复情况决定是否移去，再填不同报名身份数。','无重复，2＋3＝5。','隔日：不能机械删一个共同人数'],
  [{people:setsFixtures.sports,labels:['体育','艺术'],target:'I'},'独立登记归位，叠两完整册并逐身份去重，填写至少一项人数。','5＋3−2＝6。','备用：不等组与未参加者']
 ],
 'C04.05':[
  [{people:setsFixtures.clubs,labels:['科学','戏剧'],target:'N'},'登记归位全班，用实际计数卡分别直接取“两项都不”及从全集排除并集，得到同一身份集合，填两次人数。','直接N区3；间接10＋1−3−5＝3。','目标由至少一项改两项都不，直接/间接都对应身份'],
  [{people:setsFixtures.sports,labels:['体育','艺术'],target:'I'},'独立登记归位，做一条直接覆盖至少一项的实际组式和一条从全班排除两项都不的组式，填人数。','直接5＋3−2＝6；间接8−2＝6。','无提示：两方法需不同表示'],
  [{people:setsFixtures.classroom,labels:['阅读','乐器'],target:'notA'},'隔日登记归位，分别直接取不阅读的两类区域及从全班排除阅读组，拼实际计数卡并填人数。','直接只乐器2＋未参加2＝4；间接9−5＝4。','隔日：目标改为单组补集'],
  [{people:setsFixtures.disjoint,labels:['游泳','棋类'],target:'I'},'独立登记归位，分别直接合并报名区域和从全班排除未参加者，拼两条实际组式并填人数。','直接2＋3＝5；间接6−1＝5。','备用：空交集仍须真实直接/间接两法']
 ]
};
const setsStageSource=typeof module!=='undefined'?require('./sets').SETS_TASKS:SETS_TASKS,setsStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(SETS_CASES)){
 if(cases.length!==4)throw Error('Four set cases required: '+skillId);setsStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i],base=setsStageSource[skillId];setsStageTarget[skillId][kind]={kind:base.kind,queries:base.queries,countKeys:base.countKeys,target:base.target,id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:54,mode:'setsLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,context:params.context||prompt.slice(0,16),prompt,explain,changeDimension,...(kind==='transfer'?{hint:'全集先定，稳定身份归位；人数卡作用到具体人物，每个目标身份最后只计一次。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={SETS_CASES};
