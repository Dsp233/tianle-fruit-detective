'use strict';
const SIMILAR_TASKS={
 'G05.01':{kind:'correspond',points:[[0,0],[2,0],[0,3]],factor:3,rotation:90,targetLabels:['Q','R','P'],edgeIndex:0,angleIndex:0,context:'在旋转图中配对应对象',prompt:'原三角形ABC被整体放大3倍并转过90°，新图顶点标为Q、R、P。点实际顶点逐对连线，再标出与AB及角A对应的边和角。',explain:'A对应Q，B对应R，C对应P；AB对应QR，角A对应角Q。旋转改变方向，不改变对应。',reason:{prompt:'为什么不能按图中上下位置配点？',options:['旋转会改变方向，要核对对应端点、边与角','总把上方点配上方点','只看填充颜色即可'],answer:0}},
 'G05.02':{kind:'resize',width:3,height:2,goalX:3,goalY:3,context:'实际同比缩放两条方向',prompt:'原矩形宽3格、高2格。实际把宽、高方向都变为3倍，观察每个顶点和边的位置，再判断新旧图是否相似。',explain:'新图9×6，两方向都乘3，保持原宽高比；只改一个方向一般不保持相似。',reason:{prompt:'什么操作保留原形状？',options:['对应方向的边长同时乘相同倍数','只把宽乘3','两条边都加3即可'],answer:0}},
 'G05.03':{kind:'perimeter',width:3,height:2,goalX:3,goalY:3,context:'实际沿两图外边量一圈',prompt:'把3×2矩形两方向放大3倍。沿原图和新图外边逐单位描完整一圈，再填写新周长是原周长几倍。',explain:'原外边10单位，新外边30单位，周长3倍；面积倍数不能替代周长倍数。',reason:{prompt:'为什么周长只变3倍？',options:['每一条外边都变3倍，相加也变3倍','有两个方向就一定9倍','把内部方格数相加就是周长'],answer:0}},
 'G05.04':{kind:'area',width:3,height:2,goalX:3,goalY:3,context:'实际铺原图与放大图单位格',prompt:'把3×2矩形两方向放大3倍，用同样大小的1×1格铺满原图与新图，再填写新面积是原面积几倍。',explain:'原6格，新54格，面积9倍；行与列分别乘3，总格数乘3×3。',reason:{prompt:'为什么不是面积3倍？',options:['两个方向分别乘3，单位格总数乘9','只看一条边就够了','把长和宽相加表示面积'],answer:0}},
 'G05.05':{kind:'inverse',width:4,height:2,newWidth:10,context:'用对应边反求并实际检验比例',prompt:'原矩形一条边4厘米，新图对应边10厘米。填写长度比例，再实际同比缩放两方向，使对应边到10厘米，检验该比例。',explain:'10÷4＝2.5倍；实际宽10、高5，两个方向同比缩放。',reason:{prompt:'如何从对应边反求比例？',options:['新对应边除以原对应边，再同比检验','把10和4相乘','用面积倍数直接当边长倍数'],answer:0}}
};
for(const [skillId,t] of Object.entries(SIMILAR_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:47,mode:'similarLab',phase:'练',hint:'先核对对应对象；两方向同比保持相似，周长看单位边，面积看单位格。'});
if(typeof module!=='undefined')module.exports={SIMILAR_TASKS};
