'use strict';
const SIMILAR_CASES={
 'G05.01':[
  [{kind:'correspond',points:[[0,0],[3,0],[1,2]],factor:2,rotation:180,targetLabels:['R','P','Q'],edgeIndex:1,angleIndex:2,context:'换三角形与指定边角'},'原三角形ABC放大2倍并旋转180°，新点标R、P、Q。逐对配实际顶点，再标出与BC及角C对应的边和角。','A→R、B→P、C→Q；BC→PQ，角C→角Q。','三角形从直角换为非直角，转向、标签与指定边角改变'],
  [{kind:'correspond',points:[[0,0],[2,0],[0,4]],factor:2,rotation:90,targetLabels:['P','R','Q'],edgeIndex:0,angleIndex:1,context:'独立旋转配点'},'独立给放大2倍并转90°的三角形逐对配点；新点标P、R、Q。实际标与AB、角B对应的边角。','A→P、B→R、C→Q；AB→PR，角B→角R。','无提示：长短边与标签顺序改变'],
  [{kind:'correspond',points:[[0,0],[4,0],[1,2]],factor:1.5,rotation:270,targetLabels:['P','R','Q'],edgeIndex:2,angleIndex:0,context:'隔日斜边对应'},'隔日新图放大1.5倍并转270°。逐对配ABC与新点P、R、Q，再标与CA和角A对应的边角。','CA→QP，角A→角P；旋转不改变对应。','隔日：非整数缩放、另一个转向与指定边'],
  [{kind:'correspond',points:[[0,0],[3,0],[1,2]],factor:2,rotation:45,targetLabels:['Q','P','R'],edgeIndex:0,angleIndex:2,context:'备用斜向三角形'},'独立配原图与放大2倍、转45°的新图顶点；新点标Q、P、R。实际标与AB和角C对应的对象。','AB→QP，角C→角R。','备用：斜向图与另外的标签对应']
 ],
 'G05.02':[
  [{kind:'resize',width:3,height:2,goalX:3,goalY:2,context:'不等比拉伸的反例'},'原3×2矩形，实际把宽方向变3倍、高方向变2倍。观察9×4新图，再判断是否与原图相似。','两方向倍数不同，宽高比改变，不保持相似。','同比放大改为两个方向不同倍数'],
  [{kind:'resize',width:2,height:2,goalX:2,goalY:2,context:'独立整体放大'},'独立把2×2方形两个方向都变2倍，实际检验是否相似。','4×4，保持相似。','无提示：方形整体放大'],
  [{kind:'resize',width:4,height:2,goalX:.5,goalY:.5,context:'隔日同比缩小'},'隔日把4×2矩形两个方向都缩到一半，实际判断是否保持相似。','2×1，保持相似。','隔日：放大改缩小'],
  [{kind:'resize',width:2,height:3,goalX:1.5,goalY:1.5,context:'备用非整数倍'},'独立把2×3矩形两方向都变1.5倍，实际判断新旧图是否相似。','3×4.5，保持相似。','备用：非整数同倍缩放']
 ],
 'G05.03':[
  [{kind:'perimeter',width:2,height:4,goalX:1.5,goalY:1.5,rotation:90,context:'转向后实际描边'},'2×4矩形两方向放大1.5倍，新图转90°。实际描完两图外边全部单位段，填写周长倍数；转向不改变长度。','原12单位，新18单位，周长1.5倍。','整数放大改1.5倍并旋转，不按上下方向找边'],
  [{kind:'perimeter',width:2,height:3,goalX:2,goalY:2,context:'独立描两圈'},'独立把2×3矩形两方向变2倍，描完原图与新图的每个单位外边，填写周长倍数。','10变20，周长2倍。','无提示：另一个放大倍数'],
  [{kind:'perimeter',width:4,height:2,goalX:.5,goalY:.5,rotation:180,context:'隔日缩小外边'},'隔日把4×2矩形两个方向缩成一半。新图转180°，实际描完整两圈外边，再填周长倍数。','12变6，周长1/2倍。','隔日：缩小与旋转'],
  [{kind:'perimeter',width:2,height:2,goalX:3,goalY:3,context:'备用方形周长'},'独立把2×2方形两方向变3倍，逐单位描完原图与新图外边，填写周长倍数。','8变24，周长3倍。','备用：方形外边']
 ],
 'G05.04':[
  [{kind:'area',width:2,height:2,goalX:2,goalY:2,remove:[[0,0],[0,1],[1,0],[1,1]],context:'放大后只比较剩余面积'},'原2×2方形。先实际把两方向放大2倍；新4×4图左上2×2已剪去。用同大小单位格铺原图和新图保留区，填写保留面积是原图几倍。','原4格，新保留12格，是3倍；完整放大面积本为4倍。','同比面积关系加预剪条件，目标改剩余面积'],
  [{kind:'area',width:3,height:2,goalX:2,goalY:2,context:'独立铺放大图'},'独立把3×2矩形两方向变2倍，用同样单位格铺满两图，再填写面积倍数。','6变24，面积4倍。','无提示：双向2倍'],
  [{kind:'area',width:4,height:4,goalX:.5,goalY:.5,context:'隔日缩小面积'},'隔日把4×4方形两方向缩到一半。实际铺满两图单位格，填写新面积是原面积几倍。','16变4，面积1/4倍。','隔日：缩小后面积比为分数'],
  [{kind:'area',width:2,height:2,goalX:3,goalY:3,context:'备用铺方形'},'独立把2×2方形两方向变3倍，实际铺满原图和新图单位格，填写面积倍数。','4变36，面积9倍。','备用：方形两方向三倍']
 ],
 'G05.05':[
  [{kind:'inverse',width:4,height:4,newWidth:2,context:'反求缩小比例'},'原图对应边4厘米，新图2厘米。填写新/原长度比例，再实际同比缩小两方向，使对应边到2厘米。','2÷4＝0.5倍；两个方向都缩一半。','对应边从变长改变短，反求缩小比例'],
  [{kind:'inverse',width:2,height:1,newWidth:6,context:'独立反求整数倍'},'独立根据原对应边2厘米、新对应边6厘米填写比例，再实际同比缩放两方向检验。','3倍，新尺寸6×3。','无提示：整数对应比'],
  [{kind:'inverse',width:2,height:4,newWidth:3,context:'隔日反求1.5倍'},'隔日原对应边2厘米、新对应边3厘米。先填比例，再实际同比缩放，使对应边到3厘米。','1.5倍，新尺寸3×6。','隔日：另一个非整数比例'],
  [{kind:'inverse',width:4,height:2,newWidth:8,context:'备用反求双倍'},'独立根据原对应边4厘米、新对应边8厘米反求比例，并实际同比缩放两方向检验。','2倍，新尺寸8×4。','备用：已知对应边换数并实际代回']
 ]
};
const similarStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(SIMILAR_CASES)){
 if(cases.length!==4)throw Error('Four G05 cases required: '+skillId);similarStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];similarStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:48,mode:'similarLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'对应跟端点、边角走；分别量外边与铺保留格。反求长度比用新对应边除以原对应边，再实际检验。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={SIMILAR_CASES};
