'use strict';
function solidBoxCells(x,y,z){return Array.from({length:z},(_,k)=>Array.from({length:y},(_,j)=>Array.from({length:x},(_,i)=>[i,j,k])).flat()).flat()}
const SOLID_NETS={cross:[[0,0],[1,0],[-1,0],[0,1],[0,-1],[0,2]],row:[[0,0],[1,0],[2,0],[3,0],[1,1],[1,-1]],stair:[[0,0],[1,0],[1,1],[2,1],[2,2],[3,2]],strip:[[0,0],[1,0],[2,0],[3,0],[4,0],[5,0]],rectangle:[[0,0],[1,0],[2,0],[0,1],[1,1],[2,1]]};
const SOLID_TASKS={
 'G07.01':{kind:'counts',nets:[SOLID_NETS.cross],context:'从平面纸片折成盒子再数对象',prompt:'实际逐面折起六面纸片，转动并翻面检查隐藏面。分别点选立体中的每个面、每条边和每个顶点，填写三种对象的个数；重合的同一条边只数一次。',explain:'六个面合拢后，共12条不同边、8个不同顶点；纸片上重复的边/顶点要按折后位置去重。',reason:{prompt:'为什么不能把每面四条边直接乘6？',options:['折后相邻面共用同一条边，应按实际位置去重','六乘四就是不同边数','每个点都单独属于一个面'],answer:0}},
 'G07.02':{kind:'match',nets:[SOLID_NETS.cross],context:'同一标记在展开与合拢中保持',prompt:'实际逐面折起并转动/翻面检查六个面。依次点展开图的一面，再点合拢图中同一原面，连接全部六对。字母和图案是稳定身份。',explain:'折叠改变位置和朝向，不改变面身份；A到F各面在背面也仍存在。',reason:{prompt:'面到了背后，身份会怎样？',options:['身份保留，转动可找出同一图案的面','背面会被另一个面替换','只配当前正面的三面即可'],answer:0}},
 'G07.03':{kind:'valid',nets:[SOLID_NETS.cross,SOLID_NETS.strip],context:'实际试折并检查重合',prompt:'两张六面纸片都逐面试折到90°。转动/翻面检查折后位置，再判断各图能否成为立方体；非法图要依据面重合或连接冲突。',explain:'十字网六个面到六种朝向；六面直条折后A与E、B与F重合，不能成为立方体。',reason:{prompt:'如何判断非法网？',options:['核对全部折后位置、方向与原连接是否一致，找重合/冲突','只看纸片是否好看','有六个正方形就必然有效'],answer:0}},
 'G07.04':{kind:'opposite',nets:[SOLID_NETS.cross],asked:['A','B'],context:'用折后方向判断相对面',prompt:'实际折起六面，转动并翻面查看隐藏面。先点指定面A，再点与A相对的原面；同样找B的相对面。相对面不共用边。',explain:'此网A与F相对，B与C相对。依据折后反向法向及不同位置判断，不凭平面图上下猜。',reason:{prompt:'相对面的空间关系是什么？',options:['在盒子两侧，方向相反且不共用边','纸片上相邻一定相对','在画面上左右两边就一定相对'],answer:0}},
 'G07.05':{kind:'volume',solids:[{cells:solidBoxCells(2,2,2),title:'2×2×2盒内单位块'}],unit:1,context:'按层实际堆单位立方体',prompt:'每个小立方体边长1厘米。逐层点格堆满2×2×2目标，转动/翻面检查隐藏层，再填写体积并选择量的单位。',explain:'8个单位立方体共8立方厘米；体积计空间块，不计外面的方片。',reason:{prompt:'体积在这次操作中数什么？',options:['不重叠占据空间的单位立方体，每块1立方厘米','只数看见的外面','把边长相加'],answer:0}},
 'G07.06':{kind:'surface',solids:[{cells:solidBoxCells(2,2,2),title:'2×2×2立方体'}],unit:1,context:'实际选外表面的单位方片',prompt:'逐层堆满边长1厘米的单位块，再转动并翻面检查全部方向。选择各块实际露在外面的方片，填表面积与单位；块之间贴合的内部方片不计。',explain:'外表面共24个单位方片，24平方厘米。8块体积是8立方厘米，不是表面积。',reason:{prompt:'相邻小块贴合处的两张方片怎样算？',options:['在内部，两张都不计入外表面积','每张都算外表面','只算其中一张'],answer:0}}
};
for(const [skillId,t] of Object.entries(SOLID_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,contentVersion:51,mode:'solidLab',phase:'练',hint:'逐面折到90°，转动/翻面查看背面；稳定面身份不变。体积数单位块，表面积只选实际外露单位方片。'});
if(typeof module!=='undefined')module.exports={SOLID_TASKS,SOLID_NETS,solidBoxCells};
