'use strict';
const solidSource=typeof module!=='undefined'?require('./solid'):{SOLID_NETS,solidBoxCells},solidNets=solidSource.SOLID_NETS,solidBox=solidSource.solidBoxCells;
const SOLID_CASES={
 'G07.01':[
  [{kind:'counts',nets:[solidNets.row],context:'换有效纸网的对象去重'},'这次换成长条带上下两片的纸网。实际逐面折起，转动和翻面，再点出全部不同面、边、顶点并填个数。','换纸网仍为立方体：6面、12边、8顶点。','十字网改为另一种有效网，检查折后共用对象'],
  [{kind:'counts',nets:[solidNets.stair],context:'独立阶梯纸网'},'独立将阶梯纸网逐面折起，转动翻面后选全不同面、边、顶点，再填个数。','6、12、8，按合拢位置去重。','无提示：阶梯式有效网'],
  [{kind:'counts',nets:[solidNets.cross.map(([x,y])=>[-y,x])],context:'隔日转向纸网'},'隔日把转向的六面网实际折起。查看背面后点全部面边顶点并填个数，不把纸上重复端点当不同顶点。','6面、12边、8顶点。','隔日：纸网转90°，稳定ID保留'],
  [{kind:'counts',nets:[solidNets.row.map(([x,y])=>[-x,y])],context:'备用镜像网'},'独立折起镜像纸网，转动/翻面，点全部实际面边顶点并填写数量。','6、12、8。','备用：左右镜像后的共享对象']
 ],
 'G07.02':[
  [{kind:'match',nets:[solidNets.stair],context:'礼盒标记换到阶梯网'},'六个礼盒面有稳定字母和图案。实际折阶梯网、转动/翻面，再把展开面与盒中同一原面全部逐对连接。','全部六对身份保持，隐藏面也须对应。','纸网结构与面朝向改变'],
  [{kind:'match',nets:[solidNets.row],context:'独立长条网对应'},'独立折长条带两片纸网，查看全部面，再逐对连接展开面与立体中的同一原面。','六面身份保持。','无提示：另一种有效连接'],
  [{kind:'match',nets:[solidNets.cross.map(([x,y])=>[x,-y])],context:'隔日上下镜像'},'隔日折起上下镜像网，查看背面后，把每个展开面连接到立体中的原面。','原图案和字母随折叠保留。','隔日：上下镜像布局'],
  [{kind:'match',nets:[solidNets.stair.map(([x,y])=>[-y,x])],context:'备用斜阶方向'},'独立折转向后的阶梯网，转动/翻面检查每个面，再连六对原面对应。','六对身份保持。','备用：阶梯网转90°']
 ],
 'G07.03':[
  [{kind:'valid',nets:[solidNets.row,solidNets.rectangle],context:'额外连接冲突的反例'},'逐面试折两种六片纸网：一张长条带两片，一张2×3矩形。依据实际重合及原连接冲突判断有效性；矩形多出的连接不能默默剪开。','前图有效；矩形重合并有原连接冲突，非法。','无环重合反例改为含额外连接环的反例'],
  [{kind:'valid',nets:[solidNets.strip,solidNets.stair],context:'独立先非法再有效'},'独立把六面直条与阶梯网都逐面试折，检查背面、重合和连接冲突，再分别判断。','直条非法，阶梯有效。','无提示：图序改变，不能按第一图选有效'],
  [{kind:'valid',nets:[solidNets.rectangle,solidNets.cross.map(([x,y])=>[-y,x])],context:'隔日连接环与转向有效网'},'隔日逐面试折矩形六片网及转向十字网，检查实际位置与原连接，再判断各自能否合拢。','矩形非法；转向十字有效。','隔日：先含环非法网，后转向有效网'],
  [{kind:'valid',nets:[solidNets.row.map(([x,y])=>[-x,y]),solidNets.strip.map(([x,y])=>[y,x])],context:'备用镜像与竖直条'},'独立试折镜像有效网与竖直六面条，检查全部折后位置和背面，分别判断。','镜像网有效；竖直条有重合，非法。','备用：镜像和条方向变化']
 ],
 'G07.04':[
  [{kind:'opposite',nets:[solidNets.row],asked:['A','E'],context:'不同网的指定面'},'实际折起新网，转动/翻面。依次点A和它的相对面，再点E和它的相对面。','此网A与C、E与F相对。','指定面与纸网连接同时改变'],
  [{kind:'opposite',nets:[solidNets.stair],asked:['A','B'],context:'独立阶梯网相对'},'独立折阶梯网，查看隐藏面，分别找A和B的相对原面。','按合拢后反向朝向找相对面。','无提示：阶梯网相对关系'],
  [{kind:'opposite',nets:[solidNets.cross.map(([x,y])=>[-y,x])],asked:['C','D'],context:'隔日转向指定侧面'},'隔日折转向网，转动翻面后分别找C和D的相对原面。','C与B、D与E相对，方向变化不改原面身份。','隔日：指定侧面改变'],
  [{kind:'opposite',nets:[solidNets.row.map(([x,y])=>[-x,y])],asked:['B','F'],context:'备用镜像网相对面'},'独立折镜像网，查看所有面，分别找B和F的相对原面。','按反向法向及不共边判断。','备用：镜像和两个新指定面']
 ],
 'G07.05':[
  [{kind:'volume',solids:[{cells:solidBox(2,2,2),title:'短盒'},{cells:solidBox(4,2,1),title:'扁盒'}],unit:1,compare:'equalVolume',context:'相同块数、不同外形'},'每块1立方厘米。分别逐层堆两个目标，转动翻面检查，填写各体积和单位，再判断体积是否相同。','两形都8块、8立方厘米；外形与表面积可以不同。','单个盒改两个等体积不同形状'],
  [{kind:'volume',solids:[{cells:[[0,0,0],[1,0,0],[0,1,0],[1,1,0],[0,0,1]],title:'带一块上层的台阶'}],unit:1,context:'独立台阶与隐藏块'},'独立逐层堆目标台阶，查看隐藏底层，填体积并选择单位。','5块，5立方厘米。','无提示：长方体改非长方体台阶'],
  [{kind:'volume',solids:[{cells:solidBox(1,1,3),title:'三层立柱'}],unit:1,context:'隔日层数变化'},'隔日逐层堆三层立柱，转动翻面检查每层，再填体积和单位。','3块，3立方厘米。','隔日：更多层、更小每层'],
  [{kind:'volume',solids:[{cells:solidBox(2,2,2),title:'半厘米块组成的盒'}],unit:.5,context:'备用非单位厘米块'},'独立用每边0.5厘米的小块逐层堆2×2×2目标，转动翻面，填写实际体积及单位。','每块0.125立方厘米，8块共1立方厘米。','备用：小块边长变半厘米，块数不直接等体积']
 ],
 'G07.06':[
  [{kind:'surface',solids:[{cells:solidBox(2,2,2),title:'短盒'},{cells:solidBox(4,2,1),title:'扁盒'}],unit:1,compare:'differentArea',context:'等体积不保证等表面积'},'逐层堆两个各有8块的目标，转动翻面并分别选全部实际外露方片，填表面积与单位，再比较。','短盒24平方厘米，扁盒28平方厘米；体积都8，表面积不同。','单个表面积改等体积双形比较'],
  [{kind:'surface',solids:[{cells:solidBox(3,1,1),title:'三块横列'}],unit:1,context:'独立排除贴合内面'},'独立堆三块横列，转动翻面，逐块选择全部外露方片。内部贴合方片不计，填表面积和单位。','18张方片中4张在内部，外露14平方厘米。','无提示：细长形有两个贴合界面'],
  [{kind:'surface',solids:[{cells:[[0,0,0],[1,0,0],[2,0,0],[0,1,0],[1,1,0],[0,0,1]],title:'六块台阶'}],unit:1,context:'隔日台阶凹面'},'隔日逐层堆六块台阶，转动翻面，选各块实际外露方片，包含凹边外露面，再填表面积和单位。','六块有六个贴合界面，外露36−12＝24平方厘米。','隔日：非长方体、凹边和隐藏外面'],
  [{kind:'surface',solids:[{cells:solidBox(2,2,1),title:'半厘米薄层'}],unit:.5,context:'备用方片面积换单位'},'独立用边0.5厘米的小块堆2×2×1薄层，选全部实际外露方片，填写实际表面积及单位。','16张外露方片，每张0.25平方厘米，共4平方厘米。','备用：外露方片数与实际面积分开']
 ]
};
const solidStageTarget=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
for(const [skillId,cases] of Object.entries(SOLID_CASES)){
 if(cases.length!==4)throw Error('Four G07 cases required: '+skillId);solidStageTarget[skillId]={};
 for(const [i,kind] of ['transfer','independent','delayed','independent2'].entries()){
  const [params,prompt,explain,changeDimension]=cases[i];solidStageTarget[skillId][kind]={id:`T-${skillId.replace('.', '-')}-${i+1}`,skillId,contentVersion:52,mode:'solidLab',phase:kind==='transfer'?'迁移':kind==='delayed'?'巩固':'测',...params,contentVersion:params.kind==='valid'?71:52,prompt,explain,changeDimension,...(kind==='transfer'?{hint:'折后按真实位置、方向与连接检查，不按外观猜。逐层数空间块，外表面积只数外露方片；单位尺寸变化要换算。'}:{})};
 }
}
if(typeof module!=='undefined')module.exports={SOLID_CASES};
