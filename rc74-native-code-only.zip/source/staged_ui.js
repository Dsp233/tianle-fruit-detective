'use strict';
function stageAccess(skillId,kind){
 const tasks=STAGED_TASKS[skillId];if(!tasks?.[kind])return {allowed:false,reason:'此技能暂无该实例。'};
 if(kind==='transfer')return {allowed:true};
 const progress=saved.skillStage[skillId]||{};
 if(!progress.transferPassed)return {allowed:false,reason:'先完成另一种情境或表示。'};
 if(kind.startsWith('independent')){
  const number=Number(kind.replace('independent','')||1),prior=number===2?'independent':`independent${number-1}`;
  if(number===1||progress[prior+'Tried']||taskHistory(tasks[prior]).submissions>0)return {allowed:true};
  return {allowed:false,reason:'先提交上一道独立新题，再试备用题。'};
 }
 const qualifying=assessmentStageProgress(progress,tasks,saved.attempts);
 if(!qualifying.independentQualifiedAt)return {allowed:false,reason:`需要${ASSESSMENT_RULES.independentSuccesses}道不同新题的无提示首答正确记录。同题重试不会增加独立证据；可以回到操作练习。`};
 const delay=kind==='delayed7'?7:kind==='delayed21'?21:1;
 const dueAt=qualifying.independentQualifiedAt+delay*REVIEW_DELAY_MS;
 return Date.now()>=dueAt?{allowed:true,dueAt}:{allowed:false,dueAt,reason:'回访新实例尚未到期。'};
}
function stageLinks(skillId){
 if(!STAGED_TASKS[skillId])return '';
 const labels={transfer:'换情境或表示',independent:'独立新题一',independent2:'独立新题二',independent3:'备用新题一',independent4:'备用新题二',delayed:'隔日新实例',delayed7:'7天新实例',delayed21:'21天新实例'};
 const links=Object.entries(labels).filter(([kind])=>STAGED_TASKS[skillId][kind]).map(([kind,label])=>{
  const state=stageAccess(skillId,kind),task=STAGED_TASKS[skillId][kind];
  const tried=saved.attempts.some(a=>a.taskInstanceId===task.id);
  const due=state.dueAt?' '+new Date(state.dueAt).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false})+'（北京时间）':'';
  return `<button class="secondary" data-action="stage" data-code="${esc(skillId)}|${kind}" ${state.allowed?'':'disabled'}>${label}${tried?' · 已试过':''}</button>${state.allowed?'':`<small>${esc(state.reason+due)}</small>`}`;
 }).join('');
 return `<section class="panel stage-links"><h3>同一微技能的后续题</h3><p class="tiny-note">迁移题会改情境、表示、已知/未知位置或条件。无提示题先看关系独立作答；隔日题是不同的任务 ID，本机到期后开放。</p><div class="stage-buttons">${links}</div></section>`;
}
function stagePage(){const task=STAGED_TASKS[stageSkillId]?.[stageKind],access=stageAccess(stageSkillId,stageKind);if(!task||!access.allowed)return `<div class='panel'><h1>暂不能进入这道题</h1><p>${esc(access.reason||'任务不可用')}</p><button class='secondary' data-action='micro' data-code='${esc(stageSkillId)}'>回微技能</button></div>`;
 const heading=stageKind==='transfer'?'换一种方式试一试':stageKind==='delayed'?'隔日新题，自己想办法':'自己看题，独立作答';
 const history=taskHistory(task),assisted=history.modelViewed||history.hintEvents.length>0,attemptLabel=history.submissions?'同实例再练':history.legacyExposure?'旧实例再练':assisted?'已回看方法，本题记练习':'无提示';
 const board=taskBoard(task);
 return `<div class='page-head'><div><p class='kicker'>${esc(stageKind==='transfer'?stageSkillId+' · 迁移练习':'新实例')}</p><h1>${heading}</h1></div><button class='back' data-action='micro' data-code='${esc(stageSkillId)}'>← 微技能</button></div><div class='work'><article class='panel'><span class='phase'>${esc(task.phase)} · ${stageKind==='transfer'?'另一种表示/条件':attemptLabel}</span>${stageKind==='transfer'?`<p class='tiny-note'>本题改变：${esc(task.changeDimension)}。</p>`:''}<h2 class='task-title'>${esc(task.prompt)}</h2><div class='workshop-check-top'><button class='primary' data-action='${feedback?.ok?'next':'check'}'>${feedback?.ok?'完成本题，返回微技能 →':'检查当前操作 ✓'}</button></div>${board}${actionRow(task)}</article><aside class='side-stack'><section class='panel'><h3>本题证据边界</h3><p class='muted'>这是与前一题不同的固定实例。提交会记首答、操作状态和提示使用；同题重做不会生成新的独立首答。系统核对操作或所选对象，不判断口述是否正确。</p>${stageKind==='delayed'?'<p class="tiny-note">本机时间决定是否到期；不发送后台提醒。</p>':''}</section></aside></div>`;
}
