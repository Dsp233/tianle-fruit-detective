'use strict';
function statsData(values,extra={}){return {values,quantum:1,unit:'枚',...extra}}
function statsFreq(rows,extra={}){return {rows:rows.map(([value,frequency,label])=>({value,frequency,label})),quantum:1,unit:'本',...extra}}
const STATS_TASKS={
 'D02.01':{kind:'balance',...statsData([1,5,6]),prompt:'三个原盘分别有1、5、6枚。点一枚再放到另一个盘，实际均分全部材料。填写原总数、盘数及均分后每盘数。',explain:'移来移去总数仍12，均分到3盘，每盘4。'},
 'D02.02':{kind:'mean',...statsData([2,3,7],{unit:'本'}),prompt:'三人各读2、3、7本。用读书单位点在三人之间实际均分，填写总本数、人数和平均本数。',explain:'总12本除以3人，平均4本；平均可以不是任何人的原本数。'},
 'D02.03':{kind:'sort',...statsData([4,1,4,2,6],{unit:'分'}),prompt:'把五张原数据卡按从小到大逐张摆进顺序位。两个4来自不同记录，各须保留一次。',explain:'1、2、4、4、6；排序改变位置，不删重复记录。'},
 'D02.04':{kind:'median',...statsData([8,1,4,3],{unit:'分'}),prompt:'先逐张排序，切换圈中间卡模式，圈出偶数个数据的两张中间原卡，再填写中位数。',explain:'1、3、4、8；中间两值3、4，中位数3.5。'},
 'D02.05':{kind:'modeRange',...statsData([2,2,4,6],{unit:'分'}),prompt:'把每张原数据卡归到对应数值区，圈所有出现最多的数值区，再标最小与最大区并填写极差。若所有值各出现一次，明确选无众数。',explain:'2出现两次最多，众数2；最大6−最小2＝极差4。'},
 'D02.06':{kind:'weighted',...statsFreq([[2,1,'甲组'],[8,3,'乙组']],{quantum:0.5}),prompt:'甲组1人每人2本，乙组3人每人8本。逐行展开频数为真实人员卡，实际均分全部读书单位点，填写总本数、总人数与合班平均。每个半点0.5本。',explain:'2×1＋8×3＝26，总4人；平均6.5本，不能把组均值2与8直接平均成5。'}
};
for(const [skillId,t] of Object.entries(STATS_TASKS))Object.assign(t,{id:`O-${skillId.replace('.', '-')}-1`,skillId,mode:'statsLab',contentVersion:59,phase:'练',context:'原数据、守恒与真实人数',hint:'材料只在原盘间移动；排序保留每个记录。频数要展开为每个实际人，中间位置与出现次数是不同问题。',reason:{prompt:'你的统计结果依靠什么？',options:['保留原数据身份和总量；平均的分母是实际对象数，中位数看排序中间，众数看频数，极差看最大减最小','把重复的数据删掉后再求中间值和平均','人数不同的两组也可直接平均两个组均值'],answer:0}});
if(typeof module!=='undefined')module.exports={STATS_TASKS,statsData,statsFreq};
