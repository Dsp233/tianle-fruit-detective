'use strict';
const SubmissionContract=((P)=>{
 const checks={
  'place-and-choice':'把得到的数放回每个数位，检查顺序、是否允许重复和全部数位条件。',
  'changing-wholes':'每个分数指的是哪一个整体？画出每次变化前后的整体，再代回剩余量。',
  'changing-base':'每次百分数以哪个价格为基准？用你的结果检查前后变化能否回到题给价格。',
  'ratio-and-conservation':'比的两边分别代表谁？同一份的大小是否一致，转移前后总量是否保持？',
  'finite-purchase':'将你的包数代回总支数和总费用。检查整包、恰好或至少买够的条件。',
  'rate-and-boundary':'这个数表示时间、路程还是速度？分别代回两段行程，不把等路程当成等时间。',
  'length-and-area-scale':'当前倍率作用于长度还是面积？同一倍率作用于几条边？检查所求量。',
  'balance-and-constraints':'把候选结果代回每一条总量与差额条件。天平两边的操作是否保持等量？',
  'recurrence':'逐个检查相邻项的规则和项号，不能把第几项当成它的数值。',
  'affine-operations':'按题给顺序把候选数输入机器，再核对输出；两台机器的先后次序相同吗？',
  'factor-constraints':'将候选因数相乘，检查积和因数个数；所有合法分组都检查了吗？',
  'cycle-and-endpoints':'把事件标在时间轴上，核对周期以及开始、结束时刻是否计入。',
  'boundary-and-area':'当前求的是边界长度还是覆盖面积？检查转角、重叠和被移除的部分。',
  'angle-and-circle':'你的角度对应哪个顶点或哪段弧？检查总角与题给比例是否同时成立。',
  'distance-geometry':'先标出所求的两点或线段；检查方向、直角及图给长度，不用图上像素代替条件。',
  'spatial-boundary':'按层或面逐一核对，区分可见块与被遮住的块；同一块不能重复数。',
  'sets-and-multiplicity':'把同一个对象放进对应区域，核对交集被数了几次以及圈外对象。',
  'route-and-sampling':'逐段检查完整路线：分支是否合法、限制点有没有经过、是否漏数或重复？',
  'arrangement-and-equivalence':'检查顺序是否重要、旋转是否算同一种，再核对重复与遗漏。',
  'chart-and-scale':'先核对刻度起点和每格的单位，再把柱高或累计值还原成所求量。',
  'total-and-position':'这个数表示总量、每人量还是位置？先核对参与的人数或项数。',
  'sample-space':'每个基本结果是否等可能？检查满足条件的结果和完整样本空间是否对应。',
  'transformation':'按题给顺序追踪每次变换；中间的方向或位置有没有被跳过？',
  'invariant-and-guarantee':'对一次合法操作检查什么改变、什么保持。你的结论能应对每一种合法选择吗？',
  'structure-and-domain':'用一个较小实例检查你的规则，再核对端点、符号和全部合法情况。',
  'joined-length':'每次连接会减少哪一段长度？核对接口数量及开口、闭环的区别。',
  'interval-endpoints':'逐个检查间隔和标记的对应关系；两端分别是否需要标记？',
  'ratio-perimeter':'比例对应长宽还是一周？标出所求边，核对所有边与周长条件。',
  'unit-conversion':'写出每个数的单位，先换成相同单位，再代回题给数量关系。',
  'constant-age-gap':'比较同一时刻的两人年龄；时间变化会改变年龄差还是倍数？',
  'shared-height-balance':'找出哪些区域共用同一条高或底，再检查面积比与总面积。',
  'three-group-reference':'将人数代回三组总量、差额与倍数关系，核对所求组别。'
 };
 function numeric(input,expected){
  const text=String(input??'').trim();
  if(!text)return {ok:false,status:'awaiting_input',text:'先填写答案。',recordAttempt:false};
  if(!P.arithmetic(text))return {ok:false,status:'invalid_input',text:'这段输入还不能按数值核对。可填写数、分数或算式，草稿已保留。',recordAttempt:false};
  const ok=P.equal(text,expected);return {ok,status:ok?'correct':'needs_revision',recordAttempt:true};
 }
 function feedback(c,input,variation=false){
  const familyId=c.recipe?.familyId||c.problemState?.familyId||c.quality?.familyId||c.family;
  const model=c.quality?.modelId||c.quality?.model||c.modelId,base=checks[model]||'这个数代表哪个量？请检查使用的条件、单位和所求目标。';
  if(!variation&&['natural-weighted','natural-fractionWeighted'].includes(familyId)){
   const m=c.math,den=m.den||1;if(P.equal(input,(m.redScore+m.blueScore)/(2*den)))return '如果你直接平均两个队的每人得分：两队人数相同吗？请在图上分别表示人数，再检查全体平均分。';
  }
  if(!variation&&familyId==='ratioUnion'&&P.equal(input,(c.math.a+c.math.b)*c.math.unit))return '如果这是两组人数的合计：交集里的同一个人被数了几次？用区域图核对参加活动的不同人数。';
  const known=(variation?c.extension?.misconceptions:c.misconceptions)?.find(x=>P.equal(input,x.value));
  return known?.feedback||((variation?'条件已经改变。':'你得到的是 '+String(input)+'。')+base);
 }
 return {numeric,feedback,checks};
})(typeof module!=='undefined'?require('./problem_state'):ProblemState);
if(typeof module!=='undefined')module.exports=SubmissionContract;
