'use strict';
// Shared adapter contract: a real state, legal actions, semantic grading and
// a spoken description of that same state. No separate text-card fallback.
const PRACTICE_BANKS={workshop:WORKSHOP_TASKS,fraction:FRACTION_TASKS,percent:PERCENT_TASKS,integer:INTEGER_TASKS,ratio:RATIO_TASKS,rate:RATE_TASKS,journey:JOURNEY_TASKS,scale:SCALE_TASKS,equation:EQUATION_TASKS,constraint:CONSTRAINT_TASKS,pattern:PATTERN_TASKS,coordinate:COORDINATE_TASKS,grouping:GROUPING_TASKS,factor:FACTOR_TASKS,common:COMMON_TASKS,cycle:CYCLE_TASKS,measure:MEASURE_TASKS,angle:ANGLE_TASKS,composite:COMPOSITE_TASKS,circle:CIRCLE_TASKS,similar:SIMILAR_TASKS,right:RIGHT_TASKS,solid:SOLID_TASKS,sets:SETS_TASKS,combin:COMBIN_TASKS,chart:CHART_TASKS,stats:STATS_TASKS,chance:CHANCE_TASKS,motion:MOTION_TASKS,invariant:INVARIANT_TASKS};
const TASK_ADAPTERS=Object.freeze({
 ...Object.fromEntries(WORKSHOP_MODES.map(mode=>[mode,{board:workshopBoard,state:workshopState,act:workshopAct,grade:workshopGrade,speech:workshopSpeech}])),
 fractionLab:{board:fractionBoard,state:fractionState,act:fractionAct,grade:fractionGrade,speech:fractionSpeech},
 percentLab:{board:percentBoard,state:percentState,act:percentAct,grade:percentGrade,speech:percentSpeech},
 integerLab:{board:integerBoard,state:integerState,act:integerAct,grade:integerGrade,speech:integerSpeech},
 ratioLab:{board:ratioBoard,state:ratioState,act:ratioAct,grade:ratioGrade,speech:ratioSpeech},
 rateLab:{board:rateBoard,state:rateState,act:rateAct,grade:rateGrade,speech:rateSpeech},
 journeyLab:{board:journeyBoard,state:journeyState,act:journeyAct,grade:journeyGrade,speech:journeySpeech},
 scaleLab:{board:scaleBoard,state:scaleState,act:scaleAct,grade:scaleGrade,speech:scaleSpeech},
 equationLab:{board:equationBoard,state:equationState,act:equationAct,grade:equationGrade,speech:equationSpeech},
 constraintLab:{board:constraintBoard,state:constraintState,act:constraintAct,grade:constraintGrade,speech:constraintSpeech},
 patternLab:{board:patternBoard,state:patternState,act:patternAct,grade:patternGrade,speech:patternSpeech},
 coordinateLab:{board:coordinateBoard,state:coordinateState,act:coordinateAct,grade:coordinateGrade,speech:coordinateSpeech},
 groupingLab:{board:groupingBoard,state:groupingState,act:groupingAct,grade:groupingGrade,speech:groupingSpeech},
 factorLab:{board:factorBoard,state:factorState,act:factorAct,grade:factorGrade,speech:factorSpeech},
 commonLab:{board:commonBoard,state:commonState,act:commonAct,grade:commonGrade,speech:commonSpeech},
 cycleLab:{board:cycleBoard,state:cycleState,act:cycleAct,grade:cycleGrade,speech:cycleSpeech},
 measureLab:{board:measureBoard,state:measureState,act:measureAct,grade:measureGrade,speech:measureSpeech},
 angleLab:{board:angleBoard,state:angleState,act:angleAct,grade:angleGrade,speech:angleSpeech},
 compositeLab:{board:compositeBoard,state:compositeState,act:compositeAct,grade:compositeGrade,speech:compositeSpeech},
 circleLab:{board:circleBoard,state:circleState,act:circleAct,grade:circleGrade,speech:circleSpeech},
 similarLab:{board:similarBoard,state:similarState,act:similarAct,grade:similarGrade,speech:similarSpeech},
 rightLab:{board:rightBoard,state:rightState,act:rightAct,grade:rightGrade,speech:rightSpeech},
 solidLab:{board:solidBoard,state:solidState,act:solidAct,grade:solidGrade,speech:solidSpeech},
 setsLab:{board:setsBoard,state:setsState,act:setsAct,grade:setsGrade,speech:setsSpeech},
 combinLab:{board:combinBoard,state:combinState,act:combinAct,grade:combinGrade,speech:combinSpeech},
 chartLab:{board:chartBoard,state:chartState,act:chartAct,grade:chartGrade,speech:chartSpeech},
 statsLab:{board:statsBoard,state:statsState,act:statsAct,grade:statsGrade,speech:statsSpeech},
 chanceLab:{board:chanceBoard,state:chanceState,act:chanceAct,grade:chanceGrade,speech:chanceSpeech},
 motionLab:{board:motionBoard,state:motionState,act:motionAct,grade:motionGrade,speech:motionSpeech},
 invariantLab:{board:invariantBoard,state:invariantState,act:invariantAct,grade:invariantGrade,speech:invariantSpeech}
});
function taskAdapter(task){if(task?.competition)return {board:competitionClues,state:competitionState,act:()=>false,grade:t=>({ok:draft.choice===t.answer,reason:'同时核对所有条件。'}),speech:t=>t.prompt};const base=TASK_ADAPTERS[task?.mode]||null;const adapter=base&&predictionNeeded(task)?predictionAdapter(base):base;return task?.joint&&adapter?jointAdapter(adapter):adapter}
function taskBoard(task){return taskAdapter(task)?.board(task)||objectSortBoard(task)}
function practiceFor(sid){for(const [view,bank] of Object.entries(PRACTICE_BANKS))if(bank[sid])return {view,task:bank[sid]};return null}
function taskSemanticModel(task){
 const omit=new Set(['id','skillId','contentVersion','phase','prompt','hint','explain','reason','worked','changeDimension','authorship','context','title','label','name','taskIds','bookReferences','examReferences','demoSteps','displayOrderPolicy','semanticParameters','generation','demoSteps','demoNarration','firstResponseRuleVersion']);
 const clean=value=>Array.isArray(value)?value.map(clean):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().filter(k=>!omit.has(k)).map(k=>[k,clean(value[k])])):value;
 const model=clean(task);
 if(task.mode==='rateLab'&&task.kind==='convert'){delete model.amountUnit;delete model.unit}
 if(Array.isArray(model.base)&&['period','position'].includes(task.kind)){const symbols=new Map();model.base=model.base.map(v=>{if(!symbols.has(v))symbols.set(v,symbols.size);return symbols.get(v)})}
 if(task.mode==='patternLab'&&task.kind==='period'){const observed=[...model.base,...model.base,...model.base],size=Array.from({length:model.base.length},(_,i)=>i+1).find(n=>observed.every((v,i)=>v===observed[i%n]));model.base=model.base.slice(0,size)}
 return model;
}
function taskFingerprint(task){return JSON.stringify(taskSemanticModel(task))}
function taskContractErrors(task){const errors=[];if(!/^[A-Z0-9-]+$/.test(task.id||''))errors.push('invalid stable ID');if(!Number.isInteger(task.contentVersion)||task.contentVersion<1)errors.push('missing content version');if(!task.skillId)errors.push('missing target');if(!task.prompt)errors.push('missing prompt');if(!taskAdapter(task)&&task.mode!=='objectSort')errors.push('no real adapter');return errors}
