'use strict';
// A shared entry point keeps existing route renderers and task identities.
// Adapters continue to own real actions, state, grading and speech.
function practicePlayerPage(){const task=PRACTICE_BANKS[view]?.[microSkillId],node=NODE_BY_ID.get(microSkillId);if(!task||!node)return '<div class="panel">请选择一个操作任务。</div>';return `<div class="page-head"><div><p class="kicker">${task.skillId} · 练</p><h1>${esc(node.concept)}</h1></div><button class="back" data-action="network" data-code="${task.skillId}">← 相关知识</button></div><div class="work"><article class="panel"><h2 class="task-title">${esc(task.prompt)}</h2><div class="workshop-check-top"><button class="primary" data-action="${feedback?.ok?'next':'check'}">${feedback?.ok?'完成本题，回到相关知识 →':'检查操作与理由 ✓'}</button></div>${taskBoard(task)}${reasonBlock(task)}${actionRow(task)}</article><aside class="side-stack"><section class="panel"><h3>把思路连起来</h3><button class="secondary" data-action="learn" data-code="${task.skillId}">回看概念与条件</button><button class="secondary" data-action="demo" data-code="${task.skillId}">看另一道例子</button><button class="secondary" data-action="network" data-code="${task.skillId}">相关知识与后续新题</button></section></aside></div>`}
const TASK_PLAYERS={
 competition:{page:()=>competitionQuestionPage(),task:()=>topicActive?topicDescriptor(topicCurrent())?.task:null},
 competitionRecords:{page:()=>competitionRecordsPage(),readOnly:true},
 ...Object.fromEntries(Object.keys(PRACTICE_BANKS).map(name=>[name,{page:()=>practicePlayerPage(),task:()=>PRACTICE_BANKS[name][microSkillId]}])),
 joint:{page:()=>jointPage(),task:()=>jointAccess(jointTaskId).allowed?JOINT_TASKS[jointTaskId]:null},
 fruit:{page:()=>fruitPage(),task:()=>FRUIT_TASKS[saved.fruitCursor]},
 course:{page:()=>coursePage(),task:()=>COURSES[courseCode]?.steps[courseRecord(courseCode).cursor]},
 transfer:{page:()=>transferPage(),task:()=>FOCUS_REVIEW[courseCode]?.[reviewRecord(courseCode)?.cursor]},
 sample:{page:()=>samplePage(),task:()=>SAMPLE_TASKS[sampleCode]},
 stage:{page:()=>stagePage(),task:()=>stageAccess(stageSkillId,stageKind).allowed?STAGED_TASKS[stageSkillId]?.[stageKind]:null},
 micro:{page:()=>microPage(),task:()=>MICRO_TASKS[microSkillId]},
 learn:{page:()=>learningPage(),task:()=>LEARNING_TASKS[microSkillId],readOnly:true},
 demo:{page:()=>demoPage(),task:()=>DEMO_TASKS[demoSkillId],readOnly:true},
 network:{page:()=>networkPage(),task:()=>LEARNING_TASKS[networkSkillId],readOnly:true},
 catalog:{page:()=>catalogPageHtml(),readOnly:true},progress:{page:()=>progressPage(),readOnly:true},skillMap:{page:()=>skillMapPage(),readOnly:true},
 knowledge:{page:()=>knowledgeHome(),readOnly:true},topicSummary:{page:()=>topicSummaryPage(),readOnly:true}
};
function playerPage(){if(topicSessionMatches())return competitionQuestionPage();return TASK_PLAYERS[view]?.page()||home()}
function playerTask(){return TASK_PLAYERS[view]?.task?.()||null}
