'use strict';
// Reviewed original generator-3 configurations only. Reasons describe actual
// authored quantities, not title matches or certification of student mastery.
const TeachingSkillContracts=((math,extra,final)=>{
 const use=(skillId,reason)=>({skillId,reason});
 const family=(nodes,methodExtras,variation)=>({revision:1,routeId:'family-quantities',nodes,methodExtras,variation,
  reviewStatus:'DEVELOPER_REVIEW_NATIVE_AND_PEDAGOGICAL_ACCEPTANCE_PENDING'});
 const catalog={
  fractionBackwards:family({
   'second-remainder':[use('A03.02','Identify one third of the current whole'),use('A03.07','Second-day whole is the first-day remainder')],
   'after-first':[use('A02.05','Divide the final two parts to find one part'),use('A02.04','Reconstruct three equal parts'),use('A02.03','Undo removal in reverse order')],
   target:[use('A02.04','Double the first-day remainder to restore the original whole')]
  },[[],[]],[use('A03.02','Both uses now refer to fractions of the original total'),use('A03.04','Express halves and thirds as sixths'),use('A02.01','Remove five of six original parts'),use('A02.05','Find the remaining original sixth')]),
  ratioEqualize:family({
   'difference-parts':[use('R01.02','Red and blue refer to the two ordered ratio objects'),use('A02.01','Subtract red parts from blue parts')],
   'one-part':[use('R01.05','Recover a unit part from the known quantity difference')],
   target:[use('A02.04','Multiply a unit part by the original blue parts')]
  },[[],[use('A03.02','Represent red as a fraction of blue'),use('A03.04','Convert the complementary blue fraction to an equivalent number of equal parts')]],
  [use('R01.02','Only blue is removed; red is unchanged'),use('R01.05','Use the original difference to recover a part'),use('A02.04','Both equal groups now have the original red quantity')]),
  balanceCancel:family({
   'decision-1':[use('L01.03','Remove equal box counts from both sides of a balance')],
   'extra-boxes':[use('A02.01','Count the unmatched box after equal removal')],
   target:[use('A02.03','Undo the remaining added mass to isolate one box')]
  },[[],[use('L01.02','Represent a box by an unknown'),use('L01.05','Substitute the result into both original totals'),use('A02.04','Express repeated boxes as multiples'),use('A02.06','Interpret multiplication before the added mass')]],
  [use('L01.01','Replacement mass must restore equal totals'),use('A02.01','Replace the mass of exactly one removed box')]),
  tickets:family({
   baseline:[use('A02.04','Multiply all people by the child ticket price')],
   difference:[use('A02.01','Subtract the all-child cost from the actual cost')],
   'per-change':[use('A02.01','Subtract child price from adult price')],
   target:[use('A02.05','Divide the extra cost by one ticket replacement'),use('N01.02','The replacement count has no remainder and counts whole people')]
  },[[],[use('L01.02','Represent adult count by an unknown'),use('L01.03','Solve the equality of actual and modeled costs'),use('L01.05','Check the answer against the original total'),use('A02.06','Interpret the parenthesized child count in the cost equation')]],
  [use('C02.03','Visit every bounded adult ticket count including zero'),use('N01.02','Keep only nonnegative remainders divisible by the child price'),use('A02.04','Compute adult cost for each candidate'),use('A02.01','Subtract adult cost from the fixed total'),use('A02.05','Convert remaining cost into whole child tickets')]),
  linearTable:family({
   'input-gap':[use('A02.01','Subtract the two known input values')],
   'output-gap':[use('A02.01','Subtract the corresponding output values')],
   multiplier:[use('L04.01','One fixed machine rule must fit both known pairs'),use('A02.05','Divide output change by input change')],
   addition:[use('A02.03','Undo the multiplication to recover the fixed addition')],
   target:[use('A02.04','Multiply the target input using the recovered rule')]
  },[[],[]],[use('L04.01','Preserve the same two machine constants'),use('A02.06','Reverse the order to add first and then multiply')]),
  bells:family({
   'joint-period':[use('N03.02','Find the least positive common event time')],
   'decision-1':[use('A02.01','Exclude the starting event at zero')],
   target:[use('N01.02','Only complete common periods before the inclusive end count')]
  },[[],[use('C02.03','List every common event within the specified interval')]],
  [use('N03.02','Use one complete joint period as the new interval'),use('A02.01','Count both zero and the positive endpoint')]),
  factorBalance:family({
   pairs:[use('N02.02','Enumerate every positive factor pair once')],
   'sum-*':[use('A02.01','Add the two factors in each reviewed pair')],
   target:[use('A01.04','Compare all legal pair sums to choose the minimum')]
  },[[]],[use('N02.02','Use the same complete factor-pair set'),use('A02.01','Compute the pair sum'),use('A01.04','Reverse the objective and choose the maximum')]),
  outsideAngle:family({
   'other-sum':[use('G02.03','Triangle interior angles total 180 degrees'),use('A02.01','Remove the known apex angle')],
   'base-angle':[use('G02.05','Use the stated isosceles condition, rather than visual size'),use('A02.05','Split the remaining angle equally between the bases')],
   target:[use('G02.02','Adjacent interior and exterior angles make a straight angle'),use('A02.01','Subtract the base angle from 180 degrees')]
  },[[use('A02.06','Read the parenthesized subtraction before division')],[use('A02.06','Read division before addition in the exterior-angle expression')]],
  [use('G02.02','Find the adjacent base angle by supplementing the known exterior'),use('G02.05','The other base angle is equal by the stated condition'),use('A02.01','Subtract the exterior angle from 180 degrees')]),
  circleRoute:family({
   'other-arc':[use('G04.05','The two complementary arcs partition the whole circle'),use('A02.01','Subtract clockwise segment count from the full count')],
   target:[use('A01.04','Choose the smaller of the two arc lengths'),use('A02.05','Find one equal arc length from the circumference'),use('A02.04','Multiply by the chosen segment count')]
  },[[],[]],[use('G04.05','The outbound and return complementary arcs cover every segment'),use('A02.04','Count each equal segment exactly once for the lower bound')]),
  exactlyOneSet:family({
   'only-A':[use('C01.02','Remove the intersection from the complete A group'),use('A02.01','Subtract the shared members from A')],
   'only-B':[use('C01.02','Remove the same intersection from the complete B group'),use('A02.01','Subtract the shared members from B')],
   target:[use('C01.03','Add the two mutually exclusive only-one regions')]
  },[[],[use('C01.05','Deduplicate the union before removing the intersection again')]],
  [use('C01.02','One A-only member moves into the shared region'),use('C01.03','Only-one regions lose exactly that single identity'),use('A02.01','Decrease the only-one total by one')])
 };
 catalog.exactlyOneSet.routeId='disjoint';
 Object.assign(catalog,extra.authored(use));
 Object.assign(catalog,extra.cohortThree(use));
 Object.assign(catalog,extra.cohortFour(use));
 Object.assign(catalog,final.authored(use));
 function key(id){return catalog[id]?id+'@'+catalog[id].revision:undefined}
 function get(c){const id=c.problemState?.familyId||c.recipe?.familyId||c.family;return c.skillContractKey===key(id)?catalog[id]||null:null}
 function exactFraction(value){const pair=math.arithmetic(value);if(!pair)return String(value);let [n,d]=pair;if(d<0n){n=-n;d=-d}let a=n<0n?-n:n,b=d;while(b)[a,b]=[b,a%b];return d/a===1n?String(n/a):String(n/a)+'/'+String(d/a)}
 function valueUses(value){const pair=math.arithmetic(value);return pair&&pair[0]%pair[1]!==0n?[use('A03.02','Represent this noninteger quantity as parts of one unit'),use('A03.04','Use an exact equivalent fraction for this current quantity')]:[]}
 function decimalPlaces(value){const match=String(value).match(/^[+−-]?\d*\.(\d+)$/);return match?match[1].length:0}
 function decimalTokens(text){return String(text).match(/\d*\.\d+/g)||[]}
 function textUses(text){const out=[];
  if(decimalTokens(text).some(x=>decimalPlaces(x)===1))out.push(use('A03.06','Read tenths, as represented by the ten-part A03.06 lessons'));
  if(decimalTokens(text).some(x=>decimalPlaces(x)===2))out.push(use('A04.02','Read hundredths using the fraction-percent-decimal equivalence demonstrated in A04.02 transfer'));
  for(const match of text.matchAll(/\b\d+(?:\.\d+)?\s*\/\s*\d+(?:\.\d+)?\b/g))out.push(...valueUses(match[0]));return out;
 }
 function textKnowledgeGaps(text){return decimalTokens(text).some(x=>decimalPlaces(x)>2)?[{id:'decimal-precision-beyond-hundredths',reason:'The current A03.06 and A04.02 tasks do not establish place value beyond hundredths',message:'这里需要更高位的小数表示，当前学习范围还未覆盖。'}]:[]}
 function annotate(c,r){
  const contract=get(c);if(!contract)return null;
  const nodes=contract.revision===1?(r.id===contract.routeId?contract.nodes:null):contract.routes[r.id]?.nodes;
  if(!nodes)throw Error('Unreviewed route in skill contract '+c.family+'/'+r.id);
  const uses=[];
  for(const n of r.nodes){const entries=nodes[n.id]||Object.entries(nodes).find(([key])=>key.endsWith('*')&&n.id.startsWith(key.slice(0,-1)))?.[1];
   if(!entries?.length)throw Error('Unreviewed node in skill contract '+c.family+'/'+n.id);
   n.skillUses=[...entries,...(contract.revision===2?[...valueUses(n.answer),...textUses([n.prompt,...n.hints].join(' '))]:[])].map(x=>({...x}));uses.push(...n.skillUses);
  }
  const presented=[c.prompt,...c.options,...r.nodes.flatMap(n=>[n.prompt,...n.hints])].join(' ');
  if(contract.revision===2)uses.push(...textUses([c.prompt,...c.options].join(' ')));
  return {id:r.id,directSkills:[...new Set(uses.map(x=>x.skillId))],skillUses:uses.map(x=>({...x})),unverifiedKnowledge:[...(contract.routes?.[r.id]?.unverifiedKnowledge||[]),...textKnowledgeGaps(presented)].map(x=>({...x})),contractRevision:contract.revision,contractStatus:contract.reviewStatus};
 }
 return {catalog,key,get,annotate,valueUses,textUses,textKnowledgeGaps,decimalPlaces,exactFraction};
})(typeof module!=='undefined'?require('./problem_state'):ProblemState,typeof module!=='undefined'?require('./teaching_skill_contracts_extra'):TeachingSkillContractsExtra,typeof module!=='undefined'?require('./teaching_skill_contracts_final'):TeachingSkillContractsFinal);
if(typeof module!=='undefined')module.exports=TeachingSkillContracts;
