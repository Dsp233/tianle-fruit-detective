'use strict';
// Second review cohort: route-specific strategies and independent variations.
const TeachingSkillContractsExtra=(()=>{
 function authored(use){
  const u=use,route=(nodes)=>({nodes}),method=(routeId,extras=[],more={})=>({routeId,extras,...more}),variation=(id,uses,solution)=>({id,uses,solution});
  const family=(routes,methods,variations)=>({revision:2,routes,methods,variations,reviewStatus:'DEVELOPER_REVIEW_NATIVE_AND_PEDAGOGICAL_ACCEPTANCE_PENDING'});
  const average=[u('D02.02','Convert an average and its actual group size into a total'),u('A02.04','Multiply the average by the group size')];
  const rectangle=[u('G01.02','The perimeter contains two copies of length plus width'),u('A02.05','Halve the perimeter to obtain the side sum')];
  const area=[u('G01.03','Count the rectangle area by rows of unit squares'),u('A02.04','Multiply the two side lengths')];
  const probability=[u('D03.04','Divide favorable equally likely identities by the specified sample size')];
  const shared=[u('C01.02','Distinguish a whole group, its only region and its shared region')];
  const recurrence=[u('L03.04','Use the explicit predecessor recurrence at each grid point'),u('L04.03','Read horizontal and vertical positions in the stated order')];
  const movement=[u('R03.02','Relate a distance to its speed and elapsed time')];
  const percent=[u('A04.05','Each percentage change uses its explicitly stated current base'),u('A04.03','Compute the percentage part of that base')];
  const subtractAverage=()=>({
   'all-total':average,'back-total':average,nonoverlap:[u('A02.01','Remove the entire back segment from the entire collection')],
   'front-total':average,target:[u('A02.01','Remove the nonoverlapping front portion to leave the shared position')]
  });
  const disjoint=(complement)=>({
   'only-red':[...shared,u('A02.01','Subtract shared people from the red group')],
   'only-blue':[...shared,u('A02.01','Subtract shared people from the blue group')],
   'region-total':[u('C01.03','Add the mutually exclusive only-red, only-blue and shared identities')],
   ...(complement?{neither:[u('C04.02','Remove the union from the specified whole population')]}:{}),target:probability
  });
  const sumSets=(complement)=>({attendance:[u('A02.01','Add the two membership counts')],
   union:[u('C01.05','Correct the one duplicated appearance of each shared identity')],
   ...(complement?{outside:[u('C04.02','Take the complement within the specified whole population')]}:{}),target:probability});
  const conditionalByRegions=[...shared,u('C01.03','Use three disjoint regions as the new at-least-one-group population'),...probability];
  const setVariant=variation('conditional-regions',conditionalByRegions,c=>{const m=c.math,total=m.red+m.blue-m.both;return `条件已缩到至少参加一组：只红${m.red-m.both}、只蓝${m.blue-m.both}、两组${m.both}，共${total}人。两组人数除以这个新整体，概率为${c.extension.answer}。`});
  return {
   fixedPerimeter:family({
    pairs:route({'half-perimeter':rectangle,'pair-*':[...area,u('C02.03','Visit each positive integer short side once, with the matching long side')],target:[u('A01.04','Compare every legal area to find the maximum')]}),
    'move-one':route({'half-perimeter':rectangle,'nearest-gap':[u('N01.05','An integer side sum permits a zero gap when even and a one-unit gap when odd'),u('S02.04','Moving one unit between sides preserves their sum while increasing area until the gap is minimal')],
     'short-side':[u('A02.05','Split the side sum into the closest legal integer sides'),u('N01.02','Preserve the possible one-unit remainder')],target:area})
   },[method('pairs'),method('move-one')],[
    variation('bounded-enumeration',[...rectangle,...area,u('C02.03','List every short side from the new minimum to half the side sum'),u('A01.04','Choose the minimum of the new legal areas')],c=>{const m=c.extension.problemState.math,values=[];for(let a=m.minSide;2*a<=m.halfPerimeter;a++)values.push(`${a}×${m.halfPerimeter-a}=${a*(m.halfPerimeter-a)}`);return `长宽和${m.halfPerimeter}，每边至少${m.minSide}。列全合法配对：${values.join('；')}。最小面积为${c.extension.answer}。`}),
    variation('bounded-side-move',[...rectangle,...area,u('S02.04','Moving sides toward each other increases area at fixed side sum'),u('A01.04','Reverse the objective and use the most unequal permitted sides')])
   ]),
   overlapAverages:family({
    'sum-overlap':route({'target-position':[u('A01.01','Identify the single common position of the two stated segments')],'front-total':average,'back-total':average,'all-total':average,
     multiplicity:[u('C01.05','The common position contributes twice in the two segment totals')],target:[u('A02.01','Subtract the whole total to leave one copy of the shared number')]}),
    'remove-nonoverlap':route(subtractAverage())
   },[method('sum-overlap'),method('remove-nonoverlap')],[
    variation('new-segment-removal',[...average,u('A02.01','Use two removals to isolate the new common position')],c=>{const m=c.extension.problemState.math,num=s=>String(s).split('/').map(Number).reduce((a,b)=>a/b),front=num(m.frontMean)*m.segmentSize,back=num(m.backMean)*m.segmentSize,all=num(m.allMean)*m.n;return `重叠位置改为第${m.middlePosition}个。全部总和${all}减后段${back}，得到前段不重叠总和${all-back}；前段总和${front}再减它，所求数为${c.extension.answer}。`}),
    variation('new-segment-deduplication',[...average,u('C01.05','The new segment totals duplicate exactly their shared position'),u('A02.01','Subtract the whole total from the segment sum')])
   ]),
   'natural-unionChance':family({'family-quantities':route(sumSets(false)),'disjoint-regions':route(disjoint(false))},[method('family-quantities'),method('disjoint-regions')],[setVariant]),
   'natural-complementChance':family({'family-quantities':route(sumSets(true)),'disjoint-regions':route(disjoint(true))},[method('family-quantities'),method('disjoint-regions')],[setVariant]),
   stepwiseRoute:family({
    'family-quantities':route({'decision-1':[u('D03.06','Different complete routes need not be equally likely under local choices'),u('L04.03','Read the named grid points')],
     'route-count':[u('C02.05','Pair the counted prefix and suffix routes through the specified point')],
     'decision-2':[u('D03.01','At a single legal exit that direction is certain')],
     target:[u('D03.06','Multiply local choice probabilities and combine mutually exclusive complete routes')]}),
    'probability-flow':route({'sampling-rule':[u('D03.06','The random object is a legal local exit, not an equiprobable complete route')],
     'boundary-rule':[u('D03.01','A unique legal exit has probability one')],
     'arrival-*':[...recurrence,u('D03.06','Send all or half of the incoming probability according to legal exits'),u('A03.04','Combine incoming fractions for mutually exclusive last steps')],
     target:[u('D03.06','The probability reaching P is the requested event probability')]})
   },[method('probability-flow',[],{useRouteFrames:true})],[variation('complete-route-pairing',[u('C02.05','Pair all counted routes before and after P'),...probability])]),
   routeProbability:family({
    'family-quantities':route({'decision-1':[u('D03.03','All complete routes are equally likely by the stated sampling rule')],
     'all-routes':[u('C02.03','Account for every legal complete route')],
     'allowed-routes':[u('C02.05','Pair prefixes and suffixes through P before removing those complete routes'),u('C04.02','Remove routes through P from the whole route population')],target:probability}),
    'direct-route-count':route({'sampling-rule':[u('D03.03','The probability denominator counts equally likely complete routes')],
     'all-routes':[...recurrence,u('C02.03','The unrestricted predecessor table counts all complete routes')],
     'ways-*':[...recurrence,u('A02.01','Add disjoint arrival counts; assign zero to the forbidden point')],target:probability})
   },[method('family-quantities'),method('direct-route-count')],[variation('first-up',[u('C02.03','Count completions after fixing the first step up'),...probability])]),
   'natural-catch':family({'lead-gap':route({lead:[...movement,u('A02.04','Multiply the early time by the slow speed')],
    'gap-speed':[u('R02.03','Compare speeds expressed in the same distance and time units'),u('A02.01','Subtract slow speed from fast speed')],target:[...movement,u('A02.05','Divide the lead by the per-minute gap reduction')]})},
   [method('lead-gap'),method('lead-gap',[u('L01.02','Represent the pursuit time as an unknown'),u('L01.03','Apply equal operations to the two distance expressions'),u('A02.06','Read the parenthesized total slow time in the equation')])],
   [variation('one-person-stops',[...movement,u('A02.04','After meeting, only the still-moving person adds distance')])]),
   riverTravel:family({'family-quantities':route({'down-speed':[u('A02.01','Add the same-direction boat and water speeds')],
    'up-speed':[u('A02.01','Subtract the opposite water speed')],'down-time':movement,'up-time':movement,
    target:[u('R03.03','Accumulate the times of the two separate travel segments'),u('A02.01','Add the two actual travel times')]})},[method('family-quantities')],
   [variation('still-water',[...movement,u('A02.04','Both legs use the same still-water speed')])]),
   percentRoundTrip:family({'family-quantities':route({raised:percent,'decision-1':[u('A04.05','The second percentage base is the raised price')],
    'final-price':percent,target:[u('A02.01','Compare the final price with the original price')]})},[method('family-quantities'),method('family-quantities')],
   [variation('restore-raised-price',[...percent,u('A04.01','The removed increase is a part of the raised-price whole'),u('A02.05','Compute that part relative to the raised price')])]),
   percentRestore:family({'family-quantities':route({'new-base':[...percent,u('A02.01','Use original price 100 and add the percentage increase')],
    difference:[u('A02.01','Find the difference from the unchanged original price')],target:[...percent,u('A04.01','Express the required decrease as a percentage of the raised whole')]})},[method('family-quantities')],
   [variation('restore-lowered-price',[...percent,u('A04.01','The restoring increase uses the lowered whole as its denominator')])]),
   equalDistanceSpeed:family({'family-quantities':route({'decision-1':[u('R02.01','An average speed divides the full distance by the full elapsed time')],
    'out-time':movement,'back-time':movement,target:[u('R03.03','Accumulate both actual distances and times'),u('A02.05','Divide total distance by total time')]})},
   [method('family-quantities'),method('family-quantities',[u('R01.02','Same distance gives the stated two-to-one time ratio'),u('D02.02','Weight the two speeds by their actual time shares'),u('A02.06','Evaluate the weighted numerator before division')])],
   [variation('equal-time-speed',[u('R03.02','The same elapsed time makes distance proportional to speed'),u('D02.02','Equal time weights permit the arithmetic mean of speeds')])]),
   fractionDifferentWholes:family({'family-quantities':route({'first-part':[u('A03.02','One fourth refers to the first box as its whole'),u('A02.05','Divide only the first box into four equal parts')],
    'second-part':[u('A03.02','One third refers to the second box as a different whole'),u('A02.05','Divide only the second box into three equal parts')],
    target:[u('A02.01','Add the two quantities after applying their separate wholes')]})},[method('family-quantities')],
   [variation('both-remainders',[u('A03.02','Preserve the two separate fractional wholes'),u('A02.05','Determine each used unit fraction'),u('A02.01','Subtract the used amounts from their separate whole quantities')])])
  };
 }
 function cohortThree(use){
  const u=use,route=nodes=>({nodes}),method=(routeId,extras=[])=>({routeId,extras}),variation=(id,uses,solution)=>({id,uses,solution});
  const family=(nodes,methods,variations,alternatives={})=>({revision:2,routes:{'family-quantities':route(nodes),...alternatives},methods,variations,reviewStatus:'DEVELOPER_REVIEW_NATIVE_AND_PEDAGOGICAL_ACCEPTANCE_PENDING'});
  const add=[u('A02.01','Add or remove the stated quantities')],multiply=[u('A02.04','Count equal groups by multiplication')],divide=[u('A02.05','Divide the whole into the specified equal groups')];
  const average=[u('D02.02','Average is the actual total divided by the actual group size')];
  const ratio=[u('R01.02','Keep the two named ratio quantities in their stated order')],parts=[u('R01.03','Relate the sum of ratio parts to the combined whole')];
  const enumUses=[u('C02.03','Visit every bounded whole-package candidate, including zero')],costUses=[...multiply,...add];
  const minimum=[u('A01.04','Compare all legal costs to choose the minimum')];
  const chart=[u('D01.03','Use the equally spaced chart scale'),u('D01.04','Read the actual column heights')];
  const cube=[u('G07.01','Distinguish cube faces, edges and vertices')],chance=[u('D03.04','Divide favorable equally likely individual cubes by the stated population')];
  const weightedNodes={'people-parts':[...ratio,...parts,...add],'red-total':[...ratio,...multiply],'blue-total':[...ratio,...multiply],target:[...average,...add,...divide]};
  const weightedAlt={'score-gap':add,'extra-total':[...ratio,...multiply],'people-parts':[...parts,...add],'extra-average':[...average,...divide],target:add};
  const weightedVariation=variation('swapped-population-weights',[...ratio,...parts,...average,...multiply,...add,...divide]);
  const joinNodes={joins:[u('A01.01','Match each connection to an adjacent pair, including the final pair only in a closed loop'),...add],'overlap-total':multiply,target:[u('C01.05','Subtract each duplicated connection length exactly once'),...multiply,...add]};
  const joinForward=[u('A01.01','Match connections to the changed open or closed arrangement'),u('C01.05','Remove the duplicated overlap length exactly once'),...multiply,...add];
  const postsNodes={intervals:divide,'decision-1':[u('S02.01','Apply the stated rule to both endpoints')],target:[u('A01.01','Match intervals to marks using the stated endpoint inclusion'),...add]};
  const postsVariation=[...divide,u('A01.01','Match intervals and marks after changing both endpoint rules'),u('S02.01','Check both endpoint conditions'),...add];
  const rectangle=[u('G01.02','A rectangle boundary has two lengths and two widths')];
  const fractionWhole=[u('A03.02','Identify a unit fraction relative to its stated whole')];
  const remainingWhole=[...fractionWhole,u('A03.07','Track the new whole for the next fraction operation')];
  return {
   squareBorder:family({'outer-side':add,'all-cells':[u('G01.03','Cover the enlarged square by rows of unit cells'),...multiply],'old-cells':[u('G01.03','Count the original square cells'),...multiply],target:add},
    [method('family-quantities'),method('boundary-strips')],[variation('left-and-top',[u('C01.03','Count the two disjoint added strips and the single outer corner'),...multiply,...add])],
    {'boundary-strips':route({'outer-side':add,'top-bottom':[u('A01.01','Count the added top and bottom cell rows'),...multiply],'left-right':[u('A01.01','Count side cells without recounting corner cells'),...multiply],target:[u('C01.03','Add four mutually exclusive strips')]})}),
   packPrice:family({'decision-1':[u('S02.01','Preserve the exact requested quantity and whole-package restriction')],'cost-*':[...enumUses,...costUses],target:minimum},[method('family-quantities')],[variation('allow-surplus',[...enumUses,...costUses,...minimum,u('S02.01','Check the new at-least quantity boundary')])]),
   mixedPacks:family({'decision-1':[u('S02.01','Use exact quantity with two indivisible package types')],'cost-*':[...enumUses,u('N01.02','Keep only package pairs that fill the exact quantity'),...costUses],target:minimum},[method('family-quantities')],[variation('allow-surplus',[...enumUses,...costUses,...minimum,u('S02.01','Check every bounded pair that buys at least the requested quantity')])]),
   paintedCube:family({'decision-1':cube,'one-edge':[...cube,...add],'all-edges':cube,'two-painted':multiply,target:[u('A01.01','Count individual qualifying small cubes')]},
    [method('family-quantities'),method('face-deduplication')],[variation('opposite-painted-faces',[u('G07.04','The top and bottom are opposite faces with disjoint layers'),u('G01.03','Count every cell of both full face layers'),...multiply])],
    {'face-deduplication':route({'one-face':[...cube,...multiply,...add],'six-faces':multiply,multiplicity:[u('C01.05','An edge cube appears in exactly two face counts')],target:[u('C01.05','Remove the double count of the same cubes'),...divide]})}),
   cubeProbability:family({'decision-1':cube,'one-edge':[...cube,...add],'all-edges':cube,'two-painted':multiply,target:[...chance,u('G07.05','The complete cube population has three independent layer dimensions'),...multiply]},
    [method('family-quantities'),method('face-deduplication')],[variation('condition-on-painted',[...cube,u('G07.05','Count all cubes and the internal unpainted cube'),u('C04.02','Use the painted outer layer as the new sample population'),...chance,...multiply,...add])],
    {'face-deduplication':route({'one-face':[...cube,...multiply,...add],'six-faces':multiply,multiplicity:[u('C01.05','Every noncorner edge cube is counted in two faces')],'two-painted':[u('C01.05','Deduplicate individual edge cubes'),...divide],'all-cubes':[u('G07.05','Count the full three-dimensional cube population'),...multiply],target:chance})}),
   chartScale:family({unit:[...chart,...divide],'B-count':[...chart,...multiply],target:[...chart,...multiply,...add]},[method('family-quantities'),method('proportional-heights')],
    [variation('three-extra-grid-steps',[...chart,...divide,...multiply])],{'proportional-heights':route({'combined-height':[...chart,...add],'height-ratio':[...ratio,...divide],target:[...multiply]})}),
   missingAverage:family({'whole-total':[...average,...multiply],'remaining-total':[...average,...multiply],target:add},[method('family-quantities'),method('deviation-balance')],
    [variation('omitted-value-twice',[...average,...multiply,...add,...divide])],{'deviation-balance':route({'mean-gap':add,'remaining-deviation':[...average,...multiply],target:[u('D02.01','The omitted value balances the sum of deviations from the original mean'),...add]})}),
   foldHoles:family({'inside-copies':[u('S01.05','Trace an interior hole through both folds')],'edge-copies':[u('S01.05','A hole on one fold has only two distinct unfolded positions')],'center-copies':[u('S01.05','The intersection of both folds has one unfolded position')],target:[u('C01.03','Combine the disjoint position categories'),...multiply,...add]},
    [method('family-quantities'),method('family-quantities',[u('S01.02','Trace the two successive mirror operations')])],[variation('edge-hole-moves-inward',[u('S01.05','Changing position changes that hole from two to four copies'),...multiply,...add])]),
   'natural-weighted':family(weightedNodes,[method('family-quantities'),method('baseline-difference')],[weightedVariation],{'baseline-difference':route(weightedAlt)}),
   'natural-fractionWeighted':family(weightedNodes,[method('family-quantities'),method('baseline-difference')],[weightedVariation],{'baseline-difference':route(weightedAlt)}),
   'natural-tiles':family({'largest-side':[u('N03.04','The largest uncut square side is the greatest common divisor of both lengths')],'along-width':divide,'along-height':divide,target:[u('G01.03','Cover the rectangle by complete square tiles'),...multiply]},[method('family-quantities')],[
    variation('retile-doubled-dimensions',[u('N03.04','Recompute the greatest common divisor of the two doubled dimensions'),u('G01.03','Count rows and columns of the new whole tiles'),...multiply,...divide],c=>`新地面为${2*c.math.w}×${2*c.math.h}，最大整数砖边长为${2*c.math.side}。两边分别铺${c.math.w/c.math.side}与${c.math.h/c.math.side}块，合计${c.extension.answer}块。`),
    variation('length-and-area-scaling',[u('N03.04','Doubling both integer lengths doubles their greatest common divisor'),u('R04.03','Ground area and tile area both become four times their original areas'),...divide])]),
   'natural-angleRatio':family({parts:[...parts,...add],'one-angle-part':[u('G02.03','The three triangle interior angles sum to 180 degrees'),...divide],target:[...ratio,...multiply,u('A01.04','Select the largest ratio part')]},[method('family-quantities')],
    [variation('quadrilateral-angle-parts',[...parts,...ratio,u('G02.04','Split a quadrilateral into two triangles to obtain 360 degrees'),u('A01.04','Select the smallest angle part'),...add,...divide,...multiply])]),
   digitInsert:family({positions:[u('C02.03','List all three insertions while preserving the two original digits in order')],target:[u('A01.02','Use decimal place values of the inserted digits'),u('A01.04','Compare all legal three-digit numbers')]},[method('family-quantities')],[variation('minimum-insertion',[u('C02.03','Keep the same complete set of legal insertions'),u('A01.02','Respect positional values'),u('A01.04','Reverse the objective to minimum')])]),
   numberAppend:family({coefficient:[u('A01.02','Appending a digit shifts each original place one position to the left')],'net-factor':[...add],target:[u('A02.03','Undo the appended digit and the ninefold change'),...divide]},[method('family-quantities')],[variation('prefix-digit',[u('A01.02','Prefixing a digit adds exactly that many hundreds'),...multiply])]),
   pairedSum:family({'pair-total':add,target:[u('S02.04','Reversing the sequence preserves its total, so two copies can be paired'),...multiply,...divide]},[method('family-quantities')],[variation('only-even-terms',[u('N01.05','Retain exactly the even terms'),u('S02.04','Pair the retained arithmetic sequence'),...add,...multiply,...divide])]),
   telescopingDifferences:family({'decision-1':[u('A02.03','Each interior quantity is added and removed once')],first:[u('A01.01','Identify the first endpoint')],last:[u('A01.01','Identify the last endpoint')],target:add},[method('family-quantities'),method('equal-differences')],
    [variation('omit-first-difference',[u('A02.03','Interior additions and removals still cancel after removing the first bracket'),...add])],{'equal-differences':route({gap:[u('L03.02','Every displayed consecutive difference is the same'),...add],terms:[u('L03.02','Count all equal gaps between the actual endpoints'),...divide],target:multiply})}),
   neighborProducts:family({square:multiply,neighbors:multiply,target:add},[method('family-quantities',[u('A02.06','Read the grouped product decomposition in its stated order')]),method('family-quantities')],[variation('offset-two',[...multiply,...add])]),
   ratioTotal:family({parts:[...parts,...add],'one-part':[u('R01.05','Recover a unit share from the combined total'),...divide],target:[...ratio,...multiply]},[method('family-quantities')],[variation('equalize-by-addition',[...ratio,u('R01.05','Use the same original unit share'),...multiply,...add])]),
   linkedRatios:family({green:[...ratio],blue:[...ratio,u('R01.05','Recover the same blue quantity from the blue-to-green ratio'),...multiply,...divide],red:[...ratio,u('R01.05','Use that blue quantity in the red-to-blue ratio'),...multiply,...divide],target:add},
    [method('family-quantities',[u('R01.04','Rescale both ratios to the same blue share')]),method('family-quantities')],[variation('red-catches-blue',[...ratio,u('R01.05','Recover the same named quantities before equalizing'),...multiply,...divide,...add])]),
   unitConversion:family({millilitres:[u('R02.03','Write both capacity amounts in the same stated unit'),...multiply],target:[u('R02.03','Only divide capacity amounts after unifying their units'),...divide,u('N01.02','Count full cups without a fractional cup')]},[method('family-quantities')],[variation('double-cup-volume',[u('R02.03','Preserve equal capacity units'),...multiply,...divide,u('N01.02','Count only complete doubled cups')])]),
   mapScale:family({'same-length-factor':[u('R04.02','Corresponding map lengths change by the same linear factor')],target:[u('R04.02','Apply the given factor to this same route'),...multiply]},[method('family-quantities')],[variation('halve-current-map',[u('R04.02','Keep the corresponding route under scaling'),...fractionWhole,...multiply,...divide])]),
   'rule-join-open':family(joinNodes,[method('family-quantities')],[variation('closed-loop',joinForward)]),
   'rule-join-closed':family(joinNodes,[method('family-quantities')],[variation('open-chain',joinForward)]),
   'rule-join-piece':family({...joinNodes,target:[u('C01.05','Restore the duplicated connection lengths'),u('A02.03','Undo the connection subtraction'),...add,...divide]},[method('family-quantities')],[variation('closed-loop',joinForward)]),
   'rule-posts-both':family(postsNodes,[method('family-quantities')],[variation('exclude-both-endpoints',postsVariation)]),
   'rule-posts-neither':family(postsNodes,[method('family-quantities')],[variation('include-both-endpoints',postsVariation)]),
   'rule-weighted-mean':family({'count-parts':[...ratio,...parts,...add],'A-score':[...ratio,...multiply],'B-score':[...ratio,...multiply],target:[...average,...add,...divide]},[method('family-quantities')],[variation('recover-A-score',[...ratio,...average,...multiply,...add,...divide])]),
   'rule-weighted-score':family({'total-score':[...ratio,...average,...multiply],'B-score':[...ratio,...multiply],'A-total':add,target:[...ratio,...divide]},[method('family-quantities')],[variation('find-combined-average',[...ratio,...parts,...average,...multiply,...add,...divide])]),
   'rule-ratio-length':family({half:[...rectangle,...divide],parts:[...parts,...add],one:[u('R01.05','Recover one length part from the known side sum'),...divide],target:[...ratio,...multiply]},[method('family-quantities')],[variation('find-perimeter-from-width',[...rectangle,...ratio,u('R01.05','Use the specified width to recover a unit part'),...add,...multiply,...divide])]),
   'rule-ratio-perimeter':family({one:[u('R01.05','Recover a unit length part from the known width'),...divide],length:[...ratio,...multiply],target:[...rectangle,...multiply,...add]},[method('family-quantities')],[variation('find-length-from-perimeter',[...rectangle,...ratio,...parts,u('R01.05','Recover a unit part from half the perimeter'),...add,...multiply,...divide])]),
   'rule-fraction-reverse':family({'decision-1':remainingWhole,'after-first':[...remainingWhole,u('A03.04','Use the exact retained fraction'),...multiply,...divide],target:[...fractionWhole,u('A03.04','Restore the original retained fraction'),...multiply,...divide]},[method('family-quantities')],[variation('second-whole-is-first-use',[...remainingWhole,...multiply,...divide,...add])]),
   'rule-fraction-original':family({'decision-1':[...fractionWhole],'first-use':[...fractionWhole,...divide],'second-use':[...fractionWhole,...divide],target:add},[method('family-quantities')],[variation('reverse-two-remainders',[...remainingWhole,u('A03.04','Undo the two exact retained fractions'),...multiply,...divide])]),
   'rule-packs-exact':family({'decision-1':[u('S02.01','Packages remain indivisible and requested quantity is exact')],'cost-*':[...enumUses,...costUses],target:minimum},[method('family-quantities')],[variation('allow-surplus',[...enumUses,...costUses,...minimum,u('S02.01','Include the first whole-package purchase that exceeds the requested quantity')])])
  };
 }
 function cohortFour(use){
  const u=use,route=nodes=>({nodes}),method=(routeId='family-quantities',extras=[],more={})=>({routeId,extras,...more}),variation=(id,uses,solution)=>({id,uses,solution});
  const family=(nodes,methods,variations,alternatives={},routeId='family-quantities')=>({revision:2,routes:{[routeId]:route(nodes),...alternatives},methods,variations,reviewStatus:'DEVELOPER_REVIEW_NATIVE_AND_PEDAGOGICAL_ACCEPTANCE_PENDING'});
  const add=[u('A02.01','Add or remove the stated quantities')],mul=[u('A02.04','Count equal groups by multiplication')],div=[u('A02.05','Divide into the stated equal groups')],inverse=[u('A02.03','Undo the stated addition or removal')];
  const order=[u('A02.06','Respect the stated sequence and grouping of operations')],position=[u('A01.02','Use the decimal place value of each digit')],digits=[u('A01.03','Keep tens and units as ordered positions')];
  const remainder=[u('N01.02','Check the remainder after actual integer division')],enumerate=[u('C02.03','Visit every bounded legal integer candidate')],compare=[u('A01.04','Compare all legal results against the stated objective')];
  const area=[u('G01.03','Cover the rectangle by unit square rows'),...mul],boundary=[u('G01.02','Trace the actual exterior boundary'),...add];
  const angle=[u('G02.02','Use a complete turn of 360 degrees or a straight angle of 180 degrees')];
  const pythagoras=[u('G06.03','Recover the requested side from the stated right triangle')],similar=[u('G05.02','The stated corresponding figures have equal length ratios')];
  const percent=[u('A04.03','Compute the specified percentage of its base'),u('A04.05','Keep the percentage base at the specified operation stage')];
  const digitNodes={'decision-1':[u('C03.01','Exchanging tens and units can produce a different number'),...digits],'first-*':[u('C02.01','Partition legal numbers by their tens digit'),u('N01.03','Divisibility by three follows the sum of the two digits'),...enumerate],target:[u('C01.03','Add mutually exclusive tens-digit groups')]};
  const digitGrouped={'group-0':remainder,'group-1':remainder,'group-2':remainder,'pairs-00':[u('C02.05','Pair two zero-remainder digits, respecting repetition and ordered positions'),...mul,...add],'pairs-12':[u('C02.05','The tens remainder one pairs with units remainder two'),...mul],'pairs-21':[u('C02.05','The reverse ordered remainder pair is a separate branch'),...mul],target:[u('C01.03','Combine the three disjoint ordered remainder branches'),u('C03.01','Keep the two digit positions ordered'),u('N01.03','The taught divisibility-by-three rule makes exactly these digit-remainder pairs legal'),...digits]};
  const digitVariation=[...digits,u('C03.01','The two digit positions remain ordered'),u('N01.03','Test divisibility by three for each ordered digit pair'),...enumerate];
  const unknownRule=(id,reason)=>({unverifiedKnowledge:[{id,reason}]});
  return {
   reverseDigits:family({'digit-gap':[...position,...div],'smaller-digit':[...add,...div],'larger-digit':[...add,...div],target:[...digits,...mul,...add]},[method('family-quantities',order),method('digit-pairs')],
    [variation('smaller-swapped-number',[...position,...digits,...add,...mul,...div])],{'digit-pairs':route({'candidate-count':[...digits,...enumerate,...add],target:[...position,...digits,...compare]})}),
   divisibleDigits:family({'decision-1':[u('N01.03','The taught divisibility-by-five rule restricts the last digit to zero or five')],'candidate-count':[...enumerate,...remainder,...digits],target:[...compare,...position]},
    [method('family-quantities',[],unknownRule('digit-sum-divisibility-nine','The current N01.03 lesson teaches two, three and five; its declared coverage does not establish the digit-sum rule for nine')),method()],
    [variation('divisible-nine-and-even',[u('N01.03','Use the taught even last-digit condition'),...enumerate,...remainder,...position,...compare])]),
   lastDigit:family({'cycle-size':[u('N04.05','Establish the last-digit multiplication cycle'),...mul,...remainder],position:[u('N04.03','Align an exponent counted from one with its cycle position'),u('N04.06','A zero remainder uses the final cycle position')],target:[u('N04.05','Read the last digit at the computed cycle position')]},[method()],
    [variation('sum-neighboring-powers',[u('N04.05','Locate the last digits of the two adjacent powers'),u('N04.03','Preserve exponent positions'),...add,...remainder])]),
   'natural-digitCount':family(digitNodes,[method(),method('remainder-groups')],[variation('forbid-repetition',digitVariation)],{'remainder-groups':route(digitGrouped)}),
   'natural-distinctDigitCount':family(digitNodes,[method(),method('remainder-groups')],[variation('allow-repetition',digitVariation)],{'remainder-groups':route(digitGrouped)}),
   squareBounds:family({'lower-square':[u('A05.04','Compare positive integer square values'),u('A05.05','The positive square root lies above this integer'),...compare],'upper-square':[u('A05.04','Check the next integer square'),...add],target:[u('A05.05','Locate the root between the two consecutive integers')]},[method()],
    [variation('right-integer-bound',[u('A05.05','The nonsquare input makes the upper integer strictly above the root'),u('A05.04','Verify the neighboring squares'),...add,...compare])]),
   ageDifference:family({gap:[u('S02.04','Equal elapsed time preserves the age difference'),...add],'past-child':[u('R01.05','A three-to-one age relation makes the fixed difference two child-age parts'),...div],target:[...add]},[method()],
    [variation('future-two-to-one',[u('S02.04','The age difference remains unchanged'),u('R01.05','At a two-to-one ratio the child age equals that difference'),...add])]),
   repeatedMachine:family({'undo-final-add':[u('L02.01','Reverse the final operation of the two-stage machine'),...inverse],'undo-second':[u('L02.01','Undo the second multiplication'),...div],target:[u('L02.01','Continue the reverse sequence through the first machine use'),...inverse,...div]},
    [method(),method('family-quantities',[u('L01.02','Represent the original input as one unknown'),u('L01.03','Apply equal inverse operations to the full two-use equation'),...mul,...order])],[variation('add-then-multiply',[...order,...add,...mul])]),
   twoCoins:family({baseline:[u('A01.01','Match one unit of value to each actual coin')],excess:add,target:[u('A01.01','Every replacement by a two-unit coin contributes exactly one extra unit')]},[method()],[variation('one-of-each-removed',[...add])]),
   stampConstraint:family({'decision-1':[u('S02.01','Enforce the positive-count requirement for both stamp types')],'possible-three':[...add,...div,...remainder],target:[...enumerate,...mul,...add,...remainder]},[method()],
    [variation('allow-zero-of-one-type',[...enumerate,...remainder,...mul,...add])]),
   machineMeeting:family({'rate-gap':[u('L04.01','Compare the change from a unit input increase'),...add],'constant-gap':[u('L04.01','Compare the outputs at input zero'),...add],target:[...div]},
    [method(),method('family-quantities',[u('L01.02','Represent the common input by an unknown'),u('L01.03','Remove equal quantities from both modeled outputs')])],[variation('raise-only-A-output',[u('L04.01','The output gap increases by one while its change per input stays fixed'),...add,...div])]),
   machineOrder:family({AB:[u('L04.01','Apply machine A and then machine B'),...order,...mul,...add],BA:[u('L04.01','Apply machine B and then machine A'),...order,...mul,...add],target:add},
    [method(),method('input-cancellation')],[variation('double-original-input',[u('L04.01','Both orderings keep the same multiplication of the changed input'),...order,...mul,...add])],
    {'input-cancellation':route({'AB-extra':[...order,...mul,...add],'BA-extra':[...order,...mul,...add],target:[u('A02.03','Remove the identical input-dependent quantity from both outputs'),...add]})}),
   digitDivisor:family({'decision-1':[u('N01.01','Division into zero-sized groups is undefined')],'divisible-*':[...digits,...enumerate,...remainder],target:[u('C01.03','Each distinct units digit contributes one disjoint candidate'),...add]},
    [method(),method('tens-divisors')],[variation('zero-cannot-be-a-divisor',[u('N01.01','No finite group count can make positive quantity from zero-sized groups')])],
    {'tens-divisors':route({'tens-part':[...position,...mul],'divisor-count':[u('N02.02','List every one-digit positive divisor of the tens part once')],target:[...digits,u('A01.01','Each retained divisor corresponds to exactly one legal units digit')]})}),
   divisibleEleven:family({'decision-1':[u('N01.03','The taught divisibility-by-five rule allows only zero or five in the units position')],'candidate-count':[...enumerate,...remainder,...position],target:compare},
    [method('family-quantities',[],unknownRule('alternating-sum-divisibility-eleven','The current declared divisibility lesson does not teach the alternating-place test for eleven')),method()],
    [variation('count-legal-four-digit-numbers',[...enumerate,...position,...remainder,u('N01.03','Restrict only the units digit with the taught five rule')])]),
   threeDivisors:family({'decision-1':[u('N02.06','Three positive divisors require exactly one unpaired middle divisor'),u('N02.05','An unpaired divisor occurs at the square root'),u('N02.03','The square root must be prime to avoid extra factor pairs')],'prime-limit':[u('A05.05','Bound candidate prime bases by the positive square root'),...compare],target:[u('N02.03','Check each candidate base against the definition of prime'),u('N02.06','Count only prime squares'),...enumerate]},[method()],
    [variation('largest-prime-square',[u('N02.03','Keep only squares of prime bases'),u('N02.06','Preserve the exact three-divisor condition'),u('A05.04','Form the prime squares'),...compare,...enumerate])]),
   divisorPowers:family({'two-exponents':[u('N02.06','The exponent of two can range from zero through the original exponent'),...add],'three-exponents':[u('N02.06','The exponent of three has its own independent bounded range'),...add],target:[u('C02.05','Each exponent pair yields one unique divisor'),u('A05.06','Read the prime power representation'),...mul]},[method('family-quantities',order)],
    [variation('square-divisors',[u('N02.05','A square divisor has even prime exponents'),u('N02.06','Count the retained exponent choices'),u('N01.05','Identify the even exponent values including zero'),u('C02.05','Pair independent exponent choices'),...mul])]),
   equalBags:family({'decision-1':[u('N03.03','The bag count must divide both actual color quantities')],'common-divisor':[u('N03.04','Choose the greatest common divisor for the maximum identical bag count')],target:[u('N03.04','Use the greatest divisor as the actual number of bags')]},[method()],
    [variation('all-possible-bag-counts',[u('N03.03','Retain every common divisor'),u('N02.02','List the positive divisors of the greatest common divisor once')])]),
   offsetBells:family({'decision-1':[u('N03.05','Distinguish a joint period from the first joint event with different origins')],offset:[u('L03.02','Preserve the actual starting time of the second timeline')],target:[u('N03.01','Find the first common actual event in the two offset arithmetic timelines'),...enumerate]},[method()],
    [variation('next-joint-event',[u('N03.02','Consecutive joint events are separated by the least common positive period'),...add])]),
   cyclicPosition:family({remainder:[u('N04.01','Remove complete seat cycles by remainder'),u('N04.03','A movement count starts from the actual initial seat')],target:[u('N04.03','Advance from that seat and wrap the displayed one-based labels')]},[method()],
    [variation('reverse-direction',[u('N04.03','Keep the same starting label and reverse the remaining movement'),...remainder,...add])]),
   repeatedOnes:family({'remainder-*':[u('L03.04','Appending one applies the explicit ten-times-plus-one recurrence'),...position,...mul,...add,...remainder],target:[u('N04.03','Use the established six-position remainder cycle'),u('N04.06','A full cycle ending at remainder zero uses the last position')]},
    [method(),method('family-quantities',[u('N01.02','Removing a whole divisible six-digit block preserves the remainder'),u('A05.06','Place-value multiplication by a power of ten preserves divisibility')])],[variation('append-one-more',[u('L03.04','Continue the same ten-times-plus-one remainder recurrence'),...mul,...add,...remainder])]),
   rectangleDiagonalArea:family({'rectangle-area':area,target:[u('G03.01','The diagonal splits the rectangle into two disjoint equal right triangles'),...div]},[method()],
    [variation('increase-only-length-by-half',[...area,u('A03.02','An added half refers to the original length'),...add,...div])]),
   boundaryNotch:family({'old-boundary':[...boundary,...mul],removed:[...boundary],bottom:[...boundary],extra:[u('G03.04','The middle notch replaces a boundary segment by an equal bottom and two new depth edges'),...mul],target:[...boundary,...add]},
    [method('replacement'),method('full-contour')],[variation('internal-hole-boundaries',[...boundary,...mul,...add])],{'full-contour':route({horizontal:[...boundary,...mul],vertical:[...boundary,...mul,...add],target:add})},'replacement'),
   angleMarks:family({'one-angle':[...angle,...div],target:[...mul]},[method()],[variation('other-direction',[...angle,...add])]),
   polygonTurn:family({'decision-1':[u('G02.02','Track the change of direction rather than an interior-angle sum')],'turn-total':angle,target:div},[method(),method('interior-supplement',order)],
    [variation('partial-vertex-traversal',[...angle,...div,...mul,u('N01.05','Read the stated odd/even vertex-count condition before choosing the specified traversal count')])],{'interior-supplement':route({triangles:[u('G02.04','Split the polygon into n minus two triangles'),...add],'interior-total':[u('G02.04','Add the triangle angle totals'),...mul],'one-interior':[...div],target:[...angle,...add]})}),
   lShapeArea:family({'outer-area':area,'missing-area':area,target:[u('G03.02','Remove the corner rectangle from the whole rectangle'),...add]},[method(),method('disjoint-rectangles')],
    [variation('same-hole-area',[...area,u('G03.02','Only the removed area matters for this area target'),...add])],{'disjoint-rectangles':route({'bottom-area':area,'upper-left-area':area,target:[u('G03.01','Add two nonoverlapping rectangles')]})}),
   crossArea:family({vertical:area,horizontal:area,intersection:area,target:[u('C01.05','Remove the second copy of the overlapping strip intersection'),...add]},[method(),method('uncovered-corners')],
    [variation('intersection-only',area)],{'uncovered-corners':route({'unused-width':add,'unused-height':add,'uncovered-area':[u('G03.03','Rearrange the four uncovered corners into one rectangle'),...area],'whole-area':area,target:[u('G03.02','Remove the uncovered area from the whole rectangle'),...add]})}),
   semicircleBoundary:family({'half-arc':[u('G04.05','Use half of the given whole circumference'),...div],diameter:[u('G04.02','The diameter contains two radii'),...mul],target:[u('G01.02','Both the arc and cut diameter are part of the actual boundary'),...add]},[method()],
    [variation('rejoin-whole-circle',[u('G04.03','Rejoining along the diameters leaves the original full circle boundary')])]),
   circleRingRatio:family({'inner-squared':[u('G04.04','Circle area contains the radius squared'),...mul],'outer-squared':[u('G04.04','Use the outer radius for the whole area'),...mul],target:[u('G03.02','Subtract the inner circle area'),u('A04.01','Divide ring area by the specified outer-circle whole'),...add,...div]},[method()],
    [variation('double-both-radii',[u('G04.04','Both circle areas contain the squared radius'),u('R04.03','Both areas change by the same squared length factor'),u('A04.01','A common area multiplier leaves the part-to-whole ratio unchanged')])]),
   shadowSimilarity:family({'small-ratio':[...similar,u('R01.02','Keep pole height and shadow length in their corresponding order'),...div],target:[...similar,u('R01.04','Use the same height-to-shadow ratio under the same light direction'),...mul]},[method('shadow-factor')],
    [variation('new-light-angle',[...similar,u('R01.04','All shadows at the new shared light angle change by the same factor'),...div])],
    {'shadow-factor':route({'shadow-factor':[...similar,u('R01.02','Express shadow length as an integer number of pole-height parts'),...div],'big-shadow':[u('A01.01','Read the given actual shadow length of the large pole')],target:[...similar,u('R01.04','Use the same shadow-to-height multiplier under the stated light angle'),...div]})}),
   parallelTriangle:family({'small-area-ratio':[...similar,u('G05.04','The area ratio is the square of the corresponding side ratio'),...mul],'small-area':[u('G05.04','Apply that area fraction to the original triangle'),...mul],target:[u('G03.02','Subtract the top triangle to leave the lower trapezoid'),...add]},[method()],
    [variation('half-corresponding-side',[...similar,u('G05.04','Halving both corresponding lengths quarters the small triangle area'),u('A03.02','The rest is measured as part of the same original triangle'),...add])]),
   coordinateHorizontal:family({'decision-1':[u('G06.04','Equal y coordinates place both points on the same horizontal line')],target:[u('G06.04','The horizontal distance is the absolute coordinate difference'),u('A05.03','When necessary count the coordinate interval across zero')]},[method()],[
    variation('new-coordinate-difference',[u('G06.04','Compute the distance from the two updated horizontal coordinates'),...add],c=>`新的两点为(${c.math.a+5},${c.math.y})和(${c.math.b+5},${c.math.y})。纵坐标仍相同，两横坐标相差${c.extension.answer}，所以距离为${c.extension.answer}。`),
    variation('translate-both-x-coordinates',[u('S01.04','Translating both endpoints by the same horizontal amount preserves their difference'),u('G06.04','The segment remains horizontal')])]),
   cubeSteps:family({'first-last':[u('L03.02','Column heights form the stated consecutive arithmetic sequence'),...add],target:[u('S02.04','Pair two opposite copies without changing the original total'),...mul,...div]},[method()],
    [variation('two-block-thickness',[u('A02.04','Each original block gains one matching block, so the actual block count doubles')])]),
   openBox:family({'largest-cut':[u('N01.02','Restrict cut size to positive integers with positive remaining base length'),...div],'decision-1':[u('G07.03','Both cut corners on the same side reduce the base by twice the cut size')],'base-*':[u('G07.03','Read the remaining base from the valid unfolding'),...mul,...add],'volume-*':[u('G07.05','Multiply the square base area by the cut-size height'),...mul],target:[...enumerate,...compare]},[method()],
    [variation('fixed-cut-base-area',[u('G07.03','Use the base dimensions after the specified corner cuts'),...area,...add])]),
   'natural-coordinateDistance':family({'x-gap':[u('L04.03','Read horizontal coordinates separately from vertical coordinates'),...add],'y-gap':[u('L04.03','Read the vertical coordinate difference'),...add],'decision-1':[u('G06.01','A horizontal and a vertical displacement form a right triangle')],target:[...pythagoras,u('G06.05','Use the diagonal distance rather than the grid detour')]},
    [method(),method('family-quantities',[u('G05.02','Identify the corresponding scaled three-four-five right triangle'),u('R01.04','Apply the same scale to the hypotenuse')])],
    [variation('grid-only-distance',[u('L04.03','Separate horizontal and vertical displacement'),u('G06.04','Measure the two axis-aligned lengths'),...add])]),
   oppositeScale:family({'length-ratio':[u('R01.04','Read the stated new-to-original length factor')],'decision-1':[u('R04.03','The two length factors multiply to the unchanged area factor')],target:[u('R04.03','Use the reciprocal width factor'),...mul,...div]},[method(),method('representative-area')],[
    variation('direct-area-comparison',[...area,u('R01.04','Scale both stated side lengths by the given factor'),u('A04.01','Compare the new area with the original area'),...div,...order],c=>`取原长${c.math.a}、原宽${c.math.old}。新长${c.math.b}，新宽为${c.math.old}×${c.math.b}÷${c.math.a}。新旧面积之比为${c.math.b}×(${c.math.old}×${c.math.b}÷${c.math.a})÷(${c.math.a}×${c.math.old})=${c.extension.answer}，各步保留精确值。`),
    variation('square-length-factor',[u('R04.03','Area uses the product of the two equal length factors'),...mul])],{'representative-area':route({'original-area':area,'new-length':[u('R01.04','The representative original length a becomes b under the stated factor')],target:[...area,...div]})}),
   similarAreaPerimeter:family({'area-ratio':[...similar,u('G05.04','Read the area ratio of the corresponding similar figures')],'length-ratio':[u('G05.04','Recover the length ratio from the squared area ratio'),u('A05.05','Use the positive roots of the two area-ratio parts')],target:[u('G05.03','Perimeter scales by the corresponding length ratio'),...mul]},
    [method('integer-length-parts')],[variation('new-perimeter-to-area',[u('G05.03','A perimeter multiplier gives the corresponding length multiplier'),u('G05.04','Square that multiplier for the area'),...mul])],
    {'integer-length-parts':route({'small-length-part':[u('G05.04','Each area-ratio part is the square of a length-ratio part'),u('A05.05','Take the positive root of the smaller area part')],'large-length-part':[u('G05.04','Use the corresponding larger area part'),u('A05.05','Take its positive root')],'perimeter-one-part':[u('G05.03','Divide the known perimeter by its length-ratio parts'),...div],target:[u('G05.03','Multiply that common perimeter part by the larger length-ratio part'),...mul]})}),
   scaleAreaReverse:family({'net-length':[u('R04.05','The second length change uses the already changed length'),...mul,...div],'net-area':[u('R04.03','Square the net corresponding-length factor'),...mul],target:[u('R04.03','Undo the net area factor'),...div]},
    [method(),method('reverse-area-stages')],[variation('first-scaling-only',[u('R04.03','Only the first length multiplier contributes to the changed area'),...mul])],
    {'reverse-area-stages':route({'before-second':[u('R04.03','Undo the last length contraction using its squared area factor'),...mul],target:[u('R04.03','Undo the first length expansion using its squared area factor'),...div]})}),
   jointWork:family({'rate-total':[u('R03.05','Add the simultaneously active work rates'),...add],'work-total':[u('R02.02','Read the required box count as the actual work quantity')],target:[u('R03.05','Divide total work by the combined work rate'),...div]},[method()],
    [variation('one-worker-only',[u('R02.02','Use only the remaining active worker rate'),...div])]),
   'natural-offers':family({'shop-A':[...percent,u('R02.02','Multiply the specified item price by the actual count'),...mul,...add],'shop-B':[u('R02.02','Use the other per-item price without a fixed delivery fee'),...mul,...add],target:[u('R02.03','Compare whole-order money costs in the same unit'),...add]},
    [method('family-quantities',order),method('per-item-gap')],[variation('integer-order-threshold',[...percent,u('R02.02','Separate the per-item price gap from the fixed order fee'),u('N01.02','The smallest whole item count must reach the cost threshold'),...mul,...add,...div])],
    {'per-item-gap':route({'A-unit':[...percent,u('R02.02','Discount the per-item price while preserving its money-per-item unit')],'unit-gap':[u('R02.03','Subtract the two actual per-item prices'),...add],'before-fee-gap':[...mul],target:[u('R02.03','Apply the one fixed order fee after accumulating the item-price gap'),...add]})}),
   discountOrder:family({'decision-1':[...percent],'discounted':[...percent,...mul],target:add},[method()],[variation('coupon-before-percent',[...percent,...add,...mul])]),
   fractionSharedRemainder:family({'after-second':[u('A03.07','Undo the last fraction using the current whole'),u('A03.04','The retained current fraction is five eighths'),...mul,...div],'before-return':[...inverse],target:[u('A03.07','The restored remainder is two thirds of the original whole'),u('A03.04','Use the exact original retained fraction'),...mul,...div]},[method()],
    [variation('both-fractions-use-original',[u('A03.02','Both used fractions now refer to the same original whole'),u('A03.04','Combine the original thirds and eighths using equivalent fractions'),...mul,...div,...add])])
  };
 }
 return {authored,cohortThree,cohortFour};
})();
if(typeof module!=='undefined')module.exports=TeachingSkillContractsExtra;
