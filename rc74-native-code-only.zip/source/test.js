'use strict';
const assert=require('assert');
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const {readCsv}=require('./csv');
const dir=__dirname;
const release=require('./version.json');
const {parts,checkExpression}=require('./engine');
const {FRUIT_TASKS,PEOPLE}=require('./fruit');
const {FOUNDATION_COURSES}=require('./foundation');
const {EXTENSION_COURSES}=require('./extension');
const {REMAINING_COURSES}=require('./remaining');
const {FOCUS_CODES,FOCUS_REVIEW}=require('./focus');
const {BREADTH}=require('./breadth');
const {REASONS,SEQUENCES,TRANSFERS,EXPLORATIONS}=require('./enrichment');
const {MICRO_TASKS,MICRO_CASES}=require('./micro');
const {WORKSHOP_TASKS}=require('./workshop');
const {solveFoundation}=require('./test_foundation_solver');
const {solvePercent}=require('./test_solutions');
const {STAGED_TASKS}=require('./staged');
const {FOUNDATION_DEMOS}=require('./foundation_staged');
const {FRACTION_TASKS}=require('./fraction');
require('./fraction_staged');
const {PERCENT_TASKS}=require('./percent');
require('./percent_staged');
const {INTEGER_TASKS}=require('./integer');
require('./integer_staged');
const {RATIO_TASKS}=require('./ratio');
require('./ratio_staged');
const {RATE_TASKS}=require('./rate');
require('./rate_staged');
const {JOURNEY_TASKS}=require('./journey');
require('./journey_staged');
const {SCALE_TASKS}=require('./scale');
require('./scale_staged');
const {EQUATION_TASKS}=require('./equation');
require('./equation_staged');
const {CONSTRAINT_TASKS}=require('./constraint');
require('./constraint_staged');
const {PATTERN_TASKS}=require('./pattern');
require('./pattern_staged');
const {COORDINATE_TASKS}=require('./coordinate');
require('./coordinate_staged');
const {GROUPING_TASKS}=require('./grouping');
require('./grouping_staged');
const {FACTOR_TASKS}=require('./factor');
require('./factor_staged');
const {COMMON_TASKS}=require('./common');
require('./common_staged');
const {CYCLE_TASKS}=require('./cycle');
require('./cycle_staged');
const {MEASURE_TASKS}=require('./measure');
require('./measure_staged');
const {ANGLE_TASKS}=require('./angle');
const {angleTrianglePoints,anglePolygonPoints}=require('./angle_ui');
require('./angle_staged');
const {COMPOSITE_TASKS}=require('./composite');
require('./composite_staged');
const {CIRCLE_TASKS}=require('./circle');
require('./circle_staged');
const {SIMILAR_TASKS}=require('./similar');
const {RIGHT_TASKS}=require('./right');
const {SOLID_TASKS}=require('./solid');
const {SETS_TASKS}=require('./sets');
require('./sets_staged');
const {INVARIANT_TASKS}=require('./invariant');
require('./invariant_staged');
const {MOTION_TASKS}=require('./motion');
require('./motion_staged');
const {CHANCE_TASKS}=require('./chance');
require('./chance_staged');
const {STATS_TASKS}=require('./stats');
require('./stats_staged');
const {CHART_TASKS}=require('./chart');
require('./chart_staged');
const {COMBIN_TASKS}=require('./combin');
require('./combin_staged');
require('./solid_staged');
require('./right_staged');
require('./similar_staged');
require('./transfer_enrichment');
const COURSES={...FOUNDATION_COURSES,...EXTENSION_COURSES,...REMAINING_COURSES};
const {SAMPLE_TASKS}=require('./samples');
const catalog=require('./catalog.json');
const skills=require('./skills.json');
const reviewRows=readCsv(fs.readFileSync(path.join(dir,'..','docs','exam-review-ledger.csv'),'utf8')).rows;
const skillRows=readCsv(fs.readFileSync(path.join(dir,'..','docs','unit-skill-matrix.csv'),'utf8')).rows;
const sourceRows=readCsv(fs.readFileSync(path.join(dir,'..','docs','source-map.csv'),'utf8')).rows;
const verifiedExamIds=reviewRows.filter(r=>r.reviewStatus==='已核原题、独立求解、答案一致').map(r=>r.examId);
assert.equal(new Set(verifiedExamIds).size,verifiedExamIds.length,'each reviewed position counts once');
assert(!verifiedExamIds.includes('AMC8-2012-01'),'unresolved source discrepancy cannot be marked reviewed');
const answerAudit=fs.readFileSync(path.join(dir,'..','docs','answer-pdf-audit.csv'),'utf8');
assert.equal(answerAudit.split(/\r?\n/).filter(line=>line.startsWith('AMC8-')).length,500,'all reference answer positions have attachment evidence');
assert(answerAudit.includes('AMC8-2023-10,C,C,'),'corrected answer agrees with the uploaded 2023 booklet');
const template=fs.readFileSync(path.join(dir,'index.template.html'),'utf8');
assert(template.includes('class="version-badge" aria-label="网页版本 {{VERSION_LABEL}}">{{VERSION_LABEL}}</span>'),'version information uses the single version source');
const {DEMO_TASKS}=require('./pool_tasks');
const code=['engine.js','samples.js','fruit.js','foundation.js','extension.js','remaining.js','focus.js','breadth.js','enrichment.js','micro.js','workshop.js','workshop_ui.js','staged.js','foundation_staged.js','staged_ui.js','fraction.js','fraction_staged.js','fraction_ui.js','percent.js','percent_staged.js','percent_ui.js','integer.js','integer_staged.js','integer_ui.js','ratio.js','ratio_staged.js','ratio_ui.js','rate.js','rate_staged.js','rate_ui.js','journey.js','journey_staged.js','journey_ui.js','scale.js','scale_staged.js','scale_ui.js','equation.js','equation_staged.js','equation_ui.js','constraint.js','constraint_staged.js','constraint_ui.js','pattern.js','pattern_staged.js','pattern_ui.js','coordinate.js','coordinate_staged.js','coordinate_ui.js','divisibility.js','divisibility_ui.js','grouping.js','grouping_staged.js','grouping_ui.js','factor.js','factor_staged.js','factor_ui.js','common.js','common_staged.js','common_ui.js','cycle.js','cycle_staged.js','cycle_ui.js','measure.js','measure_staged.js','measure_ui.js','angle.js','angle_staged.js','angle_ui.js','composite.js','composite_staged.js','composite_ui.js','circle.js','circle_staged.js','circle_ui.js','similar.js','similar_staged.js','similar_ui.js','right.js','right_staged.js','right_ui.js','solid.js','solid_staged.js','solid_geometry.js','solid_ui.js','sets.js','sets_staged.js','sets_ui.js','invariant.js','invariant_staged.js','invariant_ui.js','motion.js','motion_staged.js','motion_ui.js','chance.js','chance_staged.js','chance_ui.js','stats.js','stats_staged.js','stats_ui.js','chart.js','chart_staged.js','chart_ui.js','combin.js','combin_staged.js','combin_ui.js','assessment.js','transfer_enrichment.js','pool_tasks.js','prediction.js','task_contract.js','demo_ui.js','curriculum_ui.js','knowledge_ui.js','joint_logic.js','joint_numbers.js','joint_rates.js','joint_raffle.js','joint_ui.js','competition.js','competition_catalog.js','competition_expansion.js','competition_fresh.js','competition_relations.js','competition_rule_models.js','competition_rules.js','competition_reviewed.js','competition_identity.js','competition_adaptive.js','competition_ui.js','task_player.js','topic_session.js','app.js'].map(f=>fs.readFileSync(path.join(dir,f),'utf8')).join('\n');
assert.equal(catalog.topics.length,33);
assert.equal(skills.units.length,33);
assert.equal(skills.skills.length,179);
assert.equal(new Set(skills.skills.map(s=>s.id)).size,skills.skills.length);
const partiallyLinked=skills.skills.filter(s=>s.taskIds.length);
assert.equal(partiallyLinked.length,179,'every planned skill has a narrow object task link');
assert(skills.skills.every(s=>/未验收|进行中|待验/.test(s.coverageStatus)),'no planned skill is declared mastered');
assert.equal(catalog.entries.length,500);
assert.equal(new Set(catalog.entries.map(e=>e.year+'-'+e.no)).size,500);
assert.equal(Object.keys(SAMPLE_TASKS).length,33);
assert.equal(FRUIT_TASKS.length,26);
assert.equal(Object.keys(FOUNDATION_COURSES).length,6);
assert.equal(Object.keys(EXTENSION_COURSES).length,6);
assert.equal(Object.keys(REMAINING_COURSES).length,20);
assert.equal(Object.keys(COURSES).length,32);
assert.equal(FRUIT_TASKS.length+Object.values(COURSES).reduce((n,c)=>n+c.steps.length,0),282);
const allTaskModes=new Map([...FRUIT_TASKS,...Object.values(COURSES).flatMap(c=>c.steps),...Object.values(MICRO_TASKS),...Object.values(DEMO_TASKS),...Object.values(WORKSHOP_TASKS),...Object.values(FRACTION_TASKS),...Object.values(PERCENT_TASKS),...Object.values(INTEGER_TASKS),...Object.values(RATIO_TASKS),...Object.values(RATE_TASKS),...Object.values(JOURNEY_TASKS),...Object.values(SCALE_TASKS),...Object.values(EQUATION_TASKS),...Object.values(CONSTRAINT_TASKS),...Object.values(PATTERN_TASKS),...Object.values(COORDINATE_TASKS),...Object.values(GROUPING_TASKS),...Object.values(FACTOR_TASKS),...Object.values(COMMON_TASKS),...Object.values(CYCLE_TASKS),...Object.values(MEASURE_TASKS),...Object.values(ANGLE_TASKS),...Object.values(COMPOSITE_TASKS),...Object.values(CIRCLE_TASKS),...Object.values(SIMILAR_TASKS),...Object.values(RIGHT_TASKS),...Object.values(SOLID_TASKS),...Object.values(SETS_TASKS),...Object.values(INVARIANT_TASKS),...Object.values(MOTION_TASKS),...Object.values(CHANCE_TASKS),...Object.values(STATS_TASKS),...Object.values(CHART_TASKS),...Object.values(COMBIN_TASKS),...Object.values(STAGED_TASKS).flatMap(Object.values)].map(t=>[t.id,t.mode]));
for(const skill of partiallyLinked)for(const taskId of skill.taskIds)assert(allTaskModes.has(taskId),skill.id+' points to a real task');
assert.equal(skillRows.filter(r=>r['操作任务ID']).length,179,'all 179 partial operation links are present; not full acceptance');
for(const row of skillRows)for(const taskId of row['操作任务ID'].split(';').filter(Boolean))assert(!['number','choice','multi','objectSort'].includes(allTaskModes.get(taskId)),row['微技能ID']+' must not credit classification or simple answer as full operation');
assert.equal(Object.keys(MICRO_TASKS).length,179);
assert.equal(Object.keys(WORKSHOP_TASKS).length,11);
assert.equal(skillRows.length,179);assert.equal(sourceRows.length,179);
for(const skill of skills.skills){const t=MICRO_TASKS[skill.id];assert(t&&t.id===`M-${skill.id.replace('.', '-')}-1`);assert(skill.taskIds.includes(t.id));assert.equal(t.contentVersion,6);assert(t.prompt&&t.explain&&t.hint);assert(t.objects.length>=4&&new Set(t.objects).size===t.objects.length);assert(t.answer.length>0&&t.answer.length<t.objects.length&&new Set(t.answer).size===t.answer.length&&t.answer.every(i=>Number.isInteger(i)&&i>=0&&i<t.objects.length));}
for(const [rows,field] of [[skillRows,'对象辨识任务ID'],[sourceRows,'网页任务ID']])for(const row of rows){const t=MICRO_TASKS[row['微技能ID']];assert(t&&row[field].split(';').includes(t.id),t?.id+' absent from '+field);assert(row['状态'].includes('进行中'),'matrix must not claim mastery');if(field==='对象辨识任务ID')assert(!row['操作任务ID'].split(';').includes(t.id),'sorting alone is not credited as full mathematical manipulation');}
for(const [sid,t] of Object.entries(WORKSHOP_TASKS)){assert.equal(t.contentVersion,68);assert(skills.skills.find(s=>s.id===sid)?.taskIds.includes(t.id),sid+' workshop linked');assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].split(';').includes(t.id));}
assert.equal(Object.keys(STAGED_TASKS).length,179);
assert.equal(Object.keys(FRACTION_TASKS).length,7);
assert.equal(Object.keys(PERCENT_TASKS).length,6);
assert.equal(Object.keys(INTEGER_TASKS).length,6);
for(const [dict,mode,version] of [[COMPOSITE_TASKS,'compositeLab',43],[CIRCLE_TASKS,'circleLab',45],[SIMILAR_TASKS,'similarLab',47],[RIGHT_TASKS,'rightLab',49],[SOLID_TASKS,'solidLab',51],[SETS_TASKS,'setsLab',53],[INVARIANT_TASKS,'invariantLab',65],[MOTION_TASKS,'motionLab',63],[CHANCE_TASKS,'chanceLab',61],[STATS_TASKS,'statsLab',59],[CHART_TASKS,'chartLab',57],[COMBIN_TASKS,'combinLab',55]])for(const [sid,t] of Object.entries(dict)){assert.equal(t.mode,mode);assert.equal(t.contentVersion,version);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(ANGLE_TASKS).length,5);for(const [sid,t] of Object.entries(ANGLE_TASKS)){assert.equal(t.mode,'angleLab');assert.equal(t.contentVersion,41);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(MEASURE_TASKS).length,5);for(const [sid,t] of Object.entries(MEASURE_TASKS)){assert.equal(t.mode,'measureLab');assert.equal(t.contentVersion,71);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(CYCLE_TASKS).length,6);for(const [sid,t] of Object.entries(CYCLE_TASKS)){assert(['groupingLab','patternLab','cycleLab'].includes(t.mode));assert.equal(t.contentVersion,37);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(COMMON_TASKS).length,5);for(const [sid,t] of Object.entries(COMMON_TASKS)){assert.equal(t.mode,'commonLab');assert.equal(t.contentVersion,35);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(FACTOR_TASKS).length,6);for(const [sid,t] of Object.entries(FACTOR_TASKS)){assert.equal(t.mode,'factorLab');assert.equal(t.contentVersion,33);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(GROUPING_TASKS).length,5);for(const [sid,t] of Object.entries(GROUPING_TASKS)){assert.equal(t.mode,'groupingLab');assert.equal(t.contentVersion,sid==='N01.03'?80:31);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(COORDINATE_TASKS).length,6);for(const [sid,t] of Object.entries(COORDINATE_TASKS)){assert.equal(t.mode,'coordinateLab');assert.equal(t.contentVersion,29);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(PATTERN_TASKS).length,6);for(const [sid,t] of Object.entries(PATTERN_TASKS)){assert.equal(t.mode,'patternLab');assert.equal(t.contentVersion,27);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(CONSTRAINT_TASKS).length,5);for(const [sid,t] of Object.entries(CONSTRAINT_TASKS)){assert.equal(t.mode,'constraintLab');assert.equal(t.contentVersion,25);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(EQUATION_TASKS).length,5);for(const [sid,t] of Object.entries(EQUATION_TASKS)){assert.equal(t.mode,'equationLab');assert.equal(t.contentVersion,23);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(SCALE_TASKS).length,5);for(const [sid,t] of Object.entries(SCALE_TASKS)){assert.equal(t.mode,'scaleLab');assert.equal(t.contentVersion,21);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(JOURNEY_TASKS).length,5);for(const [sid,t] of Object.entries(JOURNEY_TASKS)){assert.equal(t.mode,'journeyLab');assert.equal(t.contentVersion,19);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(RATE_TASKS).length,5);for(const [sid,t] of Object.entries(RATE_TASKS)){assert.equal(t.mode,'rateLab');assert.equal(t.contentVersion,17);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
assert.equal(Object.keys(RATIO_TASKS).length,5);
for(const [sid,t] of Object.entries(RATIO_TASKS)){assert.equal(t.mode,'ratioLab');assert.equal(t.contentVersion,15);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
for(const [sid,t] of Object.entries(INTEGER_TASKS)){assert.equal(t.mode,'integerLab');assert.equal(t.contentVersion,13);assert(t.reason&&skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].includes(t.id));}
for(const [sid,t] of Object.entries(PERCENT_TASKS)){
 assert.equal(t.contentVersion,11);assert.equal(t.mode,'percentLab');assert(t.reason);
 assert(skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));
 assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].split(';').includes(t.id));
 assert(skillRows.find(r=>r['微技能ID']===sid)['解释任务ID'].split(';').includes(t.id));
}
for(const [sid,t] of Object.entries(FRACTION_TASKS)){
 assert.equal(t.contentVersion,9);assert.equal(t.mode,'fractionLab');assert(t.reason&&t.reason.answer===0);
 assert(skills.skills.find(s=>s.id===sid).taskIds.includes(t.id));
 assert(skillRows.find(r=>r['微技能ID']===sid)['操作任务ID'].split(';').includes(t.id));
 assert(skillRows.find(r=>r['微技能ID']===sid)['解释任务ID'].split(';').includes(t.id));
 assert(sourceRows.find(r=>r['微技能ID']===sid)['网页任务ID'].split(';').includes(t.id));
}
for(const [sid,tasks] of Object.entries(STAGED_TASKS)){
 const row=skillRows.find(r=>r['微技能ID']===sid),src=sourceRows.find(r=>r['微技能ID']===sid),skill=skills.skills.find(s=>s.id===sid);
 assert(row['迁移任务ID'].split(';').includes(tasks.transfer.id));
 assert(row['独立测验ID'].split(';').includes(tasks.independent.id));
 assert(row['独立测验ID'].split(';').includes(tasks.independent2.id));
 assert(row['隔日任务ID'].split(';').includes(tasks.delayed.id));
 for(const [kind,t] of Object.entries(tasks)){
  assert(skill.taskIds.includes(t.id)&&src['网页任务ID'].split(';').includes(t.id));
  assert(Number.isInteger(t.contentVersion)&&t.contentVersion>0&&t.contentVersion<=release.contentRevision,'stage has a valid content version');assert(t.changeDimension&&t.prompt&&t.explain);
  if(t.mode==='objectSort')assert(t.answer.length&&t.answer.length<t.objects.length&&t.answer.every(i=>Number.isInteger(i)&&i>=0&&i<t.objects.length));
  else if(t.mode==='fractionLab'){
   assert.equal(t.mode,'fractionLab');
   if(['shade','decimal'].includes(t.kind))assert(t.target>0&&t.target<=t.denom);
   if(t.kind==='compare'){if(t.correctChoice==='differentWhole')assert.notEqual(t.wholeScaleLeft/t.denomLeft,t.wholeScaleRight/t.denomRight);else assert.equal(t.correctChoice,t.targetLeft/t.denomLeft===t.targetRight/t.denomRight?'equal':t.targetLeft/t.denomLeft>t.targetRight/t.denomRight?'left':'right');}
   if(t.kind==='equal')assert.equal(t.targetLeft*t.denomRight,t.targetRight*t.denomLeft,'equal strips must cover the same fraction');
   if(t.kind==='line')assert(t.target>0&&t.target<=t.denom);
   if(t.kind==='decimal')assert.equal(Number(t.correctChoice),t.target/t.denom);
   if(t.kind==='remainder'){assert.equal(t.second*2,t.total-t.first);assert.equal(Number(t.correctChoice.split('/')[0])/Number(t.correctChoice.split('/')[1]),t.second/(t.answerBasis==='remaining'?t.total-t.first:t.total))}
  }
  else if(['compositeLab','circleLab','similarLab','rightLab','solidLab','setsLab','invariantLab','motionLab','chanceLab','statsLab','chartLab','combinLab'].includes(t.mode)){assert(t.kind&&t.prompt&&t.explain);}
  else if(t.mode==='angleLab'){
   if(t.kind==='arms')assert(t.target>0&&t.target<=150&&t.target%15===0);
   if(t.kind==='turn')assert(t.targets.every(n=>n>0&&n<=360&&n%30===0));
   if(['triangle','conditions'].includes(t.kind)){assert.equal(t.angles.reduce((a,b)=>a+b,0),180);assert(t.angles.every(a=>a>0&&a%5===0));if(t.kind==='conditions')assert(t.angles.some((a,i)=>a===90&&i!==t.unknown))}
   if(t.kind==='polygon')assert(t.sides>=4&&t.sides<=7&&t.anchor>=0&&t.anchor<t.sides);
  }
  else if(t.mode==='measureLab'){
   assert(t.unitSize>0&&['cm','m'].includes(t.unit));
   if(t.kind==='length')assert(t.start>=0&&t.end>t.start&&t.end<=t.max);
   else{assert(t.rows<=4&&t.cols<=4);if(t.kind==='rearrange')assert(t.total>0&&t.total<=t.rows*t.cols&&t.reference.length>0);else assert(t.cells.length>0&&new Set(t.cells.map(p=>p.join(','))).size===t.cells.length&&t.cells.every(([r,c])=>r>=0&&r<t.rows&&c>=0&&c<t.cols))}
  }
  else if(t.mode==='cycleLab'){
   assert(Number.isInteger(t.target)&&t.target>=0&&(t.target>0||t.kind==='power'));
   if(t.kind==='power')assert([2,3,4,5].includes(t.factor)&&[1,2,4].includes(t.period));
   else{assert(t.base.length>=3);if(t.kind==='weekday')assert(t.base.length===7&&t.start>=0&&t.start<7)}
  }
  else if(t.mode==='commonLab'){
   const time=t.kind==='contexts'?t.bells:['multiples','least'].includes(t.kind)?t:null,paper=t.kind==='contexts'?t.paper:t.kind==='greatest'?t:null;
   if(time)assert(time.periods.length===2&&time.periods.every(n=>Number.isInteger(n)&&n>=2)&&time.horizon>Math.max(...time.periods));
   if(paper)assert(paper.dims.length===2&&paper.dims.every(n=>Number.isInteger(n)&&n>=4));
   if(t.kind==='divisors')assert(t.numbers.length===2&&t.numbers.every(n=>Number.isInteger(n)&&n>1));
  }
  else if(t.mode==='factorLab'){
   assert(t.numbers.length>=1&&t.numbers.every(n=>Number.isInteger(n)&&n>=1&&n<=36));
   if(t.kind==='square')assert(t.numbers.every(n=>Number.isInteger(n)&&n>0&&(t.classifySquare||Number.isInteger(Math.sqrt(n)))));
   if(t.kind==='unit')assert(t.numbers.includes(1));
   if(t.kind==='pairs')assert.equal(t.requiredPairs,2);
  }
  else if(t.mode==='groupingLab'){
   if(t.kind==='digits'){assert(t.pools.length===2&&t.pools.every(p=>p.length>1&&p.every(n=>Number.isInteger(n)&&n>=0&&n<=9)));assert(t.rule.tens!==undefined||t.rule.ones!==undefined)}
   else if(t.kind==='digitRules'){assert(t.cases.length>=3&&t.cases.every(c=>Number.isInteger(c.number)&&c.number>=0&&[2,3,5].includes(c.divisor)));assert.deepEqual([...new Set(t.cases.map(c=>c.divisor))].sort(),[2,3,5]);}
   else{assert(Number.isInteger(t.divisor)&&t.divisor>=2);const totals=t.kind==='digitSum'?t.numbers.map(n=>String(n).split('').reduce((a,v)=>a+Number(v),0)):t.totals||[t.total];assert(totals.every(n=>Number.isInteger(n)&&n>0));if(t.parts)t.parts.forEach((p,i)=>assert.equal(p.reduce((a,b)=>a+b,0),t.totals[i]));}
  }
  else if(t.mode==='coordinateLab'){
   if(t.kind==='machine'){assert(t.inputs.length===3&&t.multiplier>1&&t.add>0);if(t.reverseIndex!==undefined)assert.equal(t.reverseIndex,2)}
   if(t.kind==='pair')assert(t.target.every((v,i)=>Number.isInteger(v)&&v>=0&&v<=(i?t.maxY:t.maxX)));
   if(t.kind==='order'){assert(t.targets.length===2&&t.targets[0][0]===t.targets[1][1]&&t.targets[0][1]===t.targets[1][0]);assert.notEqual(t.targets[0][0],t.targets[0][1])}
   if(t.kind==='table')assert(t.pairs.length===3&&new Set(t.pairs.map(p=>p.join(','))).size===3);
   if(t.kind==='move')assert(t.start[0]+t.dx>=0&&t.start[0]+t.dx<=t.maxX&&t.start[1]+t.dy>=0&&t.start[1]+t.dy<=t.maxY);
   if(t.kind==='dynamic')assert(t.startValue+t.step*t.duration>=0&&t.startValue+t.step*t.duration<=t.maxY&&t.duration===t.maxX);
  }
  else if(t.mode==='patternLab'){
   if(t.kind==='period'){assert(t.base.length>=1);const observed=Array.from({length:3},()=>t.base).flat(),primitive=Array.from({length:t.base.length},(_,i)=>i+1).find(k=>observed.every((v,i)=>v===observed[i%k]));assert(primitive>=1&&t.base.length%primitive===0,'shortest repeating block reconstructs declared repeat')}
   if(t.kind==='arithmetic')assert(t.initial.slice(1).every((v,i)=>v-t.initial[i]===t.step)&&t.step!==0);
   if(t.kind==='geometric')assert(t.factor>=1&&t.initial.slice(1).every((v,i)=>v===t.initial[i]*t.factor));
   if(t.kind==='explicit')assert(t.initial.length===1&&t.multiplier>1&&t.add>0);
   if(t.kind==='twoPrev')assert(t.initial.length===2&&Number.isInteger(t.count)&&t.count>=2);
   if(t.kind==='grid')assert(t.rows>=2&&t.cols>=3&&(t.tile?t.tile.every(row=>row.length===t.tile[0].length&&row.every(v=>['red','blue'].includes(v))):['red','blue'].includes(t.start)));
  }
  else if(t.mode==='constraintLab'){
   if(['reverse','verify'].includes(t.kind))assert(t.groups>1&&t.bag>0&&t.extra>0);
   if(t.kind==='parity')assert(Number.isInteger(t.total)&&t.total>=0&&t.divisor>1,'both divisible and nondivisible conditions are valid');
   if(['stock','optimal'].includes(t.kind))assert(Number.isInteger(t.stock)&&t.stock>=0&&t.per>1,'zero full bags and exact fit are valid boundaries');
  }
  else if(t.mode==='equationLab'){
   if(t.kind==='equal')assert.equal(t.left.reduce((a,b)=>a+b,0)===t.right.reduce((a,b)=>a+b,0),t.equalAnswer??true);
   if(['unknown','bilateral'].includes(t.kind))assert(t.total>t.known&&t.known>0);
   if(t.kind==='inverse')assert(t.initial>t.remain&&t.remain>=0);
   if(t.kind==='substitute')assert.equal(t.bag+t.known===t.total,t.correctVerdict!=='reject');
  }
  else if(t.mode==='scaleLab'){
   if(t.kind==='pair')assert(t.red>0&&t.blue>0&&t.factor>1);
   if(t.kind==='length')assert(t.short>0&&t.long>0&&t.factor>1);
   if(t.kind==='area')assert(t.rows>0&&t.cols>0&&t.factor>1);
   if(t.kind==='map')assert(t.per>0&&t.count>0);
   if(t.kind==='change')assert.equal(t.correctChoice,String(t.start+t.add-t.remove));
  }
  else if(t.mode==='journeyLab'){
   if(['equal','inverse','joint'].includes(t.kind))assert(t.count>0&&t.count<7);
   if(['segment','remaining'].includes(t.kind)){assert(t.segments.length>=2&&t.segments.every(v=>v>=0)&&t.segments.some(v=>v>0));if(t.kind==='remaining')assert(t.whole>t.segments.reduce((a,b)=>a+b,0))}
   if(t.kind==='joint')assert(t.a>0&&t.b>0);
  }
  else if(t.mode==='rateLab'){
   if(['divide','compose'].includes(t.kind))assert.equal(t.total,t.units*t.per);
   if(t.kind==='compare'){assert.equal(t.a.total,t.a.units*t.a.per);assert.equal(t.b.total,t.b.units*t.b.per);assert(t.a.per>0&&t.b.per>0,'unit rates may legitimately be equal')}
   if(t.kind==='convert')assert(t.count>0&&[60,100].includes(t.factor)&&['forward','reverse'].includes(t.direction));
  }
  else if(t.mode==='ratioLab'){
   assert(t.red>0&&t.blue>0);
   if(t.kind==='unit')assert.equal(t.red,t.groups*t.unit);
   if(t.kind==='scale')assert(t.copies>=2);
   if(t.kind==='partition'){assert.equal(t.red,t.unitRed*t.copies);assert.equal(t.blue,t.unitBlue*t.copies)}
  }
  else if(t.mode==='integerLab'){
   assert.equal(t.mode,'integerLab');
   assert(Number.isInteger(t.target));
   if(t.kind==='walk')assert(t.start*t.target<0,'cross-zero instances must cross zero');
   if(t.kind==='compare')assert.equal(t.target,Math.max(t.left,t.right));
   if(['square','root'].includes(t.kind))assert.equal(t.target,t.side*t.side*(t.unitSize??1)**2);
   if(t.kind==='power')assert.equal(t.target,t.base**t.exponent);
  }
  else if(['counterBuild','compareBuild','reverseExchange','forwardExchange','placeCompose','tenFill','counterRemove','counterChange','inverseMove','equalGroups','orderGroups'].includes(t.mode)){assert(t.semanticParameters&&[68,72].includes(t.contentVersion));}
  else{
   assert.equal(t.mode,'percentLab');assert(t.choices.includes(t.correctChoice));
   if(t.kind==='shade')assert(t.target>0&&t.target<t.total);
   if(t.kind==='whole')assert.equal(Number(t.correctChoice),t.part*t.copies);
   if(t.kind==='change'){
    assert.equal(Number(t.correctChoice),t.start+t.add-t.remove);
    if(t.changeOrder==='removeFirst')assert.equal(t.remove*(t.start-t.remove),t.add*t.start,'second percentage must use the reduced base');
    else assert.equal(t.add*(t.start+t.add),t.remove*t.start,'second percentage must use the new base');
   }
   if(t.kind==='estimate'&&t.bounds){assert(t.bounds.lower[0]*t.bounds.lower[1]<t.a*t.b);assert(t.a*t.b<t.bounds.upper[0]*t.bounds.upper[1]);assert.equal(t.correctChoice,t.bounds.lower[0]*t.bounds.lower[1]+'＜积＜'+t.bounds.upper[0]*t.bounds.upper[1]);}
   if(t.kind==='estimate'&&!t.bounds){
    assert.equal(Number(t.correctChoice.replace(/\D/g,'')),t.targetA*t.targetB);
    assert.equal(t.targetA%10,0);assert.equal(t.targetB%10,0);
    assert(Math.abs(t.a-t.targetA)<=2&&Math.abs(t.b-t.targetB)<=2,'nearby tens, not unrelated factors');
   }
  }
  if(kind!=='transfer')assert(!t.hint,'independent and delayed instances have no hint');
 }
 assert(!row['操作任务ID'].split(';').includes(tasks.transfer.id),'stage object selection cannot be credited as full operation');
}
assert.equal(Object.keys(MICRO_CASES).length,33);
assert.equal(Object.keys(BREADTH).length,28);
assert.equal(FOCUS_CODES.length,33);
assert.equal(new Set(FOCUS_CODES).size,33);
assert.equal(Object.values(FOCUS_REVIEW).flat().length,66);
assert.equal(Object.keys(REASONS).length,32);
assert.equal(Object.keys(SEQUENCES).length,13);
assert.equal(Object.keys(TRANSFERS).length,32);
assert.equal(Object.keys(EXPLORATIONS).length,24);
assert.equal(new Set(Object.values(FOCUS_REVIEW).flat().map(t=>t.id)).size,66);
assert.deepEqual(FRUIT_TASKS.reduce((a,t)=>(a[t.phase]++,a),{学:0,练:0,测:0}),{学:12,练:4,测:10});
assert.deepEqual(PEOPLE.map(p=>p.group),['r','r','o','o','o','y','y']);
for(const t of catalog.topics){assert(SAMPLE_TASKS[t.code],t.code+' sample missing')}
for(const [id,t] of Object.entries(SAMPLE_TASKS)){
 assert.equal(t.id,'SAMPLE-'+id,'sample logs have stable unique task IDs');
 assert(t.prompt&&t.hint&&t.explain&&t.scene,id+' teaching metadata');
 if(t.mode==='choice')assert(t.answer>=0&&t.answer<t.options.length,id+' choice');
 else if(t.mode==='multi')assert(t.answer.length>=1&&t.answer.every(a=>a<t.options.length),id+' multi');
 else assert(Number.isFinite(t.answer),id+' number');
}
for(const [id,course] of Object.entries(COURSES)){
 assert(catalog.topics.some(t=>t.code===id),id+' catalog entry');
 assert.equal(course.steps.length,8,id+' steps');
 assert.deepEqual(course.steps.map(t=>t.phase),['学','学','学','学','练','练','测','测']);
 assert(course.steps.slice(0,4).some(t=>t.explore||!['number','choice'].includes(t.mode)),id+' needs an active learning step');
 for(const t of course.steps){
  assert(t.prompt&&t.explain,t.id+' content');
  if(t.phase==='测')assert(!t.hint,t.id+' test has no hint');
  if(t.mode==='pairs')assert.equal(new Set(t.answer).size,t.answer.length,t.id+' distinct pair answers');
 }
}
for(const [code,[step]] of Object.entries(EXPLORATIONS)){
 const x=COURSES[code].steps[step].explore;
 assert(x&&x.cards.length===3&&x.answer.length===2&&new Set(x.answer).size===2,code+' distinct concept steps');
 assert(x.answer.every(i=>i>=0&&i<3)&&x.feedback,code+' correct relation and misconception feedback');
}
assert.equal(parts({a:18,b:14,o:5}).total,27);
for(const expr of [['A','+','B','-','O'],['B','+','A','-','O'],['A','-','O','+','B'],['R','+','O','+','Y'],['Y','+','R','+','O'],['A','+','Y'],['R','+','B']]){
 assert(checkExpression(expr,{a:18,b:14,o:5}).ok,expr.join('')+' is valid');
}
const coincidental=checkExpression(['A','+','R'],{a:5,b:5,o:3});
assert.equal(coincidental.value,7);assert.equal(coincidental.ok,false,'equal total must not override wrong set meaning');
assert.equal(checkExpression(['A','+','B'],{a:5,b:5,o:3}).ok,false,'double count rejected');
assert.equal(checkExpression(['R','+','O'],{a:5,b:5,o:3}).ok,false,'missing yellow rejected');

function boot(seed={},voice=false,clock={now:Date.now()},storageFault={},appCode=code){
 const storage={...seed},root={innerHTML:''},speechStatus={textContent:''},storageStatus={textContent:'',hidden:true},spoken=[],utterances=[],events={};
 const document={getElementById:id=>id==='app'?root:id==='storage-status'?storageStatus:speechStatus,addEventListener:(name,cb)=>events[name]=cb};
 const window={__AMC8_RELEASE:release,__AMC8_CATALOG:catalog,__AMC8_SKILLS:skills,__AMC8_CURRICULUM:require('./curriculum.json'),__AMC8_KNOWLEDGE:require('./knowledge_graph.json'),__AMC8_JOINT:require('./joint_families.json'),__AMC8_EXAM_REVIEW:{verifiedIds:verifiedExamIds},scrollTo(){}};
 if(voice)window.speechSynthesis={cancel(){},speak(u){spoken.push(u.text);utterances.push(u)}};
 const ctx={document,window,SpeechSynthesisUtterance:function(text){this.text=text},MouseEvent:function(type,options){this.type=type;Object.assign(this,options)},localStorage:{getItem:k=>{if(storageFault.read)throw Error('Read blocked');return storage[k]||null;},setItem:(k,v)=>{if(storageFault.write||storageFault.backup&&k.includes('_backup_'))throw Error('Write blocked');storage[k]=v;}},console,Number,JSON,Set,Array,Math,Date:class extends Date{static now(){return clock.now}}};
 vm.createContext(ctx);vm.runInContext(appCode,ctx);
 return {root,storage,events,speechStatus,storageStatus,spoken,utterances,clock,
  click(action,extra={}){const target={dataset:{action,...extra},closest(){return target}};events.click({target})},
  input(value){events.input({target:{matches:()=>true,value:String(value)}})},
 };
}
const b=boot();
assert.equal((b.root.innerHTML.match(/data-action="topicSelect"/g)||[]).length,33,'all topics selectable on home');
b.click('knowledge');assert.equal((b.root.innerHTML.match(/class="lamp [^>]*data-action="network"/g)||[]).length,33,'all 33 regions remain available in the knowledge map');
assert.equal((b.root.innerHTML.match(/class="today-item"/g)||[]).length,4,'short recommendations do not hide the full map');
for(const topic of catalog.topics)assert(b.root.innerHTML.includes('data-action="network" data-code="'+topic.code+'"'),'all knowledge region identities remain in the parent map');
const microRun=boot();microRun.click('skillMap');
const microState=b=>JSON.parse(b.storage.tianle_amc8_question_design_v1);
const microLatest=b=>microState(b).attempts.at(-1);
assert.equal((microRun.root.innerHTML.match(/data-action="micro"/g)||[]).length,179,'all 179 micro tasks have visible direct navigation');
for(const [skillId,t] of Object.entries(MICRO_TASKS)){
 microRun.click('micro',{code:skillId});
 assert(microRun.root.innerHTML.includes(t.prompt.replaceAll('＞','&gt;'))||microRun.root.innerHTML.includes('object-board'),skillId+' opens');
 for(const index of t.answer)microRun.click('sortObject',{index:String(index)});
 microRun.click('check');
 assert(microRun.root.innerHTML.includes('答对了！'),skillId+' intended selection is accepted');
 assert.equal(microLatest(microRun).taskInstanceId,t.id);
 assert.deepEqual(microLatest(microRun).skillIds,[skillId],skillId+' records only its own skill');
 microRun.click('next');
}
const microRepeat=Object.values(MICRO_TASKS)[0];microRun.click('micro',{code:microRepeat.skillId});
for(const index of microRepeat.answer)microRun.click('sortObject',{index:String(index)});
microRun.click('check');assert.equal(microLatest(microRun).independent,false,'reopening a micro task does not create new independent evidence');
const microUndo=boot();microUndo.click('micro',{code:microRepeat.skillId});microUndo.click('check');
assert.equal(microState(microUndo).attempts.length,0,'empty tray cannot create answer evidence; display order may be saved');
microUndo.click('sortObject',{index:'2'});microUndo.click('sortUndo');assert(microUndo.root.innerHTML.includes('托盘 · 0 件'),'object returns to board after undo');
microUndo.click('sortObject',{index:'2'});microUndo.click('sortObject',{index:'2'});assert(microUndo.root.innerHTML.includes('托盘 · 0 件'),'tapping a chosen object returns it to board');
microUndo.click('sortObject',{index:'2'});microUndo.click('check');assert.equal(microLatest(microUndo).gradingResult,'incorrect','wrong mathematical object is rejected');
microUndo.click('hint');for(const index of microRepeat.answer)microUndo.click('sortObject',{index:String(index)});
microUndo.click('sortObject',{index:'2'});microUndo.click('check');assert.equal(microLatest(microUndo).gradingResult,'correct');
assert.equal(microLatest(microUndo).independent,false,'incorrect first try and opened hint cannot become independent evidence');
const stageClock={now:Date.now()},stageRun=boot({},false,stageClock);
function solvePrediction(b,t){
 if(!['测','巩固'].includes(t.phase))return;
 let expected=null;
 if(t.mode==='integerLab'&&['square','root','power'].includes(t.kind))expected=[t.kind==='root'?t.side*(t.unitSize??1):t.target];
 if(t.mode==='patternLab'&&['arithmetic','geometric','explicit','twoPrev'].includes(t.kind)){
  const values=[...t.initial];const count=t.kind==='twoPrev'?t.count:2;
  for(let i=0;i<count;i++)values.push(t.kind==='arithmetic'?values.at(-1)+t.step:t.kind==='geometric'?values.at(-1)*t.factor:t.kind==='explicit'?(t.operationOrder==='addThenMultiply'?(values.at(-1)+t.add)*t.multiplier:values.at(-1)*t.multiplier+t.add):values.at(-1)+values.at(-2));expected=values.slice(t.initial.length);
 }
 if(t.mode==='measureLab'&&t.kind!=='rearrange'){const per=measureOuterOracle(t.cells||[]).length*t.unitSize,area=(t.cells||[]).length*t.unitSize**2;expected=t.kind==='length'?[(t.end-t.start)*t.unitSize]:t.kind==='perimeter'?[per]:t.kind==='area'?[area]:[per,area]}
 if(t.mode==='angleLab'&&['triangle','conditions'].includes(t.kind))expected=[180-t.angles.filter((_,i)=>i!==t.unknown).reduce((a,b)=>a+b,0)];
 if(['percentLab','scaleLab'].includes(t.mode)){if(t.kind==='whole')expected=[t.part*t.copies];if(t.kind==='change')expected=[t.start+t.add-t.remove];if(t.kind==='estimate'&&t.bounds)expected=['lower','upper'].map(k=>t.bounds[k][0]*t.bounds[k][1])}
 if(t.mode==='ratioLab'){
  if(t.kind==='unit')expected=[t.groups];
  if(t.kind==='partition')expected=t.knownUnit?[t.copies]:[t.unitRed,t.unitBlue];
  if(t.kind==='scale')expected=[t.red*(t.targetCopies?.red||t.copies),t.blue*(t.targetCopies?.blue||t.copies)];
 }
 if(t.mode==='rateLab'){
  if(t.kind==='divide')expected=[t.per];if(t.kind==='compose')expected=[t.total];
  if(t.kind==='compare')expected=[t.a.total/t.a.units,t.b.total/t.b.units];
  if(t.kind==='convert')expected=[t.direction==='forward'?t.count*t.factor:t.count];
 }
 if(t.mode==='journeyLab'){
  const walked=t.segments?.reduce((a,b)=>a+b,0);
  expected=t.kind==='inverse'?[t.count*(t.elapsedPer||1)]:t.kind==='remaining'?[t.unknownWhole?t.whole:t.whole-walked]:t.kind==='joint'?[['a','b'].reduce((n,s)=>n+t[s]*Math.max(0,t.count-(t.starts?.[s]||0)),0)]:[t.kind==='segment'?walked:t.count*t.per];
 }
 if(t.mode==='scaleLab'){
  if(t.kind==='pair')expected=[t.red*(t.targetFactors?.red||t.factor),t.blue*(t.targetFactors?.blue||t.factor)];
  if(t.kind==='length')expected=['short','long'].map(s=>t.direction==='shrink'?t[s]/t.factor:t[s]*t.factor);
  if(t.kind==='area')expected=[t.rows*t.cols*(t.axisFactors?.rows||t.factor)*(t.axisFactors?.cols||t.factor)];
  if(t.kind==='map')expected=[t.count*t.per];
 }
if(t.mode==='equationLab'){
  if(t.kind==='equal')expected=[Number(t.left.reduce((a,n)=>a+n,0)===t.right.reduce((a,n)=>a+n,0))];
  if(['unknown','bilateral'].includes(t.kind))expected=[t.total-t.known];
  if(t.kind==='inverse')expected=[t.unknownInitial?t.remain+t.removedGiven:t.initial-t.remain];
  if(t.kind==='substitute')expected=[Number(t.bag+t.known===t.total)];
 }
 if(t.mode==='constraintLab'){
  if(t.kind==='reverse')expected=[t.bag];
  if(t.kind==='verify')expected=[Number(t.groups*t.bag+(t.extraOutside?t.extra:t.groups*t.extra)===(t.givenTotal??t.groups*(t.bag+t.extra)))];
  if(t.kind==='parity')expected=[Number(t.total%t.divisor===0)];
  if(['stock','optimal'].includes(t.kind))expected=[Math.floor(t.stock/t.per)];
 }
 if(t.mode==='coordinateLab'){
  if(t.kind==='machine')expected=[t.reverseIndex===2?t.inputs[2]:t.inputs[2]*t.multiplier+t.add];
  if(t.kind==='dynamic')expected=[t.startValue+t.step*t.duration];
 }
 if(t.mode==='groupingLab'&&t.kind==='digitRules')expected=t.cases.map(c=>c.number%c.divisor);
 else if(t.mode==='groupingLab'&&t.kind!=='digits')expected=t.kind==='reconstruct'?[t.knownGroups*t.divisor+t.remainder]:(t.kind==='digitSum'?t.numbers.map(n=>String(n).split('').reduce((a,b)=>a+Number(b),0)):t.totals||[t.total]).map(n=>n%t.divisor);
 if(t.mode==='cycleLab'){
  if(t.kind==='power'){let digit=1;for(let i=0;i<t.target;i++)digit=digit*t.factor%10;expected=[digit]}else{
   const n=t.base.length,pos=(((t.kind==='weekday'?t.start:t.indexBase===0?0:-1)+(t.direction||1)*t.target)%n+n)%n;
   expected=[t.kind==='weekday'||t.indexBase===0?pos:pos+1];
  }
 }
 if(!expected)return;
 if((t.mode==='equationLab'&&['equal','substitute'].includes(t.kind))||(t.mode==='constraintLab'&&['verify','parity'].includes(t.kind))||(t.mode==='cycleLab'&&t.kind==='weekday')){b.click('predictionPick',{value:String(expected[0])});b.click('predictionLock');return}
 expected.forEach((n,index)=>{if(n===0)b.click('predictionAmount',{index:String(index),delta:'0'});else{const sign=Math.sign(n);n=Math.abs(n);for(const d of [50,10,5,1])while(n>=d){b.click('predictionAmount',{index:String(index),delta:String(sign*d)});n-=d}}});b.click('predictionLock');
}
function solveInteger(b,t){
 solvePrediction(b,t);
 if(['position','walk'].includes(t.kind))for(let n=t.start;n!==t.target;n+=Math.sign(t.target-n))b.click('integerStep',{delta:String(Math.sign(t.target-n))});
 if(t.kind==='compare'){b.click('integerMark',{value:String(t.left)});b.click('integerMark',{value:String(t.right)});b.click('integerChoice',{value:t.target===t.left?'left':'right'})}
 if(t.kind==='square')for(let i=0;i<t.side;i++)b.click('integerRow',{delta:'1'});
 if(t.kind==='root')for(let i=0;i<t.side;i++)b.click('integerGrow',{delta:'1'});
 if(t.unitSize&&!['测','巩固'].includes(t.phase)){let n=t.kind==='root'?t.side*t.unitSize:t.target;for(const d of [10,5,1])while(n>=d){b.click('integerAmount',{delta:String(d)});n-=d}}
 if(t.kind==='power')for(let i=0;i<t.exponent;i++)b.click('integerMultiply');
}
function solveRatio(b,t){
 solvePrediction(b,t);
 if(t.kind==='unit')for(let i=0;i<t.groups;i++)b.click('ratioGroup',{delta:'1'});
 if(['order','whole'].includes(t.kind)){for(let i=0;i<t.red;i++)b.click('ratioAdd',{side:'red',delta:'1'});for(let i=0;i<t.blue;i++)b.click('ratioAdd',{side:'blue',delta:'1'});let choice;if(t.kind==='order')choice=t.order==='blueFirst'?`${t.blue}:${t.red}`:`${t.red}:${t.blue}`;else{const n=t.focusSide==='blue'?t.blue:t.red,gcd=(a,b)=>b?gcd(b,a%b):a,g=gcd(n,t.red+t.blue);choice=`${n/g}/${(t.red+t.blue)/g}`}b.click('ratioChoice',{value:choice})}
 if(t.kind==='scale'){const target=t.targetCopies||{red:t.copies,blue:t.copies};for(const side of ['red','blue'])for(let i=1;i<target[side];i++)b.click('ratioCopy',{side});if(t.targetCopies)b.click('ratioChoice',{value:target.red===target.blue?'same':'changed'})}
 if(t.kind==='partition'){if(!t.knownUnit){for(let i=0;i<t.unitRed;i++)b.click('ratioPer',{side:'red',delta:'1'});for(let i=0;i<t.unitBlue;i++)b.click('ratioPer',{side:'blue',delta:'1'})}for(let i=0;i<t.copies;i++)b.click('ratioBag')}
}
function solveRate(b,t){
 solvePrediction(b,t);
 const fill=(side,units,per)=>{for(let n=0;n<per;n++)for(let i=0;i<units;i++)b.click('rateMove',{side,index:String(i)})};
 if(['divide','compose'].includes(t.kind))fill('main',t.units,t.per);
 if(t.kind==='compare'){fill('a',t.a.units,t.a.per);fill('b',t.b.units,t.b.per);b.click('rateChoice',{value:t.a.per<t.b.per?'a':t.a.per>t.b.per?'b':'equal'})}
 if(t.kind==='convert')for(let i=0;i<t.count;i++)b.click('rateCard',{delta:'1'});
}
function solveJourney(b,t){
 solvePrediction(b,t);
 if(t.kind==='joint'){for(let i=0;i<t.count;i++)for(const side of ['b','a'])if(i>=(t.starts?.[side]||0))b.click('journeyWorker',{side})}
 else for(let i=0;i<(['segment','remaining'].includes(t.kind)?t.segments.length:t.count);i++)b.click('journeyStep');
 if(t.kind==='remaining'&&!t.unknownWhole)b.click('journeyChoice',{value:String(t.whole-t.segments.reduce((a,c)=>a+c,0))});
 for(const [action,value] of [...(t.unknownWhole?[['journeyWhole',t.whole]]:[]),...(t.elapsedPer?[['journeyElapsed',t.count*t.elapsedPer]]:[])]){let n=value;for(const d of [10,5,1])while(n>=d){b.click(action,{delta:String(d)});n-=d}}
}
function solveScale(b,t){
 solvePrediction(b,t);
 if(t.kind==='pair'){const target=t.targetFactors||{red:t.factor,blue:t.factor};for(const side of ['red','blue'])for(let i=1;i<target[side];i++)b.click('scaleCopy',{side});if(t.targetFactors)b.click('scaleChoice',{value:target.red===target.blue?'same':'changed'})}
 if(t.kind==='length')for(let i=1;i<t.factor;i++)b.click('scaleBoth');
 if(t.kind==='area'){const target=t.axisFactors||{rows:t.factor,cols:t.factor};for(const side of ['rows','cols'])for(let i=1;i<target[side];i++)b.click('scaleAxis',{side});if(t.axisFactors)b.click('scaleChoice',{value:target.rows===target.cols?'same':'changed'})}
 if(t.kind==='map')for(let i=0;i<t.count;i++)b.click('scaleCard',{delta:'1'});
 if(t.kind==='change')solvePercent(b,t);
}
function solveEquation(b,t){
 solvePrediction(b,t);
 if(t.kind==='equal'){for(const side of ['left','right'])for(let i=0;i<t[side].length;i++)b.click('equationTerm',{side,index:String(i)});if(t.equalAnswer===false)b.click('equationVerdict',{value:'unequal'})}
 if(t.kind==='unknown'){b.click('equationTake');for(let i=0;i<t.total-t.known;i++)b.click('equationBag')}
 if(t.kind==='bilateral'){if(t.addBoth!==undefined){for(let i=0;i<t.addBoth;i++){b.click('equationLeftAdd');b.click('equationRightAdd')}}else for(let i=0;i<t.known;i++){b.click('equationLeftTake');b.click('equationRightTake')}for(let i=0;i<t.total-t.known;i++)b.click('equationBag')}
 if(t.kind==='inverse'){if(t.unknownInitial){for(let i=0;i<t.removedGiven;i++)b.click('equationReturn');for(let i=0;i<t.initial;i++)b.click('equationWhole',{delta:'1'})}else for(let i=0;i<t.initial-t.remain;i++)b.click('equationRemove')}
 if(t.kind==='substitute'){for(let i=0;i<t.bag;i++)b.click('equationBag');for(let i=0;i<t.known;i++)b.click('equationKnown');if(t.correctVerdict)b.click('equationVerdict',{value:t.bag+t.known===t.total?'accept':'reject'})}
}
function solveConstraint(b,t){
 solvePrediction(b,t);
 if(t.kind==='reverse'){if(!t.extraOutside)b.click('constraintDivide');for(let i=0;i<t.extra;i++)b.click('constraintPeel');if(t.extraOutside)b.click('constraintDivide')}
 if(t.kind==='verify'){for(let i=0;i<t.bag;i++)b.click('constraintFill');for(let i=0;i<t.extra;i++)b.click('constraintExtra');if(t.correctVerdict)b.click('constraintChoose',{value:t.groups*t.bag+(t.extraOutside?t.extra:t.groups*t.extra)===(t.givenTotal??t.groups*(t.bag+t.extra))?'accept':'reject'})}
 if(t.kind==='parity'){for(let i=0;i<Math.floor(t.total/t.divisor);i++)b.click('constraintPair');b.click('constraintChoose',{value:t.total%t.divisor===0?'possible':'impossible'})}
 if(t.kind==='stock'){for(let i=0;i<Math.floor(t.stock/t.per);i++)b.click('constraintPack');b.click('constraintProbe')}
 if(t.kind==='optimal'){const max=Math.floor(t.stock/t.per);for(let i=1;i<=max+1;i++)b.click('constraintTrial',{value:String(i)});b.click('constraintChoose',{value:String(max)})}
}
function solvePattern(b,t){
 solvePrediction(b,t);
 if(t.kind==='period'){b.click('patternLength',{value:String(Array.from({length:t.base.length},(_,i)=>i+1).find(n=>[...t.base,...t.base,...t.base].every((v,i)=>v===t.base[i%n])))});b.click('patternCopy')}
 if(t.kind==='arithmetic'){for(let i=0;i<Math.abs(t.step);i++)b.click('patternAdjust',{delta:String(Math.sign(t.step))});b.click('patternAppend');b.click('patternAppend')}
 if(t.kind==='geometric'){for(let i=1;i<t.factor;i++)b.click('patternAdjust',{delta:'1'});b.click('patternAppend');b.click('patternAppend')}
 if(t.kind==='explicit')for(let i=0;i<2;i++){for(const action of t.operationOrder==='addThenMultiply'?['patternAdd','patternMultiply']:['patternMultiply','patternAdd'])b.click(action);b.click('patternCommit')}
 if(t.kind==='twoPrev')for(let i=0;i<t.count;i++){b.click('patternPick',{index:String(i)});b.click('patternPick',{index:String(i+1)});b.click('patternSum')}
 if(t.kind==='grid')for(let r=t.tile?.length||1;r<t.rows;r++)for(let c=0;c<t.cols;c++){const color=t.tile?t.tile[r%t.tile.length][c%t.tile[0].length]:(r+c)%2===0?t.start:t.start==='red'?'blue':'red';b.click('patternCell',{row:String(r),col:String(c)});if(color==='blue')b.click('patternCell',{row:String(r),col:String(c)})}
}
function solveCoordinate(b,t){
 solvePrediction(b,t);
 const locate=(i,p)=>{b.click('coordActive',{index:String(i)});b.click('coordAxis',{axis:'x',value:String(p[0])});b.click('coordAxis',{axis:'y',value:String(p[1])});b.click(t.givenPoint||t.direction==='read'?'coordRecord':'coordPoint',{x:String(p[0]),y:String(p[1])})};
 if(t.kind==='machine'){
  for(let i=1;i<t.multiplier;i++)b.click('coordAdjust',{key:'multiplier',delta:'1'});
  for(let i=0;i<t.add;i++)b.click('coordAdjust',{key:'add',delta:'1'});
  if(t.reverseIndex!==undefined)for(let i=0;i<t.inputs[t.reverseIndex];i++)b.click('coordInput',{index:String(t.reverseIndex),delta:'1'});
  for(let i=0;i<t.inputs.length;i++){b.click('coordMultiply',{index:String(i)});b.click('coordAdd',{index:String(i)})}
 }
 if(t.kind==='pair')locate(0,t.target);
 if(t.kind==='order')t.targets.forEach((p,i)=>locate(i,p));
 if(t.kind==='table')t.pairs.forEach((p,i)=>locate(i,p));
 if(t.kind==='move'){for(let i=0;i<Math.abs(t.dx);i++)b.click('coordMove',{dx:String(Math.sign(t.dx)),dy:'0'});for(let i=0;i<Math.abs(t.dy);i++)b.click('coordMove',{dx:'0',dy:String(Math.sign(t.dy))})}
 if(t.kind==='dynamic'){for(let i=0;i<Math.abs(t.step);i++)b.click('coordDelta',{delta:String(Math.sign(t.step))});for(let i=0;i<t.duration;i++)b.click('coordTick')}
}
const groupingDigitFixtures={'O-N01-04-1':['30','34','37'],'T-N01-04-1':['12','42'],'T-N01-04-2':['20','25','28'],'T-N01-04-3':['40','41'],'T-N01-04-4':['23']};
function solveGrouping(b,t){
 solvePrediction(b,t);
 if(t.kind==='digitRules'){require('./test_digit_rules_solver').solveDigitRules(b,t);return}
 if(t.kind==='reconstruct'){for(let i=0;i<t.knownGroups;i++)b.click('groupUnwrap',{index:String(i)});for(let n=0;n<t.knownGroups*t.divisor+t.remainder;n++)b.click('groupWhole',{delta:'1'});return}
 if(t.kind==='digits')for(const value of t.pools[0].flatMap(a=>t.pools[1].filter(c=>a!==0&&(t.rule.tens===undefined||a===t.rule.tens)&&(t.rule.ones===undefined||c===t.rule.ones)&&(!t.rule.different||a!==c)).map(c=>String(a)+String(c)))){b.click('groupDigit',{place:'tens',value:value[0]});b.click('groupDigit',{place:'ones',value:value[1]});b.click('groupRecord')}
 else{
  const totals=t.kind==='digitSum'?t.numbers.map(n=>String(n).split('').reduce((sum,v)=>sum+Number(v),0)):t.totals||[t.total];
  totals.forEach((total,i)=>{
   if(t.kind==='digitSum')for(let j=0;j<String(t.numbers[i]).length;j++)b.click('groupSumDigit',{card:String(i),index:String(j)});
   for(let start=0;start+t.divisor<=total;start+=t.divisor){for(let j=0;j<t.divisor;j++)b.click('groupPick',{card:String(i),index:String(start+j)});b.click('groupWrap',{card:String(i)})}
   b.click('groupProbe',{card:String(i)});const rem=total%t.divisor,value=t.kind==='remainder'?String(rem):t.kind==='parity'?rem===0?'even':'odd':rem===0?'complete':'remain';b.click('groupChoice',{card:String(i),value});
  });
 }
}
const factorFixtures={1:[[1,1]],2:[[1,2]],3:[[1,3]],4:[[1,4],[2,2]],5:[[1,5]],7:[[1,7]],8:[[1,8],[2,4]],9:[[1,9],[3,3]],10:[[1,10],[2,5]],11:[[1,11]],12:[[1,12],[2,6],[3,4]],15:[[1,15],[3,5]],16:[[1,16],[2,8],[4,4]],18:[[1,18],[2,9],[3,6]],20:[[1,20],[2,10],[4,5]],24:[[1,24],[2,12],[3,8],[4,6]],25:[[1,25],[5,5]],30:[[1,30],[2,15],[3,10],[5,6]],36:[[1,36],[2,18],[3,12],[4,9],[6,6]]};
function solveFactor(b,t){
 t.numbers.forEach((n,i)=>{
  b.click('factorActive',{index:String(i)});const allPairs=Array.from({length:Math.floor(Math.sqrt(n))},(_,i)=>i+1).filter(d=>n%d===0).map(d=>[d,n/d]),pairs=t.kind==='pairs'?allPairs.filter(p=>p[0]>=(t.minimumSide||1)).slice(0,t.requiredPairs):allPairs;
  for(const p of pairs){b.click('factorPalette');b.click('factorWidth',{value:String(p[1])});b.click('factorFill');b.click('factorRecord');if(t.kind!=='pairs')for(const v of p)b.click('factorCollect',{value:String(v)});b.click('factorClear')}
  const count=new Set(pairs.flat()).size;
  if(['unit','square','count'].includes(t.kind))for(let j=0;j<count;j++)b.click('factorCount',{delta:'1'});
  if(t.classifySquare)b.click('factorChoice',{value:Number.isInteger(Math.sqrt(n))?'square':'nonsquare'});
  if(['prime','unit'].includes(t.kind))b.click('factorChoice',{value:n===1?'neither':count===2?'prime':'composite'});
 });
}
const commonTimeFixtures={'4,6':12,'3,5':15,'2,3':6,'3,4':12,'2,5':10,'4,8':8};
const commonDivisorFixtures={'12,18':[1,2,3,6],'8,12':[1,2,4],'9,12':[1,3],'10,15':[1,5],'6,9':[1,3]};
const commonCutFixtures={'12,18':6,'8,12':4,'9,12':3,'10,15':5,'6,9':3,'4,6':2,'6,8':2,'4,10':2};
function solveCommon(b,t){
 const timing=params=>{const all=t.kind==='multiples',lists=params.periods.map((p,i)=>Array.from({length:Math.floor((params.horizon-(params.starts?.[i]??0))/p)+1},(_,j)=>(params.starts?.[i]??0)+j*p)),overlap=lists[0].filter(x=>x>0&&x>(params.after??0)&&lists[1].includes(x)),chosen=all?overlap:overlap.slice(0,1),end=all?params.horizon:chosen[0];if(!chosen.length)throw Error('No timing overlap');lists.forEach((list,i)=>{for(const x of list.slice(1))if(x<=end)b.click('commonTick',{index:String(i)})});chosen.forEach(time=>b.click('commonTime',{value:String(time)}))};
 const cutting=params=>{const best=Array.from({length:Math.min(...params.dims)},(_,i)=>i+1).filter(n=>params.dims.every(v=>v%n===0)).at(-1);b.click('commonCutSize',{value:String(best)});b.click('commonTile');b.click('commonBest');if(params.unitSize)for(let n=0;n<best*params.unitSize;n++)b.click('commonCutAmount',{delta:'1'});for(let size=best+1;size<=Math.min(...params.dims);size++){b.click('commonCutSize',{value:String(size)});b.click('commonTile')}};
 if(['multiples','least'].includes(t.kind))timing(t);
 if(t.kind==='divisors')for(const size of Array.from({length:Math.min(...t.numbers)},(_,i)=>i+1).filter(n=>t.numbers.every(v=>v%n===0))){b.click('commonGroupSize',{value:String(size)});b.click('commonSplit');b.click('commonCollect')}
 if(t.kind==='greatest')cutting(t);
 if(t.kind==='contexts'){timing(t.bells);b.click('commonSection',{index:'1'});cutting(t.paper);b.click('commonGoal',{index:'0',value:'least'});b.click('commonGoal',{index:'1',value:'greatest'})}
}
function solveCycle(b,t){
 solvePrediction(b,t);
 if(t.mode==='groupingLab'){solveGrouping(b,t);return}
 if(t.mode==='patternLab'){solvePattern(b,t);return}
 if(t.kind==='power'&&t.target===0){b.click('cycleZeroConfirm');b.click('cycleZeroChoice',{value:'1'});return}
 let length=t.base?.length;
 if(t.kind==='power'){for(let i=0;i<t.period+1;i++){b.click('cycleMultiply');b.click('cycleUnits');b.click('cycleCommit')}b.click('cyclePeriod',{value:String(t.period)});b.click('cycleMake');length=t.period}
 for(let i=0;i<Math.floor(t.target/length);i++)b.click('cycleRound');for(let i=0;i<t.target%length;i++)b.click('cycleAdvance');
 b.click('cycleChoice',{value:String(t.kind==='weekday'?((t.start+(t.direction||1)*t.target)%length+length)%length:t.indexBase===0?t.target%length:(t.target-1)%length+1)});
}
const measureRearrangeFixtures={'O-G01-05-1':[[0,0],[0,1],[0,2],[0,3],[1,0],[1,1],[1,2],[1,3],[2,0],[2,1],[3,0],[3,1]],'T-G01-05-1':[[0,0],[0,1],[0,2],[0,3],[1,0],[1,1],[1,2],[1,3]],'T-G01-05-2':[[0,0],[0,1],[0,2],[0,3],[1,0],[1,1]],'T-G01-05-3':[[0,0],[0,1],[0,2],[1,0],[2,0],[3,0],[3,1],[3,2]],'T-G01-05-4':[[0,0],[0,1],[0,2],[0,3],[1,0],[1,1],[1,2],[1,3],[2,2],[2,3],[3,2],[3,3]]};
function measureOuterOracle(cells){const set=new Set(cells.map(p=>p.join(','))),edges=[];for(const [r,c] of cells){if(!set.has((r-1)+','+c))edges.push('h,'+r+','+c);if(!set.has((r+1)+','+c))edges.push('h,'+(r+1)+','+c);if(!set.has(r+','+(c-1)))edges.push('v,'+r+','+c);if(!set.has(r+','+(c+1)))edges.push('v,'+r+','+(c+1))}return edges}
const {solveMeasure}=require('./test_solutions');
const {solveAngle}=require('./test_solutions');
const compositePlacements={'O-G03-01-1':[[2,0]],'T-G03-01-1':[[2,0],[0,1]],'T-G03-01-2':[[2,0]],'T-G03-01-3':[[0,1]],'T-G03-01-4':[[1,0]]};
function solveComposite(b,t){
 const answer=(value,index)=>{for(let n=0;n<value;n++)b.click('compositeAnswer',{...(index===undefined?{}:{index:String(index)}),delta:'1'})};
 if(['union','move'].includes(t.kind)){
  (t.puzzles||[t]).forEach((p,i)=>{const [r,c]=t.kind==='union'?compositePlacements[t.id][i]:p.destination;for(let row=p.start[0];row!==r;row+=Math.sign(r-p.start[0]))b.click('compositeMove',{index:String(i),dr:String(Math.sign(r-p.start[0])),dc:'0'});for(let col=p.start[1];col!==c;col+=Math.sign(c-p.start[1]))b.click('compositeMove',{index:String(i),dr:'0',dc:String(Math.sign(c-p.start[1]))});answer(p.fixed.length+p.piece.length,i)});
  if(t.kind==='move')b.click('compositeInvariant',{value:'area'});
 }
 if(t.kind==='cut'){for(const [r,c] of t.remove)b.click('compositeCut',{row:String(r),col:String(c)});answer(t.rows*t.cols-t.remove.length)}
 if(t.kind==='squares'){for(const size of t.sizes){b.click('compositeSize',{value:String(size)});for(let r=0;r<=t.rows-size;r++)for(let c=0;c<=t.cols-size;c++){b.click('compositePreview',{row:String(r),col:String(c)});b.click('compositeRecord')}}answer(t.sizes.reduce((n,size)=>n+(t.rows-size+1)*(t.cols-size+1),0))}
}
function solveCircle(b,t){
 const amount=(value,group,key,index)=>{for(let n=0;n<Math.floor(value);n++)b.click('circleAmount',{group,key,...(index===undefined?{}:{index:String(index)}),delta:'1'});for(let n=Math.floor(value);n<value;n+=.25)b.click('circleAmount',{group,key,...(index===undefined?{}:{index:String(index)}),delta:'0.25'})};
 const unit=(value,group,index)=>b.click('circleUnit',{group,value,...(index===undefined?{}:{index:String(index)})});
 if(t.kind==='center'){b.click('circleOrigin',{value:t.centerName||'O'});for(let i=0;i<t.points.length;i++)b.click('circleRay',{index:String(i)})}
 if(t.kind==='radii'){for(const end of ['A','B']){b.click('circleVertex',{value:'O'});b.click('circleVertex',{value:end});b.click('circleConnect')}b.click('circleJoin');amount(t.answerTarget==='radius'?t.radius:t.radius*2,'main','answer');unit('cm','main')}
 if(t.kind==='walk')(t.routes||[t]).forEach((r,i)=>{for(let n=0;n<r.targetSteps;n++)b.click('circleWalk',{index:String(i)});if(r.includeDiameter)b.click('circleDiameter',{index:String(i)});amount(2*r.radius*r.targetSteps/r.parts,'routes','coeff',i);if(r.includeDiameter)amount(2*r.radius,'routes','constant',i);unit('cm','routes',i)});
 if(t.kind==='area'){t.radii.forEach((r,i)=>{for(let part=0;part<t.parts;part++)b.click('circlePiece',{index:String(i),part:String(part)});amount(r*r,'areas','coeff',i);unit('cm2','areas',i)});if(t.compare)for(let n=0;n<t.radii[1]**2/t.radii[0]**2;n++)b.click('circleRatio',{delta:'1'})}
 if(t.kind==='arc'){for(let i=0;i<t.count;i++)b.click('circleArc',{group:'main',index:'0',part:String((t.start+i)%t.parts)});for(let n=0;n<t.count;n++)b.click('circleFraction',{key:'numerator',delta:'1'});for(let n=1;n<t.parts;n++)b.click('circleFraction',{key:'denominator',delta:'1'});amount(t.totalCirc*t.count/t.parts,'main','answer');unit('cm','main')}
 if(t.kind==='objects'){for(let i=0;i<t.count;i++){const part=String((t.start+i)%t.parts);b.click('circleArc',{group:'objects',index:'0',part});b.click('circleSector',{index:'1',part})}amount(2*t.radius*t.count/t.parts,'objects','coeff',0);unit('cm','objects',0);amount(t.radius**2*t.count/t.parts,'objects','coeff',1);unit('cm2','objects',1)}
}
function solveSimilar(b,t){
 const answer=value=>{for(let n=0;n<Math.floor(value);n++)b.click('similarAnswer',{delta:'1'});for(let n=Math.floor(value);n<value;n+=.25)b.click('similarAnswer',{delta:'0.25'})};
 if(t.kind==='correspond'){
  for(let i=0;i<t.points.length;i++){for(const side of ['source','target'])b.click('similarPoint',{side,index:String(i)});b.click('similarLink')}
  for(const side of ['source','target'])for(const [kind,index] of [['Edge',t.edgeIndex],['Angle',t.angleIndex]])b.click('similarMark',{side,kind,index:String(index)});
  return;
 }
 const x=t.kind==='inverse'?t.newWidth/t.width:t.goalX,y=t.kind==='inverse'?x:t.goalY;
 for(const [axis,target] of (x===y?[['both',x]]:[['x',x],['y',y]]))for(let k=1;k!==target;k+=.5*Math.sign(target-1))b.click('similarScale',{axis,delta:String(.5*Math.sign(target-1))});
 if(t.kind==='resize')b.click('similarChoice',{value:x===y?'similar':'different'});
 if(t.kind==='perimeter'){for(const [side,count] of [['source',2*(t.width+t.height)],['target',2*(t.width*x+t.height*y)]])for(let i=0;i<count;i++)b.click('similarTrace',{side});answer(x)}
 if(t.kind==='area'){for(const [side,width,height] of [['source',t.width,t.height],['target',t.width*x,t.height*y]])for(let r=0;r<height;r++)for(let c=0;c<width;c++)if(side==='source'||!(t.remove||[]).some(p=>p[0]===r&&p[1]===c))b.click('similarCell',{side,row:String(r),col:String(c)});answer((t.width*x*t.height*y-(t.remove||[]).length)/(t.width*t.height))}
 if(t.kind==='inverse')answer(x);
}
function solveRight(b,t,cornerChoice){
 const amount=(key,value)=>{for(let n=0;n<Math.floor(value);n++)b.click('rightAmount',{key,delta:'1'});for(let n=Math.floor(value);n<value;n+=.25)b.click('rightAmount',{key,delta:'0.25'})};
 if(t.kind==='condition'){
  t.cards.forEach((card,i)=>{b.click('rightPick',{card:String(i),index:String(card.corner)});for(const index of [card.corner,(card.corner+2)%3])b.click('rightEdge',{card:String(i),index:String(index)});b.click('rightChoice',{card:String(i),value:card.givenAngle===90?'yes':'no'})});return;
 }
 if(['squares','solve'].includes(t.kind)){b.click('rightPick',{card:'0',index:'0'});for(const index of [0,2])b.click('rightEdge',{card:'0',index:String(index)})}
 if(['axis','diagonal'].includes(t.kind))for(const role of ['A','B']){b.click('rightActive',{value:role});b.click('rightPoint',{x:String(t[role][0]),y:String(t[role][1])})}
 if(t.kind==='axis'){const dx=Math.sign(t.B[0]-t.A[0]),dy=Math.sign(t.B[1]-t.A[1]),n=Math.abs(t.B[0]-t.A[0])+Math.abs(t.B[1]-t.A[1]);for(let i=0;i<n;i++)b.click('rightStep',{dx:String(dx),dy:String(dy)});amount('answer',n);return}
 if(t.kind==='diagonal'){const C=cornerChoice||[t.B[0],t.A[1]];b.click('rightActive',{value:'C'});b.click('rightPoint',{x:String(C[0]),y:String(C[1])});b.click('rightJoin');for(const [index,p,q] of [[0,t.A,C],[1,C,t.B]])for(let n=0;n<Math.abs(p[0]-q[0])+Math.abs(p[1]-q[1]);n++)b.click('rightMeasure',{index:String(index)})}
 const unknown=t.kind==='squares'?'c':t.unknown,target=t[unknown]/t.unit;
 if(t.kind!=='squares')for(let n=1;n<target;n++)b.click('rightSize',{delta:'1'});
 const material=(t.unknown&&t.unknown!=='c'?['c']:['a','b']).flatMap(key=>{const n=t[key]/t.unit;return Array.from({length:n},(_,r)=>Array.from({length:n},(_,c)=>`${key}-${r}-${c}`)).flat()}),deduct=t.unknown&&t.unknown!=='c'?t[t.unknown==='a'?'b':'a']/t.unit:0;
 let at=0;for(const [zone,n] of [['deduct',deduct],['target',target]])for(let r=0;r<n;r++)for(let c=0;c<n;c++){b.click('rightTile',{id:material[at++]});b.click('rightSlot',{zone,row:String(r),col:String(c)})}
 if(t.kind==='squares')for(const key of ['a','b','c'])amount(key,t[key]**2);else amount('answer',t[unknown]);
}
function solveSolid(b,t){
 const geom=require('./solid_geometry'),views=()=>{for(let i=0;i<8;i++)b.click('solidTurn',{delta:'1'});b.click('solidFlip');for(let i=0;i<8;i++)b.click('solidTurn',{delta:'1'})},amount=(index,value)=>{for(let n=0;n<Math.floor(value);n++)b.click('solidAmount',{index:String(index),delta:'1'});for(let n=Math.floor(value);n<value;n+=.125)b.click('solidAmount',{index:String(index),delta:'0.125'})};
 if(t.nets){
  t.nets.forEach((net,index)=>{for(const node of geom.solidNetTree(net).nodes.slice(1))for(let k=0;k<3;k++)b.click('solidFold',{index:String(index),id:node.id,delta:'30'})});views();
  t.nets.forEach((net,index)=>{const a=geom.solidAnalysis(net,geom.solidFullAngles(net)),data={index:String(index)};
   if(t.kind==='valid')b.click('solidValidity',{...data,value:a.valid?'valid':'invalid'});
   if(t.kind==='counts'){for(const id of Object.keys(a.frames))b.click('solidFace',{...data,side:'solid',id});for(const key of ['edges','vertices'])for(const id of Object.keys(a[key]))b.click('solidObject',{...data,key,id});for(const [key,count] of [['faces',6],['edges',12],['vertices',8]])for(let n=0;n<count;n++)b.click('solidCount',{...data,key,delta:'1'})}
   if(t.kind==='match')for(const id of Object.keys(a.frames)){b.click('solidFace',{...data,side:'net',id});b.click('solidFace',{...data,side:'solid',id})}
   if(t.kind==='opposite')for(const id of t.asked){b.click('solidFace',{...data,side:'solid',id});b.click('solidFace',{...data,side:'solid',id:Object.keys(a.frames).find(other=>geom.solidDot(a.frames[id].n,a.frames[other].n)<-.999)})}
  });return;
 }
 t.solids.forEach((model,index)=>{for(const z of [...new Set(model.cells.map(p=>p[2]))]){b.click('solidSlice',{index:String(index),value:String(z)});for(const [x,y,k] of model.cells.filter(p=>p[2]===z))b.click('solidCell',{index:String(index),x:String(x),y:String(y),z:String(k)})}});views();
 t.solids.forEach((model,index)=>{const faces=geom.solidSurface(model.cells);if(t.kind==='surface'){b.click('solidMode',{index:String(index),value:'inspect'});for(const cell of model.cells){const id=cell.join(',');b.click('solidInspect',{index:String(index),id});for(const face of faces.filter(f=>f.cell.join(',')===id))b.click('solidSurface',{index:String(index),side:face.side})}}amount(index,t.kind==='volume'?model.cells.length*t.unit**3:faces.length*t.unit**2);b.click('solidUnit',{index:String(index),value:t.kind==='volume'?'volume':'area'})});
 if(t.compare){const values=t.solids.map(model=>t.kind==='volume'?model.cells.length:geom.solidSurface(model.cells).length);b.click('solidCompare',{value:values.every(v=>v===values[0])?'equal':'different'})}
}
function solveSets(b,t){
 const belongs=(p,key)=>key==='U'||key===p.group||key==='A'&&['R','O'].includes(p.group)||key==='B'&&['Y','O'].includes(p.group)||key==='I'&&p.group!=='N'||key==='exact1'&&['R','Y'].includes(p.group)||key==='notA'&&['Y','N'].includes(p.group)||key==='notB'&&['R','N'].includes(p.group),amount=(key,value,row)=>{for(let n=0;n<value;n++)b.click('setsAmount',{key,...(row===undefined?{}:{row:String(row)}),delta:'1'})},apply=(row,key,sign=1)=>b.click('setsApply',{row:String(row),key,sign:String(sign)});
 for(const p of t.people)for(const flag of (p.group==='N'?['N']:p.group==='O'?['A','B']:p.group==='R'?['A']:['B']))b.click('setsRegister',{id:p.id,flag});
 for(const p of t.people){b.click('setsActor',{id:p.id});b.click('setsPlace',{zone:p.group})}
 for(const key of t.queries||[]){b.click('setsQuery',{key});const members=t.people.filter(p=>belongs(p,key));if(members.length)for(const p of members)b.click('setsActor',{id:p.id});else b.click('setsEmpty')}
 const target=t.target||'U',expected=t.people.filter(p=>belongs(p,target)).length;
 if(['identity','universe','partition'].includes(t.kind))amount('answer',expected);
 if(t.kind==='partition')for(const key of t.countKeys)amount(key,t.people.filter(p=>p.group===key).length);
 if(t.kind==='formula'){for(const key of ['R','O','Y'])apply(0,key);for(const key of ['A','Y'])apply(1,key);for(const row of [0,1])amount('answer',expected,row)}
 if(t.kind==='complement'){apply(0,'U');if(target==='notA')apply(0,'A',-1);else if(target==='notB')apply(0,'B',-1);else{apply(0,'O');apply(0,'A',-1);apply(0,'B',-1)}amount('answer',expected,0)}
 if(t.kind==='twoWays'){if(target==='I'){apply(0,'A');apply(0,'B');apply(0,'O',-1);apply(1,'U');apply(1,'N',-1)}else if(target==='N'){apply(0,'N');apply(1,'U');apply(1,'O');apply(1,'A',-1);apply(1,'B',-1)}else{for(const key of [target==='notA'?'Y':'R','N'])apply(0,key);apply(1,'U');apply(1,target==='notA'?'A':'B',-1)}for(const row of [0,1])amount('answer',expected,row)}
 if(t.kind==='dedup'){for(const key of ['A','B'])b.click('setsAddList',{key});for(const p of t.people.filter(p=>p.group==='O'))b.click('setsTrim',{id:p.id});amount('answer',expected)}
}
function solveCombin(b,t){const {combinAll,combinRule}=require('./combin_ui');t.models.forEach((m,index)=>{const data={index:String(index)};for(let i=0;i<(m.seed||[]).length;i++)b.click('combinDelete',{...data,id:'R'+(i+1)});for(const tuple of combinAll(m)){b.click('combinBin',{...data,id:tuple[0]});tuple.forEach((id,slot)=>{b.click('combinSlot',{...data,slot:String(slot)});b.click('combinCard',{...data,id,...(m.type==='pair'?{list:String(slot)}:{})})});b.click('combinRecord',data)}for(let n=0;n<combinAll(m).length;n++)b.click('combinAmount',{...data,delta:'1'});if(t.kind==='orderMeaning')b.click('combinOrder',{...data,value:m.ordered?'yes':'no'})});if(t.kind==='rule')b.click('combinRule',{value:combinRule(t)})}

function solveChart(b,t){const {chartIntervals,chartQualifies,chartDuration}=require('./chart_ui');const amount=(index,n)=>{if(n===0)b.click('chartAmount',{index:String(index),delta:'0'});for(const d of [100,10,5,1])while(n>=d){b.click('chartAmount',{index:String(index),delta:String(d)});n-=d}};if(t.kind==='legend')for(let r=0;r<t.icons.length;r++)for(let i=0;i<Math.ceil(t.icons[r]);i++){const id=r+':'+i;b.click('chartIcon',{id});for(let k=0;k<t.legend*Math.min(1,t.icons[r]-i);k++){b.click('chartDot',{id:id+':'+k});b.click('chartPlace',{row:String(r)})}}if(t.kind==='ticks')for(let i=1;i<t.ticks.length-1;i++){b.click('chartTick',{index:String(i)});b.click('chartScale',{value:String(t.ticks[i])})}else if(t.kind==='interval'){const ids=chartIntervals(t).filter(p=>chartQualifies(t,p)).map(p=>p.id);if(ids.length)for(const id of ids)b.click('chartInterval',{id});else b.click('chartEmpty');let n=chartDuration(t,ids);while(n>=1){b.click('chartTime',{delta:'1'});n--}if(n)b.click('chartTime',{delta:'0.5'})}else{t.values.forEach((v,i)=>{b.click('chartCategory',{index:String(i)});if(t.kind==='read'||t.kind==='convert'&&t.direction==='read')b.click('chartMark',{index:String((v-t.ticks[0])/t.gap)});if(t.kind==='build'||t.kind==='convert'&&t.direction==='build'){for(let k=0;k<(v-t.ticks[0])/t.gap;k++)b.click('chartBlock',{delta:'1'});if(v===t.ticks[0])b.click('chartZero')}amount(i,v)})}if(t.kind!=='ticks')b.click('chartUnit',{value:t.unit})}

function solveStats(b,t){const {statsObservations,statsSummary,statsUnits}=require('./stats_ui'),obs=statsObservations(t),sum=statsSummary(t),amount=(key,n)=>{for(const d of [10,5,1,0.5])while(n>=d){b.click('statsAmount',{key,delta:String(d)});n-=d}};if(['balance','mean','weighted'].includes(t.kind)){if(t.kind==='weighted')t.rows.forEach((r,row)=>b.click('statsExpand',{row:String(row)}));const units=obs.flatMap(p=>statsUnits(t,p)),per=sum.mean/t.quantum;units.forEach((id,i)=>{b.click('statsDot',{id});b.click('statsPlace',{row:String(Math.floor(i/per))})});amount('total',sum.total);amount('denominator',sum.n);amount('answer',sum.mean)}else if(t.kind==='modeRange'){for(const p of obs){b.click('statsCard',{id:p.id});b.click('statsGroup',{value:String(p.value)})}for(const value of sum.modes)b.click('statsModeValue',{value:String(value)});if(!sum.modes.length)b.click('statsNoMode');for(const value of sum.ends)b.click('statsEnd',{value:String(value)});amount('range',sum.range)}else{const sorted=[...obs].sort((a,c)=>t.direction==='desc'?c.value-a.value:a.value-c.value);sorted.forEach((p,slot)=>{b.click('statsCard',{id:p.id});b.click('statsSlot',{slot:String(slot)})});if(t.kind==='median'){b.click('statsWorkMode',{value:'middle'});for(const p of sum.n%2?[sorted[(sum.n-1)/2]]:[sorted[sum.n/2-1],sorted[sum.n/2]])b.click('statsCard',{id:p.id});amount('answer',sum.median)}}}

function solveChance(b,t){const {chanceOutcomes,chanceFavorable,chanceCertainty,chanceLabelEqual,chanceCompare}=require('./chance_ui');t.models.forEach((m,index)=>{const data={index:String(index)},all=chanceOutcomes(m);all.forEach((tuple,i)=>{tuple.forEach((id,slot)=>b.click('chanceAtom',{...data,slot:String(slot),id}));b.click('chanceRecord',data);if(['certainty','favorable','two','weighted'].includes(t.kind)&&chanceFavorable(m,tuple))b.click('chanceFavor',{...data,id:'R'+(i+1)})});const favorable=all.filter(p=>chanceFavorable(m,p)).length;if(['certainty','favorable','two','weighted'].includes(t.kind)&&!favorable)b.click('chanceEmpty',data);if(['favorable','two','weighted'].includes(t.kind))for(const [key,n] of [['numerator',favorable],['denominator',all.length]])for(let k=0;k<n;k++)b.click('chanceAmount',{...data,key,delta:'1'});if(t.kind==='certainty')b.click('chanceChoice',{...data,key:'certainty',value:chanceCertainty(m)});if(t.kind==='equal'){b.click('chanceChoice',{...data,key:'basic',value:'yes'});b.click('chanceChoice',{...data,key:'labels',value:chanceLabelEqual(m)?'yes':'no'})}if(t.kind==='weighted')b.click('chanceChoice',{...data,key:'compare',value:chanceCompare(m)})})}

function solveMotion(b,t){const {motionFinal,motionPaperExpected,motionArea}=require('./motion_ui');if(t.kind==='fold'){for(const id of motionPaperExpected(t))b.click('motionHole',{id});b.click('motionLock');for(const f of t.folds)b.click('motionFold',{axis:f.axis,from:f.from});for(const [x,y] of t.cuts)b.click('motionCut',{x:String(x),y:String(y)});for(const f of t.folds)b.click('motionUnfold');return}for(const p of motionFinal(t)){b.click('motionSelect',{id:p.id});b.click('motionPlace',{x:String(p.x),y:String(p.y)})}b.click('motionLock');let axisValue=0,dx=0,dy=0;for(const step of t.steps){if(step.type==='reflect'){b.click('motionAxis',{value:step.axis});while(axisValue!==step.value){const delta=Math.sign(step.value-axisValue);b.click('motionAdjust',{key:'axisValue',delta:String(delta)});axisValue+=delta}}else if(step.type==='rotate'){b.click('motionGridMode',{value:'centre'});b.click('motionPlace',{x:String(step.cx),y:String(step.cy)});b.click('motionDirection',{value:step.direction});b.click('motionAngle',{value:String(step.angle)})}else{for(const [key,target] of [['dx',step.dx],['dy',step.dy]]){let value=key==='dx'?dx:dy;while(value!==target){const delta=Math.sign(target-value);b.click('motionAdjust',{key,delta:String(delta)});value+=delta}if(key==='dx')dx=value;else dy=value}}b.click('motionApply',{type:step.type})}if(t.kind!=='axis')b.click('motionOrientation',{value:motionArea(t.points)*motionArea(motionFinal(t))>0?'same':'changed'})}

function solveInvariant(b,t){const lib=require('./invariant_ui');if(t.kind==='filter'){for(const tuple of lib.invariantAll(t.items)){tuple.forEach((id,slot)=>{b.click('invariantCard',{id});b.click('invariantSlot',{slot:String(slot)})});const failed=t.conditions.filter(c=>!lib.invariantCondition(c,tuple)).map(c=>c.id);b.click('invariantClass',{value:failed.length?'reject':'keep'});for(const id of failed)b.click('invariantFailed',{id});b.click('invariantRecord')}return}let state=lib.invariantInitial(t),states=[state];const run=ids=>{for(const id of ids)b.click('invariantCoin',{id});b.click('invariantRun');state=lib.invariantStep(t.rule,state,ids);states.push(state)};if(t.kind==='legal'){for(const ids of t.attempts){for(const id of ids)b.click('invariantCoin',{id});b.click('invariantPredictLegal',{value:lib.invariantLegal(t.rule,state,ids)?'legal':'illegal'});b.click('invariantRun');state=lib.invariantStep(t.rule,state,ids)}return}let reachable=false;if(t.kind==='proof'){const node=lib.invariantReachable(t).get(t.goal.join(','));reachable=!!node;if(reachable)for(const ids of node.path)run(ids)}if(t.kind!=='proof'||!reachable)for(let i=0;i<t.minOps;i++)run(lib.invariantChoices(t.rule,state)[0]);if(t.kind==='parity'){for(const [side,s] of [['initial',states[0]],['current',state]]){b.click('invariantPairSide',{value:side});const red=lib.invariantRed(s);for(let i=0;i+1<red.length;i+=2){for(const id of red.slice(i,i+2))b.click('invariantPairCoin',{id});b.click('invariantBindPair')}if(red.length%2){b.click('invariantPairCoin',{id:red.at(-1)});b.click('invariantSingle')}else b.click('invariantNoSingle');b.click('invariantParity',{value:red.length%2?'odd':'even'})}return}for(const [row,s] of states.entries()){for(const [key,n] of [['total',s.order.length],['red',lib.invariantRed(s).length]])for(let i=0;i<n;i++)b.click('invariantLedger',{row:String(row),key,delta:'1'});b.click('invariantLedgerParity',{row:String(row),value:lib.invariantRed(s).length%2?'odd':'even'})}if(t.kind==='proof'){b.click('invariantVerdict',{value:reachable?'reachable':'unreachable'});b.click('invariantProof',{value:reachable?'path':t.rule==='swapAdjacent'?'count':'parity'})}if(t.kind==='invariant'||!reachable){lib.invariantProbes(t.rule).forEach((p,row)=>{for(const id of p.before.order)b.click('invariantProbeCoin',{row:String(row),id});b.click('invariantProbeRun',{row:String(row)});const after=lib.invariantStep(t.rule,p.before,p.before.order);b.click('invariantProbeDelta',{row:String(row),value:String(lib.invariantRed(after).length-lib.invariantRed(p.before).length)})});for(const value of lib.invariantQuantities(t.rule))b.click('invariantQuantity',{value})}}

function solveStage(b,t){
 if(['counterBuild','compareBuild','reverseExchange','forwardExchange','placeCompose','tenFill','counterRemove','counterChange','inverseMove','equalGroups','orderGroups'].includes(t.mode))solveFoundation(b,t);
 else if(t.mode==='objectSort')for(const index of t.answer)b.click('sortObject',{index:String(index)});
 else if(t.mode==='fractionLab'){
  const tap=(side,n)=>{for(let i=0;i<n;i++)b.click('fractionCell',{side,index:String(i)})};
  if(['shade','decimal'].includes(t.kind))tap('left',t.target);
  if(['compare','equal'].includes(t.kind)){tap('left',t.targetLeft);tap('right',t.targetRight);b.click('fractionChoice',{value:t.correctChoice|| (t.kind==='equal'?'equal':'left')})}
  if(t.kind==='decimal')b.click('fractionChoice',{value:t.correctChoice});
  if(t.kind==='line')b.click('fractionMark',{index:String(t.target)});
  if(t.kind==='remainder'){if(t.requireBasisSelection)b.click('fractionReference',{value:t.answerBasis||'original'});for(let i=0;i<t.first;i++)b.click('fractionPiece',{index:String(i)});b.click('fractionPhase');for(let i=t.first;i<t.first+t.second;i++)b.click('fractionPiece',{index:String(i)});if(t.correctChoice)b.click('fractionChoice',{value:t.correctChoice})}
 }
 else if(t.mode==='integerLab')solveInteger(b,t);
 else if(t.mode==='ratioLab')solveRatio(b,t);
 else if(t.mode==='rateLab')solveRate(b,t);
 else if(t.mode==='journeyLab')solveJourney(b,t);
 else if(t.mode==='scaleLab')solveScale(b,t);
 else if(t.mode==='equationLab')solveEquation(b,t);
 else if(t.mode==='constraintLab')solveConstraint(b,t);
 else if(t.mode==='patternLab')solvePattern(b,t);
 else if(t.mode==='coordinateLab')solveCoordinate(b,t);
 else if(t.mode==='groupingLab')solveGrouping(b,t);
 else if(t.mode==='factorLab')solveFactor(b,t);
 else if(t.mode==='commonLab')solveCommon(b,t);
 else if(t.mode==='cycleLab')solveCycle(b,t);
 else if(t.mode==='measureLab')solveMeasure(b,t);
 else if(t.mode==='angleLab')solveAngle(b,t);
 else if(t.mode==='compositeLab')solveComposite(b,t);
 else if(t.mode==='circleLab')solveCircle(b,t);
 else if(t.mode==='similarLab')solveSimilar(b,t);
 else if(t.mode==='rightLab')solveRight(b,t);
 else if(t.mode==='solidLab')solveSolid(b,t);
 else if(t.mode==='combinLab')solveCombin(b,t);
 else if(t.mode==='chartLab')solveChart(b,t);
 else if(t.mode==='statsLab')solveStats(b,t);
 else if(t.mode==='chanceLab')solveChance(b,t);
 else if(t.mode==='motionLab')solveMotion(b,t);
 else if(t.mode==='invariantLab')solveInvariant(b,t);
 else if(t.mode==='setsLab')solveSets(b,t);
 else solvePercent(b,t);
 b.click('check');assert.equal(microLatest(b).gradingResult,'correct',t.id+' authored answer '+JSON.stringify(microLatest(b).operationSummary));
}
for(const [sid,tasks] of Object.entries(STAGED_TASKS)){
 stageRun.click('micro',{code:sid});
 stageRun.click('stage',{code:sid+'|independent'});
 assert(stageRun.root.innerHTML.includes('同一微技能的后续题'),'independent cannot open before transfer');
 stageRun.click('stage',{code:sid+'|transfer'});assert(stageRun.root.innerHTML.includes(tasks.transfer.changeDimension));
 solveStage(stageRun,tasks.transfer);
 let attempt=microLatest(stageRun);assert.equal(attempt.stageKind,'transfer');assert.equal(attempt.changeDimension,tasks.transfer.changeDimension);
 stageRun.click('next');assert(stageRun.root.innerHTML.includes('它能联系到哪里？'));stageRun.click('stage',{code:sid+'|independent'});assert(stageRun.root.innerHTML.includes(tasks.independent.prompt));assert(!stageRun.root.innerHTML.includes('data-action="hint"'));
 solveStage(stageRun,tasks.independent);
 attempt=microLatest(stageRun);assert.equal(attempt.stageKind,'independent');assert.equal(attempt.independent,true);
 const cleanAt=microState(stageRun).skillStage[sid].cleanIndependentAt;
 assert.equal(cleanAt,stageClock.now);
 stageRun.click('next');stageRun.click('stage',{code:sid+'|independent2'});
 solveStage(stageRun,tasks.independent2);assert.equal(microState(stageRun).skillStage[sid].cleanInstances.length,2,'second clean instance stays reachable after first success');
 stageRun.click('next');stageRun.click('stage',{code:sid+'|delayed'});
 assert(stageRun.root.innerHTML.includes('回访新实例尚未到期'),'delayed instance stays locked');
 stageClock.now+=24*60*60*1000;
 stageRun.click('stage',{code:sid+'|delayed'});assert(stageRun.root.innerHTML.includes(tasks.delayed.prompt));
 solveStage(stageRun,tasks.delayed);assert.equal(microLatest(stageRun).stageKind,'delayed');
 assert.equal(microState(stageRun).skillStage[sid].delayedFirstCorrect,true);
 stageRun.click('next');
}
const stageRetryClock={now:Date.now()},stageRetry=boot({},false,stageRetryClock),retryTasks=STAGED_TASKS['A01.01'];
stageRetry.click('micro',{code:'A01.01'});stageRetry.click('stage',{code:'A01.01|transfer'});solveStage(stageRetry,retryTasks.transfer);
stageRetry.click('next');stageRetry.click('stage',{code:'A01.01|independent'});const distractor=0;
stageRetry.click('workAdd');stageRetry.click('check');assert.equal(microLatest(stageRetry).gradingResult,'incorrect');
for(let n=1;n<retryTasks.independent.target;n++)stageRetry.click('workAdd');
stageRetry.click('check');assert.equal(microLatest(stageRetry).independent,false);
assert.equal(microState(stageRetry).skillStage['A01.01'].cleanIndependentAt||0,0,'corrected same instance is not clean');
stageRetry.click('micro',{code:'A01.01'});stageRetry.click('stage',{code:'A01.01|delayed'});assert(stageRetry.root.innerHTML.includes('同一微技能的后续题'));
stageRetry.click('stage',{code:'A01.01|independent2'});solveStage(stageRetry,retryTasks.independent2);
assert.equal(microState(stageRetry).skillStage['A01.01'].cleanTaskId,retryTasks.independent2.id);
stageRetry.click('next');stageRetryClock.now+=24*60*60*1000;stageRetry.click('stage',{code:'A01.01|delayed'});assert(stageRetry.root.innerHTML.includes('同一微技能的后续题'),'one clean backup does not satisfy two-success rule');
const stageReload=boot(stageRetry.storage,false,stageRetryClock);stageReload.click('micro',{code:'A01.01'});stageReload.click('stage',{code:'A01.01|delayed'});assert(stageReload.root.innerHTML.includes('同一微技能的后续题'),'one clean backup remains one after reload');
const priorV10={storageVersion:2,contentRevision:10,courses:{A03:{frontier:8,cursor:8}},skillStage:{'A03.01':{transferPassed:true,independentTried:true,cleanIndependentAt:stageRetryClock.now-24*60*60*1000,cleanTaskId:STAGED_TASKS['A03.01'].independent.id}}};
const carryV10=boot({tianle_amc8_question_design_v1:JSON.stringify(priorV10)},false,stageRetryClock);
carryV10.click('micro',{code:'A03.01'});carryV10.click('stage',{code:'A03.01|delayed'});
assert(carryV10.root.innerHTML.includes('同一微技能的后续题'),'legacy single-clean flag cannot satisfy revised two-instance rule');
assert.equal(microState(carryV10).courses.A03.frontier,8,'new A04 content does not reset completed A03 route');
const fractionStageRetry=boot(),fractionStages=STAGED_TASKS['A03.07'];
fractionStageRetry.click('micro',{code:'A03.07'});fractionStageRetry.click('stage',{code:'A03.07|transfer'});solveStage(fractionStageRetry,fractionStages.transfer);
fractionStageRetry.click('next');fractionStageRetry.click('stage',{code:'A03.07|independent'});for(let i=0;i<10;i++)fractionStageRetry.click('fractionPiece',{index:String(i)});
fractionStageRetry.click('fractionPhase');for(let i=10;i<15;i++)fractionStageRetry.click('fractionPiece',{index:String(i)});
fractionStageRetry.click('fractionChoice',{value:'1/2'});fractionStageRetry.click('check');assert.equal(microLatest(fractionStageRetry).gradingResult,'incorrect');
fractionStageRetry.click('fractionChoice',{value:'1/4'});fractionStageRetry.click('check');assert.equal(microLatest(fractionStageRetry).gradingResult,'correct');
assert.equal(microState(fractionStageRetry).skillStage['A03.07'].cleanIndependentAt||0,0,'fraction answer corrected on same instance does not become clean independent evidence');
fractionStageRetry.click('micro',{code:'A03.07'});fractionStageRetry.click('stage',{code:'A03.07|independent2'});assert(fractionStageRetry.root.innerHTML.includes(fractionStages.independent2.prompt),'fresh fallback is available after wrong fraction answer');
const delayedFixture=microState(stageRun);delayedFixture.attempts=delayedFixture.attempts.filter(a=>a.taskInstanceId!==retryTasks.delayed.id);delete delayedFixture.taskHistory[retryTasks.delayed.contentVersion+':'+retryTasks.delayed.id];delayedFixture.skillStage['A01.01'].reviewInstances=[];delayedFixture.skillStage['A01.01'].delayedFirstCorrect=false;delayedFixture.skillStage['A01.01'].delayedTried=false;
const delayedWrong=boot({tianle_amc8_question_design_v1:JSON.stringify(delayedFixture)},false,stageClock);delayedWrong.click('micro',{code:'A01.01'});delayedWrong.click('stage',{code:'A01.01|delayed'});
const delayedDistractor=0;
delayedWrong.click('workAdd');delayedWrong.click('check');
for(let n=1;n<retryTasks.delayed.target;n++)delayedWrong.click('workAdd');
delayedWrong.click('check');assert.equal(microState(delayedWrong).skillStage['A01.01'].delayedFirstCorrect,false,'corrected delayed instance never becomes a clean delayed first answer');
const fractionRun=boot();
function fractionTap(b,side,n,start=0){for(let i=start;i<start+n;i++)b.click('fractionCell',{side,index:String(i)})}
for(const [sid,t] of Object.entries(FRACTION_TASKS)){
 fractionRun.click('fraction',{code:sid});assert(fractionRun.root.innerHTML.includes(t.prompt),sid+' opens fraction lab');
 const before=fractionRun.storage.tianle_amc8_question_design_v1?microState(fractionRun).attempts.length:0;
 fractionRun.click('check');assert.equal(fractionRun.storage.tianle_amc8_question_design_v1?microState(fractionRun).attempts.length:0,before,'empty lab cannot log');
 if(['shade','decimal'].includes(t.kind))fractionTap(fractionRun,'left',t.target);
 if(['compare','equal'].includes(t.kind)){fractionTap(fractionRun,'left',t.targetLeft);fractionTap(fractionRun,'right',t.targetRight)}
 if(t.kind==='compare')fractionRun.click('fractionChoice',{value:'left'});
 if(t.kind==='equal')fractionRun.click('fractionChoice',{value:'equal'});
 if(t.kind==='decimal')fractionRun.click('fractionChoice',{value:'0.7'});
 if(t.kind==='line')fractionRun.click('fractionMark',{index:String(t.target)});
 if(t.kind==='remainder'){
  for(let i=0;i<t.first;i++)fractionRun.click('fractionPiece',{index:String(i)});
  fractionRun.click('fractionPhase');
  for(let i=t.first;i<t.first+t.second;i++)fractionRun.click('fractionPiece',{index:String(i)});
 }
 fractionRun.click('check');assert(fractionRun.root.innerHTML.includes('先说一说你的理由'),sid+' reason required');
 fractionRun.click('reason',{index:String(t.reason.answer)});fractionRun.click('check');
 const attempt=microLatest(fractionRun);assert.equal(attempt.taskInstanceId,t.id);assert.deepEqual(attempt.skillIds,[sid]);assert.equal(attempt.gradingResult,'correct');
 assert(attempt.operationSummary.work.moves>0&&attempt.explanationEvidence.correct,sid+' real state and reason recorded');
 fractionRun.click('next');
}
const fractionWrong=boot();fractionWrong.click('fraction',{code:'A03.04'});
fractionWrong.click('fractionCell',{side:'left',index:'3'});
assert(fractionWrong.root.innerHTML.includes('aria-label="第1个等份，未涂色"'),'cannot jump across fractional pieces');
fractionTap(fractionWrong,'left',2);fractionTap(fractionWrong,'right',2);fractionWrong.click('fractionChoice',{value:'equal'});fractionWrong.click('reason',{index:'0'});fractionWrong.click('check');
assert.equal(microLatest(fractionWrong).gradingResult,'incorrect','2/4 and 2/6 are not equivalent in same-size wholes');
fractionWrong.click('fractionCell',{side:'right',index:'2'});fractionWrong.click('reason',{index:'0'});fractionWrong.click('check');
assert.equal(microLatest(fractionWrong).independent,false,'correcting same fraction task does not create a new first response');
const remainderWrong=boot();remainderWrong.click('fraction',{code:'A03.07'});
for(let i=0;i<6;i++)remainderWrong.click('fractionPiece',{index:String(i)});
remainderWrong.click('fractionPhase');remainderWrong.click('fractionPiece',{index:'0'});
assert(remainderWrong.root.innerHTML.includes('第二次拿0块'),'cannot take already removed piece again');
remainderWrong.click('fractionPiece',{index:'6'});remainderWrong.click('fractionReset');
assert(remainderWrong.root.innerHTML.includes('第一次拿0块'),'reset restores original whole');
const beforeResetCheck=remainderWrong.storage.tianle_amc8_question_design_v1?microState(remainderWrong).attempts.length:0;
remainderWrong.click('check');assert.equal(remainderWrong.storage.tianle_amc8_question_design_v1?microState(remainderWrong).attempts.length:0,beforeResetCheck,'reset does not create an operation attempt');
const percentRun=boot();
for(const [sid,t] of Object.entries(PERCENT_TASKS)){
 percentRun.click('percent',{code:sid});assert(percentRun.root.innerHTML.includes(t.prompt));
 const before=percentRun.storage.tianle_amc8_question_design_v1?microState(percentRun).attempts.length:0;
 percentRun.click('check');assert.equal(percentRun.storage.tianle_amc8_question_design_v1?microState(percentRun).attempts.length:0,before,'empty percent model cannot submit');
 if(t.kind==='shade')for(let i=0;i<t.target;i++)percentRun.click('percentCell',{index:String(i)});
 if(t.kind==='whole')for(let i=0;i<t.copies;i++)percentRun.click('percentCopy');
 if(t.kind==='change')solvePercent(percentRun,t);
 if(t.kind==='estimate')for(const [side,initial,target] of [['a',t.a,t.targetA],['b',t.b,t.targetB]])for(let i=initial;i!==target;i+=Math.sign(target-initial))percentRun.click('percentAdjust',{side,delta:String(Math.sign(target-initial))});
 percentRun.click('percentChoice',{value:t.correctChoice});percentRun.click('check');assert(percentRun.root.innerHTML.includes('先说一说你的理由'));
 percentRun.click('reason',{index:String(t.reason.answer)});percentRun.click('check');
 const attempt=microLatest(percentRun);assert.equal(attempt.taskInstanceId,t.id);assert.deepEqual(attempt.skillIds,[sid]);assert.equal(attempt.gradingResult,'correct');
 assert(attempt.operationSummary.work.moves>0&&attempt.explanationEvidence.correct);percentRun.click('next');
}
const integerRun=boot();
for(const [sid,t] of Object.entries(INTEGER_TASKS)){
 integerRun.click('integer',{code:sid});assert(integerRun.root.innerHTML.includes(t.prompt));
 const before=integerRun.storage.tianle_amc8_question_design_v1?microState(integerRun).attempts.length:0;
 integerRun.click('check');assert.equal(integerRun.storage.tianle_amc8_question_design_v1?microState(integerRun).attempts.length:0,before,'empty integer model cannot submit');
 solveInteger(integerRun,t);integerRun.click('check');assert(integerRun.root.innerHTML.includes('先说一说你的理由'));
 integerRun.click('reason',{index:'0'});integerRun.click('check');
 const attempt=microLatest(integerRun);assert.equal(attempt.taskInstanceId,t.id);assert.equal(attempt.gradingResult,'correct');assert(attempt.operationSummary.work.moves>0&&attempt.explanationEvidence.correct);integerRun.click('next');
}
const crossingWrong=boot();crossingWrong.click('integer',{code:'A05.03'});
for(let i=0;i<6;i++)crossingWrong.click('integerStep',{delta:'1'});crossingWrong.click('integerStep',{delta:'-1'});crossingWrong.click('reason',{index:'0'});crossingWrong.click('check');
assert.equal(microLatest(crossingWrong).gradingResult,'incorrect','detour must not count as exact crossing distance');
const squareWrong=boot();squareWrong.click('integer',{code:'A05.04'});for(let i=0;i<3;i++)squareWrong.click('integerRow',{delta:'1'});squareWrong.click('reason',{index:'0'});squareWrong.click('check');assert.equal(microLatest(squareWrong).gradingResult,'incorrect','three rows cannot count as four-by-four square');
const ratioRun=boot();for(const [sid,t] of Object.entries(RATIO_TASKS)){
 ratioRun.click('ratio',{code:sid});assert(ratioRun.root.innerHTML.includes(t.prompt));
 const before=ratioRun.storage.tianle_amc8_question_design_v1?microState(ratioRun).attempts.length:0;ratioRun.click('check');assert.equal(ratioRun.storage.tianle_amc8_question_design_v1?microState(ratioRun).attempts.length:0,before,'empty ratio model cannot submit');
 solveRatio(ratioRun,t);ratioRun.click('check');assert(ratioRun.root.innerHTML.includes('先说一说你的理由'));ratioRun.click('reason',{index:'0'});ratioRun.click('check');
 const a=microLatest(ratioRun);assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);ratioRun.click('next');
}
const oneSide=boot();oneSide.click('ratio',{code:'R01.04'});oneSide.click('ratioCopy',{side:'red'});oneSide.click('ratioCopy',{side:'red'});oneSide.click('reason',{index:'0'});oneSide.click('check');assert.equal(microLatest(oneSide).gradingResult,'incorrect','scaling only one color is not proportional');
const wrongWhole=boot();wrongWhole.click('ratio',{code:'R01.03'});for(let i=0;i<2;i++)wrongWhole.click('ratioAdd',{side:'red',delta:'1'});for(let i=0;i<3;i++)wrongWhole.click('ratioAdd',{side:'blue',delta:'1'});wrongWhole.click('ratioChoice',{value:'2/3'});wrongWhole.click('reason',{index:'0'});wrongWhole.click('check');assert.equal(microLatest(wrongWhole).gradingResult,'incorrect','red:blue cannot substitute red:whole');
const rateRun=boot();for(const [sid,t] of Object.entries(RATE_TASKS)){
 rateRun.click('rate',{code:sid});assert(rateRun.root.innerHTML.includes(t.prompt));
 const before=rateRun.storage.tianle_amc8_question_design_v1?microState(rateRun).attempts.length:0;rateRun.click('check');assert.equal(rateRun.storage.tianle_amc8_question_design_v1?microState(rateRun).attempts.length:0,before,'empty rate model cannot submit');
 solveRate(rateRun,t);rateRun.click('check');assert(rateRun.root.innerHTML.includes('先说一说你的理由'));rateRun.click('reason',{index:'0'});rateRun.click('check');
 const a=microLatest(rateRun);assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);rateRun.click('next');
}
const rateWrong=boot();rateWrong.click('rate',{code:'R02.03'});for(let i=0;i<6;i++)rateWrong.click('rateMove',{side:'a',index:String(i%3)});for(let i=0;i<8;i++)rateWrong.click('rateMove',{side:'b',index:String(i%2)});rateWrong.click('rateChoice',{value:'b'});rateWrong.click('reason',{index:'0'});rateWrong.click('check');assert.equal(microLatest(rateWrong).gradingResult,'incorrect','total price comparison must not replace per-unit comparison');
const rateUneven=boot();rateUneven.click('rate',{code:'R02.01'});for(let i=0;i<8;i++)rateUneven.click('rateMove',{side:'main',index:String(i<3?0:(i-3)%3+1)});rateUneven.click('reason',{index:'0'});rateUneven.click('check');assert.equal(microLatest(rateUneven).gradingResult,'incorrect','unequal allocation is not a unit price');
const journeyRun=boot();for(const [sid,t] of Object.entries(JOURNEY_TASKS)){
 journeyRun.click('journey',{code:sid});assert(journeyRun.root.innerHTML.includes(t.prompt));
 const before=journeyRun.storage.tianle_amc8_question_design_v1?microState(journeyRun).attempts.length:0;journeyRun.click('check');assert.equal(journeyRun.storage.tianle_amc8_question_design_v1?microState(journeyRun).attempts.length:0,before,'empty journey model cannot submit');
 solveJourney(journeyRun,t);journeyRun.click('check');assert(journeyRun.root.innerHTML.includes('先说一说你的理由'));
 journeyRun.click('reason',{index:'0'});journeyRun.click('check');
 const a=microLatest(journeyRun);assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);journeyRun.click('next');
}
const jointOnlyOne=boot();jointOnlyOne.click('journey',{code:'R03.05'});for(let i=0;i<2;i++)jointOnlyOne.click('journeyWorker',{side:'a'});jointOnlyOne.click('reason',{index:'0'});jointOnlyOne.click('check');assert.equal(jointOnlyOne.storage.tianle_amc8_question_design_v1?microState(jointOnlyOne).attempts.length:0,0,'only one worker cannot count as both workers in the same minute');
const jointUndo=boot();jointUndo.click('journey',{code:'R03.05'});jointUndo.click('journeyWorker',{side:'b'});jointUndo.click('journeyWorker',{side:'a'});jointUndo.click('journeyUndo');assert(jointUndo.root.innerHTML.includes('已摆 2 个'),'undo removes the latest worker only');
const wrongRemainder=boot();wrongRemainder.click('journey',{code:'R03.04'});wrongRemainder.click('journeyStep');wrongRemainder.click('journeyStep');wrongRemainder.click('journeyChoice',{value:'5'});wrongRemainder.click('reason',{index:'0'});wrongRemainder.click('check');assert.equal(microLatest(wrongRemainder).gradingResult,'incorrect','walked part cannot substitute the remainder');
const overshoot=boot();overshoot.click('journey',{code:'R03.02'});for(let i=0;i<5;i++)overshoot.click('journeyStep');overshoot.click('reason',{index:'0'});overshoot.click('check');assert.equal(microLatest(overshoot).gradingResult,'incorrect','walking past the target cannot count as correct elapsed time');
const scaleRun=boot();for(const [sid,t] of Object.entries(SCALE_TASKS)){
 scaleRun.click('scale',{code:sid});assert(scaleRun.root.innerHTML.includes(t.prompt));
 const before=scaleRun.storage.tianle_amc8_question_design_v1?microState(scaleRun).attempts.length:0;
 scaleRun.click('check');assert.equal(scaleRun.storage.tianle_amc8_question_design_v1?microState(scaleRun).attempts.length:0,before,'empty scale model cannot submit');
 solveScale(scaleRun,t);scaleRun.click('check');assert(scaleRun.root.innerHTML.includes('先说一说你的理由'));
 scaleRun.click('reason',{index:'0'});scaleRun.click('check');const a=microLatest(scaleRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 scaleRun.click('next');
}
const oneColor=boot();oneColor.click('scale',{code:'R04.01'});oneColor.click('scaleCopy',{side:'red'});oneColor.click('reason',{index:'0'});oneColor.click('check');assert.equal(microLatest(oneColor).gradingResult,'incorrect','one color cannot count as equal scaling');
oneColor.click('scaleUndo');assert(oneColor.root.innerHTML.includes('红 2 朵'),'undo restores the first group');
const oneAxis=boot();oneAxis.click('scale',{code:'R04.03'});oneAxis.click('scaleAxis',{side:'rows'});oneAxis.click('reason',{index:'0'});oneAxis.click('check');assert.equal(microLatest(oneAxis).gradingResult,'incorrect','one axis alone does not quadruple area');
const newBase=boot();newBase.click('scale',{code:'R04.05'});for(let i=0;i<20;i++)newBase.click('percentAdd');newBase.click('percentPhase');for(let i=0;i<20;i++)newBase.click('percentRemove');newBase.click('percentChoice',{value:'100'});newBase.click('reason',{index:'0'});newBase.click('check');assert.equal(microLatest(newBase).gradingResult,'incorrect','second percentage must use 120 as base');
const equationRun=boot();for(const [sid,t] of Object.entries(EQUATION_TASKS)){
 equationRun.click('equation',{code:sid});assert(equationRun.root.innerHTML.includes(t.prompt));
 const before=equationRun.storage.tianle_amc8_question_design_v1?microState(equationRun).attempts.length:0;
 equationRun.click('check');assert.equal(equationRun.storage.tianle_amc8_question_design_v1?microState(equationRun).attempts.length:0,before,'empty equation model cannot submit');
 solveEquation(equationRun,t);equationRun.click('check');assert(equationRun.root.innerHTML.includes('先说一说你的理由'));
 equationRun.click('reason',{index:'0'});equationRun.click('check');const a=microLatest(equationRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 equationRun.click('next');
}
const onePan=boot();onePan.click('equation',{code:'L01.01'});onePan.click('equationTerm',{side:'left',index:'0'});onePan.click('equationTerm',{side:'left',index:'1'});onePan.click('reason',{index:'0'});onePan.click('check');assert.equal(microLatest(onePan).gradingResult,'incorrect','one pan cannot establish equality');
const leftOnly=boot();leftOnly.click('equation',{code:'L01.03'});for(let i=0;i<3;i++)leftOnly.click('equationLeftTake');for(let i=0;i<4;i++)leftOnly.click('equationBag');leftOnly.click('reason',{index:'0'});leftOnly.click('check');assert.equal(microLatest(leftOnly).gradingResult,'incorrect','one-sided removal cannot preserve equality');
leftOnly.click('equationUndo');assert(leftOnly.root.innerHTML.includes('袋内已摆 3颗'),'undo returns the last placed unit');
const notIsolated=boot();notIsolated.click('equation',{code:'L01.02'});for(let i=0;i<4;i++)notIsolated.click('equationBag');notIsolated.click('reason',{index:'0'});notIsolated.click('check');assert.equal(microLatest(notIsolated).gradingResult,'incorrect','guessing bag size without both-side operation cannot count');
const wrongInverse=boot();wrongInverse.click('equation',{code:'L01.04'});for(let i=0;i<5;i++)wrongInverse.click('equationRemove');wrongInverse.click('reason',{index:'0'});wrongInverse.click('check');assert.equal(microLatest(wrongInverse).gradingResult,'incorrect','removed amount must leave exactly five');
const partialSubstitution=boot();partialSubstitution.click('equation',{code:'L01.05'});for(let i=0;i<4;i++)partialSubstitution.click('equationBag');partialSubstitution.click('reason',{index:'0'});partialSubstitution.click('check');assert.equal(microLatest(partialSubstitution).gradingResult,'incorrect','bag alone does not verify the original equality');
const constraintRun=boot();for(const [sid,t] of Object.entries(CONSTRAINT_TASKS)){
 constraintRun.click('constraint',{code:sid});assert(constraintRun.root.innerHTML.includes(t.prompt));
 const before=constraintRun.storage.tianle_amc8_question_design_v1?microState(constraintRun).attempts.length:0;
 constraintRun.click('check');assert.equal(constraintRun.storage.tianle_amc8_question_design_v1?microState(constraintRun).attempts.length:0,before,'empty constraint model cannot submit');
 solveConstraint(constraintRun,t);constraintRun.click('check');assert(constraintRun.root.innerHTML.includes('先说一说你的理由'));
 constraintRun.click('reason',{index:'0'});constraintRun.click('check');const a=microLatest(constraintRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 constraintRun.click('next');
}
const skippedInner=boot();skippedInner.click('constraint',{code:'L02.01'});skippedInner.click('constraintDivide');skippedInner.click('reason',{index:'0'});skippedInner.click('check');assert.equal(microLatest(skippedInner).gradingResult,'incorrect','dividing alone does not remove the added amount inside every group');
const oneBagOnly=boot();oneBagOnly.click('constraint',{code:'L02.02'});for(let i=0;i<5;i++)oneBagOnly.click('constraintFill');oneBagOnly.click('reason',{index:'0'});oneBagOnly.click('check');assert.equal(microLatest(oneBagOnly).gradingResult,'incorrect','bag value alone does not verify grouped bracket');
const parityGuess=boot();parityGuess.click('constraint',{code:'L02.03'});parityGuess.click('constraintPair');parityGuess.click('constraintChoose',{value:'impossible'});parityGuess.click('reason',{index:'0'});parityGuess.click('check');assert.equal(microLatest(parityGuess).gradingResult,'incorrect','integer conclusion requires pairing all available groups');
const unprobed=boot();unprobed.click('constraint',{code:'L02.04'});unprobed.click('constraintPack');unprobed.click('constraintPack');unprobed.click('reason',{index:'0'});unprobed.click('check');assert.equal(microLatest(unprobed).gradingResult,'incorrect','must establish that the next bag exceeds stock');
const optimalGuess=boot();optimalGuess.click('constraint',{code:'L02.05'});optimalGuess.click('constraintTrial',{value:'2'});optimalGuess.click('constraintChoose',{value:'2'});optimalGuess.click('reason',{index:'0'});optimalGuess.click('check');assert.equal(microLatest(optimalGuess).gradingResult,'incorrect','choosing a feasible count alone does not establish maximality');
const trialUndo=boot();trialUndo.click('constraint',{code:'L02.05'});trialUndo.click('constraintTrial',{value:'3'});trialUndo.click('constraintUndo');assert(trialUndo.root.innerHTML.includes('比较最多可行方案与紧邻的不可行方案。'),'undo restores the untested state');
for(const t of [...Object.values(ANGLE_TASKS),...Object.values(COMPOSITE_TASKS),...Object.values(CIRCLE_TASKS),...Object.values(SIMILAR_TASKS),...Object.values(RIGHT_TASKS),...Object.values(SOLID_TASKS),...Object.values(SETS_TASKS),...Object.values(INVARIANT_TASKS),...Object.values(MOTION_TASKS),...Object.values(CHANCE_TASKS),...Object.values(STATS_TASKS),...Object.values(CHART_TASKS),...Object.values(COMBIN_TASKS),...Object.values(STAGED_TASKS).flatMap(Object.values)].filter(t=>t.mode==='angleLab')){
 if(['triangle','conditions'].includes(t.kind)){const points=angleTrianglePoints(t.angles);for(let i=0;i<3;i++){const a=points[(i+1)%3].map((v,k)=>v-points[i][k]),b=points[(i+2)%3].map((v,k)=>v-points[i][k]),degrees=Math.acos((a[0]*b[0]+a[1]*b[1])/(Math.hypot(...a)*Math.hypot(...b)))*180/Math.PI;assert(Math.abs(degrees-t.angles[i])<1e-8,t.id+' actual drawn corner '+i+' agrees with marked angle')}}
 if(t.kind==='polygon'){const p=anglePolygonPoints(t),cross=(a,b)=>a[0]*b[1]-a[1]*b[0],area=Math.abs(p.reduce((sum,v,i)=>sum+cross(v,p[(i+1)%p.length]),0))/2;const ordered=Array.from({length:t.sides},(_,i)=>p[(t.anchor+i)%t.sides]),triangles=Array.from({length:t.sides-2},(_,i)=>[ordered[0],ordered[i+1],ordered[i+2]]),total=triangles.reduce((sum,[a,b,c])=>sum+Math.abs(cross(b.map((v,k)=>v-a[k]),c.map((v,k)=>v-a[k])))/2,0);assert(Math.abs(total-area)<1e-7,t.id+' fan triangles cover polygon without overlap or missing area')}
}
const angleRun=boot();for(const [sid,t] of Object.entries(ANGLE_TASKS)){
 angleRun.click('micro',{code:sid});assert(angleRun.root.innerHTML.includes('data-action="angle"'));
 angleRun.click('angle',{code:sid});assert(angleRun.root.innerHTML.includes(t.prompt));
 const before=angleRun.storage.tianle_amc8_question_design_v1?microState(angleRun).attempts.length:0;
 angleRun.click('check');assert.equal(angleRun.storage.tianle_amc8_question_design_v1?microState(angleRun).attempts.length:0,before,'empty angle model cannot submit');
 solveAngle(angleRun,t);angleRun.click('check');assert(angleRun.root.innerHTML.includes('先说一说你的理由'));
 angleRun.click('reason',{index:'0'});angleRun.click('check');const a=microLatest(angleRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 angleRun.click('next');assert(angleRun.root.innerHTML.includes('它能联系到哪里？'));
}
const chordArm=boot();chordArm.click('angle',{code:'G02.01'});for(let i=0;i<4;i++)chordArm.click('angleRotate',{delta:'15'});chordArm.click('angleArm',{value:'AB'});chordArm.click('angleArm',{value:'BC'});chordArm.click('reason',{index:'0'});chordArm.click('check');assert.equal(microLatest(chordArm).gradingResult,'incorrect','chord BC is not a ray from the common vertex');
const resizeAngle=boot();resizeAngle.click('stage',{code:'G02.01|transfer'});solveAngle(resizeAngle,STAGED_TASKS['G02.01'].transfer);resizeAngle.click('check');assert.equal(microLatest(resizeAngle).operationSummary.work.angle,60);assert.equal(microLatest(resizeAngle).operationSummary.work.resized,true);assert.deepEqual(microLatest(resizeAngle).operationSummary.work.lengths,[85,110],'angle measure stays constant despite actual ray-length changes');
const fullOnBoth=boot();fullOnBoth.click('angle',{code:'G02.02'});for(let i=0;i<2;i++)for(let a=0;a<360;a+=30)fullOnBoth.click('angleTurn',{index:String(i)});fullOnBoth.click('reason',{index:'0'});fullOnBoth.click('check');assert.equal(microLatest(fullOnBoth).gradingResult,'incorrect','full turn cannot stand in for the requested half turn');assert.equal(microLatest(fullOnBoth).operationSummary.work.turns[1].path.at(-1),360,'full-turn path retains 360 rather than normalizing to zero');
const twoAngles=boot();twoAngles.click('angle',{code:'G02.03'});for(const i of [0,1])twoAngles.click('anglePiece',{index:String(i)});for(let a=0;a<70;a+=5)twoAngles.click('angleAnswer',{delta:'5'});twoAngles.click('reason',{index:'0'});twoAngles.click('check');assert.equal(microLatest(twoAngles).gradingResult,'incorrect','right number does not replace moving all three corner pieces');
const justPolySum=boot();justPolySum.click('angle',{code:'G02.04'});for(let i=0;i<3;i++){justPolySum.click('angleTriangles',{delta:'1'});justPolySum.click('angleTotal',{delta:'180'})}justPolySum.click('reason',{index:'0'});justPolySum.click('check');assert.equal(microLatest(justPolySum).gradingResult,'incorrect','count and angle sum need the actual specified fan partition');
const adjacentLine=boot();adjacentLine.click('angle',{code:'G02.04'});adjacentLine.click('angleVertex',{index:'0'});adjacentLine.click('angleVertex',{index:'1'});adjacentLine.click('angleConnect');adjacentLine.click('reason',{index:'0'});adjacentLine.click('check');assert.equal(microLatest(adjacentLine).operationSummary.work.diagonals.length,0,'polygon side is not a dividing diagonal');
const crossingFans=boot();crossingFans.click('angle',{code:'G02.04'});for(const [a,b] of [[0,2],[1,3]]){crossingFans.click('angleVertex',{index:String(a)});crossingFans.click('angleVertex',{index:String(b)});crossingFans.click('angleConnect')}for(let i=0;i<3;i++){crossingFans.click('angleTriangles',{delta:'1'});crossingFans.click('angleTotal',{delta:'180'})}crossingFans.click('reason',{index:'0'});crossingFans.click('check');assert.equal(microLatest(crossingFans).gradingResult,'incorrect','crossing diagonals from different vertices are not the requested nonoverlapping fan');
const visualGuess=boot();visualGuess.click('angle',{code:'G02.05'});solveAngle(visualGuess,ANGLE_TASKS['G02.05']);visualGuess.click('angleCondition',{value:'longest'});visualGuess.click('reason',{index:'0'});visualGuess.click('check');assert.equal(microLatest(visualGuess).gradingResult,'incorrect','correct numeric answer cannot replace reading only the marked conditions');
const angleUndo=boot();angleUndo.click('angle',{code:'G02.03'});solveAngle(angleUndo,ANGLE_TASKS['G02.03']);for(let i=0;i<14;i++)angleUndo.click('angleUndo');angleUndo.click('angleUndo');angleUndo.click('reason',{index:'0'});angleUndo.click('check');assert.equal(microLatest(angleUndo).operationSummary.work.pieces.length,2,'undo returns the last angle piece to the source');
const angleBackup=boot({tianle_amc8_question_design_v1:JSON.stringify({storageVersion:2,contentRevision:release.contentRevision,skillStage:Object.fromEntries(Object.keys(ANGLE_TASKS).map(sid=>[sid,{transferPassed:true,independentTried:true}]))})});for(const sid of Object.keys(ANGLE_TASKS)){angleBackup.click('stage',{code:sid+'|independent2'});solveStage(angleBackup,STAGED_TASKS[sid].independent2);assert.equal(microLatest(angleBackup).independent,true);angleBackup.click('next')}
const angleVoice=boot({},true);angleVoice.click('angle',{code:'G02.05'});angleVoice.click('speakState');assert(angleVoice.spoken.at(-1).includes('A30度')&&angleVoice.spoken.at(-1).includes('C有直角标记')&&!angleVoice.spoken.at(-1).includes('B60度'),'speech reads known marks and retains the unknown angle');
assert.deepEqual(Object.values(measureRearrangeFixtures).map(cells=>measureOuterOracle(cells).length),[16,12,12,18,16],'authored free-placement fixtures have independently counted perimeters');
const measureRun=boot();for(const [sid,t] of Object.entries(MEASURE_TASKS)){
 measureRun.click('micro',{code:sid});assert(measureRun.root.innerHTML.includes('data-action="measure"'));
 measureRun.click('measure',{code:sid});assert(measureRun.root.innerHTML.includes(t.prompt));
 const before=measureRun.storage.tianle_amc8_question_design_v1?microState(measureRun).attempts.length:0;
 measureRun.click('check');assert.equal(measureRun.storage.tianle_amc8_question_design_v1?microState(measureRun).attempts.length:0,before,'empty measure model cannot submit');
 solveMeasure(measureRun,t);measureRun.click('check');assert(measureRun.root.innerHTML.includes('先说一说你的理由'));
 measureRun.click('reason',{index:'0'});measureRun.click('check');const a=microLatest(measureRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 if(t.kind==='rearrange')assert.equal(new Set(Object.values(a.operationSummary.work.tiles)).size,12,'same twelve physical tile IDs are used once each');
 measureRun.click('next');assert(measureRun.root.innerHTML.includes('它能联系到哪里？'));
}
const gapLength=boot();gapLength.click('measure',{code:'G01.01'});for(const i of [0,1,2,4])gapLength.click('measureSegment',{index:String(i)});gapLength.click('reason',{index:'0'});gapLength.click('check');assert.equal(microLatest(gapLength).gradingResult,'incorrect','four segments with a gap and overshoot do not cover the target length');
const insideEdge=boot();insideEdge.click('measure',{code:'G01.02'});solveMeasure(insideEdge,MEASURE_TASKS['G01.02']);insideEdge.click('measureEdge',{value:'h,0,0'});insideEdge.click('measureEdge',{value:'h,1,0'});insideEdge.click('reason',{index:'0'});insideEdge.click('check');assert.equal(microLatest(insideEdge).operationSummary.work.edges.length,10);assert.equal(microLatest(insideEdge).gradingResult,'incorrect','same edge count with an internal divider is not the perimeter');
const outsideArea=boot();outsideArea.click('stage',{code:'G01.03|transfer'});for(const [r,c] of STAGED_TASKS['G01.03'].transfer.cells.filter(([r,c])=>r!==0||c!==0))outsideArea.click('measureCell',{row:String(r),col:String(c)});outsideArea.click('measureCell',{row:'2',col:'2'});outsideArea.click('check');assert.equal(microLatest(outsideArea).operationSummary.work.covered.length,8);assert.equal(microLatest(outsideArea).gradingResult,'incorrect','same number of shaded tiles outside the target does not cover its area');
const wrongUnits=boot();wrongUnits.click('measure',{code:'G01.04'});solveMeasure(wrongUnits,MEASURE_TASKS['G01.04']);wrongUnits.click('measureUnit',{key:'areaUnit',value:'cm'});wrongUnits.click('reason',{index:'0'});wrongUnits.click('check');assert.equal(microLatest(wrongUnits).gradingResult,'incorrect','length unit cannot replace the square area unit');
function tryMeasureLayout(cells){const b=boot();b.click('measure',{code:'G01.05'});for(const [r,c] of cells)b.click('measureCell',{row:String(r),col:String(c)});b.click('measureTrace');for(const edge of measureOuterOracle(cells))b.click('measureEdge',{value:edge});for(const [key,n] of [['length',measureOuterOracle(cells).length],['area',cells.length]])for(let i=0;i<n;i++)b.click('measureAmount',{key,delta:'1'});b.click('reason',{index:'0'});b.click('check');return b}
const rotatedMeasure=tryMeasureLayout(Array.from({length:4},(_,r)=>Array.from({length:3},(_,c)=>[r,c])).flat());assert.equal(microLatest(rotatedMeasure).gradingResult,'incorrect','rotation alone preserves both area and perimeter');
const holeCells=Array.from({length:4},(_,r)=>Array.from({length:4},(_,c)=>[r,c])).flat().filter(([r,c])=>r===0||c===0||r===3||c===3);const holeMeasure=tryMeasureLayout(holeCells);assert.equal(microLatest(holeMeasure).gradingResult,'incorrect','explicit no-hole condition rejects the hollow layout even with twelve tiles');
const splitCells=Array.from({length:4},(_,r)=>Array.from({length:4},(_,c)=>[r,c])).flat().filter(([r,c])=>![[0,1],[1,0],[3,2],[3,3]].some(([a,b])=>a===r&&b===c));const splitMeasure=tryMeasureLayout(splitCells);assert.equal(microLatest(splitMeasure).gradingResult,'incorrect','isolated corner tile violates the connected-layout condition');
const anotherLayout=tryMeasureLayout(Array.from({length:4},(_,r)=>Array.from({length:4},(_,c)=>[r,c])).flat().filter(([r,c])=>![[0,0],[0,3],[3,0],[3,3]].some(([a,b])=>a===r&&b===c)));assert.equal(microLatest(anotherLayout).gradingResult,'correct','a different valid connected layout is accepted rather than only the test fixture');
const materialLimit=boot();materialLimit.click('measure',{code:'G01.05'});const fixture=measureRearrangeFixtures['O-G01-05-1'];for(const [r,c] of fixture)materialLimit.click('measureCell',{row:String(r),col:String(c)});materialLimit.click('measureCell',{row:'3',col:'3'});materialLimit.click('measureTrace');materialLimit.click('reason',{index:'0'});materialLimit.click('check');assert.equal(Object.keys(microLatest(materialLimit).operationSummary.work.tiles).length,12,'placing another tile cannot invent extra source material');materialLimit.click('measureRearrange');materialLimit.click('measureCell',{row:'0',col:'0'});materialLimit.click('measureUndo');materialLimit.click('check');assert.equal(Object.keys(microLatest(materialLimit).operationSummary.work.tiles).length,12,'undo returns removed source tile ID');
const measureBackup=boot({tianle_amc8_question_design_v1:JSON.stringify({storageVersion:2,contentRevision:release.contentRevision,skillStage:Object.fromEntries(Object.keys(MEASURE_TASKS).map(sid=>[sid,{transferPassed:true,independentTried:true}]))})});for(const sid of Object.keys(MEASURE_TASKS)){measureBackup.click('stage',{code:sid+'|independent2'});solveStage(measureBackup,STAGED_TASKS[sid].independent2);assert.equal(microLatest(measureBackup).independent,true);measureBackup.click('next')}
const measureVoice=boot({},true);measureVoice.click('measure',{code:'G01.01'});measureVoice.click('measureSegment',{index:'0'});measureVoice.click('speakState');assert(measureVoice.spoken.at(-1).includes('0到1厘米'));measureVoice.click('measure',{code:'G01.05'});measureVoice.click('measureCell',{row:'0',col:'0'});measureVoice.click('speakState');assert(measureVoice.spoken.at(-1).includes('待摆材料11格'));
const cycleRun=boot();for(const [sid,t] of Object.entries(CYCLE_TASKS)){
 cycleRun.click('micro',{code:sid});assert(cycleRun.root.innerHTML.includes('data-action="cycle"'));
 cycleRun.click('cycle',{code:sid});assert(cycleRun.root.innerHTML.includes(t.prompt));
 const before=cycleRun.storage.tianle_amc8_question_design_v1?microState(cycleRun).attempts.length:0;
 cycleRun.click('check');assert.equal(cycleRun.storage.tianle_amc8_question_design_v1?microState(cycleRun).attempts.length:0,before,'empty cycle model cannot submit');
 solveCycle(cycleRun,t);cycleRun.click('check');assert(cycleRun.root.innerHTML.includes('先说一说你的理由'));
 cycleRun.click('reason',{index:'0'});cycleRun.click('check');const a=microLatest(cycleRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 if(t.mode==='cycleLab'){assert.equal(a.operationSummary.work.steps,t.target);assert.equal(a.operationSummary.work.walk.length,t.target)}
 cycleRun.click('next');assert(cycleRun.root.innerHTML.includes('它能联系到哪里？'));
}
const zeroPosition=boot();zeroPosition.click('cycle',{code:'N04.06'});solveCycle(zeroPosition,CYCLE_TASKS['N04.06']);zeroPosition.click('cycleChoice',{value:'0'});zeroPosition.click('reason',{index:'0'});zeroPosition.click('check');assert.equal(microLatest(zeroPosition).gradingResult,'incorrect');assert.equal(microLatest(zeroPosition).operationSummary.work.cursor,4,'a whole-number of counted seat rounds stops on last seat');
const weekdayOff=boot();weekdayOff.click('cycle',{code:'N04.04'});solveCycle(weekdayOff,CYCLE_TASKS['N04.04']);weekdayOff.click('cycleChoice',{value:'4'});weekdayOff.click('reason',{index:'0'});weekdayOff.click('check');assert.equal(microLatest(weekdayOff).gradingResult,'incorrect','counting today as day one gives the wrong elapsed-day answer');
const chosenOnly=boot();chosenOnly.click('cycle',{code:'N04.03'});chosenOnly.click('cycleChoice',{value:'1'});chosenOnly.click('reason',{index:'0'});chosenOnly.click('check');assert.equal(microLatest(chosenOnly).gradingResult,'incorrect','correct position alone cannot replace the actual counted path');
const cycleOvershoot=boot();cycleOvershoot.click('cycle',{code:'N04.03'});cycleOvershoot.click('cycleRound');cycleOvershoot.click('cycleRound');cycleOvershoot.click('cycleRound');cycleOvershoot.click('cycleChoice',{value:'3'});cycleOvershoot.click('reason',{index:'0'});cycleOvershoot.click('check');assert.equal(microLatest(cycleOvershoot).operationSummary.work.steps,6,'whole round cannot overshoot target seven');
const cycleUndo=boot();cycleUndo.click('cycle',{code:'N04.03'});cycleUndo.click('cycleRound');cycleUndo.click('cycleUndo');cycleUndo.click('cycleChoice',{value:'1'});cycleUndo.click('reason',{index:'0'});cycleUndo.click('check');assert.equal(microLatest(cycleUndo).operationSummary.work.walk.length,0,'undo removes every step in the whole round');
const shortPowerPeriod=boot();shortPowerPeriod.click('cycle',{code:'N04.05'});for(let i=0;i<5;i++){shortPowerPeriod.click('cycleMultiply');shortPowerPeriod.click('cycleUnits');shortPowerPeriod.click('cycleCommit')}shortPowerPeriod.click('cyclePeriod',{value:'3'});shortPowerPeriod.click('cycleMake');shortPowerPeriod.click('cycleRound');shortPowerPeriod.click('cycleAdvance');shortPowerPeriod.click('cycleAdvance');shortPowerPeriod.click('cycleChoice',{value:'2'});shortPowerPeriod.click('reason',{index:'0'});shortPowerPeriod.click('check');assert.equal(microLatest(shortPowerPeriod).gradingResult,'incorrect','wrong period cannot be accepted even if a ring can be walked');
const missingPower=boot();missingPower.click('cycle',{code:'N04.05'});missingPower.click('cycleUnits');missingPower.click('cycleCommit');missingPower.click('cyclePeriod',{value:'4'});missingPower.click('cycleMake');missingPower.click('cycleRound');missingPower.click('check');assert(!missingPower.storage.tianle_amc8_question_design_v1||!microState(missingPower).attempts.length,'cannot use a hidden authored cycle without generating its digits');
const powerStrip=boot();powerStrip.click('cycle',{code:'N04.05'});for(let i=0;i<3;i++){powerStrip.click('cycleMultiply');powerStrip.click('cycleUnits');powerStrip.click('cycleCommit')}powerStrip.click('cycleMultiply');assert(powerStrip.root.innerHTML.includes('机器内 16'));powerStrip.click('cycleCommit');assert(powerStrip.root.innerHTML.includes('机器内 16'),'cannot record a two-digit product as its last digit');powerStrip.click('cycleUnits');assert(powerStrip.root.innerHTML.includes('机器内 6'));powerStrip.click('cycleCommit');powerStrip.click('reason',{index:'0'});powerStrip.click('check');assert.deepEqual(microLatest(powerStrip).operationSummary.work.generated,[2,4,8,6]);assert.deepEqual(microLatest(powerStrip).operationSummary.work.products,[2,4,8,16]);
const cycleBackup=boot({tianle_amc8_question_design_v1:JSON.stringify({storageVersion:2,contentRevision:release.contentRevision,skillStage:Object.fromEntries(Object.keys(CYCLE_TASKS).map(sid=>[sid,{transferPassed:true,independentTried:true}]))})});for(const sid of Object.keys(CYCLE_TASKS)){cycleBackup.click('stage',{code:sid+'|independent2'});solveStage(cycleBackup,STAGED_TASKS[sid].independent2);assert.equal(microLatest(cycleBackup).independent,true);cycleBackup.click('next')}
const cycleVoice=boot({},true);cycleVoice.click('cycle',{code:'N04.04'});cycleVoice.click('cycleAdvance');cycleVoice.click('speakState');assert(cycleVoice.spoken.at(-1).includes('已过1天')&&cycleVoice.spoken.at(-1).includes('星期二'));cycleVoice.click('cycle',{code:'N04.03'});cycleVoice.click('cycleAdvance');cycleVoice.click('speakState');assert(cycleVoice.spoken.at(-1).includes('已数1项')&&cycleVoice.spoken.at(-1).includes('周期第1位'));
const commonRun=boot();for(const [sid,t] of Object.entries(COMMON_TASKS)){
 commonRun.click('micro',{code:sid});assert(commonRun.root.innerHTML.includes('data-action="common"'));
 commonRun.click('common',{code:sid});assert(commonRun.root.innerHTML.includes(t.prompt));
 const before=commonRun.storage.tianle_amc8_question_design_v1?microState(commonRun).attempts.length:0;
 commonRun.click('check');assert.equal(commonRun.storage.tianle_amc8_question_design_v1?microState(commonRun).attempts.length:0,before,'empty common model cannot submit');
 solveCommon(commonRun,t);commonRun.click('check');assert(commonRun.root.innerHTML.includes('先说一说你的理由'));
 commonRun.click('reason',{index:'0'});commonRun.click('check');const a=microLatest(commonRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 if(['multiples','least'].includes(t.kind))a.operationSummary.work.timing.selected.forEach(time=>assert(time>0&&t.periods.every(p=>time%p===0)));
 commonRun.click('next');assert(commonRun.root.innerHTML.includes('它能联系到哪里？'));
}
const zeroNext=boot();zeroNext.click('common',{code:'N03.02'});solveCommon(zeroNext,COMMON_TASKS['N03.02']);zeroNext.click('commonTime',{value:'12'});zeroNext.click('commonTime',{value:'0'});zeroNext.click('reason',{index:'0'});zeroNext.click('check');assert.equal(microLatest(zeroNext).gradingResult,'incorrect','time zero is not the next positive overlap');
const laterNext=boot();laterNext.click('common',{code:'N03.02'});for(const [period,i] of [[4,0],[6,1]])for(let time=period;time<=24;time+=period)laterNext.click('commonTick',{index:String(i)});laterNext.click('commonTime',{value:'24'});laterNext.click('reason',{index:'0'});laterNext.click('check');assert.equal(microLatest(laterNext).gradingResult,'incorrect','a later common time does not satisfy next');
const oneLane=boot();oneLane.click('common',{code:'N03.01'});for(let time=4;time<=24;time+=4)oneLane.click('commonTick',{index:'0'});oneLane.click('commonTime',{value:'12'});oneLane.click('commonTime',{value:'24'});oneLane.click('reason',{index:'0'});oneLane.click('check');assert.equal(microLatest(oneLane).gradingResult,'incorrect','one timeline alone cannot prove common multiples');
const onlyOneDivides=boot();onlyOneDivides.click('common',{code:'N03.03'});onlyOneDivides.click('commonGroupSize',{value:'4'});onlyOneDivides.click('commonSplit');onlyOneDivides.click('commonCollect');onlyOneDivides.click('reason',{index:'0'});onlyOneDivides.click('check');const badCommon=microLatest(onlyOneDivides);assert.equal(badCommon.gradingResult,'incorrect');assert.deepEqual(badCommon.operationSummary.work.group.trials[0].remainders,[0,2]);assert.equal(badCommon.operationSummary.work.group.collected.length,0,'one divisible pool is not common');
const missingCommon=boot();missingCommon.click('common',{code:'N03.03'});for(const size of [1,2,6]){missingCommon.click('commonGroupSize',{value:String(size)});missingCommon.click('commonSplit');missingCommon.click('commonCollect')}missingCommon.click('reason',{index:'0'});missingCommon.click('check');assert.equal(microLatest(missingCommon).gradingResult,'incorrect','missing common divisor 3 prevents complete enumeration');
const uncheckedMaximum=boot();uncheckedMaximum.click('common',{code:'N03.04'});uncheckedMaximum.click('commonCutSize',{value:'6'});uncheckedMaximum.click('commonTile');uncheckedMaximum.click('commonBest');for(let size=7;size<12;size++){uncheckedMaximum.click('commonCutSize',{value:String(size)});uncheckedMaximum.click('commonTile')}uncheckedMaximum.click('reason',{index:'0'});uncheckedMaximum.click('check');assert.equal(microLatest(uncheckedMaximum).gradingResult,'incorrect','explicit proof requires testing all larger sizes through the shorter side');uncheckedMaximum.click('commonCutSize',{value:'12'});uncheckedMaximum.click('commonTile');uncheckedMaximum.click('check');assert.equal(microLatest(uncheckedMaximum).gradingResult,'correct');assert.equal(microLatest(uncheckedMaximum).independent,false,'corrected maximum proof does not become a new clean first answer');
const shortSideOnly=boot();shortSideOnly.click('common',{code:'N03.04'});shortSideOnly.click('commonCutSize',{value:'12'});shortSideOnly.click('commonTile');shortSideOnly.click('commonBest');shortSideOnly.click('reason',{index:'0'});shortSideOnly.click('check');assert.equal(microLatest(shortSideOnly).operationSummary.work.cut.selected,null,'12 divides width but cannot tile height 18');
const switchedGoals=boot();switchedGoals.click('common',{code:'N03.05'});solveCommon(switchedGoals,COMMON_TASKS['N03.05']);switchedGoals.click('commonGoal',{index:'0',value:'greatest'});switchedGoals.click('commonGoal',{index:'1',value:'least'});switchedGoals.click('reason',{index:'0'});switchedGoals.click('check');assert.equal(microLatest(switchedGoals).gradingResult,'incorrect','right arithmetic cannot compensate for swapping the story goals');
const commonUndo=boot();commonUndo.click('common',{code:'N03.02'});commonUndo.click('commonTick',{index:'0'});commonUndo.click('commonUndo');commonUndo.click('reason',{index:'0'});commonUndo.click('check');assert.deepEqual(microLatest(commonUndo).operationSummary.work.timing.marks,[[0],[0]],'undo returns generated time event');
const commonInvalid=boot();commonInvalid.click('common',{code:'N03.04'});commonInvalid.click('commonCutSize',{value:'0'});commonInvalid.click('commonCutSize',{value:'13'});commonInvalid.click('commonTile');commonInvalid.click('reason',{index:'0'});commonInvalid.click('check');assert.equal(microLatest(commonInvalid).operationSummary.work.cut.size,1);
const commonBackup=boot({tianle_amc8_question_design_v1:JSON.stringify({storageVersion:2,contentRevision:release.contentRevision,skillStage:Object.fromEntries(Object.keys(COMMON_TASKS).map(sid=>[sid,{transferPassed:true,independentTried:true}]))})});for(const sid of Object.keys(COMMON_TASKS)){commonBackup.click('stage',{code:sid+'|independent2'});solveStage(commonBackup,STAGED_TASKS[sid].independent2);assert.equal(microLatest(commonBackup).independent,true);commonBackup.click('next')}
const commonVoice=boot({},true);commonVoice.click('common',{code:'N03.02'});commonVoice.click('commonTick',{index:'0'});commonVoice.click('speakState');assert(commonVoice.spoken.at(-1).includes('甲时刻0、4')&&commonVoice.spoken.at(-1).includes('乙时刻0'));
const factorRun=boot();for(const [sid,t] of Object.entries(FACTOR_TASKS)){
 factorRun.click('micro',{code:sid});assert(factorRun.root.innerHTML.includes('data-action="factor"'));
 factorRun.click('factor',{code:sid});assert(factorRun.root.innerHTML.includes(t.prompt));
 const before=factorRun.storage.tianle_amc8_question_design_v1?microState(factorRun).attempts.length:0;
 factorRun.click('check');assert.equal(factorRun.storage.tianle_amc8_question_design_v1?microState(factorRun).attempts.length:0,before,'empty factor model cannot submit');
 solveFactor(factorRun,t);factorRun.click('check');assert(factorRun.root.innerHTML.includes('先说一说你的理由'));
 factorRun.click('reason',{index:'0'});factorRun.click('check');const a=microLatest(factorRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 a.operationSummary.work.cards.forEach((c,i)=>{assert(c.pairs.every(([x,y])=>x*y===t.numbers[i]));assert.equal(new Set(c.pairs.map(p=>p.join(','))).size,c.pairs.length);assert.equal(new Set(c.collected).size,c.collected.length)});
 factorRun.click('next');assert(factorRun.root.innerHTML.includes('它能联系到哪里？'));
}
const missingFactor=boot();missingFactor.click('factor',{code:'N02.02'});for(const [a,c] of [[1,12],[2,6]]){missingFactor.click('factorWidth',{value:String(c)});missingFactor.click('factorFill');missingFactor.click('factorRecord');for(const n of [a,c])missingFactor.click('factorCollect',{value:String(n)});missingFactor.click('factorClear')}missingFactor.click('reason',{index:'0'});missingFactor.click('check');assert.equal(microLatest(missingFactor).gradingResult,'incorrect','missing 3×4 prevents claiming all factors of 12');
const rotatedPair=boot();rotatedPair.click('factor',{code:'N02.01'});for(const width of [2,10]){rotatedPair.click('factorWidth',{value:String(width)});rotatedPair.click('factorFill');rotatedPair.click('factorRecord');rotatedPair.click('factorClear')}rotatedPair.click('reason',{index:'0'});rotatedPair.click('check');assert.equal(microLatest(rotatedPair).gradingResult,'incorrect');assert.equal(microLatest(rotatedPair).operationSummary.work.cards[0].pairs.length,1,'rotation is a duplicate pair');
const raggedRect=boot();raggedRect.click('factor',{code:'N02.01'});raggedRect.click('factorWidth',{value:'3'});raggedRect.click('factorFill');assert(raggedRect.root.innerHTML.includes('末行仍有缺格'));raggedRect.click('factorRecord');raggedRect.click('reason',{index:'0'});raggedRect.click('check');assert.equal(microLatest(raggedRect).operationSummary.work.cards[0].pairs.length,0,'a ragged 7-row shape is not a 3×7 rectangle of 20');
const oddPrime=boot();oddPrime.click('factor',{code:'N02.03'});solveFactor(oddPrime,FACTOR_TASKS['N02.03']);oddPrime.click('factorActive',{index:'2'});oddPrime.click('factorChoice',{value:'prime'});oddPrime.click('reason',{index:'0'});oddPrime.click('check');assert.equal(microLatest(oddPrime).gradingResult,'incorrect','odd composite 9 is not prime');
const oneAsPrime=boot();oneAsPrime.click('factor',{code:'N02.04'});solveFactor(oneAsPrime,FACTOR_TASKS['N02.04']);oneAsPrime.click('factorChoice',{value:'prime'});oneAsPrime.click('reason',{index:'0'});oneAsPrime.click('check');assert.equal(microLatest(oneAsPrime).gradingResult,'incorrect','1 has only one positive factor');
const squareDouble=boot();squareDouble.click('factor',{code:'N02.05'});solveFactor(squareDouble,FACTOR_TASKS['N02.05']);squareDouble.click('factorCollect',{value:'4'});squareDouble.click('factorCount',{delta:'1'});squareDouble.click('reason',{index:'0'});squareDouble.click('check');assert.equal(microLatest(squareDouble).gradingResult,'incorrect');assert.equal(microLatest(squareDouble).operationSummary.work.cards[0].collected.filter(v=>v===4).length,1,'middle factor only has one distinct card');
const justCount=boot();justCount.click('factor',{code:'N02.06'});for(let i=0;i<9;i++)justCount.click('factorCount',{delta:'1'});justCount.click('reason',{index:'0'});justCount.click('check');assert.equal(microLatest(justCount).gradingResult,'incorrect','guessing the right count without arrays and factor cards is insufficient');
const factorUndo=boot();factorUndo.click('factor',{code:'N02.01'});factorUndo.click('factorWidth',{value:'10'});factorUndo.click('factorRow');factorUndo.click('factorRow');factorUndo.click('factorRecord');factorUndo.click('factorUndo');factorUndo.click('reason',{index:'0'});factorUndo.click('check');assert.equal(microLatest(factorUndo).operationSummary.work.cards[0].pairs.length,0);assert.equal(microLatest(factorUndo).operationSummary.work.cards[0].laid,20,'undo record preserves previously laid material');factorUndo.click('factorUndo');factorUndo.click('check');assert.equal(microLatest(factorUndo).operationSummary.work.cards[0].laid,10,'undo row returns half the material');
const factorInvalid=boot();factorInvalid.click('factor',{code:'N02.01'});factorInvalid.click('factorWidth',{value:'0'});factorInvalid.click('factorWidth',{value:'21'});factorInvalid.click('factorFill');factorInvalid.click('factorWidth',{value:'10'});factorInvalid.click('reason',{index:'0'});factorInvalid.click('check');assert.equal(microLatest(factorInvalid).operationSummary.work.cards[0].width,1,'invalid widths or width changes with material laid are rejected');
const factorBackup=boot({tianle_amc8_question_design_v1:JSON.stringify({storageVersion:2,contentRevision:release.contentRevision,skillStage:Object.fromEntries(Object.keys(FACTOR_TASKS).map(sid=>[sid,{transferPassed:true,independentTried:true}]))})});for(const sid of Object.keys(FACTOR_TASKS)){factorBackup.click('stage',{code:sid+'|independent2'});solveStage(factorBackup,STAGED_TASKS[sid].independent2);assert.equal(microLatest(factorBackup).independent,true);factorBackup.click('next')}
const factorVoice=boot({},true);factorVoice.click('factor',{code:'N02.01'});factorVoice.click('factorWidth',{value:'3'});factorVoice.click('factorFill');factorVoice.click('speakState');assert(factorVoice.spoken.at(-1).includes('已铺20块')&&factorVoice.spoken.at(-1).includes('末行缺1格'));
const groupingRun=boot();for(const [sid,t] of Object.entries(GROUPING_TASKS)){
 groupingRun.click('micro',{code:sid});assert(groupingRun.root.innerHTML.includes('data-action="grouping"'));
 groupingRun.click('grouping',{code:sid});assert(groupingRun.root.innerHTML.includes(t.prompt));
 const before=groupingRun.storage.tianle_amc8_question_design_v1?microState(groupingRun).attempts.length:0;
 groupingRun.click('check');assert.equal(groupingRun.storage.tianle_amc8_question_design_v1?microState(groupingRun).attempts.length:0,before,'empty grouping model cannot submit');
 solveGrouping(groupingRun,t);groupingRun.click('check');assert(groupingRun.root.innerHTML.includes('先说一说你的理由'));
 groupingRun.click('reason',{index:'0'});groupingRun.click('check');const a=microLatest(groupingRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 if(t.kind==='digitRules')require('./model_oracles').verify(t,a.operationSummary.work);
 else if(t.kind!=='digits')a.operationSummary.work.cards.forEach((c,i)=>{const total=t.kind==='digitSum'?t.numbers[i].toString().split('').reduce((a,v)=>a+Number(v),0):t.totals?.[i]??t.total;assert.equal(c.groups.flat().length+total%t.divisor,total,'grouping preserves original total')});
 groupingRun.click('next');assert(groupingRun.root.innerHTML.includes('它能联系到哪里？'));
}
const shortBag=boot();shortBag.click('grouping',{code:'N01.02'});for(let start=0;start<12;start+=3){for(let i=0;i<3;i++)shortBag.click('groupPick',{card:'0',index:String(start+i)});shortBag.click('groupWrap',{card:'0'})}shortBag.click('groupPick',{card:'0',index:'12'});shortBag.click('groupPick',{card:'0',index:'13'});shortBag.click('groupWrap',{card:'0'});shortBag.click('groupProbe',{card:'0'});shortBag.click('groupChoice',{card:'0',value:'2'});shortBag.click('reason',{index:'0'});shortBag.click('check');assert.equal(microLatest(shortBag).gradingResult,'incorrect','two leftover pieces cannot become a three-piece bag');assert.equal(microLatest(shortBag).operationSummary.work.cards[0].groups.length,4);
const notAllGrouped=boot();notAllGrouped.click('grouping',{code:'N01.01'});notAllGrouped.click('groupProbe',{card:'0'});notAllGrouped.click('groupChoice',{card:'0',value:'complete'});notAllGrouped.click('reason',{index:'0'});notAllGrouped.click('check');assert.equal(microLatest(notAllGrouped).gradingResult,'incorrect','classification alone cannot replace actual grouping');assert(notAllGrouped.root.innerHTML.includes('盘中还够3个'));
const usedPiece=boot();usedPiece.click('grouping',{code:'N01.01'});for(let i=0;i<3;i++)usedPiece.click('groupPick',{card:'0',index:String(i)});usedPiece.click('groupWrap',{card:'0'});usedPiece.click('groupPick',{card:'0',index:'0'});usedPiece.click('groupPick',{card:'0',index:'-1'});usedPiece.click('groupPick',{card:'0',index:'100'});usedPiece.click('reason',{index:'0'});usedPiece.click('check');assert.equal(microLatest(usedPiece).operationSummary.work.cards[0].selected.length,0,'grouped or nonexistent pieces cannot be reused');
const missingDigit=boot();missingDigit.click('grouping',{code:'N01.03'});missingDigit.click('digitRuleChoice',{card:'0',value:'complete'});missingDigit.click('reason',{index:'0'});missingDigit.click('check');assert.equal(microLatest(missingDigit).gradingResult,'incorrect','using only one digit is not a divisibility test');
const leadingZero=boot();leadingZero.click('grouping',{code:'N01.04'});solveGrouping(leadingZero,GROUPING_TASKS['N01.04']);leadingZero.click('groupDigit',{place:'tens',value:'0'});leadingZero.click('groupDigit',{place:'ones',value:'4'});leadingZero.click('groupRecord');leadingZero.click('reason',{index:'0'});leadingZero.click('check');assert.equal(microLatest(leadingZero).gradingResult,'incorrect','leading zero does not make a two-digit number');leadingZero.click('groupRemoveEntry',{index:'3'});leadingZero.click('check');assert.equal(microLatest(leadingZero).gradingResult,'correct');assert.equal(microLatest(leadingZero).independent,false,'correcting same instance is not new independent evidence');
const oddWrong=boot();oddWrong.click('grouping',{code:'N01.05'});solveGrouping(oddWrong,GROUPING_TASKS['N01.05']);oddWrong.click('groupChoice',{card:'1',value:'even'});oddWrong.click('reason',{index:'0'});oddWrong.click('check');assert.equal(microLatest(oddWrong).gradingResult,'incorrect','one leftover is odd despite having many complete pairs');
const groupUndo=boot();groupUndo.click('grouping',{code:'N01.01'});for(let i=0;i<3;i++)groupUndo.click('groupPick',{card:'0',index:String(i)});groupUndo.click('groupWrap',{card:'0'});groupUndo.click('groupUndo');groupUndo.click('reason',{index:'0'});groupUndo.click('check');assert.equal(microLatest(groupUndo).operationSummary.work.cards[0].groups.length,0);assert.equal(microLatest(groupUndo).operationSummary.work.cards[0].selected.length,3,'undo restores pieces and selection before grouping');
const groupingBackup=boot({tianle_amc8_question_design_v1:JSON.stringify({storageVersion:2,contentRevision:release.contentRevision,skillStage:Object.fromEntries(Object.keys(GROUPING_TASKS).map(sid=>[sid,{transferPassed:true,independentTried:true}]))})});for(const sid of Object.keys(GROUPING_TASKS)){groupingBackup.click('stage',{code:sid+'|independent2'});solveStage(groupingBackup,STAGED_TASKS[sid].independent2);assert.equal(microLatest(groupingBackup).independent,true);groupingBackup.click('next')}
const groupVoice=boot({},true);groupVoice.click('grouping',{code:'N01.01'});for(let i=0;i<3;i++)groupVoice.click('groupPick',{card:'0',index:String(i)});groupVoice.click('groupWrap',{card:'0'});groupVoice.click('speakState');assert(groupVoice.spoken.at(-1).includes('已装1组')&&groupVoice.spoken.at(-1).includes('盘中9个'));
const coordinateRun=boot();for(const [sid,t] of Object.entries(COORDINATE_TASKS)){
 coordinateRun.click('micro',{code:sid});assert(coordinateRun.root.innerHTML.includes('data-action="coordinate"'),sid+' operation reachable from micro-skill');
 coordinateRun.click('coordinate',{code:sid});assert(coordinateRun.root.innerHTML.includes(t.prompt));
 const before=coordinateRun.storage.tianle_amc8_question_design_v1?microState(coordinateRun).attempts.length:0;
 coordinateRun.click('check');assert.equal(coordinateRun.storage.tianle_amc8_question_design_v1?microState(coordinateRun).attempts.length:0,before,'empty coordinate model cannot submit');
 solveCoordinate(coordinateRun,t);coordinateRun.click('check');assert(coordinateRun.root.innerHTML.includes('先说一说你的理由'));
 coordinateRun.click('reason',{index:'0'});coordinateRun.click('check');const a=microLatest(coordinateRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 coordinateRun.click('next');assert(coordinateRun.root.innerHTML.includes('它能联系到哪里？'),'completed operation returns to related knowledge');
}
const switchedAxis=boot();switchedAxis.click('coordinate',{code:'L04.02'});switchedAxis.click('coordAxis',{axis:'x',value:'3'});switchedAxis.click('coordAxis',{axis:'y',value:'2'});switchedAxis.click('coordPoint',{x:'3',y:'2'});switchedAxis.click('reason',{index:'0'});switchedAxis.click('check');assert.equal(microLatest(switchedAxis).gradingResult,'incorrect','swapping axes changes the actual location');
const skippedGuides=boot();skippedGuides.click('coordinate',{code:'L04.02'});skippedGuides.click('coordPoint',{x:'2',y:'3'});skippedGuides.click('reason',{index:'0'});skippedGuides.click('check');assert(!skippedGuides.storage.tianle_amc8_question_design_v1||!microState(skippedGuides).attempts.length,'point cannot be recorded without locating both axes');
const bothAtA=boot();bothAtA.click('coordinate',{code:'L04.03'});for(let i=0;i<2;i++){bothAtA.click('coordActive',{index:String(i)});bothAtA.click('coordAxis',{axis:'x',value:'2'});bothAtA.click('coordAxis',{axis:'y',value:'3'});bothAtA.click('coordPoint',{x:'2',y:'3'})}bothAtA.click('reason',{index:'0'});bothAtA.click('check');assert.equal(microLatest(bothAtA).gradingResult,'incorrect','A and B must respect their own coordinate order');
const detour=boot();detour.click('coordinate',{code:'L04.04'});detour.click('coordMove',{dx:'1',dy:'0'});detour.click('coordMove',{dx:'-1',dy:'0'});solveCoordinate(detour,COORDINATE_TASKS['L04.04']);detour.click('reason',{index:'0'});detour.click('check');assert.equal(microLatest(detour).gradingResult,'incorrect','same endpoint with extra loop fails the explicit no-detour condition');
const badTable=boot();badTable.click('coordinate',{code:'L04.05'});for(const [i,x,y] of [[0,1,7],[1,2,5],[2,3,3]]){badTable.click('coordActive',{index:String(i)});badTable.click('coordAxis',{axis:'x',value:String(x)});badTable.click('coordAxis',{axis:'y',value:String(y)});badTable.click('coordPoint',{x:String(x),y:String(y)})}badTable.click('reason',{index:'0'});badTable.click('check');assert.equal(microLatest(badTable).gradingResult,'incorrect','table input and output cannot be mixed between rows');
const fakeDynamic=boot();fakeDynamic.click('coordinate',{code:'L04.06'});fakeDynamic.click('coordDelta',{delta:'1'});fakeDynamic.click('coordTick');fakeDynamic.click('coordDelta',{delta:'1'});fakeDynamic.click('coordTick');fakeDynamic.click('coordDelta',{delta:'1'});fakeDynamic.click('coordTick');fakeDynamic.click('coordDelta',{delta:'-1'});fakeDynamic.click('reason',{index:'0'});fakeDynamic.click('check');assert.equal(microLatest(fakeDynamic).gradingResult,'incorrect','right endpoint and final knob cannot replace the constant-change path');
const pointUndo=boot();pointUndo.click('coordinate',{code:'L04.02'});solveCoordinate(pointUndo,COORDINATE_TASKS['L04.02']);pointUndo.click('coordUndo');pointUndo.click('reason',{index:'0'});pointUndo.click('check');assert.equal(microLatest(pointUndo).gradingResult,'incorrect','undo removes the plotted point');
const machineOrder=boot();machineOrder.click('coordinate',{code:'L04.01'});machineOrder.click('coordAdd',{index:'0'});machineOrder.click('check');assert(!machineOrder.storage.tianle_amc8_question_design_v1||!microState(machineOrder).attempts.length,'add cannot precede multiply');
const mixedRules=boot();mixedRules.click('coordinate',{code:'L04.01'});
// 1×1+2=3 and 2×2+1=5 happen to fit individual cards but are different rules.
for(let i=0;i<2;i++)mixedRules.click('coordAdjust',{key:'add',delta:'1'});mixedRules.click('coordMultiply',{index:'0'});mixedRules.click('coordAdd',{index:'0'});
mixedRules.click('coordAdjust',{key:'multiplier',delta:'1'});mixedRules.click('coordAdjust',{key:'add',delta:'-1'});for(let i=1;i<3;i++){mixedRules.click('coordMultiply',{index:String(i)});mixedRules.click('coordAdd',{index:String(i)})}mixedRules.click('reason',{index:'0'});mixedRules.click('check');assert.equal(microLatest(mixedRules).gradingResult,'incorrect','one common rule is required even when all outputs happen to match');
const coordinateInvalid=boot();coordinateInvalid.click('coordinate',{code:'L04.04'});coordinateInvalid.click('coordMove',{dx:'2',dy:'0'});coordinateInvalid.click('coordMove',{dx:'-2',dy:'0'});coordinateInvalid.click('check');assert(!coordinateInvalid.storage.tianle_amc8_question_design_v1||!microState(coordinateInvalid).attempts.length,'invalid move sizes do not modify state');
const coordinateBackup=boot({tianle_amc8_question_design_v1:JSON.stringify({storageVersion:2,contentRevision:release.contentRevision,skillStage:Object.fromEntries(Object.keys(COORDINATE_TASKS).map(sid=>[sid,{transferPassed:true,independentTried:true}]))})});
for(const sid of Object.keys(COORDINATE_TASKS)){coordinateBackup.click('stage',{code:sid+'|independent2'});solveStage(coordinateBackup,STAGED_TASKS[sid].independent2);assert.equal(microLatest(coordinateBackup).independent,true);coordinateBackup.click('next')}
const coordinateVoice=boot({},true);coordinateVoice.click('coordinate',{code:'L04.04'});coordinateVoice.click('coordMove',{dx:'1',dy:'0'});coordinateVoice.click('speakState');assert(coordinateVoice.spoken.at(-1).includes('横2纵2'),'coordinate speech describes current moved position');coordinateVoice.click('coordinate',{code:'L04.06'});coordinateVoice.click('coordDelta',{delta:'1'});coordinateVoice.click('coordDelta',{delta:'1'});coordinateVoice.click('coordTick');coordinateVoice.click('speakState');assert(coordinateVoice.spoken.at(-1).includes('0分钟在位置1')&&coordinateVoice.spoken.at(-1).includes('1分钟在位置3'),'dynamic speech includes time zero and actual trace');
const patternRun=boot();for(const [sid,t] of Object.entries(PATTERN_TASKS)){
 patternRun.click('pattern',{code:sid});assert(patternRun.root.innerHTML.includes(t.prompt));
 const before=patternRun.storage.tianle_amc8_question_design_v1?microState(patternRun).attempts.length:0;
 patternRun.click('check');assert.equal(patternRun.storage.tianle_amc8_question_design_v1?microState(patternRun).attempts.length:0,before,'empty pattern model cannot submit');
 solvePattern(patternRun,t);patternRun.click('check');assert(patternRun.root.innerHTML.includes('先说一说你的理由'));
 patternRun.click('reason',{index:'0'});patternRun.click('check');const a=microLatest(patternRun);
 assert.equal(a.taskInstanceId,t.id);assert.equal(a.gradingResult,'correct');assert(a.operationSummary.work.moves>0&&a.explanationEvidence.correct);
 patternRun.click('next');
}
const longPeriod=boot();longPeriod.click('pattern',{code:'L03.01'});longPeriod.click('patternLength',{value:'4'});longPeriod.click('patternCopy');longPeriod.click('reason',{index:'0'});longPeriod.click('check');assert.equal(microLatest(longPeriod).gradingResult,'incorrect','valid four-item repetition is not the shortest period');
const wrongDifference=boot();wrongDifference.click('pattern',{code:'L03.02'});for(let i=0;i<2;i++)wrongDifference.click('patternAdjust',{delta:'1'});wrongDifference.click('patternAppend');wrongDifference.click('patternAppend');wrongDifference.click('reason',{index:'0'});wrongDifference.click('check');assert.equal(microLatest(wrongDifference).gradingResult,'incorrect','constant wrong difference cannot count as the authored progression');
const wrongFactor=boot();wrongFactor.click('pattern',{code:'L03.03'});wrongFactor.click('patternAdjust',{delta:'1'});wrongFactor.click('patternAdjust',{delta:'1'});wrongFactor.click('patternAppend');wrongFactor.click('patternAppend');wrongFactor.click('reason',{index:'0'});wrongFactor.click('check');assert.equal(microLatest(wrongFactor).gradingResult,'incorrect','multiplying by three does not extend a doubling sequence');
const incompleteRule=boot();incompleteRule.click('pattern',{code:'L03.04'});incompleteRule.click('patternAdd');assert(!incompleteRule.root.innerHTML.includes('机器里现在 3'),'cannot add before multiplying');incompleteRule.click('patternMultiply');incompleteRule.click('patternAdd');incompleteRule.click('patternCommit');incompleteRule.click('reason',{index:'0'});incompleteRule.click('check');assert.equal(microLatest(incompleteRule).gradingResult,'incorrect','one generated term cannot finish a two-round rule');
const oldTwo=boot();oldTwo.click('pattern',{code:'L03.05'});oldTwo.click('patternPick',{index:'0'});oldTwo.click('patternPick',{index:'1'});oldTwo.click('patternSum');oldTwo.click('patternPick',{index:'0'});oldTwo.click('patternPick',{index:'2'});oldTwo.click('patternSum');oldTwo.click('reason',{index:'0'});oldTwo.click('check');assert.equal(microLatest(oldTwo).gradingResult,'incorrect','must use the immediately preceding two terms');
const badGrid=boot();badGrid.click('pattern',{code:'L03.06'});const gridTask=PATTERN_TASKS['L03.06'];for(let r=1;r<gridTask.rows;r++)for(let c=0;c<gridTask.cols;c++){badGrid.click('patternCell',{row:String(r),col:String(c)});const shouldBlue=(r+c)%2===1;if(shouldBlue&&!(r===1&&c===0))badGrid.click('patternCell',{row:String(r),col:String(c)})}badGrid.click('reason',{index:'0'});badGrid.click('check');assert.equal(microLatest(badGrid).gradingResult,'incorrect','same-color vertical neighbor breaks the two-dimensional pattern');
const gridUndo=boot();gridUndo.click('pattern',{code:'L03.06'});gridUndo.click('patternCell',{row:'1',col:'0'});gridUndo.click('patternUndo');assert(gridUndo.root.innerHTML.includes('已涂0格')||gridUndo.root.innerHTML.includes('未涂'),'undo clears the cell');
const baseWrong=boot();baseWrong.click('percent',{code:'A04.05'});
for(let i=0;i<10;i++)baseWrong.click('percentAdd');baseWrong.click('percentPhase');
for(let i=0;i<10;i++)baseWrong.click('percentRemove');baseWrong.click('percentChoice',{value:'100'});baseWrong.click('reason',{index:'0'});baseWrong.click('check');
assert.equal(microLatest(baseWrong).gradingResult,'incorrect','second 10% uses 110, so removing only 10 is wrong');
baseWrong.click('percentRemove');baseWrong.click('percentChoice',{value:'99'});baseWrong.click('reason',{index:'0'});baseWrong.click('check');
assert.equal(microLatest(baseWrong).independent,false,'corrected percentage base does not create clean first answer');
const workshopRun=boot();
const workshopMoves={
 'A01.01':[['workAdd',{},4]],
 'A01.04':[['workAdjust',{side:'right',delta:'1'},1],['workChoice',{value:'right'},1]],
 'A01.05':[['workUnbundle',{},1],['workChoice',{value:'0'},1]],
 'A02.01':[['workTake',{index:'0'},1],['workTake',{index:'1'},1],['workTake',{index:'2'},1]],
 'A02.03':[['workInverseAdd',{},3],['workInverseRemove',{},3],['workChoice',{value:'0'},1]],
 'A02.04':[['workPlace',{index:'0'},4],['workPlace',{index:'1'},4],['workPlace',{index:'2'},4]],
 'A02.05':[['workPlace',{index:'0'},4],['workPlace',{index:'1'},4],['workPlace',{index:'2'},4]],
 'A02.06':[['workFirstAdd',{},2],['workCopy',{},1]],
};
for(const [sid,t] of Object.entries(WORKSHOP_TASKS)){
 workshopRun.click('workshop',{code:sid});assert(workshopRun.root.innerHTML.includes(t.prompt),sid+' opens');
 workshopRun.click('check');assert.equal(workshopRun.storage.tianle_amc8_question_design_v1?microState(workshopRun).attempts.length:0,Object.keys(WORKSHOP_TASKS).indexOf(sid),'no empty operation can be submitted');
 solveFoundation(workshopRun,t);
 workshopRun.click('check');assert(workshopRun.root.innerHTML.includes('先说一说你的理由'),'operation alone cannot bypass explanation selection');
 workshopRun.click('reason',{index:String(t.reason.answer)});
 workshopRun.click('check');assert(workshopRun.root.innerHTML.includes('答对了！'),sid+' actual state accepted');
 const attempt=microLatest(workshopRun);assert.equal(attempt.taskInstanceId,t.id);assert.deepEqual(attempt.skillIds,[sid]);assert.equal(attempt.contentVersion,68);assert.equal(attempt.operationSummary.work.moves,attempt.operationSummary.moves);assert.equal(attempt.explanationEvidence.correct,true);
 workshopRun.click('next');
}
const wrongWorkshop=boot();wrongWorkshop.click('workshop',{code:'A02.04'});
for(let i=0;i<5;i++)wrongWorkshop.click('workPlace',{index:'0'});
for(let i=0;i<4;i++)wrongWorkshop.click('workPlace',{index:'1'});
for(let i=0;i<3;i++)wrongWorkshop.click('workPlace',{index:'2'});
wrongWorkshop.click('check');assert.equal(microLatest(wrongWorkshop).gradingResult,'incorrect','same total but unequal groups is rejected');
wrongWorkshop.click('workUnplace',{index:'0'});wrongWorkshop.click('workPlace',{index:'2'});wrongWorkshop.click('reason',{index:'0'});wrongWorkshop.click('check');assert.equal(microLatest(wrongWorkshop).gradingResult,'correct');assert.equal(microLatest(wrongWorkshop).independent,false);
const reverseCheck=boot();reverseCheck.click('workshop',{code:'A01.05'});reverseCheck.click('workUnbundle');
assert(reverseCheck.root.innerHTML.includes('1十 13一'),'ten-to-one exchange is visible');
reverseCheck.click('workRebundle');assert(reverseCheck.root.innerHTML.includes('2十 3一'),'inverse exchange restores original representation');
reverseCheck.click('workUnbundle');reverseCheck.click('workChoice',{value:'0'});reverseCheck.click('reason',{index:'0'});reverseCheck.click('check');assert.equal(microLatest(reverseCheck).gradingResult,'correct');
const inverseCheck=boot();inverseCheck.click('workshop',{code:'A02.03'});for(let i=0;i<3;i++)inverseCheck.click('workInverseAdd');inverseCheck.click('workInverseRemove');inverseCheck.click('workInverseUndo');
assert(inverseCheck.root.innerHTML.includes('已拿走0'),'undo restores state before final removal');
const reasonWrong=boot();reasonWrong.click('workshop',{code:'A01.01'});for(let i=0;i<4;i++)reasonWrong.click('workAdd');reasonWrong.click('reason',{index:'1'});reasonWrong.click('check');
assert.equal(microLatest(reasonWrong).gradingResult,'incorrect');assert.equal(microLatest(reasonWrong).explanationEvidence.correct,false,'wrong mathematical reason is saved distinctly');
reasonWrong.click('reason',{index:'0'});reasonWrong.click('check');assert.equal(microLatest(reasonWrong).gradingResult,'correct');assert.equal(microLatest(reasonWrong).independent,false,'wrong reasoning cannot be erased by fixing it');
const invalidGroup=boot();invalidGroup.click('workshop',{code:'A02.05'});invalidGroup.click('workPlace',{index:'9'});invalidGroup.click('workUnplace',{index:'-1'});
assert.equal((invalidGroup.root.innerHTML.match(/data-object-id='P[0-9]+'/g)||[]).length,12,'invalid group indices do not move counters');
b.click('fruit');
b.click('next');assert.equal(b.storage.tianle_amc8_question_design_v1?JSON.parse(b.storage.tianle_amc8_question_design_v1).fruitFrontier:0,0,'cannot advance before correct answer');
// Wrong answer, then repair the same task; wrong attempts cannot advance progress.
b.click('person',{index:'6'});b.click('check');
assert(b.root.innerHTML.includes('有没有漏选或多选'));
assert.equal(JSON.parse(b.storage.tianle_amc8_question_design_v1).errors.F01,1,'wrong attempt is stored locally');
const wrongEvidence=JSON.parse(b.storage.tianle_amc8_question_design_v1).attempts[0];
assert.equal(wrongEvidence.taskInstanceId,'F01');
assert.equal(wrongEvidence.gradingResult,'incorrect');
assert.equal(wrongEvidence.firstSubmissionCorrect,false);
assert.deepEqual(wrongEvidence.skillIds,[],'unreviewed skills have no claimed evidence');
assert.equal(JSON.parse(b.storage.tianle_amc8_question_design_v1||'{"fruitFrontier":0}').fruitFrontier,0);
b.click('person',{index:'6'});
for(let i=0;i<FRUIT_TASKS.length;i++){
 const t=FRUIT_TASKS[i];
 if(t.mode==='people')for(const index of t.want)b.click('person',{index:String(index)});
 if(t.mode==='choice')b.click('choice',{index:String(t.answer)});
 if(t.mode==='number')b.input(t.answer);
 if(t.mode==='formula'){
  const expr=t.allowed.includes('A')&&t.allowed.includes('B')&&t.allowed.includes('O')&&t.terms===3?['A','+','B','-','O']:
   t.allowed.includes('A')&&t.allowed.includes('Y')&&t.terms===2?['A','+','Y']:
   t.allowed.includes('R')&&t.allowed.includes('O')&&t.allowed.includes('Y')&&t.terms===3?['R','+','O','+','Y']:
   ['A','+','B','-','O'];
  for(const x of expr)b.click('+-'.includes(x)?'op':'term',{id:x});
 }
 b.click('check');assert(b.root.innerHTML.includes('答对了！'),t.id+' must be solvable via UI');
 b.click('next');
 if(i===0){const reopened=boot(b.storage);reopened.click('fruit');assert(reopened.root.innerHTML.includes('喜欢苹果的都有谁'), 'reload keeps checkpoint')}
}
assert(b.root.innerHTML.includes('水果集合 · 路线走完'));
assert.equal(JSON.parse(b.storage.tianle_amc8_question_design_v1).fruitFrontier,26);
b.click('review');assert.equal(JSON.parse(b.storage.tianle_amc8_question_design_v1).fruitFrontier,26);
b.click('home');b.click('network',{code:'C01'});assert(b.root.innerHTML.includes('继续已有练习'),'completed legacy fruit route remains reachable from its knowledge region');
b.click('fruit');b.click('frontier');assert(b.root.innerHTML.includes('水果集合 · 路线走完'));
b.click('previous');assert(b.root.innerHTML.includes('26/26'));
b.click('progress');assert(b.root.innerHTML.includes('本机学习进度'));
assert.equal((b.root.innerHTML.match(/class="progress-card"/g)||[]).length,33,'all continuous routes summarized');
assert(b.root.innerHTML.includes('错过 1 次'),'past wrong step listed');
b.click('jump',{code:'C01',step:'0'});assert(b.root.innerHTML.includes('1/26'),'mistake opens its original task');
assert.equal(JSON.parse(b.storage.tianle_amc8_question_design_v1).fruitFrontier,26,'mistake review retains completion');
b.click('nextSolved');assert(b.root.innerHTML.includes('2/26'),'answered fruit task can advance without resubmitting');
b.click('nextSolved');assert(b.root.innerHTML.includes('3/26'),'can continue through multiple answered fruit tasks');
b.click('previous');assert(b.root.innerHTML.includes('2/26'));
b.click('nextSolved');assert(b.root.innerHTML.includes('3/26'),'forward navigation also works after going back');
const newFruit=boot();newFruit.click('fruit');newFruit.click('nextSolved');assert(newFruit.root.innerHTML.includes('1/26'),'unsolved fruit task cannot be skipped');

function solveCourse(b,t){
 if(t.mode==='number')b.input(t.answer);
 if(t.mode==='choice')b.click('choice',{index:String(t.answer)});
 if(t.mode==='multi')for(const index of t.answer)b.click('multi',{index:String(index)});
 if(t.mode==='pairs')for(const label of t.answer)b.click('multi',{index:String(t.options.indexOf(label))});
 if(t.mode==='bundleTen'){
  for(let i=0;i<10;i++)b.click('bundleDot',{index:String(i)});
  b.click('bundle');
  b.click('bundleMeaning',{index:'0'});
 }
 if(t.mode==='netFold'){
  for(const i of [0,1,3,4,5])b.click('netFoldFace',{index:String(i)});
  b.input(t.answer);
 }
 if(t.mode==='balanceUnknown'){b.click('balanceTake');b.input(t.answer)}
 if(t.mode==='selectIcons')for(const i of t.answer)b.click('selectIcon',{index:String(i)});
 if(t.mode==='cycleOverlap')b.click('cycleTime',{time:String(t.answer)});
 if(t.mode==='enumerate')for(const key of t.answer){for(const value of key.split('|'))b.click('enumItem',{value});b.click('enumRecord')}
 if(t.mode==='netSelect')for(const index of t.answer)b.click('netFace',{index:String(index)});
 if(t.mode==='parityMoves'){for(let i=0;i<t.moves;i++)b.click('applyMove');b.click('parityChoice',{value:t.answer})}
 if(t.mode==='tenTap')for(let i=t.filled;i<t.target;i++)b.click('tenCell',{index:String(i)});
 if(t.mode==='sequence')for(const value of t.answer)b.click('seqToken',{value});
 if(t.mode==='lineWalk')for(let n=t.start;n<t.target;n++)b.click('lineMove',{delta:'1'});
 if(t.mode==='barBuild')for(const [i,height] of t.barValues.entries())for(let j=0;j<height;j++)b.click('barChange',{index:String(i),delta:'1'});
 if(t.mode==='arcSelect')b.click('arcPart',{index:'0'});
 if(t.mode==='sides')for(const index of t.answer)b.click('side',{index:String(index)});
 if(t.mode==='placeValue'){
  for(let i=0;i<t.tens;i++)b.click('place',{unit:'tens',delta:'1'});
  for(let i=0;i<t.ones;i++)b.click('place',{unit:'ones',delta:'1'});
 }
 if(t.mode==='gridSelect')for(const index of t.answer)b.click('cutCell',{index:String(index)});
 if(t.mode==='formula')for(const x of ['A','+','B','-','O'])b.click('+-'.includes(x)?'op':'term',{id:x});
 if(t.mode==='redistribute'){
  const values=[...t.values];
  while(values.some((v,i)=>v!==t.answer[i])){
   const from=values.findIndex((v,i)=>v>t.answer[i]),to=values.findIndex((v,i)=>v<t.answer[i]);
   assert(from>=0&&to>=0,t.id+' conservation');
   b.click('movePile',{index:String(from)});b.click('movePile',{index:String(to)});
   values[from]--;values[to]++;
  }
 }
 if(t.reason)b.click('reason',{index:String(t.reason.answer)});
 b.click('check');assert(b.root.innerHTML.includes('答对了！'),t.id+' must be solvable via UI');
}
for(const [id,course] of Object.entries(COURSES)){
 const route=boot();route.click('course',{code:id});
 if(course.steps[0].mode==='pairs'){
  const t=course.steps[0],dup=t.options.lastIndexOf(t.answer[0]);
  assert(dup>t.options.indexOf(t.answer[0]));
  route.click('multi',{index:String(dup)});
  for(const label of t.answer.slice(1))route.click('multi',{index:String(t.options.indexOf(label))});
  route.click('check');assert(route.root.innerHTML.includes('答对了！'),'equivalent duplicate card is accepted');
 }else solveCourse(route,course.steps[0]);
 route.click('next');
 const reopened=boot(route.storage);reopened.click('course',{code:id});
 assert(reopened.root.innerHTML.includes('2/8'),id+' reload keeps cursor');
 route.click('nextSolved');assert(route.root.innerHTML.includes('2/8'),id+' unanswered step cannot be skipped');
 route.click('previous');assert.equal(JSON.parse(route.storage.tianle_amc8_question_design_v1).courses[id].frontier,1,'back preserves completed frontier');
 assert(route.root.innerHTML.includes('data-action="nextSolved"'),id+' answered step exposes next navigation');
 route.click('nextSolved');assert(route.root.innerHTML.includes('2/8'),id+' answered step can be skipped without solving again');
 for(const t of course.steps.slice(1)){solveCourse(route,t);route.click('next')}
 assert(route.root.innerHTML.includes('路线走完'),id+' completion');
 assert.equal(JSON.parse(route.storage.tianle_amc8_question_design_v1).courses[id].frontier,8,id+' frontier');
 route.click('review');assert.equal(JSON.parse(route.storage.tianle_amc8_question_design_v1).courses[id].cursor,0);
 route.click('nextSolved');route.click('nextSolved');assert(route.root.innerHTML.includes('3/8'),id+' completed route can be reviewed forward step by step');
 assert(route.root.innerHTML.includes(`data-action="sample" data-code="${id}"`),id+' sample reachable');
 route.click('home');assert.equal(JSON.parse(route.storage.tianle_amc8_question_design_v1).courses[id].frontier,8,id+' route completion remains after review');route.click('network',{code:id});assert(route.root.innerHTML.includes('继续已有练习'),id+' historical route stays accessible');
}
const activeModes=new Set(['sequence','lineWalk','barBuild','arcSelect','enumerate']);
for(const [id,course] of Object.entries(COURSES)){
 const reason=course.steps[4].reason;
 assert(reason&&reason.options.length===3&&reason.options[reason.answer],id+' practice has a reason card');
 assert.notEqual(FOCUS_REVIEW[id][0].prompt,FOCUS_REVIEW[id][1].prompt,id+' delayed context differs');
 if(['A05','D01','G02','G04','G05','G06','L01','L02','L04','N01','N02','N03','N04','R01','R02','R03','R04'].includes(id))assert(activeModes.has(course.steps[5].mode),id+' second practice has an active operation');
}
const whySeed={tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{A02:{frontier:4,cursor:4}}})};
const why=boot(whySeed);why.click('course',{code:'A02'});
for(let i=4;i<10;i++)why.click('tenCell',{index:String(i)});
why.click('check');assert(why.root.innerHTML.includes('先说一说你的理由'),'correct manipulation requires reason');
assert.equal(JSON.parse(why.storage.tianle_amc8_question_design_v1).errors?.['A02-5'],undefined,'missing reason is not an actual wrong attempt');
const wrongReason=(COURSES.A02.steps[4].reason.answer+1)%3;
why.click('reason',{index:String(wrongReason)});why.click('check');assert(!why.root.innerHTML.includes('答对了！'),'unrelated reason fails');
why.click('reason',{index:String(COURSES.A02.steps[4].reason.answer)});why.click('check');assert(why.root.innerHTML.includes('答对了！'),'answer and reason both correct');
const v2Seed={tianle_amc8_question_design_v1:JSON.stringify({contentRevision:2,courses:{G04:{frontier:8,cursor:8}},reviews:{G04:{dueAt:1,cursor:2,clean:true,verifiedAt:555}}})};
const v2=boot(v2Seed),v2State=JSON.parse(v2.storage.tianle_amc8_question_design_v1);
assert.equal(v2State.courses.G04.frontier,8,'v2 completed frontier retained');
assert.equal(v2State.courses.G04.cursor,0,'v2 starts at the earliest changed learning step');
assert.equal(v2State.legacyReviews.G04,555,'previous review time retained as history');
v2.click('course',{code:'G04'});assert(v2.root.innerHTML.includes('1/8'),'v2 migration opens new learning step');
v2.click('frontier');assert(v2.root.innerHTML.includes('1/8'),'v2 cannot bypass new content');
const v3=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:3,courses:{A01:{frontier:8,cursor:8},R03:{frontier:8,cursor:8},A02:{frontier:8,cursor:8}},reviews:{A01:{dueAt:1,cursor:2,clean:true,verifiedAt:777}}})});
const v3State=JSON.parse(v3.storage.tianle_amc8_question_design_v1);
assert.equal(v3State.courses.A01.frontier,8,'old completion is retained');
assert.equal(v3State.courses.A01.cursor,1,'A01 reopens at the redesigned bundle task');
assert.equal(v3State.courses.R03.cursor,0,'new reasoning chain reopens the changed learning step');
assert.equal(v3State.courses.A02.cursor,8,'unchanged course remains completed');
assert.equal(v3State.legacyReviews.A01,777,'old review result retained as history');
const v4=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:4,courses:{G07:{frontier:8,cursor:8},G04:{frontier:8,cursor:8},A03:{frontier:8,cursor:8},A02:{frontier:8,cursor:8}}})});
const v4State=JSON.parse(v4.storage.tianle_amc8_question_design_v1);
for(const code of ['G07','G04','A03']){
 assert.equal(v4State.courses[code].frontier,8,code+' historical completion is retained');
 assert.equal(v4State.courses[code].cursor,0,code+' reopens at its corrected representation');
}
assert.equal(v4State.courses.A02.cursor,8,'unchanged route is not reopened');
const v4Changed=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:4,courses:Object.fromEntries(['A05','R02','L01','N03','C03','D01'].map(code=>[code,{frontier:8,cursor:8}]))})});
const v4ChangedState=JSON.parse(v4Changed.storage.tianle_amc8_question_design_v1);
for(const [code,index] of Object.entries({A05:1,R02:0,L01:1,N03:0,C03:1,D01:0})){
 assert.equal(v4ChangedState.courses[code].frontier,8,code+' preserves historical completion');
 assert.equal(v4ChangedState.courses[code].cursor,index,code+' reopens at the new operation');
}
const guided=boot();guided.click('course',{code:'R03'});guided.input(COURSES.R03.steps[0].answer);
guided.click('check');assert(guided.root.innerHTML.includes('答对了！'),'valid independent number does not require a fixed card order');
guided.click('previous');guided.click('exploreToggle');
assert(guided.root.innerHTML.includes('explorePick'),'optional explanation cards can be opened on review');
const guidedVoice=boot({},true);guidedVoice.click('course',{code:'R03'});guidedVoice.click('speak');
assert(!guidedVoice.spoken.at(-1).includes('可选卡片'),'hidden optional cards are not spoken');
guidedVoice.click('exploreToggle');guidedVoice.click('speak');
assert(guidedVoice.spoken.at(-1).includes('你也可以用思路卡解释做法')&&guidedVoice.spoken.at(-1).includes('可选卡片'),'opened optional cards can be spoken');
const choiceVoice=boot({},true);choiceVoice.click('course',{code:'R01'});
choiceVoice.click('speakOption',{index:'0'});
assert.equal(choiceVoice.spoken.at(-1),COURSES.R01.steps[0].options[0]);
choiceVoice.click('check');assert(choiceVoice.root.innerHTML.includes('先选一个答案'),'reading an option does not select it');
const fold=boot();fold.click('course',{code:'G07'});fold.click('netFoldFace',{index:'4'});
assert(fold.root.innerHTML.includes('先把 D 沿边折起'),'outer E needs its parent D');
fold.input(6);fold.click('check');assert(!fold.root.innerHTML.includes('答对了！'),'number alone cannot replace folding action');
for(const i of [0,1,3,4,5])fold.click('netFoldFace',{index:String(i)});
fold.input(6);fold.click('check');assert(fold.root.innerHTML.includes('答对了！'),'all six faces folded and counted');
for(const [code,data] of Object.entries(BREADTH)){
 const [step,wrong,message]=data.diagnostic,task=COURSES[code].steps[step];
 const diagnostic=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{[code]:{frontier:step,cursor:step}}})});
 diagnostic.click('course',{code});
 if(task.mode==='choice')diagnostic.click('choice',{index:String(wrong)});
 else if(task.mode==='number')diagnostic.input(wrong);
 else if(task.mode==='gridSelect')for(const index of [0,1,4,5])diagnostic.click('cutCell',{index:String(index)});
 else assert.fail(code+' diagnostic mode unsupported');
 diagnostic.click('check');
 assert(diagnostic.root.innerHTML.includes(message),code+' displays its conceptual feedback');
 assert(!diagnostic.root.innerHTML.includes('答对了！'),code+' error cannot pass');
 assert.equal(JSON.parse(diagnostic.storage.tianle_amc8_question_design_v1).courses[code].frontier,step,code+' error cannot advance');
}
const countGrid=boot();countGrid.click('course',{code:'A03'});
assert(countGrid.root.innerHTML.includes('先看一个不同的例子'));
for(const code of FOCUS_CODES){
 const tasks=code==='C01'?FRUIT_TASKS:COURSES[code].steps;
 assert.equal(tasks.filter(t=>t.worked).length,2,code+' two spaced worked examples');
 assert(tasks.filter(t=>t.worked).every(t=>t.phase==='学'),code+' models appear only in learning phase');
 for(const task of tasks.filter(t=>t.worked))assert(task.worked.title&&task.worked.steps.length===3,code+' complete scaffold');
 for(const task of FOCUS_REVIEW[code]){
  assert(task.prompt&&task.explain&&task.phase==='巩固'&&!task.hint,task.id+' independent prompt and explanation');
  if(task.mode==='choice')assert(task.options.length>task.answer,task.id+' answer present');
  else if(['multi','gridSelect','sides','sequence'].includes(task.mode))assert(task.answer.length>0,task.id+' answer present');
  else if(task.mode==='number')assert(Number.isFinite(task.answer),task.id+' numeric answer');
 }
}
countGrid.click('model');assert(countGrid.root.innerHTML.includes('任选2格涂色'));
for(const i of [1,2,3])countGrid.click('cutCell',{index:String(i)});
countGrid.click('check');assert(countGrid.root.innerHTML.includes('答对了！'),'any three cells represent 3/4');
const countWrong=boot();countWrong.click('course',{code:'A03'});for(const i of [1,3])countWrong.click('cutCell',{index:String(i)});
countWrong.click('check');assert(!countWrong.root.innerHTML.includes('答对了！'),'only two cells cannot represent 3/4');
const quarter=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{A04:{frontier:1,cursor:1}}})});quarter.click('course',{code:'A04'});
for(const i of [5,8,11,14,17])quarter.click('cutCell',{index:String(i)});
quarter.click('check');assert(quarter.root.innerHTML.includes('答对了！'),'any five of twenty cells represent 25%');
const conceptual=boot();conceptual.click('course',{code:'C04'});
for(const x of ['A','+','R'])conceptual.click('+-'.includes(x)?'op':'term',{id:x});
conceptual.click('check');assert(!conceptual.root.innerHTML.includes('答对了！'),'7 from overlapping wrong regions must fail');
conceptual.click('clear');for(const x of ['B','+','A','-','O'])conceptual.click('+-'.includes(x)?'op':'term',{id:x});
conceptual.click('check');assert(conceptual.root.innerHTML.includes('答对了！'),'semantic alternate order in C04');
assert.equal(REMAINING_COURSES.C04.steps[6].mode,'formula','18+14-5 requires a constructed expression');
const delay=24*60*60*1000;
for(const code of FOCUS_CODES){
 const clock={now:1_700_000_000_000},prior={contentRevision:5,fruitFrontier:code==='C01'?26:0,fruitCursor:code==='C01'?26:0,courses:code==='C01'?{}:{[code]:{frontier:8,cursor:8}}};
 const review=boot({tianle_amc8_question_design_v1:JSON.stringify(prior)},false,clock);
 const savedReview=JSON.parse(review.storage.tianle_amc8_question_design_v1).reviews[code];
 assert.equal(savedReview.dueAt,clock.now+delay,code+' migrates old completed route without an instant mastery star');
 review.click('transfer',{code});assert(!review.root.innerHTML.includes('换情境，自己想办法'),code+' gate before 24 hours');
 clock.now+=delay;review.click('home');review.click('transfer',{code});
 assert(review.root.innerHTML.includes('换情境，自己想办法'),code+' available after delay');
 assert(!review.root.innerHTML.includes('小提示'),code+' independent tasks have no hints');
 solveCourse(review,FOCUS_REVIEW[code][0]);review.click('next');
 const resumed=boot(review.storage,false,clock);resumed.click('transfer',{code});
 assert(resumed.root.innerHTML.includes('2/2'),code+' review resumes after reload');
 solveCourse(review,FOCUS_REVIEW[code][1]);review.click('next');
 const state=JSON.parse(review.storage.tianle_amc8_question_design_v1);
 assert.equal(state.reviews[code].verifiedAt,clock.now,code+' independent first-try pair recorded');
 review.click('home');review.click('network',{code});assert(review.root.innerHTML.includes('隔日两题通过'),code+' historical route verification remains visible within its own scope');
}
const retryClock={now:1_700_000_000_000};
const retry=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{A03:{frontier:8,cursor:8}}})},false,retryClock);
retryClock.now+=delay;retry.click('home');retry.click('transfer',{code:'A03'});
retry.click('check');assert(JSON.parse(retry.storage.tianle_amc8_question_design_v1).reviews.A03.clean,'empty check is not counted as an attempt');
for(const i of [0,1,2,3,4])retry.click('cutCell',{index:String(i)});
retry.click('check');assert(!JSON.parse(retry.storage.tianle_amc8_question_design_v1).reviews.A03.clean,'actual wrong attempt persists');
retry.click('cutCell',{index:'5'});retry.click('check');retry.click('next');solveCourse(retry,FOCUS_REVIEW.A03[1]);retry.click('next');
assert.equal(JSON.parse(retry.storage.tianle_amc8_question_design_v1).reviews.A03.verifiedAt,0,'retry after feedback is practice, not independent verification');
assert(retry.root.innerHTML.includes('上次巩固中有一题先答错了'));
retry.click('transfer',{code:'A03'});assert(!retry.root.innerHTML.includes('换情境，自己想办法'),'new attempt delayed again');
const transferClock={now:1_700_000_000_000};
for(const [code,selection,shouldPass] of [
 ['A04',[0,2,4,5,7,9,10,11,12,13,14,15],true],
 ['G03',[0,3],false]
]){
 const transfer=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{[code]:{frontier:8,cursor:8}}})},false,transferClock);
 transferClock.now+=delay;transfer.click('home');transfer.click('transfer',{code});
 for(const index of selection)transfer.click('cutCell',{index:String(index)});
 transfer.click('check');
 assert.equal(transfer.root.innerHTML.includes('答对了！'),shouldPass,code+' delayed grid meaning');
}
const pairing=boot();pairing.click('course',{code:'C02'});
for(const label of FOUNDATION_COURSES.C02.steps[0].answer.slice(1))pairing.click('multi',{index:String(FOUNDATION_COURSES.C02.steps[0].options.indexOf(label))});
pairing.click('multi',{index:'0'});pairing.click('multi',{index:'4'});
pairing.click('check');assert(!pairing.root.innerHTML.includes('答对了！'),'double selecting same pair rejected');
const perimeter=boot();perimeter.click('course',{code:'G01'});perimeter.click('side',{index:'4'});for(let i=0;i<4;i++)perimeter.click('side',{index:String(i)});
perimeter.click('check');assert(!perimeter.root.innerHTML.includes('答对了！'),'interior cannot count as perimeter');
const place=boot();place.click('course',{code:'A01'});place.click('place',{unit:'tens',delta:'1'});place.click('place',{unit:'ones',delta:'1'});
place.click('check');assert(!place.root.innerHTML.includes('答对了！'),'place value requires both digits');
place.click('progress');assert(place.root.innerHTML.includes('十与个位 · 第1步'),'course mistake appears in review list');
place.click('jump',{code:'A01',step:'0'});assert(place.root.innerHTML.includes('1/8'),'course mistake reopens exact task');
const area=boot();area.click('course',{code:'G03'});for(const i of [0,1,4,5])area.click('cutCell',{index:String(i)});
area.click('check');assert(!area.root.innerHTML.includes('答对了！'),'same cut area but wrong location is rejected');
assert(area.root.innerHTML.includes('右下角的2列2行'),'same-count wrong-position diagnosis');
const exchange=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{A01:{frontier:1,cursor:1}}})});exchange.click('course',{code:'A01'});
for(let i=0;i<9;i++)exchange.click('bundleDot',{index:String(i)});
assert(exchange.root.innerHTML.includes('捆扎框 · 9/10'),'selected dots visibly move into the ten-slot tray');
exchange.click('bundle');assert(!exchange.root.innerHTML.includes('两边都是 23'),'cannot bundle nine loose dots');
exchange.click('check');assert(exchange.root.innerHTML.includes('还差1个一'),'feedback states exactly what action is missing');
exchange.click('bundleDot',{index:'9'});exchange.click('bundleDot',{index:'10'});
assert(exchange.root.innerHTML.includes('捆扎框 · 10/10'),'an eleventh dot cannot enter the tray');
assert(exchange.root.innerHTML.includes('散点盘 · 3个'),'three loose dots remain before the exchange');
exchange.click('check');assert(exchange.root.innerHTML.includes('请点框下方'),'check at 10/10 points to the actual next action');
exchange.click('bundleDot',{index:'9'});assert(exchange.root.innerHTML.includes('捆扎框 · 9/10'),'a tray dot can be put back');
exchange.click('bundleDot',{index:'9'});exchange.click('bundle');
assert(exchange.root.innerHTML.includes('10个已捆成1根十棒'),'the new bar appears in the tray');
assert(exchange.root.innerHTML.includes('现在 2个十＋3个一。总数变化了吗'),'ten ones exchanged into two tens and three ones');
exchange.click('check');assert(exchange.root.innerHTML.includes('再判断两种摆法'),'a bundled bar alone is not enough to pass');
exchange.click('bundleMeaning',{index:'1'});exchange.click('check');assert(!exchange.root.innerHTML.includes('答对了！'),'the child must identify that the total is invariant');
exchange.click('unbundle');assert(exchange.root.innerHTML.includes('捆扎框 · 10/10'),'the exchange can be undone');
exchange.click('bundle');exchange.click('bundleMeaning',{index:'0'});exchange.click('check');assert(exchange.root.innerHTML.includes('答对了！'));
const fullPair=boot();fullPair.click('course',{code:'C02'});assert(fullPair.root.innerHTML.includes('pair-matrix'));
for(let i=0;i<4;i++)fullPair.click('pairCell',{index:String(i)});
fullPair.click('check');assert(fullPair.root.innerHTML.includes('答对了！'),'pair grid supports exhaustive selection');
const ordered=boot();ordered.click('course',{code:'C03'});
for(const item of ['A','B','C'])ordered.click('enumItem',{value:item});ordered.click('enumRecord');
for(const item of ['B','A','C'])ordered.click('enumItem',{value:item});ordered.click('enumRecord');
ordered.click('check');assert(!ordered.root.innerHTML.includes('答对了！'),'two orderings cannot prove all six');
for(const key of REMAINING_COURSES.C03.steps[0].answer.slice(1).filter(x=>x!=='B|A|C')){for(const item of key.split('|'))ordered.click('enumItem',{value:item});ordered.click('enumRecord')}
ordered.click('check');assert(ordered.root.innerHTML.includes('答对了！'),'all six orderings recorded');
const fair=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{D03:{frontier:1,cursor:1}}})});fair.click('course',{code:'D03'});
for(const key of ['正|正','正|反','反|反']){for(const value of key.split('|'))fair.click('enumItem',{value});fair.click('enumRecord')}
fair.click('check');assert(!fair.root.innerHTML.includes('答对了！'),'missing 反正 cannot pass sample-space task');
for(const value of ['反','正'])fair.click('enumItem',{value});fair.click('enumRecord');fair.click('check');assert(fair.root.innerHTML.includes('答对了！'),'ordered outcomes complete');
const arc=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{G04:{frontier:6,cursor:6}}})});arc.click('course',{code:'G04'});assert(arc.root.innerHTML.includes('circleArc')||arc.root.innerHTML.includes('四分之一圆弧'));arc.input(5);arc.click('check');assert(arc.root.innerHTML.includes('答对了！'));
const weighted=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{D02:{frontier:5,cursor:5}}})});weighted.click('course',{code:'D02'});weighted.input(7);weighted.click('check');assert(!weighted.root.innerHTML.includes('答对了！'),'frequency 2 cannot be ignored');weighted.input(6);weighted.click('check');assert(weighted.root.innerHTML.includes('答对了！'));
const folded=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{S01:{frontier:3,cursor:3}}})});folded.click('course',{code:'S01'});folded.click('cutCell',{index:'0'});folded.click('cutCell',{index:'3'});folded.click('check');assert(folded.root.innerHTML.includes('答对了！'),'source mark stays fixed and its mirror is selected');
const invariant=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{S02:{frontier:2,cursor:2}}})});invariant.click('course',{code:'S02'});invariant.click('applyMove');invariant.click('check');assert(!invariant.root.innerHTML.includes('答对了！'),'must observe full operation chain');invariant.click('applyMove');invariant.click('applyMove');invariant.click('parityChoice',{value:'偶'});invariant.click('check');assert(!invariant.root.innerHTML.includes('答对了！'),'tapping alone cannot pass without concept');invariant.click('parityChoice',{value:'奇'});invariant.click('check');assert(invariant.root.innerHTML.includes('答对了！'));
const net=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{G07:{frontier:3,cursor:3}}})});net.click('course',{code:'G07'});net.click('netFace',{index:'0'});net.click('check');assert(!net.root.innerHTML.includes('答对了！'),'adjacent face is not opposite');net.click('netFace',{index:'0'});net.click('netFace',{index:'4'});net.click('check');assert(net.root.innerHTML.includes('答对了！'));
const upgradeClock={now:1_700_000_000_000},legacy=boot({tianle_amc8_question_design_v1:JSON.stringify({courses:{C03:{frontier:8,cursor:8}},reviews:{C03:{dueAt:1,cursor:2,clean:true,verifiedAt:1234}}})},false,upgradeClock);
let priorState=JSON.parse(legacy.storage.tianle_amc8_question_design_v1);
assert.equal(priorState.courses.C03.frontier,8,'upgrade preserves old route frontier');
assert.equal(priorState.courses.C03.cursor,0,'upgrade opens the first revised task');
assert.equal(priorState.legacyReviews.C03,1234,'previous review evidence remains recorded');
assert.equal(priorState.reviews.C03.verifiedAt,0,'old star cannot certify new content');
legacy.click('knowledge');assert(legacy.root.innerHTML.includes('新版待复习'),'historical upgrade status is retained in the parent knowledge map');
legacy.click('course',{code:'C03'});
assert(!legacy.root.innerHTML.includes('回到最新进度'),'cannot skip revised work via old frontier button');
legacy.click('frontier');assert(legacy.root.innerHTML.includes('1/8'),'old frontier action cannot certify revised work');
legacy.click('nextSolved');assert(legacy.root.innerHTML.includes('1/8'),'old completed frontier cannot skip first revised task');
legacy.click('progress');legacy.click('jump',{code:'C03',step:'7'});assert(legacy.root.innerHTML.includes('本机学习进度'),'progress jump cannot skip revised work');
legacy.click('course',{code:'C03'});
for(const [i,t] of REMAINING_COURSES.C03.steps.entries()){
 solveCourse(legacy,t);legacy.click('next');
 if(i===0){
  legacy.click('previous');assert(legacy.root.innerHTML.includes('data-action="nextSolved"'),'newly answered revised step can be revisited');
  legacy.click('nextSolved');assert(legacy.root.innerHTML.includes('2/8'),'revised step advances without resubmission');
  legacy.click('nextSolved');assert(legacy.root.innerHTML.includes('2/8'),'next revised task remains gated');
  const resumed=boot(legacy.storage,false,upgradeClock);resumed.click('course',{code:'C03'});resumed.click('previous');
  resumed.click('nextSolved');assert(resumed.root.innerHTML.includes('2/8'),'revised answered frontier survives reload');
 }
}
priorState=JSON.parse(legacy.storage.tianle_amc8_question_design_v1);
assert.equal(priorState.upgradePending.C03,undefined);
assert.equal(priorState.reviews.C03.dueAt,upgradeClock.now+delay,'new delayed review starts after revised route');
const share=boot();share.click('course',{code:'D02'});share.click('check');assert(!share.root.innerHTML.includes('答对了！'),'unequal distribution rejected');
share.click('movePile',{index:'2'});share.click('movePile',{index:'0'});
assert(share.root.innerHTML.includes('3颗')&&share.root.innerHTML.includes('5颗'),'transfer visible');
share.click('resetMoves');assert(share.root.innerHTML.includes('2颗')&&share.root.innerHTML.includes('6颗'),'reset restores starting quantities');
const bridgeSeed={tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,fruitFrontier:0,fruitCursor:0,seen:{},courses:{D03:{frontier:4,cursor:4}}})};
const spinner=boot(bridgeSeed);spinner.click('course',{code:'D03'});assert(spinner.root.innerHTML.includes('class="spinner"'),'fair wheel is drawn as six sectors');
const preview=boot();preview.click('course',{code:'A01'});preview.click('sample',{code:'A01'});
assert(preview.root.innerHTML.includes('哪张卡表示 16'),'course preview is reachable');
preview.click('choice',{index:'1'});preview.click('check');preview.click('next');
assert(preview.root.innerHTML.includes('十与个位'),'preview returns to its course');
const unit=boot(b.storage);
for(const [id,t] of Object.entries(SAMPLE_TASKS)){
 unit.click('sample',{code:id});
 if(t.mode==='number')unit.input(t.answer);
 if(t.mode==='choice')unit.click('choice',{index:String(t.answer)});
 if(t.mode==='multi')for(const index of t.answer)unit.click('multi',{index:String(index)});
 if(id==='G03')assert.equal((unit.root.innerHTML.match(/class="cell filled"/g)||[]).length,12,'cut-out square must show 12 filled cells');
 if(id==='A02')assert.equal((unit.root.innerHTML.match(/class="cell /g)||[]).length,10,'ten frame really has 10 cells');
 unit.click('check');assert(unit.root.innerHTML.includes('答对了！'),id+' sample answer');
 unit.click('next');
}
assert.equal(Object.keys(JSON.parse(unit.storage.tianle_amc8_question_design_v1).seen).length,33);
unit.click('home');
assert(unit.root.innerHTML.includes('今天想练什么'));unit.click('knowledge');assert(unit.root.innerHTML.includes('33 盏知识灯'));
const parent=boot(b.storage);parent.click('catalog');assert(parent.root.innerHTML.includes('20 届 · 500 个题位'));
assert(parent.root.innerHTML.includes(`${verifiedExamIds.length}/500 题`),'public index count comes from reviewed records');
assert(parent.root.innerHTML.includes('本轮已核原题与独立解法'),'current original-PDF review shown on first page');
assert.equal((parent.root.innerHTML.match(/class="catalog-item"/g)||[]).length,25);
parent.click('page',{delta:'1'});assert(parent.root.innerHTML.includes('2 / 20'));
parent.click('page',{delta:'18'});assert(parent.root.innerHTML.includes('20 / 20'));
assert(!parent.root.innerHTML.includes('旧记录有独立求解线索，待核原题'),'historical 2023 notes are resolved');
const beforeOriginal=FRUIT_TASKS.findIndex(t=>t.prompt.includes('苹果 18 人、香蕉 14 人、共同 5 人，不同的人数'));
assert(beforeOriginal>=0);
const voiceSeed={tianle_amc8_question_design_v1:JSON.stringify({fruitAt:beforeOriginal,seen:{}})};
const silent=boot(voiceSeed);silent.click('fruit');silent.click('speak');assert(silent.speechStatus.textContent.includes('不支持朗读'));
const spoken=boot(voiceSeed,true);spoken.click('fruit');spoken.click('speak');assert.equal(spoken.spoken.length,1);assert(!spoken.spoken[0].includes('27'),'reading must not announce the solution before answering');
spoken.click('person',{index:'0'});spoken.utterances[0].onerror();assert(spoken.speechStatus.textContent.includes('朗读未成功'),'speech failure survives an answer rerender');
const courseVoice=boot({},true);courseVoice.click('course',{code:'L03'});courseVoice.click('speak');assert(courseVoice.spoken[0].includes('红、蓝'));
const scaffoldVoice=boot({},true);scaffoldVoice.click('course',{code:'A02'});scaffoldVoice.click('model');scaffoldVoice.click('speakWorked');assert(scaffoldVoice.spoken.at(-1).includes('7＋3'));
scaffoldVoice.click('hint');scaffoldVoice.click('speakHint');assert(scaffoldVoice.spoken.at(-1).includes('上排5格'));
scaffoldVoice.click('tenCell',{index:'6'});scaffoldVoice.click('check');scaffoldVoice.click('speakFeedback');assert(scaffoldVoice.spoken.at(-1).includes('只点空着的格子'));
const guidedEvidence=JSON.parse(scaffoldVoice.storage.tianle_amc8_question_design_v1).attempts.at(-1);
assert.equal(guidedEvidence.modelViewed,true);
assert.equal(guidedEvidence.hintEvents.length,1);
assert.equal(guidedEvidence.independent,false,'viewing a model or hint cannot count as independent');
const independentEvidence=boot();independentEvidence.click('course',{code:'R02'});
for(let i=0;i<8;i++){independentEvidence.click('movePile',{index:'0'});independentEvidence.click('movePile',{index:String(1+Math.floor(i/2))})}
independentEvidence.click('check');
assert(independentEvidence.root.innerHTML.includes('答对了！'));
const operationEvidence=JSON.parse(independentEvidence.storage.tianle_amc8_question_design_v1).attempts.at(-1);
assert.equal(operationEvidence.independent,false,'learning action is recorded separately from a formal assessment');assert.equal(operationEvidence.unassistedFirstSubmissionCorrect,true);assert.equal(operationEvidence.evidenceScope,'legacy-route');
assert.equal(operationEvidence.skillIds.join(','),'R02.01','only the curated partial link is reported');
assert.deepEqual(operationEvidence.operationSummary.values,[0,2,2,2,2]);
const balance=boot({tianle_amc8_question_design_v1:JSON.stringify({contentRevision:5,courses:{L01:{frontier:1,cursor:1}}})});
balance.click('course',{code:'L01'});balance.input(4);balance.click('check');
assert(!balance.root.innerHTML.includes('答对了！'),'answer alone cannot skip equal action on the balance');
balance.click('balanceTake');balance.click('balanceUndo');balance.click('check');
assert(!balance.root.innerHTML.includes('答对了！'),'undo restores the initial state');
balance.click('balanceTake');balance.input(5);balance.click('check');
assert(!balance.root.innerHTML.includes('答对了！'),'substitution must preserve original equality');
balance.input(4);balance.click('check');assert(balance.root.innerHTML.includes('答对了！'));
// Delivery audit regressions: an unchanged fixed task is one instance across visits.
const STORE_KEY='tianle_amc8_question_design_v1';
const stateOf=b=>JSON.parse(b.storage[STORE_KEY]);
const latestAttempt=b=>stateOf(b).attempts.at(-1);
const repeated=boot();repeated.click('sample',{code:'A01'});repeated.click('choice',{index:'1'});repeated.click('check');
assert.equal(latestAttempt(repeated).taskInstanceId,'SAMPLE-A01');
assert.equal(latestAttempt(repeated).independent,false,'sample first success is practice');assert.equal(latestAttempt(repeated).unassistedFirstSubmissionCorrect,true);
repeated.click('home');repeated.click('sample',{code:'A01'});repeated.click('choice',{index:'1'});repeated.click('check');
assert.equal(latestAttempt(repeated).firstSubmissionCorrect,false,'returning home cannot reset first submission');
assert.equal(latestAttempt(repeated).independent,false);
const repeatReload=boot(repeated.storage);repeatReload.click('sample',{code:'A01'});repeatReload.click('choice',{index:'1'});repeatReload.click('check');
assert.equal(latestAttempt(repeatReload).independent,false,'reload cannot count the same success again');
assert.equal(stateOf(repeatReload).attempts.filter(a=>a.independent).length,0);assert.equal(stateOf(repeatReload).attempts.filter(a=>a.unassistedFirstSubmissionCorrect).length,1);
assert.equal(new Set(stateOf(repeated).attempts.map(a=>a.id)).size,2,'same-millisecond submissions have distinct IDs');
repeatReload.click('sample',{code:'A02'});repeatReload.input(SAMPLE_TASKS.A02.answer);repeatReload.click('check');
assert.equal(latestAttempt(repeatReload).taskInstanceId,'SAMPLE-A02');
assert.equal(latestAttempt(repeatReload).independent,false,'different sample remains practice');assert.equal(latestAttempt(repeatReload).unassistedFirstSubmissionCorrect,true,'different fixed task has its own history');
const hintBeforeSubmit=boot();hintBeforeSubmit.click('course',{code:'A02'});hintBeforeSubmit.click('hint');
const hintReload=boot(hintBeforeSubmit.storage);hintReload.click('course',{code:'A02'});solveCourse(hintReload,COURSES.A02.steps[0]);
assert.equal(latestAttempt(hintReload).independent,false,'unsubmitted hint exposure survives reload');
assert.equal(latestAttempt(hintReload).hintEvents[0].kind,'hint');
const modelBeforeSubmit=boot();modelBeforeSubmit.click('course',{code:'A02'});modelBeforeSubmit.click('model');
const modelReload=boot(modelBeforeSubmit.storage);modelReload.click('course',{code:'A02'});solveCourse(modelReload,COURSES.A02.steps[0]);
assert.equal(latestAttempt(modelReload).modelViewed,true);
assert.equal(latestAttempt(modelReload).independent,false);
const exploration=boot({},true);exploration.click('course',{code:'R01'});exploration.click('speak');
const card=COURSES.R01.steps[0].explore.cards[0];
assert(!exploration.spoken.at(-1).includes(card),'closed optional scaffolding is not read with the question');
const voiceCount=exploration.spoken.length;exploration.click('speakExploreCard',{index:'0'});assert.equal(exploration.spoken.length,voiceCount);
exploration.click('exploreToggle');exploration.click('speakExploreCard',{index:'0'});assert.equal(exploration.spoken.at(-1),card);
const explorationReload=boot(exploration.storage);explorationReload.click('course',{code:'R01'});solveCourse(explorationReload,COURSES.R01.steps[0]);
assert.equal(latestAttempt(explorationReload).independent,false,'optional reasoning cards count as support');
assert.equal(latestAttempt(explorationReload).hintEvents[0].kind,'explore');
const wrongReopen=boot();wrongReopen.click('sample',{code:'A01'});wrongReopen.click('choice',{index:'0'});wrongReopen.click('check');
wrongReopen.click('home');wrongReopen.click('sample',{code:'A01'});wrongReopen.click('choice',{index:'1'});wrongReopen.click('check');
assert.equal(latestAttempt(wrongReopen).firstSubmissionCorrect,false,'wrong answer cannot be erased by re-entry');
const truncatedHistory=boot({[STORE_KEY]:JSON.stringify({storageVersion:2,contentRevision:5,taskHistory:{'5:SAMPLE-A01':{submissions:2001,modelViewed:false,hintEvents:[]}},attempts:[]})});
truncatedHistory.click('sample',{code:'A01'});truncatedHistory.click('choice',{index:'1'});truncatedHistory.click('check');
assert.equal(latestAttempt(truncatedHistory).independent,false,'history survives the 2000-log retention limit');
const priorV5=boot({[STORE_KEY]:JSON.stringify({storageVersion:2,contentRevision:5,fruitFrontier:26,fruitCursor:26,courses:{A03:{frontier:8,cursor:8}},taskHistory:{'5:A03-1':{submissions:1,modelViewed:false,hintEvents:[]}},attempts:[]})});
assert.equal(stateOf(priorV5).courses.A03.frontier,8);
assert.equal(stateOf(priorV5).upgradePending.A03,undefined,'adding micro tasks does not reopen unchanged V5 route');
assert.equal(stateOf(priorV5).taskHistory['5:A03-1'].submissions,1,'existing task key remains V5');
const priorV6=boot({[STORE_KEY]:JSON.stringify({storageVersion:2,contentRevision:6,courses:{A02:{frontier:8,cursor:8}},taskHistory:{'6:M-A02-01-1':{submissions:1,modelViewed:false,hintEvents:[]}},attempts:[]})});
assert.equal(stateOf(priorV6).upgradePending.A02,undefined,'new workshop tasks do not reopen existing V6 routes');
priorV6.click('micro',{code:'A02.01'});for(const i of MICRO_TASKS['A02.01'].answer)priorV6.click('sortObject',{index:String(i)});priorV6.click('check');
assert.equal(latestAttempt(priorV6).contentVersion,6);assert.equal(latestAttempt(priorV6).independent,false,'V6 micro history survives rc4');
const legacyData=JSON.stringify({contentRevision:5,courses:{R02:{frontier:1,cursor:0}},attempts:[{taskInstanceId:'R02-1',contentVersion:5,independent:true,firstSubmissionCorrect:true,gradingResult:'correct'}]});
const oldLogs=boot({[STORE_KEY]:legacyData});
assert.equal(oldLogs.storage[STORE_KEY+'_backup_before_v2'],legacyData,'exact original JSON backed up before migration');
assert.equal(stateOf(oldLogs).attempts[0].legacyIndependent,true);
assert.equal(stateOf(oldLogs).attempts[0].independent,false,'old per-visit flags cannot establish independent evidence');
oldLogs.click('course',{code:'R02'});solveCourse(oldLogs,COURSES.R02.steps[0]);assert.equal(latestAttempt(oldLogs).independent,false);
const migratedAgain=boot(oldLogs.storage);assert.equal(migratedAgain.storage[STORE_KEY+'_backup_before_v2'],legacyData,'migration does not replace the backup');
migratedAgain.click('todayPin',{code:'A01'});assert.equal(stateOf(migratedAgain).attempts[0].legacyIndependent,true,'reload preserves the original legacy flag as history');
assert.equal(stateOf(migratedAgain).courses.R02.frontier,1,'evidence correction preserves route progress');
const writeFault={write:true};const noSave=boot({},false,{now:Date.now()},writeFault);noSave.click('sample',{code:'A01'});noSave.click('choice',{index:'1'});noSave.click('check');
assert.equal(noSave.storage[STORE_KEY],undefined);assert.equal(noSave.storageStatus.hidden,false);assert(noSave.storageStatus.textContent.includes('未能保存'));
writeFault.write=false;noSave.click('home');noSave.click('todayPin',{code:'A01'});assert.equal(noSave.storageStatus.hidden,true,'successful later write clears the warning');
const badJson=boot({[STORE_KEY]:'{broken'});assert.equal(badJson.storageStatus.hidden,false);badJson.click('todayPin',{code:'A01'});assert.equal(badJson.storage[STORE_KEY],'{broken','damaged original is not overwritten');
const noBackup=boot({[STORE_KEY]:legacyData},false,{now:Date.now()},{backup:true});noBackup.click('todayPin',{code:'A01'});
assert.equal(noBackup.storage[STORE_KEY],legacyData,'failed backup prevents migration writes');assert(noBackup.storageStatus.textContent.includes('未能备份'));
const readBlocked=boot({},false,{now:Date.now()},{read:true});assert.equal(readBlocked.storageStatus.hidden,false);
const future=JSON.stringify({storageVersion:99,contentRevision:99});const futureState=boot({[STORE_KEY]:future});futureState.click('todayPin',{code:'A01'});assert.equal(futureState.storage[STORE_KEY],future);
require('./test_combin')({assert,boot,microState,microLatest,solveCombin,solveStage,COMBIN_TASKS,STAGED_TASKS,release});
require('./test_chart')({assert,boot,microState,microLatest,solveChart,solveStage,CHART_TASKS,STAGED_TASKS,release});
require('./test_stats')({assert,boot,microState,microLatest,solveStats,solveStage,STATS_TASKS,STAGED_TASKS,release});
require('./test_chance')({assert,boot,microState,microLatest,solveChance,solveStage,CHANCE_TASKS,STAGED_TASKS,release});
require('./test_motion')({assert,boot,microState,microLatest,solveMotion,solveStage,MOTION_TASKS,STAGED_TASKS,release});
require('./test_invariant')({assert,boot,microState,microLatest,solveInvariant,solveStage,INVARIANT_TASKS,STAGED_TASKS,release});
require('./test_sets')({assert,boot,microState,microLatest,solveSets,solveStage,SETS_TASKS,STAGED_TASKS,release});
require('./test_solid')({assert,boot,microState,microLatest,solveSolid,solveStage,SOLID_TASKS,STAGED_TASKS,release});
require('./test_right')({assert,boot,microState,microLatest,solveRight,solveStage,RIGHT_TASKS,STAGED_TASKS,release});
require('./test_similarity')({assert,boot,microState,microLatest,solveSimilar,solveStage,SIMILAR_TASKS,STAGED_TASKS,release});
require('./test_geometry')({assert,boot,microState,microLatest,solveComposite,solveCircle,solveStage,COMPOSITE_TASKS,CIRCLE_TASKS,STAGED_TASKS,release});
const countsView=boot();countsView.click('knowledge');
assert(countsView.root.innerHTML.includes(`<strong>${allTaskModes.size+33+66+require('./joint_families.json').families.reduce((n,f)=>n+f.instances.length,0)}</strong>`),'parent map counts all compiled native and shared task instances');
assert(countsView.root.innerHTML.includes('<strong>0</strong><span>已发布微技能</span>'));
assert.deepEqual(readCsv('\ufeffid,note\r\nA,"一,二\n三""四"\r\n').rows,[{id:'A',note:'一,二\n三"四'}]);
assert.throws(()=>readCsv('id,note\nA,"unfinished'));
const built=fs.readFileSync(path.join(dir,'..','index.html'),'utf8');
assert(built.includes(`aria-label="网页版本 ${release.label}">${release.label}</span>`),'compiled version information includes the current version');
const embeddedScripts=[...built.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]).join('\n');
const standalone=boot({},false,{now:Date.now()},{},embeddedScripts);
assert.equal((standalone.root.innerHTML.match(/data-action="topicSelect"/g)||[]).length,33,'compiled entry executes its embedded scripts and starts on topic selection');
standalone.click('sample',{code:'A01'});standalone.click('choice',{index:'1'});standalone.click('check');
assert.equal(latestAttempt(standalone).taskInstanceId,'SAMPLE-A01');
console.log('PASS: 33 units / 282 route steps / 66 fixed reviews / 33 samples / 179 object tasks / 179 manipulatives staged instances for 179 skills; fraction, percent, integer, ratio, rate, journey, scale, equation, constraint, pattern, coordinate, grouping, factor, common relation, cycle, measurement, angle, composite figure, circle, similarity, right-triangle, solid, set-identity, enumeration, chart, statistics, probability, transform and invariant states, migration, stage clock and first-answer gates, grading, speech, stable IDs, evidence deduplication and storage failures (simulated DOM).');
