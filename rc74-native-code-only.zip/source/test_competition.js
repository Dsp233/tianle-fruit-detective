'use strict';
const assert=require('assert'),fs=require('fs'),old=require('./competition'),c=require('./competition_catalog'),{integratedOracle}=require('./competition_test_oracles');
const numeric=x=>String(x).includes('/')?String(x).split('/').map(Number).reduce((a,b)=>a/b):Number(x);
const same=(a,b)=>Math.abs(numeric(a)-numeric(b))<1e-9;
const memo=new Map();
function cached(key,fn){if(!memo.has(key))memo.set(key,fn());return memo.get(key)}
function routeOracle(m){let all=0,through=0;function walk(x,y,p){if(x===m.w&&y===m.h){all++;if(p)through++;return}if(x<m.w)walk(x+1,y,p||x+1===m.x&&y===m.y);if(y<m.h)walk(x,y+1,p||x===m.x&&y+1===m.y)}walk(0,0,false);return {all,through}}
function cubeOracle(n,paint){let count=0;for(let x=0;x<n;x++)for(let y=0;y<n;y++)for(let z=0;z<n;z++)if([x,y,z].filter(v=>v===0||v===n-1).length===paint)count++;return count}
function permutationOracle(n){let count=0;function visit(used,lastEven){if(used.length===n){count++;return}for(let v=1;v<=n;v++)if(!used.includes(v)&&!(lastEven&&v%2===0))visit([...used,v],v%2===0)}visit([],false);return count}
function dominoOracle(w,h){
 const removed=(x,y)=>x===0&&y===0||x===w-1&&y===h-1,match=new Map();let count=0;
 function augment(x,y,seen){for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const a=x+dx,b=y+dy,key=a+','+b;if(a<0||a>=w||b<0||b>=h||removed(a,b)||seen.has(key))continue;seen.add(key);const prior=match.get(key);if(!prior||augment(...prior,seen)){match.set(key,[x,y]);return true}}return false}
 for(let y=0;y<h;y++)for(let x=0;x<w;x++)if((x+y)%2===0&&!removed(x,y)&&augment(x,y,new Set()))count++;return count;
}
function oracle(task){
 const p=task.competition,m=p.math;let answer,extension;
 if(p.legacyIdentity)return integratedOracle(task);
 switch(p.family){
 case 'reverseDigits':{const candidates=[];for(let v=10;v<100;v++){const a=Math.floor(v/10),b=v%10;if(a>b&&a+b===m.a+m.b&&v-(10*b+a)===9*(m.a-m.b))candidates.push(v)}assert.equal(candidates.length,1);answer=candidates[0];extension=10*(answer%10)+Math.floor(answer/10);break;}
 case 'groupProducts':answer=m.a*m.price+m.b*m.price-m.c;extension=(m.a+m.b+1)*m.price-m.c;break;
 case 'fractionBackwards':{let v=0;for(let n=1;n<1000;n++){const first=n/2,second=(n-first)/3;if(Number.isInteger(first)&&Number.isInteger(second)&&n-first-second===m.left)v=n}answer=v;extension=v/6;break;}
 case 'percentRoundTrip':{const raised=m.start+m.start*m.percent/100,final=raised-raised*m.percent/100;answer=m.start-final;extension=final;break;}
 case 'squareBorder':{let border=0;for(let y=0;y<m.n+2;y++)for(let x=0;x<m.n+2;x++)if(x===0||y===0||x===m.n+1||y===m.n+1)border++;answer=border;extension=(m.n+4)**2-m.n**2;break;}
 case 'ratioEqualize':{const blue=m.b*m.unit,red=m.a*m.unit;assert.equal(red+(m.b-m.a)*m.unit,blue);answer=blue;extension=red+blue;break;}
 case 'packPrice':{const costs=[];for(let packs=0;3*packs<=m.count;packs++)costs.push(packs*m.pack+(m.count-3*packs)*m.single);answer=Math.min(...costs);extension=m.count*m.single-answer;break;}
 case 'equalDistanceSpeed':{const distance=120*m.speed,time=distance/m.speed+distance/(2*m.speed);answer=2*distance/time;extension=2;break;}
 case 'oppositeScale':answer=m.a*m.old/m.b;extension=(m.b/m.a)**2;break;
 case 'balanceCancel':{const x=[];for(let v=1;v<100;v++)if((m.a+1)*v+m.b===m.a*v+m.b+m.x)x.push(v);assert.equal(x.length,1);answer=x[0];extension=2*x[0];break;}
 case 'tickets':{const total=m.adults*m.adult+(m.people-m.adults)*m.child;const legal=[];for(let v=0;v<=m.people;v++)if(v*m.adult+(m.people-v)*m.child===total)legal.push(v);assert.equal(legal.length,1);answer=legal[0];extension=m.child+m.adult;break;}
 case 'recurrenceBackwards':{const values=[m.first,m.second];while(values.length<=m.n)values.push(values.at(-1)+values.at(-2));answer=values[0];extension=values[m.n];break;}
 case 'linearTable':{const y1=m.k*m.x+m.b,y2=m.k*(m.x+2)+m.b,mult=(y2-y1)/2;answer=y1+mult*(m.target-m.x);extension=3*mult;break;}
 case 'divisibleDigits':{const legal=[];for(let n=1000;n<10000;n++)if(Math.floor(n/1000)===m.a&&Math.floor(n/10)%10===m.b&&n%9===0&&n%5===0)legal.push(n);answer=Math.max(...legal);extension=legal.length;break;}
 case 'factorBalance':{let best=Infinity,pairs=0;for(let a=1;a<=m.product;a++)for(let b=a;b<=m.product;b++)if(a*b===m.product){best=Math.min(best,a+b);pairs++}answer=best;extension=pairs;break;}
 case 'bells':{let count=0;for(let t=1;t<=m.duration;t++)if(t%m.a===0&&t%m.b===0)count++;answer=count;extension=count+1;break;}
 case 'lastDigit':answer=Number(BigInt(m.base)**BigInt(m.exponent)%10n);extension=Number(BigInt(m.base)**BigInt(m.exponent+1)%10n);break;
 case 'fixedPerimeter':{const areas=[];for(let a=1;a<m.half;a++)areas.push(a*(m.half-a));answer=Math.max(...areas);const next=[];for(let a=1;a<m.half+2;a++)next.push(a*(m.half+2-a));extension=Math.max(...next);break;}
 case 'outsideAngle':answer=180-(180-m.apex)/2;extension=180-m.apex;break;
 case 'overlapSquares':case 'overlapProbability':{const one=new Set(),two=new Set();for(let y=0;y<m.n;y++)for(let x=0;x<m.n;x++){one.add(x+','+y);two.add((x+m.dx)+','+(y+m.dy))}const overlap=[...one].filter(k=>two.has(k)).length,union=new Set([...one,...two]).size;answer=p.family==='overlapSquares'?union:overlap/union;extension=p.family==='overlapSquares'?overlap:(union-overlap)/union;break;}
 case 'circleRoute':answer=Math.min(m.steps*m.unit,(m.sectors-m.steps)*m.unit);extension=Math.abs((m.sectors-m.steps)*m.unit-m.steps*m.unit);break;
 case 'similarAreaPerimeter':answer=m.a*m.unit*Math.sqrt(m.b*m.b/(m.a*m.a));extension=4;break;
 case 'ladderShift':answer=Math.sqrt((5*m.k)**2-(3*m.k)**2)-Math.sqrt((5*m.k)**2-(4*m.k)**2);extension=5*m.k-Math.sqrt((5*m.k)**2-(4*m.k)**2);break;
 case 'paintedCube':answer=cached('cube2-'+m.n,()=>cubeOracle(m.n,2));extension=cached('cube0-'+m.n,()=>cubeOracle(m.n,0));break;
 case 'exactlyOneSet':{const a=new Set(Array.from({length:m.a},(_,i)=>i)),b=new Set([...Array.from({length:m.both},(_,i)=>i),...Array.from({length:m.b-m.both},(_,i)=>i+m.a)]);answer=[...new Set([...a,...b])].filter(v=>a.has(v)!==b.has(v)).length;extension=new Set([...a,...b]).size;break;}
 case 'gridDetour':case 'routeProbability':{const {all,through}=routeOracle(m);answer=p.family==='gridDetour'?all-through:(all-through)/all;extension=p.family==='gridDetour'?through:through/all;break;}
 case 'adjacentLine':{const n=m.n;answer=cached('adjacent'+n,()=>{let count=0;function perm(a){if(a.length===n){if(Math.abs(a.indexOf(1)-a.indexOf(2))===1)count++;return}for(let i=1;i<=n;i++)if(!a.includes(i))perm([...a,i])}perm([]);return count});extension=answer/2;break;}
 case 'restrictedTeam':{let all=0,exactOne=0;for(let a=1;a<=m.n;a++)for(let b=a+1;b<=m.n;b++)for(let z=b+1;z<=m.n;z++){const special=[a,b,z].filter(v=>v<=2).length;if(special<=1)all++;if(special===1)exactOne++}answer=all;extension=exactOne;break;}
 case 'digitComplement':{let count=0,lastOnly=0;for(let n=0;n<10**m.length;n++){const s=String(n).padStart(m.length,'0');if(s.includes(String(m.digit)))count++;if(s.at(-1)===String(m.digit)&&!s.slice(0,-1).includes(String(m.digit)))lastOnly++}answer=count;extension=lastOnly;break;}
 case 'chartScale':answer=(m.b+m.c)*(m.a*m.unit/m.a);extension=(m.a+m.b+m.c)*m.unit;break;
 case 'missingAverage':answer=m.count*m.mean-(m.count-1)*m.other;extension=m.mean+2;break;
 case 'diceSum':{let good=0;for(let a=1;a<=m.faces;a++)for(let b=1;b<=m.faces;b++)if(a+b===m.target)good++;answer=good/(m.faces*m.faces);extension=1-answer;break;}
 case 'foldHoles':{const points=[];for(let i=0;i<m.interior;i++)points.push([i+1,10+i]);for(let i=0;i<m.edge;i++)points.push([0,20+i]);if(m.center)points.push([0,0]);const expanded=new Set();for(const [x,y] of points)for(const a of [-1,1])for(const b of [-1,1])expanded.add(a*x+','+b*y);answer=expanded.size;extension=answer+4;break;}
 case 'checkerDomino':answer=cached('domino'+m.w+','+m.h,()=>dominoOracle(m.w,m.h));extension=m.w*m.h/2;break;
 case 'cubeProbability':answer=cached('cube2-'+m.n,()=>cubeOracle(m.n,2))/(m.n**3);extension=cubeOracle(m.n,3)/(m.n**3);break;
 case 'ratioUnion':{const red=m.a*m.unit,blue=m.b*m.unit;answer=blue-m.both;extension=red-m.both;break;}
 case 'chartAverage':{const scores=m.counts.flatMap((n,i)=>Array(n).fill(2+2*i));answer=scores.reduce((a,b)=>a+b,0)/scores.length;extension=scores.reduce((a,b)=>a+b+1,0)/scores.length;break;}
 case 'parityPermutations':answer=cached('parity'+m.n,()=>permutationOracle(m.n));extension=answer/Array.from({length:Math.ceil(m.n/2)},(_,i)=>i+1).reduce((a,b)=>a*b,1);break;
 case 'recurrenceRemainders':{const seq=[1n,1n];while(seq.length<=m.n)seq.push(seq.at(-1)+seq.at(-2));answer=seq.slice(0,m.n).reduce((sum,v)=>sum+Number(v%3n),0);extension=Number(seq[m.n]%3n);break;}
 default:throw Error('No independent oracle for '+p.family);
 }
 assert(same(p.answer,answer),p.family+' answer '+JSON.stringify(m));assert(same(p.extension.answer,extension),p.family+' variation '+JSON.stringify(m));
 return {answer,extension};
}
module.exports={oracle,routeOracle,cubeOracle,dominoOracle};
if(require.main===module){
const families={},answerPositions=Array(5).fill(0);let checks=0;
for(const f of c.COMPETITION_CATALOG)for(let seed=1;seed<=128;seed++){
 const t=c.competitionCreate({engine:2,familyId:f.id,seed}),p=t.competition;
 assert.equal(t.contentVersion,92);assert.equal(t.options.length,5);assert.equal(new Set(t.options).size,5);assert.equal(t.options[t.answer],p.answer);assert(!p.clues&&!p.verification&&p.family!=='constraints');assert.deepEqual(p.topicIds,f.topicIds);assert(p.methods.length===2&&p.methods.every(m=>m.steps.length>=2));assert(p.hints[0]&&p.extension.prompt);oracle(t);families[f.id]=(families[f.id]||0)+1;answerPositions[t.answer]++;checks++;
}
for(const id of old.COMPETITION_TOPIC_IDS){const eligible=c.competitionEligible([id]);assert(eligible.length>0);assert(eligible.every(f=>f.topicIds.length===1&&f.topicIds[0]===id))}
const ten=['A01','A02','A03','A04','N01','N02','G01','G03','C02','D03'];const pool=c.competitionEligible(ten);assert(pool.some(f=>f.topicIds.length===1));assert(pool.some(f=>f.topicIds.length>1));assert(pool.every(f=>f.topicIds.every(id=>ten.includes(id))));assert(!pool.some(f=>f.topicIds.length===10));assert.deepEqual(c.competitionEligible([]),[]);
assert.throws(()=>c.competitionCreate({engine:2,familyId:'constraints',seed:1}));assert.throws(()=>c.competitionCreate({engine:2,familyId:'paintedCube',seed:0}));assert.throws(()=>old.competitionCreate({engine:3}));assert(answerPositions.every(n=>n>500));
for(const [family,topics] of c.COMPETITION_REUSED)for(const seed of [1,17,95]){const current=c.competitionCreate({engine:2,familyId:'natural-'+family,seed}),legacy=old.competitionCreate({topicIds:topics,seed});assert.equal(current.competition.signature,legacy.competition.signature);assert.equal(current.id,legacy.id);assert.deepEqual(current.options,legacy.options);assert.equal(legacy.contentVersion,91)}
assert(old.competitionValueEqual('2/4','1/2'));assert(old.competitionValueEqual('0.5','1/2'));assert(!old.competitionValueEqual('','0'));assert(!old.competitionValueEqual('1/0','0'));assert(!old.competitionValueEqual('0.51','1/2'));
const evidence='docs/evidence/2026-10-05-natural-competition';fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(evidence+'/mathematics.json',JSON.stringify({release:require('./version.json').label,result:'passed',environment:'deterministic curated structures; separate enumeration/arithmetic/BigInt/matching oracles',families:Object.keys(families).length,checks,familyChecks:families,answerPositions,checked:['one scenario and five distinct choices, no generated clue cards','33 single-theme pools available; natural multi-theme families selected by subset','main answers and variations independently solved','grid paths counted by enumerating actual walks','painted cubes counted by inspecting every small cube','domino maximum independently checked by bipartite matching','restricted permutations/teams counted by enumeration','recurrence remainders checked with exact BigInt values','unchanged RC59 natural mathematics keeps signature, options and exposure'],limits:['authored AMC8-style training, not verified past papers','parameter variants do not represent additional reasoning structures','no claim of all pair/triple combinations, all difficulty bands or learning effect','no real browser or iPad testing']},null,2)+'\n');console.log(`PASS: ${Object.keys(families).length} natural problem families, ${checks} independent main-answer/variation checks; selection is a scope.`);
}
