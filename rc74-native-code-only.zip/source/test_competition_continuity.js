'use strict';
const assert=require('assert'),fs=require('fs'),{execFileSync}=require('child_process');
const {boot}=require('./test_support'),{competitionCreate,competitionHash}=require('./competition'),{COMPETITION_REVIEWED}=require('./competition_reviewed');
const evidence='docs/evidence/2026-10-06-practice-continuity',storageKey='tianle_amc8_question_design_v1',baseline='c4a1ea1';
function row(t){return {view:'competition',code:t.id,taskId:t.id,contentVersion:t.contentVersion,recipe:t.competition.recipe,openedAt:2000000000000,passed:false,draft:null,feedback:null}}
function install(app,t,id='fixture-round'){
 const session={mode:'competition-v2',id,topicIds:t.competition.topicIds,planSeed:1,total:10,cursor:0,items:[row(t)]};
 app.run('saved.topicPractice.selectedTopicIds='+JSON.stringify(session.topicIds)+';saved.topicPractice.session='+JSON.stringify(session)+';topicOpenCurrent()');
}
function solve(app,t=app.value('taskNow()')){app.click('competitionPick',{index:String(t.answer)});app.click('check');assert.equal(app.value('feedback.ok'),true)}
function wrong(app,t=app.value('taskNow()')){app.click('competitionPick',{index:String((t.answer+1)%5)});app.click('check');assert.equal(app.value('feedback.ok'),false)}
function variation(app,t=app.value('taskNow()'),value=t.competition.extension.answer){app.inputCompetition('extension',value);app.click('competitionExtensionCheck')}
function counts(app){return app.value('competitionProgressCounts()')}
function profile(app){return app.value('competitionAdaptiveProfile(saved.competition.attempts,saved.competition.extensions,["A02"],saved.competition.extensionViews,saved.competition.views)')}
function freshStorage(app){return {...app.storage}}

// These are the actual read handlers: no answer selection, help exposure or marks.
const speech=boot(),spokenExamples=[];
for(const family of COMPETITION_REVIEWED)for(const seed of [1,27,128]){
 const t=competitionCreate({engine:3,familyId:family.id,seed});install(speech,t,'speech-only');
 const before=speech.value('JSON.stringify(saved.competition)');speech.click('competitionRead');
 const actual=speech.spoken.at(-1);assert(actual&&actual.length);assert.equal(speech.value('draft.choice'),-1);assert.equal(speech.value('JSON.stringify(saved.competition)'),before);
 assert(speech.root.innerHTML.includes('id="speech-status"'));assert(speech.root.innerHTML.includes('aria-live="polite"'));
 if(family.id==='chartAverage'){
  t.competition.diagram.values.forEach((height,i)=>assert(actual.includes(t.competition.diagram.names[i]+'柱高'+height+'格'),'read every actual given bar height'));
  assert(!actual.includes('总人数')&&!actual.includes('总分')&&!actual.includes('平均为'),'question read does not derive a total or average');
  spokenExamples.push({recipe:t.competition.recipe,text:actual});
 }
 speech.utterances.at(-1).onend();assert.equal(speech.value('speechMessage'),'朗读已结束。');
}
for(const [text,expected] of [['1/4','4分之1'],['-3/4','4分之负3'],['−3/4','4分之负3'],['10−3','10减3'],['10-3','10减3'],['1:2:3','1比2比3'],['20%','百分之20'],['√17','17的平方根'],['4²','4的平方'],['3³','3的立方']])assert.equal(speech.value('competitionSpeechText('+JSON.stringify(text)+')'),expected);
const chart=competitionCreate({engine:3,familyId:'chartAverage',seed:27});install(speech,chart);
speech.click('competitionRead');const stale=speech.utterances.at(-1);speech.click('competitionReadOption',{index:'0'});stale.onend();assert.equal(speech.value('speechMessage'),'正在尝试朗读…');speech.utterances.at(-1).onerror();assert(speech.value('speechMessage').startsWith('朗读未成功'));
speech.click('competitionRead');const beforeNext=speech.utterances.at(-1);solve(speech,chart);speech.click('next');assert.equal(speech.value('speechMessage'),'');beforeNext.onerror();assert.equal(speech.value('speechMessage'),'','a previous question cannot change current speech status');
speech.run('delete window.speechSynthesis');speech.click('competitionRead');assert(speech.value('speechMessage').includes('暂不支持朗读'));assert.equal(speech.value('draft.choice'),-1);

// Stress a real bounded log using actual answer/input handlers. The fixture
// controls recipes; this does not claim the picker supplies 512 identical types.
const recipes=[],unique=new Set(),uniqueVariations=new Set();
for(let seed=1;seed<10000&&recipes.length<512;seed++){
 const t=competitionCreate({engine:3,familyId:'telescopingDifferences',seed});
 if(unique.has(t.competition.signature)||uniqueVariations.has(t.competition.extension.signature))continue;
 unique.add(t.competition.signature);uniqueVariations.add(t.competition.extension.signature);recipes.push(t);
}
assert.equal(recipes.length,512);
const long=boot();
for(let i=0;i<recipes.length;i++){
 const t=recipes[i];install(long,t,'long-'+i);if(i===0)wrong(long,t);if(i===1)long.click('competitionHint');solve(long,t);
 if(i===2){variation(long,t,'999999');assert.equal(long.value('draft.work.extensionResult.ok'),false)}variation(long,t);assert.equal(long.value('draft.work.extensionResult.ok'),true);
}
assert.equal(long.value('saved.competition.attempts.length'),500);assert.equal(long.value('saved.competition.extensions.length'),300);
assert.deepEqual(counts(long),{solved:512,first:510,extensions:512});const originalProfile=profile(long);assert.equal(originalProfile.eventCount,512);assert.equal(originalProfile.topics.A02.band,1,'the old two first struggles still influence replay');
const reloaded=boot(long.storage);assert.deepEqual(counts(reloaded),counts(long));assert.deepEqual(profile(reloaded),originalProfile,'equal-time events keep submission order after restore');
long.run('saved.competition.attempts=[];saved.competition.extensions=[];persist()');const compact=boot(long.storage);assert.deepEqual(counts(compact),{solved:512,first:510,extensions:512});assert.deepEqual(profile(compact),originalProfile);
compact.click('competitionRecords');assert(compact.root.innerHTML.includes('完成 512 道不同题，510 道未用提示首答正确，完成 512 道变式'));assert(compact.root.innerHTML.includes('最近没有答题明细'));
install(compact,recipes[0],'retry-after-cap');solve(compact,recipes[0]);assert.equal(compact.value('saved.competition.attempts.at(-1).firstAttempt'),false);assert.equal(compact.value('saved.competition.attempts.at(-1).firstCorrect'),false);
install(compact,recipes[2],'variation-after-cap');solve(compact,recipes[2]);variation(compact,recipes[2]);assert.equal(compact.value('saved.competition.extensions.at(-1).firstAttempt'),false);assert.equal(compact.value('Object.values(saved.competition.extensionViews).find(h=>h.signature==='+JSON.stringify(recipes[2].competition.extension.signature)+').firstCorrect'),false);
assert.deepEqual(counts(compact),{solved:512,first:510,extensions:512});

// A current round's solved row also survives log truncation; another round's
// receipt is exposure only and must not auto-pass an unanswered current row.
const round=boot();round.click('topicSelect',{code:'A02'});round.click('topicStart');round.run('topicSession().total=2');const first=round.value('taskNow()');round.inputCompetition('notes','保留第一题思路');solve(round);round.click('next');const second=round.value('taskNow()');
for(let i=0;i<501;i++)wrong(round,second);
assert(!round.value('saved.competition.attempts.some(a=>a.signature==='+JSON.stringify(first.competition.signature)+')'));
const resume=boot(round.storage);assert.equal(resume.value('topicSession().items[0].passed'),true);resume.click('topicResume');assert.equal(resume.value('taskNow().id'),second.id);solve(resume,second);resume.click('next');assert(resume.root.innerHTML.includes('完成 2 道题，1 道未用提示首答正确'));
resume.run('saved.competition.attempts=[];persist()');const summary=boot(resume.storage);summary.click('topicResume');assert(summary.root.innerHTML.includes('完成 2 道题，1 道未用提示首答正确'));summary.click('topicPrevious');summary.click('topicPrevious');assert.equal(summary.value('draft.work.notes'),'保留第一题思路');
install(summary,first,'different-round');summary.run('persist()');const unanswered=boot(summary.storage);assert.equal(unanswered.value('topicSession().items[0].passed'),false,'old completion does not pass a new-round question');

// Recent family choices and difficulty use the same durable facts with or
// without detail logs. Use the normal picker, not the stress fixture.
const picker=boot();picker.click('topicSelect',{code:'A02'});picker.click('topicStart');for(let i=0;i<20;i++){if(picker.value('view')==='topicSummary')picker.click('topicStart');solve(picker);picker.click('next')}
const withLogs=freshStorage(picker),noLogs=freshStorage(picker),without=JSON.parse(noLogs[storageKey]);without.competition.attempts=[];without.competition.extensions=[];noLogs[storageKey]=JSON.stringify(without);
const p1=boot(withLogs),p2=boot(noLogs);p1.click('topicResume');p2.click('topicResume');p1.click('topicStart');p2.click('topicStart');assert.deepEqual(p1.value('taskNow().competition.recipe'),p2.value('taskNow().competition.recipe'),'next recipe is unchanged when only details expire');

// Real RC62 storage supplies only facts that RC62 actually recorded.
const oldHtml=execFileSync('git',['show',baseline+':index.html'],{maxBuffer:8*1024*1024}).toString(),old=boot({},2000000000000,oldHtml),oldTask=recipes[7];install(old,oldTask,'rc62-in-progress');old.inputCompetition('notes','RC62草稿');wrong(old,oldTask);solve(old,oldTask);variation(old,oldTask,'999999');variation(old,oldTask);
const migrated=boot(old.storage);assert.deepEqual(counts(migrated),{solved:1,first:0,extensions:1});migrated.click('topicResume');migrated.click('topicPrevious');assert.equal(migrated.value('draft.work.notes'),'RC62草稿');migrated.run('saved.competition.attempts=[];saved.competition.extensions=[];persist()');assert.deepEqual(counts(boot(migrated.storage)),{solved:1,first:0,extensions:1});
const unknown=freshStorage(old),unknownState=JSON.parse(unknown[storageKey]);unknownState.competition.attempts=[];unknownState.competition.extensions=[];unknown[storageKey]=JSON.stringify(unknownState);const absent=boot(unknown);assert.equal(counts(absent).first,0);assert.equal(counts(absent).solved,0,'old exposure alone cannot invent a missing completion receipt');

// Stored flags are not an oracle: reconstruct answers from the original recipe.
const corrupt=freshStorage(compact),bad=JSON.parse(corrupt[storageKey]),mainKey=competitionHash(recipes[0].competition.signature),extKey=competitionHash(recipes[2].competition.extension.signature);
bad.competition.views[mainKey].first.correct=true;bad.competition.views[mainKey].solved.choice=(recipes[0].answer+1)%5;bad.competition.views[mainKey].solved.correct=true;bad.competition.extensionViews[extKey].solved.input='999999';bad.competition.extensionViews[extKey].solved.correct=true;bad.competition.attempts=[];bad.competition.extensions=[];corrupt[storageKey]=JSON.stringify(bad);
const sanitized=boot(corrupt);assert.deepEqual(counts(sanitized),{solved:511,first:510,extensions:511});assert.equal(sanitized.value('saved.competition.views['+JSON.stringify(mainKey)+'].first.correct'),false);assert(!sanitized.value('saved.competition.views['+JSON.stringify(mainKey)+'].solved'));

const report={release:require('./version.json').label,result:'passed',baseline,environment:'Node VM simulated DOM and speech callbacks; actual answer, read, input, picker and storage handlers',speechRecipes:COMPETITION_REVIEWED.length*3,spokenExamples,boundedLogStress:{uniqueMainProblems:512,mainDetails:500,extensionDetails:300,preservedCounts:counts(reloaded),preservedProfile:originalProfile},checked:['given chart heights read without totals or solution','fraction, signed fraction, subtraction, ratio, percent, root and power spoken semantically','end/error and unsupported statuses; obsolete callbacks ignored','512 verified completion and extension facts survive real detail caps and reload','first wrong or helped main, first wrong transfer and equal-time order remain permanent','same-round completion and first summary survive 501 later wrong attempts','another round cannot auto-pass a previously solved mathematical question','normal picker chooses the same next recipe after detail removal','real RC62 draft and known facts migrate; missing old receipts remain unknown','stored correctness flags are recomputed from recipes'],limits:['does not execute a real speech engine or verify pronunciation quality','does not verify browser layout, iPad touch, child outcomes or public deployment','old already-truncated records with no surviving completion receipt cannot be reconstructed']};
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(evidence+'/practice-continuity.json',JSON.stringify(report,null,2)+'\n');console.log('PASS: given-only speech, native callback guards, 512-problem capped logs, durable first facts, round continuation, picker replay and RC62 migration.');
