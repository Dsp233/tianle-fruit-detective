'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path'),{execFileSync}=require('child_process');
const {boot}=require('./test_support'),{COMPETITION_REVIEWED,competitionCreate}=require('./competition_reviewed');
const baseline='c32163f',evidence='docs/evidence/2026-10-06-practice-continuity';
const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'amc8-rc61-contract-'));
const originalHtml=execFileSync('git',['show',baseline+':index.html'],{maxBuffer:8*1024*1024}).toString();
function contract(t){const c=t.competition;return {id:t.id,contentVersion:t.contentVersion,prompt:t.prompt,options:t.options,optionIds:t.optionIds,answer:t.answer,signature:c.signature,recipe:c.recipe,extension:{prompt:c.extension.prompt,answer:c.extension.answer,signature:c.extension.signature,key:c.extension.key}}}
let contracts=0;
try{
 for(const name of ['competition.js','competition_catalog.js','competition_expansion.js','competition_reviewed.js'])fs.writeFileSync(path.join(temporary,name),execFileSync('git',['show',baseline+':source/'+name]));
 const original=require(path.join(temporary,'competition_reviewed.js'));
 for(const f of COMPETITION_REVIEWED.filter(f=>!['rc64-structure','rc65-rules'].includes(f.origin)))for(let seed=1;seed<=128;seed++){
  const recipe={engine:3,familyId:f.id,seed};assert.deepEqual(contract(competitionCreate(recipe)),contract(original.competitionCreate(recipe)),f.id+' must replay RC61 mathematics and grading unchanged');contracts++;
 }
}finally{fs.rmSync(temporary,{recursive:true,force:true})}
function begin(app,ids){if(app.value('view')==='topicSummary'){app.click('topicStart');return}for(const code of ids)app.click('topicSelect',{code});app.click('topicStart')}
function solve(app){const t=app.value('taskNow()');app.click('competitionPick',{index:String(t.answer)});app.click('check');assert.equal(app.value('feedback.ok'),true);return t}
function run(ids,html=null,rounds=2){
 const app=boot({},2000000000000,html),rows=[];begin(app,ids);
 for(let i=0;i<rounds*10;i++){
  if(app.value('view')==='topicSummary')begin(app,ids);
  const t=app.value('taskNow()');assert(t.competition.topicIds.every(id=>ids.includes(id)),'topic selection remains a scope, including natural composites');
  rows.push({family:t.competition.recipe.familyId,level:t.competition.level,signature:t.competition.signature});solve(app);app.click('next');
 }
 let maxRun=1,current=1,adjacentRepeats=0;for(let i=1;i<rows.length;i++){current=rows[i].family===rows[i-1].family?current+1:1;if(current>1)adjacentRepeats++;maxRun=Math.max(maxRun,current)}
 return {rows,maxRun,adjacentRepeats,structures:new Set(rows.map(r=>r.family)).size};
}
const singleTheme=[];
for(const id of ['A01','A02','A03','A04','A05','R01','R02','R03','R04','L01','L02','L03','L04','N01','N02','N03','N04','G01','G02','G03','G04','G05','G06','G07','C01','C02','C03','C04','D01','D02','D03','S01','S02']){
 const r=run([id]);assert(r.structures>=2,id+' should offer another perspective');assert(r.maxRun<=2,id+' should not keep changing numbers in the same structure during clean practice');singleTheme.push({id,maxRun:r.maxRun,structures:r.structures,adjacentRepeats:r.adjacentRepeats});
}
const comparisons=[];
for(const ids of [['A02'],['D03'],['G07'],['A01','A02','R01','R03','L01','N01','G03','C02','D02','D03']]){
 const before=run(ids,originalHtml),after=run(ids);assert(after.adjacentRepeats<=before.adjacentRepeats,'polish should not increase repeats in the comparison scenarios');
 comparisons.push({scope:ids,before:{maxRun:before.maxRun,adjacentRepeats:before.adjacentRepeats},after:{maxRun:after.maxRun,adjacentRepeats:after.adjacentRepeats},currentExample:after.rows.map(({family,level})=>({family,level}))});
}
const failure=boot();begin(failure,['A04']);
for(let i=0;i<7;i++){const t=failure.value('taskNow()');if(i>=2)assert.equal(t.competition.level,1,'a low-band learner is not forced into a harder structure for variety');failure.click('competitionHint');solve(failure);failure.click('next')}
// Render real diagram output, then inspect mathematical relationships in it.
const app=boot(),diagram=d=>app.value('competitionDiagram('+JSON.stringify(d)+')');
for(let seed=1;seed<=128;seed++){
 const bars=competitionCreate({engine:3,familyId:'truncatedBars',seed}).competition.diagram,svg=diagram(bars);
 const lines=[...svg.matchAll(/class="competition-grid-line" d="M54 ([\d.]+) H240"/g)].map(m=>Number(m[1])).sort((a,b)=>a-b);
 assert.equal(lines.length,bars.b+1,'every stated small grid cell must exist, even with sparse numeric tick labels');
 for(let i=1;i<lines.length;i++)assert(Math.abs(lines[i]-lines[i-1]-80/bars.b)<1e-8,'equal grid cells must represent equal given increments');
 assert(svg.includes('>'+bars.base+'</text>')&&svg.includes('>'+(bars.base+bars.b*bars.step)+'</text>'),'start and top tick values must be stated');
 const product=competitionCreate({engine:3,familyId:'signedProduct',seed}).competition,cards=[-4*product.math.k,-3*product.math.k,-product.math.k,0,2*product.math.k,5*product.math.k],negative=new Set();
 for(let mask=0;mask<64;mask++){const chosen=cards.filter((_,i)=>mask&(1<<i));if(chosen.length===3&&chosen.reduce((p,x)=>p*x,1)<0)negative.add(chosen.reduce((p,x)=>p*x,1))}
 for(const value of negative)assert(product.methods[1].steps.join(' ').includes('='+value),'enumeration should show every negative candidate rather than merely announce the minimum');
 const box=competitionCreate({engine:3,familyId:'openBox',seed}).competition,boxSvg=diagram(box.diagram);assert.equal((boxSvg.match(/<rect class="competition-fill"/g)||[]).length,4,'net shows all four equal removed corners');assert(!boxSvg.includes(String(box.math.side-2)+' ×'),'pre-answer net must not fill in a solved bottom dimension');
 const proof=competitionCreate({engine:3,familyId:'threeDivisors',seed}).competition;assert.equal(proof.methods.length,1,'keep the full prime-square reasoning without an undeveloped brute-force second route');
}
const midSvg=diagram({kind:'hypotenuseMidpoint',k:6});
const triangle=midSvg.match(/class="competition-shape" d="M([\d.]+) ([\d.]+) V([\d.]+) L([\d.]+) ([\d.]+) Z"/),midpoint=midSvg.match(/class="competition-dot" cx="([\d.]+)" cy="([\d.]+)"/);
assert(triangle&&midpoint);const [,ax,ay,by,cx,cy]=triangle.map(Number),[,mx,my]=midpoint.map(Number);
assert.equal(ay,cy);assert.equal(mx,(ax+cx)/2);assert.equal(my,(by+cy)/2);assert.equal((cx-ax)/(ay-by),3/4,'drawn legs use the stated 3:4 geometry');
assert(midSvg.includes(`d="M${ax} ${ay} L${mx} ${my}"`),'show the actual requested segment, not only a point');
assert(!midSvg.includes('>15</text>'),'the required distance stays unanswered');
const angleSvg=diagram({kind:'angleRatioTriangle',ratios:[2,3,4]});assert(angleSvg.includes('2份')&&angleSvg.includes('3份')&&angleSvg.includes('4份'));assert(!angleSvg.includes('80°')&&!angleSvg.includes('20°'),'only given angle ratios are presented');
// Continue a genuine RC61 session with a two-route draft and wrong transfer.
const old=boot({},2000000000000,originalHtml),t=competitionCreate({engine:3,familyId:'threeDivisors',seed:27});
old.run('saved.topicPractice.selectedTopicIds=["N02"];saved.topicPractice.session={mode:"competition-v2",id:"rc61-in-progress",topicIds:["N02"],planSeed:1,total:10,cursor:0,items:[{view:"competition",code:'+JSON.stringify(t.id)+',taskId:'+JSON.stringify(t.id)+',contentVersion:93,recipe:'+JSON.stringify(t.competition.recipe)+',openedAt:Date.now(),passed:false}]};topicOpenCurrent()');
old.inputCompetition('notes','原来的思路');solve(old);old.click('competitionMethod',{index:'1'});old.inputCompetition('extension','999999');old.click('competitionExtensionCheck');
const resumed=boot(old.storage);resumed.click('topicResume');resumed.click('topicPrevious');assert.equal(resumed.value('taskNow().id'),t.id);assert.equal(resumed.value('draft.work.notes'),'原来的思路');assert.equal(resumed.value('draft.work.method'),0,'saved method index clamps to the actual surviving route');assert.equal(resumed.value('saved.competition.attempts[0].firstCorrect'),true);
resumed.inputCompetition('extension',t.competition.extension.answer);resumed.click('competitionExtensionCheck');assert.equal(resumed.value('saved.competition.extensions.at(-1).firstAttempt'),false,'editorial polish does not reset a previously wrong transfer');
assert.equal(Object.values(resumed.value('saved.competition.extensionViews'))[0].firstCorrect,false);
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(evidence+'/practice-polish.json',JSON.stringify({release:require('./version.json').label,baseline,result:'passed',preservedMainAndTransferContracts:contracts,singleThemeRounds:66,singleThemeQuestions:660,singleTheme,comparisons,checked:['same main/transfer conditions, answer options, identities and grading as RC61 across 119×128 recipes','two clean rounds in each of 33 single-theme scopes','historical family exposure affects following rounds without topic quotas','struggling low-band scope may repeat rather than force harder material','truncated chart retains every given small grid cell with sparse labels','four-corner net and stated 3:4 midpoint geometry','enumeration shows all negative candidates','only given ratios appear before answers','RC61 draft, surviving method index and first wrong transfer survive'],limits:['Node VM interaction and SVG coordinate checks do not verify browser layout or child outcomes','structure variety does not promise a new mathematical strategy in every question']},null,2)+'\n');
console.log('PASS: RC61 contracts, 33 scopes × two rounds, difficulty-sensitive variety, complete diagrams and RC61 continuation.');
