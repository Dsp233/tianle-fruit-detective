'use strict';
const assert=require('assert'),fs=require('fs'),catalog=require('./competition_reviewed'),base=require('./competition_catalog'),core=require('./competition'),{oracle}=require('./test_competition'),{expansionOracle,reviewedTransferOracle,n}=require('./competition_reviewed_oracles');
const {freshOracle}=require('./competition_fresh_oracles');
const {rulesOracle}=require('./competition_rules_oracle'),rules=require('./competition_rules');
const evidence='docs/evidence/2026-10-06-practice-continuity';
fs.mkdirSync(evidence,{recursive:true});
const rows=[],positions=Array(5).fill(0);let checks=0;
for(const f of catalog.COMPETITION_REVIEWED){
 for(let seed=1;seed<=128;seed++){
  const task=core.competitionCreate({engine:3,familyId:f.id,seed}),c=task.competition;let expected;
  if(f.origin==='reviewed-rc60'){
   const old=base.competitionCreate({engine:2,familyId:f.id,seed});oracle(old);
   assert.equal(c.signature,old.competition.signature);assert.equal(task.id,old.id);assert.deepEqual(task.options,old.options);assert.equal(c.answer,old.competition.answer);
   expected={answer:n(old.competition.answer),extension:reviewedTransferOracle(f.id,c.math)};
  }else expected=f.origin==='rc65-rules'?{answer:rulesOracle(c.math),extension:rulesOracle(c.extension.math)}:f.origin==='rc64-structure'?freshOracle(f.id,c.math):expansionOracle(f.id,c.math);
  assert(Number.isFinite(expected.answer)&&Number.isFinite(expected.extension),f.id+' incomplete independent solver');
  assert(Math.abs(n(c.answer)-expected.answer)<1e-8,f.id+' main '+JSON.stringify(c.math));
  assert(Math.abs(n(c.extension.answer)-expected.extension)<1e-8,f.id+' transfer '+JSON.stringify(c.math));
  assert.equal(task.contentVersion,93);assert.equal(task.options.length,5);assert.equal(new Set(task.options).size,5);assert.equal(task.options[task.answer],c.answer);
  assert(c.methods.length>=1&&c.methods.length<=3&&c.methods.every(m=>m.steps.length>=2));assert(c.extension.key&&c.extension.signature&&c.extension.kind==='condition-change');
  assert(c.level>=1&&c.level<=3&&c.levelReason.includes(f.insight));assert(c.hints.length>=1&&c.hints.every(h=>typeof h==='string'&&h));
  if(!rules.adapters[f.id])assert(c.hints[0]===f.insight);
  assert(!c.clues&&!c.verification&&c.family!=='constraints');assert(!/先算|不用逐|染色|插空|逆推|补集|规律|相消/.test(c.title),f.id+' title cues strategy');
  if(f.id==='fractionBackwards'){assert.equal(c.diagram.kind,'scene-fractions');assert.equal(c.diagram.start,'?');assert.equal(c.diagram.left,c.math.left);}
  if(f.id==='fixedPerimeter')assert(!JSON.stringify(c.diagram).includes('长 + 宽'));
  positions[task.answer]++;checks++;
 }
 const example=core.competitionCreate({engine:3,familyId:f.id,seed:11}).competition;
 rows.push({id:f.id,topicIds:f.topicIds,origin:f.origin,level:f.level,levelReason:f.levelReason,title:example.title,insight:f.insight,methods:example.methods.map(m=>m.name),methodDecision:example.methods.length===1?'保留完整的一条路线，不硬凑第二解':'不同的表示、计数对象或推理顺序；不把同一公式改写算第二解',transfer:example.extension.prompt,benchmarks:f.benchmarks,benchmarkKind:f.benchmarkKind,benchmarkMatch:f.benchmarkMatch});
}
const pools=core.COMPETITION_TOPIC_IDS.map(id=>({topicId:id,families:catalog.competitionReviewedEligible([id]).map(f=>f.id)}));assert(pools.every(p=>p.families.length>=3));assert.equal(catalog.COMPETITION_REVIEWED.filter(f=>f.origin!=='rc65-rules').length,127);assert.equal(catalog.COMPETITION_REVIEWED.filter(f=>f.origin==='rc65-rules').length,13);assert(!catalog.COMPETITION_REVIEWED.some(f=>f.id==='groupProducts'));assert.equal(core.competitionCreate({engine:2,familyId:'groupProducts',seed:1}).contentVersion,92);
assert(positions.every(v=>v>1500));
fs.writeFileSync(evidence+'/content-review.json',JSON.stringify({release:require('./version.json').label,result:'passed',originalStructures:67,reviewedExistingStructures:52,activeFamilies:catalog.COMPETITION_REVIEWED.length,newRC64Structures:8,rc65RuleModels:6,rc65RuleConfigurations:13,singleThemePools:pools,difficultyBands:rows.reduce((a,r)=>(a[r.level]=(a[r.level]||0)+1,a),{}),oneMethodStructures:rows.filter(r=>r.methods.length===1).length,review:rows,limits:['原创训练题；结构参照来自已复核台账摘要，未新增原题复核状态','难度为内容推理层级，不等同AMC8官方题号或孩子能力评价','数字参数变化不计为新结构']},null,2)+'\n');
fs.writeFileSync(evidence+'/mathematics.json',JSON.stringify({release:require('./version.json').label,result:'passed',families:catalog.COMPETITION_REVIEWED.length,seedsPerFamily:128,mainAndTransferInstances:checks,answerPositions:positions,independentChecks:['RC60主问题用已有独立枚举、路径、匹配、BigInt求解器重算，主数学身份与选项保持','67个新结构的主答与变式独立求解','放回/条件概率按具体结果枚举','缺口边界逐段计算，覆盖区域按单位格计数','棋盘改删同一行两角用二分图最大匹配求解','受限排列按实际排列枚举；多色串按实际用色计数','长整数取余和递推余数用BigInt检查','年龄、机器、数字整除按条件搜索唯一解','离散球数、整杯数和买整件的条件保持整数'],limits:['不代表140道真题或17920种解题结构；13个规则配置来自6个模型','未进行真实浏览器、iPad或儿童效果测试']},null,2)+'\n');
console.log('PASS: 127 legacy families and 13 rule configurations, '+checks+' independently solved main/transfer instances; all 33 single-theme pools have >=3 families.');
