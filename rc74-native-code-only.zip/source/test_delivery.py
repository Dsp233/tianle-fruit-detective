"""Non-browser delivery checks, with destructive cases confined to a temporary copy."""
import csv
import shutil
import subprocess
import tempfile
from pathlib import Path

repo = Path(__file__).resolve().parent.parent

def run(cwd, *args, success=True):
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True)
    assert (result.returncode == 0) == success, result.stdout + result.stderr
    return result

run(repo, 'python3', 'source/build.py', '--check')
run(repo, 'node', 'source/audit_units.js', '--check')
with tempfile.TemporaryDirectory(prefix='amc8-delivery-') as temporary:
    temp = Path(temporary)
    shutil.copytree(repo / 'source', temp / 'source', ignore=shutil.ignore_patterns('index.html', '__pycache__'))
    (temp / 'docs').mkdir()
    for name in ['exam-review-ledger.csv', 'unit-acceptance.csv']:
        shutil.copyfile(repo / 'docs' / name, temp / 'docs' / name)
    run(temp, 'python3', 'source/build.py')
    entry = temp / 'amc8' / 'index.html'
    entry.write_text('STALE ENTRY', encoding='utf-8')
    result = run(temp, 'python3', 'source/build.py', '--check', success=False)
    assert 'amc8/index.html' in result.stderr
    assert entry.read_text() == 'STALE ENTRY', '--check must not change a file'
    run(temp, 'python3', 'source/build.py')
    run(temp, 'python3', 'source/build.py', '--check')
    matrix = temp / 'docs' / 'unit-acceptance.csv'
    with matrix.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        fields, rows = reader.fieldnames, list(reader)
    fields.append('manualNote')
    rows[0]['browserEvidencePaths'] = 'evidence/example.png'
    rows[0]['ipadStatus'] = '待真机：手工记录,包含逗号'
    rows[0]['manualNote'] = '保留第一行\n以及"第二行"'
    rows[0]['operationTaskIds'] = 'obsolete-task-id'
    with matrix.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)
    run(temp, 'node', 'source/audit_units.js', '--check', success=False)
    run(temp, 'node', 'source/audit_units.js')
    with matrix.open(encoding='utf-8-sig', newline='') as stream:
        revised = list(csv.DictReader(stream))
    assert len(revised) == 33
    for field in ['browserEvidencePaths', 'ipadStatus', 'manualNote']:
        assert revised[0][field] == rows[0][field], field + ' must survive regeneration'
    assert revised[0]['operationTaskIds'] != 'obsolete-task-id'
    run(temp, 'node', 'source/audit_units.js', '--check')

# Coordinates reconstructed from the three right-angle marks on the supplied page.
def area(a, b, c):
    return abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])) / 2
X = area((0, 0), (0, 3), (3, 3))
Y = area((0, 0), (-4, 0), (0, -4))
Z = area((-4, 0), (0, 3), (-7, 4))
W = area((0, 0), (-4, 0), (0, 3))
assert (X, Y, Z) == (4.5, 8, 12.5)
assert [X+Z == W+Y, W+X == Z, 3*X+4*Y == 5*Z, X+W == (Y+Z)/2, X+Y == Z] == [False]*4+[True]
with (repo / 'docs' / 'exam-review-ledger.csv').open(encoding='utf-8-sig', newline='') as stream:
    q16 = next(r for r in csv.DictReader(stream) if r['examId'] == 'AMC8-2002-16')
assert 'X＝9/2、Y＝16/2、Z＝25/2' in q16['independentSolution'] and q16['referenceAnswer'] == 'E'
print('PASS: three-entry build synchronization, stale-entry detection, manual matrix evidence preservation, 2002 Q16 areas. No browser/device claim.')
