'use strict';
// A legal manipulation trace constructed from elementary arithmetic; no
// runtime grading or expected-position functions are imported here.
function solveDigitRules(b,t){
 for(const d of [...new Set(t.cases.map(c=>c.divisor))]){
  for(let n=0;n+d<=10;n+=d){for(let j=0;j<d;j++)b.click('digitRuleProofPick',{divisor:String(d),index:String(n+j)});b.click('digitRuleProofWrap',{divisor:String(d)})}
  b.click('digitRuleProofProbe',{divisor:String(d)});
 }
 t.cases.forEach((c,i)=>{
  b.click('digitRuleActive',{index:String(i)});const digits=String(c.number).split(''),ids=[];
  digits.forEach((digit,j)=>{const add=c.divisor===3||j===digits.length-1;b.click('digitRulePlace',{card:String(i),index:String(j),value:add?'add':'skip'});if(add)for(let k=0;k<Number(digit);k++)ids.push(c.id+':P'+j+':U'+k)});
  for(let n=0;n+c.divisor<=ids.length;n+=c.divisor){for(let j=0;j<c.divisor;j++)b.click('digitRulePick',{card:String(i),id:ids[n+j]});b.click('digitRuleWrap',{card:String(i)})}
  b.click('digitRuleProbe',{card:String(i)});b.click('digitRuleRemainder',{card:String(i),value:String(c.number%c.divisor)});b.click('digitRuleChoice',{card:String(i),value:c.number%c.divisor===0?'complete':'remain'});
 });
}
module.exports={solveDigitRules};
