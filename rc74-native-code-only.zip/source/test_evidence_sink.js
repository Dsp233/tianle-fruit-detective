'use strict';
// Test-only preload: preserve historical reports while collecting current runs.
const fs=require('fs'),path=require('path');
if(process.env.AMC8_EVIDENCE_DIR){
 const oldRoot=path.resolve('docs/evidence')+path.sep,newRoot=path.resolve(process.env.AMC8_EVIDENCE_DIR);
 function target(value){if(typeof value!=='string')return value;const absolute=path.resolve(value);if(!absolute.startsWith(oldRoot)||absolute.startsWith(newRoot+path.sep))return value;return path.join(newRoot,path.relative(oldRoot,absolute))}
 for(const method of ['mkdirSync','writeFileSync','appendFileSync']){const original=fs[method];fs[method]=function(file,...args){return original.call(this,target(file),...args)}}
}
