'use strict';
const assert=require('assert'),{boot}=require('./test_support'),{solveFoundation}=require('./test_foundation_solver');
const b=boot(),all=b.value('Object.fromEntries(Object.keys(FOUNDATION_MODELS).map(sid=>[sid,[WORKSHOP_TASKS[sid],...Object.values(STAGED_TASKS[sid]),FOUNDATION_DEMOS[sid]]]))');
let count=0;
for(const [sid,tasks] of Object.entries(all)){
 const prints=new Set();
 for(const t of tasks){
  b.ctx.__case=t;b.run('draft=freshDraft();');
  const fp=b.value('taskFingerprint(__case)');assert(!prints.has(fp),sid+' distinct semantic model '+t.id);prints.add(fp);
  assert.deepEqual(b.value('taskContractErrors(__case)'),[]);
  const actor={click(action,data){b.ctx.__action=action;b.ctx.__data=data;b.run('taskAdapter(__case).act(__action,__data,__case)');const w=b.value('draft.work');if(['reverseExchange','forwardExchange'].includes(t.mode)){const units=[...w.tenIds.flat(),...w.oneIds];assert.equal(new Set(units).size,10*(t.initialTens??2)+(t.initialOnes??3));assert.equal(units.length,10*(t.initialTens??2)+(t.initialOnes??3));assert(w.tray.length<=10)}if(t.mode==='equalGroups'){const ids=[...w.pool,...w.bins.flat()];assert.equal(ids.length,t.total??t.groups*t.each);assert.equal(new Set(ids).size,ids.length)}}};
  solveFoundation(actor,t);assert.equal(b.value('taskAdapter(__case).grade(__case).ok'),true,t.id+' reachable semantic goal');count++;
 }
}
b.click('workshop',{code:'A01.02'});for(let i=1;i<=10;i++)b.click('workPick',{id:'U'+i});
const before=b.value('draft.work.tray');b.click('workPick',{id:'U11'});b.click('workPick',{id:'U1'});assert.deepEqual(b.value('draft.work.tray'),before,'full frame rejects eleventh and duplicate');
assert.equal((b.root.innerHTML.match(/data-action='workUnpick'/g)||[]).length,10,'ten physical circles are children of frame markup');
b.click('workBundle');const grouped=b.value('draft.work.tenIds.at(-1)');assert.deepEqual(grouped,before);b.click('workBundleUndo');assert.equal(b.value('draft.work.oneIds.length'),13);
const original=b.value('draft.work.oneIds').sort();assert.deepEqual(original,Array.from({length:13},(_,i)=>'U'+(i+1)).sort(),'undo restores same original objects');
b.click('workshop',{code:'A02.05'});b.click('workPlace',{index:'0'});const id=b.value('draft.work.bins[0][0]');b.click('workUnplace',{index:'0'});assert(b.value('draft.work.pool').includes(id),'mean grouping returns same unit');
console.log(`PASS: ${count} finite foundation models, all semantic goals reachable, original identities conserved, ten-slot frame capacity/markup and inverse actions (simulated DOM; no browser geometry or iPad claim).`);
