'use strict';
function solveFoundation(b,t){
 const click=(action,data={})=>b.click(action,data);
 if(t.mode==='counterBuild')for(let i=0;i<t.target;i++)click('workAdd');
 if(t.mode==='compareBuild'){for(const [i,side] of ['left','right'].entries())for(let n=t.initial[i];n!==t.target[i];n+=Math.sign(t.target[i]-n))click('workAdjust',{side,delta:String(Math.sign(t.target[i]-n))});click('workChoice',{value:t.target[0]===t.target[1]?'equal':t.target[0]>t.target[1]?'left':'right'})}
 if(t.mode==='reverseExchange'){for(let i=t.initialTens??2;i>(t.targetTens??1);i--)click('workUnbundle');click('workChoice',{value:'0'})}
 if(t.mode==='forwardExchange'){for(let i=1;i<=10;i++)click('workPick',{id:'U'+i});click('workBundle');click('workChoice',{value:'0'})}
 if(t.mode==='placeCompose')for(const [key,n] of [['tens',t.tens],['ones',t.ones]])for(let i=0;i<n;i++)click('workUnit',{key,delta:'1'});
 if(t.mode==='tenFill')for(let i=0;i<10;i++)if(t.filledIndices?!t.filledIndices.includes(i):i>=t.filled)click('workFill',{index:String(i)});
 if(t.mode==='counterRemove')for(let i=0;i<t.remove;i++)click('workTake',{index:String(i)});
 if(t.mode==='counterChange')for(let i=1;i<=t.add;i++)click('workMoveIn',{id:'A'+i});
 if(t.mode==='inverseMove'){for(const action of t.inverseOrder==='removeFirst'?['workInverseRemove','workInverseAdd']:['workInverseAdd','workInverseRemove'])for(let i=0;i<t.delta;i++)click(action);click('workChoice',{value:'0'})}
 if(t.mode==='equalGroups'){if(t.dynamicGroups)for(let i=0;i<t.groups;i++)click('workNewGroup');for(let i=0;i<t.groups;i++)for(let j=0;j<t.each;j++)click('workPlace',{index:String(i)})}
 if(t.mode==='orderGroups'){for(let i=0;i<Math.abs(t.add);i++)click('workFirstAdd');for(let i=0;i<(t.copies??2)-1;i++)click('workCopy')}
}
module.exports={solveFoundation};
