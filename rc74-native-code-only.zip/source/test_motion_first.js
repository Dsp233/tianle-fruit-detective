'use strict';
const assert=require('assert'),fs=require('fs'),{boot}=require('./test_support'),{solveStage,solveMotion}=require('./test_solutions');
const probe=boot(),release=probe.value('window.__AMC8_RELEASE'),tasks=probe.value('Object.values(STAGED_TASKS).flatMap(Object.values).filter(t=>t.mode==="motionLab"&&assessmentFormal(t))');
const key=t=>t.contentVersion+':'+t.id;
function prepare(t,seed={}){const b=boot(seed);b.ctx.__case=t;const actor={last:null,click(action,data={}){if(action==='reason')return;if(action==='check'){this.last={gradingResult:b.value('taskAdapter(__case).grade(__case).ok')?'correct':'incorrect',operationSummary:b.value('draft')};return}b.ctx.__action=action;b.ctx.__data=data;b.run('taskAdapter(__case).act(__action,__data,__case)')}};return {b,actor};}
function first(b,t){return b.value('taskHistory(__case).motionPrediction')}
function wrongPrediction(actor,t){if(t.kind==='fold')actor.click('motionLock');else{for(const p of t.points){actor.click('motionSelect',{id:p.id});actor.click('motionPlace',{x:'4',y:'4'})}actor.click('motionLock');}}
const coverage=[];
for(const t of tasks){
 assert.equal(t.firstResponseRuleVersion,1);assert.equal(t.contentVersion,82);
 const {b,actor}=prepare(t);wrongPrediction(actor,t);const original=first(b,t);assert(original,'an explicit empty-hole prediction is a recorded response too');
 actor.click('motionUndo');assert(b.value('motionState(__case).locked'),'undo cannot cross the formal prediction boundary');assert.deepEqual(first(b,t),original);
 solveMotion(actor,t);assert(!b.value('taskAdapter(__case).grade(__case).ok'),'correct operations do not replace wrong first prediction');
 b.run('draft=freshDraft();motionState(__case);');assert.deepEqual(first(b,t),original);
 const reloaded=prepare(t,b.storage);assert.deepEqual(first(reloaded.b,t),original);solveMotion(reloaded.actor,t);assert(!reloaded.b.value('taskAdapter(__case).grade(__case).ok'),'reload retains a wrong first response');
 const clean=prepare(t);solveStage(clean.actor,t);assert(clean.b.value('taskAdapter(__case).grade(__case).ok'),'different learner, correct first response');const saved=first(clean.b,t);clean.b.run('draft=freshDraft();');solveStage(clean.actor,t);assert.deepEqual(first(clean.b,t),saved);assert(clean.b.value('taskAdapter(__case).grade(__case).ok'));
 coverage.push({skillId:t.skillId,taskId:t.id,contentVersion:t.contentVersion,kind:t.kind,wrongFirstAfterUndoResetReload:'rejected',correctFirstAndNewTrace:'passed'});
}
function formal(sid,seed={}){const b=boot(seed);b.run('saved.skillStage["'+sid+'"]={transferPassed:true};');b.click('stage',{code:sid+'|independent'});b.ctx.__case=b.value('taskNow()');return b;}
for(const sid of ['S01.01','S01.02','S01.03','S01.04','S01.05']){
 const b=formal(sid),t=b.value('taskNow()');wrongPrediction(b,t);const before=b.value('draft.work');b.click('speakState');assert.deepEqual(b.value('draft.work'),before,'reading does not change an answer');assert(!b.spoken.at(-1).includes(t.explain));
 b.click('micro',{code:sid});b.click('stage',{code:sid+'|independent'});assert(b.value('draft.work.locked'));assert(b.root.innerHTML.includes('首次预测已保存'));solveMotion(b,t);b.click('check');assert.equal(b.value('saved.attempts.at(-1).gradingResult'),'incorrect');assert(!b.value('saved.attempts.at(-1).independent'));assert.deepEqual(b.value('saved.attempts.at(-1).motionFirstResponse'),b.value('taskHistory(taskNow()).motionPrediction'));
 b.click('stage',{code:sid+'|independent2'});const newer=b.value('taskNow()');solveStage(b,newer);assert(b.value('saved.attempts.at(-1).independent'),'a different, unseen instance remains eligible');
}
const formalTask=tasks.find(t=>t.skillId==='S01.02'&&t.phase==='测'),valid=prepare(formalTask);solveStage(valid.actor,formalTask);const original=first(valid.b,formalTask);
for(const mutate of [v=>{v.kind='holes';v.holes=[]},v=>{v.predicted.A=[999,0]},v=>{v.predicted.EXTRA=[0,0]},v=>{delete v.predicted.A},v=>{v.lockedAt=0},v=>{v.ruleVersion=0}]){
 const bad=JSON.parse(JSON.stringify(original));mutate(bad);const seed=JSON.parse(valid.b.storage.tianle_amc8_question_design_v1);seed.taskHistory[key(formalTask)].motionPrediction=bad;const checked=prepare(formalTask,{tianle_amc8_question_design_v1:JSON.stringify(seed)});assert.equal(first(checked.b,formalTask),null);assert(checked.b.value('taskHistory(__case).legacyExposure'),'unverifiable saved responses cannot create new independence');assert.deepEqual(checked.b.value('taskHistory(__case).unverifiedMotionPrediction'),bad);
}
const foldTask=tasks.find(t=>t.kind==='fold'),fold=prepare(foldTask);wrongPrediction(fold.actor,foldTask);const empty=first(fold.b,foldTask);assert.deepEqual(empty.holes,[]);for(const holes of [['C0-0','C0-0'],['C9-9']]){fold.b.ctx.__bad={...empty,holes};assert.equal(fold.b.value('motionSavedPrediction(__case,__bad)'),null)}
for(const shape of ['history','attempt','pending']){
 const sid='S01.02',t=probe.value('STAGED_TASKS["'+sid+'"].independent'),oldKey='64:'+t.id,seed={storageVersion:2,contentRevision:81};
 if(shape==='history')seed.taskHistory={[oldKey]:{submissions:1}};
 if(shape==='attempt')seed.attempts=[{id:'old-motion',taskInstanceId:t.id,contentVersion:64,evidenceVersion:2,evidenceRuleVersion:4,independent:true,firstSubmissionCorrect:true,modelViewed:false,hintEvents:[],gradingResult:'correct'}];
 if(shape==='pending')seed.pendingFormal={[oldKey]:{taskId:t.id,contentVersion:64,openedAt:1}};
 const b=formal(sid,{tianle_amc8_question_design_v1:JSON.stringify(seed)});assert(b.root.innerHTML.includes('旧实例再练'));solveStage(b,t);assert.equal(b.value('saved.attempts.at(-1).gradingResult'),'correct');assert(!b.value('saved.attempts.at(-1).independent'),'a revised rule is not a new mathematical instance');assert.deepEqual(b.value('taskHistory(taskNow()).priorMotionExposure'),[oldKey]);
}
const practice=probe.value('MOTION_TASKS["S01.02"]'),free=prepare(practice);wrongPrediction(free.actor,practice);free.actor.click('motionUndo');assert(!free.b.value('draft.work.locked'),'practice remains reversible');free.b.run('draft=freshDraft();');solveStage(free.actor,practice);assert(free.b.value('taskAdapter(__case).grade(__case).ok'));assert.equal(first(free.b,practice),null);
fs.mkdirSync('docs/evidence/2026-10-04-m3-first-motion',{recursive:true});fs.writeFileSync('docs/evidence/2026-10-04-m3-first-motion/validation.json',JSON.stringify({version:release.label,formalInstances:tasks.length,coverage,result:'passed',claim:'Simulated state/DOM only. No browser, iPad or deployment acceptance.'},null,2)+'\n');
console.log('PASS: '+tasks.length+' formal motion first responses persist across undo/reset/reload; 5 visible stage flows, malformed records, old exposure and reversible practice (simulated DOM).');
