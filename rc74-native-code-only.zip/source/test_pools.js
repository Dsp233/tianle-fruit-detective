'use strict';
const assert=require('assert'),{boot}=require('./test_support'),{solveStage}=require('./test_solutions');
const b=boot(),pools=b.value('GENERATED_POOLS'),demos=b.value('DEMO_TASKS');let verified=0;
for(const [sid,tasks] of Object.entries(pools)){
 const originals=b.value(`(()=>{const t=STAGED_TASKS[${JSON.stringify(sid)}];return [practiceFor(${JSON.stringify(sid)}).task,t.transfer,t.independent,t.independent2,t.delayed]})()`),seen=new Set();
 for(const t of [...originals,...Object.values(tasks),demos[sid]]){b.ctx.__case=t;const fp=b.value('taskFingerprint(__case)');assert(!seen.has(fp),sid+' repeats an actual mathematical model');seen.add(fp)}
 for(const t of Object.values(tasks)){
  b.ctx.__case=t;b.run('draft=freshDraft();');const actor={last:null,click(action,data={}){if(action==='check'){this.last={gradingResult:b.value('taskAdapter(__case).grade(__case).ok')?'correct':'incorrect',operationSummary:b.value('draft.work')};return}b.ctx.__action=action;b.ctx.__data=data;b.run('taskAdapter(__case).act(__action,__data,__case)')}};
  solveStage(actor,t);assert(actor.last.gradingResult==='correct');verified++;
 }
}
for(const [sid,t] of Object.entries(demos)){
 b.click('demo',{code:sid});const groups=b.value('demoGroups(taskNow()).length');assert(groups>0);for(let i=0;i<groups;i++)b.click('demoNext');assert.equal(b.value('taskAdapter(taskNow()).grade(taskNow()).ok'),true,t.id+' legal action replay reaches goal');
 b.click('check');assert.equal(b.value('saved.attempts.length'),0,'playback never creates child attempt');b.click('demoReset');assert.equal(b.value('demoCursor'),0);assert.equal(b.value('taskAdapter(taskNow()).state(taskNow()).moves'),0,'replay restores initial state');
 b.click('demoSpeak');assert(b.spoken.at(-1)?.length,'demonstration narration available separately');
}
console.log(`PASS: ${verified} new finite reserve/review models, ${Object.keys(demos).length} distinct real action demonstrations, replay/state grading and no child assessment credit (simulated DOM).`);
