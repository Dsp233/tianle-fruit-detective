'use strict';
const assert=require('assert'),fs=require('fs'),{execFileSync}=require('child_process');
const {boot}=require('./test_support'),core=require('./competition'),{COMPETITION_REVIEWED:families,competitionCreate:create}=require('./competition_reviewed'),{freshOracle,colorings,walks}=require('./competition_fresh_oracles');
const evidence='docs/evidence/2026-10-07-rc64',baseline='6d5627938a575792a9ca6f9e99b562ed1c6e191d';
const n=v=>String(v).includes('/')?String(v).split('/').map(Number).reduce((a,b)=>a/b):Number(v);
function select(app,ids){if(app.value('view')!=='home')app.click('topicExit');app.click('topicClear');for(const code of ids)app.click('topicSelect',{code});app.click('topicStart')}
function solve(app,wrong=false){const t=app.value('taskNow()');app.click('competitionPick',{index:String(wrong?(t.answer+1)%5:t.answer)});app.click('check');assert.equal(app.value('feedback.ok'),!wrong);return t}
function install(app,t){app.run('saved.topicPractice.selectedTopicIds='+JSON.stringify(t.competition.topicIds)+';saved.topicPractice.session={mode:"competition-v2",id:"rc64-fixture",topicIds:'+JSON.stringify(t.competition.topicIds)+',planSeed:1,total:10,cursor:0,items:[{view:"competition",code:'+JSON.stringify(t.id)+',taskId:'+JSON.stringify(t.id)+',contentVersion:93,recipe:'+JSON.stringify(t.competition.recipe)+',openedAt:Date.now(),passed:false,draft:null,feedback:null}]};topicOpenCurrent()')}

// Presentation keeps exact values and the legacy mathematical identity.
assert.equal(core.competitionRatioText(99000,100),'990');assert.equal(core.competitionRatioText(1,16),'0.0625');assert.equal(core.competitionRatioText(1,3),'1/3');assert.equal(core.competitionRatioText(-1,8),'-0.125');assert.equal(core.competitionRatioText(100,100),'1');assert.equal(core.competitionRatioText(0,16),'0');assert.equal(core.competitionRatioText(1,2**40),'0.0000000000009094947017729282379150390625');
const price=create({engine:3,familyId:'percentRoundTrip',seed:38});assert(price.competition.methods[0].steps[0].includes('=990 元'));assert(!JSON.stringify(price).includes('990.0000000000001'));assert.equal(price.options[price.answer],'9');
for(const f of families.filter(f=>f.origin!=='rc64-structure'))for(let seed=1;seed<=128;seed++){
 const t=create({engine:3,familyId:f.id,seed}),display=[t.prompt,...t.options,...t.competition.methods.flatMap(m=>m.steps),t.competition.extension.prompt,t.competition.extension.solution].join(' ');
 assert(!/\d+\.\d{12,}/.test(display),f.id+' unformatted long decimal');
}

// Scope snapshots, genuine wrong feedback and all four reload states.
const stateCases=[];
for(const kind of ['unanswered','selected','wrong','correct']){
 const a=boot();select(a,['A02']);const t=a.value('taskNow()');a.inputCompetition('notes','我的思路保留');
 if(kind==='selected')a.click('competitionPick',{index:String(t.answer)});
 if(kind==='wrong')solve(a,true);if(kind==='correct')solve(a);
 const b=boot(a.storage);b.click('topicResume');if(kind==='correct')b.click('topicPrevious');assert.equal(b.value('taskNow().id'),t.id);assert.equal(b.value('draft.work.notes'),'我的思路保留');
 if(kind==='wrong'){assert.equal(b.value('feedback.ok'),false);assert.equal(b.value('topicCurrent().passed'),false);solve(b);assert.equal(b.value('saved.competition.attempts[0].firstCorrect'),false)}
 if(kind==='correct'){assert.equal(b.value('feedback.ok'),true);const before=b.value('saved.competition.attempts.length');b.click('check');assert.equal(b.value('saved.competition.attempts.length'),before);b.click('next');assert.equal(b.value('topicSession().cursor'),1)}
 if(kind==='selected'){assert.equal(b.value('draft.choice'),t.answer);assert.equal(b.value('feedback'),null)}
 if(kind==='unanswered')assert.equal(b.value('draft.choice'),-1);
 stateCases.push(kind);
}
const empty=boot();empty.click('topicStart');assert.equal(empty.value('topicSession()'),null);empty.click('topicSelect',{code:'A02'});empty.click('topicClear');empty.click('topicStart');assert.equal(empty.value('topicSession()'),null);assert(!empty.root.innerHTML.includes('出题范围：0'));
const switched=boot();select(switched,['A02']);const prior=switched.value('taskNow().id');switched.click('topicExit');switched.click('topicClear');switched.click('topicSelect',{code:'N04'});switched.click('topicResume');assert.equal(switched.value('taskNow().id'),prior);assert.deepEqual(switched.value('topicSession().topicIds'),['A02']);switched.click('topicExit');switched.click('topicStart');assert.deepEqual(switched.value('topicSession().topicIds'),['N04']);
const solo=boot(),soloRounds=[];
for(const topic of core.COMPETITION_TOPIC_IDS){select(solo,[topic]);const used=[];for(let i=0;i<10;i++){const t=solve(solo);assert.deepEqual(t.competition.topicIds,[topic]);used.push(t.competition.recipe.familyId);solo.click('next')}assert.equal(solo.value('view'),'topicSummary');soloRounds.push({topic,families:used})}
const scopes=[['R01','G02'],['C02','D03'],['N04','D03'],['S01','C02'],['A02','N02'],['A02','L02','N02'],['A01','A03','R01','R03','L01','L02','N03','N04','C02','D03']],scopeRounds=[];
for(const ids of scopes){const a=boot();select(a,ids);const seen=[];for(let i=0;i<10;i++){const t=solve(a);assert(t.competition.topicIds.every(id=>ids.includes(id)));seen.push(t.competition.recipe.familyId);a.click('next')}scopeRounds.push({ids,families:seen})}
assert(!require('./competition_reviewed').competitionReviewedEligible(['A02','N02']).some(f=>f.id==='consecutiveRepresentations'));

// Hint speech is gated, read-only, interruptible and ignores obsolete callbacks.
const voice=boot();select(voice,['A04']);let t=voice.value('taskNow()');const beforeHint=voice.value('JSON.stringify(saved.competition)');voice.click('competitionReadHint');assert.equal(voice.spoken.length,0);assert.equal(voice.value('JSON.stringify(saved.competition)'),beforeHint);
voice.click('competitionRead');assert.equal(voice.value('competitionHistory(taskNow()).hinted'),false);
voice.click('competitionHint');const afterHint=voice.value('JSON.stringify(saved.competition)');assert(voice.root.innerHTML.includes('competitionReadHint'));
voice.click('competitionReadHint');assert.equal(voice.spoken.at(-1),voice.value('competitionSpeechText(taskNow().competition.hints[0])'));const stopped=voice.utterances.at(-1);voice.click('competitionStopSpeech');assert.equal(voice.value('speechMessage'),'朗读已停止。');stopped.onend();assert.equal(voice.value('speechMessage'),'朗读已停止。');
voice.click('competitionReadHint');voice.utterances.at(-1).onend();assert.equal(voice.value('speechMessage'),'朗读已结束。');assert.equal(voice.value('JSON.stringify(saved.competition)'),afterHint);
voice.click('competitionReadHint');const old=voice.utterances.at(-1);voice.click('competitionReadOption',{index:'0'});old.onerror();assert.equal(voice.value('speechMessage'),'正在尝试朗读…');voice.utterances.at(-1).onerror();assert(voice.value('speechMessage').startsWith('朗读未成功'));assert.equal(voice.value('draft.choice'),-1);
voice.click('competitionReadHint');const priorVoice=voice.utterances.at(-1);solve(voice);voice.click('next');priorVoice.onerror();assert.equal(voice.value('speechMessage'),'');
const restoredVoice=boot(voice.storage);restoredVoice.click('topicResume');assert.equal(restoredVoice.spoken.length,0);
const unsupported=boot();select(unsupported,['A02']);unsupported.click('competitionHint');unsupported.run('delete window.speechSynthesis');unsupported.click('competitionReadHint');assert(unsupported.value('speechMessage').includes('暂不支持'));assert.equal(unsupported.value('competitionHistory(taskNow()).hinted'),true);
const assisted=boot();select(assisted,['A04']);for(let i=0;i<2;i++){assisted.click('competitionHint');for(let j=0;j<5;j++)assisted.click('competitionReadHint');solve(assisted);assisted.click('next')}assert.equal(assisted.value('competitionAdaptiveProfile(saved.competition.attempts,saved.competition.extensions,["A04"],saved.competition.extensionViews,saved.competition.views).topics.A04.band'),1);assert.equal(assisted.value('saved.competition.attempts.filter(a=>a.firstAttempt).length'),2);

// Real RC63 storage/unfinished recipe resumes without resetting errors/help.
const legacyHtml=execFileSync('git',['show',baseline+':index.html'],{maxBuffer:8*1024*1024}).toString(),oldApp=boot({},2000000000000,legacyHtml);select(oldApp,['A04']);oldApp.click('competitionHint');oldApp.inputCompetition('notes','RC63 原草稿');const oldTask=solve(oldApp,true),migrated=boot(oldApp.storage);migrated.click('topicResume');assert.equal(migrated.value('taskNow().id'),oldTask.id);assert.equal(migrated.value('draft.work.notes'),'RC63 原草稿');assert.equal(migrated.value('feedback.ok'),false);assert.equal(migrated.value('competitionHistory(taskNow()).hinted'),true);solve(migrated);assert.equal(migrated.value('saved.competition.attempts[0].firstCorrect'),false);

// Every new family has meaningful choices, independent main and transfer answers.
const additions=[];
for(const f of families.filter(f=>f.origin==='rc64-structure')){
 const unique=new Set();
 for(let seed=1;seed<=128;seed++){
  const task=create({engine:3,familyId:f.id,seed}),c=task.competition,expected=freshOracle(f.id,c.math);unique.add(c.signature);
  assert(Math.abs(n(c.answer)-expected.answer)<1e-8);assert(Math.abs(n(c.extension.answer)-expected.extension)<1e-8);assert.equal(task.options.filter(v=>Math.abs(n(v)-expected.answer)<1e-8).length,1);assert.equal(new Set(task.options.map(n)).size,5);
  if(c.topicIds.includes('D03'))assert(task.options.every(v=>n(v)>=0&&n(v)<=1));
 }
 const a=boot(),task=create({engine:3,familyId:f.id,seed:17});install(a,task);assert(!a.root.innerHTML.includes(task.competition.methods[0].name));a.click('competitionRead');assert.equal(a.value('competitionHistory(taskNow()).hinted'),false);solve(a);a.inputCompetition('extension','999999');a.click('competitionExtensionCheck');assert(a.root.innerHTML.includes('<details class="competition-extension" open>'));assert(a.root.innerHTML.includes('再核对改变的是哪条条件。'));a.inputCompetition('extension',task.competition.extension.answer);a.click('competitionExtensionCheck');assert(a.root.innerHTML.includes('<details class="competition-extension" open>'));assert(a.root.innerHTML.includes('✓ '+task.competition.extension.solution));assert.equal(a.value('saved.competition.extensions[0].correct'),false);assert.equal(a.value('saved.competition.extensions[1].correct'),true);assert.equal(a.value('saved.competition.extensions[1].firstAttempt'),false);
 const r=boot(a.storage);r.click('topicResume');r.click('topicPrevious');assert.equal(r.value('draft.work.extensionInput'),task.competition.extension.answer);assert.equal(r.value('Object.values(saved.competition.extensionViews)[0].firstCorrect'),false);
 additions.push({id:f.id,topicIds:f.topicIds,level:f.level,seeds:128,distinctMathematicalInstances:unique.size});
}
// Exhaustive small condition domains, independent of sampling seeds.
let rotationalCases=0,stockCases=0;
for(let positions=4;positions<=7;positions++)for(let red=2;red<=positions-2;red++){const c=colorings(positions,red);assert(c.rotating<=c.fixed);rotationalCases++}
for(let k=3;k<=5;k++)for(let red=1;red<k;red++)for(let blue=k+1;blue<=k+4;blue++)for(let green=k+1;green<=k+4;green++){
 const caps=[red,blue,green],c=freshOracle('worstCaseColors',{caps,k});assert.equal(c.answer,caps.reduce((s,v)=>s+Math.min(v,k-1),0)+1);assert.equal(c.extension,caps.reduce((s,v)=>s+Math.min(v,k),0)+1);stockCases++;
}
assert.equal(freshOracle('stepwiseRoute',{w:2,h:1,x:1,y:0}).answer,1/2);assert.equal(freshOracle('stepwiseRoute',{w:2,h:1,x:1,y:0}).extension,2/3);assert.equal(walks({w:2,h:1,x:1,y:0}).length,3);
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(evidence+'/rc64-functional.json',JSON.stringify({release:require('./version.json').label,result:'passed',baseline,corrected:['exact finite decimal/fraction display','wrong feedback restored from validated choice after reload','variation submission keeps feedback panel open'],stateCases,singleThemeRounds:soloRounds,multiThemeRounds:scopeRounds,hintSpeech:['not available before reveal','same visible text','read-only repeated playback','stop/end/error/obsolete callback handling','no autoplay on reload','unsupported keeps help fact','two hinted problems, not ten repeated plays, affect difficulty'],newStructures:additions,exhaustiveConditionDomains:{rotationalCases,stockCases},limits:['Node VM handler and speech callback simulation, not real audio','128 seeds do not exhaust larger parameter domains','real iPad and child learning outcomes require separate observation']},null,2)+'\n');
console.log('PASS RC64: exact displays, 33 solo and 9 multi-theme rounds, feedback reload, hint speech, RC63 migration, 8 independently solved additions.');
