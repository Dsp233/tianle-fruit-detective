'use strict';
// Program verification of the actual bundled site. The DOM and voice API are
// simulated; browser layout, real sound and child outcomes are not inferred.
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os'),{execFileSync}=require('child_process');
const rel=require('./competition_relations'),rules=require('./competition_rules'),models=require('./competition_rule_models');
const {rulesOracle}=require('./competition_rules_oracle'),{competitionCreate:create,COMPETITION_REVIEWED:families,competitionReviewedEligible:eligible}=require('./competition_reviewed');
const {COMPETITION_TOPIC_IDS}=require('./competition'),{boot}=require('./test_support');
const root=path.resolve(__dirname,'..'),evidence=path.join(root,'docs/evidence/2026-10-07-rc65-local');
const registered=JSON.parse(fs.readFileSync(path.join(root,'docs/rc65-design-tasks.json'),'utf8'));
const localHtml=fs.readFileSync(path.join(root,'local-preview/index.html'),'utf8');
const n=x=>rel.decimal(rel.number(x)),close=(a,b)=>assert(Math.abs(n(a)-b)<1e-8,`${a} != independent ${b}`);
const displayStrings=x=>typeof x==='string'?[x]:Array.isArray(x)?x.flatMap(displayStrings):x&&typeof x==='object'?Object.values(x).flatMap(displayStrings):[];
function verify(c){
 close(c.answer,rulesOracle(c.math));close(c.extension.answer,rulesOracle(c.extension.math));
 assert.equal(c.options.length,5);assert.equal(new Set(c.options.map(n)).size,5);assert.equal(c.options.filter(x=>Math.abs(n(x)-n(c.answer))<1e-10).length,1);
 assert(c.methods.every(m=>m.frames.length===m.steps.length&&m.steps.length>=2));
 assert(c.extension.topicIds.every(id=>models[c.math.variant].topics.includes(id)));
 assert(!/\d+\.\d{12,}/.test(displayStrings([c.prompt,c.methods,c.extension.prompt,c.extension.solution]).join(' ')),'visible text contains an unformatted long decimal');
}
const expected=['68','7','9','18','48','49','64','4','39','30'];
const examples=[...registered.exploration,...registered.reserved].map((task,i)=>{
 const c=rules.create(task.variant,task.params,task.context);verify(c);assert.equal(c.answer,expected[i]);
 return {id:task.id,role:i<6?'exploration':'reserved',model:c.relationModel.key,variant:task.variant,topicIds:models[task.variant].topics,context:task.context,params:task.params,requirements:task.requirements||[task.focus],prompt:c.prompt,answer:c.answer,methods:c.methods,hints:c.ruleHints,misconceptions:c.misconceptions,extension:c.extension,result:'passed'};
});
assert(examples.slice(0,6).filter(x=>x.topicIds.length>1).length>=2);
const configurations=[];let generatedPairs=0;
for(const f of rules.catalog){
 const identities=new Set(),positions=Array(5).fill(0);
 for(let seed=1;seed<=128;seed++){
  const t=create({engine:3,familyId:f.id,seed}),c=t.competition;verify(c);
  assert.deepEqual(c.topicIds,f.topicIds);assert.equal(t.options[t.answer],c.answer);
  identities.add(c.signature);positions[t.answer]++;generatedPairs++;
 }
 configurations.push({id:f.id,model:models[f.id.slice(5)].model,reasoningKey:f.reasoningKey,topicIds:f.topicIds,level:f.level,seeds:128,distinctMathematicalInstances:identities.size,answerPositions:positions});
}
assert.equal(configurations.length,13);assert.equal(new Set(configurations.map(c=>c.model)).size,6);
// A different reviewed context is presentation, not a new mathematical identity.
const contextInstances=new Map();let contextAlias=null;
for(let seed=1;seed<=512&&!contextAlias;seed++){
 const t=create({engine:3,familyId:'rule-join-open',seed}),key=JSON.stringify(t.competition.math.params),prior=contextInstances.get(key);
 if(prior&&prior.competition.math.context!==t.competition.math.context)contextAlias=[prior,t];else contextInstances.set(key,t);
}
assert(contextAlias,'context-identity fixture not found');
assert.equal(contextAlias[0].id,contextAlias[1].id);assert.equal(contextAlias[0].competition.extension.signature,contextAlias[1].competition.extension.signature);

// Exhaustively enumerate bounded subsets of the declared domains, independent
// of RNG sampling. This is not a claim to exhaust all production combinations.
const subsets={};
function domain(key,params,context){const c=rel.compile(models[key],params,context);close(c.answer,rulesOracle({variant:key,params}));subsets[key]=(subsets[key]||0)+1}
for(let count=2;count<=5;count++)for(let piece=7;piece<=12;piece++)for(let lap=1;lap<=3;lap++)if(piece>2*lap){
 domain('join-open',{n:count,piece,lap},'panels');
 domain('join-piece',{n:count,total:count*piece-(count-1)*lap,lap},'panels');
 if(count>=3)domain('join-closed',{n:count,piece,lap},'ribbon');
}
for(let intervals=2;intervals<=8;intervals++)for(let gap=1;gap<=4;gap++)for(const key of ['posts-both','posts-neither'])domain(key,{distance:intervals*gap,gap},'trail');
for(let a=1;a<=3;a++)for(let b=1;b<=3;b++)if(a!==b)for(let low=1;low<=3;low++)for(let high=4;high<=6;high++){
 domain('weighted-mean',{a,b,low,high},'teams');domain('weighted-score',{a,b,high,mean:`${a*low+b*high}/${a+b}`},'teams');
}
for(let a=1;a<=3;a++)for(let b=a+1;b<=5;b++)for(let unit=1;unit<=4;unit++){
 domain('ratio-length',{a,b,perimeter:2*(a+b)*unit},'enclosure');domain('ratio-perimeter',{a,b,width:a*unit},'enclosure');
}
for(let d1=2;d1<=4;d1++)for(let d2=2;d2<=4;d2++)for(let k=1;k<=3;k++){
 domain('fraction-reverse',{d1,d2,left:(d1-1)*(d2-1)*k},'supplies');
 if(d1*d2>d1+d2)domain('fraction-original',{d1,d2,start:d1*d2*k},'supplies');
}
for(let size=2;size<=4;size++)for(let single=3;single<=4;single++)for(let pack=1;pack<size*single;pack++)for(let count=size+1;count<=size+4;count++)for(const key of ['packs-exact','packs-enough'])domain(key,{size,single,pack,count},'brushes');
const invalid=[
 ['join-open',{n:3,piece:6,lap:3},'panels'],['join-piece',{n:3,total:10,lap:2},'panels'],
 ['posts-both',{distance:61,gap:10},'trail'],['weighted-mean',{a:2,b:2,low:7,high:12},'teams'],
 ['weighted-mean',{a:2,b:3,low:7,high:7},'teams'],['weighted-score',{a:3,b:2,high:14,mean:1},'teams'],
 ['ratio-length',{a:3,b:2,perimeter:60},'enclosure'],['fraction-original',{d1:2,d2:2,start:12},'water'],
 ['fraction-reverse',{d1:3,d2:4,left:1},'supplies'],['packs-exact',{size:4,single:5,pack:-1,count:11},'brushes'],
 ['packs-enough',{size:4,single:5,pack:20,count:11},'brushes'],['packs-exact',{size:4,single:5,pack:13,count:41},'brushes']
];
for(const [key,p,context]of invalid)assert.throws(()=>rel.compile(models[key],p,context),key+' invalid domain admitted');
assert.throws(()=>rel.q(Number.MAX_SAFE_INTEGER+1));assert.throws(()=>rel.q(1,0));
assert.throws(()=>rules.create('join-open',{n:3,piece:24,lap:2},'unreviewed'));
assert.throws(()=>rel.compile({...models['join-open'],contexts:{panels:'答案前泄漏 {gross}'}},{n:3,piece:24,lap:2},'panels'),/Unbound display gross/);
close(rel.compile(models['fraction-reverse'],{d1:3,d2:4,left:1},'water').answer,2);
const tied=rules.create('packs-enough',{size:4,single:5,pack:15,count:7},'brushes');verify(tied);assert.equal(tied.answer,'30');
assert(tied.methods[0].frames[1].rows.filter(row=>n(row[3])===30).length===2,'minimum cost remains unique even if two plans tie');

// RC64 replay: preserve all core contracts, including the six adapters. The
// RC66 product audit permits only additive worked details for the two weighted
// variations; the original explanation and every other field stay intact.
function contract(t){const c=t.competition;return {id:t.id,contentVersion:t.contentVersion,prompt:t.prompt,options:t.options,optionIds:t.optionIds,answer:t.answer,math:c.math,signature:c.signature,recipe:c.recipe,methods:c.methods.map(m=>({name:m.name,steps:m.steps})),extension:{prompt:c.extension.prompt,answer:c.extension.answer,solution:c.extension.solution,signature:c.extension.signature,key:c.extension.key}}}
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'amc8-rc64-'));
let preservedContracts=0,reviewedExplanationAppendices=0;const baseline=registered.baseline;
const baselineHtml=execFileSync('git',['show',baseline+':index.html'],{cwd:root,maxBuffer:8*1024*1024}).toString();
try{
 for(const name of ['competition','competition_catalog','competition_expansion','competition_fresh','competition_reviewed'])fs.writeFileSync(path.join(tmp,name+'.js'),execFileSync('git',['show',baseline+':source/'+name+'.js'],{cwd:root}));
 const original=require(path.join(tmp,'competition_reviewed'));
 for(const f of families.filter(f=>f.origin!=='rc65-rules'))for(let seed=1;seed<=128;seed++){
  const recipe={engine:3,familyId:f.id,seed},actual=contract(create(recipe)),expected=contract(original.competitionCreate(recipe));
  if(['natural-weighted','natural-fractionWeighted'].includes(f.id)){
   assert(actual.extension.solution.startsWith(expected.extension.solution),f.id+' original explanation was replaced');
   if(actual.extension.solution!==expected.extension.solution)reviewedExplanationAppendices++;
   actual.extension.solution=expected.extension.solution;
  }
  assert.deepEqual(actual,expected,f.id+' RC64 core contract changed');preservedContracts++;
 }
}finally{fs.rmSync(tmp,{recursive:true,force:true})}
assert.equal(preservedContracts,127*128);
assert.equal(reviewedExplanationAppendices,2*128);

// Local bundle isolation and genuine RC64 storage migration are separate tests.
const newApp=(seed={})=>boot(seed,2000000000000,localHtml);
const live=newApp({tianle_amc8_question_design_v1:'original progress sentinel'});
assert.equal(live.value('STORE'),'tianle_amc8_rc67_local_v1');live.run('persist()');
assert.equal(live.storage.tianle_amc8_question_design_v1,'original progress sentinel');
assert(live.storage.tianle_amc8_rc67_local_v1);
assert.equal((live.root.innerHTML.match(/data-action="topicSelect"/g)||[]).length,33);
function select(app,ids){if(app.value('view')!=='home')app.click('topicExit');app.click('topicClear');for(const code of ids)app.click('topicSelect',{code});app.click('topicStart')}
function solve(app){const t=app.value('taskNow()');app.click('competitionPick',{index:String(t.answer)});app.click('check');assert.equal(app.value('feedback.ok'),true);return t}
function fixture(app,t){app.run(`saved.topicPractice.selectedTopicIds=${JSON.stringify(t.competition.topicIds)};saved.topicPractice.session={mode:'competition-v2',id:'rc65-fixture',topicIds:${JSON.stringify(t.competition.topicIds)},planSeed:1,total:10,cursor:0,items:[{view:'competition',code:${JSON.stringify(t.id)},taskId:${JSON.stringify(t.id)},contentVersion:93,recipe:${JSON.stringify(t.competition.recipe)},openedAt:Date.now(),passed:false,draft:null,feedback:null}]};topicOpenCurrent()`)}
const integration=[];
for(const f of rules.catalog){
 const app=newApp(),t=create({engine:3,familyId:f.id,seed:17});fixture(app,t);
 assert(!app.root.innerHTML.includes('competition-solutions'));assert(!app.root.innerHTML.includes(t.competition.methods[0].name));
 app.click('competitionReadStep',{index:'0'});assert.equal(app.spoken.length,0);
 solve(app);assert(app.root.innerHTML.includes('competition-solutions'));assert(app.root.innerHTML.includes('rule-figure'));
 app.click('competitionStep',{index:String(t.competition.methods[0].steps.length-1)});
 app.inputCompetition('extension','999999');app.click('competitionExtensionCheck');assert.equal(app.value('draft.work.extensionResult.ok'),false);
 app.inputCompetition('extension',t.competition.extension.answer);app.click('competitionExtensionCheck');assert.equal(app.value('draft.work.extensionResult.ok'),true);
 const reloaded=newApp(app.storage);reloaded.click('topicResume');reloaded.click('topicPrevious');
 assert.equal(reloaded.value('taskNow().id'),t.id);assert.equal(reloaded.value('draft.work.step'),t.competition.methods[0].steps.length-1);
 assert.equal(reloaded.value('Object.values(saved.competition.extensionViews)[0].firstCorrect'),false);
 const attempts=reloaded.value('saved.competition.attempts.length');reloaded.click('check');assert.equal(reloaded.value('saved.competition.attempts.length'),attempts);
 reloaded.click('next');assert.equal(reloaded.value('topicSession().cursor'),1);
 integration.push({family:f.id,checked:['pre-answer gating','main answer','step frame','wrong/correct variation','reload','next']});
}
const hints=newApp(),hintTask=create({engine:3,familyId:'rule-join-open',seed:11});fixture(hints,hintTask);
const aliasApp=newApp();fixture(aliasApp,contextAlias[0]);aliasApp.click('competitionPick',{index:String((contextAlias[0].answer+1)%5)});aliasApp.click('check');
fixture(aliasApp,contextAlias[1]);solve(aliasApp);assert.equal(aliasApp.value('saved.competition.attempts.at(-1).firstCorrect'),false,'changing only context cannot reset a first error');
hints.click('competitionReadHint');assert.equal(hints.spoken.length,0);
hints.click('competitionHint');hints.click('competitionReadHint');assert.equal(hints.spoken.at(-1),hints.value('competitionSpeechText(taskNow().competition.hints[0])'));
hints.click('competitionHintMore');assert.equal(hints.value('draft.work.hintLevel'),2);assert(hints.root.innerHTML.includes('data-scene-kind="scene-join"'));assert.equal(hints.value('taskNow().competition.hintDiagram.lap'),hintTask.competition.math.params.lap);assert.equal(hints.value('taskNow().competition.hintDiagram.n'),hintTask.competition.math.params.n);
const facts=hints.value('JSON.stringify(saved.competition)');hints.click('competitionReadHint');assert.equal(hints.spoken.at(-1),hints.value('competitionSpeechText(taskNow().competition.hints[1])'));assert.equal(hints.value('JSON.stringify(saved.competition)'),facts);
hints.inputCompetition('notes','连接处不是段数');const crossed=(hintTask.answer+1)%5;hints.click('competitionEliminate',{index:String(crossed)});
const hintReload=newApp(hints.storage);hintReload.click('topicResume');assert.equal(hintReload.value('draft.work.hintLevel'),2);assert.equal(hintReload.value('draft.work.notes'),'连接处不是段数');assert.deepEqual(hintReload.value('draft.work.eliminated'),[crossed]);assert.equal(hintReload.spoken.length,0);
solve(hintReload);assert.equal(hintReload.value('saved.competition.attempts[0].firstCorrect'),false);assert.equal(hintReload.value('saved.competition.attempts[0].hinted'),true);

const reloadStates=[];
for(const state of ['unanswered','selected','wrong','correct']){
 const a=newApp(),t=create({engine:3,familyId:'rule-join-open',seed:29});fixture(a,t);a.inputCompetition('notes','刷新保留');
 const misconception=t.competition.misconceptions.find(m=>n(m.value)!==n(t.competition.answer)&&t.options.includes(m.value));assert(misconception);
 if(state==='selected')a.click('competitionPick',{index:String(t.answer)});
 if(state==='wrong'){a.click('competitionPick',{index:String(t.options.indexOf(misconception.value))});a.click('check');assert.equal(a.value('feedback.text'),misconception.feedback)}
 if(state==='correct')solve(a);
 const b=newApp(a.storage);b.click('topicResume');if(state==='correct')b.click('topicPrevious');assert.equal(b.value('taskNow().id'),t.id);assert.equal(b.value('draft.work.notes'),'刷新保留');
 if(state==='selected'){assert.equal(b.value('draft.choice'),t.answer);assert.equal(b.value('feedback'),null)}
 if(state==='unanswered')assert.equal(b.value('draft.choice'),-1);
 if(state==='wrong'){assert.equal(b.value('feedback.text'),misconception.feedback);solve(b);assert.equal(b.value('saved.competition.attempts[0].firstCorrect'),false)}
 if(state==='correct')assert.equal(b.value('topicCurrent().passed'),true);
 reloadStates.push(state);
}
const adapted=[];
for(const id of Object.keys(rules.adapters)){
 const app=newApp(),t=create({engine:3,familyId:id,seed:11});fixture(app,t);assert.equal(t.competition.hints.length,2);solve(app);
 for(let method=0;method<t.competition.methods.length;method++)for(let step=0;step<t.competition.methods[method].steps.length;step++){
  app.click('competitionMethod',{index:String(method)});app.click('competitionStep',{index:String(step)});assert(app.root.innerHTML.includes('rule-figure'));
 }
 const reloaded=newApp(app.storage);reloaded.click('topicResume');reloaded.click('topicPrevious');assert.equal(reloaded.value('draft.work.method'),t.competition.methods.length-1);
 adapted.push({id,methods:t.competition.methods.map(m=>({name:m.name,frames:m.frames})),hints:t.competition.hints});
}
const old=boot({},2000000000000,baselineHtml);select(old,['A03']);old.click('competitionHint');old.inputCompetition('notes','RC64 未完成草稿');
const oldTask=old.value('taskNow()');old.click('competitionPick',{index:String((oldTask.answer+1)%5)});old.click('check');
const migrated=boot(old.storage);migrated.click('topicResume');assert.equal(migrated.value('taskNow().id'),oldTask.id);assert.equal(migrated.value('draft.work.notes'),'RC64 未完成草稿');assert.equal(migrated.value('feedback.ok'),false);assert.equal(migrated.value('competitionHistory(taskNow()).hinted'),true);
solve(migrated);assert.equal(migrated.value('saved.competition.attempts[0].firstCorrect'),false);

const normalRounds=[],normalFamilies=new Set();
for(const ids of [...COMPETITION_TOPIC_IDS.map(id=>[id]),['R01','D02'],['R01','G01'],['A02','A03','R01','R02','G01','D02'],['A02','N02']]){
 const app=newApp();select(app,ids);const picked=[];
 for(let i=0;i<10;i++){const t=solve(app);assert(t.competition.topicIds.every(id=>ids.includes(id)));assert((t.competition.extension.topicIds||t.competition.topicIds).every(id=>ids.includes(id)));picked.push(t.competition.recipe.familyId);normalFamilies.add(t.competition.recipe.familyId);app.click('next')}
 assert.equal(app.value('view'),'topicSummary');normalRounds.push({selected:ids,families:picked});
}
assert([...normalFamilies].some(f=>f.startsWith('rule-'))&&[...normalFamilies].some(f=>!f.startsWith('rule-')));
assert(!eligible(['R01']).some(f=>f.origin==='rc65-rules'));assert(!eligible(['A02','N02']).some(f=>f.id==='rule-weighted-mean'));
const all=newApp();select(all,COMPETITION_TOPIC_IDS);assert.equal(all.value('topicSession().total'),10);
const scope=all.value('taskNow().competition.topicIds');assert(scope.length<33,'selecting all topics is not a per-question quota');

fs.mkdirSync(evidence,{recursive:true});
fs.writeFileSync(path.join(evidence,'rc65-method-verification.json'),JSON.stringify({release:require('./version.json'),baseline,result:'passed',registration:registered.registeredAt,registrationLimit:'同一实施者预登记，不是外部盲测。',modelCount:6,configurations,generatedMainVariationPairs:generatedPairs,fullSubsetEnumeration:subsets,invalidDomainsRejected:invalid.length+4,preservedRC64Contracts:preservedContracts,reviewedExplanationAppendices:{recipes:reviewedExplanationAppendices,families:["natural-weighted","natural-fractionWeighted"],policy:"Only additive worked details; original solution prefix and all other contract fields preserved"},contextIdentity:{result:'passed',recipes:contextAlias.map(t=>t.competition.recipe),contexts:contextAlias.map(t=>t.competition.math.context),sameSignature:contextAlias[0].competition.signature,firstWrongRetained:true},examples,adaptedLegacyFamilies:adapted,integratedNewConfigurations:integration,reloadStates,normalRounds,localStorageKey:live.value('STORE'),browser:{status:'pending',reason:'No local browser executable; Playwright download returned a Site Unavailable HTML page, package installation is blocked by runtime permissions.'},limits:['6 models with 13 goal/condition configurations; numeric seeds and context changes are not new reasoning structures','Enumeration covers explicitly bounded subsets, not all possible values','No arbitrary topic-combination or free-form question-generation claim','Node VM DOM and speech callback simulation do not verify layout or real pronunciation','No public deployment or child outcome evaluation']},null,2)+'\n');
console.log(`PASS RC65: 6 exploration + 4 reserved tasks; ${generatedPairs} independent main/variation pairs; ${Object.values(subsets).reduce((s,v)=>s+v,0)} bounded exhaustive cases; ${preservedContracts} preserved RC64 core contracts with ${reviewedExplanationAppendices} reviewed explanation appendices; local-store isolation, 13 new and 6 old UI flows, four reload states, 37 normal rounds. Browser pending.`);
