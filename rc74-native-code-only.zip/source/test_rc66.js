'use strict';
const assert=require('assert'),fs=require('fs');
const {competitionCreate:create}=require('./competition');
const {competitionReviewedRecipe:currentRecipe,COMPETITION_REVIEWED:families}=require('./competition_reviewed');
// This suite freezes the RC66 mathematical protocol; current normal-entry
// behavior is checked below and in the RC67 coverage/normal-entry suites.
const recipe=(id,seed)=>({...currentRecipe(id,seed),generatorRevision:2});
const {rulesOracle}=require('./competition_rules_oracle');
const rules=require('./competition_rules'),rel=require('./competition_relations'),identity=require('./competition_identity');
const {boot}=require('./test_support'),{install,solve}=require('./test_rc66_defects');
const evidence='docs/evidence/2026-10-08-rc66-local';fs.mkdirSync(evidence,{recursive:true});
const numeric=x=>String(x).split('/').map(Number).reduce((a,b)=>a/b),close=(a,b)=>assert(Math.abs(numeric(a)-b)<1e-8,`${a} != independently solved ${b}`);
function purchase(p,enough){
 const plans=[];for(let b=0;b<=Math.ceil(p.count/p.size);b++)for(let i=0;i<=p.count;i++){
  const bought=b*p.size+i;if(enough?bought>=p.count:bought===p.count)plans.push({b,i,bought,cost:b*p.pack+i*p.single});
 }return Math.min(...plans.map(p=>p.cost));
}
const coverage={overbuy:0,tie:0,exact:0,divisible:0},unique={overbuy:new Set(),tie:new Set(),exact:new Set()},representatives={};
for(let seed=1;seed<=10000;seed++){
 const t=create(recipe('rule-packs-enough',seed)),c=t.competition,p=c.math.params;
 const exact=purchase(p,false),enough=purchase(p,true);close(c.answer,enough);close(c.extension.answer,exact);
 assert(p.pack>0&&p.pack<p.size*p.single&&p.count>p.size&&p.count<=40);
 let kind='divisible';if(p.count%p.size){const extra=Math.ceil(p.count/p.size)*p.pack;kind=extra<exact?'overbuy':extra===exact?'tie':'exact';unique[kind].add(JSON.stringify(p))}
 coverage[kind]++;representatives[kind]??={recipe:c.recipe,params:p,prompt:t.prompt,exact,enough};
}
for(const k of ['overbuy','tie','exact']){assert(coverage[k]>=1000);assert(unique[k].size>=20)}
let exhaustive=0;
for(let size=3;size<=5;size++)for(let single=3;single<=8;single++)for(let pack=1;pack<size*single;pack++)for(let count=size+1;count<=40;count++){
 const p={size,single,pack,count};for(const enough of [false,true]){const c=rules.create(enough?'packs-enough':'packs-exact',p,'brushes');close(c.answer,purchase(p,enough));exhaustive++}
}
fs.writeFileSync(evidence+'/rc66-generator-coverage.json',JSON.stringify({result:'passed',seeds:10000,coverage,distinct:Object.fromEntries(Object.entries(unique).map(([k,v])=>[k,v.size])),representatives,exhaustive:{domain:'size 3..5; single 3..8; pack 1..size*single-1; count size+1..40; exact and lower-bound constraints',cases:exhaustive},oracle:'independent two-variable purchase enumeration; no generator case labels or answers used as expected values',roundQuota:false},null,2)+'\n');

// An independent arithmetic parser verifies the actual flat expressions.
function arithmetic(source){
 const s=source.replace(/−/g,'-').replace(/×/g,'*').replace(/÷/g,'/').replace(/²/g,'^2').replace(/³/g,'^3');
 assert(/^[\d\s.()+\-*/^]+$/.test(s),s);const tokens=s.match(/\d+(?:\.\d+)?|[()+\-*/^]/g)||[];let i=0;
 function atom(){if(tokens[i]==='('){i++;const v=sum();assert.equal(tokens[i++],')');return v}if(tokens[i]==='-'){i++;return -atom()}if(tokens[i]==='+'){i++;return atom()}const v=Number(tokens[i++]);assert(Number.isFinite(v));return v}
 function power(){const a=atom();if(tokens[i]==='^'){i++;return a**power()}return a}
 function product(){let a=power();while(['*','/'].includes(tokens[i])){const op=tokens[i++],b=power();a=op==='*'?a*b:a/b}return a}
 function sum(){let a=product();while(['+','-'].includes(tokens[i])){const op=tokens[i++],b=product();a=op==='+'?a+b:a-b}return a}
 const v=sum();assert.equal(i,tokens.length,s);return v;
}
const expressionCases=[[['div',16,'2/3'],24],[['div',24,'1/2'],48],[['div',-12,['sub',4,1]],-4],[['mul','2/3',['add',3,2]],10/3],[['sub',5,['add',1,2]],2],[['pow',['pow',2,3],2],64]];
for(const [expr,want]of expressionCases)close(arithmetic(rel.expression(expr,{})),want);
let equations=0,pairs=0;
for(const f of rules.catalog)for(let seed=1;seed<=128;seed++){
 const t=create(recipe(f.id,seed)),c=t.competition;close(c.answer,rulesOracle(c.math));close(c.extension.answer,rulesOracle(c.extension.math));pairs++;
 assert.equal(new Set(t.options.map(numeric)).size,5);
 const content=JSON.stringify([c.title,t.prompt,c.diagram,c.methods,c.ruleHints,c.extension]);assert(!content.includes('单支/棵'));assert(!/\{=?[A-Za-z]/.test(content));
 if(c.math.context==='seedlings')assert(c.title.includes('树苗'));
 if(c.math.variant==='join-piece'&&c.math.context==='ribbon')assert(c.title.includes('彩带'));
 for(const text of [...c.methods.flatMap(m=>m.steps),c.extension.solution])for(const m of text.matchAll(/([\d\s.+\-−×÷/^()]+)\s*[=＝]\s*(-?\d+(?:\/\d+)?(?:\.\d+)?)/g)){
  close(arithmetic(m[1]),numeric(m[2]));equations++;
 }
}
const app=boot();assert.equal(app.value('competitionSpeechText("16 ÷ (2/3) = 24")').replace(/\s/g,''),'16除以3分之2等于24');
assert(app.value('competitionSpeechText("12 ÷ (4 − 1)")').includes('左括号'));

const old=create({engine:3,familyId:'fractionBackwards',seed:121}),fresh=create({engine:3,familyId:'rule-fraction-reverse',seed:23});
assert.equal(identity.key(old),identity.key(fresh));assert.equal(identity.key(old,'extension'),identity.key(fresh,'extension'));
const matrix=[];
for(const reverse of [false,true])for(const exposure of ['wrong','correct','hint','solution']){
 const a=reverse?fresh:old,b=reverse?old:fresh,x=boot();install(x,a,'first');
 if(exposure==='hint')x.click('competitionHint');else solve(x,a,exposure!=='wrong');
 install(x,b,'second');assert.equal(x.value('topicCurrent().passed'),false);assert.equal(x.value('draft.choice'),-1);
 if(exposure==='hint')assert.equal(x.value('draft.work.hintLevel'),0,'shared help facts do not auto-open a hint');
 solve(x,b);assert.equal(x.value('saved.competition.attempts.at(-1).firstCorrect'),false);
 assert.equal(x.value('competitionProgressCounts().first'),['correct','solution'].includes(exposure)?1:0);
 x.run('topicSession().total=1');x.click('next');assert(x.root.innerHTML.includes('0 道未用提示首答正确'),'round summary also excludes the repeated mathematical opportunity');
 x.run('persist()');const reload=boot(x.storage);reload.click('topicResume');assert.equal(reload.value('competitionProgressCounts().first'),['correct','solution'].includes(exposure)?1:0);
 assert.equal(reload.value('topicSession().items[0].taskId'),b.id);assert.equal(reload.value('topicSession().items[0].passed'),true);
 reload.run('saved.competition.attempts=[];saved.competition.extensions=[];persist()');const durable=boot(reload.storage);
 assert.equal(durable.value('competitionProgressCounts().first'),['correct','solution'].includes(exposure)?1:0);
 matrix.push({direction:reverse?'new-to-old':'old-to-new',exposure,result:'passed'});
}
// Unknown first facts remain unknown, even when a clean-looking alias is later solved.
const unknown=boot();install(unknown,old,'unknown');unknown.run('const h=competitionHistory(taskNow());h.attempted=true;CompetitionIdentity.invalidate(saved.competition);persist()');install(unknown,fresh,'after-unknown');solve(unknown,fresh);assert.equal(unknown.value('competitionProgressCounts().first'),0);
const oldHelp=boot();install(oldHelp,fresh,'old-help');oldHelp.click('competitionHint');oldHelp.run('for(const h of Object.values(saved.competition.views)){delete h.recipe;delete h.hintedAt;delete h.hintOrder}persist()');const incomplete=boot(oldHelp.storage);install(incomplete,old,'after-incomplete-help');solve(incomplete,old);assert.equal(incomplete.value('saved.competition.attempts.at(-1).firstCorrect'),false);assert.equal(incomplete.value('saved.competition.attempts.at(-1).priorExposureUnknown'),true);assert.equal(incomplete.value('saved.competition.attempts.at(-1).hinted'),false,'missing unit evidence does not invent an actual hint fact');

// Repeating a solved mathematical problem does not auto-complete a new session.
const clean=boot();install(clean,old,'clean');solve(clean,old);install(clean,fresh,'alias');assert.equal(clean.value('topicCurrent().passed'),false);clean.click('competitionHint');assert.equal(clean.value('competitionProgressCounts().first'),1,'later hints do not erase a real earlier clean first');solve(clean,fresh);assert.equal(clean.value('competitionProgressCounts().first'),1);

// Variations have their own first facts, and are linked only by actual mathematics.
for(const reverse of [false,true]){
 const a=reverse?fresh:old,b=reverse?old:fresh,x=boot();install(x,a,'a');solve(x,a);
 x.inputCompetition('extension','999999');x.click('competitionExtensionCheck');
 install(x,b,'b');solve(x,b);x.inputCompetition('extension',b.competition.extension.answer);x.click('competitionExtensionCheck');
 assert.equal(x.value('saved.competition.extensions.at(-1).firstAttempt'),false);
 const g=x.value('CompetitionIdentity.exposure(saved.competition,taskNow(),"extension")');assert.equal(g.cleanFirst,false);
 x.run('saved.competition.extensions=[];persist()');const r=boot(x.storage);r.click('topicResume');r.click('topicPrevious');assert.equal(r.value('CompetitionIdentity.exposure(saved.competition,taskNow(),"extension").cleanFirst'),false);
 matrix.push({direction:reverse?'new-to-old':'old-to-new',exposure:'variation-first-error',result:'passed'});
}
// Goal/constraint, item domain and numeric changes must not collapse to one key.
const exact=rules.create('packs-exact',{size:4,single:5,pack:15,count:11},'brushes'),enough=rules.create('packs-enough',{size:4,single:5,pack:15,count:11},'brushes');
function taskOf(c){return {competition:{...c,signature:c.family+JSON.stringify(c.math),extension:{...c.extension,signature:JSON.stringify(c.extension.math)}}}}
assert.equal(exact.answer,enough.answer);assert.notEqual(identity.key(taskOf(exact)),identity.key(taskOf(enough)));
const count=rules.create('fraction-reverse',{d1:2,d2:3,left:18},'supplies'),water=rules.create('fraction-reverse',{d1:2,d2:3,left:18},'water');assert.notEqual(identity.key(taskOf(count)),identity.key(taskOf(water)));
assert.notEqual(identity.key(old),identity.key(create({engine:3,familyId:'fractionBackwards',seed:122})));
const pold=create({engine:3,familyId:'packPrice',seed:121}),pnew=rules.create('packs-exact',{size:3,...pold.competition.math},'brushes');assert.equal(identity.key(pold),identity.key(taskOf(pnew)));assert.equal(identity.key(pold,'extension'),identity.key(taskOf(pnew),'extension'));

// Historical duplicate first flags are preserved; only derived statistics change.
const historical=boot();const make=(t,correct,order)=>({taskId:t.id,contentVersion:t.contentVersion,recipe:t.competition.recipe,signature:t.competition.signature,topicIds:t.competition.topicIds,choice:correct?t.answer:(t.answer+1)%5,correct,firstAttempt:true,firstCorrect:correct,hinted:false,priorSolutionViewed:false,at:2000000000000+order,order});
historical.run('saved.competition.attempts='+JSON.stringify([make(old,false,1),make(fresh,true,2)])+';saved.competition=competitionRestoreRecords(saved.competition);persist()');
assert.equal(historical.value('saved.competition.attempts[1].firstCorrect'),true);assert.equal(historical.value('competitionProgressCounts().first'),0);
fs.writeFileSync(evidence+'/rc66-equivalence-regression.json',JSON.stringify({result:'passed',matrix,unknownFirst:'not reconstructed',laterHints:'earlier clean first preserved',negativeControls:['different constraint despite same answer','countable items versus litres','different numbers using the same strategy'],reviewedLegacyMappings:{fractionBackwards:'fraction-reverse and original-whole variation (countable units)',packPrice:'packs-exact and lower-bound variation (countable items/yuan)',squareBorder:'no new-model alias',chartScale:'no new-model alias',missingAverage:'no new-model alias',transferBetweenBoxes:'no new-model alias'},historicalCorrection:{rawDuplicateFirstFlag:true,derivedFirstCount:0,recordsDeleted:false},compatibilityTest:'18,060 frozen RC65 recipe contracts checked separately'},null,2)+'\n');

// The existing topic picker must emit current, versioned recipes in normal rounds.
const rounds=[],decisions=new Set();
function select(x,ids){if(x.value('view')!=='home')x.click('topicExit');x.click('topicClear');for(const code of ids)x.click('topicSelect',{code});x.click('topicStart')}
for(let start=1;start<=721;start+=40){
 const x=boot();x.run('saved.topicPractice.nextSeed='+start);select(x,['R02']);const items=[];
 for(let i=0;i<10;i++){
  const t=x.value('taskNow()'),c=t.competition;assert(c.topicIds.every(id=>id==='R02'));
  assert.equal(c.recipe.generatorRevision,currentRecipe(c.recipe.familyId,c.recipe.seed).generatorRevision);
  if(c.family==='rule-packs-enough'){const p=c.math.params;if(p.count%p.size){const extra=Math.ceil(p.count/p.size)*p.pack,exact=purchase(p,false);decisions.add(extra<exact?'overbuy':extra===exact?'tie':'exact')}}
  items.push({recipe:c.recipe,family:c.family,level:c.level});solve(x,t);x.click('next');
 }assert.equal(x.value('view'),'topicSummary');rounds.push({nextSeed:start,items});
}
assert.equal(decisions.size,3,'all decision cases are reachable through normal topic selection');
fs.writeFileSync(evidence+'/rc66-ui-regression.json',JSON.stringify({result:'passed',environment:'Node VM with actual bundled UI handlers and simulated DOM/speech',newConfigurationPairs:pairs,parsedVisibleEquations:equations,normalR02Rounds:rounds,normalPickerDecisions:[...decisions],browser:'pending',realAudio:'pending',ipad:'pending'},null,2)+'\n');
console.log(`PASS RC66: 10,000 normal generator seeds; ${exhaustive} exhaustive purchases; ${pairs} new-version main/variation pairs; ${equations} independently parsed visible equations; equivalent-history matrix and ${rounds.length} R02 normal rounds.`);
