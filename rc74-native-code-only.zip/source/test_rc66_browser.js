'use strict';
// Run only against a separately started local HTTP server. A launch failure is
// written as pending, never substituted by VM results or fabricated screenshots.
const fs=require('fs'),path=require('path'),assert=require('assert');
const evidence=path.resolve('docs/evidence/2026-10-08-rc66-local'),url=process.env.AMC8_LOCAL_URL||'http://127.0.0.1:8765';
const report={result:'pending',url,story:'choose topics -> local reviewed generator -> answer and help -> persistent facts -> restored UI',viewports:[],screenshots:[],realAudio:'pending; requires listening on a device',ipad:'pending; viewport is not a Safari device',publicDeployment:false};
(async()=>{
 let browser;
 try{browser=await require('playwright').chromium.launch({headless:true})}catch(e){report.launchError=String(e.message);fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(path.join(evidence,'rc66-browser.json'),JSON.stringify(report,null,2)+'\n');console.log('BROWSER PENDING:',String(e.message).split('\n')[0]);process.exitCode=2;return}
 try{
  for(const viewport of [{width:1024,height:768},{width:1180,height:820},{width:375,height:812}]){
   const context=await browser.newContext({viewport}),page=await context.newPage(),errors=[];
   page.on('pageerror',e=>errors.push(String(e)));await page.goto(url);await page.waitForSelector('[data-action="topicSelect"]');
   const click=action=>page.locator('[data-action="'+action+'"]').first().click();
   async function scope(ids){if(await page.locator('[data-action="topicExit"]').count())await click('topicExit');if(await page.locator('[data-action="topicClear"]').count())await click('topicClear');for(const id of ids)await page.locator('[data-action="topicSelect"][data-code="'+id+'"]').click();await click('topicStart')}
   async function solve(correct=true){const answer=await page.evaluate(()=>taskNow().answer);await page.locator('[data-action="competitionPick"][data-index="'+(correct?answer:(answer+1)%5)+'"]').click();await click('check')}
   const scopes=[['A03'],['R02'],['R01','D02'],['R01','G01'],['A02','A03','A05','R01','R02','G01','G02','D01','D02','C01']];
   for(const ids of scopes){
    await scope(ids);await solve(false);await click('competitionHint');await click('competitionHintMore');await click('competitionReadHint');await click('competitionStopSpeech');
    await page.reload();await click('topicResume');assert(await page.locator('.competition-hint').count());await solve();
    const solution=await page.locator('.competition-solutions').textContent();assert(!/÷\s*\d+\/\d+/.test(solution));
    await page.locator('.competition-extension summary').click();const answer=await page.evaluate(()=>taskNow().competition.extension.answer);await page.locator('[data-competition-input="extension"]').fill(String(answer));await click('competitionExtensionCheck');
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1));await click('next');await click('topicPrevious');await click('next');
   }
   const file='rc66-'+viewport.width+'x'+viewport.height+'.png';await page.screenshot({path:path.join(evidence,file),fullPage:true});report.screenshots.push(file);assert.deepEqual(errors,[]);report.viewports.push({...viewport,result:'passed',scopes});await context.close();
  }report.result='browser-automation-passed/audio-and-device-pending';
 }catch(e){report.result='failed';report.error=String(e.stack);process.exitCode=1}finally{await browser.close();fs.writeFileSync(path.join(evidence,'rc66-browser.json'),JSON.stringify(report,null,2)+'\n')}
 console.log(report.result);
})();
