'use strict';
const assert=require('assert'),fs=require('fs'),crypto=require('crypto');
const {competitionCreate:create}=require('./competition_reviewed');
const baseline=JSON.parse(fs.readFileSync('docs/evidence/2026-10-08-rc66-local/rc65-recipe-contracts.json','utf8'));
const contract=t=>({id:t.id,contentVersion:t.contentVersion,options:t.options,answer:t.answer,signature:t.competition.signature,math:t.competition.math,topics:t.competition.topicIds,extension:{signature:t.competition.extension.signature,answer:t.competition.extension.answer,math:t.competition.extension.math||null}});
for(const row of baseline.rows){
 const hash=crypto.createHash('sha256');for(const seed of [...Array.from({length:128},(_,i)=>i+1),2147483647])hash.update(JSON.stringify(contract(create({engine:3,familyId:row.familyId,seed})))+'\n');
 assert.equal(hash.digest('hex'),row.sha256,'RC65 mathematical recipe changed: '+row.familyId);
}
console.log('PASS RC66 compatibility:',baseline.rows.length*129,'RC65 mathematical recipe contracts');
