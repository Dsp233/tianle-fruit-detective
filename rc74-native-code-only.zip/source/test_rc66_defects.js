'use strict';
// These product regressions intentionally fail against the RC65 baseline.
const assert=require('assert'),fs=require('fs');
const {competitionCreate:create}=require('./competition');
const {COMPETITION_REVIEWED:families}=require('./competition_reviewed');
const {boot}=require('./test_support');
function install(app,t,id){
 app.run('saved.topicPractice.session='+JSON.stringify({mode:'competition-v2',id,topicIds:t.competition.topicIds,planSeed:1,total:10,cursor:0,items:[{view:'competition',code:t.id,taskId:t.id,contentVersion:t.contentVersion,recipe:t.competition.recipe,openedAt:2000000000000,passed:false}]})+';topicOpenCurrent()');
}
function solve(app,t,correct=true){app.click('competitionPick',{index:String(correct?t.answer:(t.answer+1)%5)});app.click('check')}
function currentRecipe(familyId,seed){return {engine:3,familyId,seed,generatorRevision:2}}
const checks=[
 ['F1 normal sampler reaches three decisions',()=>{
  const found=new Set();for(let seed=1;seed<=1000;seed++){
   const c=create(currentRecipe('rule-packs-enough',seed)).competition,p=c.math.params;
   if(p.count%p.size===0)continue;
   const extra=Math.ceil(p.count/p.size)*p.pack,exact=Number(c.extension.answer);
   found.add(extra<exact?'overbuy':extra===exact?'tie':'exact');
  }assert.deepEqual([...found].sort(),['exact','overbuy','tie']);
 }],
 ['F2 visible fraction divisor is unambiguous',()=>{
  const t=create({engine:3,familyId:'rule-fraction-reverse',seed:23});
  assert(!/÷\s*\d+\/\d+/.test(t.competition.methods.flatMap(m=>m.steps).join(' ')));
 }],
 ['F3 equivalent old/new problem retains first error',()=>{
  const app=boot(),old=create({engine:3,familyId:'fractionBackwards',seed:121}),fresh=create({engine:3,familyId:'rule-fraction-reverse',seed:23});
  install(app,old,'old');solve(app,old,false);install(app,fresh,'fresh');solve(app,fresh);
  assert.equal(app.value('saved.competition.attempts.at(-1).firstCorrect'),false);
  assert.equal(app.value('competitionProgressCounts().first'),0);
 }],
 ['F4 title and item measures follow context',()=>{
  const t=create({engine:3,familyId:'rule-packs-enough',seed:2});
  assert(t.prompt.includes('树苗'));assert(t.competition.title.includes('树苗'));
  assert(!JSON.stringify([t.competition.diagram,t.competition.methods,t.competition.extension]).includes('单支/棵'));
 }],
 ['F5 adaptation reads reasoning identity',()=>{
  const {competitionAdaptiveProfile:profile}=require('./competition_adaptive');
  const seen=new Set(),records=[];let at=2000000000000;
  for(const [familyId,correct] of [['fractionBackwards',false],['fractionBackwards',false],['fractionBackwards',true],['rule-fraction-reverse',true],['rule-fraction-reverse',true]]){
   let t;for(let seed=1;seed<=1000;seed++){t=create({engine:3,familyId,seed});if(!seen.has(t.competition.signature))break}
   seen.add(t.competition.signature);records.push({recipe:t.competition.recipe,signature:t.competition.signature,choice:correct?t.answer:(t.answer+1)%5,correct,firstAttempt:true,firstCorrect:correct,hinted:false,priorSolutionViewed:false,at:++at});
  }
  assert.equal(profile(records,[],['A03']).topics.A03.band,1,'three successes using the same inverse-fraction strategy do not establish multiple strategies');
 }],
 ['C1 explicit unsupported generator revisions are rejected',()=>{
  assert.throws(()=>create({engine:3,familyId:'rule-packs-enough',seed:1,generatorRevision:999}));
 }]
];
if(require.main===module){
const results=checks.map(([name,fn])=>{try{fn();return {name,result:'passed'}}catch(e){return {name,result:'failed',message:e.message.split('\n')[0]}}});
const report={baseline:'e987c946c017c4ad42a8bc34c09ad4d075bef6a2',stage:process.argv.includes('--baseline')?'before changes':'after changes',results};
if(process.argv.includes('--baseline')){
 fs.mkdirSync('docs/evidence/2026-10-08-rc66-local',{recursive:true});fs.writeFileSync('docs/evidence/2026-10-08-rc66-local/baseline-defects.json',JSON.stringify(report,null,2)+'\n');
}else assert(results.every(r=>r.result==='passed'),JSON.stringify(results,null,2));
console.log(JSON.stringify(report,null,2));
}
module.exports={install,solve,currentRecipe};
