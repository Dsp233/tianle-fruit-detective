'use strict';
const assert=require('assert'),fs=require('fs');
const {boot}=require('./test_support'),{competitionCreate:create,competitionReviewedRecipe:recipe}=require('./competition_reviewed');
const app=boot(),render=d=>app.value('competitionDiagram('+JSON.stringify(d)+')'),root='docs/evidence/2026-10-08-rc67-full';
let peopleChecks=0,packageChecks=0,fractionChecks=0;
for(let seed=1;seed<=128;seed++){
 for(const id of ['natural-weighted','natural-fractionWeighted']){const c=create(recipe(id,seed)).competition;for(const d of [c.diagram,c.extension.diagram]){const html=render(d);assert.equal((html.match(/class="scene-person /g)||[]).length,d.groups.reduce((s,g)=>s+g.count,0));for(const g of d.groups)assert(html.includes('data-count="'+g.count+'"'));assert(html.includes('全体平均：?'));peopleChecks++}}
 for(const id of ['rule-packs-exact','rule-packs-enough']){const c=create(recipe(id,seed)).competition;for(const d of [c.diagram,c.extension.diagram]){const html=render(d),object=d.object.includes('苗')?'seedling':'pencil';assert.equal((html.match(new RegExp('class="scene-object '+object+' ','g'))||[]).length,d.size+Number(d.single!==undefined));assert(html.includes('每包 '+d.pack+' 元'));if(d.single===undefined)assert(!html.includes('class="scene-single"'));packageChecks++}}
 const c=create(recipe('rule-fraction-reverse',seed)).competition,d=c.diagram,v=c.extension.diagram;
 assert(render(d).includes('width:'+100*(d.d1-1)/d.d1+'%'));assert(render(v).includes('width:'+100/v.d1+'%'));assert(render(v).includes('第一次用掉'));fractionChecks++;
}
const css=fs.readFileSync('source/competition.css','utf8');assert(!/url\(\s*['"]?https?:/i.test(css));assert(css.includes('radial-gradient')&&css.includes('scene-head')&&css.includes('box-shadow')&&css.includes('@media(max-width:380px)'));
fs.writeFileSync(root+'/visual-components.json',JSON.stringify({result:'passed',peopleChecks,packageChecks,fractionChecks,assets:'Local SVG/CSS people, coins, balls, pencils, seedlings, packs, strips, joins and spatial blocks',quantities:'Explicit exact counts; compression labelled by a multiplier; partial score coins labelled by their rational value',responsive:'Declared grid, wrap and narrow-screen rules checked in source',limits:['Does not assert real browser measurements, font fit, touch or absence of clipping; those remain browser gate 19']},null,2));
console.log('PASS RC67 components: exact people, package objects, currency/unit labels, and changing-whole scales');
