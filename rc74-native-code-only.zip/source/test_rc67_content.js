'use strict';
const assert=require('assert'),fs=require('fs');
const {COMPETITION_REVIEWED:families,competitionCreate:create,competitionReviewedRecipe:recipe}=require('./competition_reviewed');
const {designOracle}=require('./competition_design_oracles');
const {boot}=require('./test_support');
const numeric=s=>String(s).split('/').map(Number).reduce((a,b)=>a/b);
const near=(a,b,msg)=>assert(Number.isFinite(b)&&Math.abs(numeric(a)-b)<1e-8,msg+': '+a+' vs '+b);
const root='docs/evidence/2026-10-08-rc67-full',app=boot(),rows=[],positions=Array(5).fill(0),kinds=new Set(),failures=[];
let pairs=0,frames=0,materialRenders=0;
function render(d,label){const html=app.value('competitionDiagram('+JSON.stringify(d)+')');assert(html&&/<svg|class="scene-|class="competition-scene|<table/.test(html),label+' blank');assert(!/undefined|NaN|Infinity/.test(html),label+' unbound value');materialRenders++;return html}
function semantics(c,f){
 const m=c.math,d=c.diagram,v=c.extension.diagram;
 assert.deepStrictEqual(c.quality.givens,m);assert.equal(c.reasoningLoad.level,f.level);assert(c.quality.criticalDecision.length>6);assert(c.quality.requiredTopics.every(t=>f.topicIds.includes(t)));
 assert(c.calculationLoad.reason&&c.readingLoad.reason);
 if(['natural-weighted','natural-fractionWeighted'].includes(f.id)){
  assert(m.den===1&&m.red!==m.blue&&m.redScore<m.blueScore);
  for(const x of [m.red,m.blue,m.redScore,m.blueScore])assert(Number.isInteger(x)&&x>0);
  assert.equal(d.groups[0].count,m.red);assert.equal(d.groups[1].count,m.blue);assert.equal(numeric(d.groups[0].score),m.redScore);assert.equal(numeric(d.groups[1].score),m.blueScore);
  assert.equal(v.groups[0].count,m.blue);assert.equal(v.groups[1].count,m.red);assert.equal(d.average,'?');
 }
 if(f.id.startsWith('rule-packs-')){
  const p=m.params;assert(p.pack>0&&p.pack<p.size*p.single&&p.count>p.size);assert.equal(d.size,p.size);assert.equal(d.count,p.count);assert.equal(d.pack,p.pack);
  if(f.id==='rule-packs-enough')assert.equal(v.single,undefined);
  if(m.context==='seedlings')assert(d.object.includes('苗')&&d.object.startsWith('棵'));
 }
 if(f.id.startsWith('rule-fraction-')){
  const p=m.params,start=m.variant==='fraction-original'?p.start:p.left*p.d1*p.d2/((p.d1-1)*(p.d2-1));
  const first=start/p.d1,second=m.variant==='fraction-original'?start/p.d2:(start-first)/p.d2;
  if(m.context==='supplies')for(const x of [start,first,second,start-first-second])assert(Number.isInteger(x)&&x>=0);
  assert.equal(d.d1,p.d1);assert.equal(d.d2,p.d2);
  if(f.id==='rule-fraction-reverse')assert(v.secondOfUsed&&p.d1>2);
 }
 if(f.id==='fixedPerimeter')assert.equal(v.minSide,3);
 if(f.id==='boundaryNotch')assert(v.kind==='scene-holeRectangle'&&v.countInner&&v.a===m.a&&v.b===m.depth);
 if(f.id==='overlapAverages'){assert(d.n===7&&d.k===4&&v.n===9&&v.k===5);assert.equal(new Set(d.means).size,3);assert(new Set(m.values).size>1);}
 if(f.id==='squareBounds')assert(!JSON.stringify(d).includes('"k":'));
 if(f.id==='ageDifference')assert(d.child==='?'&&d.parent==='?');
 if(f.id==='ratioUnion')assert(String(d.a).endsWith('份')&&String(d.b).endsWith('份'));
 if(f.id==='checkerDomino')assert(v.removeTop);
 if(f.id==='hypotenuseMidpoint')assert(v.legMidpoint);
 if(f.id==='openBox')assert(v.cut===1&&v.side===m.side);
 if(f.id==='cubeSteps')assert(v.depth===2&&d.depth===1);
 const visible=[c.prompt,...c.methods.flatMap(m=>m.steps),c.extension.prompt,c.extension.solution].join(' ');
 assert(!/\d+\.\d{10,}|÷\s*[-−]?\d+\/[−-]?\d+/.test(visible),'unformatted arithmetic '+f.id);
}
for(const f of families){
 const row={id:f.id,topicIds:f.topicIds,seeds:0,sameAnswerVariations:0,mainRepresentation:null,variationRepresentation:null,criticalDecision:null};
 for(let seed=1;seed<=128;seed++){
  try{
   const task=create(recipe(f.id,seed)),c=task.competition,expected=designOracle(task,f);
   near(c.answer,expected.answer,f.id+' main '+seed);near(c.extension.answer,expected.extension,f.id+' variation '+seed);
   assert.equal(new Set(task.options.map(numeric)).size,5);assert.equal(task.options.filter(v=>Math.abs(numeric(v)-expected.answer)<1e-8).length,1);assert.equal(task.options[task.answer],c.answer);
   semantics(c,f);render(c.diagram,f.id+' main');render(c.hintDiagram,f.id+' hint');render(c.extension.diagram,f.id+' variation');render(c.extension.solutionFrames[0],f.id+' variation solution');
   for(const m of c.methods){assert.equal(m.frames.length,m.steps.length);for(let i=0;i<m.steps.length;i++){assert.equal(m.frames[i].stage.text,m.steps[i]);render(m.frames[i],f.id+' method frame '+i);frames++}}
   assert(c.extension.signature&&c.extension.key&&c.extension.prompt!==c.prompt);
   kinds.add(c.diagram.kind);positions[task.answer]++;pairs++;row.seeds++;row.sameAnswerVariations+=Number(Math.abs(numeric(c.answer)-numeric(c.extension.answer))<1e-8);
   row.mainRepresentation=c.diagram.kind;row.variationRepresentation=c.extension.diagram.kind;row.criticalDecision=c.quality.criticalDecision;row.variationDecision=c.quality.variationSpec.decision;
  }catch(error){failures.push({familyId:f.id,seed,message:error.message.split('\n')[0]});break}
 }
 rows.push(row);
}
const report={result:failures.length?'failed':'passed',families:families.length,seedsPerFamily:128,mainVariationPairs:pairs,methodFrames:frames,materialRenders,answerPositions:positions,representationKinds:[...kinds].sort(),rows,failures,limits:['Program and simulated DOM verification; no real browser geometry or sound proof','Fixed seeds do not cover an infinite parameter domain','No human review or learning-effect claim']};
fs.writeFileSync(root+'/content-validation.json',JSON.stringify(report,null,2));
assert.equal(failures.length,0,JSON.stringify(failures,null,2));
console.log('PASS RC67 content:',pairs,'independent main/variation pairs;',materialRenders,'actual rendering calls;',frames,'bound method frames');
