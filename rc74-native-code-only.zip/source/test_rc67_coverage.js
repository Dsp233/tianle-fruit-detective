'use strict';
const assert=require('assert'),fs=require('fs');
const {COMPETITION_REVIEWED:families,competitionCreate:create,competitionReviewedRecipe:recipe}=require('./competition_reviewed');
const {COMPETITION_TOPIC_IDS:topics}=require('./competition');
const {designOracle}=require('./competition_design_oracles');
const root='docs/evidence/2026-10-08-rc67-full';
const number=s=>String(s).split('/').map(Number).reduce((a,b)=>a/b);
const near=(a,b,label)=>assert(Math.abs(number(a)-b)<1e-8,label+': '+a+' != '+b);
const save=(name,data)=>fs.writeFileSync(root+'/'+name,JSON.stringify(data,null,2)+'\n');
const baseline=JSON.parse(fs.readFileSync(root+'/baseline/samples.json'));
const contracts=[],variations=[],categories=new Set();
const invariantReasons={
 balanceCancel:'移去右边一个盒子后，缺少的质量等于刚求出的盒子质量；需识别单侧失衡并在同侧补回。',
 'natural-catch':'原差速恰为1，追及时间和停住后间距数值恰同；前者单位是分钟，后者是米，有效运动者和速率已改变。',
 'natural-tiles':'重新选择的最大砖边长和地面长宽一起加倍；地面和每砖面积一起乘4，砖数保持。',
 machineOrder:'共同输入项在两种复合规则之差中抵消；输入变了，但需核查两个加数受到的乘数不同。',
 lShapeArea:'移去同样面积的矩形，不论在角上还是内部，总剩余面积相同；边界变化不能误用于面积。',
 circleRingRatio:'内外半径同乘2，使圆环面积和大圆面积同乘4；分子分母必须同步缩放。',
 coordinateHorizontal:'两端横坐标同加5，坐标差保持；不能把每端位移直接加到长度。',
 medianSort:'只改变最大值，第三个排序位置保持；需区分中位数和会变化的平均数。'
};
for(const f of families){
 const task=create(recipe(f.id,1)),c=task.competition,q=c.quality;
 assert(q.variationSpec.category&&q.variationSpec.decision.length>12);
 assert.equal(q.variationSpec.newStrategyClaim,false);
 assert(c.diagram.kind&&c.hintDiagram.kind&&c.extension.diagram.kind);
 assert(c.methods.every(m=>m.frames.length===m.steps.length));
 assert.deepStrictEqual(q.givens,c.math);
 contracts.push({id:f.id,topicIds:f.topicIds,disposition:'改动并校验',...q});
 let same=0,example=null,changed=null;
 for(let seed=1;seed<=128;seed++){
  const t=create(recipe(f.id,seed)),p=t.competition,e=designOracle(t,f);
  near(p.answer,e.answer,f.id+' main '+seed);near(p.extension.answer,e.extension,f.id+' variation '+seed);
  if(Math.abs(number(p.answer)-number(p.extension.answer))<1e-8){same++;example??={recipe:p.recipe,main:p.prompt,variation:p.extension.prompt,answer:p.answer,why:p.extension.solution};}
  else changed??={recipe:p.recipe,mainAnswer:p.answer,variationAnswer:p.extension.answer};
 }
 if(same===128)assert(invariantReasons[f.id],'Always-same variation requires an explicit relationship proof: '+f.id);
 categories.add(q.variationSpec.category);
 variations.push({familyId:f.id,category:q.variationSpec.category,recheck:q.variationSpec.decision,main:c.prompt,variation:c.extension.prompt,independentPairs:128,sameNumericAnswers:same,sameAnswerExample:example,changedAnswerExample:changed,alwaysSameReason:same===128?invariantReasons[f.id]:null,classification:'condition, goal, dependency, boundary, sampling or invariant check; not a new strategy count'});
}
save('family-contracts.json',{result:'passed',families:contracts.length,rows:contracts,limits:['Contract and program verification; real browser geometry is tracked separately']});
save('variation-review.json',{result:'passed',families:variations.length,independentPairs:families.length*128,categories:[...categories],rows:variations,policy:'A different number alone does not establish transfer. Every family specifies an actual relationship to recheck; equal answers require the recorded condition or invariant explanation.'});

const changes=[
 ['natural-weighted','weights','个人积分改为整数；反向构造整数平均；变式交换人数权重。'],
 ['natural-fractionWeighted','weights','个人积分为整数，合法分数平均保留；以总分和低分补差两条路线解释权重。'],
 ['packPrice','purchase-boundary','不再总取3的倍数；至少条件可出现多买省钱、同价和恰好省钱。'],
 ['mixedPacks','purchase-boundary','4支与6支包装的相对价格可变；独立枚举恰好和至少的合法集合。'],
 ['fixedPerimeter','extremum-domain','旧变式正偶数最大面积改为每边至少3的整数最小面积，必须检查合法端点。'],
 ['overlapAverages','overlap-total','三个平均数反向造为不同整数；前后段由4+4改5+5，重新定位唯一重叠位置。'],
 ['boundaryNotch','counted-boundary','原角缺口变式改为内部洞，并明确内外边界都计入；不再套用只增加两条深度边。'],
 ['rule-packs-enough','feasibility','变式只能买整包且要求恰好，先判定是否存在方案，再比较费用。'],
 ['rule-fraction-reverse','changing-whole','首次分数取1/3或1/4，变式取第一次用量的一部分，避开半数时两个整体相等的退化。'],
 ['quarterTurn','direction','新默认只取奇数个90°，顺逆方向始终需要不同的定位。'],
 ['transformOrder','operation-order','新默认只取90°或270°，避免180°使镜像与旋转恰好可交换。']
];
const priority=changes.map(([id,judgment,description])=>{
 const f=families.find(f=>f.id===id),t=create(recipe(id,1)),c=t.competition;
 const old=Array.isArray(baseline)?baseline.find(x=>x.familyId===id||x.id===id):baseline.rows.find(x=>x.familyId===id||x.id===id);
 assert(old,'missing frozen baseline '+id);
 const legacy=create({engine:3,familyId:id,seed:1}).competition;
 assert(JSON.stringify([legacy.prompt,legacy.math,legacy.extension.prompt])!==JSON.stringify([c.prompt,c.math,c.extension.prompt]));
 const expected=designOracle(t,f);near(c.answer,expected.answer,id);near(c.extension.answer,expected.extension,id+' variation');
 return {familyId:id,judgment,description,baseline:{recipe:legacy.recipe,prompt:legacy.prompt,math:legacy.math,variation:legacy.extension.prompt},current:{recipe:c.recipe,prompt:c.prompt,math:c.math,variation:c.extension.prompt},topics:f.topicIds,proof:'independently solved; normal entry reachability tracked in normal-entry.json',newStrategyClaim:false};
});
assert(priority.length>=6&&new Set(priority.map(p=>p.judgment)).size>=4);
save('priority-configurations.json',{result:'passed',revisedConfigurations:priority.length,judgmentCategories:new Set(priority.map(p=>p.judgment)).size,newStrategiesClaimed:0,rows:priority});

// These are explicitly different mathematical decisions, not names or counts.
const pairs={
 A01:['digitInsert','numberAppend','比较插入位置的高位数字；对比追加一位使整个原数乘10。'],
 A02:['pairedSum','rule-join-open','配成同和的两项；对比连接处造成的重复长度扣除。'],
 A03:['fractionDifferentWholes','fractionBackwards','两个独立整体分别取分数；对比用余量作为第二次整体逆推。'],
 A04:['discountOrder','percentRoundTrip','固定优惠与百分比不可交换；对比同百分比因基准改变而不抵消。'],
 A05:['squareBounds','signedProduct','用相邻平方夹住无理数；对比负乘积的符号组合筛选。'],
 R01:['ratioTotal','transferBetweenBoxes','总份数决定单位量；对比内部转移会使数量差缩小两倍。'],
 R02:['unitConversion','packPrice','统一容量单位再求份数；对比不可拆包装的整数可行范围。'],
 R03:['jointWork','stagedClimb','合作叠加每分钟产量；对比白天到达后最后一次回退不发生。'],
 R04:['mapScale','oppositeScale','同路距离随长度倍率变；对比面积固定要求宽用反向倍率。'],
 L01:['balanceCancel','ageDifference','从平衡两侧消去同一部分；对比跨时间年龄差保持但倍数改变。'],
 L02:['twoCoins','tickets','用1元基准补出2元币数；对比票价差和总人数共同限制成人数。'],
 L03:['recurrenceForward','recurrenceBackwards','从初始项相加推进；对比从相邻末项相减反向恢复。'],
 L04:['linearTable','machineOrder','输入输出差还原变化率；对比复合次序差中共同输入项抵消。'],
 N01:['digitDivisor','divisibleDigits','个位非零的不同除数逐类检查；对比同时满足固定两种整除条件。'],
 N02:['threeDivisors','factorBalance','三个因数强制质数平方；对比给定乘积的全部因数对极值。'],
 N03:['equalBags','bells','最多同规格礼袋用共同整除；对比共同时间周期与端点。'],
 N04:['cyclicPosition','repeatedOnes','余步从实际起点定位；对比追加一位让余数按10r+1更新。'],
 G01:['rectangleDiagonalArea','boundaryNotch','对角线两侧等面积；对比挖凹口时被替换边与新增边抵消。'],
 G02:['angleMarks','outsideAngle','等间隔射线分一整圈；对比等腰底角与相邻外角互补。'],
 G03:['lShapeArea','rectanglePointAreas','大面积减去同一缺口；对比相对三角形共享底高关系。'],
 G04:['circleRoute','semicircleBoundary','在两条補弧比较较短路径；对比半圆周长还含直径。'],
 G05:['shadowSimilarity','similarAreaPerimeter','同时光照的对应长度倍率；对比面积倍率先开平方才用于周长。'],
 G06:['coordinateHorizontal','hypotenuseMidpoint','同水平线距离为坐标差；对比斜边中点到直角顶点等于半斜边。'],
 G07:['cubeSteps','paintedCube','按列高或按层累计；对比按角棱面分类排除角块。'],
 C01:['setOutside','exactlyOneSet','先求至少一组的并集再取整体补集；对比恰好一组需扣交集两次。'],
 C02:['menuBranches','gridDetour','互斥分支先乘后加；对比通过P路径由前后部分配对后排除。'],
 C03:['unorderedPairs','adjacentLine','不分职位消除二人顺序重复；对比相邻双人捆绑再计内部顺序。'],
 C04:['digitComplement','worstCaseColors','至少出现一次可从全部扣补集；对比保证问题先构造库存允许的最大失败量。'],
 D01:['chartScale','truncatedBars','用已知柱确定每格数量；对比非零轴起点不能直接用柱高比。'],
 D02:['medianSort','overlapAverages','排序位置确定中位数；对比先平均乘人数，再用重复计数反求重叠数。'],
 D03:['spinnerLabels','diceSum','等可能扇区中标签重复；对比等可能点数对而非等可能数字和。'],
 S01:['quarterTurn','foldHoles','追踪一次次旋转的位置；对比折痕孔与内部孔有不同镜像复制次数。'],
 S02:['lightSwitchParity','checkerDomino','翻转奇偶决定最终状态；对比黑白数量给铺排上界且需达到上界的构造。']
};
const coverage=topics.map(code=>{
 const pool=families.filter(f=>f.topicIds.length===1&&f.topicIds[0]===code),[a,b,distinction]=pairs[code];
 assert(pool.length>=2&&a!==b&&distinction.length>15);
 const opportunities=[a,b].map(id=>{const f=pool.find(f=>f.id===id);assert(f,code+' is outside single selected topic');const t=create(recipe(id,1)),e=designOracle(t,f),c=t.competition;near(c.answer,e.answer,id);near(c.extension.answer,e.extension,id+' variation');return {familyId:id,level:f.level,decision:f.insight,recipe:c.recipe,prompt:c.prompt,math:c.math,expectedAnswer:e.answer,diagram:c.diagram.kind,variationRecheck:c.quality.variationSpec.decision};});
 assert(opportunities[0].decision!==opportunities[1].decision);
 return {topicId:code,singleTopicFamilies:pool.length,familyIds:pool.map(f=>f.id),distinction,opportunities,selection:'Different judgment opportunities exist in the pool; the picker does not force a low-band learner into the harder member.'};
});
assert.equal(coverage.length,33);
save('topic-strategy-coverage.json',{result:'passed',topics:coverage.length,qualifiedSingleTopicFamilies:families.filter(f=>f.topicIds.length===1).length,explicitOpportunities:coverage.length*2,rows:coverage});

const largeSeeds=[129,1024,65535,2147483646,2147483647];let boundaryCases=0;
for(const f of families)for(const seed of largeSeeds){const t=create(recipe(f.id,seed)),e=designOracle(t,f);near(t.competition.answer,e.answer,f.id+' boundary '+seed);near(t.competition.extension.answer,e.extension,f.id+' variation boundary '+seed);assert(!/NaN|Infinity|undefined/.test(JSON.stringify(t.competition)));boundaryCases++;}
const contexts=[];
for(const id of ['rule-packs-exact','rule-packs-enough','rule-fraction-reverse','rule-fraction-original','rule-join-open','rule-join-closed']){
 const counts={};for(let seed=1;seed<=1024;seed++){const c=create(recipe(id,seed)).competition;counts[c.math.context]=(counts[c.math.context]||0)+1;const f=families.find(f=>f.id===id),e=designOracle({competition:c},f);near(c.answer,e.answer,id+' context');near(c.extension.answer,e.extension,id+' context variation');if(id==='rule-fraction-reverse'){const p=c.math.params,start=p.left*p.d1*p.d2/((p.d1-1)*(p.d2-1));assert(p.d1>2&&start/p.d1!==start-start/p.d1);if(c.math.context==='supplies')assert(Number.isInteger(number(c.answer))&&Number.isInteger(number(c.extension.answer)));}}
 contexts.push({id,contexts:counts});
}
const purchaseCases=[];
for(const id of ['packPrice','mixedPacks','rule-packs-exact','rule-packs-enough']){
 const decisions={};for(let seed=1;seed<=512;seed++){const t=create(recipe(id,seed)),c=t.competition,m=c.math,p=m.params||m;let exact,extra,key;
  if(id==='packPrice'){exact=Math.floor(m.count/3)*m.pack+m.count%3*m.single;extra=Math.ceil(m.count/3)*m.pack;key=m.count%3===0?'divisible':extra<exact?'overbuy':extra===exact?'tie':'exact';}
  else if(id==='mixedPacks'){exact=number(c.answer);extra=Math.ceil(m.count/6)*m.q;key=extra<exact?'overbuy':extra===exact?'tie':'exact';}
  else{exact=Math.floor(p.count/p.size)*p.pack+p.count%p.size*p.single;extra=Math.ceil(p.count/p.size)*p.pack;key=p.count%p.size===0?'divisible':extra<exact?'overbuy':extra===exact?'tie':'exact';}
  decisions[key]=(decisions[key]||0)+1;
 }for(const k of ['overbuy','tie','exact'])assert(decisions[k]>0,id+' lacks decision '+k);purchaseCases.push({familyId:id,decisions});
}
save('parameter-boundaries.json',{result:'passed',largeSeedCases:boundaryCases,declaredGeneratorSeedBoundaries:[1,2147483647],contexts,purchaseCases,ordinaryScores:'integer; distinct weights and scores; rational mean allowed',nonDegenerate:['weighted groups unequal','three overlap averages distinct','fraction first used and remainder unequal','opposite rotations differ','mirror/rotation order differs'],limits:['Declared seed boundaries and context cases; not exhaustive all possible numeric parameter domains']});
console.log('PASS RC67 coverage: 140 explicit variations, 11 revised configurations, 66 different judgment opportunities in 33 themes, 700 boundary seeds');
