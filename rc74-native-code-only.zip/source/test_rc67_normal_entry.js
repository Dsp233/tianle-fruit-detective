'use strict';
const assert=require('assert'),fs=require('fs'),crypto=require('crypto');
const {boot}=require('./test_support'),{scopes,minimal}=require('./rc67_test_scopes');
const {COMPETITION_REVIEWED:families}=require('./competition_reviewed');
const {designOracle}=require('./competition_design_oracles');
const root='docs/evidence/2026-10-08-rc67-full',selectionOnly=process.argv.includes('--selection');
const selected=selectionOnly?scopes.filter(s=>['R02','A02','S01','S02','D02'].includes(s.ids.join(','))||['ten-topics-1','ten-topics-2','all-topics'].includes(s.kind)):scopes;
assert.equal(scopes.length,59);assert.equal(minimal.length,23);
const profiles=['clean-first','wrong-hint-correct','draft-wrong-refresh-variation'];
const number=s=>String(s).split('/').map(Number).reduce((a,b)=>a/b);
const near=(a,b,label)=>assert(Math.abs(number(a)-b)<1e-8,label);
const rows=[],failureRows=[],integrated=new Set(),priorityReach=new Set(),purchaseCases=new Set();let appearances=0,rounds=0,refreshes=0,alternativesChecked=0,streakExceptions=0;
function select(app,ids){app.click('topicClear');for(const code of ids)app.click('topicSelect',{code});app.click('topicStart')}
function submit(app,t,correct){app.click('competitionPick',{index:String(correct?t.answer:(t.answer+1)%5)});app.click('check');assert.equal(app.value('feedback.ok'),correct);}
function availableAlternatives(app,reason){
 return app.value(`(()=>{const s=topicSession(),profile=competitionAdaptiveProfile(saved.competition.attempts,saved.competition.extensions,s.topicIds,saved.competition.extensionViews,saved.competition.views),used=new Set(s.items.map(row=>CompetitionIdentity.key(topicDescriptor(row).task))),seen=new Set([...CompetitionIdentity.index(saved.competition).values()].filter(x=>x.attempted||x.hinted||x.solutionViewed).map(x=>x.key));
 return competitionReviewedEligible(s.topicIds).filter(f=>(f.selectionReasoningKey||f.reasoningKey||f.strategy)!==${JSON.stringify(reason)}&&f.level<=competitionAdaptiveTarget(profile,f).level).filter(f=>{for(let i=0;i<120;i++){const seed=((saved.topicPractice.nextSeed+i-1)%2147483647)+1,t=competitionCreate(competitionReviewedRecipe(f.id,seed)),key=CompetitionIdentity.key(t);if(!used.has(key)&&!seen.has(key))return true}return false}).map(f=>f.id)})()`);
}
try{
 for(let scopeIndex=0;scopeIndex<selected.length;scopeIndex++){
  const scope=selected[scopeIndex];
  for(let profileIndex=0;profileIndex<profiles.length;profileIndex++){
   const profile=profiles[profileIndex],clock={now:2000000000000+scopeIndex*10000000+profileIndex*1000000};let app=boot({},clock);
   app.run('saved.topicPractice.nextSeed='+(1+scopeIndex*113+profileIndex*17));select(app,scope.ids);const trace=[],usedKeys=new Set();
   for(let round=0;round<2;round++){
    if(round){assert.equal(app.value('view'),'topicSummary');clock.now+=1000;app.click('topicStart');}
    for(let i=0;i<10;i++){
     clock.now+=1000;assert.equal(app.value('view'),'competition',scope.ids+' premature exhaustion');assert.equal(app.value('topicSession().cursor'),i);
     const t=app.value('taskNow()'),c=t.competition,f=families.find(f=>f.id===c.recipe.familyId),expected=designOracle(t,f),key=app.value('CompetitionIdentity.key(taskNow())');
     assert.equal(c.recipe.generatorRevision,3);assert(c.topicIds.every(id=>scope.ids.includes(id)));assert(!c.clues&&!c.verification);
     assert(!usedKeys.has(key),'same mathematical instance appeared twice across the isolated two rounds: '+f.id);usedKeys.add(key);
     near(c.answer,expected.answer,f.id+' main');near(c.extension.answer,expected.extension,f.id+' variation');
     assert(c.diagram&&c.extension.diagram&&c.methods.every(m=>m.frames.length===m.steps.length));assert(/<svg|competition-scene|<table/.test(app.root.innerHTML));
     assert(!app.root.innerHTML.includes('class="competition-solutions"'));
     const reason=f.selectionReasoningKey||f.reasoningKey||f.strategy,previous=trace.slice(-2),priorExposure=app.value('CompetitionIdentity.exposure(saved.competition,taskNow())');
     const entry={scope:scope.ids,profile,round:round+1,position:i+1,recipe:c.recipe,familyId:f.id,mathematicalKey:key,topics:c.topicIds,reasoningKey:reason,reasoning:c.reasoningLoad,calculation:c.calculationLoad,reading:c.readingLoad,initialDiagram:c.diagram.kind,variationDiagram:c.extension.diagram.kind,firstExposure:priorExposure.attempted||priorExposure.hinted||priorExposure.solutionViewed,events:[]};
     app.inputCompetition('notes','第'+(round+1)+'轮第'+(i+1)+'题：'+profile);
     if(profile!=='clean-first'){
      app.click('competitionEliminate',{index:String((t.answer+2)%5)});submit(app,t,false);entry.events.push('first wrong');app.click('competitionHint');entry.events.push('hint');
      if(profile==='wrong-hint-correct'){app.click('competitionHintMore');app.click('competitionReadHint');assert.equal(app.spoken.at(-1),app.value('competitionSpeechText('+JSON.stringify(c.hints[1])+')'));app.click('competitionStopSpeech');}
      if(profile==='draft-wrong-refresh-variation'&&(i===1||i===6)){
       const savedNotes=app.value('draft.work.notes'),savedExcluded=app.value('draft.work.eliminated');app.run('persist()');app=boot(app.storage,clock);app.click('topicResume');
       assert.equal(app.value('taskNow().id'),t.id);assert.equal(app.value('draft.work.notes'),savedNotes);assert.deepStrictEqual(app.value('draft.work.eliminated'),savedExcluded);assert.equal(app.value('feedback.ok'),false);assert(app.value('competitionHistory(taskNow()).hinted'));entry.events.push('refresh restored same task, draft, exclusions, wrong feedback and help');refreshes++;
      }
     }
     submit(app,t,true);const record=app.value('saved.competition.attempts.at(-1)');
     assert.equal(record.firstCorrect,profile==='clean-first'&&!entry.firstExposure);entry.events.push('correct');
     assert(app.root.innerHTML.includes('class="competition-solutions"'));const before=app.value('saved.competition.attempts.length');app.click('check');assert.equal(app.value('saved.competition.attempts.length'),before);
     if(i===2||i===7){
      app.click('competitionMethod',{index:String(c.methods.length-1)});app.click('competitionStep',{index:String(c.methods.at(-1).steps.length-1)});
      if(profile!=='clean-first'){app.inputCompetition('extension','999999999');app.click('competitionExtensionCheck');assert.equal(app.value('draft.work.extensionResult.ok'),false);}
      app.inputCompetition('extension',c.extension.answer);app.click('competitionExtensionCheck');assert.equal(app.value('draft.work.extensionResult.ok'),true);
      if(profile!=='clean-first')assert.equal(app.value('saved.competition.extensions.at(-1).firstAttempt'),false);
      const beforeVariation=app.value('saved.competition.extensions.length');app.click('competitionExtensionCheck');assert.equal(app.value('saved.competition.extensions.length'),beforeVariation);entry.events.push('optional method, step and graded variation');
     }
     if(c.topicIds.length>1)integrated.add(f.id);priorityReach.add(f.id);
     if(f.id==='rule-packs-enough'||f.id==='packPrice'){
      const p=c.math.params||c.math,size=p.size||3,exact=Math.floor(p.count/size)*p.pack+p.count%size*p.single,extra=Math.ceil(p.count/size)*p.pack;
      purchaseCases.add(p.count%size===0?'divisible':extra<exact?'overbuy':extra===exact?'tie':'exact');
     }
     entry.firstCorrect=record.firstCorrect;entry.feedback=app.value('feedback.text');trace.push(entry);appearances++;
     // Check the next selection against the actual current profile, after feedback.
     let alternatives=[];const lastTwo=trace.slice(-2);
     if(lastTwo.length===2&&lastTwo.every(x=>x.reasoningKey===reason)){alternatives=availableAlternatives(app,reason);alternativesChecked++;}
     if(i===3)app.click('competitionRead');const oldVoice=i===3?app.utterances.at(-1):null;app.click('next');
     if(oldVoice){oldVoice.onerror();assert.equal(app.value('speechMessage'),'');}
     if(app.value('view')==='competition'&&lastTwo.length===2&&lastTwo.every(x=>x.reasoningKey===reason)){
      const nextFamily=families.find(f=>f.id===app.value('taskNow().competition.recipe.familyId')),nextReason=nextFamily.selectionReasoningKey||nextFamily.reasoningKey||nextFamily.strategy;
      if(alternatives.length)assert.notEqual(nextReason,reason,'third repeated reasoning while fresh in-band alternatives exist: '+scope.ids+' '+reason+' choices '+alternatives.join(','));
      else{streakExceptions++;entry.repeatException='No fresh different reasoning available within current adaptive level; no forced harder question.';}
     }
     if(i===4){const future=app.value('taskNow().id');app.click('topicPrevious');assert.equal(app.value('taskNow().id'),t.id);assert(app.value('topicCurrent().passed'));assert.equal(app.value('draft.work.notes'),'第'+(round+1)+'轮第'+(i+1)+'题：'+profile);app.click('check');assert.equal(app.value('saved.competition.attempts.length'),before);app.click('next');assert.equal(app.value('taskNow().id'),future);entry.events.push('previous/next preserves drafts and adds no attempts');}
    }
    assert.equal(app.value('view'),'topicSummary');assert.equal(app.value('topicSession().items.length'),10);assert(app.value('topicSession().items.every(x=>x.passed)'));assert.equal(app.value('saved.attempts.length'),0);assert.deepStrictEqual(app.value('saved.skillStage'),{});rounds++;
   }
   rows.push({kind:scope.kind,scope:scope.ids,profile,rounds:2,appearances:trace.length,trace});
  }
  if((scopeIndex+1)%5===0||scopeIndex===selected.length-1)console.log('Validated scopes '+(scopeIndex+1)+'/'+selected.length+'; '+rounds+' rounds; '+appearances+' appearances');
 }
 if(!selectionOnly){assert.equal(rounds,354);assert.equal(appearances,3540);assert.equal(refreshes,236);assert(integrated.size>=20,'natural integrated family reachability');for(const k of ['overbuy','tie','exact'])assert(purchaseCases.has(k),'normal picker purchase case unreachable '+k);}
}catch(error){failureRows.push({message:error.message,stack:error.stack,completedRounds:rounds,completedAppearances:appearances});process.exitCode=1;}
const report={result:failureRows.length?'failed':'passed',mode:selectionOnly?'selection-policy sample':'fixed full normal-entry plan',scopes:selected.length,plannedScopes:59,minimalIntegratedScopes:minimal.length,profiles,rounds,appearances,refreshes,alternativeChecks:alternativesChecked,narrowPoolExceptions:streakExceptions,integratedFamiliesReached:[...integrated].sort(),allFamiliesReached:[...priorityReach].sort(),purchaseCases:[...purchaseCases].sort(),rows,failures:failureRows,testedBuildSha256:crypto.createHash('sha256').update(fs.readFileSync('source/index.html')).digest('hex'),limits:['Actual bundled handlers in Node VM with simulated DOM and speech; not real browser screenshots or audio','Appearances are not a count of independent new tasks, new strategies or real child performance','No human review and no public deployment']};
fs.writeFileSync(root+'/'+(selectionOnly?'picker-policy.json':'normal-entry.json'),JSON.stringify(report,null,2)+'\n');
assert.equal(failureRows.length,0,JSON.stringify(failureRows,null,2));console.log('PASS RC67 '+report.mode+': '+rounds+' rounds, '+appearances+' appearances');
