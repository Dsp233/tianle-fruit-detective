'use strict';
const assert=require('assert'),fs=require('fs');
const {boot}=require('./test_support'),rel=require('./competition_relations'),design=require('./competition_design');
const {competitionCreate:create,competitionReviewedRecipe:recipe,COMPETITION_REVIEWED:families}=require('./competition_reviewed');
const root='docs/evidence/2026-10-08-rc67-full',app=boot();
function arithmetic(source){
 const s=source.replace(/(\d+(?:\.\d+)?)%/g,(_,x)=>'('+Number(x)/100+')').replace(/−/g,'-').replace(/×/g,'*').replace(/÷/g,'/').replace(/²/g,'^2').replace(/³/g,'^3');
 assert(/^[\d\s.()+\-*/^]+$/.test(s),s);const t=s.match(/\d+(?:\.\d+)?|[()+\-*/^]/g)||[];let i=0;
 function atom(){if(t[i]==='('){i++;const v=sum();assert.equal(t[i++],')');return v}if(t[i]==='-'){i++;return -atom()}if(t[i]==='+'){i++;return atom()}const v=Number(t[i++]);assert(Number.isFinite(v));return v}
 function pow(){const a=atom();if(t[i]==='^'){i++;return a**pow()}return a}
 function mul(){let a=pow();while(['*','/'].includes(t[i])){const o=t[i++],b=pow();a=o==='*'?a*b:a/b}return a}
 function sum(){let a=mul();while(['+','-'].includes(t[i])){const o=t[i++],b=mul();a=o==='+'?a+b:a-b}return a}
 const v=sum();assert.equal(i,t.length,source);return v;
}
const expressions=[[['div',16,'2/3'],24],[['sub',3,['sub',0,2]],5],[['mul','1/2',['add',3,5]],4],[['pow',['pow',2,3],2],64],[['div',-12,['sub',4,1]],-4]];
for(const [expression,want]of expressions)assert(Math.abs(arithmetic(rel.expression(expression,{}))-want)<1e-10);
let equations=0;const failed=[];
for(const f of families)for(let seed=1;seed<=128;seed++){
 const c=create(recipe(f.id,seed)).competition;
 for(const text of [...c.methods.flatMap(m=>m.steps),c.extension.solution])for(const match of text.matchAll(/[\d\s.+\-−×÷/^()²³%]+(?:[=＝][\d\s.+\-−×÷/^()²³%]+)+/g)){
  let parts=match[0].split(/[=＝]/).map(x=>x.trim());
  // Do not interpret the numeric suffix of 3t+4=... as a complete equation.
  if(/[A-Za-z]/.test(text[match.index-1]||''))parts.shift();
  if(/[A-Za-z]/.test(text[match.index+match[0].length]||''))parts.pop();
  parts=parts.filter(x=>x&&/[\d]/.test(x)&&!/^([+×÷/^²³%])/.test(x));if(parts.length<2)continue;
  if(parts.some(x=>[...x].filter(c=>c==='(').length!==[...x].filter(c=>c===')').length))continue;
  try{const values=parts.map(arithmetic);assert(values.every(x=>Math.abs(x-values[0])<1e-7),match[0]);equations+=values.length-1}catch(e){failed.push({familyId:f.id,seed,equation:match[0],error:e.message.split('\n')[0]})}
 }
}
const speechCases=[['1/4','4分之1'],['−3/4','4分之负3'],['10−3','10减3'],['3-(-2)','3减左括号负2右括号'],['1:2:3','1比2比3'],['20%','百分之20'],['4²','4的平方'],['厘米²','平方厘米'],['米³','立方米'],['16÷(2/3)','16除以3分之2'],['12÷(4−1)','12除以左括号4减1右括号']];
for(const [source,want]of speechCases)assert.equal(app.value('competitionSpeechText('+JSON.stringify(source)+')').replace(/\s/g,''),want);
fs.writeFileSync(root+'/mathematical-display.json',JSON.stringify({result:failed.length?'failed':'passed',parsedEquations:equations,expressionCases:expressions.length,speechCases,failures:failed,limits:['Numeric equations parsed; verbal proofs and variable identities checked separately by content oracles','Speech scripts and callbacks only; no real voice synthesis claimed']},null,2));
assert.equal(failed.length,0,JSON.stringify(failed.slice(0,12),null,2));

const variants=[];for(let seed=1;seed<=128;seed++){const c=create(recipe('signedProduct',seed)).competition;variants.push({seed,k:c.math.k,reasoning:c.reasoningLoad.level,calculation:c.calculationLoad.level})}
assert(new Set(variants.map(x=>x.calculation)).size>=2);assert.equal(new Set(variants.map(x=>x.reasoning)).size,1);
const shortcuts=[1,64,128].map(seed=>create(recipe('neighborProducts',seed)).competition);assert(shortcuts.every(c=>c.calculationLoad.level===1&&c.reasoningLoad.level===3));
const picker=boot();picker.click('topicSelect',{code:'R01'});picker.click('topicStart');const first=picker.value('taskNow()'),nextSeed=picker.value('saved.topicPractice.nextSeed');
const candidateScores=Array.from({length:Math.min(12,nextSeed-1)},(_,i)=>design.comfort(create(recipe(first.competition.recipe.familyId,i+1)).competition));
assert.equal(design.comfort(first.competition),Math.min(...candidateScores));
const chosen=[];for(let i=0;i<20;i++){if(picker.value('view')==='topicSummary')picker.click('topicStart');const t=picker.value('taskNow()');chosen.push({recipe:t.competition.recipe,reasoning:t.competition.level,calculation:t.competition.calculationLoad.level,reading:t.competition.readingLoad.level});picker.click('competitionPick',{index:String(t.answer)});picker.click('check');picker.click('next')}
assert(chosen.every(c=>c.calculation<=2));
fs.writeFileSync(root+'/load-policy.json',JSON.stringify({result:'passed',sameStructureDifferentCalculation:variants,shortcutProof:shortcuts.map(c=>({math:c.math,reasoning:c.reasoningLoad,calculation:c.calculationLoad})),boundedCandidates:12,firstSelectedMinimum:true,cleanAdultTrace:chosen,limits:['Model-based workload estimates; not a measurement of child effort','Adaptive reasoning rules retain existing semantics']},null,2));
console.log('PASS RC67 policies:',equations,'parsed equations; semantic speech; independent reasoning and calculation loads; bounded easy-parameter selection');
