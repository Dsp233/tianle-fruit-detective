'use strict';
// Supplemental default-start trace; does not replace the registered 354 rounds.
const assert=require('assert'),fs=require('fs'),crypto=require('crypto');
const {boot}=require('./test_support');
const app=boot(),trace=[];
for(const code of ['A03','R01','D02'])app.click('topicSelect',{code});app.click('topicStart');
for(let i=0;i<20;i++){
 if(app.value('view')==='topicSummary')app.click('topicStart');
 const t=app.value('taskNow()'),c=t.competition;
 assert(c.topicIds.every(x=>['A03','R01','D02'].includes(x)));assert.equal(c.recipe.generatorRevision,3);
 trace.push({position:i+1,recipe:c.recipe,prompt:c.prompt,math:c.math,diagram:c.diagram.kind,level:c.level,calculation:c.calculationLoad});
 app.click('competitionPick',{index:String(t.answer)});app.click('check');assert.equal(app.value('feedback.ok'),true);app.click('next');
}
assert.equal(app.value('view'),'topicSummary');assert(trace.some(x=>x.recipe.familyId==='natural-fractionWeighted'));
const result={result:'passed',scope:['A03','R01','D02'],startSeed:1,normalAppearances:20,rounds:2,reachedFractionalWeighted:trace.find(x=>x.recipe.familyId==='natural-fractionWeighted'),trace,testedBuildSha256:crypto.createHash('sha256').update(fs.readFileSync('source/index.html')).digest('hex'),limits:['Additional default-start actual handler trace, separately counted from the fixed 354-round plan','No forced question, ability band, pool or history injection; Node VM DOM']};
fs.writeFileSync('docs/evidence/2026-10-08-rc67-full/default-start-reachability.json',JSON.stringify(result,null,2)+'\n');
console.log('PASS default-start natural fractional weighted reachability in two normal rounds');
