'use strict';
const assert=require('assert'),fs=require('fs');
const {boot}=require('./test_support'),{install,solve}=require('./test_rc66_defects');
const {COMPETITION_REVIEWED:families,competitionCreate:create,competitionReviewedRecipe:recipe}=require('./competition_reviewed');
const root='docs/evidence/2026-10-08-rc67-full',app=boot(),rows=[];
for(const f of families){
 const t=create(recipe(f.id,1)),c=t.competition;install(app,t,'rc67-flow-'+f.id);
 assert(app.root.innerHTML.includes('<svg')||app.root.innerHTML.includes('competition-scene')||app.root.innerHTML.includes('<table'));
 assert(!app.root.innerHTML.includes('class="competition-solutions"'));
 const voiceBefore=app.spoken.length;app.click('competitionReadStep',{index:'0'});assert.equal(app.spoken.length,voiceBefore,'solution speech guarded before answer');
 app.click('check');assert.equal(app.value('feedback.ok'),false);assert(app.value('feedback.text').includes('先选'));
 app.click('competitionHint');app.click('competitionHintMore');assert.equal(app.value('draft.work.hintLevel'),2);
 app.click('competitionReadHint');const hintText=app.value('competitionSpeechText('+JSON.stringify(c.hints[1])+')');assert.equal(app.spoken.at(-1),hintText);
 app.utterances.at(-1).onend();app.click('competitionStopSpeech');assert.equal(app.value('speechMessage'),'朗读已停止。');
 app.inputCompetition('notes','检查 '+f.id);app.click('competitionEliminate',{index:String((t.answer+2)%5)});
 const before=app.value('saved.competition.attempts.length');solve(app,t,false);assert.equal(app.value('feedback.ok'),false);solve(app,t);assert.equal(app.value('feedback.ok'),true);
 assert.equal(app.value('saved.competition.attempts.at(-1).firstCorrect'),false);
 app.click('check');assert.equal(app.value('saved.competition.attempts.length'),Math.min(500,before+2));
 const seenFrames=[];
 for(let route=0;route<c.methods.length;route++){
  app.click('competitionMethod',{index:String(route)});
  for(let step=0;step<c.methods[route].steps.length;step++){
   app.click('competitionStep',{index:String(step)});assert.equal(app.value('draft.work.step'),step);assert.equal(app.value('draft.work.method'),route);
   assert(app.root.innerHTML.includes('data-step="'+step+'"'));
   app.click('competitionReadStep',{index:String(step)});assert.equal(app.spoken.at(-1),app.value('competitionSpeechText('+JSON.stringify(c.methods[route].steps[step])+')'));seenFrames.push({route,step});
  }
 }
 app.inputCompetition('extension','999999999');app.click('competitionExtensionCheck');assert.equal(app.value('draft.work.extensionResult.ok'),false);
 app.inputCompetition('extension',c.extension.answer);app.click('competitionExtensionCheck');assert.equal(app.value('draft.work.extensionResult.ok'),true);
 assert.equal(app.value('saved.competition.extensions.at(-1).firstAttempt'),false);
 app.click('competitionRead');const oldVoice=app.utterances.at(-1);app.click('next');assert.equal(app.value('speechMessage'),'');oldVoice.onerror();assert.equal(app.value('speechMessage'),'','old voice callback cannot affect next question');
 app.click('topicPrevious');assert.equal(app.value('taskNow().id'),t.id);assert.equal(app.value('draft.work.notes'),'检查 '+f.id);assert(app.value('topicCurrent().passed'));app.click('next');
 rows.push({familyId:f.id,recipe:c.recipe,result:'passed',hintStages:2,seenFrames,variationFirstWrong:true,optionalDoesNotBlockNext:true});
}

const restart=boot();restart.click('topicSelect',{code:'A03'});restart.click('topicSelect',{code:'R01'});restart.click('topicStart');const first=restart.value('taskNow()');
restart.inputCompetition('notes','刷新后保留');restart.click('competitionEliminate',{index:String((first.answer+2)%5)});restart.click('competitionHint');solve(restart,first,false);restart.run('persist()');
const resumed=boot(restart.storage);resumed.click('topicResume');assert.equal(resumed.value('taskNow().id'),first.id);assert.equal(resumed.value('draft.work.notes'),'刷新后保留');assert(resumed.value('draft.work.eliminated.length')===1);assert.equal(resumed.value('feedback.ok'),false);assert(resumed.value('competitionHistory(taskNow()).hinted'));
solve(resumed,first);assert.equal(resumed.value('saved.competition.attempts.at(-1).firstCorrect'),false);resumed.click('next');resumed.click('topicExit');
resumed.click('topicClear');resumed.click('topicSelect',{code:'G01'});resumed.click('topicStart');assert.deepStrictEqual(resumed.value('taskNow().competition.topicIds'),['G01']);
resumed.run('delete window.speechSynthesis');resumed.click('competitionRead');assert(resumed.value('speechMessage').includes('暂不支持'));
const noExtension=boot();noExtension.click('topicSelect',{code:'D02'});noExtension.click('topicStart');const unassisted=noExtension.value('taskNow()');solve(noExtension,unassisted);noExtension.click('next');assert.notEqual(noExtension.value('taskNow().id'),unassisted.id);
const report={result:'passed',familyFlows:rows.length,rows,refresh:'draft, wrong feedback, exclusions, prior hints and original task survive',switchTopics:'new round limited to newly selected G01',voice:'current scripts, stop, guarded before answer, unsupported engine, stale callbacks',next:'works without opening hint, method or variation',limits:['Actual bundled handlers in Node VM with simulated DOM/voice; no real browser or audio assertion']};
fs.writeFileSync(root+'/workflow-validation.json',JSON.stringify(report,null,2));
console.log('PASS RC67 workflow: 140 family flows, optional hints/steps/voice/variations, permanent first facts, resume and topic switching');
