'use strict';
const assert=require('assert'),A=require('./rc69_acceptance'),{save}=require('./rc69_evidence');
const identity={sourceCommit:'a'.repeat(40),buildSha256:'b'.repeat(64)},row={...identity,caseId:'A',familyId:'bells',configurationId:'bells',seed:1,steps:['actual operation'],expected:{response:true},actual:{response:true},status:'PASS',evidencePaths:['raw/A.json'],observedAt:new Date().toISOString(),runner:'schema-fixture',mandatory:true};
let cases=0;const check=(expected,rows,ids=['A'])=>{assert.equal(A.aggregate(ids,rows,identity).status,expected);cases++};
check('PASS',[row]);check('FAIL',[{...row,status:'FAIL'}]);check('BLOCKED',[{...row,status:'BLOCKED'}]);check('NOT_RUN',[{...row,status:'NOT_RUN'}]);check('NOT_RUN',[]);check('BLOCKED',[{...row,evidencePaths:[]}]);check('BLOCKED',[{...row,sourceCommit:'c'.repeat(40)}]);check('BLOCKED',[row,row]);check('BLOCKED',[{...row,status:'NOT_APPLICABLE',reason:'attempted waiver'}]);check('NOT_RUN',[row],['A','B']);
save('contracts/evidence-aggregation',{result:'passed',cases,limits:['Validation fixtures test summary rules; they are not product/browser PASS records']});
