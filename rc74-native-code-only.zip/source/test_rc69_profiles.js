'use strict';
const assert=require('assert'),fs=require('fs'),M=require('./competition_reviewed'),Sources=require('./source_catalog'),Skills=require('./skills.json'),{boot}=require('./test_support'),{save}=require('./rc69_evidence');
const html=fs.readFileSync('qa/index.html','utf8'),manifest=require('../docs/rc69-execution-manifest.json'),all=Skills.units.map(u=>u.id),rows=[],failures=[];
function check(id,fn){try{rows.push({caseId:id,status:'PASS',actual:fn()})}catch(e){rows.push({caseId:id,status:'FAIL',error:e.message});failures.push({caseId:id,error:e.message})}}
for(const skill of Skills.skills)check('declaration/'+skill.id,()=>{
 const p=Sources.profile({topicIds:[skill.unitId],sourceIds:['original']});assert.equal(p.knowledgeStatus,'user-declared');assert(p.declaredSkillIds.includes(skill.id));
 const excluded=Sources.profile({...p,excludedSkillIds:[skill.id]});assert(!excluded.declaredSkillIds.includes(skill.id));assert.deepStrictEqual(excluded.topicIds,[skill.unitId]);
 const outside=Sources.profile({topicIds:[],declaredSkillIds:[skill.id]});assert(!outside.declaredSkillIds.length,'No automatic prerequisite or mastery selection');
 return {skillId:skill.id,declarationStatus:p.knowledgeStatus,exclusionWorks:true,actualUseCertification:'NOT_ESTABLISHED_BY_THIS_TEST'};
});
check('invalid-and-empty-profile',()=>{const p=Sources.profile({topicIds:['bad','A02','A02'],excludedSkillIds:['bad','A02.04','A02.04'],sourceIds:[],examIds:['bad'],maxReadingLoad:9});assert.deepStrictEqual(p.topicIds,['A02']);assert.deepStrictEqual(p.excludedSkillIds,['A02.04']);assert.deepStrictEqual(p.sourceIds,[]);assert.equal(p.maxReadingLoad,null);assert.equal(Sources.profile(null).declaredSkillIds.length,0);assert(!Sources.eligible(M.COMPETITION_REVIEWED,p).length);return p});
for(const config of manifest.configurations)for(const seed of [1,2,129,2147483646,2147483647])check('instance-boundary/'+config.familyId+'/'+config.configurationId+'/'+seed,()=>{
 const t=M.competitionCreate({...config.rc68Recipe,seed}),p=Sources.profile({topicIds:all,sourceIds:['original','AMC8']}),routes=Sources.taskRoutes(t),full=Sources.taskAllowed(t,p);assert.equal(full.length,routes.filter(r=>!r.unverifiedKnowledge?.length).length);
 let exclusions=0;for(const route of routes)for(const skill of route.requiredSkills){assert(!Sources.taskAllowed(t,{...p,excludedSkillIds:[skill]}).some(r=>r.id===route.id));exclusions++;}
 return {familyId:config.familyId,configurationId:config.configurationId,seed,routeCount:routes.length,exclusionChecks:exclusions,limits:'Required-skill policy check; no claim of semantic usage for conservative route maps'};
});
function load(seed=1,excluded=[]){const a=boot({},2000000000000,html);a.run('window.AMC8_QA.loadCase('+JSON.stringify({familyId:'lShapeArea',configuration:'amc2000-06-full',seed,generatorRevision:4,excludedSkillIds:excluded})+',true)');return a}
check('old-session-snapshot-survives-home-edit-and-reload',()=>{
 let a=load();const signature=a.value('taskNow().competition.signature'),profile=a.value('topicSessionSettings()');a.click('reasoningOpen');a.click('reasoningRoute',{code:'complete-remove'});a.inputCompetition('reasoning','scratch expression');
 a.click('topicExit');a.click('sourceSkillToggle',{code:'G03.02'});assert(a.value('saved.topicPractice.excludedSkillIds.includes("G03.02")'));a.click('topicResume');assert.deepStrictEqual(a.value('topicSessionSettings()'),profile);assert.equal(a.value('reasoningState().state.routeId'),'complete-remove');assert(a.value('competitionScopedContent(taskNow()).methods.some(m=>m.routeId==="complete-remove")'));assert.equal(a.value('reasoningState().state.input'),'scratch expression');
 a=boot(a.storage,2000000000001,html);a.click('topicResume');assert.deepStrictEqual(a.value('topicSessionSettings()'),profile);assert.equal(a.value('taskNow().competition.signature'),signature);assert.equal(a.value('reasoningState().state.input'),'scratch expression');assert(a.value('canPersist'));return {signature,excludedForNextGroup:['G03.02'],excludedInSavedGroup:profile.excludedSkillIds};
});
check('expanded-home-preferences-do-not-open-old-restricted-route',()=>{
 let a=load(1,['G03.02']);a.click('topicExit');a.click('sourceSkillToggle',{code:'G03.02'});assert(!a.value('saved.topicPractice.excludedSkillIds.includes("G03.02")'));a.click('topicResume');a.click('reasoningOpen');assert(!a.root.innerHTML.includes('data-code="complete-remove"'));a.click('reasoningRoute',{code:'complete-remove'});assert.equal(a.value('reasoningState().state.routeId'),null);
 assert.deepStrictEqual(a.value('competitionScopedContent(taskNow()).methods.map(m=>m.routeId)'),['disjoint-strips']);a=boot(a.storage,2000000000001,html);a.click('topicResume');assert(a.value('topicSessionSettings().excludedSkillIds.includes("G03.02")'));return {savedScopeRetained:true};
});
check('direct-hint-example-read-and-submit-cannot-bypass-restricted-route',()=>{
 const a=load();a.click('reasoningOpen');a.click('reasoningRoute',{code:'complete-remove'});a.inputCompetition('reasoning','kept draft');a.run('saved.topicPractice.session.excludedSkillIds=["G03.02"]');
 for(const action of ['reasoningHint','reasoningExample','reasoningRead','reasoningCheck','reasoningFocus']){const spoken=a.spoken.length;a.click(action,{code:'target'});assert.equal(a.spoken.length,spoken);assert(!a.value('reasoningState().state.completed.target'));assert.equal(a.value('reasoningState().state.input'),'kept draft');}
 assert(!a.root.innerHTML.includes('data-action="reasoningExample"'));a.click('reasoningRoute',{code:'disjoint-strips'});assert.equal(a.value('reasoningState().state.routeId'),'disjoint-strips');assert.equal(a.value('reasoningState().state.archivedGraphs.at(-1).input'),'kept draft');return {draftArchived:true,actionsBlocked:5};
});
check('new-home-group-uses-new-scope-while-repeat-group-uses-saved-scope',()=>{
 const a=load(1,['G03.02']);const old=a.value('topicSessionSettings()');a.click('topicExit');a.run('saved.topicPractice.selectedTopicIds='+JSON.stringify(all));a.click('sourceSkillToggle',{code:'G03.02'});a.run('saved.topicPractice.sourceIds=["original"]');const preferences=a.value('({...saved.topicPractice,session:null})');
 a.run('view="topicSummary"; topicStart()');assert.deepStrictEqual(a.value('topicSessionSettings()'),old);assert.deepStrictEqual(a.value('({...saved.topicPractice,session:null,nextSeed:0})'),{...preferences,nextSeed:0});
 a.click('topicExit');a.click('topicStart');assert.deepStrictEqual(a.value('topicSession().sourceIds'),['original']);assert(!a.value('topicSession().excludedSkillIds.includes("G03.02")'));assert.equal(a.value('topicSession().knowledgeStatus'),'user-declared');return {newGroupUsesPreferences:true,repeatKeepsSavedScope:true};
});
check('legacy-missing-exclusion-snapshot-does-not-inherit-later-home-edits',()=>{
 let a=load();a.run('delete saved.topicPractice.session.excludedSkillIds;delete saved.topicPractice.session.profileVersion');a.click('topicExit');a.click('sourceSkillToggle',{code:'G03.02'});a=boot(a.storage,2000000000001,html);a.click('topicResume');assert.deepStrictEqual(a.value('topicSessionSettings().excludedSkillIds'),[]);assert.equal(a.value('topicSession().profileOrigin'),'legacy-topic-declaration');assert(a.value('saved.topicPractice.excludedSkillIds.includes("G03.02")'));assert(a.value('canPersist'));return {legacyDefaultsPreserved:true};
});
check('no-allowed-route-hides-out-of-scope-solution-and-preserves-original-record',()=>{
 const a=load();a.click('competitionPick',{index:String(a.value('taskNow().answer'))});a.click('check');const before=a.value('saved.competition.attempts');a.run('saved.topicPractice.session.excludedSkillIds='+JSON.stringify(Skills.skills.map(s=>s.id)));a.click('competitionShowSolution');assert(a.value('competitionScopedContent(taskNow()).scopeBlocked'));assert.equal(a.value('competitionScopedContent(taskNow()).extension.solutionFrames.length'),0);assert.deepStrictEqual(a.value('saved.competition.attempts'),before);return {historyPreserved:true};
});
check('normal-source-entry-and-pause-resume-share-one-profile',()=>{
 let a=boot();a.run('saved.topicPractice.selectedTopicIds='+JSON.stringify(all)+';saved.topicPractice.sourceIds=["AMC8"];saved.topicPractice.examIds=["AMC8-2000-06"];saved.topicPractice.excludedSkillIds=["G03.02"]');a.click('topicStart');assert.equal(a.value('taskNow().competition.sourceProvenance.examId'),'AMC8-2000-06');const scope=a.value('topicSessionSettings()');a.click('topicExit');a.click('sourceSkillToggle',{code:'G03.02'});a.click('sourceExamClear');a.click('sourceToggle',{code:'original'});a=boot(a.storage);a.click('topicResume');assert.deepStrictEqual(a.value('topicSessionSettings()'),scope);a.click('reasoningOpen');assert(!a.root.innerHTML.includes('data-code="complete-remove"'));assert.equal(a.value('competitionScopedContent(taskNow()).methods.length'),1);return {normalEntry:true,source:'AMC8-2000-06',scope};
});
save('regression/knowledge-profiles',{result:failures.length?'failed':'passed',cases:rows.length,rows,failures,
 unitCount:33,skillCount:179,configurationCount:149,
 limits:['Declared-skill exclusion policy checks do not establish actual mathematical use of every skill','Conservative all-topic route maps remain a separate WP12 backlog','Node generated-interface journeys; native, device and Muse acceptance remain NOT_RUN']});if(failures.length)process.exitCode=1;
