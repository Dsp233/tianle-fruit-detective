'use strict';
const assert=require('assert'),fs=require('fs'),M=require('./competition_reviewed'),Sources=require('./source_catalog'),Skills=require('./skills.json'),Contracts=require('./teaching_skill_contracts'),Graph=require('./reasoning_graph'),{oracle}=require('./rc68_oracles'),{boot}=require('./test_support'),{save}=require('./rc69_evidence');
const all=Skills.units.map(x=>x.id),html=fs.readFileSync('qa/index.html','utf8'),rows=[],failures=[];
const boundaries={fractionBackwards:['A03.07','A03.06'],ratioEqualize:['R01.05','R01.03'],balanceCancel:['L01.03','L01.05'],tickets:['A02.05','L02.04'],linearTable:['L04.01','L04.03'],bells:['N03.02','N03.04'],factorBalance:['N02.02','N02.06'],outsideAngle:['G02.03','G02.04'],circleRoute:['G04.05','G04.04'],exactlyOneSet:['C01.02','C01.05']};
function check(id,fn){try{rows.push({caseId:id,status:'PASS',actual:fn()})}catch(e){rows.push({caseId:id,status:'FAIL',error:e.message});failures.push({caseId:id,error:e.message})}}
const make=(id,seed)=>M.competitionCreate(M.competitionReviewedRecipe(id,seed));
function expectedNodes(id,m){
 switch(id){
  case 'fractionBackwards':return {'second-remainder':'2/3','after-first':3*m.left/2,target:3*m.left};
  case 'ratioEqualize':return {'difference-parts':m.b-m.a,'one-part':m.unit,target:m.b*m.unit};
  case 'balanceCancel':return {'decision-1':'两边同时移去相同盒子','extra-boxes':1,target:m.x};
  case 'tickets':return {baseline:m.people*m.child,difference:m.adults*(m.adult-m.child),'per-change':m.adult-m.child,target:m.adults};
  case 'linearTable':return {'input-gap':2,'output-gap':2*m.k,multiplier:m.k,addition:m.b,target:m.k*m.target+m.b};
  case 'bells':{let joint=m.a;while(joint%m.b)joint+=m.a;return {'joint-period':joint,'decision-1':'不计入',target:Math.floor(m.duration/joint)}}
  case 'factorBalance':{const pairs=[];for(let a=1;a*a<=m.product;a++)if(m.product%a===0)pairs.push([a,m.product/a]);return {pairs:pairs.length,...Object.fromEntries(pairs.map(([a,b],i)=>['sum-'+i,a+b])),target:Math.min(...pairs.map(([a,b])=>a+b))}}
  case 'outsideAngle':return {'other-sum':180-m.apex,'base-angle':(180-m.apex)/2,target:180-(180-m.apex)/2};
  case 'circleRoute':return {'other-arc':m.sectors-m.steps,target:Math.min(m.steps,m.sectors-m.steps)*m.unit};
  case 'exactlyOneSet':return {'only-A':m.a-m.both,'only-B':m.b-m.both,target:m.a+m.b-2*m.both};
 }
}
const seeds=[...Array.from({length:128},(_,i)=>i+1),129,2147483646,2147483647];
for(const id of Object.keys(boundaries))for(const seed of seeds)check('quantity-and-skill-use/'+id+'/'+seed,()=>{
 const t=make(id,seed),c=t.competition,r=c.routes[0],expected=expectedNodes(id,c.math),f=M.COMPETITION_REVIEWED.find(f=>f.id===id),o=oracle(t,f);
 assert.deepStrictEqual(r.nodes.map(n=>n.id),Object.keys(expected));
 for(const n of r.nodes){assert(Graph.accepts(n,String(expected[n.id])),n.id+' independent quantity');assert(n.skillUses?.every(u=>Skills.skills.some(s=>s.id===u.skillId)&&u.reason.length>20));}
 assert.equal(c.answer,String(o.answer));assert.equal(c.extension.answer,String(o.extension));
 const [needed,unrelated]=boundaries[id];assert(!Sources.taskAllowed(t,{topicIds:all,excludedSkillIds:[needed]}).length,'Necessary reasoning skill removed');
 assert.equal(Sources.taskAllowed(t,{topicIds:all,excludedSkillIds:[unrelated]}).length,1,'Unrelated topic skill must not block this route');
 return {familyId:id,seed,nodeCount:r.nodes.length,directSkillIds:Sources.taskRoutes(t)[0].directSkills,necessaryExclusion:needed,unrelatedExclusion:unrelated,quantityOracle:'independent-family-calculation-and-rc68-oracle'};
});
for(const id of Object.keys(boundaries))check('normal-supply-with-only-required-declaration/'+id,()=>{
 const t=make(id,1),required=Sources.taskRoutes(t)[0].requiredSkills,topics=[...new Set(required.map(id=>Skills.skills.find(s=>s.id===id).unitId))],settings={topicIds:topics,excludedSkillIds:Skills.skills.filter(s=>!required.includes(s.id)).map(s=>s.id),sourceIds:['original']};
 const pool=Sources.eligible(M.COMPETITION_REVIEWED,settings),entry=pool.find(f=>f.id===id&&!f.configurationId);assert(entry,'Exact route is available through production supply');assert.deepStrictEqual(entry.allowedRouteIds,[t.competition.routes[0].id]);
 const missing={...settings,excludedSkillIds:[...settings.excludedSkillIds,boundaries[id][0]]};assert(!Sources.eligible(M.COMPETITION_REVIEWED,missing).some(f=>f.id===id&&!f.configurationId));
 return {topicIds:topics,requiredSkillIds:required,originalSupply:true,noAutomaticPrerequisites:true};
});
function load(id,seed=1,excluded=[]){const a=boot({},2000000000000,html);a.run('window.AMC8_QA.loadCase('+JSON.stringify({familyId:id,configuration:id,seed,generatorRevision:3,topicIds:all,excludedSkillIds:excluded})+',true)');return a}
for(const id of Object.keys(boundaries))for(const seed of [1,129,2147483647])check('restricted-route-journey/'+id+'/'+seed,()=>{
 let a=load(id,seed,[boundaries[id][1]]);a.click('reasoningOpen');const r=a.value('taskNow().competition.routes[0]');a.click('reasoningRoute',{code:r.id});
 for(const n of r.nodes){a.inputCompetition('reasoning',n.answer);a.click('reasoningCheck');assert(a.value('reasoningState().state.completed['+JSON.stringify(n.id)+']'));}
 assert(a.value('reasoningState().state.processVerified'));a.click('competitionPick',{index:String(a.value('taskNow().answer'))});a.click('check');assert(a.value('topicCurrent().passed'));a.click('competitionShowSolution');
 const before=a.value('saved.competition.attempts');a=boot(a.storage,2000000000001,html);a.click('topicResume');assert(a.value('topicCurrent().passed'));assert.deepStrictEqual(a.value('saved.competition.attempts'),before);assert(a.value('canPersist'));
 return {familyId:id,seed,route:r.id,nodeCount:r.nodes.length,mainPassRetained:true,runner:'Node generated-HTML handlers'};
});
check('tickets-main-does-not-inherit-variant-enumeration',()=>{
 let a=load('tickets',1,['C02.03']);assert(a.value('SourceCatalog.taskAllowed(taskNow(),topicSessionSettings()).length'));a.click('competitionHint');assert(a.root.innerHTML.includes('若全部按儿童票计算'));
 a.click('competitionPick',{index:String(a.value('taskNow().answer'))});a.click('check');a.click('competitionShowSolution');assert(a.value('topicCurrent().passed'));assert(a.value('competitionScopedContent(taskNow()).variationScopeBlocked'));assert(!a.root.innerHTML.includes('data-action="competitionIndependentVariation"'));
 const before=a.value('saved.competition.extensions'),spoken=a.spoken.length;
 a.inputCompetition('extension',a.value('taskNow().competition.extension.answer'));
 for(const action of ['competitionIndependentVariation','competitionCompareVariation','competitionExtensionCheck','competitionReadExtension'])a.click(action);
 assert.equal(a.spoken.length,spoken);assert.deepStrictEqual(a.value('saved.competition.extensions'),before);assert.equal(a.value('draft.work.extensionInput'),'');
 a=boot(a.storage,2000000000001,html);a.click('topicResume');a.click('topicPrevious');assert(a.value('topicCurrent().passed'));assert(a.value('competitionScopedContent(taskNow()).variationScopeBlocked'));assert(a.value('canPersist'));return {mainAvailable:true,variantActionsBlocked:4,recordAndReloadPreserved:true};
});
for(const [id,excluded,hiddenMethod] of [['ratioEqualize','A03.02',1],['balanceCancel','L01.05',1],['bells','C02.03',1],['exactlyOneSet','C01.05',1]])check('alternative-method-has-own-boundary/'+id,()=>{
 const a=load(id,1,[excluded]),raw=a.value('taskNow().competition.methods'),scope=a.value('SourceCatalog.teachingScope(taskNow(),topicSessionSettings())');assert(!scope.allowedMethodIndexes.includes(hiddenMethod));
 a.click('competitionPick',{index:String(a.value('taskNow().answer'))});a.click('check');a.click('competitionShowSolution');assert(!a.root.innerHTML.includes(raw[hiddenMethod].name));
 a.click('competitionMethod',{index:'1'});a.click('competitionReadStep',{index:'0'});assert(a.spoken.every(x=>!JSON.stringify(x).includes(raw[hiddenMethod].steps[0])));return {excluded,mainRetained:true,hiddenMethod:raw[hiddenMethod].name};
});
check('old-variant-draft-and-success-remain-hidden-and-intact-outside-scope',()=>{
 let a=load('tickets');a.click('competitionPick',{index:String(a.value('taskNow().answer'))});a.click('check');a.click('competitionIndependentVariation');a.inputCompetition('extension',a.value('taskNow().competition.extension.answer'));a.click('competitionExtensionCheck');assert(a.value('draft.work.extensionResult.ok'));
 const records=a.value('saved.competition.extensions'),input=a.value('draft.work.extensionInput');a.run('saved.topicPractice.session.excludedSkillIds=["C02.03"]');a.click('competitionShowSolution');assert(!a.root.innerHTML.includes('class="variation-feedback"'));assert.deepStrictEqual(a.value('saved.competition.extensions'),records);assert.equal(a.value('draft.work.extensionInput'),input);
 a=boot(a.storage,2000000000001,html);a.click('topicResume');a.click('topicPrevious');assert.deepStrictEqual(a.value('saved.competition.extensions'),records);assert.equal(a.value('draft.work.extensionInput'),input);assert(!a.root.innerHTML.includes('class="variation-feedback"'));return {priorSuccessPreserved:true,draftPreserved:true,hiddenOutsideSavedScope:true};
});
check('method-free-quantity-guidance-stays-in-declared-scope',()=>{
 const a=load('outsideAngle',1,['A02.06']);assert(a.value('SourceCatalog.taskAllowed(taskNow(),topicSessionSettings()).length'));assert.deepStrictEqual(a.value('SourceCatalog.teachingScope(taskNow(),topicSessionSettings()).allowedMethodIndexes'),[]);
 a.click('competitionPick',{index:String(a.value('taskNow().answer'))});a.click('check');a.click('competitionShowSolution');assert(a.root.innerHTML.includes('连接已经求出的量'));assert(!a.root.innerHTML.includes('180−'));return {independentQuantityRouteAvailable:true,unlearnedOperationOrderNotShown:true};
});
check('normal-minimal-scope-session-restores-without-domain-tag-selection',()=>{
 const t=make('tickets',1),required=Sources.taskRoutes(t)[0].requiredSkills,topics=[...new Set(required.map(id=>Skills.skills.find(s=>s.id===id).unitId))],excluded=Skills.skills.filter(s=>!required.includes(s.id)).map(s=>s.id);
 let a=boot();a.run('saved.topicPractice.selectedTopicIds='+JSON.stringify(topics)+';saved.topicPractice.sourceIds=["original"];saved.topicPractice.excludedSkillIds='+JSON.stringify(excluded));a.click('topicStart');assert.equal(a.value('taskNow().competition.family'),'tickets');assert(!a.value('topicSession().topicIds.includes("L02")'));
 a.inputCompetition('notes','Keep the cost difference model');const id=a.value('taskNow().id'),settings=a.value('topicSessionSettings()');a.click('competitionPick',{index:String(a.value('(taskNow().answer+1)%5'))});a.click('check');assert.equal(a.value('feedback.ok'),false);
 a=boot(a.storage,2000000000001);a.click('topicResume');assert.equal(a.value('taskNow().id'),id);assert.deepStrictEqual(a.value('topicSessionSettings()'),settings);assert.equal(a.value('draft.work.notes'),'Keep the cost difference model');assert.equal(a.value('feedback.ok'),false);assert(a.value('canPersist'));
 a.click('competitionPick',{index:String(a.value('taskNow().answer'))});a.click('check');a=boot(a.storage,2000000000002);a.click('topicResume');assert(a.value('saved.competition.attempts.some(x=>x.correct&&x.taskId==='+JSON.stringify(id)+')'));assert(a.value('canPersist'));return {normalProductionEntry:true,domainTag:'L02',declaration:topics,wrongDraftAndCorrectRecordPersisted:true};
});
save('regression/precise-skill-routes',{result:failures.length?'failed':'passed',cases:rows.length,rows,failures,reviewedOriginalConfigurations:10,
 directSkillIds:[...new Set(rows.filter(x=>x.actual?.directSkillIds).flatMap(x=>x.actual.directSkillIds))].sort(),
 limits:['Explicit developer review of ten original generator-3 configurations, not all 179 skills or all configurations','Method extras and variation use are separately bounded; prior records remain replayable','Node quantity and generated-interface evidence only; native, device, Muse and learner acceptance remain NOT_RUN']});
if(failures.length)process.exitCode=1;
