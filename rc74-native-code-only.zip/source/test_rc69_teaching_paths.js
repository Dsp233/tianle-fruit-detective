'use strict';
const assert=require('assert'),fs=require('fs'),M=require('./competition_reviewed'),Graph=require('./reasoning_graph'),Session=require('./reasoning_session'),Sources=require('./source_catalog'),O=require('./rc68_oracles'),Fresh=require('./competition_fresh_oracles'),{boot}=require('./test_support'),{save}=require('./rc69_evidence');
const manifest=require('../docs/rc69-execution-manifest.json'),html=fs.readFileSync('qa/index.html','utf8'),seeds=[1,2,129,2147483646,2147483647],rows=[],failures=[];
function check(familyId,seed,name,fn){try{rows.push({familyId,seed,name,status:'PASS',actual:fn()})}catch(e){rows.push({familyId,seed,name,status:'FAIL',error:e.message});failures.push({familyId,seed,name,error:e.message})}}
function create(familyId,seed,configurationId){return M.competitionCreate(configurationId?{engine:3,familyId,seed,configurationId,generatorRevision:4}:M.competitionReviewedRecipe(familyId,seed))}
function submit(s,g,node){assert(Session.focus(s,g,node.id));s.input=node.answer;assert(Session.submit(s,g),node.id);return Session.restore(JSON.parse(JSON.stringify(s)),s.signature,g)}
// Exercise a different valid order, including a reload after every answer.
for(const row of manifest.reasoning28Families)for(const seed of seeds)check(row.familyId,seed,'Reverse ready-node order preserves work across reloads',()=>{
 const t=create(row.familyId,seed),g=Graph.create(t.competition),expected=O.oracle(t,M.COMPETITION_REVIEWED.find(f=>f.id===row.familyId)).answer;assert.deepStrictEqual(Graph.validate(g),[]);
 const orders=[];
 for(const route of g.routes){let s=Session.fresh(t.competition.signature,g.graphRevision);assert(Session.select(s,g,route.id));const order=[];
  while(!s.processVerified){const ready=route.nodes.filter(n=>!s.completed[n.id]&&Session.ready(s,n));assert(ready.length,'No legal next step');const node=ready.at(-1);s=submit(s,g,node);order.push(node.id);assert(s.completed[node.id]);}
  const target=route.nodes.findLast(n=>n.id==='target')||route.nodes.at(-1);assert(Math.abs(O.rational(s.completed[target.id].input)-expected)<1e-8);assert.equal(order.length,route.nodes.length);orders.push({routeId:route.id,order});
 }
 return {routes:orders};
});
// The expected sibling quantities come from the mathematical roles, not from
// the graph's stored dependency list.
const siblings={
 'natural-weighted':['red-total','blue-total'],'natural-fractionWeighted':['red-total','blue-total'],
 'natural-catch':['lead','gap-speed'],'natural-tiles':['along-width','along-height'],
 'natural-pairChance':['all-pairs','red-pairs'],'natural-offers':['shop-A','shop-B'],
 'natural-coordinateDistance':['x-gap','y-gap'],routeProbability:['all-routes','allowed-routes'],
 cubeProbability:['one-edge','all-edges'],overlapProbability:['overlap-width','overlap-height'],
 ratioUnion:['attendance','parts'],chartAverage:['count','score-total'],
 recurrenceRemainders:['whole-cycles','tail-size'],remainderProbability:['whole-cycles','tail'],
 'rule-weighted-mean':['A-score','B-score'],'rule-weighted-score':['total-score','B-score'],'rule-ratio-length':['half','parts']
};
for(const [familyId,[first,second]]of Object.entries(siblings))for(const seed of seeds)check(familyId,seed,'Choose sibling first, reload, and revise the other without losing it',()=>{
 const t=create(familyId,seed),g=Graph.create(t.competition),route=g.routes[0];let s=Session.fresh(t.competition.signature,g.graphRevision);Session.select(s,g,route.id);
 const nodes=new Map(route.nodes.map(n=>[n.id,n]));
 function establish(id){const node=nodes.get(id);for(const dep of node.prerequisiteIds)if(!s.completed[dep])establish(dep);s=submit(s,g,node)}
 establish(second);assert(!s.completed[first],'Independent first quantity was required');assert(s.completed[second]);
 establish(first);assert(Session.revise(s,g,first));assert(s.completed[second],'Revision erased a valid sibling');s=Session.restore(s,t.competition.signature,g);assert(s.completed[second]);
 return {first,second,preservedInput:s.completed[second].input};
});
for(const seed of seeds){
 check('consecutiveRepresentations',seed,'Every bounded candidate is shown without preselection, including invalid lengths',()=>{
  const t=create('consecutiveRepresentations',seed),g=Graph.create(t.competition),nodes=g.routes[0].nodes,max=Math.floor((Math.sqrt(8*t.competition.math.total+1)-1)/2),candidates=nodes.filter(n=>n.candidateLength);
  assert.deepStrictEqual(candidates.map(n=>n.candidateLength),Array.from({length:max-1},(_,i)=>i+2));let count=0,invalid=0;
  for(const node of candidates){const length=node.candidateLength,starts=[];for(let start=1;start<=t.competition.math.total;start++){let total=0;for(let k=0;k<length;k++)total+=start+k;if(total===t.competition.math.total)starts.push(start)}
   assert(!node.prompt.includes('合法表示'));assert(node.prompt.includes('否则'));assert(!node.choices);
   if(starts.length){count++;assert(Graph.accepts(node,String(starts[0])));assert(!Graph.accepts(node,'不成立'));assert(Graph.recognizes(node,'不成立'));}
   else{invalid++;assert(Graph.accepts(node,'不成立'));assert(!Graph.accepts(node,'1'));}
  }
  assert(invalid>0);assert.equal(count,Fresh.freshOracle('consecutiveRepresentations',t.competition.math).answer);
  const a=boot({},2000000000000,html);a.run('window.AMC8_QA.loadCase('+JSON.stringify({familyId:'consecutiveRepresentations',seed,generatorRevision:3})+',true)');a.click('reasoningOpen');a.click('reasoningRoute',{code:'family-quantities'});
  const nav=a.root.innerHTML.match(/<details class="reasoning-goals[\s\S]*?<\/details>/)?.[0]||'';assert(nav);for(const node of candidates)assert(nav.includes('data-code="'+node.id+'"'));
  assert(!nav.includes('data-code="start-'));return {maximum:max,candidateCount:candidates.length,valid:count,invalid};
 });
 check('stepwiseRoute',seed,'Probability-flow route works without complete-route counting',()=>{
  const t=create('stepwiseRoute',seed),g=Graph.create(t.competition),r=g.routes.find(r=>r.id==='probability-flow'),m=t.competition.math;assert(r);assert(!r.nodes.some(n=>n.id==='route-count'));
  const walks=Fresh.walks(m);for(const n of r.nodes.filter(n=>n.id.startsWith('arrival-'))){const [,x,y]=n.id.split('-').map(Number);const actual=walks.filter(p=>{let px=0,py=0;if(x+y===0)return true;for(const step of p.route){if(step==='R')px++;else py++;if(px===x&&py===y)return true}return false}).reduce((sum,p)=>sum+p.weight,0);assert.equal(O.rational(n.answer),actual,n.id);}
  const a=boot({},2000000000000,html);a.run('window.AMC8_QA.loadCase('+JSON.stringify({familyId:'stepwiseRoute',seed,generatorRevision:3})+',true)');a.click('reasoningOpen');a.click('reasoningRoute',{code:r.id});for(const n of r.nodes){a.inputCompetition('reasoning',n.answer);a.click('reasoningCheck')}assert(a.value('reasoningState().state.processVerified'));assert(!a.value('reasoningState().state.completed["route-count"]'));return {target:m.x+','+m.y,routeId:r.id,answer:t.competition.answer};
 });
 check('routeProbability',seed,'Direct count excludes P and reaches the independent endpoint',()=>{
  const t=create('routeProbability',seed),g=Graph.create(t.competition),r=g.routes.find(r=>r.id==='direct-route-count'),m=t.competition.math;assert(r);assert(!r.nodes.some(n=>n.id==='through-P'));
  function count(x,y){let result=0;function walk(px,py){if(px===m.x&&py===m.y)return;if(px===x&&py===y){result++;return}if(px<x)walk(px+1,py);if(py<y)walk(px,py+1)}walk(0,0);return result}
  for(const node of r.nodes.filter(n=>n.id.startsWith('ways-'))){const [,x,y]=node.id.split('-').map(Number);assert.equal(O.rational(node.answer),count(x,y),node.id);}
  assert.equal(O.rational(r.nodes.at(-1).answer),O.oracle(t,M.COMPETITION_REVIEWED.find(f=>f.id==='routeProbability')).answer);return {routeId:r.id,allowed:count(m.w,m.h)};
 });
 check('parityPermutations',seed,'New boundary variant agrees with actual permutations and keeps legacy role swap',()=>{
  const t=create('parityPermutations',seed,'first-odd-transfer'),m=t.competition.math,expected=O.parityEnumeration(m.n),legacy=create('parityPermutations',seed);assert.equal(+t.competition.answer,expected.answer);assert.equal(+t.competition.extension.answer,expected.extension);assert(expected.extension<expected.answer);assert.equal(t.competition.quality.variationSpec.transferStrength,'changed-boundary');
  assert.equal(t.competition.extension.problemState.math.firstParity,'odd');assert(t.competition.extension.diagram.caption.includes('首位'));assert(t.competition.extension.prompt.includes('首位必须是奇数'));
  assert(legacy.competition.extension.prompt.includes('奇数都不能相邻'));if(legacy.competition.math.n%2===0)assert.equal(legacy.competition.quality.variationSpec.transferStrength,'isomorphic-role-swap');
  assert.notEqual(t.competition.signature,legacy.competition.signature);assert.notEqual(t.competition.extension.signature,legacy.competition.extension.signature);return {n:m.n,main:expected.answer,variant:expected.extension,legacySignature:legacy.competition.signature};
 });
}
check('consecutiveRepresentations',1,'Old process evidence is archived and cannot certify newly required candidate checks',()=>{
 const t=create('consecutiveRepresentations',1),g=Graph.create(t.competition),old={...Session.fresh(t.competition.signature,1),routeId:'family-quantities',completed:{'decision-1':{input:'首项与项数',providedBy:'student'},'maximum-length':{input:'10',providedBy:'student'},'start-0':{input:'31',providedBy:'student'},target:{input:'5',providedBy:'student'}},processVerified:true};
 const restored=Session.restore(old,t.competition.signature,g);assert.equal(restored.processVerified,false);assert(!restored.completed.target);assert.equal(restored.archivedGraphs.length,1);assert.equal(restored.archivedGraphs[0].completed['start-0'].input,'31');assert.equal(restored.archivedGraphs[0].completed.target.input,'5');assert.equal(Session.restore(restored,t.competition.signature,g).archivedGraphs.length,1);return {archivedRevision:1,currentRevision:restored.graphRevision};
});
check('parityPermutations',1,'Normal original-source selection and QA can reach the added configuration',()=>{
 const all=require('./skills.json').skills.map(s=>s.unitId),pool=Sources.eligible(M.COMPETITION_REVIEWED,{topicIds:[...new Set(all)],sourceIds:['original'],excludedSkillIds:[]});assert(pool.some(f=>f.id==='parityPermutations'&&f.configurationId==='first-odd-transfer'));
 const a=boot({},2000000000000,html);a.run('window.AMC8_QA.loadCase({familyId:"parityPermutations",configuration:"first-odd-transfer",seed:1,generatorRevision:4},true)');assert.equal(a.value('taskNow().competition.recipe.configurationId'),'first-odd-transfer');a.click('competitionPick',{index:String(a.value('taskNow().answer'))});a.click('check');assert(a.value('topicCurrent().passed'));a.click('competitionIndependentVariation');a.inputCompetition('extension','576');a.click('competitionExtensionCheck');assert(a.value('draft.work.extensionResult.ok'));assert(a.value('canPersist'));return {configurationId:'first-odd-transfer'};
});
save('regression/teaching-paths',{result:failures.length?'failed':'passed',cases:rows.length,rows,failures,baselineConfigurations:148,currentConfigurations:149,limits:['Developer Node/source and generated UI evidence only; native browser and Muse remain NOT_RUN','Complete candidate checking is one route; direct final answers remain allowed','New boundary transfer supplements, and does not overwrite, historical parity recipes']});if(failures.length)process.exitCode=1;
