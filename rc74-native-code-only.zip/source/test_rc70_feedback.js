'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert'),M=require('./competition_reviewed'),I=require('./competition_integrated'),F=require('./competition_feedback'),C=require('./competition_content_contracts'),O=require('./rc68_oracles');
const configs=require('../docs/rc69-execution-manifest.json').configurations.map(c=>({familyId:c.familyId,id:c.configurationId,recipe:{...c.rc68Recipe,...(c.familyId==='natural-weighted'?{generatorRevision:5}:{})}}));
for(const f of I.catalog)for(const id of f.configurations)configs.push({familyId:f.id,id,recipe:{engine:3,familyId:f.id,configurationId:id,generatorRevision:5,seed:1}});
const rows=[],failures=[];for(const c of configs)try{
 const t=M.competitionCreate({...c.recipe,seed:1}),o=O.oracle(t,M.COMPETITION_REVIEWED.find(f=>f.id===c.familyId));
 for(const scopeId of ['main','variation:'+t.competition.extension.key]){
  const descriptor=C.resolve(t,scopeId),expected=scopeId==='main'?O.exactInput(o.answer):O.exactInput(o.extension);assert(F.evaluateInput(expected,descriptor).ok);
  for(const delta of [1,2]){const input='('+expected+')+'+delta,task={...t,competition:{...t.competition,misconceptions:scopeId==='main'?t.competition.misconceptions:[{value:input,feedback:'MAIN_ONLY_SENTINEL'}]}};
   const feedback=F.diagnose({task,input,scopeId});assert.equal(feedback.scopeId,scopeId);assert.equal(feedback.goalId,descriptor.goal.id||'target');assert.equal(feedback.modelId,descriptor.modelId);assert(feedback.text.trim().length>=5);assert(!/^(再想想|答案不对|再试一次)[。！!]*$/.test(feedback.text.trim()));assert(!/undefined|NaN|MAIN_ONLY_SENTINEL/.test(feedback.text));assert.equal(feedback.confidence,'suggested_check');rows.push({familyId:c.familyId,configurationId:c.id,scopeId,input,modelId:feedback.modelId,goalId:feedback.goalId,ruleId:feedback.diagnosticRuleId,text:feedback.text,status:'PASS'});
  }
 }
}catch(error){failures.push({familyId:c.familyId,configurationId:c.id,error:error.stack})}
const out=process.env.AMC8_RC70_EVIDENCE||'tmp/rc70/checks';fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'feedback.json'),JSON.stringify({result:failures.length?'FAIL':'PASS',cases:rows.length,rows,failures,limits:['Two legal non-answer probes per scope check matching and fallback; raw values alone do not establish a unique misconception','Muse independently reviews diagnostic usefulness']},null,2)+'\n');console.log(failures.length?'FAIL':'PASS',rows.length,'scope feedback checks');if(failures.length){console.log(JSON.stringify(failures.slice(0,3)));process.exitCode=1}
