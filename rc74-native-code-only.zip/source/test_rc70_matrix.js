'use strict';
// Complete fixed-instance matrix. Uses only synthetic QA records and independent
// expected values; VM evidence is explicitly distinct from native browser proof.
const fs=require('fs'),path=require('path'),assert=require('assert'),{boot}=require('./test_support'),M=require('./competition_reviewed'),O=require('./rc68_oracles'),P=require('./problem_state');
const root=process.env.AMC8_RC70_CANDIDATE||path.resolve(__dirname,'..'),scope=JSON.parse(fs.readFileSync(path.join(root,'scope.json'))),html=fs.readFileSync(path.join(root,'qa/index.html'),'utf8'),seeds=[1,2,129,2147483646,2147483647],shard=Number(process.env.AMC8_RC70_SHARD||0),shards=Number(process.env.AMC8_RC70_SHARDS||1),rows=[],failures=[];
const all=scope.configurations.flatMap(c=>seeds.map(seed=>({...c,seed}))).filter((_,i)=>i%shards===shard);
for(const c of all){const row={familyId:c.familyId,configurationId:c.configurationId,seed:c.seed,status:'NOT_RUN',runner:'Node VM production UI handlers'};
 try{
  const recipe={...c.recipe,seed:c.seed},t=M.competitionCreate(recipe),f=M.COMPETITION_REVIEWED.find(f=>f.id===c.familyId),o=O.oracle(t,f),main=O.exactInput(o.answer),variant=O.exactInput(o.extension),a=boot({},2000000000000,html),q={familyId:c.familyId,configuration:c.configurationId,seed:c.seed,generatorRevision:recipe.generatorRevision};
  assert(P.equal(t.competition.answer,main));assert(P.equal(t.competition.extension.answer,variant));a.run('window.AMC8_QA.loadCase('+JSON.stringify(q)+',true)');
  if(c.familyId==='signedProduct'){
   a.click('competitionIndependentVariation');a.click('competitionExtensionCheck');a.click('competitionPick',{index:String(t.answer)});a.click('check');assert.equal(a.value('feedback.status'),'unsupported_scope');assert.equal(a.value('saved.competition.attempts.length'),0);assert.equal(a.value('saved.competition.extensions.length'),0);row.status='POLICY_PASS';row.policy='untaught-negative-products';
  }else{
   a.click('competitionIndependentVariation');assert(a.root.innerHTML.includes('competition-extension" open'));a.click('competitionExtensionCheck');assert.equal(a.value('draft.work.extensionResult.status'),'awaiting_input');
   a.inputCompetition('extension','abc');a.click('competitionExtensionCheck');assert.equal(a.value('draft.work.extensionResult.status'),'invalid_input');
   a.inputCompetition('extension','987654321');a.click('competitionExtensionCheck');assert.equal(a.value('draft.work.extensionResult.status'),'needs_revision');
   a.inputCompetition('extension',variant);a.click('competitionExtensionCheck');assert(a.value('draft.work.extensionResult.ok'));assert(!a.value('topicCurrent().passed'));const variants=a.value('saved.competition.extensions.length');a.click('competitionExtensionCheck');assert.equal(a.value('saved.competition.extensions.length'),variants);
   const free=c.familyId==='threeGroupBalance'||t.competition.integrated;if(free)a.inputCompetition('final','abc');a.click('check');assert.equal(a.value('feedback.status'),free?'invalid_input':'awaiting_input');assert.equal(a.value('saved.competition.attempts.length'),0);
   if(free)a.inputCompetition('final','987654321');else a.click('competitionPick',{index:String((t.answer+1)%t.options.length)});a.click('check');assert.equal(a.value('feedback.status'),'needs_revision');assert(a.value('feedback.text').length>8);
   if(free)a.inputCompetition('final',main);else a.click('competitionPick',{index:String(t.answer)});a.click('check');assert(a.value('topicCurrent().passed'));assert(a.value('feedback.ok'));const n=a.value('saved.competition.attempts.length');a.click('check');assert.equal(a.value('saved.competition.attempts.length'),n);
   a.click('competitionHint');a.click('competitionReadHint',{scope:'main',index:'0'});assert(a.spoken.length);a.inputCompetition('notes','synthetic-notes-'+c.seed);const snapshot=a.value('JSON.stringify(saved)');a.run('render();render()');assert.equal(a.value('JSON.stringify(saved)'),snapshot);
   const b=boot(a.storage,2000000000001,html);b.run('window.AMC8_QA.loadCase('+JSON.stringify(q)+',false)');assert(b.value('topicCurrent().passed'));assert(b.value('feedback.ok'));assert(b.value('draft.work.extensionResult.ok'));assert.equal(b.value('draft.work.notes'),'synthetic-notes-'+c.seed);assert(b.value('draft.work.hintLevel')>0);
   row.status='PASS';row.main=main;row.variation=variant;row.dimensions={math:'PASS',independentVariation:'PASS',emptyInvalidWrongCorrect:'PASS',idempotency:'PASS',renderPurity:'PASS',refresh:'PASS',hintNarrationRequest:'PASS'};
  }
 }catch(error){row.status='FAIL';row.error=error.stack;failures.push(row)}rows.push(row);
}
const out=process.env.AMC8_RC70_EVIDENCE||'tmp/rc70/checks';fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'matrix-'+shard+'.json'),JSON.stringify({schema:1,result:failures.length?'FAIL':'PASS',shard,shards,instanceCount:rows.length,rows,failures,limits:['Node VM only; real browser, audible speech and geometry are independent gates']},null,2)+'\n');console.log(failures.length?'FAIL':'PASS',rows.length,'instance pairs',failures.length,'failures');if(failures.length){console.log(JSON.stringify(failures.slice(0,2)));process.exitCode=1}
