'use strict';
const {boot,M,assert,fs,path,load,report,suite,configurations}=require('./rc73_test_support'),Contracts=require('./competition_content_contracts');
const s=suite(),app=boot(),old=boot({},2000000000000,fs.readFileSync(path.join(__dirname,'../docs/evidence/rc73/baseline/rc72-main.html'),'utf8')),instances=[],seeds=[1,2,129,2147483646,2147483647];
function mathContract(t){return {id:t.id,contentVersion:t.contentVersion,prompt:t.prompt,options:t.options,optionIds:t.optionIds,answer:t.answer,signature:t.competition.signature,math:t.competition.math,recipe:t.competition.recipe,extension:{prompt:t.competition.extension.prompt,answer:t.competition.extension.answer,signature:t.competition.extension.signature,key:t.competition.extension.key,math:t.competition.extension.math}}}
function diagram(d){return app.value('competitionDiagram('+JSON.stringify(d)+')')}
function quantity(html,expected){
 const mode=html.match(/data-count-mode="([^"]+)"/)?.[1],represented=Number(html.match(/data-represented-count="(\d+)"/)?.[1]),glyphs=(html.match(/data-quantity-glyph/g)||[]).length;
 if(expected==='?'){assert.equal(mode,'unknown');assert.equal(glyphs,0);return}
 assert.equal(represented,expected);
 if(expected>18){assert.equal(mode,'compressed');assert.equal(glyphs,1);assert(html.includes('× '+expected));assert(html.includes('图标为示意'))}
 else{assert.equal(mode,'exact');assert.equal(glyphs,expected)}
}
for(const c of configurations())for(const seed of seeds){
 const task=M.competitionCreate({...c.recipe,seed});
 s.test('identity/'+c.familyId+'/'+c.configurationId+'/'+seed,()=>assert.deepStrictEqual(mathContract(task),mathContract(old.value('competitionCreate('+JSON.stringify({...c.recipe,seed})+')'))));
 for(const scope of ['main','variation']){
  const contract=Contracts.resolve(task,scope==='main'?'main':'variation:condition-transfer'),id=c.familyId+'/'+c.configurationId+'/'+seed+'/'+scope;
  s.test('diagram/'+id,()=>{
   assert.equal(contract.initialDiagramAllowed,false);assert.equal(contract.diagramRole,'hint');if(/如图|如表|图中|表中/.test(scope==='main'?task.prompt:task.competition.extension.prompt))assert(contract.givenText);
   const d=contract.diagram,html=diagram(d);
   if(d?.kind==='scene-purchase'){
    const expected=c.familyId==='packPrice'?[{size:3}]:c.familyId==='mixedPacks'?[{size:4},{size:6}]:c.familyId.startsWith('rule-packs-')?[{size:Number((scope==='main'?task.competition.math:task.competition.extension.math).params.size)}]:d.packs||[{size:d.size,price:d.pack}],containers=[...html.matchAll(/data-package-size="([^"]+)">([\s\S]*?)<\/div>/g)];
    assert.equal(containers.length,expected.length);containers.forEach((m,i)=>{assert.equal(Number(m[1]),expected[i].size);quantity(m[2],expected[i].size)});
   }
   if(d?.kind==='scene-units'){
    const expected=c.familyId==='equalBags'?[task.competition.math.a,task.competition.math.b]:d.groups.map(g=>g.count),containers=[...html.matchAll(/<section class="scene-group"[^>]*>([\s\S]*?)<\/section>/g)];assert.equal(containers.length,expected.length);containers.forEach((m,i)=>quantity(m[1],expected[i]));
   }
   instances.push({familyId:c.familyId,configurationId:c.configurationId,seed,scopeId:scope,status:'PASS',phase:'content-contract-and-hint-render',diagramKind:d?.kind||null});return {diagramKind:d?.kind||null};
  });
 }
}
s.test('count-boundaries',()=>{for(const count of [0,1,18,19,44,66,'?'])quantity(diagram({kind:'scene-units',groups:[{name:'物品',count,unit:'个'}]}),count)});
s.test('negative-count-fixtures',()=>{const valid=diagram({kind:'scene-units',groups:[{name:'糖',count:44,unit:'颗'}]});assert.throws(()=>quantity(valid.replace('× 44','× 43'),44));assert.throws(()=>quantity(valid.replace('data-represented-count="44"','data-represented-count="43"'),44));assert.throws(()=>quantity(valid.replaceAll('图标为示意',''),44));const pack=diagram({kind:'scene-purchase',size:3,pack:8,single:4,count:14,object:'支笔'});assert.throws(()=>quantity(pack,3))});
s.test('restricted-team-target-not-prefilled',()=>{const a=load('restrictedTeam');a.click('competitionIndependentVariation');const id=a.value('CompetitionWork.variationId(taskNow())');a.click('competitionHint',{scope:id});const d=a.value('CompetitionPresentation.projectDiagram(taskNow(),draft.work,'+JSON.stringify(id)+')');assert.equal(d.groups[2].count,'?');assert.equal(d.groups[2].quantityRole,'target');const html=diagram(d);assert(!/>13(?:\s|<)/.test(html));assert.equal((html.match(/scene-person /g)||[]).length,2);assert(diagram(a.value('taskNow().competition.extension.solutionFrames[0]')).includes('13 人'))});
s.test('offset-bells-draft-versus-solution',()=>{const t=M.competitionCreate(M.competitionReviewedRecipe('offsetBells',1)),hint=diagram(t.competition.extension.diagram),solution=diagram(t.competition.extension.solutionFrames[0]);assert(hint.includes('第一次：4 分钟'));assert(hint.includes('之后每 8 分钟'));assert(!/>12</.test(hint));assert(/>12</.test(solution))});
s.test('repeated-ones-positions',()=>{const t=M.competitionCreate(M.competitionReviewedRecipe('repeatedOnes',1));assert.deepEqual(t.competition.diagram.positionLabels,['第1位','第2位','…','第17位']);assert(t.competition.extension.diagram.positionLabels.includes('第18位'));assert(!diagram(t.competition.diagram).includes('>4</span>'))});
s.test('percent-reference-unit',()=>{const t=M.competitionCreate(M.competitionReviewedRecipe('percentRestore',1));for(const d of [t.competition.diagram,t.competition.extension.diagram]){const h=diagram(d);assert(h.includes('看作100份'));assert(h.includes('100 份'));assert(h.includes('为整体'))}});
s.test('hint-only-first-screen-and-independent-scopes',()=>{const a=load('outsideAngle');assert(!a.root.innerHTML.includes('<svg'));a.click('competitionHint');assert(a.root.innerHTML.includes('<svg'));const title=a.root.innerHTML.indexOf('class="task-title"'),hint=a.root.innerHTML.indexOf('class="competition-hints"'),form=a.root.innerHTML.indexOf('data-competition-form="main"');assert(title<hint&&hint<form);a.click('competitionIndependentVariation');assert.equal(a.value('draft.work.scopes[CompetitionWork.variationId(taskNow())].help.revealedHintIds.length'),0)});
report('diagram-contract',s.rows,{instanceScopes:instances.length,uniqueInstanceScopes:new Set(instances.map(r=>JSON.stringify([r.familyId,r.configurationId,r.seed,r.scopeId]))).size,instances,reviewBoundary:'Visual aesthetics, original missing 275 REVIEW item evidence and child usability remain independent review.'});
