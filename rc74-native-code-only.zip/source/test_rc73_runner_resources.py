"""Resource and classification contracts. No sleeping or browser simulation."""
import hashlib, json, os, pathlib, tempfile
from gate_resources import snapshot,worker_limit,retry_delay,task_budget,MIB
from run_rc70_gates import classify,run_plan
from unittest.mock import patch

rows=[]
def test(name,fn):
    try:fn();rows.append({'caseId':name,'status':'PASS'})
    except Exception as e:rows.append({'caseId':name,'status':'FAIL','error':repr(e)})
def check(value):
    assert value
def fixture_snapshot():
    with tempfile.TemporaryDirectory() as td:
        root=pathlib.Path(td);proc=root/'proc';cg=root/'cg';proc.mkdir();cg.mkdir()
        (proc/'meminfo').write_text('MemAvailable: 8000000 kB\nMemTotal: 16000000 kB\n')
        (cg/'memory.max').write_text(str(4096*MIB));(cg/'memory.current').write_text(str(3900*MIB));(cg/'cpu.max').write_text('200000 100000')
        r=snapshot(proc,cg);check(r['availableBytes']==196*MIB);check(r['cpus']<=2);check(worker_limit('cpu',r)==0)
test('E01-cgroup-current-subtracted',fixture_snapshot)
test('E02-insufficient-memory-allows-zero',lambda:check(worker_limit('cpu',{'cpus':8,'availableBytes':558*MIB,'reserveBytes':512*MIB})==0))
test('E03-kind-and-inflight-budgets',lambda:check(worker_limit('cpu',{'cpus':8,'availableBytes':4096*MIB,'reserveBytes':512*MIB})>worker_limit('browser',{'cpus':8,'availableBytes':4096*MIB,'reserveBytes':512*MIB}) and worker_limit('cpu',{'cpus':8,'availableBytes':4096*MIB,'reserveBytes':512*MIB},3500*MIB)==0))
test('E04-only-evidenced-infra',lambda:check(classify(-9,'OOM killed process')==('BLOCKED','INFRA') and classify(1,'EPERM write failed')==('BLOCKED','INFRA') and classify(1,'ERR_BLOCKED_BY_LOCAL_NETWORK_ACCESS_CHECKS')==('BLOCKED','INFRA')))
test('E05-unknown-crash-and-timeout',lambda:check(classify(-5,'SIGTRAP')==('BLOCKED','UNKNOWN') and classify(124,'timeout')==('BLOCKED','UNKNOWN') and classify(-9,'')==('BLOCKED','UNKNOWN')))
test('E06-product-assertion-retained',lambda:check(classify(1,'AssertionError: wrong mathematical answer')==('FAIL','PRODUCT')))
test('E07-retry-minimum-and-retry-after',lambda:check(all(retry_delay(i,(30,120,300),jitter=0)>=d for i,d in enumerate((30,120,300),1)) and retry_delay(1,(30,120,300),retry_after=180,jitter=1)>=180 and retry_delay(4,(30,120,300)) is None))
test('E08-missing-browser-not-passed',lambda:check(classify(2,'BROWSER_UNAVAILABLE')==('BLOCKED','MISSING_EVIDENCE')))
def no_resource_launch():
    with tempfile.TemporaryDirectory() as td:
        plan={'buildId':'synthetic-policy-test','testDefinitionHash':'synthetic-definition','tasks':[{'caseId':'cpu/test','kind':'cpu','script':'must-not-run','runtime':'node'}]}
        with patch('run_rc70_gates.resource_limit',return_value=0),patch.dict(os.environ,{'AMC8_RESOURCE_WAIT_SECONDS':'0'}),patch('run_rc70_gates.execute') as execute:
            check(run_plan(plan,pathlib.Path(td))==2);execute.assert_not_called()
        check(json.loads((pathlib.Path(td)/'resource-blocked.json').read_text())['status']=='BLOCKED')
test('E02-actual-zero-worker-admission',no_resource_launch)
out=pathlib.Path(os.environ.get('AMC8_RC70_EVIDENCE','tmp/rc73/checks'));out.mkdir(parents=True,exist_ok=True)
report={'schema':1,'result':'FAIL' if any(r['status']!='PASS' for r in rows) else 'PASS','cases':len(rows),'rows':rows,'resources':snapshot(),'limits':['Pure resource policy contracts; no fabricated browser/independent acceptance']}
(out/'runner-resources.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['result'],len(rows),'resource contracts')
raise SystemExit(0 if report['result']=='PASS' else 1)
