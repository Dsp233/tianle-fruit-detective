"""Independent exact arithmetic for the RC73 review disagreements; no project oracle."""
import itertools
import json
import os
import pathlib
import subprocess
from fractions import Fraction

ROOT = pathlib.Path(__file__).resolve().parent.parent
code = """const M=require('./source/competition_reviewed'),rows=[];
for(const id of ['oppositeScale','recurrenceRemainders','stepwiseRoute','parityPermutations'])
for(const configurationId of id==='parityPermutations'?[null,'first-odd-transfer']:[null])
for(const seed of [1,2,129,2147483646,2147483647]){
 const recipe=configurationId?{engine:3,familyId:id,configurationId,generatorRevision:4,seed}:M.competitionReviewedRecipe(id,seed);
 const t=M.competitionCreate(recipe);rows.push({recipe,math:t.competition.math,main:t.competition.answer,variation:t.competition.extension.answer});
}console.log(JSON.stringify(rows));"""
inputs = json.loads(subprocess.check_output(['node', '-e', code], cwd=ROOT, text=True))
rows = []


def residue_sum(first, second, count):
    terms = [first, second]
    while len(terms) < count:
        terms.append(terms[-1] + terms[-2])
    return sum(n % 3 for n in terms[:count])


def route_weights(m):
    paths = []

    def walk(x, y, probability, path, hit):
        hit = hit or (x, y) == (m['x'], m['y'])
        if (x, y) == (m['w'], m['h']):
            paths.append({'path': path, 'probability': str(probability), 'throughP': hit})
            return
        moves = []
        if x < m['w']:
            moves.append((x + 1, y, 'R'))
        if y < m['h']:
            moves.append((x, y + 1, 'U'))
        for nx, ny, direction in moves:
            walk(nx, ny, probability / len(moves), path + direction, hit)

    walk(0, 0, Fraction(1), '', False)
    assert sum(Fraction(p['probability']) for p in paths) == 1
    return (sum(Fraction(p['probability']) for p in paths if p['throughP']),
            Fraction(sum(p['throughP'] for p in paths), len(paths)), paths)


def permutations(n, first_odd):
    main, variation = 0, 0
    for order in itertools.permutations(range(1, n + 1)):
        no_adjacent_evens = all(a % 2 or b % 2 for a, b in zip(order, order[1:]))
        no_adjacent_odds = all(a % 2 == 0 or b % 2 == 0 for a, b in zip(order, order[1:]))
        main += no_adjacent_evens
        variation += (no_adjacent_evens and order[0] % 2 == 1) if first_odd else no_adjacent_odds
    return main, variation


for item in inputs:
    recipe, m = item['recipe'], item['math']
    family, detail = recipe['familyId'], {}
    if family == 'recurrenceRemainders':
        main, variation = residue_sum(1, 1, m['n']), residue_sum(2, 2, m['n'])
    elif family == 'stepwiseRoute':
        main, variation, paths = route_weights(m)
        detail['paths'] = paths
        if recipe['seed'] == 1:
            assert main == Fraction(1, 2) and variation == Fraction(2, 3)
            assert all(Fraction(p['probability']) != Fraction(1, 16) for p in paths)
    elif family == 'parityPermutations':
        main, variation = permutations(m['n'], recipe.get('configurationId') == 'first-odd-transfer')
    else:
        main, variation = Fraction(m['old'] * m['a'], m['b']), Fraction(m['b'], m['a']) ** 2
    assert Fraction(main) == Fraction(item['main']), recipe
    assert Fraction(variation) == Fraction(item['variation']), recipe
    rows.append({'recipe': recipe, 'main': str(main), 'variation': str(variation), 'status': 'PASS', **detail})

assert len(rows) == 25
out = pathlib.Path(os.environ.get('AMC8_RC70_EVIDENCE', str(ROOT / 'tmp/rc74/math-review')))
out.mkdir(parents=True, exist_ok=True)
report = {'result': 'PASS', 'cases': len(rows), 'answerComparisons': 2 * len(rows),
          'method': 'Python arbitrary precision integers, Fraction, complete route and permutation enumeration',
          'projectOracleUsed': False, 'rows': rows}
(out / 'math-review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS independent math review: 25 recipes / 50 exact answers; forced boundary probabilities verified')
