'use strict';
const {assert,fs,path,load,report,suite,configurations}=require('./rc73_test_support');
const M=require('./competition_reviewed'),C=require('./competition_content_contracts'),N=require('./storage_namespaces'),s=suite(),seeds=[1,2,129,2147483646,2147483647];
for(const config of configurations())s.test('shared-text-contract/'+config.familyId+'/'+config.configurationId,()=>{
 const task=M.competitionCreate({...config.recipe,seed:1});
 for(const scope of ['main','variation']){const c=C.resolve(task,scope);assert(c.promptText&&c.narrationText);assert(c.narrationText.includes(c.promptText));if(c.givenText)assert(c.narrationText.includes(c.givenText));assert.equal(c.initialDiagramAllowed,false);assert(!/如图|如表|图中|表中|坐标图/.test(c.promptText));}
});
for(const family of ['oppositeScale','chartAverage','natural-coordinateDistance'])for(const seed of seeds)s.test('direct-variation-givens-and-speech/'+family+'/'+seed,()=>{
 const a=load(family,null,seed),task=a.value('taskNow()'),c=task.competition,m=c.math,main=C.resolve(task),v=C.resolve(task,'variation');
 assert(!a.root.innerHTML.includes('<svg'));assert(a.root.innerHTML.includes(main.promptText));
 a.click('competitionRead');assert.equal(a.spoken.at(-1),a.value('competitionSpeechText('+JSON.stringify(main.narrationText)+')'));
 a.click('competitionIndependentVariation');assert(a.root.innerHTML.includes(v.promptText));if(v.givenText)assert(a.root.innerHTML.includes(v.givenText));
 a.click('competitionReadExtension');const spoken=a.spoken.at(-1);assert.equal(spoken,a.value('competitionSpeechText('+JSON.stringify(v.narrationText)+')'));
 if(family==='oppositeScale'){assert(v.promptText.includes(m.b+'/'+m.a));assert(spoken.includes(m.a+'分之'+m.b));assert.equal(v.narrationText,v.promptText);}
 if(family==='chartAverage'){m.counts.forEach((n,i)=>assert(spoken.includes('得 '+(2*(i+1))+' 分的有 '+n+' 人')));assert.equal(c.extension.problemState.math.counts[2],m.counts[2]+1);}
 if(family==='natural-coordinateDistance')assert(v.givenText.includes('A=('+m.x+','+m.y+')')&&v.givenText.includes('B=('+(m.x+m.dx)+','+(m.y+m.dy)+')'));
 const before=JSON.stringify(a.value('saved.competition'));a.click('competitionStopSpeech');assert.equal(JSON.stringify(a.value('saved.competition')),before);
 const b=load(family,null,seed);b.click('competitionIndependentVariation');assert.equal(b.value('topicCurrent().passed'),false);assert.equal(b.value('saved.competition.attempts.length'),0);
 return {recipe:c.recipe,prompt:v.promptText,givens:v.givenText,narration:spoken};
});
for(const family of ['quarterTurn','natural-coordinateDistance','chartAverage'])s.test('visible-empty-and-wrong-feedback/'+family,()=>{
 const a=load(family),t=a.value('taskNow()');a.click('check');assert.equal(a.value('feedback.status'),'awaiting_input');assert.equal(a.value('saved.competition.attempts.length'),0);
 let html=a.root.innerHTML,button=html.indexOf('data-action="check"'),message=html.indexOf('data-answer-status="awaiting_input"'),end=html.indexOf('</form>',button);assert(button<message&&message<end);assert(html.includes('先选一个答案。'));
 a.click('competitionPick',{index:String((t.answer+1)%5)});a.click('check');assert.equal(a.value('feedback.status'),'needs_revision');assert.equal(a.value('topicCurrent().passed'),false);assert.equal(a.value('saved.competition.attempts.length'),1);assert(a.root.innerHTML.includes('这次还没答对。'));assert(a.root.innerHTML.includes('tabindex="-1" data-answer-status="needs_revision"'));
 a.click('competitionIndependentVariation');a.inputCompetition('extension','-99999');a.click('competitionExtensionCheck');assert(a.root.innerHTML.includes('variation-feedback competition-submit-feedback'));assert(a.root.innerHTML.includes('这次还没答对。'));
});
s.test('legacy-qa-records-retained-in-archive',()=>{
 const rows=N.registry(require('./version.json'));assert.equal(new Set(rows.map(r=>r.key)).size,10);
 for(const version of [72,73,74])for(const scope of ['qa','qa-normal','qa-history'])assert(rows.some(r=>r.version===version&&r.scope===scope));
 assert.equal(N.registry('V12.0-rc.73').length,7);assert.equal(N.registry('V12.0-rc.72').length,4);
});
s.test('l-shape-references-text-conditions',()=>{
 const task=M.competitionCreate({engine:3,familyId:'lShapeArea',configurationId:'amc2000-06-full',generatorRevision:4,seed:1}),c=C.resolve(task);assert(c.promptText.includes('下方文字描述'));assert(c.givenText.includes('等宽L形条带'));assert(c.narrationText.includes(c.givenText));
});
report('rc74-presentation',s.rows,{scope:'Shared display and narration, inherited givens, unchanged math, explicit and inline feedback; native viewport checked separately in the full Chrome matrix'});
