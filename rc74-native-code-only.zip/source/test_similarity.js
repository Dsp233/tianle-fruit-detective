'use strict';
module.exports=function({assert,boot,microState,microLatest,solveSimilar,solveStage,SIMILAR_TASKS,STAGED_TASKS,release}){
 const {similarTransform,similarBoundary,similarCells,similarWorld}=require('./similar_ui');
 const submit=(b,reason=true)=>{if(reason)b.click('reason',{index:'0'});b.click('check');return microLatest(b)};
 const answer=(b,n)=>{for(let k=0;k<n;k+=.25)b.click('similarAnswer',{delta:'0.25'})};
 const b=boot();for(const [sid,t] of Object.entries(SIMILAR_TASKS)){
  b.click('micro',{code:sid});assert(b.root.innerHTML.includes('data-action="similar"'));b.click('similar',{code:sid});assert(b.root.innerHTML.includes(t.prompt));
  const before=b.storage.tianle_amc8_question_design_v1?microState(b).attempts.length:0;b.click('check');assert.equal(b.storage.tianle_amc8_question_design_v1?microState(b).attempts.length:0,before);
  solveSimilar(b,t);b.click('check');assert(b.root.innerHTML.includes('先说一说你的理由'));assert.equal(submit(b).gradingResult,'correct',t.id);b.click('next');assert(b.root.innerHTML.includes('它能联系到哪里？'));
 }
 const backup=boot({tianle_amc8_question_design_v1:JSON.stringify({storageVersion:2,contentRevision:release.contentRevision,skillStage:Object.fromEntries(Object.keys(SIMILAR_TASKS).map(sid=>[sid,{transferPassed:true,independentTried:true}]))})});
 for(const sid of Object.keys(SIMILAR_TASKS)){backup.click('stage',{code:sid+'|independent2'});solveStage(backup,STAGED_TASKS[sid].independent2);assert.equal(microLatest(backup).independent,true);backup.click('next')}
 const distance=(p,q)=>Math.hypot(p[0]-q[0],p[1]-q[1]),area=ps=>Math.abs(ps.reduce((n,p,i)=>{const q=ps[(i+1)%ps.length];return n+p[0]*q[1]-p[1]*q[0]},0))/2;
 const angleCos=(ps,i)=>{const p=ps[i],u=ps[(i+ps.length-1)%ps.length].map((v,k)=>v-p[k]),v=ps[(i+1)%ps.length].map((x,k)=>x-p[k]);return (u[0]*v[0]+u[1]*v[1])/(Math.hypot(...u)*Math.hypot(...v))};
 const all=[...Object.values(SIMILAR_TASKS),...Object.values(STAGED_TASKS).flatMap(Object.values)].filter(t=>t.mode==='similarLab');
 for(const t of all){
  if(t.kind==='correspond'){
   const target=similarTransform(t.points,t.factor,t.factor,t.rotation||0);
   for(let i=0;i<t.points.length;i++){assert(Math.abs(distance(target[i],target[(i+1)%target.length])/distance(t.points[i],t.points[(i+1)%t.points.length])-t.factor)<1e-10);assert(Math.abs(angleCos(target,i)-angleCos(t.points,i))<1e-10)}
   assert(Math.abs(area(target)/area(t.points)-t.factor**2)<1e-10);
  }
  if(t.kind==='perimeter')for(const [width,height] of [[t.width,t.height],[t.width*t.goalX,t.height*t.goalY]]){const edges=similarBoundary(width,height);assert.equal(edges.length,2*(width+height));assert.equal(edges.reduce((n,[p,q])=>n+distance(p,q),0),2*(width+height));for(let i=0;i<edges.length;i++)assert.deepEqual(edges[i][1],edges[(i+1)%edges.length][0])}
 }
 assert.deepEqual(similarBoundary(4.5,3),[],'unit boundary never silently rounds fractional lengths');
 const stretch=STAGED_TASKS['G05.02'].transfer,world=similarWorld(stretch,'target',{scaleX:3,scaleY:2});assert.equal(distance(world[0],world[1])/distance(world[1],world[2]),9/4);assert.notEqual(9/4,3/2);
 const wrongPairs=boot();wrongPairs.click('similar',{code:'G05.01'});for(const [a,c] of [[0,0],[1,2],[2,1]]){wrongPairs.click('similarPoint',{side:'source',index:String(a)});wrongPairs.click('similarPoint',{side:'target',index:String(c)});wrongPairs.click('similarLink')}for(const side of ['source','target'])for(const kind of ['Edge','Angle'])wrongPairs.click('similarMark',{side,kind,index:'0'});assert.equal(submit(wrongPairs).gradingResult,'incorrect','all vertices paired wrongly cannot pass');
 const duplicate=boot();duplicate.click('similar',{code:'G05.01'});for(const [a,c] of [[0,0],[0,1]]){duplicate.click('similarPoint',{side:'source',index:String(a)});duplicate.click('similarPoint',{side:'target',index:String(c)});duplicate.click('similarLink')}assert.equal(submit(duplicate).operationSummary.work.links.length,1,'one endpoint can belong to only one pair');
 const mark=boot();mark.click('similar',{code:'G05.01'});solveSimilar(mark,SIMILAR_TASKS['G05.01']);mark.click('similarMark',{side:'target',kind:'Angle',index:'1'});assert.equal(submit(mark).gradingResult,'incorrect');
 const undo=boot();undo.click('similar',{code:'G05.01'});solveSimilar(undo,SIMILAR_TASKS['G05.01']);undo.click('similarUnlink',{index:'1'});undo.click('similarUndo');assert.equal(submit(undo).gradingResult,'correct');
 const nonuniform=boot();nonuniform.click('stage',{code:'G05.02|transfer'});solveSimilar(nonuniform,stretch);nonuniform.click('similarChoice',{value:'similar'});assert.equal(submit(nonuniform,false).gradingResult,'incorrect');
 const axis=boot();axis.click('similar',{code:'G05.02'});for(let i=0;i<4;i++)axis.click('similarScale',{axis:'x',delta:'0.5'});axis.click('similarChoice',{value:'similar'});assert.equal(submit(axis).gradingResult,'incorrect');
 for(const [sid,n] of [['G05.03',3],['G05.04',9],['G05.05',2.5]]){const guess=boot();guess.click('similar',{code:sid});answer(guess,n);assert.equal(submit(guess).gradingResult,'incorrect','number alone is not manipulation')}
 const traced=boot();traced.click('similar',{code:'G05.03'});solveSimilar(traced,SIMILAR_TASKS['G05.03']);const tw=submit(traced).operationSummary.work;assert.equal(tw.trace.source.length,10);assert.equal(tw.trace.target.length,30);assert(traced.root.innerHTML.includes('data-unit-edge-id="target-29"'));
 const missing=boot();missing.click('similar',{code:'G05.03'});for(let i=0;i<4;i++)missing.click('similarScale',{axis:'both',delta:'0.5'});for(let i=0;i<30;i++)missing.click('similarTrace',{side:'target'});answer(missing,3);assert.equal(submit(missing).gradingResult,'incorrect','source measurement is required too');
 const stale=boot();stale.click('similar',{code:'G05.03'});solveSimilar(stale,SIMILAR_TASKS['G05.03']);stale.click('similarScale',{axis:'both',delta:'-0.5'});stale.click('similarScale',{axis:'both',delta:'0.5'});assert.equal(submit(stale).gradingResult,'incorrect');assert.equal(microLatest(stale).operationSummary.work.trace.target.length,0);
 const fill=boot();fill.click('similar',{code:'G05.04'});solveSimilar(fill,SIMILAR_TASKS['G05.04']);const fw=submit(fill).operationSummary.work;assert.equal(fw.covered.source.length,6);assert.equal(fw.covered.target.length,54);assert.equal(fw.answer,9);
 const cut=boot(),ct=STAGED_TASKS['G05.04'].transfer;cut.click('stage',{code:'G05.04|transfer'});solveSimilar(cut,ct);cut.click('similarCell',{side:'target',row:'0',col:'0'});const cw=submit(cut,false).operationSummary.work;assert.equal(cw.covered.source.length,4);assert.equal(cw.covered.target.length,12);assert(!cw.covered.target.includes('0,0'));assert.equal(cw.answer,3);assert(cut.root.innerHTML.includes('预先剪去格'));const whole=boot();whole.click('stage',{code:'G05.04|transfer'});solveSimilar(whole,ct);whole.click('similarAnswer',{delta:'1'});assert.equal(submit(whole,false).gradingResult,'incorrect','remaining region is not the whole scaled area');
 const erased=boot();erased.click('similar',{code:'G05.04'});solveSimilar(erased,SIMILAR_TASKS['G05.04']);erased.click('similarScale',{axis:'both',delta:'-0.5'});assert.equal(submit(erased).operationSummary.work.covered.target.length,0);
 assert.deepEqual(similarCells(SIMILAR_TASKS['G05.04'],'target',{scaleX:1.5,scaleY:1.5}),[],'fractional dimensions need actual subdivision, not rounded cells');
 const inverse=boot();inverse.click('similar',{code:'G05.05'});solveSimilar(inverse,SIMILAR_TASKS['G05.05']);inverse.click('similarScale',{axis:'y',delta:'-0.5'});assert.equal(submit(inverse).gradingResult,'incorrect','both corresponding dimensions must use inferred factor');
 const speech=boot({},true);speech.click('similar',{code:'G05.05'});speech.click('speakState');assert(!speech.spoken.at(-1).includes('2.5倍'));speech.click('similarScale',{axis:'both',delta:'0.5'});speech.click('speakState');assert(speech.spoken.at(-1).includes('新尺寸6乘3'));
};
