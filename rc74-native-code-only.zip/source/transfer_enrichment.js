'use strict';
// Authored transfers change a representation, condition, direction or unknown.
// Finite number variants are distinct instances, not new transfer dimensions.
const transferStages=typeof module!=='undefined'?require('./staged').STAGED_TASKS:STAGED_TASKS;
const TRANSFER_AUDIT={};
function replaceTransfer(sid,params,dimension,proof,contentVersion=72){
 const old=transferStages[sid].transfer;
 transferStages[sid].transfer={id:old.id,skillId:sid,phase:'迁移',contentVersion,authorship:'原创儿童操作适配',...params,semanticParameters:Object.fromEntries(Object.entries(params).filter(([key])=>key!=='prompt')),changeDimension:dimension,explain:proof,hint:'先看改变的条件，再动手验证。'};
 TRANSFER_AUDIT[sid]={taskId:old.id,contentVersion,dimension,proof,codeStatus:'真实模型已接入；数学/状态按证据登记；浏览器与iPad待验'};
}
function retainTransfer(sid,dimension,proof){
 const t=transferStages[sid].transfer;
 if(dimension)t.changeDimension=dimension;
 if(proof)t.explain=proof;
 TRANSFER_AUDIT[sid]={taskId:t.id,contentVersion:t.contentVersion,dimension:t.changeDimension,proof:t.explain,codeStatus:'既有实质变化已审查；浏览器与iPad待验'};
}
replaceTransfer('A01.02',{mode:'reverseExchange',initialTens:2,initialOnes:2,targetTens:0,targetOnes:22,prompt:'把2根十棒都拆开，与原来的2个散点合起来，再判断总数。'},'捆十改为逐棒拆回；交换方向和次数改变','20个棒内原点和2个散点仍是22个，表示改变而数量不变。');
replaceTransfer('A01.03',{mode:'placeCompose',tens:5,ones:2,sourceMoney:[20,20,10,1,1],prompt:'看钱币图：两张20元、一张10元和两枚1元。用十棒和散点表示同样金额。'},'不同面额组合转成十与一','20＋20＋10＋1＋1＝52；每张20元对应两个十。');
replaceTransfer('A01.05',{mode:'forwardExchange',initialTens:2,initialOnes:13,prompt:'把2个十和13个一整理成个位不足10的表示。先将10个散点收入框，再捆棒。'},'标准表示拆回改为非标准表示重新组成十','同一批33个原单位由2十13一整理为3十3一。');
replaceTransfer('A02.02',{mode:'tenFill',filled:8,filledIndices:[0,1,2,4,5,6,8,9],target:10,prompt:'圆点散放在十格板里。只补空格，一格一颗，正好凑满十。'},'连续尾部空位改为中间分散空位','两个空位各补一个；位置变化，8＋2＝10不变。');
replaceTransfer('A02.03',{mode:'inverseMove',initial:8,delta:3,inverseOrder:'removeFirst',prompt:'先从8颗里拿走3颗，再把同样的3颗逐颗放回。选择整个过程的关系。'},'先加后减改为先减后加；放回同一批原点','8－3＋3＝8，被拿走的三个原点回到原盘。');
replaceTransfer('A02.04',{mode:'equalGroups',groups:4,each:3,total:12,arrayLayout:true,prompt:'把12个原点排成4行，每行3个。每点只占一个位置。'},'分盘等组改为二维行列阵列','4行各3点组成12点；行数是组数，列数是每组量。');
replaceTransfer('A03.01',{mode:'fractionLab',kind:'shade',denom:6,target:4,partitionRows:2,prompt:'同一个长方形平均分成两行共6格。涂其中4份。'},'一维纸条改为二维等面积分割','六个等面积小格合成同一整体，四格占4/6。');
replaceTransfer('A03.02',{mode:'fractionLab',kind:'shade',denom:6,target:1,wholeShape:'circle',prompt:'同一个圆平均分成6个扇形。点亮一个等份，表示1/6。'},'等长纸条改为等面积圆扇形','同圆六个等角扇形面积相等，其中一份是整个圆的1/6。');
replaceTransfer('A03.03',{mode:'fractionLab',kind:'compare',denomLeft:4,targetLeft:3,denomRight:4,targetRight:2,wholeScaleLeft:1,wholeScaleRight:2,correctChoice:'differentWhole',prompt:'左边整条只有右边的一半长。各四等分，左涂3格、右涂2格。能只按涂色格数比较实际长度吗？'},'整体不同的反例；区分分数大小与实际量','3/4与2/4这两个分数能比较，但左边每格更短，实际长度不能仅按3格与2格判断。');
replaceTransfer('A03.04',{mode:'fractionLab',kind:'equal',denomLeft:4,targetLeft:2,denomRight:8,targetRight:4,partitionRowsLeft:2,partitionRowsRight:2,compareArea:true,prompt:'两个外框面积一样大，左分4格涂2格，右分8格涂4格。比较涂色面积。'},'等长度等值改为二维等面积等值','同样大的两个面都涂一半，2/4＝4/8；格数无需相等。');
replaceTransfer('A03.05',{mode:'fractionLab',kind:'line',denom:4,target:3,lineStart:1,lineEnd:2,coordinate:1.75,prompt:'数轴显示1到2，平均分成4段。点出1又3/4的刻度。'},'数轴左端不再为零；由段数转绝对坐标','从1再走3/4单位到1又3/4，第三段端点不是3/4。');
replaceTransfer('A03.06',{mode:'fractionLab',kind:'decimal',denom:10,target:4,wholeShape:'circle',choices:['0.4','0.04','4'],correctChoice:'0.4',prompt:'同圆平均分10个扇形，涂4份，选择对应小数。'},'长度十分位改为面积十分位','4/10＝0.4，形状改变而整体单位不变。');
replaceTransfer('A03.07',{mode:'fractionLab',kind:'remainder',total:18,first:6,second:6,answerBasis:'remaining',requireBasisSelection:true,choices:['1/2','1/3','2/3'],correctChoice:'1/2',prompt:'18块先拿6块，再拿6块。选择第一次之后的一盘作为整体，判断第二次取走这盘的几分之几。'},'原整体改为剩余整体；主动选择原点集合','第一次剩12块，第二次6块占6/12＝1/2；按原18块才是1/3。');
replaceTransfer('A04.01',{mode:'percentLab',kind:'shade',total:20,wholeIndices:Array.from({length:12},(_,i)=>i),requireWholeSelection:true,target:3,choices:['25%','15%','3%'],correctChoice:'25%',prompt:'框内12颗是本题整体，桌上另有8颗。先选整体，再涂框内3颗，判断百分数。'},'加入框外对象；全部对象与规定整体分开','3颗占框内12颗的25%；15%采用全桌20颗，基准不符。');
replaceTransfer('A04.02',{mode:'fractionLab',kind:'decimal',denom:20,target:15,partitionRows:4,choices:['0.75','0.075','75'],correctChoice:'0.75',prompt:'同一个方格面共20格，涂出75%，再选小数表示。'},'百分数转分数改为转小数与二维面积','15/20＝3/4＝75/100＝0.75。');
replaceTransfer('A04.03',{mode:'percentLab',kind:'shade',total:8,target:6,wholeShape:'circle',choices:['6','8','75'],correctChoice:'6',prompt:'8个等面积扇形合成一个圆。点亮75%，选择亮了几份。'},'离散排点改为圆面积份','8份的四分之三是6份；75是每百份比例，并非本题份数。');
replaceTransfer('A04.04',{mode:'percentLab',kind:'whole',part:2,knownCount:6,givenPercent:60,knownShares:3,copies:5,choices:['10','6','3.6'],correctChoice:'10',prompt:'整体的60%有6颗。先把6个原点平均分成3个单位份，再补出其余份，恢复整体。'},'已知非单位分数；先拆单位份再反求整体','60%＝3/5，6颗对应3份，每份2颗，5份共10颗。');
replaceTransfer('A04.05',{mode:'percentLab',kind:'change',changeOrder:'removeFirst',start:100,remove:20,add:16,choices:['96','100','104'],correctChoice:'96',prompt:'100先减少20%，再按变化后的整体增加20%。按顺序操作，判断最终量。'},'先增后减改为先减后增；新基准变小','先剩80，再增加80的20%即16，最后96。');
replaceTransfer('A04.06',{mode:'percentLab',kind:'estimate',a:49,b:21,bounds:{lower:[40,20],upper:[50,30]},choices:['800＜积＜1500','积＜800','积＞1500'],correctChoice:'800＜积＜1500',prompt:'给49×21构造整十下界与上界，保存两幅面积模型，再选积所在区间。'},'单近似值改为有方向的严格上下界','正因数满足40＜49＜50、20＜21＜30，所以800＜积＜1500。');
replaceTransfer('R04.05',{mode:'scaleLab',kind:'change',changeOrder:'removeFirst',start:100,remove:20,add:16,choices:['96','100','104'],correctChoice:'96',prompt:'原量100，先减少20%，再按当前量增加20%。完成模型并判断最终量。'},'反向连续变化；每步采用当前基准','100×0.8×1.2＝96；相同百分比对应不同实际增减量。');
for(const sid of ['A01.01','A01.04','A02.01','A02.05','A02.06'])retainTransfer(sid);
replaceTransfer('A05.01',{mode:'integerLab',kind:'position',axis:'vertical',start:0,target:-2,context:'海面与潜水',prompt:'海面记作0。沿竖直数轴向下两格，标出潜水员所在的位置。'},'水平数轴改为正数在上、负数在下的竖直轴','方向取决于数轴：这里向下数值减小，0向下两格是−2。',73);
retainTransfer('A05.02','跨正负比较改为两个负数比较','−2位于−5右边，所以−2更大；绝对值更大不能代替数本身更大。');
replaceTransfer('A05.03',{mode:'integerLab',kind:'walk',start:3,target:-2,context:'反向跨零',prompt:'从＋3逐格走到−2，经过0；每步向左一格，不绕路。'},'由负到正改为由正到负；跨零方向反转','3到0是3格，再到−2是2格，共5格；每步坐标减1。',73);
replaceTransfer('A05.04',{mode:'integerLab',kind:'square',side:3,unitSize:2,target:36,context:'方砖面积',prompt:'每块方砖边长2米。铺出3行、每行3块的正方形，再写实际面积。'},'格数改为含实际边长的面积单位','9块方砖，每块4平方米，总面积36平方米；9是块数。',73);
replaceTransfer('A05.05',{mode:'integerLab',kind:'root',side:3,unitSize:2,target:36,context:'方砖边长',prompt:'每块方砖边长2米。拼出面积36平方米的正方形，再写实际边长。'},'平方根从方格边数改为实际长度','3块连成一边，每块2米，边长6米；6×6＝36。',73);
replaceTransfer('A05.06',{mode:'integerLab',kind:'power',base:1,exponent:4,target:1,context:'不增长的复制规则',prompt:'从1开始，每轮乘1，共做4轮。观察数量是否一定增长。'},'底数1的边界反例；重复乘法不一定增长','1的四次幂仍为1。轮数变化并不意味着数量必定变大。',73);
replaceTransfer('R01.01',{mode:'ratioLab',kind:'partition',red:12,blue:8,copies:4,unitRed:3,unitBlue:2,context:'反求单位份',prompt:'红12颗、蓝8颗，分成4个完全相同的份。先决定一份中各色的数量，再逐份分完。'},'已知一份求份数改为已知份数求单位份','蓝8颗对应4份，每份蓝2颗；红12颗对应同样4份，每份红3颗。',73);
retainTransfer('R01.02','比的先后顺序由红在前改为蓝在前','前项必须对应题目先说的颜色，不能按界面位置固定写红在前。');
replaceTransfer('R01.03',{mode:'ratioLab',kind:'whole',red:2,blue:3,focusSide:'blue',context:'部分换位',prompt:'摆出红2颗、蓝3颗。把整个盒子作为整体，选择蓝色占整体的几分之几。'},'关注的部分从红色改为蓝色；整体包含两色','蓝色3颗，整体5颗，所以蓝占3/5；3/2是蓝比红。',73);
replaceTransfer('R01.04',{mode:'ratioLab',kind:'scale',red:3,blue:2,copies:2,targetCopies:{red:2,blue:1},context:'单边复制反例',prompt:'原来红3颗、蓝2颗。只把红色复制一份，蓝色不变。完成模型，判断配比是否保持。'},'共同倍增改为只变一种量的反例','红变成6、蓝仍2；6:2不等于3:2，单边复制改变配比。',73);
replaceTransfer('R01.05',{mode:'ratioLab',kind:'partition',red:8,blue:4,copies:4,unitRed:2,unitBlue:1,knownUnit:true,context:'反求完整份数',prompt:'每袋红2颗、蓝1颗。把红8颗和蓝4颗按这个配方分袋，找出能分几袋。'},'已知总量与袋数求每袋量改为已知每袋量求袋数','两色每袋配方固定，4袋恰好用完红8颗、蓝4颗。',73);
retainTransfer('R02.01','给总价求单价改为给单价合成总价','每一件放入相同单价；未知量从每件价格换为总价。');
retainTransfer('R02.02','由总流量反求单位率改为给单位率合成总量','已知每单位的量，必须对全部时间格按同样量累计。');
replaceTransfer('R02.03',{mode:'rateLab',kind:'compare',a:{units:2,per:3,total:6},b:{units:4,per:3,total:12},unit:'本',amountUnit:'元',context:'总价不同、单价相同',prompt:'甲2本共6元，乙4本共12元。把两边总价分别平均分到每一本，再比较单价。'},'总价不同但单位率相等的反例','甲6÷2＝3，乙12÷4＝3；总价不同，单价可以相同。',73);
replaceTransfer('R02.04',{mode:'rateLab',kind:'convert',direction:'reverse',from:'米',to:'厘米',factor:100,count:6,context:'小单位捆回大单位',prompt:'600厘米，每100厘米捆成1米。逐份换成米，核对大单位的份数。'},'大单位展开成小单位改为小单位捆回大单位','600厘米含六个100厘米，换成6米；数字减小而长度不变。',73);
retainTransfer('R02.05','由总量求复合单位率改为按已知单位率求总量','距离与时间按同一单位率对应，未知位置从单位率改为总距离。');
replaceTransfer('R03.01',{mode:'journeyLab',kind:'inverse',per:2,count:3,elapsedPer:10,interval:'10分钟',unit:'千米',context:'时间单位转换',prompt:'每10分钟走2千米。逐个时间格摆到6千米，再写实际用了多少分钟。'},'时间格数反求后还需换算为实际分钟','三个时间格，每格10分钟，共30分钟；3是格数，不是分钟数。',73);
retainTransfer('R03.02','由总量反求时间改为给时间合成总量','时间已知时累计各分钟的成果；未知量换为总张数。');
replaceTransfer('R03.03',{mode:'journeyLab',kind:'segment',segments:[3,0,4],interval:'10分钟',unit:'千米',context:'中途停留',prompt:'三个相同时间段依次走3千米、停留、再走4千米。逐时段记录，停留时也保留时间格。'},'加入零路程时段；累计量不变而时间仍推进','三时段累计是3、3、7千米，停留那段不能从时间轴删除。',73);
replaceTransfer('R03.04',{mode:'journeyLab',kind:'remaining',segments:[4,3],whole:12,unknownWhole:true,givenRemaining:5,interval:'段',unit:'千米',context:'从部分恢复全程',prompt:'已经走4千米和3千米，还剩5千米。摆出已走部分，并调整全程外框，正好包含全部路程。'},'给全程求剩余改为给已走和剩余反求整体','已走7千米，加上剩余5千米，全程12千米；剩余只加入一次。',73);
replaceTransfer('R03.05',{mode:'journeyLab',kind:'joint',a:2,b:4,count:3,starts:{a:0,b:1},interval:'分钟',unit:'个',context:'不同开工时间',prompt:'甲每分钟2个，乙每分钟4个。甲先做1分钟，乙从第2分钟加入，到第3分钟结束。按实际开工时间摆成果。'},'同时开工改为乙晚1分钟；分别核对有效工作时长','甲做3分钟得6个，乙做2分钟得8个，共14个；不能把乙也计3分钟。',73);
replaceTransfer('R04.01',{mode:'scaleLab',kind:'pair',red:2,blue:3,factor:2,targetFactors:{red:2,blue:1},context:'只改一种颜色',prompt:'红2朵、蓝3朵。只复制红色一份，蓝色保持不变，判断原配比是否保持。'},'同倍缩放改为单边改变的反例','红4、蓝3的4:3与原2:3不同；两量必须同倍改变才保持比。',73);
replaceTransfer('R04.02',{mode:'scaleLab',kind:'length',short:6,long:10,factor:2,direction:'shrink',context:'反向缩小',prompt:'原图两边长6格和10格。把两条边都缩为原来的一半，观察对应长度。'},'放大改为缩小；长度除以相同倍数','6÷2＝3、10÷2＝5，两边都减为一半，3:5仍等于6:10。',73);
replaceTransfer('R04.03',{mode:'scaleLab',kind:'area',rows:2,cols:2,factor:3,axisFactors:{rows:1,cols:3},context:'只扩一个方向',prompt:'原图2行2列。保持行数，把列数扩成3份，判断新图是否仍与原图相似。'},'两轴共同扩展改为只扩列；面积与相似条件分开','现在2行6列，共12格，是原面积3倍；行列倍数不同，所以形状不相似。',73);
replaceTransfer('R04.04',{mode:'scaleLab',kind:'map',inputUnitSize:2,per:3,count:3,from:'杯面粉',to:'个蛋糕',context:'非单个输入份',prompt:'每2杯面粉对应3个蛋糕。用真实的两杯输入和三个输出组，摆出6杯面粉的对应蛋糕。'},'每一个输入单位改为每两个输入单位的对应组','6杯面粉是三组两杯，每组3个蛋糕，共9个；不能把每杯误当3个蛋糕。',73);

replaceTransfer('L01.01',{mode:'equationLab',kind:'equal',left:[3,2],right:[3,4],equalAnswer:false,methodSpecific:false,context:'等号反例',prompt:'把左盘3＋2、右盘3＋4全部摆出。判断两盘是否相等。'},'两个相等分解改为不相等的反例','左盘5、右盘7，总量不同；都含3并不表示两盘相等。',74);
replaceTransfer('L01.02',{mode:'equationLab',kind:'unknown',known:2,total:8,unknownSide:'right',methodSpecific:false,context:'未知袋换边',prompt:'左边8颗，右边未知袋加2颗，两盘相等。自己确定袋内数，可用两边同取验证。'},'未知袋从等号左边换到右边；允许自主有效解法','8＝袋＋2与袋＋2＝8表达同一等量关系，袋里6颗；不必固定先做同取。',74);
replaceTransfer('L01.03',{mode:'equationLab',kind:'bilateral',known:2,total:6,addBoth:3,methodSpecific:true,context:'双边同加',prompt:'未知袋加2颗等于6颗。两盘各添3颗，再摆出原未知袋，核对原式和新式。'},'两边同减改为两边同加；未知量不变','原袋4颗；两边各添3后，4＋5＝9。只添一边不能保持等量。',74);
replaceTransfer('L01.04',{mode:'equationLab',kind:'inverse',initial:8,remain:3,removedGiven:5,unknownInitial:true,methodSpecific:false,context:'反求原整体',prompt:'先前拿走5颗，现在剩3颗。把同一批拿走的原点放回，再写原来有多少颗。'},'已知原量求拿走量改为给拿走与剩余求原量','拿走的5颗和剩余3颗合成原来8颗，放回改变位置而不制造对象。',74);
replaceTransfer('L01.05',{mode:'equationLab',kind:'substitute',bag:6,known:2,total:9,correctVerdict:'reject',methodSpecific:false,context:'不合适的候选值',prompt:'原式是未知袋＋2＝9。试把袋里放6颗，代回完整原式，判断这个候选是否满足。'},'正确候选改为错误候选；代回是检验而非确认','6＋2＝8，不等于9，候选6不满足原式。',74);
replaceTransfer('L02.01',{mode:'constraintLab',kind:'reverse',groups:3,extra:2,bag:4,extraOutside:true,context:'整批附加一次',prompt:'3个相同未知袋，整批另外加2颗，总共14颗。先撤销整体附加，再把剩余原点均分，找每袋量。'},'每组附加改为整体只附加一次；逆运算层次改变','14－2＝12，再均分3组得每袋4；不能先用14除以3，也不能扣三次2。',74);
replaceTransfer('L02.02',{mode:'constraintLab',kind:'verify',groups:3,extra:2,bag:4,extraOutside:true,givenTotal:15,correctVerdict:'reject',context:'整体附加与错误候选',prompt:'3个相同袋，整批另加2颗，目标总数15。试每袋4颗，摆出完整模型，判断候选是否满足。'},'附加位置换到整体且候选不满足；不能把代回当自动成立','3×4＋2＝14，不是15；附加2只算一次，候选4不满足。',74);
replaceTransfer('L02.03',{mode:'constraintLab',kind:'parity',total:12,divisor:3,context:'可行的整数分组',prompt:'12个原点平均分成3个同样多的整数组。逐轮每组各放1颗，判断能否全分完。'},'有余数的不可行情况改为整除的可行边界','三组各4颗，无剩余，因此有整数解；不能固定选择“没有整数解”。',74);
replaceTransfer('L02.04',{mode:'constraintLab',kind:'stock',stock:3,per:4,context:'连一袋也装不满',prompt:'库存只有3颗，一满袋要4颗。核对原库存和下一袋空位，判断能否装一满袋。'},'可装若干袋改为最大完整袋数为0的边界','3＜4，一满袋也装不出；0个完整袋是有效结论，不是未操作。',74);
replaceTransfer('L02.05',{mode:'constraintLab',kind:'optimal',stock:12,per:4,context:'恰好用完的最优方案',prompt:'12颗，每满袋4颗。比较最多可行方案与再多一袋，选择最大完整袋数。'},'有剩余改为恰好用完；最大可行与邻近不可行证明','3袋正好用完12颗，4袋要16颗，缺4颗；无需强制试遍较小袋数。',74);
retainTransfer('L03.01','交替AB改为含相邻同符号的ABB最短重复块','ABB重复与AB交替不同。只取AB无法生成ABBABB，六格块可以重复但不是最短。');
replaceTransfer('L03.02',{mode:'patternLab',kind:'arithmetic',initial:[14,12,10],step:-2,context:'递减等差',prompt:'规则已给定：每次减2。从14、12、10继续两项。'},'正公差增长改为负公差递减','相邻差都是−2，后两项8、6；不能把差的大小2直接当加2。',74);
replaceTransfer('L03.03',{mode:'patternLab',kind:'geometric',initial:[3,3,3],factor:1,context:'公比为1的边界',prompt:'规则已给定：每次乘1。从3、3、3继续两项，核对是否必须变大。'},'公比大于1改为公比1的常量边界','同一非零数重复时，相邻比为1；后两项仍3、3。',74);
replaceTransfer('L03.04',{mode:'patternLab',kind:'explicit',initial:[1],multiplier:2,add:2,operationOrder:'addThenMultiply',context:'先加再乘',prompt:'从1开始，每一轮先加2，再乘2。按正确顺序生成接下来两项。'},'递推中的操作顺序反转；不是只换系数','(1＋2)×2＝6，(6＋2)×2＝16；先乘再加会得到4、10。',74);
replaceTransfer('L03.05',{mode:'patternLab',kind:'twoPrev',initial:[0,1],count:3,context:'从零开始的两前项递推',prompt:'从0、1开始，规则是每个新项等于紧邻前两项之和。接出三个新项。'},'加入零初始项的边界；迭代增加到三轮','依次0＋1＝1，1＋1＝2，1＋2＝3；每轮必须使用最新两项。',74);
replaceTransfer('L03.06',{mode:'patternLab',kind:'grid',tile:[['red','red','blue'],['blue','blue','red']],rows:4,cols:6,context:'二维重复块',prompt:'给出的两行按“红红蓝／蓝蓝红”构成两行三列重复块。横向和纵向重复这个块，填好下面两行。'},'棋盘相邻交替改为2×3重复块；允许相邻同色','横向每3列重复，纵向每2行重复；相邻两红是规则的一部分，不能强制处处换色。',74);
for(const sid of ['L04.01','L04.02','L04.03','L04.04','L04.05','L04.06'])retainTransfer(sid);

retainTransfer('N01.01','整除的等组改为有余数的反例','完整组数并不证明整除，必须保留余量并核对能否再成完整一组。');
replaceTransfer('N01.02',{mode:'groupingLab',kind:'remainder',total:3,divisor:4,context:'零个完整组',prompt:'3颗，每4颗一组。核对还能否圈出完整组，再选余数。'},'总量少于组量；商为0但余数不为0','3＝0×4＋3；没有完整组不表示余数也是0，余数3小于4。',75);
retainTransfer('N01.03','两位数改为含零的三位数；同时区分2/3/5规则与数位贡献','102除2无余、105除5无余、104除3余2。高位十的倍数除2/5无余；除3保留数位和余数，0的位置仍须明确选择。');
retainTransfer('N01.04','限制从十位改为个位；前导零仍被排除','个位限制与两位数条件须同时满足，02不属于两位数。');
retainTransfer('N01.05','单盘奇偶改为两部分相加，跨部分配对','合计奇偶由全部对象的两两配对决定，颜色和原分盘不限制配对。');
replaceTransfer('N02.01',{mode:'factorLab',kind:'pairs',numbers:[24],requiredPairs:2,minimumSide:2,context:'不许单行的长方阵',prompt:'24块排成完整长方阵，两边都至少2格。记录两种不同的边长对，转向不另算一种。'},'增加两边至少2的限制；平凡因数对不再可用','可用2×12、3×8、4×6；1×24不满足两边至少2，交换边长不产生新因数对。',75);
replaceTransfer('N02.02',{mode:'factorLab',kind:'all',numbers:[16,18],context:'平方与非平方的完整表',prompt:'分别用16块和18块拼遍完整整数长方阵，收录全部不同正因数。相同中间边长只收一次。'},'单一非平方表改为平方/非平方并列；中间因数重复规则不同','16的4×4只贡献一个不同因数；18的每对边长都不同，不能把两盘都按两倍对数计算。',75);
replaceTransfer('N02.03',{mode:'factorLab',kind:'prime',numbers:[1,2,9],context:'质数定义的三个边界',prompt:'用1、2、9块分别拼遍长方阵并收录不同正因数，再判断质数、合数或两者都不是。'},'加入1的定义边界并并列最小偶质数与奇平方合数','1只有一个正因数，两者都不是；2恰有两个，是质数；9有1、3、9，是合数。',75);
retainTransfer('N02.04','单独判断1改为和最小质数2并列比较','1×1中相同的1只算一个不同因数，2有1与2两个不同正因数。');
replaceTransfer('N02.05',{mode:'factorLab',kind:'square',numbers:[16,18],classifySquare:true,context:'检验是否有中间相同边',prompt:'分别拼遍16和18的长方阵，数不同因数，再判断哪盘是平方数。不能假定两盘都有相同的中间边长。'},'只处理平方数改为和非平方数对照；平方条件需要检验','16有4×4，中间因数4只一次，共5个；18无等边因数对，共6个，不是平方数。',75);
retainTransfer('N02.06','平方数改为非平方数；因数个数由奇变偶','非平方数每个因数都配一个不同的伙伴，不能沿用平方中间一项去重的计数。');
replaceTransfer('N03.01',{mode:'commonLab',kind:'multiples',periods:[3,4],starts:[1,2],horizon:25,context:'不同起点的事件',prompt:'甲第一次在1分钟，以后每3分钟；乙第一次在2分钟，以后每4分钟。生成到25分钟，选全部同时发生的时刻。'},'共同零起点改为不同起点；不能直接把时刻当周期公倍数','甲1、4、7、10…，乙2、6、10…，窗口内重合10、22；12是周期最小公倍数，却不是这里的第一次重合时刻。',75);
replaceTransfer('N03.02',{mode:'commonLab',kind:'least',periods:[4,6],starts:[1,3],horizon:30,context:'异起点的最早重合',prompt:'甲从1分钟起每4分钟一次，乙从3分钟起每6分钟一次。实际生成两条线，找最早同时发生的时刻。'},'有共同起点的最小公倍数应用改为异起点重合','甲1、5、9…，乙3、9…，最早9分钟；不能把周期的12直接当时刻答案。',75);
replaceTransfer('N03.03',{mode:'commonLab',kind:'divisors',numbers:[8,9],context:'只有单位共同因数',prompt:'8颗和9颗按相同正整数的组量试装，收录两盘都没有剩余的全部组量。'},'有非单位共同因数改为互质边界','8和9只有共同正因数1；共同不表示一定有大于1的因数。',75);
replaceTransfer('N03.04',{mode:'commonLab',kind:'greatest',dims:[6,9],unitSize:2,unit:'厘米',context:'方格边数与实际长度',prompt:'6格×9格纸板，每格边长2厘米。试铺最大整数格边长正方形，排除更大方案，再写实际边长。'},'格边数改为带物理长度单位的最大边长','最大边长3格，每格2厘米，所以实际6厘米；3是格数。',75);
replaceTransfer('N03.05',{mode:'commonLab',kind:'contexts',bells:{periods:[3,4],starts:[1,2],horizon:22},paper:{dims:[6,9],unitSize:2,unit:'厘米'},context:'不同条件的两个目标',prompt:'甲从1分钟起每3分钟，乙从2分钟起每4分钟，找首次重合；6×9格纸板每格2厘米，求最大方块实际边长。操作两套材料并选各自最小或最大目标。'},'同零起点与纯格数改为异起点事件和真实长度','事件首次重合10分钟；纸板最大方块3格即6厘米。两故事的目标和基准分别核对。',75);
replaceTransfer('N04.01',{mode:'groupingLab',kind:'reconstruct',total:14,divisor:4,knownGroups:3,remainder:2,context:'从商余恢复总数',prompt:'已有3组，每组4颗，另有2颗散点。把原组逐个打开合回一盘，再写原总数。'},'给总数求余数改为给完整组与余数反求总数','3×4＋2＝14，余数2小于4；只把原对象合回，不制造新点。',75);
replaceTransfer('N04.02',{mode:'patternLab',kind:'period',base:['A','A','A'],context:'看起来三格，实际一格',prompt:'整串全部是同一种图形。圈出最短的重复块，并用它生成整串。'},'多种图形的非平凡周期改为周期1边界；显示段不等于最短块','一格A就能生成全部A；三格可以重复，但不是最短。',75);
replaceTransfer('N04.03',{mode:'cycleLab',kind:'position',base:['A','B','B'],indexBase:0,target:8,context:'从编号0开始',prompt:'编号0是A，之后B、B，再重复。从编号0出发走到编号8，选择轮内编号。'},'第1项计数改为零基编号；先走距离再定位','编号8除以3余2，对应轮内编号2；零基编号无需再减1。',75);
replaceTransfer('N04.04',{mode:'cycleLab',kind:'weekday',base:['星期一','星期二','星期三','星期四','星期五','星期六','星期日'],start:1,direction:-1,target:9,context:'向过去倒数',prompt:'今天星期二记作0天。实际往前倒数9天，判断那天是星期几。'},'向未来过天改为向过去倒数；模负数需规范化','倒数7天仍星期二，再倒数2天到星期日；负位移不能仍顺向走。',75);
replaceTransfer('N04.05',{mode:'cycleLab',kind:'power',factor:4,period:2,target:0,context:'零次乘法的起点',prompt:'非零数4的0次方：从单位1开始，一次也不乘4。把原单位移到结果盘，选择保留的个位。'},'正指数末位循环改为零指数边界；不能套用正项周期','非零底数的0次方为1；4的正指数个位4、6不包含0次方的起始单位。',75);
replaceTransfer('N04.06',{mode:'cycleLab',kind:'position',base:['A','B','C','D'],indexBase:0,target:12,context:'零基编号的整轮',prompt:'编号0是A，之后B、C、D循环。从编号0走到编号12，选择轮内编号。'},'余数0对应第末位改为零基编号的第0位；起点改变','12除以4余0，轮内编号0是A；一基第12项才停第4位，不能混用。',75);

replaceTransfer('G01.04',{mode:'measureLab',kind:'units',rows:2,cols:3,cells:[[0,0],[0,1],[0,2],[1,0],[1,1],[1,2]],unitSize:2,unit:'m',context:'一格边长两米',prompt:'花园图2行3列，每格边长2米。实际描外边、铺内部，再分别填写周长和面积并选单位。'},'每格实际边长由1变2；长度乘2、面积乘4，必须按量纲换算','外边10个单位段，每段2米，周长20米；6个单位方格，每格4平方米，面积24平方米。',76);
replaceTransfer('G03.04',{mode:'compositeLab',kind:'cut',rows:4,cols:4,remove:[[1,3],[2,3]],context:'边缘凹口与内部孔洞',hideDerivedValues:true,prompt:'4行4列纸板，只剪下最右列第2、3行的两格。形成边缘凹口，而不是内部孔洞。把原格移到材料盘，再填写保留面积。'},'内部孔洞改为边缘非角部凹口；保留面积相同但边界条件不同','原16格剪去2格，保留14；最右列切口与外部相通，原内部孔洞不与外部相通，面积相同不能代替位置条件。',76);
replaceTransfer('G04.01',{mode:'circleLab',kind:'center',radius:2,rotation:45,points:[0,90,180,270],origins:{O:[235,180],P:[180,180]},centerName:'P',context:'圆心标签需要重新核对',prompt:'两个候选点叫O和P，字母并不保证谁是圆心。任选起点连到四个圆周点，比较实际线段长度，找出等距的那个。'},'圆心从默认O换为候选P；须依据四条实际等距线段而不是名字','P到四个圆周点均为2厘米；O偏离中心，四段不等。圆心由等距关系确定，不能默认字母O就是答案。',76);
replaceTransfer('G06.03',{mode:'rightLab',kind:'solve',a:6,b:8,c:10,unit:2,unknown:'a',rotation:90,context:'斜边已知，恢复一条直角边',prompt:'已知直角三角形斜边10、另一条直角边8，每原格边长2。先核直角，再从斜边25个原平方格中扣出已知直角边平方，剩余原格拼未知正方形，填写实际未知边。'},'由两直角边求斜边改为斜边及一直角边求另一直角边；相加改相减','未知平方100－64＝36，实际边长是正根6；所有25个原格各4平方单位，在扣去盘和未知平方之间恰出现一次。',76);
replaceTransfer('G06.04',{mode:'rightLab',kind:'axis',A:[-2,3],B:[-6,3],minX:-6,maxX:0,minY:0,maxY:5,context:'负坐标之间向左量',prompt:'A在(−2,3)，B在(−6,3)。标端点，再从A向B实际逐格量，填写非负距离。'},'同列正坐标改为同行负坐标并反向行走；带符号差与距离分开','从−2走到−6向左4格，距离4；坐标差−4不能作为负长度。',76);
for(const [sid,dimension,proof] of [
 ['G01.01','单位段变2厘米且起点非0；绝对刻度与两端距离分开','1到4有3个单位段，每段2厘米，实际长度6厘米。'],
 ['G01.02','矩形外边改含凹边的L形；内接缝排除','L形4个原格的外露单位边10条，内部共用边不计，凹边仍属边界。'],
 ['G01.03','完整矩形改缺一角覆盖；空位不能补算','3×3框中仅8个目标方格，缺角不属于材料，面积8平方厘米。'],
 ['G01.05','同面积异周长改为同周长异面积；逆命题反例','原3×3面积9、周长12；新2×4面积8、周长12，等周长不保证等面积。'],
 ['G02.01','改变角边实际长度而保持转角；角度不由线长决定','缩短或延长从同顶点出发的角边，60度张角仍60度。'],
 ['G02.02','增加四分之一圈，与半圈及整圈的实际扫过路径比较','转动分别90、180、360度，不能只比较转动后的末方向。'],
 ['G02.03','未知角由第三角换到第二角；只使用另外两角条件','180－40－75＝65；角片对应位置随未知改变。'],
 ['G02.04','换锚点并旋转多边形；按有效对角线实际划分','凸六边形从B连接非邻顶点有3条对角线，分4个三角形，内角和720度。'],
 ['G02.05','已知角与未知角交换；读取直角标记和另一已知角','A未知、B40度、C90度，所以A50度；不能把原B未知的模板照搬。'],
 ['G03.01','同一目标采用两套不同原片分割；最终覆盖需一致','横分与竖分分别移动完整原片，两盘都形成同一7格L形，无重叠无遗漏。'],
 ['G03.02','角落方块改为整列条形切除；位置条件改变','原3×5中移出最右列3格，保留12格；等数量其他剪法不满足位置条件。'],
 ['G03.03','增加重排后周长改变的反例；保面积不保周长','同一12原格保面积，外边从14段变18段；原片身份与刚性位移保留。'],
 ['G03.05','单一尺寸枚举改全尺寸枚举；图形个数与格数分开','4×4网格按1/2/3/4边长分别16/9/4/1个，共30，不能只数16单位格。'],
 ['G04.02','已知直径反求半径；未知量与方向改变','直径10厘米由两条反向半径组成，各半径5厘米。'],
 ['G04.03','同一半圆改变测量对象；半圆弧与纸片闭边分别量','半径3：半圈弧3π厘米，半圆纸片整边3π＋6厘米。'],
 ['G04.04','用共同比例两圆比较；半径与面积倍数不同','半径2与4的面积4π与16π，半径2倍、面积4倍。'],
 ['G04.05','连续弧跨过编号起点；环形相邻而非线性编号相邻','八等分从7起连续3段为7、0、1，弧长32×3/8＝12。'],
 ['G04.06','相同数值系数而量纲不同的反例；必须选弧或扇形','半径2的四分之一弧π厘米、扇形π平方厘米；相同系数不表示同一量。'],
 ['G05.01','直角形改非直角形并转向换标签；按对应身份连点边角','旋转后同一顶点、边和角的对应保留，屏幕上下不能作为对应关系。'],
 ['G05.02','同比扩大改两轴不同倍数；相似条件反例','宽3倍、高2倍，对应边比例不一致，因此不相似。'],
 ['G05.03','整数比改分数比并旋转；实际量全部对应外边','宽2高4扩大1.5倍，新宽3高6，周长12到18，比例1.5。'],
 ['G05.04','同比扩大后另有预剪区域；剩余面积不是原相似面积','原4格，放大后16格剪去4格，剩12格是原3倍，不再是单纯2²。'],
 ['G05.05','反求放大比改反求缩小比；比例方向需核对','新边2除原边4得1/2，两方向共同缩小为1/2。'],
 ['G06.01','改变直角顶点与图方向，加入钝角反例','只有给定直角的卡满足勾股前提；旋转不影响直角，120度卡不满足。'],
 ['G06.02','原平方格边长变半厘米；格数与面积分开','9、16、25格各0.25平方厘米，面积2.25＋4＝6.25，边1.5、2、2.5。'],
 ['G06.05','坐标非零起点，构造垂直位移并区分直线与街区路径','(1,1)到(4,5)位移3与4；直线5，格线绕路7。'],
 ['G07.01','十字展开图改另一有效网；折后物理身份去重','不同有效六面网折成同一立方体，仍6面12棱8顶点，不能每面单独重复数棱。'],
 ['G07.02','连接结构改阶梯网；折后朝向改变而面身份不变','六原面各自按折叠方向转到实际位置，正背面切换不产生新身份。'],
 ['G07.03','无环重合反例改含额外连接环的冲突反例','2×3六格带额外连接，折叠约束冲突，不因六格连通就成为立方体网。'],
 ['G07.04','纸网和被问原面同时改变；相对由折后法向认定','相反法向才是相对面，展开平面上的远近或相邻不是判据。'],
 ['G07.05','单个盒体积改双等体积不同形状；外观大小反例','2×2×2与4×2×1都8原单位块，体积相等。'],
 ['G07.06','单表面积改等体积双形；体积与外面积关系反例','同为8单位块，2×2×2外面积24，4×2×1外面积28，内共享面均排除。']
])retainTransfer(sid,dimension,proof);
for(const p of transferStages['G03.01'].transfer.puzzles){p.label=p.label.startsWith('横')?'横向分割':'纵向分割';}
transferStages['G03.01'].transfer.hideDerivedValues=true;

const transferPeople=(r,o,y,n)=>Array.from({length:r+o+y+n},(_,i)=>({id:'P'+(i+1),name:'队员'+(i+1),group:i<r?'R':i<r+o?'O':i<r+o+y?'Y':'N'}));
const cLabels=['体育','艺术'];
const sameName=transferPeople(3,2,1,2);sameName[0].name=sameName[1].name='小安';
replaceTransfer('C01.01',{mode:'setsLab',kind:'identity',people:sameName,labels:cLabels,context:'同名但原身份不同',prompt:'名单上有两个同名“小安”，编号分别P1、P2；同一编号可能出现在两份活动名单。按原编号登记归位，再填不同原人物数，不能按名字合并。'},'两个同名不同编号加共同名单；显示名字不能替代原身份','P1与P2是两个人，同名不合并；同一P4在两个名单出现仍只对应一原人物。',77);
replaceTransfer('C01.02',{mode:'setsLab',kind:'members',people:transferPeople(2,0,1,1),labels:cLabels,queries:['A','R','O'],context:'共同区域可以为空',prompt:'按名册登记归位。分别圈体育整组、只体育、两项都参加；若某集合没有原人物，需明确标空。'},'交集非空改交集为空的边界；完整A和仅A此时可一致','体育整组与只体育均为P1、P2；两项都参加为空，必须主动标空，不能把未作答当空集合。',77);
replaceTransfer('C01.04',{mode:'setsLab',kind:'formula',people:transferPeople(3,2,0,1),labels:cLabels,target:'I',context:'一个活动组完全包含另一个',prompt:'艺术报名者都在体育名单中。登记归位，再用两种不同计数工作盘计至少参加一项的人，每个目标原身份恰计一次。'},'相交但不包含的双集合改B包含于A；空的仅B分区','仅体育3、共同2、仅艺术0，共5；并集就是体育整组，不能另加艺术而不移除重复计数。',77);
replaceTransfer('C01.05',{mode:'setsLab',kind:'dedup',people:transferPeople(2,0,3,1),labels:cLabels,target:'I',context:'两份名册没有共同编号',prompt:'登记归位这两份互不重合的活动名册与未参加者。叠完整A、B名单，再核对是否存在要移去的重复计数，填写至少一项的不同人数。'},'有重复名册改为完全不相交的边界；不能无条件扣共同人数','2名体育、3名艺术，没有共同原身份，至少一项共5；不参加者不加入目标，也没有重复可移。',77);
const cards=names=>names.map(id=>({id,label:id}));
replaceTransfer('C02.02',{mode:'combinLab',kind:'pair',models:[{type:'pair',name:'有禁止搭配的两位编码',first:cards(['A','B','C']),second:cards(['1','2']),forbidden:[['B','2']]}],context:'笛卡尔搭配有一个禁格',prompt:'编码第一位A/B/C，第二位1/2，但B2禁止。实际摆卡列出全部合法有序编码，不能把3×2直接当合法总数。'},'完整双类搭配改有禁止对的限制；分支不再同宽','A有2项、B有1项、C有2项，共5个合法编码；B2不属于样本列表。',77);
replaceTransfer('C02.03',{mode:'combinLab',kind:'complete',models:[{type:'pair',name:'有非法初始记录的票表',first:cards(['成人','儿童']),second:cards(['周一','周二','周三']),forbidden:[['儿童','周二']],seed:[['成人','周一'],['儿童','周二']]}],context:'补漏之前先核记录是否合法',prompt:'票种成人/儿童，日期周一/二/三，儿童周二票不提供。现有票表含一条禁止记录；实际删除非法项，再补齐全部合法票种日期组合。'},'只补空缺改同时删除非法种子记录与补漏；存在禁止分支','成人三日、儿童周一和周三共5；既有儿童周二必须移除，不能只把表补成六行。',77);
replaceTransfer('C02.04',{mode:'combinLab',kind:'dedup',models:[{type:'order',name:'无角色搭档的换序重复',items:cards(['A','B','C']),size:2,ordered:false,repeat:false,seed:[['A','B'],['B','A'],['A','C']]}],context:'记录不同，成员组可能相同',prompt:'从A/B/C选两人作无角色搭档。已有AB、BA、AC记录；换书写顺序不算新组。删除同成员的重复，再补齐全部不同搭档。'},'完全相同文本重复改反向元组的等价重复；去重依据成员集合','AB与BA是同组，保留一次；补BC后共AB、AC、BC三组。',77);
replaceTransfer('C03.03',{mode:'combinLab',kind:'choose',models:[{type:'order',name:'必须带D的两人小队',items:cards(['A','B','C','D']),size:2,ordered:false,repeat:false,include:'D'}],context:'无序选择新增必选成员',prompt:'从A/B/C/D选两人，D必须加入，队内无角色。实际收录全部合法小队，不重复换序。'},'无约束组合改必含指定成员；不能只换n套组合总数','只有AD、BD、CD三组；AB、AC、BC不含D，虽是两人组仍不合法。',77);
replaceTransfer('C04.01',{mode:'setsLab',kind:'universe',people:transferPeople(2,1,4,3),outside:[{id:'V1',name:'访客甲'},{id:'V2',name:'访客乙'}],universeLabel:'本班学生',labels:['科学','戏剧'],queries:['U'],context:'全桌对象与规定全集分开',prompt:'本题全集仅本班10名学生，包括两项都不参加的学生。桌边还有两名访客。登记本班原人物、圈规定全集，填写全集人数。'},'增加可见但不在规定全集内的访客；全桌对象不等于全集','本班10名原人物全部属于全集，含3名未报名者；V1/V2访客不属于本班，不能计入。',77);
replaceTransfer('C04.03',{mode:'setsLab',kind:'intersection',people:transferPeople(2,0,3,1),labels:cLabels,queries:['O','I','exact1'],context:'AND为空而OR非空的边界',prompt:'两份活动名册没有共同编号。登记归位后，分别圈两项都参加、至少一项、恰好一项；没有成员的集合要主动标空。'},'交集非空改两个不相交集合；OR与恰一一致、AND为空','同时参加0人，至少一项和恰好一项都是5人；三个提问不能按同一非空列表回答。',77);
replaceTransfer('C04.04',{mode:'setsLab',kind:'dedup',people:transferPeople(0,3,2,1),labels:cLabels,target:'I',context:'整个A名册在B名册里',prompt:'所有体育成员也参加艺术，另有只艺术和两项都不的人。叠完整A、B名册，再逐原身份移去多算的一次，填写至少一项人数。'},'普通重叠改整个A均重复的包含边界；保留一次原成员','体育3名都是交集，在两个名册各计一次；各移去一次后并集5名，不能删掉这3个原人物。',77);
for(const [sid,dimension,proof] of [
 ['C01.03','三分区并集改四分区全集；两项都不者需归位并计入','R3/O2/Y1/N2四个互斥区覆盖8原人物；并集只有6，全集8。'],
 ['C02.01','交换首选择与第二选择，实际表格分组方向改变','帽先选两类，每类接三种上衣；每条有序方案对应原衣帽配对，列举方向可换而完整性保留。'],
 ['C02.05','单一有禁配流程改两个互斥方案择一；求和而不是逐步乘积','室内4种、室外1种，共5；选择两类之一，不是每种室内再配一种室外。'],
 ['C03.01','明示重复许可及无序不同成员；顺序与重复分别判断','两位密码允许重复有11/12/21/22四种；无序抽两张不同数卡仅{1,2}一组。'],
 ['C03.02','全体排队改部分有序角色选择；没有使用的原卡不等于漏项','四人选前后两位有4×3＝12，不是4!也不是无序6组。'],
 ['C03.04','固定首位改指定二人相邻；需核块内两种顺序','甲乙作为相邻块，两种内部顺序与丙左右位置共4个队列。'],
 ['C03.05','有角色第一位分组改无角色最早成员规范分组','四选二共6不同成员组，AB与BA不另算；按名册最早成员分组以免重收。'],
 ['C04.02','补集目标由不A改不B；原集合范围及所减组改变','不B包括只A和两项都不；先取全集再移完整B，而不是仍移A。'],
 ['C04.05','目标由至少一项改两项都不；直接/间接构造分别核身份','直接计N3名，间接U10减并集7，也3；数值一致还需两盘逐原身份一致。']
])retainTransfer(sid,dimension,proof);

replaceTransfer('D01.01',{mode:'chartLab',kind:'legend',labels:['篮球','足球'],icons:[2,1.5],legend:4,unit:'球',values:[8,6],context:'半个图标也有实际单位',prompt:'一个完整图标代表4球。篮球有2个完整图标；足球有1个完整和半个图标。把每个来源图标拆成对应原单位点再计数，半个不能当一整个。'},'整数个符号改包含半个图标；图例份量按实际占比缩放','完整图标4球、半个2球；篮球8，足球6。半图标只产生2个原单位，不能制造另外2个。',78);
replaceTransfer('D01.02',{mode:'chartLab',kind:'read',orientation:'horizontal',labels:['铅笔','尺子'],values:[15,10],gap:5,unit:'支',ticks:[0,5,10,15,20],context:'数量轴横过来',prompt:'这张条形图横向显示数量，纵向是类别。选择每条末端对应的横轴刻度，填数量并选单位；不要把类别位置当数量。'},'竖直柱高改横向条长；数量轴与类别轴方向交换','每格5支，铅笔条长3格即15，尺子2格即10；数量读横轴。',78);
replaceTransfer('D01.03',{mode:'chartLab',kind:'ticks',labels:['甲'],values:[20],gap:5,unit:'人',ticks:[10,15,20,25,30],context:'量尺从10开始',prompt:'等距量尺底端是10、顶端30，中间有三张缺刻度卡。放入每个缺位置的真实数值，不把底端当0。'},'零起点改非零刻度起点；绝对刻度=起点+格数×步长','四个等间隔每格5，缺刻度依次15、20、25；第1格不是5。',78);
replaceTransfer('D01.04',{mode:'chartLab',kind:'build',labels:['甲班','乙班','丙班'],values:[0,5,15],gap:5,unit:'人',ticks:[0,5,10,15,20],context:'零人数的类别仍保留',prompt:'来源表甲班0、乙班5、丙班15。逐类别搭柱；甲班要主动确认零柱并填写0，类别不能消失。每格5人。'},'全部正数柱改含零柱的边界；没有柱与没有类别分开','三类仍有三个位置；甲班确认0，乙1格5人、丙3格15人。零值不能靠未操作的默认值通过。',78);
replaceTransfer('D01.06',{mode:'chartLab',kind:'interval',points:[[0,6],[2,2],[4,6],[6,2]],threshold:4,relation:'below',timeStep:1,unit:'分钟',valueUnit:'厘米',values:[],context:'由高于改低于阈值',prompt:'两标记点之间是直线。选择水位严格低于4厘米的所有时间小段并累计分钟；高于和恰在阈值处不能混入。'},'高于阈值改严格低于；不连续区间并保留末段','符合1–3和5–6分钟，累计2＋1＝3分钟；不把间隔3–5加入。',78);
replaceTransfer('D02.02',{mode:'statsLab',kind:'mean',values:[1,2,4,3],quantum:0.5,unit:'升',context:'平均量需要半单位',prompt:'四桶分别1、2、4、3升。每原点代表半升，移动全部原量使四桶一样多，再填总量、对象数和平均量。平均数可以不是整数。'},'整数均值改半单位均值；原量粒度改0.5升而人数仍按桶','10升平均分四桶，每桶2.5升；20个半升原点不是20桶。',78);
replaceTransfer('D02.06',{mode:'statsLab',kind:'weighted',rows:[{value:2,frequency:0,label:'未出现的值'},{value:4,frequency:1,label:'第一组'},{value:8,frequency:1,label:'第二组'}],quantum:1,unit:'本',context:'零频数行不增加人数',prompt:'表里2本有0人、4本有1人、8本有1人。实际展开每行原成员和原量，再均分填平均数。零频数行保留，但不是一个人。'},'全部正频数改包含零频数；行数与实际人数分开','实际只有2人，共12本，平均6；不能把三行当3人，也不能给0频数行制造成员。',78);
for(const [sid,dimension,proof] of [
 ['D01.05','柱图读成表改给表搭图；表示转换方向反转','表中6、2、4本按每格2本搭3、1、2格，类别和原数量同时保留。'],
 ['D02.01','包含零原量空盘；数据对象仍存在','0、3、9的总量12在三个盘均分，每盘4；空盘仍计一个对象。'],
 ['D02.03','升序改降序并保留重复值的不同原身份','7、5、2、2降序；两个2编号不同，不能去重。'],
 ['D02.04','偶数个取中间两项均值改奇数个取一项','五个原记录排序1、3、5、7、9，只圈中间原记录5。'],
 ['D02.05','唯一众数改两个并列最高频值','1和3各两次是两个众数，5一次不是众数，极差5－1＝4。'],
 ['D03.01','物理袋样本改明确只有正反两结果的模型；逻辑事件合并','正或反覆盖全部为必然，侧立不在本题两结果模型内为不可能；结论限定模型。'],
 ['D03.02','单次原子身份改两次有序样本树','两次硬币有HH/HT/TH/TT四个原子；HT与TH因阶段不同不合并。'],
 ['D03.03','原物等可能但颜色不等改颜色也等可能的边界','公平硬币正、反各一个等可能原子；红3蓝1袋的标签不等概率不能照搬。'],
 ['D03.04','数字偶数筛选改颜色合并事件；分母仍按原身份','红B1/B2/B3共3有利原子，总4，不是红蓝两个标签取1/2。'],
 ['D03.05','两次同硬币恰一正改不同设备的AND条件','3编号×2硬币共6有序原子，仅F2＋H符合，两条件同时成立概率1/6。'],
 ['D03.06','连续角度权重改离散原物重数；保留底层等可能原子','红3球蓝1球，每球公平，红3/4；两个颜色标签不等可能。'],
 ['S01.01','竖直对称轴改水平轴；固定点与反向坐标互换','水平0轴固定y=0原点，其他原点y取相反数，x和身份保留。'],
 ['S01.02','竖镜改横镜；翻转坐标方向改变','关于y=0反射保x、y变负，不能按原竖镜规则只改x。'],
 ['S01.03','改变旋转中心，并顺时针改逆时针','关于原点逆时针90度使用(x,y)→(−y,x)，不是原中心(1,1)顺时针的公式。'],
 ['S01.04','向右平移改向左且同时向上；带符号向量','每个原点都加向量(−2,2)，边方向、距离、朝向和身份保持。'],
 ['S01.05','两折四层改一折两层；剪痕原层数量改变','一次竖折后剪(3,1)，展开出现(0,1)与(3,1)两原纸格，不凭四层旧图补四孔。'],
 ['S02.01','人物前后限制改数位奇偶与前后同时限制','完整六排列逐条验证首位奇数且1在3之前，不能只满足一个条件。'],
 ['S02.02','奇数红初态改偶数红初态；双翻仍保持原奇偶','初始红2为偶，翻两片红数变化−2/0/2，当前红数仍偶，原片身份不变。'],
 ['S02.03','翻颜色改相邻位置交换；合法性需使用当前原身份邻接','交换C1/C2后顺序已改变，再判断其后的非邻身份；不是固定编号相邻。'],
 ['S02.04','双翻改相邻交换，红色数量也成为不变量','相邻交换只改变顺序，原颜色及红数2保持；原双翻只能保证红数奇偶。'],
 ['S02.05','不变量不同不可达目标改同类可达目标；须实际构造路径','初红C1改到红C2，可双翻C1/C2一步实现；不变量一致本身不作为可达证明。']
])retainTransfer(sid,dimension,proof);

function normaliseFormalPercent(t){
 if(['测','巩固'].includes(t.phase)&&((t.mode==='groupingLab'&&t.kind!=='digits')||t.mode==='cycleLab'))t.contentVersion=75;
 if(['测','巩固'].includes(t.phase)&&(['equationLab','constraintLab'].includes(t.mode)||t.mode==='coordinateLab'&&['machine','dynamic'].includes(t.kind)))t.contentVersion=74;
 if(['测','巩固'].includes(t.phase)&&['ratioLab','rateLab','journeyLab','scaleLab'].includes(t.mode)&&!(t.mode==='ratioLab'&&['order','whole'].includes(t.kind))&&!(t.mode==='scaleLab'&&t.kind==='change'))t.contentVersion=73;
 if(!['测','巩固'].includes(t.phase)||!['percentLab','scaleLab'].includes(t.mode)||!['whole','change'].includes(t.kind))return t;
 t.contentVersion=72;
 if(t.kind==='change'){
  const reverse=t.changeOrder==='removeFirst',upBase=reverse?t.start-t.remove:t.start,downBase=reverse?t.start:t.start+t.add;
  const rate=(n,d)=>Number.isInteger(100*n/d)?`${100*n/d}%`:`当前整体的${n}/${d}`;
  t.prompt=`原量${t.start}，先${reverse?'减少'+rate(t.remove,downBase):'增加'+rate(t.add,upBase)}，再按变化后的整体${reverse?'增加'+rate(t.add,upBase):'减少'+rate(t.remove,downBase)}。先保存最终量预测，再操作验证。`;
 }
 return t;
}
for(const tasks of Object.values(transferStages))for(const t of Object.values(tasks))normaliseFormalPercent(t);
if(typeof module!=='undefined')module.exports={TRANSFER_AUDIT,normaliseFormalPercent};
