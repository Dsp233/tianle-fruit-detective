"""Sync actual authored/validated shared families, preserving frozen/manual fields."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
content = json.loads((ROOT / 'source/joint_families.json').read_text())
families = {f['id']: f for f in content['families']}
validated = {}
for file in (ROOT / 'docs/evidence/2026-10-04-m4-joint').glob('validation*.json'):
    report = json.loads(file.read_text())
    if report.get('result') != 'passed':
        continue
    for result in report.get('coverage', []):
        if result.get('result') == 'passed' and isinstance(result.get('contentVersion'), int):
            validated[(result['id'], result['contentVersion'])] = str(file.relative_to(ROOT))

file = ROOT / 'docs/application-coverage.csv'
with file.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    fields, rows = reader.fieldnames, list(reader)
assert len(rows) == 179 and len({r['primarySkillId'] for r in rows}) == 179
assert len(families) == len({f['primarySkillId'] for f in families.values()})
for row in rows:
    f = families.get(row['familyId'])
    if not f:
        continue
    row['frozenOriginalSupportSkillIds'] = row.get('frozenOriginalSupportSkillIds') or row['supportSkillIds']
    row['supportSkillIds'] = ';'.join(f['supportNodeIds'])
    row['primaryEvidenceAnchor'], row['supportRole'] = f['primaryEvidenceAnchor'], f['supportEvidenceAnchor']
    row['sharedGoalDefinition'] = f['title'] + '：' + f['quantityLabel']
    row['instanceConditions'] = ';'.join(i['kind'] + ':' + i['operator'] +
        (':' + i['pool'] + '/' + i['event'] if i['operator'] == 'raffle' else '') for i in f['instances'])
    row['jointRelationId'] = 'REL-APPLICATION-' + f['id']
    paths = {validated.get((i['id'], i.get('contentVersion', f['contentVersion']))) for i in f['instances']}
    verified = None not in paths
    row['codeEvidencePaths'] = ';'.join(sorted(p for p in paths if p))
    row['status'] = '四实例共同目标/身份/操作及支持条件模拟通过；完整教学/浏览器/iPad待验' if verified else '真实共同题已编写；本版四实例验证待运行；完整教学/设备待验'
    row['nativeReusePolicy'] = '原生模型复用且披露先前查看；新共同目标单独评价，不授新的单点独立成功；相同完整数学签名不靠新ID/版本重计'
    note = ' 支持角色审查：' + f['roleReview']
    if note not in row['notes']:
        row['notes'] += note
with file.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fields, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
print(f'Updated {len(families)}/179 actual shared families; frozen supports and manual evidence preserved.')
