'use strict';
// Only mechanically derived ID/contract columns are updated. Human source,
// browser, device and acceptance evidence is preserved.
const fs=require('fs'),path=require('path'),{boot}=require('./test_support'),{readCsv}=require('./csv');
const b=boot(),data=b.value('SKILL_DATA.skills.map(s=>({id:s.id,practice:practiceFor(s.id).task,stages:STAGED_TASKS[s.id],demo:DEMO_TASKS[s.id],learning:CURRICULUM.lessons[s.id],learningTask:LEARNING_TASKS[s.id],transferAudit:TRANSFER_AUDIT[s.id]||null}))');
const evidencePath=path.join(__dirname,'../docs/evidence/2026-10-03-m3-transfer/validation.json'),evidence=fs.existsSync(evidencePath)?JSON.parse(fs.readFileSync(evidencePath,'utf8')):null;
const validated=new Set(evidence?.version===b.value('window.__AMC8_RELEASE.label')?evidence.transferCases.filter(r=>r.result==='correct').map(r=>r.skillId):[]);
const teachingPath=path.join(__dirname,'../docs/evidence/2026-10-04-m3-teaching/validation.json'),teaching=fs.existsSync(teachingPath)?JSON.parse(fs.readFileSync(teachingPath,'utf8')):null;
const checkedTeaching=new Set(teaching?.version===b.value('window.__AMC8_RELEASE.label')?teaching.coverage.filter(r=>r.result==='passed').map(r=>r.skillId):[]);
function write(file,rows,fields){const quote=x=>/[",\n]/.test(String(x??''))?'"'+String(x??'').replaceAll('"','""')+'"':String(x??'');fs.writeFileSync(file,'\ufeff'+[fields.join(','),...rows.map(r=>fields.map(f=>quote(r[f])).join(','))].join('\n')+'\n')}
const skillPath=path.join(__dirname,'skills.json'),skills=JSON.parse(fs.readFileSync(skillPath,'utf8'));
for(const c of data){const s=skills.skills.find(s=>s.id===c.id),ids=[c.practice.id,...Object.values(c.stages).map(t=>t.id),...(c.demo?[c.demo.id]:[])];s.taskIds=[...new Set([...s.taskIds,...ids])];if(c.demo)s.demonstrationTaskId=c.demo.id;s.explanationTaskId=c.practice.id;
 if(c.learning){if(JSON.stringify(s.prerequisiteIds)!==JSON.stringify(c.learning.prerequisiteIds))s.priorPrerequisiteIds??=[...s.prerequisiteIds];s.prerequisiteIds=[...c.learning.prerequisiteIds];s.learningTaskId=c.learningTask.id;s.learningContentVersion=c.learningTask.contentVersion;s.observableSuccess=s.observableSuccess.filter(text=>!text.includes('在单次对象分类任务中'));if(!s.observableSuccess.includes(c.practice.explain))s.observableSuccess.push(c.practice.explain);s.localDiagnosticScope='对象辨识单题只证明所选对象符合本题条件，与完整操作、口述及掌握证据分开。'}
 s.contentStatus='进行中：概念/条件/反例、真实操作/解释、示范与8阶段已关联；模型结果单独登记；完整教学/图形与设备待验';s.coverageStatus='概念与真实操作/8阶段/不同示范代码覆盖；来源按直接/部分/未直接覆盖；整体教学与设备待验';
}
fs.writeFileSync(skillPath,JSON.stringify(skills,null,2)+'\n');
for(const name of ['unit-skill-matrix.csv','source-map.csv']){
 const file=path.join(__dirname,'../docs',name),parsed=readCsv(fs.readFileSync(file,'utf8')),fields=[...parsed.headers||Object.keys(parsed.rows[0])],rows=parsed.rows;
 if(name==='unit-skill-matrix.csv')for(const f of ['备用实例ID','7天任务ID','21天任务ID','内容代码状态','模拟DOM证据','浏览器证据','iPad真机证据','实质迁移维度','迁移审核状态','实质迁移证据','概念任务ID','概念定义','成立理由','适用条件','反例','先修微技能ID','概念代码状态','概念模拟证据'])if(!fields.includes(f))fields.push(f);
 for(const r of rows){const c=data.find(c=>c.id===r['微技能ID']);if(!c)throw Error('Unmapped skill '+r['微技能ID']);
  if(name==='source-map.csv'){r['网页任务ID']=[...new Set([...r['网页任务ID'].split(';'),c.practice.id,...Object.values(c.stages).map(t=>t.id),...(c.demo?[c.demo.id]:[])])].filter(Boolean).join(';');continue}
  if(c.demo)r['示范任务ID']=c.demo.id;r['操作任务ID']=[...new Set([...r['操作任务ID'].split(';'),c.practice.id])].filter(Boolean).join(';');r['解释任务ID']=c.practice.id;
  r['独立测验ID']=[c.stages.independent.id,c.stages.independent2.id].join(';');r['备用实例ID']=[c.stages.independent3?.id,c.stages.independent4?.id].filter(Boolean).join(';');r['7天任务ID']=c.stages.delayed7?.id||'';r['21天任务ID']=c.stages.delayed21?.id||'';
  r['内容代码状态']=`操作/解释已关联；${c.demo?'示范可重放':'示范待补'}；${c.stages.independent4?'四独立及三回访已写定':'备用及7/21天待补'}；${validated.has(c.id)?'实质迁移通过模型/状态检查':'实质迁移审校进行中'}`;
  if(c.transferAudit){r['实质迁移维度']=c.transferAudit.dimension;r['迁移审核状态']=validated.has(c.id)?'模型/状态已验；浏览器与iPad待验':'代码已审查；本版验证待运行';r['实质迁移证据']=validated.has(c.id)?'docs/evidence/2026-10-03-m3-transfer/validation.json':''}
  if(c.learning){r['先修ID']=c.learning.prerequisiteIds.join(';');r['概念任务ID']=c.learningTask.id;r['概念定义']=c.learning.definition;r['成立理由']=c.learning.why;r['适用条件']=c.learning.use;r['反例']=c.learning.counterexample;r['先修微技能ID']=c.learning.prerequisiteIds.join(';');r['概念代码状态']=checkedTeaching.has(c.id)?'179逐项文本/引用/连接/语音通过模拟DOM；整体教学与设备待验':'概念已写定；本版验证待运行';r['概念模拟证据']=checkedTeaching.has(c.id)?'docs/evidence/2026-10-04-m3-teaching/validation.json':''}
  r['浏览器证据']||='待验';r['iPad真机证据']||='待验';
 }
 write(file,rows,fields);
}
console.log('Updated actual content IDs for 179 rows; preserved source/device/manual acceptance evidence.');
