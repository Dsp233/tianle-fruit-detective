'use strict';
// Capture the actual local candidate's normal handlers. VM output is not a
// browser screenshot or a child outcome. Human judgements live in a separate file.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert');
const {execFileSync}=require('child_process'),{boot}=require('./test_support');
const {COMPETITION_REVIEWED:families}=require('./competition_reviewed');
const catalog=require('./competition_catalog'),{oracle}=require('./test_competition');
const {expansionOracle,reviewedTransferOracle,n}=require('./competition_reviewed_oracles');
const {freshOracle}=require('./competition_fresh_oracles'),{rulesOracle}=require('./competition_rules_oracle');
const identity=require('./competition_identity');
const root=path.resolve(__dirname,'..'),evidence=path.join(root,'docs/evidence/2026-10-08-rc66-product-validation');
const pagePath=path.join(root,'local-preview/index.html'),html=fs.readFileSync(pagePath,'utf8');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex'),clock={now:Date.parse('2026-10-08T00:03:52Z')};
const create=(storage={})=>boot(storage,clock,html);
const initial=create();initial.run('persist()');
const initialStorage={...initial.storage},initialState=JSON.parse(initialStorage[initial.value('STORE')]);
assert.equal(initialState.topicPractice.nextSeed,1);assert.equal(initialState.competition.attempts.length,0);
const scopes=[['Q1',['A02']],['Q2',['R02']],['Q3',['A03']],['Q4',['R01','D02']],['Q5',['R01','G01']],['Q6',['A02','A03','A05','R01','R02','G01','G02','D01','D02','C01']]];
const byId=new Map(families.map(f=>[f.id,f]));
function independentlySolve(t){
 const c=t.competition,f=byId.get(c.recipe.familyId);let p;
 if(f.origin==='reviewed-rc60'){
  const old=catalog.competitionCreate({engine:2,familyId:f.id,seed:c.recipe.seed});oracle(old);
  p={answer:n(old.competition.answer),extension:reviewedTransferOracle(f.id,c.math)};
 }else if(f.origin==='rc65-rules')p={answer:rulesOracle(c.math),extension:rulesOracle(c.extension.math)};
 else p=f.origin==='rc64-structure'?freshOracle(f.id,c.math):expansionOracle(f.id,c.math);
 assert(Number.isFinite(p.answer)&&Number.isFinite(p.extension));
 assert(Math.abs(n(c.answer)-p.answer)<1e-8,t.id+' main answer');
 assert(Math.abs(n(c.extension.answer)-p.extension)<1e-8,t.id+' extension answer');
 const answers=t.options.map(n);assert.equal(new Set(answers).size,5);
 const matches=answers.map((v,i)=>Math.abs(v-p.answer)<1e-8?i:-1).filter(i=>i>=0);
 assert.equal(matches.length,1);assert.equal(matches[0],t.answer);
 return {...p,optionIndex:matches[0],oracle:f.origin==='reviewed-rc60'?'independent legacy enumerator + reviewed transfer solver':f.origin==='rc65-rules'?'independent rules oracle':f.origin==='rc64-structure'?'independent fresh-structure oracle':'independent expansion oracle'};
}
function selected(app,ids){app.click('topicClear');for(const code of ids)app.click('topicSelect',{code});app.click('topicStart');assert.equal(app.value('topicSession().total'),10)}
const rounds=[];
fs.mkdirSync(evidence,{recursive:true});
fs.writeFileSync(path.join(evidence,'initial-storage.json'),JSON.stringify(initialStorage,null,2)+'\n');
// Keep the fixture identical across scopes. Answers advance the normal picker;
// help/variation review happens in snapshots after the complete main trajectory.
for(const [id,ids] of scopes){
 const app=create(initialStorage);selected(app,ids);const rows=[],keys=new Set();
 for(let i=0;i<10;i++){
  const task=app.value('taskNow()'),c=task.competition,key=identity.key(task);
  assert(c.topicIds.every(x=>ids.includes(x)),id+' scope');
  assert((c.extension.topicIds||c.topicIds).every(x=>ids.includes(x)),id+' extension scope');
  assert(!keys.has(key));keys.add(key);
  const expected=independentlySolve(task),state=JSON.parse(app.storage[app.value('STORE')]);
  assert(!app.root.innerHTML.includes('competition-solutions'));
  const row={id:id+'-'+String(i+1).padStart(2,'0'),order:i+1,task,mathematicalKey:key,expected,initialHtml:app.root.innerHTML,
   adaptiveBefore:app.value('competitionAdaptiveProfile(saved.competition.attempts,saved.competition.extensions,topicSession().topicIds,saved.competition.extensionViews,saved.competition.views)'),
   preAnswerStorage:{...app.storage},preAnswerSession:app.value('topicSession()')};
  app.click('competitionPick',{index:String(expected.optionIndex)});app.click('check');
  assert.equal(app.value('feedback.ok'),true);assert.equal(app.value('topicCurrent().passed'),true);
  row.afterAnswerHtml=app.root.innerHTML;row.afterAnswerStorage={...app.storage};
  row.attempt=app.value('saved.competition.attempts.at(-1)');
  assert.equal(row.attempt.hinted,false);assert.equal(row.attempt.priorSolutionViewed,false);
  rows.push(row);app.click('next');clock.now+=1000;
 }
 assert.equal(app.value('view'),'topicSummary');
 const variations=[],seen=new Set();
 for(const row of rows){
  if(variations.length===2)break;
  if(seen.has(row.mathematicalKey)||!row.task.competition.extension)continue;
  seen.add(row.mathematicalKey);
  const hintCopy=create(row.preAnswerStorage);hintCopy.click('topicResume');
  assert.equal(hintCopy.value('taskNow().id'),row.task.id);assert.equal(hintCopy.value('topicCurrent().passed'),false);
  hintCopy.click('competitionHint');assert.equal(hintCopy.value('draft.work.hintLevel'),1);const firstHint=hintCopy.root.innerHTML;
  hintCopy.click('competitionHintMore');assert.equal(hintCopy.value('draft.work.hintLevel'),Math.min(2,row.task.competition.hints.length));const secondHint=hintCopy.root.innerHTML;
  assert(firstHint.includes('competition-hint'));assert(secondHint.includes('competition-hint'));
  const copy=create(row.afterAnswerStorage);copy.click('topicResume');
  if(copy.value('taskNow().id')!==row.task.id)copy.click('topicPrevious');
  assert.equal(copy.value('taskNow().id'),row.task.id);
  copy.inputCompetition('extension',row.task.competition.extension.answer);copy.click('competitionExtensionCheck');
  assert.equal(copy.value('draft.work.extensionResult.ok'),true);
  variations.push({sourceId:row.id,mathematicalKey:identity.key(row.task,'extension'),extension:row.task.competition.extension,
   expected:row.expected.extension,firstHintHtml:firstHint,secondHintHtml:secondHint,checkedHtml:copy.root.innerHTML,
   extensionRecord:copy.value('saved.competition.extensions.at(-1)')});
 }
 rounds.push({id,selected:ids,initialStorageSha256:sha(JSON.stringify(initialStorage)),rows,variations,
  finalState:app.value('saved'),summaryHtml:app.root.innerHTML});
}
const report={release:require('./version.json'),productBaseline:'3c7a8ce',sourceCommitAtCapture:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),
 environment:'Node VM; actual isolated local HTML and handlers; simulated DOM and speech only',story:'topic selection -> reviewed local generation -> independent solution -> real bundled answer handler -> persistent first facts -> normal next picker',
 pagePath,pageSha256:sha(html),plan:'rc66-product-validation-plan.md',initialStorageSha256:sha(JSON.stringify(initialStorage)),
 initialNextSeed:1,clockStartedAt:'2026-10-08T00:03:52Z',trajectory:'fresh isolated state for each scope; 10 clean correct main submissions; no main-path hints, solutions, or variations before sampling finishes',
 variationSampling:'first two different mathematical identities in each captured round; reviewed only in copied snapshots',
 programCapture:'passed',mainQuestions:rounds.reduce((a,r)=>a+r.rows.length,0),sampledVariations:rounds.reduce((a,r)=>a+r.variations.length,0),
 contentReview:'pending independent reading of captured prompts; family/strategy labels are not verdicts',browser:'pending',ipad:'pending',childObservation:'pending',rounds};
fs.writeFileSync(path.join(evidence,'normal-rounds.json'),JSON.stringify(report,null,2)+'\n');
const lines=['# RC66 正常入口原始题序','',`候选页面SHA256：${report.pageSha256}。VM采集，不是实际浏览器截图。`,''];
for(const round of rounds){
 lines.push('## '+round.id+' · '+round.selected.join('＋'),'');
 for(const row of round.rows){const t=row.task,c=t.competition;
  lines.push('### '+row.id+' · '+c.title,'',`配方：${JSON.stringify(c.recipe)}；实际主题：${c.topicIds.join('＋')}；层级：${c.level}。`,'',t.prompt,'',
   '选项：'+t.options.join(' / '),`答案：${c.answer}；独立求解：${row.expected.answer}。`,'',
   '初始图：'+JSON.stringify(c.diagram),'','提示：'+c.hints.join(' | '),'',
   ...c.methods.map(m=>m.name+'：'+m.steps.join('；')),'',
   '变式：'+c.extension.prompt,`变式答案：${c.extension.answer}；独立求解：${row.expected.extension}。`,c.extension.solution,'');
 }
 lines.push('抽取变式：'+round.variations.map(v=>v.sourceId).join('、'),'');
}
fs.writeFileSync(path.join(evidence,'normal-rounds-readable.md'),lines.join('\n')+'\n');
console.log(JSON.stringify({result:'capture-passed/content-review-pending',mainQuestions:report.mainQuestions,variations:report.sampledVariations,pageSha256:report.pageSha256,rounds:rounds.map(r=>({id:r.id,families:r.rows.map(x=>x.task.competition.family),levels:r.rows.map(x=>x.task.competition.level)}))},null,2));
