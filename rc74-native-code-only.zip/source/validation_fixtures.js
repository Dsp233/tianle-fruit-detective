'use strict';
// Authored AFTER interface-freeze-v2. Four engineering hold-outs, QA only.
const ValidationFixtures=(()=>{
 const gcd=(a,b)=>b?gcd(b,a%b):a,F=(a,b=1)=>{const g=gcd(Math.abs(a),Math.abs(b));return b/g===1?String(a/g):a/g+'/'+b/g},add=(a,b)=>{const [n,d=1]=a.split('/').map(Number),[p,q=1]=b.split('/').map(Number);return F(n*q+p*d,d*q)},multiply=(a,b)=>{const [n,d=1]=a.split('/').map(Number),[p,q=1]=b.split('/').map(Number);return F(n*p,d*q)};
 const N=(id,prompt,answer,prerequisiteIds,hints,errorCheck,unit='')=>({id,prompt,answer:String(answer),prerequisiteIds,hints,errorCheck,unit,rule:{kind:'authored-quantity-relation',statement:prompt}});
 const R=(id,name,nodes,requiredSkills)=>({id,name,nodes,requiredSkills});
 const quantities=(rows,caption)=>({kind:'scene-quantities',quantities:rows.map(([label,value,unit])=>({label,value:String(value),unit})),caption});
 function urn(red,blue,replaceBlue){
  const total=red+blue,p=F(red,total),q=F(blue,total),nextR=F(red-1,total-1),nextB=F(red,replaceBlue?total:total-1),a=multiply(p,nextR),b=multiply(q,nextB),answer=add(a,b);
  const nodes=[N('total','第一次抽取前共有几个球？',total,[],['只数最初的球，先确认全体范围。','红球与蓝球不重叠，把这两部分合起来。'],'你数的是首次抽取前，还是抽取后的球？','个'),N('first-red','第一次抽到红球的概率是多少？',p,['total'],['第一次抽取时，每个球的机会相同。','把红球数量与首次抽取的全体数量比较。'],'分子与分母对应同一次抽取吗？'),N('second-if-red','第一次抽到红球并移走后，第二次红球概率是多少？',nextR,['total'],['跟踪移走的颜色，分别检查红球数与总球数。','红球和全体都少一个；不要把蓝球也减去。'],'移走一颗红球后，红球和全体各怎样变化？'),N('red-branch','先红后红这一条分支的概率是多少？',a,['first-red','second-if-red'],['这条分支同时要求两个事件发生。','使用“首次红”的机会，再结合“首次红之后”的机会。'],'第二次的概率有使用首次红之后的条件吗？'),N('first-blue','第一次抽到蓝球的概率是多少？',q,['total'],['第一次红和蓝是互斥且完整的两个分支。','使用首次抽取前的蓝球数量与全体。'],'此处仍是第一次抽取，不使用改变后的全体。'),N('second-if-blue','首次蓝球'+(replaceBlue?'放回':'移走')+'后，第二次红球概率是多少？',nextB,['total'],[replaceBlue?'放回后袋里的球发生变化了吗？':'移走的是蓝球，红球数会减少吗？','检查这一条分支的红球数和总球数。'],'不要把首次红球分支的操作套到蓝球分支。'),N('blue-branch','先蓝后红这一条分支的概率是多少？',b,['first-blue','second-if-blue'],['使用首次蓝的机会以及这个条件下第二次红的机会。','先保持分支独立，最后才合并。'],'同一分支中的前后两次条件是否匹配？'),N('target','第二次红球可能来自这两个互斥分支，合计概率是多少？',answer,['red-branch','blue-branch'],['第二次红，首次可能是红也可能是蓝。','两条首次颜色分支互斥，可以把已得机会相加。'],'是否漏掉了首次蓝球但第二次红球的分支？')];
  return {parameters:{red,blue,firstRed:'remove',firstBlue:replaceBlue?'replace':'remove'},goal:'第二次抽到红球的概率',unit:'',domain:'probability',answer,prompt:'袋中有'+red+'个红球、'+blue+'个蓝球，每次随机抽一球。第一次抽到红球就移走，抽到蓝球就'+(replaceBlue?'放回':'移走')+'，再抽第二次。第二次抽到红球的概率是多少？请用精确值。',conditions:[{id:'initial-counts',red,blue},{id:'first-operation',red:'remove',blue:replaceBlue?'replace':'remove'},{id:'sampling',rule:'uniform-ball'}],diagram:quantities([['首次红球',red,'个'],['首次蓝球',blue,'个'],['首次红球处理','移走',''],['首次蓝球处理',replaceBlue?'放回':'移走','']],'每个球等可能；按第一次抽到的颜色执行对应操作'),routes:[R('color-branches','按第一次颜色分支',nodes,['D03.05','D03.06','C02.05','A03.02','A03.04','A02.01'])]};
 }
 function laps(lap,rest,n,finalRest){
  const two=2*lap+rest,three=3*lap+2*rest,delta=three-two,answer=n*lap+(n-1+Number(finalRest))*rest,rests=n-1+Number(finalRest);
  return {parameters:{twoLapTime:two,threeLapTime:three,targetLaps:n,finalRest},goal:finalRest?'末圈休息结束的时间':'完成末圈的时间',unit:'分钟',domain:'elapsed-time',answer:String(answer),prompt:'小明每圈用时相同，每跑完一圈就休息相同时间，最后完成时停止计时。完成2圈用了'+two+'分钟，完成3圈用了'+three+'分钟。跑'+n+'圈'+(finalRest?'并完成最后一次休息':'，完成最后一圈就结束')+'共需要多少分钟？',conditions:[{id:'uniform-laps',rule:'constant-run-time'},{id:'uniform-rest',rule:'constant-rest-time'},{id:'observations',two,three},{id:'finish',finalRest}],diagram:quantities([['完成2圈（含1次休息）',two,'分钟'],['完成3圈（含2次休息）',three,'分钟'],['目标圈数',n,'圈'],['结束时刻',finalRest?'最后休息结束':'最后一圈完成','']],'区分每圈用时与休息用时，结束时刻决定休息次数'),routes:[R('subtract-observations','比较两次计时',[
   N('one-plus-rest','两次计时之差包括一圈和一次休息，共多少分钟？',delta,[],['比较完成3圈与完成2圈之间增加了什么。','第三圈开始前还有一次休息，不只是跑步时间。'],'计时之差有包含新增加的那次休息吗？','分钟'),
   N('two-double','把完成2圈的用时加倍，得到多少分钟？',2*two,[],['先只组合这个已知量。','两份“2圈加1次休息”包含4圈和2次休息。'],'加倍的是整个计时，休息也在里面。','分钟'),
   N('lap-time','两份2圈计时与3圈计时相比，剩下的一圈用时是多少？',lap,['two-double'],['两次休息正好抵消，剩下的圈数是多少？','用同样的休息数量比较，不把剩余量当成一圈加休息。'],'比较两边的跑步圈数和休息次数，哪些相同？','分钟'),
   N('rest-time','一圈加休息的用时扣掉跑一圈，休息多久？',rest,['one-plus-rest','lap-time'],['这是两个不同用时，先用已得的一圈时间。','计时差中有一圈与一次休息。'],'求得的一圈时间与休息时间有混淆吗？','分钟'),
   N('rest-count','目标结束之前实际经历了几次休息？',rests,[],['看清完成末圈后是否还计入休息。','可以画圈与圈之间的空隙，再单独检查最后一次。'],'你的结束时刻与题目指定的时刻相同吗？','次'),
   N('target','合并目标圈数的跑步时间与实际休息时间。',answer,['lap-time','rest-time','rest-count'],['跑步和休息分别累计，再合并。','使用题目指定的圈数和已经确认的休息次数。'],'是否把最后一圈之后的休息计错了？','分钟')],['A02.01','A02.03','A02.04','L01.01'])]};
 }
 function area(a,minGap){
  const area=a*(a+3),pairs=[];for(let w=2;w<=area;w++)if(area%w===0&&w<=area/w&&area/w-w>=minGap)pairs.push([w,area/w]);const answer=Math.min(...pairs.map(([w,l])=>2*(w+l)));
  const nodes=[N('candidate-count','短边至少2且不大于长边，合法因数配对有几组？',pairs.length,[],['长宽的乘积固定，先列因数配对。','检查两边的最小值，以及题目是否限制边长之差。'],'是否把同一对交换次序算了两次，或保留了不合法的边长？','组'),...pairs.map(([w,l])=>N('perimeter-'+w,'短边取'+w+'时，长方形的周长是多少？',2*(w+l),['candidate-count'],['先从面积与短边确定另一边。','周长包括两条短边和两条长边。'],'你算的是面积、长宽和，还是四条边的总长？','长度单位')),N('target','比较所有合法配对，最小周长是多少？',answer,pairs.map(([w])=>'perimeter-'+w),['面积固定时，接近的整数因数通常值得比较。','必须使用真正的因数配对，同时满足所有限制。'],'选出的长宽都是整数、乘积正确并满足附加限制吗？','长度单位')];
  return {parameters:{area,minSide:2,minGap,integerSides:true},goal:'最小周长',unit:'长度单位',domain:'rectangle-integer-sides',answer:String(answer),prompt:'一块长方形的面积为'+area+'，两条边都是不小于2的整数'+(minGap?'，长边至少比短边长'+minGap:'')+'。它的最小周长是多少？',conditions:[{id:'area',value:area},{id:'integer-domain',min:2},{id:'difference',minGap}],diagram:{kind:'rectangle',labels:['长 ?','宽 ?','面积 '+area+'；整数边≥2'+(minGap?'；边长之差≥'+minGap:'')]},routes:[R('factor-pairs','列完整的合法因数配对',nodes,['N02.01','G03.01','G01.01','A02.05'])]};
 }
 function tanks(s,internal){
  const unit=7*s,a=14*s,b=21*s,firstAfter=internal?15*s:18*s,secondAfter=internal?20*s:24*s,answer=internal?firstAfter:a+b,knownA=internal?s:4*s,knownB=internal?-s:3*s;
  const params=internal?{beforeRatio:[2,3],afterRatio:[3,4],transferred:s,direction:'B-to-A',goal:'first-after'}:{beforeRatio:[2,3],afterRatio:[3,4],firstAdded:4*s,secondAdded:3*s,goal:'total-before'};
  return {parameters:params,goal:internal?'操作后甲箱水量':'操作前总水量',unit:'升',domain:'tank-volumes',answer:String(answer),prompt:'甲乙两箱原来的水量比为2:3。'+(internal?'从乙箱移'+s+'升水到甲箱':'往甲箱另加'+4*s+'升，往乙箱另加'+3*s+'升')+'后，甲乙水量比变为3:4。'+(internal?'操作后甲箱有多少升水？':'操作前两箱合计有多少升水？'),conditions:[{id:'before-ratio',values:[2,3]},{id:'operation',...params},{id:'after-ratio',values:[3,4]}],diagram:quantities([['操作前甲乙份数比','2 : 3',''],['甲箱变化',knownA,'升'],['乙箱变化',knownB,'升'],['操作后甲乙份数比','3 : 4','']],'前后比例对应不同的水量；外部加水与内部转移分别处理'),routes:[R('scaled-balance','让变化后比例的两边可比较',[
   N('first-multiplier','变化后甲乙为3:4，甲箱水量乘几才可与乙箱乘3比较？',4,[],['先确认变化后的比例对应哪个状态。','为了比较两边，使用比例的另一项作倍数。'],'你用的是变化前比例还是变化后比例？'),
   N('known-first','甲箱外部变化乘4，是多少升？',4*knownA,['first-multiplier'],['乘的是甲箱变化量，不是操作前全部水量。','内部转移时，另一箱的变化方向与甲相反。'],'改变的数量与改变方向是否都保留了？','升'),
   N('known-second','乙箱变化乘3，是多少升？',3*knownB,[],['外部加水为增加，移出为减少。','先保留变化量的正负方向，再应用3倍。'],'乙箱是加水还是被移走水？','升'),
   N('original-unit','操作前共同的一份是多少升？',unit,['known-first','known-second'],['比较甲的2份乘4与乙的3份乘3，相差几份？','把两边的已知变化量平衡，留下原来的一份。'],'原来的一份与后来比例的一份是同一个量吗？','升'),
   N('original-first','操作前甲箱水量是多少？',a,['original-unit'],['回到操作前的2:3份数。','甲对应原来同一大小的2份。'],'不要把变化后3份直接当成原来3份。','升'),
   N('original-second','操作前乙箱水量是多少？',b,['original-unit'],['乙在操作前对应3份。','核对原来的一份单位为升。'],'使用的比例是操作前的2:3吗？','升'),
   N('target',internal?'把转入的水合到原甲箱，操作后甲有多少？':'回到所求的操作前总量，合计多少？',answer,internal?['original-first']:['original-first','original-second'],['确认最后问的是哪个状态、哪个对象。','已确认的量中，哪些需要合并或调整？'],'数值代表操作前合计还是操作后某一箱？','升'),
   N('verify','代回操作后的条件，甲乙水量的合计是多少？',firstAfter+secondAfter,['target'],['把两箱分别应用变化操作，再核对3:4。','同时检查原来2:3与后来3:4，不能只符合一个比例。'],'操作后的两箱是否同时符合所有条件？','升')
  ],['R01.02','R01.03','R01.04','R01.05','L01.03','A02.04','A02.03','A02.05'])]};
 }
 return [
  {id:'validation-conditional-redraw',title:'首次颜色改变抽球规则',topicIds:['D03','C02','A03','A02'],build(seed){const r=3+seed%4,b=2+Math.floor(seed/4)%4;return {main:urn(r,b,true),variation:urn(r,b,false),insight:'分支操作改变各自样本空间',transform:{category:'conditional-operation',changed:['首次蓝球由放回改为移走'],preserved:['最初球数','首次红球移走','第二次红球目标']}}}},
  {id:'validation-lap-rest',title:'计时中隐藏的跑圈与休息',topicIds:['A02','L01'],build(seed){const t=4+seed%6,r=1+Math.floor(seed/6)%4,n=4+Math.floor(seed/24)%4;return {main:laps(t,r,n,false),variation:laps(t,r,n,true),insight:'对齐休息次数，再区分结束边界',transform:{category:'finish-boundary',changed:['末圈休息计入结束'],preserved:['每圈时间','每次休息时间','圈数']}}}},
  {id:'validation-integer-area',title:'固定面积下的整数边界',topicIds:['N02','G03','G01','A02'],build(seed){const a=3+2*(seed%4);return {main:area(a,0),variation:area(a,5),insight:'先找合法因数，再比较接近程度',transform:{category:'feasible-domain',changed:['长短边之差至少5'],preserved:['面积','整数边至少2','最小周长目标']}}}},
  {id:'validation-ratio-adjustment',title:'前后比例与水量变化',topicIds:['R01','A02'],build(seed){const s=1+seed%8;return {main:tanks(s,false),variation:tanks(s,true),insight:'同一组旧份数连接两种状态，区分加水和转移',transform:{category:'operation-and-goal',changed:['外部加水改为内部转移','原总量改为变化后甲箱'],preserved:['原甲乙2:3','后甲乙3:4','升的单位']}}}}
 ];
})();
if(typeof module!=='undefined')module.exports=ValidationFixtures;else window.__AMC8_VALIDATION_FACTORIES=ValidationFixtures;
