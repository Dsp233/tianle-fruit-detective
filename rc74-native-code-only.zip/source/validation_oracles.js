'use strict';
// Separate enumeration/constraint algorithms. Never read published answers.
const rational=(n,d=1)=>{const gcd=(a,b)=>b?gcd(b,a%b):a,g=gcd(Math.abs(n),Math.abs(d));return d/g===1?String(n/g):n/g+'/'+d/g};
const add=(a,b)=>{const [n,d=1]=a.split('/').map(Number),[p,q=1]=b.split('/').map(Number);return rational(n*q+p*d,d*q)};
function oracle(task,variation=false){
 const c=task.competition,p=variation?c.extension.problemState.math:c.problemState.math,id=c.recipe.familyId,nodes={};let answer;
 if(id==='validation-conditional-redraw'){
  const balls=Array.from({length:p.red+p.blue},(_,i)=>i<p.red?'red':'blue'),T=balls.length;let red='0',blue='0';
  balls.forEach((color,i)=>{const next=balls.filter((_,j)=>j!==i||color==='blue'&&p.firstBlue==='replace');next.forEach(second=>{if(second==='red'){const weight=rational(1,T*next.length);if(color==='red')red=add(red,weight);else blue=add(blue,weight)}})});
  answer=add(red,blue);Object.assign(nodes,{total:T,'first-red':rational(p.red,T),'second-if-red':rational(p.red-1,T-1),'red-branch':red,'first-blue':rational(p.blue,T),'second-if-blue':rational(p.red,p.firstBlue==='replace'?T:T-1),'blue-branch':blue,target:answer});
 }else if(id==='validation-lap-rest'){
  const solutions=[];for(let t=1;t<=p.threeLapTime;t++)for(let r=1;r<=p.threeLapTime;r++)if(2*t+r===p.twoLapTime&&3*t+2*r===p.threeLapTime)solutions.push({t,r});if(solutions.length!==1)throw Error('Nonunique observed lap/rest pair');const {t,r}=solutions[0];let time=0,rests=0;for(let lap=0;lap<p.targetLaps;lap++){time+=t;if(lap<p.targetLaps-1||p.finalRest){time+=r;rests++}}answer=String(time);Object.assign(nodes,{'one-plus-rest':p.threeLapTime-p.twoLapTime,'two-double':2*p.twoLapTime,'lap-time':t,'rest-time':r,'rest-count':rests,target:time});
 }else if(id==='validation-integer-area'){
  const pairs=[];for(let w=p.minSide;w<=p.area;w++)for(let l=w;l<=p.area;l++)if(w*l===p.area&&l-w>=p.minGap)pairs.push([w,l]);if(!pairs.length)throw Error('Empty integer geometry domain');answer=String(Math.min(...pairs.map(([w,l])=>2*(w+l))));nodes['candidate-count']=pairs.length;for(const [w,l]of pairs)nodes['perimeter-'+w]=2*(w+l);nodes.target=answer;
 }else if(id==='validation-ratio-adjustment'){
  const solutions=[];for(let a=1;a<=1000;a++){const b=3*a/2;if(!Number.isInteger(b))continue;const nextA=a+(p.transferred||p.firstAdded),nextB=b+(p.transferred?-p.transferred:p.secondAdded);if(nextB>0&&4*nextA===3*nextB)solutions.push({a,b,nextA,nextB})}if(solutions.length!==1)throw Error('Nonunique volume conditions');const q=solutions[0],da=p.transferred||p.firstAdded,db=p.transferred?-p.transferred:p.secondAdded;answer=String(p.goal==='total-before'?q.a+q.b:q.nextA);Object.assign(nodes,{'first-multiplier':4,'known-first':4*da,'known-second':3*db,'original-unit':q.a/2,'original-first':q.a,'original-second':q.b,target:answer,verify:q.nextA+q.nextB});
 }else throw Error('Unknown validation oracle '+id);
 return {answer:String(answer),nodes};
}
module.exports={oracle};
