'use strict';
// Authored manipulatives for early arithmetic. Each operation has an explicit
// mathematical state and inverse action. Completion is limited to this instance.
const WORKSHOP_TASKS={
 'A01.01':{id:'O-A01-01-1',skillId:'A01.01',contentVersion:7,mode:'counterBuild',phase:'练',prompt:'图卡上有4颗星。逐颗摆出一样多的圆点，再核对两组是否一一对应。',target:4,explain:'每摆一颗就对应图卡上的一颗；4对4，没有多也没有少。',hint:'一边数图卡，一边在右侧逐颗摆。'},
 'A01.04':{id:'O-A01-04-1',skillId:'A01.04',contentVersion:7,mode:'compareBuild',phase:'练',prompt:'左盘是3十6一，右盘也是3十6一。按“添一个一”使右盘成为37，再比较36和37。',initial:[36,36],target:[36,37],explain:'十位同为3，右盘添一个一后，7个一比6个一多，所以37大。',hint:'十棒相同，先在右盘添一颗圆点，再比较个位。'},
 'A01.05':{id:'O-A01-05-1',skillId:'A01.05',contentVersion:7,mode:'reverseExchange',phase:'练',prompt:'从2根十棒和3个散点出发。拆开一根十棒，摆成1根十棒和13个散点，并判断总数。',explain:'拆开一根十棒得到十个散点，2十3一与1十13一都表示23。',hint:'拆的是一根十棒，原来的3个一仍留在盘里。'},
 'A02.01':{id:'O-A02-01-1',skillId:'A02.01',contentVersion:7,mode:'counterRemove',phase:'练',prompt:'盘里有7颗。逐颗拿走3颗，把拿走的放到旁边，并观察盘里剩多少。',initial:7,remove:3,explain:'从7颗中拿走3颗，盘里留下4颗；点旁边的圆点可以放回去。',hint:'一次拿走一颗，共拿走三颗。'},
 'A02.03':{id:'O-A02-03-1',skillId:'A02.03',contentVersion:7,mode:'inverseMove',phase:'练',prompt:'原来7颗，先逐颗添3颗到10，再从10颗中逐颗拿走3颗。观察是否回到7颗。',initial:7,delta:3,explain:'加上3后再拿走同样的3颗，数量回到7；10－3＝7。',hint:'先添满3颗才可以反向拿走，顺序不可颠倒。'},
 'A02.04':{id:'O-A02-04-1',skillId:'A02.04',contentVersion:7,mode:'equalGroups',phase:'练',prompt:'12颗圆点摆成3盘，每盘恰好4颗。逐颗放盘里；每个盘就是一组4。',groups:3,each:4,explain:'三个互不重叠的4颗合成12颗，即4＋4＋4＝3×4＝12。',hint:'先摆满一盘4颗，再依次摆第二盘、第三盘。'},
 'A02.05':{id:'O-A02-05-1',skillId:'A02.05',contentVersion:7,mode:'equalGroups',phase:'练',prompt:'12颗点平均分到3个盘。每放一颗就从待分区少一颗，直到三盘一样多。',groups:3,each:4,explain:'把12颗平均分成3份，三盘各4颗，即12÷3＝4。',hint:'每盘先放一颗，再继续轮流放，看看是否一样多。'},
 'A02.06':{id:'O-A02-06-1',skillId:'A02.06',contentVersion:7,mode:'orderGroups',phase:'练',prompt:'摆出(3＋2)×2：第一组先有3颗，再添2颗；复制完整的第一组作为第二组。',initial:3,add:2,explain:'先算括号中的3＋2＝5，再把整组5颗复制一次，共10颗；3＋2×2只有7。',hint:'先把第一组添到5颗，再复制整组。'}
};
const WORKSHOP_REASONS={
 'A01.01':['为什么摆4颗？',['图卡有4颗，每颗恰好配到一颗','圆点看起来比星星大，所以数量更多','颜色一样就必定相等'],0],
 'A01.04':['为什么右盘37更大？',['十位同为3，右盘个位7比左盘6大','右盘只因摆在右边就较大','36有6个十，所以更大'],0],
 'A01.05':['拆开后为什么仍是23？',['一根十棒换成十个一，没有添减数量','十棒少一根，总数必少10','散点变多，数量必增10'],0],
 'A02.01':['7拿走3后为什么剩4？',['原来7颗中有3颗转到旁边，盘里还留4颗','旁边添了3颗，所以原盘变10颗','只看被拿走的3颗，原盘剩3颗'],0],
 'A02.03':['为什么又回到7？',['添3后拿走同样的3，两个动作互相抵消','10比7大，所以不可能回来','每次拿走都应减7'],0],
 'A02.04':['这些盘怎样说明3×4？',['三盘各4颗，三份相同量合成12','盘数3与每盘4合起来只有7','只要总数是12，三盘如何分都表示3×4'],0],
 'A02.05':['为什么每盘4颗？',['12颗都分完，三盘相同，每盘4颗','把12颗分成任意三盘也算平均','把12减3，得到每盘9颗'],0],
 'A02.06':['为什么两组共10？',['先把3＋2摆成5，再复制完整的5颗','先复制2颗再加3，共7颗','括号可以省略且结果不会变'],0],
};
for(const [sid,[prompt,options,answer]] of Object.entries(WORKSHOP_REASONS))WORKSHOP_TASKS[sid].reason={prompt,options,answer};
if(typeof module!=='undefined')module.exports={WORKSHOP_TASKS};
