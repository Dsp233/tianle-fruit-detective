// NON-GATING diagnostic copy: exact R5 test with four selected cases.
'use strict';
// Actual native Chrome events. Mathematical answers are independently checked
// by verify_exam_mapping.py; this file verifies the UI and record contract.
const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert/strict'),cp=require('child_process'),{chromium}=require('playwright');
const M=require('./exam_mapping'),Skills=require('./skills.json'),release=require('./version.json');
const root=process.env.AMC8_RC70_CANDIDATE||path.resolve(__dirname,'..'),out=process.env.AMC8_RC70_EVIDENCE||path.join(root,'tmp/rtm1/browser');
const shard=Number(process.env.AMC8_RC70_SHARD||0),shards=Number(process.env.AMC8_RC70_SHARDS||4),rows=[];
const profile={declaredSkillIds:Skills.skills.map(s=>s.id),sourceIds:['AMC8'],examIds:[]};
const training=Object.values(M.data.tasks).filter(t=>M.taskAllowed(t,profile).eligible);
const Review=require('./child_review_status');
const reviewedTraining=training.filter(t=>Review.review(M.getProblem(t.originProblemGroupId)).eligible);
const cases=[...Object.values(M.data.problems).filter(p=>M.check(p,profile).eligible).map(p=>({id:p.examId,kind:'exam',examId:p.examId,definition:{answerContract:p.answerContract,options:p.presentation?.options||[]},seed:1})),...training.map((t,i)=>({id:t.taskId,kind:'training',definition:t,seed:i+1})),...require('./rtm_case_manifest.json').scenarioIds.map(id=>({id,kind:'scenario',examId:id.startsWith('CONNECTED-')?(id==='CONNECTED-presentation-blocked'?'AMC8-2023-09':'AMC8-2000-01'):id.startsWith('PATHWAY-')?null:id==='POLICY-negative'?'AMC8-2000-07':id==='HOLDOUT-help-conversion'||id==='DIAGNOSTIC-return-to-first-attempt'?'AMC8-2000-01':'AMC8-2000-23',seed:1}))];
// Preserve every registered case. Restricted child forms are negative cases;
// positive training seeds follow the actual reviewed supply, not the raw ledger.
for(const c of cases)if(c.kind!=='scenario'){
 const origin=c.kind==='exam'?c.examId:c.definition.originProblemGroupId;
 c.childRestricted=!Review.review(M.getProblem(origin)).eligible;
 if(c.kind==='training')c.seed=Math.max(1,reviewedTraining.findIndex(t=>t.taskId===c.id)+1);
 if(c.childRestricted)c.examId=origin;
}
async function parentConsole(page){const details=page.locator('.topic-parent');if(await details.getAttribute('open')===null)await details.locator('summary').click();await page.locator('[data-action="rtmOpen"]').click()}
function chromePath(){if(process.env.AMC8_BROWSER_EXECUTABLE)return process.env.AMC8_BROWSER_EXECUTABLE;for(const name of ['google-chrome','google-chrome-stable','chromium','chromium-browser']){const x=cp.spawnSync('which',[name],{encoding:'utf8'});if(x.status===0)return x.stdout.trim()}return null}
async function scenario(page,c,context,base){
 const start=mode=>page.locator('[data-action="rtmStart"][data-mode="'+mode+'"]').click();
 const answer=async()=>{const a=await page.evaluate(()=>saved.rtm1.sessions.active),value=String(a.definition.answerContract.expected);if(a.definition.answerContract.kind==='choice')await page.locator('[data-action="rtmChoice"][data-value="'+value+'"]').click();else await page.locator('[data-rtm-input]').fill(value);await page.locator('[data-action="rtmSubmit"]').click()};
 if(c.id.startsWith('CONNECTED-')){
  assert.equal(await page.getByRole('button',{name:'打开真题应用',exact:true}).count(),0);
  if(c.id==='CONNECTED-presentation-blocked'){
   assert.equal(await page.evaluate(()=>ExamMappingUI.connectedAvailability()),0);assert.equal(await page.locator('[data-rtm-task]').count(),0);return;
  }
  await page.locator('[data-action="topicStart"]').first().click();await page.locator('[data-rtm-task]').waitFor();
  assert.equal(await page.locator('[data-action="rtmModes"]').count(),0);
  if(c.id==='CONNECTED-skip-withholds-original'){
   await page.locator('[data-action="rtmNext"]').click();await page.locator('[data-connected-summary]').waitFor();
   assert.equal(await page.evaluate(()=>Object.values(saved.rtm1.eventsById).some(e=>e.type==='problem_presented'&&e.examId)),false);return;
  }
  if(c.id==='CONNECTED-refresh-snapshot'){
   const before=await page.evaluate(()=>saved.rtm1.sessions.active);await page.locator('[data-action="rtmHint"]').first().click();
   await page.evaluate(()=>{saved.topicPractice.selectedTopicIds=[];saved.topicPractice.sourceIds=[];persist()});
   await page.reload({waitUntil:'domcontentloaded'});await page.waitForFunction(()=>progressStore.getStatus()==='ready');await page.locator('[data-action="rtmConnectedResume"]').click();
   assert.equal(await page.evaluate(()=>saved.rtm1.sessions.active.attemptId),before.attemptId);
   assert.deepEqual(await page.evaluate(()=>saved.rtm1.sessions.active.profileSnapshot),before.profileSnapshot);
  }
  let n=0;while(await page.evaluate(()=>saved.rtm1.sessions.active.kind==='training')){
   const panel=page.locator('[data-rtm-task]');const pos=await panel.evaluate(el=>({q:el.querySelector('.task-title').getBoundingClientRect().bottom,h:el.querySelector('.competition-hints').getBoundingClientRect().top,a:el.querySelector('form').getBoundingClientRect().top}));assert(pos.h>=pos.q&&pos.a>pos.h);
   await answer();await page.locator('[data-action="rtmNext"]').click();assert(++n<8);
  }
  assert.equal(await page.evaluate(()=>saved.rtm1.sessions.active.examId),'AMC8-2000-01');assert.equal(await page.evaluate(()=>saved.rtm1.sessions.active.mode),'practice');
  assert.equal(await page.evaluate(()=>saved.rtm1.sessions.active.readinessSnapshot.independentHoldout),false);await answer();
  assert.equal(await page.evaluate(()=>TransferEvidenceStore.statistics(saved.rtm1).holdoutSubmitted),0);return;
 }
 if(c.id.startsWith('PATHWAY-')){
  await page.locator('[data-action="rtmPathway"]').click();await page.locator('[data-rtm-task]').waitFor();
  const plan=await page.evaluate(()=>Object.values(saved.rtm1.assignmentsById)[0]);assert.equal(plan.holdoutExamId,'AMC8-2001-03');
  if(c.id==='PATHWAY-scope-change'){
   await answer();await page.evaluate(()=>{saved.topicPractice.selectedTopicIds=[];persist()});await page.locator('[data-action="rtmNext"]').click();
   assert.equal(await page.evaluate(()=>saved.rtm1.sessions.pathway.stage),'blocked');assert.equal(await page.locator('[data-rtm-task]').count(),0);return;
  }
  let n=0;while(await page.evaluate(()=>saved.rtm1.sessions.active.pathwayStage==='training')){await answer();await page.locator('[data-action="rtmNext"]').click();assert(++n<=3)}
  assert.equal(n,3);assert.equal(await page.evaluate(()=>saved.rtm1.sessions.active.mode),'exam_holdout');
  assert.equal(await page.locator('[data-rtm-task]').getAttribute('data-rtm-task'),plan.holdoutExamId);await answer();
  assert.equal(await page.evaluate(()=>TransferEvidenceStore.statistics(saved.rtm1).holdoutFirstUnassistedCorrect),1);return;
 }
 if(c.id==='HOLDOUT-help-conversion'){
  await start('exam_holdout');await page.locator('[data-action="rtmHint"]').first().click();await answer();
  const result=await page.evaluate(()=>({a:saved.rtm1.sessions.active,s:TransferEvidenceStore.statistics(saved.rtm1)}));
  assert.equal(result.a.mode,'practice');assert.equal(result.s.holdoutHelpConversions,1);assert.equal(result.s.holdoutFirstUnassistedCorrect,0);return;
 }
 if(c.id==='DIAGNOSTIC-return-to-first-attempt'){
  await start('exam_holdout');const parent=await page.evaluate(()=>saved.rtm1.sessions.active.attemptId);
  await page.locator('[data-rtm-input]').fill('15');await page.locator('[data-action="rtmSubmit"]').click();
  await page.locator('[data-action="rtmDiagnostic"]').click();await answer();await page.locator('[data-action="rtmReturnParent"]').click();await answer();
  assert.equal(await page.evaluate(()=>saved.rtm1.sessions.active.attemptId),parent);
  assert.equal(await page.evaluate(()=>TransferEvidenceStore.instance(saved.rtm1,saved.rtm1.sessions.active.mathKey).firstSubmission.input),'15');
  assert.equal(await page.evaluate(()=>TransferEvidenceStore.statistics(saved.rtm1).holdoutFirstUnassistedCorrect),0);return;
 }
 if(c.id==='POLICY-negative'){await start('practice');assert.equal(await page.locator('[data-rtm-task]').count(),0);assert.equal(await page.evaluate(()=>Object.keys(saved.rtm1.eventsById).length),0);return}
 if(c.id==='HISTORY-future-record'){
  const before=await page.evaluate(()=>JSON.stringify(saved.rtm1));await start('practice');assert.equal(await page.evaluate(()=>JSON.stringify(saved.rtm1)),before);assert((await page.locator('#app').innerText()).includes('只读'));return;
 }
 if(c.id==='HOLDOUT-contaminated'){
  await start('training');await page.locator('[data-rtm-task]').waitFor();await page.locator('[data-action="rtmHint"]').first().click();await page.locator('[data-action="rtmModes"]').click();await start('exam_holdout');assert.equal(await page.locator('[data-rtm-task]').count(),0);assert((await page.locator('#app').innerText()).includes('没有合格的新题'));return;
 }
 await start(c.id==='HOLDOUT-fresh'?'exam_holdout':'practice');await page.locator('[data-rtm-task]').waitFor();
 if(c.id==='HOLDOUT-fresh'){
  await page.locator('[data-rtm-input]').fill('6');await page.locator('[data-action="rtmSubmit"]').click();
  const record=await page.evaluate(()=>{const a=saved.rtm1.sessions.active;return {mode:a.mode,first:TransferEvidenceStore.instance(saved.rtm1,a.mathKey).firstSubmission,stats:TransferEvidenceStore.statistics(saved.rtm1)}});
  assert.equal(record.mode,'exam_holdout');assert.equal(record.first.supportSnapshot.methodHelpCount,0);assert.equal(record.first.result.level,null);assert.equal(record.stats.firstUnassistedCorrect,1);return;
 }
 if(c.id==='STORAGE-quota'){
  const raw=await page.evaluate(()=>localStorage.getItem(STORE));await page.evaluate(()=>{Storage.prototype.setItem=function(){throw new DOMException('quota fixture','QuotaExceededError')}});
  await page.locator('[data-rtm-input]').fill('6');await page.locator('[data-action="rtmSubmit"]').click();assert.equal(await page.evaluate(()=>localStorage.getItem(STORE)),raw);assert.equal(await page.evaluate(()=>Object.values(saved.rtm1.eventsById).filter(e=>e.type==='response_submitted').length),0);assert.equal(await page.evaluate(()=>progressSnapshot().rtmDraft.activeInput),'6');assert((await page.locator('#storage-status').innerText()).includes('未能保存'));return;
 }
 if(c.id==='STORAGE-competing-writer'){
  const other=await context.newPage();await other.goto(base+'/qa/normal/',{waitUntil:'domcontentloaded'});await other.waitForFunction(()=>progressStore.getStatus()==='read_only');
  const before=await other.evaluate(()=>localStorage.getItem(STORE));await parentConsole(other);await other.locator('[data-rtm-input]').fill('6');await other.locator('[data-action="rtmSubmit"]').click();assert.equal(await other.evaluate(()=>localStorage.getItem(STORE)),before);await other.close();return;
 }
 throw Error('Unknown native scenario '+c.id);
}
async function run(){
 const binary=chromePath();if(!binary){console.error('BROWSER_UNAVAILABLE: Native Chrome is required');process.exitCode=2;return}
 fs.mkdirSync(out,{recursive:true});
 const server=http.createServer((req,res)=>{try{const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname),file=path.resolve(root,'.'+name);if(!file.startsWith(root+path.sep))throw Error('path');const p=fs.statSync(file).isDirectory()?path.join(file,'index.html'):file;res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(p))}catch{res.writeHead(404).end()}});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:binary,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{for(const c of cases.filter(c=>["AMC8-2001-17", "AMC8-2026-02", "AMC8-2000-01", "RTM-2026-10-DECISION"].includes(c.id))){
  const context=await browser.newContext({locale:'zh-CN',viewport:{width:1280,height:900}});
  await context.addInitScript(({version,revision,topics,examIds,seed,future})=>{
   const key='tianle_amc8_qa_normal_rc'+version+'_v1';
   if(!localStorage.getItem(key))localStorage.setItem(key,JSON.stringify({contentRevision:revision,storageVersion:2,topicPractice:{sourceIds:['AMC8'],examIds,selectedTopicIds:topics,nextSeed:1},competition:{attempts:[],extensions:[]},rtm1:future?{schemaVersion:999,future:{original:['保留',1]}}:{schemaVersion:1,eventsById:{},sessions:{nextSeed:seed}}}));
   window.__rtmSpoken=[];window.__rtmStops=0;
   Object.defineProperty(window,'speechSynthesis',{value:{speak:u=>window.__rtmSpoken.push(u.text),cancel:()=>window.__rtmStops++,pause(){},resume(){},paused:false},configurable:true});window.SpeechSynthesisUtterance=class{constructor(text){this.text=text}};
  },{version:release.siteVersion.match(/rc\.(\d+)/)[1],revision:release.contentRevision,topics:Skills.units.map(u=>u.id),examIds:c.id.startsWith('PATHWAY-')?['AMC8-2000-01','AMC8-2001-03']:c.examId?[c.examId]:[],seed:c.seed,future:c.id==='HISTORY-future-record'});
  const page=await context.newPage(),errors=[],row={caseId:c.id,shard,kind:c.kind,status:'NOT_RUN',mappingBuildId:M.data.mappingBuildId};page.setDefaultTimeout(15000);
  page.on('pageerror',e=>errors.push(e.message));page.on('console',e=>{if(e.type()==='error'&&e.text().includes('Action failed'))errors.push(e.text())});
  try{
   await page.goto(base+'/qa/normal/',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>progressStore.getStatus()==='ready');
   if(c.id==='CONNECTED-presentation-blocked')await page.evaluate(id=>{window.__AMC8_CHILD_FORMS.problems[id]={status:'PENDING'};render()},c.examId);
   if(!c.id.startsWith('CONNECTED-'))await parentConsole(page);
   if(c.kind==='scenario')await scenario(page,c,context,base);
   else if(c.childRestricted){
    await page.locator('[data-action="rtmStart"][data-mode="'+(c.kind==='training'?'training':'practice')+'"]').click();
    assert.equal(await page.locator('[data-rtm-task]').count(),0);
    assert.equal(await page.evaluate(()=>Object.keys(saved.rtm1?.eventsById||{}).length),0);
    row.presentationRestricted=true;row.withheldWithoutAttempt=true;
   }
   else{
   await page.locator('[data-action="rtmStart"][data-mode="'+(c.kind==='training'?'training':'practice')+'"]').click();
   const panel=page.locator('[data-rtm-task]');await panel.waitFor();assert.equal(await panel.getAttribute('data-rtm-task'),c.id);
   assert.equal(await panel.locator('[data-rtm-help-figure]').count(),0);
   assert.equal(await page.evaluate(()=>Object.values(saved.rtm1.eventsById).filter(e=>e.type==='problem_presented').length),1);
   await panel.locator('[data-action="rtmRead"]').click();
   const statement=await page.evaluate(()=>{const d=saved.rtm1.sessions.active.definition;return {text:d.prompt+' '+(d.givenText||''),table:d.givenTable||[]}});
   // Authored data rows are part of the statement's narration contract.
   const tableNarration=statement.table.map((values,i)=>'数据表第'+(i+1)+'行：'+values.join('，')).join('；');
   const expectedRead=statement.text+(tableNarration?' '+tableNarration:'');
   assert.equal(await page.evaluate(()=>window.__rtmSpoken.at(-1)),expectedRead);row.statementTableRows=statement.table.length;
   const contract=c.definition.answerContract,good=Array.isArray(contract.expected)?contract.expected.join(','):String(contract.expected);
   let wrong;
   if(contract.kind==='choice'){wrong=c.definition.options.find(o=>o.id!==good).id;await panel.locator('[data-action="rtmChoice"][data-value="'+wrong+'"]').click()}
   else{wrong=contract.kind==='rational'?'('+good+')+1':Array.isArray(contract.expected)?contract.expected.slice(1).join(','):'0';await panel.locator('[data-rtm-input]').fill(wrong)}
   await panel.locator('[data-action="rtmSubmit"]').click();assert((await panel.locator('[data-rtm-feedback]').innerText()).includes('还未通过'));
   const first=await page.evaluate(()=>TransferEvidenceStore.instance(saved.rtm1,saved.rtm1.sessions.active.mathKey).firstSubmission);assert.equal(first.input,wrong);
   await panel.locator('[data-action="rtmHint"]').first().click();assert(await panel.getByRole('button',{name:'🔊 朗读提示',exact:true}).isVisible());
   const position=await panel.evaluate(el=>({q:el.querySelector('.task-title').getBoundingClientRect().bottom,h:el.querySelector('.competition-hints').getBoundingClientRect().top}));assert(position.h>=position.q);
   await panel.locator('[data-action="rtmReadHint"]').click();assert.equal(await page.evaluate(()=>window.__rtmSpoken.at(-1)),await page.evaluate(()=>saved.rtm1.sessions.active.definition.hints[0]));
   if(contract.kind==='choice')await panel.locator('[data-action="rtmChoice"][data-value="'+good+'"]').click();else await panel.locator('[data-rtm-input]').fill(good);
   await panel.locator('[data-action="rtmSubmit"]').click();assert((await panel.locator('[data-rtm-feedback]').innerText()).includes('答案正确'));
   const result=await page.evaluate(()=>{const a=saved.rtm1.sessions.active,first=TransferEvidenceStore.instance(saved.rtm1,a.mathKey).firstSubmission;return {first,feedback:a.feedback,events:Object.values(saved.rtm1.eventsById),key:a.mathKey,solved:CompetitionIdentity.solvedKeys(saved.competition).has(a.mathKey)}});
   assert.equal(result.first.input,wrong);assert.equal(result.feedback.outcome,'VERIFIED');if(c.kind==='exam')assert(result.solved);
   assert(result.events.some(e=>e.type==='statement_read_requested'));assert(result.events.some(e=>e.type==='hint_read_requested'));
   const attempts=result.events.filter(e=>e.type==='response_submitted').length;await panel.locator('[data-action="rtmSubmit"]').click();assert.equal(await page.evaluate(()=>Object.values(saved.rtm1.eventsById).filter(e=>e.type==='response_submitted').length),attempts);
   await page.reload({waitUntil:'domcontentloaded'});await page.waitForFunction(()=>progressStore.getStatus()==='ready');await parentConsole(page);await panel.waitFor();
   assert.equal(await panel.getAttribute('data-rtm-task'),c.id);assert.equal(await page.evaluate(()=>saved.rtm1.sessions.active.input),good);
   const beforeHistory=await page.evaluate(()=>Object.keys(saved.rtm1.eventsById).length);
   await panel.locator('[data-action="rtmHistory"]').click();await page.locator('[data-action="rtmReview"]').first().click();assert.equal(await page.locator('[data-rtm-history] form').count(),0);assert((await page.locator('[data-rtm-history]').innerText()).includes(wrong));assert.equal(await page.evaluate(()=>Object.keys(saved.rtm1.eventsById).length),beforeHistory);await page.locator('[data-action="rtmHistory"]').click();await page.locator('[data-action="rtmReturn"]').click();
   await panel.locator('[data-action="rtmNext"]').click();assert.equal(await page.locator('[data-rtm-task="'+c.id+'"]').count(),0);
   row.firstResponsePreserved=true;row.refreshed=true;row.solvedExcluded=true;row.narrationContract=true;row.historyReadOnly=true;
   }
   assert.equal(errors.length,0,errors.join('\n'));
   row.status='PASS';row.nativeBrowser=browser.version();
  }catch(error){row.status='FAIL';row.error=error.stack;await page.screenshot({path:path.join(out,c.id+'-failure.png'),fullPage:true}).catch(()=>{});fs.writeFileSync(path.join(out,c.id+'-failure.html'),await page.locator('#app').evaluate(el=>el.outerHTML).catch(()=>''));}
  rows.push(row);console.log(JSON.stringify(row));await context.close();
 }}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
 const report={schema:1,shard,shards,mappingBuildId:M.data.mappingBuildId,expectedCaseIds:cases.filter(c=>["AMC8-2001-17", "AMC8-2026-02", "AMC8-2000-01", "RTM-2026-10-DECISION"].includes(c.id)).map(c=>c.id),rows,result:rows.every(r=>r.status==='PASS')?'PASS':'FAIL',audioEvidence:'narration requests only',learningEffect:'NOT_MEASURED'};
 fs.writeFileSync(path.join(out,'rtm1-browser-'+shard+'.json'),JSON.stringify(report,null,2)+'\n');if(report.result!=='PASS')process.exitCode=1;
}
run().catch(e=>{console.error(e);process.exitCode=1});
